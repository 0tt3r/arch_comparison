module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @stage : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 8 : i64} : !qlx.logical_qubit
    %9 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 9 : i64} : !qlx.logical_qubit
    %10 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 10 : i64} : !qlx.logical_qubit
    %11 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 11 : i64} : !qlx.logical_qubit
    %12 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 12 : i64} : !qlx.logical_qubit
    %13 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 13 : i64} : !qlx.logical_qubit
    %14 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 14 : i64} : !qlx.logical_qubit
    %15 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 15 : i64} : !qlx.logical_qubit
    %16 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 16 : i64} : !qlx.logical_qubit
    %17 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 17 : i64} : !qlx.logical_qubit
    %18 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 18 : i64} : !qlx.logical_qubit
    %19 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 19 : i64} : !qlx.logical_qubit
    %20 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 20 : i64} : !qlx.logical_qubit
    %21 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 21 : i64} : !qlx.logical_qubit
    %22 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 22 : i64} : !qlx.logical_qubit
    %23 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 23 : i64} : !qlx.logical_qubit
    %24 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 24 : i64} : !qlx.logical_qubit
    %25 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 25 : i64} : !qlx.logical_qubit
    %26 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 26 : i64} : !qlx.logical_qubit
    %27 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 27 : i64} : !qlx.logical_qubit
    %28 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 28 : i64} : !qlx.logical_qubit
    %29 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 29 : i64} : !qlx.logical_qubit
    %30 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 30 : i64} : !qlx.logical_qubit
    %31 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 31 : i64} : !qlx.logical_qubit
    %32 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 32 : i64} : !qlx.logical_qubit
    %33 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 33 : i64} : !qlx.logical_qubit
    %34 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 34 : i64} : !qlx.logical_qubit
    %35:2 = qlx.apply #qlx.action<cx>(%0, %1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %36:2 = qlx.apply #qlx.action<cx>(%2, %3) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %37:2 = qlx.apply #qlx.action<cx>(%4, %5) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %38:2 = qlx.apply #qlx.action<cx>(%6, %7) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %39:2 = qlx.apply #qlx.action<cx>(%8, %9) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %40:2 = qlx.apply #qlx.action<cx>(%10, %11) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %41:2 = qlx.apply #qlx.action<cx>(%12, %13) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %42:2 = qlx.apply #qlx.action<cx>(%14, %15) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %43:2 = qlx.apply #qlx.action<cx>(%16, %17) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44:2 = qlx.apply #qlx.action<cx>(%18, %19) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %45:2 = qlx.apply #qlx.action<cx>(%20, %21) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %46:2 = qlx.apply #qlx.action<cx>(%22, %23) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %47:2 = qlx.apply #qlx.action<cx>(%24, %25) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %48:2 = qlx.apply #qlx.action<cx>(%26, %27) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %49:2 = qlx.apply #qlx.action<cx>(%28, %29) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %50:2 = qlx.apply #qlx.action<cx>(%30, %31) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %51:2 = qlx.apply #qlx.action<cx>(%35#1, %36#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %52:2 = qlx.apply #qlx.action<cx>(%51#0, %37#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %53 = qlx.apply #qlx.action<h>(%32) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %54 = qlx.apply #qlx.action<t>(%53) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %55:2 = qlx.apply #qlx.action<cx>(%52#1, %54) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %56 = qlx.apply #qlx.action<tdg>(%55#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %57:2 = qlx.apply #qlx.action<cx>(%51#1, %56) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %58 = qlx.apply #qlx.action<t>(%57#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %59:2 = qlx.apply #qlx.action<cx>(%55#0, %58) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %60 = qlx.apply #qlx.action<tdg>(%59#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %61 = qlx.apply #qlx.action<h>(%60) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %62 = qlx.apply #qlx.action<sdg>(%61) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %63:2 = qlx.apply #qlx.action<cx>(%52#0, %62) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64:2 = qlx.apply #qlx.action<cx>(%57#0, %59#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %65:2 = qlx.apply #qlx.action<cx>(%63#0, %64#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %66 = qlx.apply #qlx.action<h>(%33) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %67 = qlx.apply #qlx.action<t>(%66) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %68:2 = qlx.apply #qlx.action<cx>(%65#1, %67) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %69 = qlx.apply #qlx.action<tdg>(%68#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %70:2 = qlx.apply #qlx.action<cx>(%38#1, %69) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %71 = qlx.apply #qlx.action<t>(%70#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %72:2 = qlx.apply #qlx.action<cx>(%68#0, %71) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %73 = qlx.apply #qlx.action<tdg>(%72#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %74 = qlx.apply #qlx.action<h>(%73) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %75 = qlx.apply #qlx.action<sdg>(%74) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %76:2 = qlx.apply #qlx.action<cx>(%70#0, %72#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %77 = qlx.apply #qlx.action<h>(%34) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %78 = qlx.apply #qlx.action<t>(%77) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %79:2 = qlx.apply #qlx.action<cx>(%75, %78) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %80 = qlx.apply #qlx.action<tdg>(%79#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %81:2 = qlx.apply #qlx.action<cx>(%63#1, %80) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %82 = qlx.apply #qlx.action<t>(%81#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %83:2 = qlx.apply #qlx.action<cx>(%79#0, %82) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %84 = qlx.apply #qlx.action<tdg>(%83#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %85 = qlx.apply #qlx.action<h>(%84) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %86 = qlx.apply #qlx.action<sdg>(%85) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %87:2 = qlx.apply #qlx.action<cx>(%81#0, %83#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst = arith.constant 0.055555555555555552 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%76#1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_0 = arith.constant 0.1111111111111111 : f64
    %89 = qlx.apply #qlx.action<pauli_rotation>(%87#1, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 0.22222222222222221 : f64
    %90 = qlx.apply #qlx.action<pauli_rotation>(%86, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %91:2 = qlx.apply #qlx.action<cx>(%87#0, %89) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %92 = qlx.measure <X> %90 : !qlx.logical_qubit -> i1
    %93:2 = cflow.if %92 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%91#0, %91#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %91#0, %91#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %94:2 = qlx.apply #qlx.action<cx>(%76#0, %88) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %95 = qlx.measure <X> %93#1 : !qlx.logical_qubit -> i1
    %96:2 = cflow.if %95 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%94#0, %94#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %94#0, %94#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %97:2 = qlx.apply #qlx.action<cx>(%65#0, %96#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %98:2 = qlx.apply #qlx.action<cx>(%64#0, %97#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %99:2 = qlx.apply #qlx.action<cx>(%97#0, %93#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %100 = qlx.measure <X> %99#1 : !qlx.logical_qubit -> i1
    %101:2 = cflow.if %100 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%98#0, %98#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %98#0, %98#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %102:2 = qlx.apply #qlx.action<cx>(%99#0, %101#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %103:2 = qlx.apply #qlx.action<cx>(%102#0, %101#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %104:2 = qlx.apply #qlx.action<cx>(%39#1, %40#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %105:2 = qlx.apply #qlx.action<cx>(%104#0, %41#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %106 = qlx.prepare "zero" {allocation = 1 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %107 = qlx.apply #qlx.action<h>(%106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %108 = qlx.apply #qlx.action<t>(%107) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %109:2 = qlx.apply #qlx.action<cx>(%105#1, %108) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %110 = qlx.apply #qlx.action<tdg>(%109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %111:2 = qlx.apply #qlx.action<cx>(%104#1, %110) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %112 = qlx.apply #qlx.action<t>(%111#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %113:2 = qlx.apply #qlx.action<cx>(%109#0, %112) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %114 = qlx.apply #qlx.action<tdg>(%113#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %115 = qlx.apply #qlx.action<h>(%114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %116 = qlx.apply #qlx.action<sdg>(%115) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %117:2 = qlx.apply #qlx.action<cx>(%105#0, %116) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %118:2 = qlx.apply #qlx.action<cx>(%111#0, %113#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %119:2 = qlx.apply #qlx.action<cx>(%117#0, %118#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %120 = qlx.prepare "zero" {allocation = 2 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %121 = qlx.apply #qlx.action<h>(%120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %122 = qlx.apply #qlx.action<t>(%121) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %123:2 = qlx.apply #qlx.action<cx>(%119#1, %122) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %124 = qlx.apply #qlx.action<tdg>(%123#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %125:2 = qlx.apply #qlx.action<cx>(%42#1, %124) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %126 = qlx.apply #qlx.action<t>(%125#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %127:2 = qlx.apply #qlx.action<cx>(%123#0, %126) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %128 = qlx.apply #qlx.action<tdg>(%127#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %129 = qlx.apply #qlx.action<h>(%128) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %130 = qlx.apply #qlx.action<sdg>(%129) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %131:2 = qlx.apply #qlx.action<cx>(%125#0, %127#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %132 = qlx.prepare "zero" {allocation = 3 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %133 = qlx.apply #qlx.action<h>(%132) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %134 = qlx.apply #qlx.action<t>(%133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %135:2 = qlx.apply #qlx.action<cx>(%130, %134) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %136 = qlx.apply #qlx.action<tdg>(%135#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %137:2 = qlx.apply #qlx.action<cx>(%117#1, %136) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %138 = qlx.apply #qlx.action<t>(%137#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %139:2 = qlx.apply #qlx.action<cx>(%135#0, %138) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %140 = qlx.apply #qlx.action<tdg>(%139#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %141 = qlx.apply #qlx.action<h>(%140) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %142 = qlx.apply #qlx.action<sdg>(%141) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %143:2 = qlx.apply #qlx.action<cx>(%137#0, %139#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2 = arith.constant 0.055555555555555552 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%131#1, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_3 = arith.constant 0.1111111111111111 : f64
    %145 = qlx.apply #qlx.action<pauli_rotation>(%143#1, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_4 = arith.constant 0.22222222222222221 : f64
    %146 = qlx.apply #qlx.action<pauli_rotation>(%142, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %147:2 = qlx.apply #qlx.action<cx>(%143#0, %145) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %148 = qlx.measure <X> %146 : !qlx.logical_qubit -> i1
    %149:2 = cflow.if %148 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%147#0, %147#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %147#0, %147#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %150:2 = qlx.apply #qlx.action<cx>(%131#0, %144) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %151 = qlx.measure <X> %149#1 : !qlx.logical_qubit -> i1
    %152:2 = cflow.if %151 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%150#0, %150#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %150#0, %150#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %153:2 = qlx.apply #qlx.action<cx>(%119#0, %152#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %154:2 = qlx.apply #qlx.action<cx>(%118#0, %153#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %155:2 = qlx.apply #qlx.action<cx>(%153#0, %149#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %156 = qlx.measure <X> %155#1 : !qlx.logical_qubit -> i1
    %157:2 = cflow.if %156 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%154#0, %154#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %154#0, %154#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %158:2 = qlx.apply #qlx.action<cx>(%155#0, %157#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %159:2 = qlx.apply #qlx.action<cx>(%158#0, %157#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %160:2 = qlx.apply #qlx.action<cx>(%43#1, %44#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %161:2 = qlx.apply #qlx.action<cx>(%160#0, %45#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %162 = qlx.prepare "zero" {allocation = 4 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %163 = qlx.apply #qlx.action<h>(%162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %164 = qlx.apply #qlx.action<t>(%163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %165:2 = qlx.apply #qlx.action<cx>(%161#1, %164) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %166 = qlx.apply #qlx.action<tdg>(%165#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %167:2 = qlx.apply #qlx.action<cx>(%160#1, %166) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %168 = qlx.apply #qlx.action<t>(%167#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %169:2 = qlx.apply #qlx.action<cx>(%165#0, %168) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %170 = qlx.apply #qlx.action<tdg>(%169#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %171 = qlx.apply #qlx.action<h>(%170) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %172 = qlx.apply #qlx.action<sdg>(%171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %173:2 = qlx.apply #qlx.action<cx>(%161#0, %172) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %174:2 = qlx.apply #qlx.action<cx>(%167#0, %169#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %175:2 = qlx.apply #qlx.action<cx>(%173#0, %174#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %176 = qlx.prepare "zero" {allocation = 5 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %177 = qlx.apply #qlx.action<h>(%176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %178 = qlx.apply #qlx.action<t>(%177) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %179:2 = qlx.apply #qlx.action<cx>(%175#1, %178) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %180 = qlx.apply #qlx.action<tdg>(%179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %181:2 = qlx.apply #qlx.action<cx>(%46#1, %180) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %182 = qlx.apply #qlx.action<t>(%181#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %183:2 = qlx.apply #qlx.action<cx>(%179#0, %182) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %184 = qlx.apply #qlx.action<tdg>(%183#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %185 = qlx.apply #qlx.action<h>(%184) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %186 = qlx.apply #qlx.action<sdg>(%185) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %187:2 = qlx.apply #qlx.action<cx>(%181#0, %183#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %188 = qlx.prepare "zero" {allocation = 6 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %189 = qlx.apply #qlx.action<h>(%188) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %190 = qlx.apply #qlx.action<t>(%189) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %191:2 = qlx.apply #qlx.action<cx>(%186, %190) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %192 = qlx.apply #qlx.action<tdg>(%191#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %193:2 = qlx.apply #qlx.action<cx>(%173#1, %192) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %194 = qlx.apply #qlx.action<t>(%193#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %195:2 = qlx.apply #qlx.action<cx>(%191#0, %194) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %196 = qlx.apply #qlx.action<tdg>(%195#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<h>(%196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %198 = qlx.apply #qlx.action<sdg>(%197) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %199:2 = qlx.apply #qlx.action<cx>(%193#0, %195#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_5 = arith.constant 0.055555555555555552 : f64
    %200 = qlx.apply #qlx.action<pauli_rotation>(%187#1, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_6 = arith.constant 0.1111111111111111 : f64
    %201 = qlx.apply #qlx.action<pauli_rotation>(%199#1, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 0.22222222222222221 : f64
    %202 = qlx.apply #qlx.action<pauli_rotation>(%198, %cst_7) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %203:2 = qlx.apply #qlx.action<cx>(%199#0, %201) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %204 = qlx.measure <X> %202 : !qlx.logical_qubit -> i1
    %205:2 = cflow.if %204 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%203#0, %203#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %203#0, %203#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %206:2 = qlx.apply #qlx.action<cx>(%187#0, %200) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %207 = qlx.measure <X> %205#1 : !qlx.logical_qubit -> i1
    %208:2 = cflow.if %207 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%206#0, %206#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %206#0, %206#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %209:2 = qlx.apply #qlx.action<cx>(%175#0, %208#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %210:2 = qlx.apply #qlx.action<cx>(%174#0, %209#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %211:2 = qlx.apply #qlx.action<cx>(%209#0, %205#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %212 = qlx.measure <X> %211#1 : !qlx.logical_qubit -> i1
    %213:2 = cflow.if %212 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%210#0, %210#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %210#0, %210#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %214:2 = qlx.apply #qlx.action<cx>(%211#0, %213#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %215:2 = qlx.apply #qlx.action<cx>(%214#0, %213#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %216:2 = qlx.apply #qlx.action<cx>(%47#1, %48#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %217:2 = qlx.apply #qlx.action<cx>(%216#0, %49#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %218 = qlx.prepare "zero" {allocation = 7 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %219 = qlx.apply #qlx.action<h>(%218) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<t>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %221:2 = qlx.apply #qlx.action<cx>(%217#1, %220) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %222 = qlx.apply #qlx.action<tdg>(%221#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %223:2 = qlx.apply #qlx.action<cx>(%216#1, %222) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %224 = qlx.apply #qlx.action<t>(%223#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %225:2 = qlx.apply #qlx.action<cx>(%221#0, %224) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %226 = qlx.apply #qlx.action<tdg>(%225#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %227 = qlx.apply #qlx.action<h>(%226) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %228 = qlx.apply #qlx.action<sdg>(%227) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %229:2 = qlx.apply #qlx.action<cx>(%217#0, %228) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %230:2 = qlx.apply #qlx.action<cx>(%223#0, %225#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %231:2 = qlx.apply #qlx.action<cx>(%229#0, %230#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %232 = qlx.prepare "zero" {allocation = 8 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<h>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %234 = qlx.apply #qlx.action<t>(%233) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %235:2 = qlx.apply #qlx.action<cx>(%231#1, %234) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %236 = qlx.apply #qlx.action<tdg>(%235#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %237:2 = qlx.apply #qlx.action<cx>(%50#1, %236) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %238 = qlx.apply #qlx.action<t>(%237#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %239:2 = qlx.apply #qlx.action<cx>(%235#0, %238) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %240 = qlx.apply #qlx.action<tdg>(%239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %241 = qlx.apply #qlx.action<h>(%240) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %242 = qlx.apply #qlx.action<sdg>(%241) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %243:2 = qlx.apply #qlx.action<cx>(%237#0, %239#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %244 = qlx.prepare "zero" {allocation = 9 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %245 = qlx.apply #qlx.action<h>(%244) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %246 = qlx.apply #qlx.action<t>(%245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %247:2 = qlx.apply #qlx.action<cx>(%242, %246) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %248 = qlx.apply #qlx.action<tdg>(%247#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %249:2 = qlx.apply #qlx.action<cx>(%229#1, %248) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %250 = qlx.apply #qlx.action<t>(%249#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %251:2 = qlx.apply #qlx.action<cx>(%247#0, %250) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %252 = qlx.apply #qlx.action<tdg>(%251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %253 = qlx.apply #qlx.action<h>(%252) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %254 = qlx.apply #qlx.action<sdg>(%253) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %255:2 = qlx.apply #qlx.action<cx>(%249#0, %251#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_8 = arith.constant 0.055555555555555552 : f64
    %256 = qlx.apply #qlx.action<pauli_rotation>(%243#1, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_9 = arith.constant 0.1111111111111111 : f64
    %257 = qlx.apply #qlx.action<pauli_rotation>(%255#1, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_10 = arith.constant 0.22222222222222221 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%254, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259:2 = qlx.apply #qlx.action<cx>(%255#0, %257) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %260 = qlx.measure <X> %258 : !qlx.logical_qubit -> i1
    %261:2 = cflow.if %260 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%259#0, %259#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %259#0, %259#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %262:2 = qlx.apply #qlx.action<cx>(%243#0, %256) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %263 = qlx.measure <X> %261#1 : !qlx.logical_qubit -> i1
    %264:2 = cflow.if %263 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%262#0, %262#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %262#0, %262#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %265:2 = qlx.apply #qlx.action<cx>(%231#0, %264#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %266:2 = qlx.apply #qlx.action<cx>(%230#0, %265#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %267:2 = qlx.apply #qlx.action<cx>(%265#0, %261#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %268 = qlx.measure <X> %267#1 : !qlx.logical_qubit -> i1
    %269:2 = cflow.if %268 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %320:2 = qlx.apply #qlx.action<cz>(%266#0, %266#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %320#0, %320#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %266#0, %266#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %270:2 = qlx.apply #qlx.action<cx>(%267#0, %269#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %271:2 = qlx.apply #qlx.action<cx>(%270#0, %269#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %272:2 = qlx.apply #qlx.action<cx>(%35#0, %103#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %273:2 = qlx.apply #qlx.action<cx>(%36#0, %103#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %274:2 = qlx.apply #qlx.action<cx>(%37#0, %102#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %275:2 = qlx.apply #qlx.action<cx>(%38#0, %96#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %276:2 = qlx.apply #qlx.action<cx>(%39#0, %159#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %277:2 = qlx.apply #qlx.action<cx>(%40#0, %159#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %278:2 = qlx.apply #qlx.action<cx>(%41#0, %158#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %279:2 = qlx.apply #qlx.action<cx>(%42#0, %152#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %280:2 = qlx.apply #qlx.action<cx>(%43#0, %215#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %281:2 = qlx.apply #qlx.action<cx>(%44#0, %215#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %282:2 = qlx.apply #qlx.action<cx>(%45#0, %214#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %283:2 = qlx.apply #qlx.action<cx>(%46#0, %208#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %284:2 = qlx.apply #qlx.action<cx>(%47#0, %271#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %285:2 = qlx.apply #qlx.action<cx>(%48#0, %271#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %286:2 = qlx.apply #qlx.action<cx>(%49#0, %270#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %287:2 = qlx.apply #qlx.action<cx>(%50#0, %264#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %288 = qlx.measure <Z> %272#0 : !qlx.logical_qubit -> i1
    %289 = qlx.measure <Z> %272#1 : !qlx.logical_qubit -> i1
    %290 = qlx.measure <Z> %273#0 : !qlx.logical_qubit -> i1
    %291 = qlx.measure <Z> %273#1 : !qlx.logical_qubit -> i1
    %292 = qlx.measure <Z> %274#0 : !qlx.logical_qubit -> i1
    %293 = qlx.measure <Z> %274#1 : !qlx.logical_qubit -> i1
    %294 = qlx.measure <Z> %275#0 : !qlx.logical_qubit -> i1
    %295 = qlx.measure <Z> %275#1 : !qlx.logical_qubit -> i1
    %296 = qlx.measure <Z> %276#0 : !qlx.logical_qubit -> i1
    %297 = qlx.measure <Z> %276#1 : !qlx.logical_qubit -> i1
    %298 = qlx.measure <Z> %277#0 : !qlx.logical_qubit -> i1
    %299 = qlx.measure <Z> %277#1 : !qlx.logical_qubit -> i1
    %300 = qlx.measure <Z> %278#0 : !qlx.logical_qubit -> i1
    %301 = qlx.measure <Z> %278#1 : !qlx.logical_qubit -> i1
    %302 = qlx.measure <Z> %279#0 : !qlx.logical_qubit -> i1
    %303 = qlx.measure <Z> %279#1 : !qlx.logical_qubit -> i1
    %304 = qlx.measure <Z> %280#0 : !qlx.logical_qubit -> i1
    %305 = qlx.measure <Z> %280#1 : !qlx.logical_qubit -> i1
    %306 = qlx.measure <Z> %281#0 : !qlx.logical_qubit -> i1
    %307 = qlx.measure <Z> %281#1 : !qlx.logical_qubit -> i1
    %308 = qlx.measure <Z> %282#0 : !qlx.logical_qubit -> i1
    %309 = qlx.measure <Z> %282#1 : !qlx.logical_qubit -> i1
    %310 = qlx.measure <Z> %283#0 : !qlx.logical_qubit -> i1
    %311 = qlx.measure <Z> %283#1 : !qlx.logical_qubit -> i1
    %312 = qlx.measure <Z> %284#0 : !qlx.logical_qubit -> i1
    %313 = qlx.measure <Z> %284#1 : !qlx.logical_qubit -> i1
    %314 = qlx.measure <Z> %285#0 : !qlx.logical_qubit -> i1
    %315 = qlx.measure <Z> %285#1 : !qlx.logical_qubit -> i1
    %316 = qlx.measure <Z> %286#0 : !qlx.logical_qubit -> i1
    %317 = qlx.measure <Z> %286#1 : !qlx.logical_qubit -> i1
    %318 = qlx.measure <Z> %287#0 : !qlx.logical_qubit -> i1
    %319 = qlx.measure <Z> %287#1 : !qlx.logical_qubit -> i1
  }
}
