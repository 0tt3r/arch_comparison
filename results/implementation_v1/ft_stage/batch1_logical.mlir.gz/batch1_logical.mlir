module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @stage : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 8 : i64} : !qlx.logical_qubit
    %9 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 9 : i64} : !qlx.logical_qubit
    %10 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 10 : i64} : !qlx.logical_qubit
    %11 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 11 : i64} : !qlx.logical_qubit
    %12 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 12 : i64} : !qlx.logical_qubit
    %13 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 13 : i64} : !qlx.logical_qubit
    %14 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 14 : i64} : !qlx.logical_qubit
    %15 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 15 : i64} : !qlx.logical_qubit
    %16 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 16 : i64} : !qlx.logical_qubit
    %17 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 17 : i64} : !qlx.logical_qubit
    %18 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 18 : i64} : !qlx.logical_qubit
    %19 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 19 : i64} : !qlx.logical_qubit
    %20 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 20 : i64} : !qlx.logical_qubit
    %21 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 21 : i64} : !qlx.logical_qubit
    %22 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 22 : i64} : !qlx.logical_qubit
    %23 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 23 : i64} : !qlx.logical_qubit
    %24 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 24 : i64} : !qlx.logical_qubit
    %25 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 25 : i64} : !qlx.logical_qubit
    %26 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 26 : i64} : !qlx.logical_qubit
    %27 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 27 : i64} : !qlx.logical_qubit
    %28 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 28 : i64} : !qlx.logical_qubit
    %29 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 29 : i64} : !qlx.logical_qubit
    %30 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 30 : i64} : !qlx.logical_qubit
    %31 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 31 : i64} : !qlx.logical_qubit
    %32:2 = qlx.apply #qlx.action<cx>(%0, %1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %33:2 = qlx.apply #qlx.action<cx>(%2, %3) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %34:2 = qlx.apply #qlx.action<cx>(%4, %5) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %35:2 = qlx.apply #qlx.action<cx>(%6, %7) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %36:2 = qlx.apply #qlx.action<cx>(%8, %9) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %37:2 = qlx.apply #qlx.action<cx>(%10, %11) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %38:2 = qlx.apply #qlx.action<cx>(%12, %13) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %39:2 = qlx.apply #qlx.action<cx>(%14, %15) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %40:2 = qlx.apply #qlx.action<cx>(%16, %17) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %41:2 = qlx.apply #qlx.action<cx>(%18, %19) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %42:2 = qlx.apply #qlx.action<cx>(%20, %21) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %43:2 = qlx.apply #qlx.action<cx>(%22, %23) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44:2 = qlx.apply #qlx.action<cx>(%24, %25) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %45:2 = qlx.apply #qlx.action<cx>(%26, %27) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %46:2 = qlx.apply #qlx.action<cx>(%28, %29) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %47:2 = qlx.apply #qlx.action<cx>(%30, %31) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst = arith.constant 0.055555555555555552 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%32#1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_0 = arith.constant 0.055555555555555552 : f64
    %49 = qlx.apply #qlx.action<pauli_rotation>(%33#1, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 0.055555555555555552 : f64
    %50 = qlx.apply #qlx.action<pauli_rotation>(%34#1, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 0.055555555555555552 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%35#1, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_3 = arith.constant 0.055555555555555552 : f64
    %52 = qlx.apply #qlx.action<pauli_rotation>(%36#1, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_4 = arith.constant 0.055555555555555552 : f64
    %53 = qlx.apply #qlx.action<pauli_rotation>(%37#1, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.055555555555555552 : f64
    %54 = qlx.apply #qlx.action<pauli_rotation>(%38#1, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_6 = arith.constant 0.055555555555555552 : f64
    %55 = qlx.apply #qlx.action<pauli_rotation>(%39#1, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 0.055555555555555552 : f64
    %56 = qlx.apply #qlx.action<pauli_rotation>(%40#1, %cst_7) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_8 = arith.constant 0.055555555555555552 : f64
    %57 = qlx.apply #qlx.action<pauli_rotation>(%41#1, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_9 = arith.constant 0.055555555555555552 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%42#1, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_10 = arith.constant 0.055555555555555552 : f64
    %59 = qlx.apply #qlx.action<pauli_rotation>(%43#1, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_11 = arith.constant 0.055555555555555552 : f64
    %60 = qlx.apply #qlx.action<pauli_rotation>(%44#1, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_12 = arith.constant 0.055555555555555552 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%45#1, %cst_12) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_13 = arith.constant 0.055555555555555552 : f64
    %62 = qlx.apply #qlx.action<pauli_rotation>(%46#1, %cst_13) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_14 = arith.constant 0.055555555555555552 : f64
    %63 = qlx.apply #qlx.action<pauli_rotation>(%47#1, %cst_14) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %64:2 = qlx.apply #qlx.action<cx>(%32#0, %48) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %65:2 = qlx.apply #qlx.action<cx>(%33#0, %49) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %66:2 = qlx.apply #qlx.action<cx>(%34#0, %50) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %67:2 = qlx.apply #qlx.action<cx>(%35#0, %51) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %68:2 = qlx.apply #qlx.action<cx>(%36#0, %52) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %69:2 = qlx.apply #qlx.action<cx>(%37#0, %53) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %70:2 = qlx.apply #qlx.action<cx>(%38#0, %54) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %71:2 = qlx.apply #qlx.action<cx>(%39#0, %55) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %72:2 = qlx.apply #qlx.action<cx>(%40#0, %56) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %73:2 = qlx.apply #qlx.action<cx>(%41#0, %57) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %74:2 = qlx.apply #qlx.action<cx>(%42#0, %58) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %75:2 = qlx.apply #qlx.action<cx>(%43#0, %59) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %76:2 = qlx.apply #qlx.action<cx>(%44#0, %60) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %77:2 = qlx.apply #qlx.action<cx>(%45#0, %61) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %78:2 = qlx.apply #qlx.action<cx>(%46#0, %62) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %79:2 = qlx.apply #qlx.action<cx>(%47#0, %63) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %80 = qlx.measure <Z> %64#0 : !qlx.logical_qubit -> i1
    %81 = qlx.measure <Z> %64#1 : !qlx.logical_qubit -> i1
    %82 = qlx.measure <Z> %65#0 : !qlx.logical_qubit -> i1
    %83 = qlx.measure <Z> %65#1 : !qlx.logical_qubit -> i1
    %84 = qlx.measure <Z> %66#0 : !qlx.logical_qubit -> i1
    %85 = qlx.measure <Z> %66#1 : !qlx.logical_qubit -> i1
    %86 = qlx.measure <Z> %67#0 : !qlx.logical_qubit -> i1
    %87 = qlx.measure <Z> %67#1 : !qlx.logical_qubit -> i1
    %88 = qlx.measure <Z> %68#0 : !qlx.logical_qubit -> i1
    %89 = qlx.measure <Z> %68#1 : !qlx.logical_qubit -> i1
    %90 = qlx.measure <Z> %69#0 : !qlx.logical_qubit -> i1
    %91 = qlx.measure <Z> %69#1 : !qlx.logical_qubit -> i1
    %92 = qlx.measure <Z> %70#0 : !qlx.logical_qubit -> i1
    %93 = qlx.measure <Z> %70#1 : !qlx.logical_qubit -> i1
    %94 = qlx.measure <Z> %71#0 : !qlx.logical_qubit -> i1
    %95 = qlx.measure <Z> %71#1 : !qlx.logical_qubit -> i1
    %96 = qlx.measure <Z> %72#0 : !qlx.logical_qubit -> i1
    %97 = qlx.measure <Z> %72#1 : !qlx.logical_qubit -> i1
    %98 = qlx.measure <Z> %73#0 : !qlx.logical_qubit -> i1
    %99 = qlx.measure <Z> %73#1 : !qlx.logical_qubit -> i1
    %100 = qlx.measure <Z> %74#0 : !qlx.logical_qubit -> i1
    %101 = qlx.measure <Z> %74#1 : !qlx.logical_qubit -> i1
    %102 = qlx.measure <Z> %75#0 : !qlx.logical_qubit -> i1
    %103 = qlx.measure <Z> %75#1 : !qlx.logical_qubit -> i1
    %104 = qlx.measure <Z> %76#0 : !qlx.logical_qubit -> i1
    %105 = qlx.measure <Z> %76#1 : !qlx.logical_qubit -> i1
    %106 = qlx.measure <Z> %77#0 : !qlx.logical_qubit -> i1
    %107 = qlx.measure <Z> %77#1 : !qlx.logical_qubit -> i1
    %108 = qlx.measure <Z> %78#0 : !qlx.logical_qubit -> i1
    %109 = qlx.measure <Z> %78#1 : !qlx.logical_qubit -> i1
    %110 = qlx.measure <Z> %79#0 : !qlx.logical_qubit -> i1
    %111 = qlx.measure <Z> %79#1 : !qlx.logical_qubit -> i1
  }
}
