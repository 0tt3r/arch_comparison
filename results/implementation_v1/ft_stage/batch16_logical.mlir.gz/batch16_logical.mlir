module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @stage : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 8 : i64} : !qlx.logical_qubit
    %9 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 9 : i64} : !qlx.logical_qubit
    %10 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 10 : i64} : !qlx.logical_qubit
    %11 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 11 : i64} : !qlx.logical_qubit
    %12 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 12 : i64} : !qlx.logical_qubit
    %13 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 13 : i64} : !qlx.logical_qubit
    %14 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 14 : i64} : !qlx.logical_qubit
    %15 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 15 : i64} : !qlx.logical_qubit
    %16 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 16 : i64} : !qlx.logical_qubit
    %17 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 17 : i64} : !qlx.logical_qubit
    %18 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 18 : i64} : !qlx.logical_qubit
    %19 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 19 : i64} : !qlx.logical_qubit
    %20 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 20 : i64} : !qlx.logical_qubit
    %21 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 21 : i64} : !qlx.logical_qubit
    %22 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 22 : i64} : !qlx.logical_qubit
    %23 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 23 : i64} : !qlx.logical_qubit
    %24 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 24 : i64} : !qlx.logical_qubit
    %25 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 25 : i64} : !qlx.logical_qubit
    %26 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 26 : i64} : !qlx.logical_qubit
    %27 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 27 : i64} : !qlx.logical_qubit
    %28 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 28 : i64} : !qlx.logical_qubit
    %29 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 29 : i64} : !qlx.logical_qubit
    %30 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 30 : i64} : !qlx.logical_qubit
    %31 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 31 : i64} : !qlx.logical_qubit
    %32 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 32 : i64} : !qlx.logical_qubit
    %33 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 33 : i64} : !qlx.logical_qubit
    %34 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 34 : i64} : !qlx.logical_qubit
    %35 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 35 : i64} : !qlx.logical_qubit
    %36 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 36 : i64} : !qlx.logical_qubit
    %37 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 37 : i64} : !qlx.logical_qubit
    %38 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 38 : i64} : !qlx.logical_qubit
    %39 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 39 : i64} : !qlx.logical_qubit
    %40 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 40 : i64} : !qlx.logical_qubit
    %41 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 41 : i64} : !qlx.logical_qubit
    %42 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 42 : i64} : !qlx.logical_qubit
    %43 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 43 : i64} : !qlx.logical_qubit
    %44 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 44 : i64} : !qlx.logical_qubit
    %45 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 45 : i64} : !qlx.logical_qubit
    %46 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 46 : i64} : !qlx.logical_qubit
    %47:2 = qlx.apply #qlx.action<cx>(%0, %1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %48:2 = qlx.apply #qlx.action<cx>(%2, %3) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %49:2 = qlx.apply #qlx.action<cx>(%4, %5) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %50:2 = qlx.apply #qlx.action<cx>(%6, %7) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %51:2 = qlx.apply #qlx.action<cx>(%8, %9) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %52:2 = qlx.apply #qlx.action<cx>(%10, %11) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %53:2 = qlx.apply #qlx.action<cx>(%12, %13) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %54:2 = qlx.apply #qlx.action<cx>(%14, %15) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %55:2 = qlx.apply #qlx.action<cx>(%16, %17) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %56:2 = qlx.apply #qlx.action<cx>(%18, %19) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %57:2 = qlx.apply #qlx.action<cx>(%20, %21) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %58:2 = qlx.apply #qlx.action<cx>(%22, %23) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %59:2 = qlx.apply #qlx.action<cx>(%24, %25) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %60:2 = qlx.apply #qlx.action<cx>(%26, %27) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %61:2 = qlx.apply #qlx.action<cx>(%28, %29) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %62:2 = qlx.apply #qlx.action<cx>(%30, %31) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %63:2 = qlx.apply #qlx.action<cx>(%47#1, %48#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64:2 = qlx.apply #qlx.action<cx>(%63#0, %49#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %65 = qlx.apply #qlx.action<h>(%32) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<t>(%65) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %67:2 = qlx.apply #qlx.action<cx>(%64#1, %66) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %68 = qlx.apply #qlx.action<tdg>(%67#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %69:2 = qlx.apply #qlx.action<cx>(%63#1, %68) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %70 = qlx.apply #qlx.action<t>(%69#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %71:2 = qlx.apply #qlx.action<cx>(%67#0, %70) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %72 = qlx.apply #qlx.action<tdg>(%71#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<h>(%72) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %74 = qlx.apply #qlx.action<sdg>(%73) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %75:2 = qlx.apply #qlx.action<cx>(%64#0, %74) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %76:2 = qlx.apply #qlx.action<cx>(%69#0, %71#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %77:2 = qlx.apply #qlx.action<cx>(%75#0, %76#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %78:2 = qlx.apply #qlx.action<cx>(%50#1, %51#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %79:2 = qlx.apply #qlx.action<cx>(%78#0, %52#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %80 = qlx.apply #qlx.action<h>(%33) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %81 = qlx.apply #qlx.action<t>(%80) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %82:2 = qlx.apply #qlx.action<cx>(%79#1, %81) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %83 = qlx.apply #qlx.action<tdg>(%82#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %84:2 = qlx.apply #qlx.action<cx>(%78#1, %83) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %85 = qlx.apply #qlx.action<t>(%84#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %86:2 = qlx.apply #qlx.action<cx>(%82#0, %85) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %87 = qlx.apply #qlx.action<tdg>(%86#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %88 = qlx.apply #qlx.action<h>(%87) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %89 = qlx.apply #qlx.action<sdg>(%88) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %90:2 = qlx.apply #qlx.action<cx>(%79#0, %89) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %91:2 = qlx.apply #qlx.action<cx>(%84#0, %86#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %92:2 = qlx.apply #qlx.action<cx>(%90#0, %91#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %93:2 = qlx.apply #qlx.action<cx>(%53#1, %54#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %94:2 = qlx.apply #qlx.action<cx>(%93#0, %55#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %95 = qlx.apply #qlx.action<h>(%34) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %96 = qlx.apply #qlx.action<t>(%95) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %97:2 = qlx.apply #qlx.action<cx>(%94#1, %96) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %98 = qlx.apply #qlx.action<tdg>(%97#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %99:2 = qlx.apply #qlx.action<cx>(%93#1, %98) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %100 = qlx.apply #qlx.action<t>(%99#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %101:2 = qlx.apply #qlx.action<cx>(%97#0, %100) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %102 = qlx.apply #qlx.action<tdg>(%101#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %103 = qlx.apply #qlx.action<h>(%102) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %104 = qlx.apply #qlx.action<sdg>(%103) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %105:2 = qlx.apply #qlx.action<cx>(%94#0, %104) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %106:2 = qlx.apply #qlx.action<cx>(%99#0, %101#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %107:2 = qlx.apply #qlx.action<cx>(%105#0, %106#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %108:2 = qlx.apply #qlx.action<cx>(%56#1, %57#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %109:2 = qlx.apply #qlx.action<cx>(%108#0, %58#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %110 = qlx.apply #qlx.action<h>(%35) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %111 = qlx.apply #qlx.action<t>(%110) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %112:2 = qlx.apply #qlx.action<cx>(%109#1, %111) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %113 = qlx.apply #qlx.action<tdg>(%112#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %114:2 = qlx.apply #qlx.action<cx>(%108#1, %113) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %115 = qlx.apply #qlx.action<t>(%114#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %116:2 = qlx.apply #qlx.action<cx>(%112#0, %115) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %117 = qlx.apply #qlx.action<tdg>(%116#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %118 = qlx.apply #qlx.action<h>(%117) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %119 = qlx.apply #qlx.action<sdg>(%118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %120:2 = qlx.apply #qlx.action<cx>(%109#0, %119) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %121:2 = qlx.apply #qlx.action<cx>(%114#0, %116#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %122:2 = qlx.apply #qlx.action<cx>(%120#0, %121#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %123:2 = qlx.apply #qlx.action<cx>(%59#1, %60#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %124:2 = qlx.apply #qlx.action<cx>(%123#0, %61#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %125 = qlx.apply #qlx.action<h>(%36) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %126 = qlx.apply #qlx.action<t>(%125) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %127:2 = qlx.apply #qlx.action<cx>(%124#1, %126) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %128 = qlx.apply #qlx.action<tdg>(%127#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %129:2 = qlx.apply #qlx.action<cx>(%123#1, %128) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %130 = qlx.apply #qlx.action<t>(%129#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %131:2 = qlx.apply #qlx.action<cx>(%127#0, %130) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %132 = qlx.apply #qlx.action<tdg>(%131#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %133 = qlx.apply #qlx.action<h>(%132) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %134 = qlx.apply #qlx.action<sdg>(%133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %135:2 = qlx.apply #qlx.action<cx>(%124#0, %134) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %136:2 = qlx.apply #qlx.action<cx>(%129#0, %131#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %137:2 = qlx.apply #qlx.action<cx>(%135#0, %136#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %138:2 = qlx.apply #qlx.action<cx>(%62#1, %77#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %139:2 = qlx.apply #qlx.action<cx>(%138#0, %92#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %140 = qlx.apply #qlx.action<h>(%37) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %141 = qlx.apply #qlx.action<t>(%140) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %142:2 = qlx.apply #qlx.action<cx>(%139#1, %141) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %143 = qlx.apply #qlx.action<tdg>(%142#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %144:2 = qlx.apply #qlx.action<cx>(%138#1, %143) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %145 = qlx.apply #qlx.action<t>(%144#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %146:2 = qlx.apply #qlx.action<cx>(%142#0, %145) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %147 = qlx.apply #qlx.action<tdg>(%146#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %148 = qlx.apply #qlx.action<h>(%147) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %149 = qlx.apply #qlx.action<sdg>(%148) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %150:2 = qlx.apply #qlx.action<cx>(%139#0, %149) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %151:2 = qlx.apply #qlx.action<cx>(%144#0, %146#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %152:2 = qlx.apply #qlx.action<cx>(%150#0, %151#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %153:2 = qlx.apply #qlx.action<cx>(%107#1, %122#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %154:2 = qlx.apply #qlx.action<cx>(%153#0, %137#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %155 = qlx.apply #qlx.action<h>(%38) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %156 = qlx.apply #qlx.action<t>(%155) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %157:2 = qlx.apply #qlx.action<cx>(%154#1, %156) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %158 = qlx.apply #qlx.action<tdg>(%157#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %159:2 = qlx.apply #qlx.action<cx>(%153#1, %158) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %160 = qlx.apply #qlx.action<t>(%159#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %161:2 = qlx.apply #qlx.action<cx>(%157#0, %160) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %162 = qlx.apply #qlx.action<tdg>(%161#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %163 = qlx.apply #qlx.action<h>(%162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %164 = qlx.apply #qlx.action<sdg>(%163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %165:2 = qlx.apply #qlx.action<cx>(%154#0, %164) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %166:2 = qlx.apply #qlx.action<cx>(%159#0, %161#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %167:2 = qlx.apply #qlx.action<cx>(%165#0, %166#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %168 = qlx.apply #qlx.action<h>(%39) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %169 = qlx.apply #qlx.action<t>(%168) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %170:2 = qlx.apply #qlx.action<cx>(%167#1, %169) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %171 = qlx.apply #qlx.action<tdg>(%170#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %172:2 = qlx.apply #qlx.action<cx>(%152#1, %171) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %173 = qlx.apply #qlx.action<t>(%172#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %174:2 = qlx.apply #qlx.action<cx>(%170#0, %173) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %175 = qlx.apply #qlx.action<tdg>(%174#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %176 = qlx.apply #qlx.action<h>(%175) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %177 = qlx.apply #qlx.action<sdg>(%176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %178:2 = qlx.apply #qlx.action<cx>(%172#0, %174#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %179:2 = qlx.apply #qlx.action<cx>(%75#1, %90#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %180:2 = qlx.apply #qlx.action<cx>(%179#0, %105#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %181 = qlx.apply #qlx.action<h>(%40) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %182 = qlx.apply #qlx.action<t>(%181) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %183:2 = qlx.apply #qlx.action<cx>(%180#1, %182) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %184 = qlx.apply #qlx.action<tdg>(%183#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %185:2 = qlx.apply #qlx.action<cx>(%179#1, %184) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %186 = qlx.apply #qlx.action<t>(%185#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %187:2 = qlx.apply #qlx.action<cx>(%183#0, %186) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %188 = qlx.apply #qlx.action<tdg>(%187#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %189 = qlx.apply #qlx.action<h>(%188) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %190 = qlx.apply #qlx.action<sdg>(%189) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %191:2 = qlx.apply #qlx.action<cx>(%180#0, %190) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %192:2 = qlx.apply #qlx.action<cx>(%185#0, %187#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %193:2 = qlx.apply #qlx.action<cx>(%191#0, %192#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %194:2 = qlx.apply #qlx.action<cx>(%120#1, %135#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %195:2 = qlx.apply #qlx.action<cx>(%194#0, %150#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %196 = qlx.apply #qlx.action<h>(%41) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<t>(%196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %198:2 = qlx.apply #qlx.action<cx>(%195#1, %197) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %199 = qlx.apply #qlx.action<tdg>(%198#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %200:2 = qlx.apply #qlx.action<cx>(%194#1, %199) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %201 = qlx.apply #qlx.action<t>(%200#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %202:2 = qlx.apply #qlx.action<cx>(%198#0, %201) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %203 = qlx.apply #qlx.action<tdg>(%202#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %204 = qlx.apply #qlx.action<h>(%203) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %205 = qlx.apply #qlx.action<sdg>(%204) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %206:2 = qlx.apply #qlx.action<cx>(%195#0, %205) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %207:2 = qlx.apply #qlx.action<cx>(%200#0, %202#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %208:2 = qlx.apply #qlx.action<cx>(%206#0, %207#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %209:2 = qlx.apply #qlx.action<cx>(%165#1, %177) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %210:2 = qlx.apply #qlx.action<cx>(%209#0, %193#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %211 = qlx.apply #qlx.action<h>(%42) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %212 = qlx.apply #qlx.action<t>(%211) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %213:2 = qlx.apply #qlx.action<cx>(%210#1, %212) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %214 = qlx.apply #qlx.action<tdg>(%213#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %215:2 = qlx.apply #qlx.action<cx>(%209#1, %214) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %216 = qlx.apply #qlx.action<t>(%215#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %217:2 = qlx.apply #qlx.action<cx>(%213#0, %216) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %218 = qlx.apply #qlx.action<tdg>(%217#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %219 = qlx.apply #qlx.action<h>(%218) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<sdg>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %221:2 = qlx.apply #qlx.action<cx>(%210#0, %220) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %222:2 = qlx.apply #qlx.action<cx>(%215#0, %217#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %223:2 = qlx.apply #qlx.action<cx>(%221#0, %222#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %224 = qlx.apply #qlx.action<h>(%43) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %225 = qlx.apply #qlx.action<t>(%224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %226:2 = qlx.apply #qlx.action<cx>(%223#1, %225) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %227 = qlx.apply #qlx.action<tdg>(%226#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %228:2 = qlx.apply #qlx.action<cx>(%208#1, %227) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %229 = qlx.apply #qlx.action<t>(%228#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %230:2 = qlx.apply #qlx.action<cx>(%226#0, %229) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %231 = qlx.apply #qlx.action<tdg>(%230#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %232 = qlx.apply #qlx.action<h>(%231) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<sdg>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %234:2 = qlx.apply #qlx.action<cx>(%228#0, %230#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %235:2 = qlx.apply #qlx.action<cx>(%191#1, %206#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %236:2 = qlx.apply #qlx.action<cx>(%235#0, %221#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %237 = qlx.apply #qlx.action<h>(%44) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<t>(%237) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %239:2 = qlx.apply #qlx.action<cx>(%236#1, %238) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %240 = qlx.apply #qlx.action<tdg>(%239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %241:2 = qlx.apply #qlx.action<cx>(%235#1, %240) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %242 = qlx.apply #qlx.action<t>(%241#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %243:2 = qlx.apply #qlx.action<cx>(%239#0, %242) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %244 = qlx.apply #qlx.action<tdg>(%243#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %245 = qlx.apply #qlx.action<h>(%244) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %246 = qlx.apply #qlx.action<sdg>(%245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %247:2 = qlx.apply #qlx.action<cx>(%236#0, %246) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %248:2 = qlx.apply #qlx.action<cx>(%241#0, %243#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %249:2 = qlx.apply #qlx.action<cx>(%247#0, %248#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %250 = qlx.apply #qlx.action<h>(%45) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %251 = qlx.apply #qlx.action<t>(%250) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %252:2 = qlx.apply #qlx.action<cx>(%249#1, %251) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %253 = qlx.apply #qlx.action<tdg>(%252#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %254:2 = qlx.apply #qlx.action<cx>(%233, %253) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %255 = qlx.apply #qlx.action<t>(%254#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %256:2 = qlx.apply #qlx.action<cx>(%252#0, %255) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<tdg>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %258 = qlx.apply #qlx.action<h>(%257) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<sdg>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260:2 = qlx.apply #qlx.action<cx>(%254#0, %256#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %261 = qlx.apply #qlx.action<h>(%46) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %262 = qlx.apply #qlx.action<t>(%261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %263:2 = qlx.apply #qlx.action<cx>(%259, %262) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %264 = qlx.apply #qlx.action<tdg>(%263#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %265:2 = qlx.apply #qlx.action<cx>(%247#1, %264) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %266 = qlx.apply #qlx.action<t>(%265#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %267:2 = qlx.apply #qlx.action<cx>(%263#0, %266) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %268 = qlx.apply #qlx.action<tdg>(%267#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %269 = qlx.apply #qlx.action<h>(%268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %270 = qlx.apply #qlx.action<sdg>(%269) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %271:2 = qlx.apply #qlx.action<cx>(%265#0, %267#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst = arith.constant 0.055555555555555552 : f64
    %272 = qlx.apply #qlx.action<pauli_rotation>(%178#1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_0 = arith.constant 0.1111111111111111 : f64
    %273 = qlx.apply #qlx.action<pauli_rotation>(%234#1, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 0.22222222222222221 : f64
    %274 = qlx.apply #qlx.action<pauli_rotation>(%260#1, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 0.44444444444444442 : f64
    %275 = qlx.apply #qlx.action<pauli_rotation>(%271#1, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_3 = arith.constant 0.88888888888888883 : f64
    %276 = qlx.apply #qlx.action<pauli_rotation>(%270, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %277:2 = qlx.apply #qlx.action<cx>(%271#0, %275) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %278 = qlx.measure <X> %276 : !qlx.logical_qubit -> i1
    %279:2 = cflow.if %278 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%277#0, %277#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %277#0, %277#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %280:2 = qlx.apply #qlx.action<cx>(%260#0, %274) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %281 = qlx.measure <X> %279#1 : !qlx.logical_qubit -> i1
    %282:2 = cflow.if %281 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%280#0, %280#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %280#0, %280#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %283:2 = qlx.apply #qlx.action<cx>(%249#0, %282#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %284:2 = qlx.apply #qlx.action<cx>(%248#0, %283#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %285:2 = qlx.apply #qlx.action<cx>(%283#0, %279#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %286 = qlx.measure <X> %285#1 : !qlx.logical_qubit -> i1
    %287:2 = cflow.if %286 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%284#0, %284#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %284#0, %284#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %288:2 = qlx.apply #qlx.action<cx>(%285#0, %287#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %289:2 = qlx.apply #qlx.action<cx>(%288#0, %287#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %290:2 = qlx.apply #qlx.action<cx>(%234#0, %273) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %291 = qlx.measure <X> %282#0 : !qlx.logical_qubit -> i1
    %292:2 = cflow.if %291 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%290#0, %290#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %290#0, %290#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %293:2 = qlx.apply #qlx.action<cx>(%223#0, %292#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %294:2 = qlx.apply #qlx.action<cx>(%222#0, %293#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %295:2 = qlx.apply #qlx.action<cx>(%293#0, %288#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %296 = qlx.measure <X> %295#1 : !qlx.logical_qubit -> i1
    %297:2 = cflow.if %296 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%294#0, %294#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %294#0, %294#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %298:2 = qlx.apply #qlx.action<cx>(%295#0, %297#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %299:2 = qlx.apply #qlx.action<cx>(%298#0, %297#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %300:2 = qlx.apply #qlx.action<cx>(%208#0, %292#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %301:2 = qlx.apply #qlx.action<cx>(%207#0, %300#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %302:2 = qlx.apply #qlx.action<cx>(%300#0, %289#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %303 = qlx.measure <X> %302#1 : !qlx.logical_qubit -> i1
    %304:2 = cflow.if %303 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%301#0, %301#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %301#0, %301#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %305:2 = qlx.apply #qlx.action<cx>(%302#0, %304#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %306:2 = qlx.apply #qlx.action<cx>(%305#0, %304#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %307:2 = qlx.apply #qlx.action<cx>(%193#0, %298#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %308:2 = qlx.apply #qlx.action<cx>(%192#0, %307#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %309:2 = qlx.apply #qlx.action<cx>(%307#0, %289#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %310 = qlx.measure <X> %309#1 : !qlx.logical_qubit -> i1
    %311:2 = cflow.if %310 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%308#0, %308#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %308#0, %308#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %312:2 = qlx.apply #qlx.action<cx>(%309#0, %311#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %313:2 = qlx.apply #qlx.action<cx>(%312#0, %311#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %314:2 = qlx.apply #qlx.action<cx>(%178#0, %272) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %315 = qlx.measure <X> %299#1 : !qlx.logical_qubit -> i1
    %316:2 = cflow.if %315 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%314#0, %314#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %314#0, %314#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %317:2 = qlx.apply #qlx.action<cx>(%167#0, %316#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %318:2 = qlx.apply #qlx.action<cx>(%166#0, %317#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %319:2 = qlx.apply #qlx.action<cx>(%317#0, %299#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %320 = qlx.measure <X> %319#1 : !qlx.logical_qubit -> i1
    %321:2 = cflow.if %320 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%318#0, %318#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %318#0, %318#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %322:2 = qlx.apply #qlx.action<cx>(%319#0, %321#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %323:2 = qlx.apply #qlx.action<cx>(%322#0, %321#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %324:2 = qlx.apply #qlx.action<cx>(%152#0, %316#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %325:2 = qlx.apply #qlx.action<cx>(%151#0, %324#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %326:2 = qlx.apply #qlx.action<cx>(%324#0, %305#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %327 = qlx.measure <X> %326#1 : !qlx.logical_qubit -> i1
    %328:2 = cflow.if %327 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%325#0, %325#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %325#0, %325#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %329:2 = qlx.apply #qlx.action<cx>(%326#0, %328#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %330:2 = qlx.apply #qlx.action<cx>(%329#0, %328#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %331:2 = qlx.apply #qlx.action<cx>(%137#0, %322#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %332:2 = qlx.apply #qlx.action<cx>(%136#0, %331#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %333:2 = qlx.apply #qlx.action<cx>(%331#0, %306#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %334 = qlx.measure <X> %333#1 : !qlx.logical_qubit -> i1
    %335:2 = cflow.if %334 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%332#0, %332#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %332#0, %332#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %336:2 = qlx.apply #qlx.action<cx>(%333#0, %335#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %337:2 = qlx.apply #qlx.action<cx>(%336#0, %335#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %338:2 = qlx.apply #qlx.action<cx>(%122#0, %323#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %339:2 = qlx.apply #qlx.action<cx>(%121#0, %338#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %340:2 = qlx.apply #qlx.action<cx>(%338#0, %306#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %341 = qlx.measure <X> %340#1 : !qlx.logical_qubit -> i1
    %342:2 = cflow.if %341 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%339#0, %339#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %339#0, %339#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %343:2 = qlx.apply #qlx.action<cx>(%340#0, %342#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %344:2 = qlx.apply #qlx.action<cx>(%343#0, %342#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %345:2 = qlx.apply #qlx.action<cx>(%107#0, %323#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %346:2 = qlx.apply #qlx.action<cx>(%106#0, %345#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %347:2 = qlx.apply #qlx.action<cx>(%345#0, %312#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %348 = qlx.measure <X> %347#1 : !qlx.logical_qubit -> i1
    %349:2 = cflow.if %348 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%346#0, %346#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %346#0, %346#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %350:2 = qlx.apply #qlx.action<cx>(%347#0, %349#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %351:2 = qlx.apply #qlx.action<cx>(%350#0, %349#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %352:2 = qlx.apply #qlx.action<cx>(%92#0, %329#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %353:2 = qlx.apply #qlx.action<cx>(%91#0, %352#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %354:2 = qlx.apply #qlx.action<cx>(%352#0, %313#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %355 = qlx.measure <X> %354#1 : !qlx.logical_qubit -> i1
    %356:2 = cflow.if %355 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%353#0, %353#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %353#0, %353#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %357:2 = qlx.apply #qlx.action<cx>(%354#0, %356#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %358:2 = qlx.apply #qlx.action<cx>(%357#0, %356#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %359:2 = qlx.apply #qlx.action<cx>(%77#0, %330#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %360:2 = qlx.apply #qlx.action<cx>(%76#0, %359#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %361:2 = qlx.apply #qlx.action<cx>(%359#0, %313#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %362 = qlx.measure <X> %361#1 : !qlx.logical_qubit -> i1
    %363:2 = cflow.if %362 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %414:2 = qlx.apply #qlx.action<cz>(%360#0, %360#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %414#0, %414#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %360#0, %360#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %364:2 = qlx.apply #qlx.action<cx>(%361#0, %363#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %365:2 = qlx.apply #qlx.action<cx>(%364#0, %363#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %366:2 = qlx.apply #qlx.action<cx>(%47#0, %365#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %367:2 = qlx.apply #qlx.action<cx>(%48#0, %365#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %368:2 = qlx.apply #qlx.action<cx>(%49#0, %364#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %369:2 = qlx.apply #qlx.action<cx>(%50#0, %358#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %370:2 = qlx.apply #qlx.action<cx>(%51#0, %358#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %371:2 = qlx.apply #qlx.action<cx>(%52#0, %357#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %372:2 = qlx.apply #qlx.action<cx>(%53#0, %351#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %373:2 = qlx.apply #qlx.action<cx>(%54#0, %351#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %374:2 = qlx.apply #qlx.action<cx>(%55#0, %350#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %375:2 = qlx.apply #qlx.action<cx>(%56#0, %344#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %376:2 = qlx.apply #qlx.action<cx>(%57#0, %344#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %377:2 = qlx.apply #qlx.action<cx>(%58#0, %343#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %378:2 = qlx.apply #qlx.action<cx>(%59#0, %337#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %379:2 = qlx.apply #qlx.action<cx>(%60#0, %337#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %380:2 = qlx.apply #qlx.action<cx>(%61#0, %336#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %381:2 = qlx.apply #qlx.action<cx>(%62#0, %330#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %382 = qlx.measure <Z> %366#0 : !qlx.logical_qubit -> i1
    %383 = qlx.measure <Z> %366#1 : !qlx.logical_qubit -> i1
    %384 = qlx.measure <Z> %367#0 : !qlx.logical_qubit -> i1
    %385 = qlx.measure <Z> %367#1 : !qlx.logical_qubit -> i1
    %386 = qlx.measure <Z> %368#0 : !qlx.logical_qubit -> i1
    %387 = qlx.measure <Z> %368#1 : !qlx.logical_qubit -> i1
    %388 = qlx.measure <Z> %369#0 : !qlx.logical_qubit -> i1
    %389 = qlx.measure <Z> %369#1 : !qlx.logical_qubit -> i1
    %390 = qlx.measure <Z> %370#0 : !qlx.logical_qubit -> i1
    %391 = qlx.measure <Z> %370#1 : !qlx.logical_qubit -> i1
    %392 = qlx.measure <Z> %371#0 : !qlx.logical_qubit -> i1
    %393 = qlx.measure <Z> %371#1 : !qlx.logical_qubit -> i1
    %394 = qlx.measure <Z> %372#0 : !qlx.logical_qubit -> i1
    %395 = qlx.measure <Z> %372#1 : !qlx.logical_qubit -> i1
    %396 = qlx.measure <Z> %373#0 : !qlx.logical_qubit -> i1
    %397 = qlx.measure <Z> %373#1 : !qlx.logical_qubit -> i1
    %398 = qlx.measure <Z> %374#0 : !qlx.logical_qubit -> i1
    %399 = qlx.measure <Z> %374#1 : !qlx.logical_qubit -> i1
    %400 = qlx.measure <Z> %375#0 : !qlx.logical_qubit -> i1
    %401 = qlx.measure <Z> %375#1 : !qlx.logical_qubit -> i1
    %402 = qlx.measure <Z> %376#0 : !qlx.logical_qubit -> i1
    %403 = qlx.measure <Z> %376#1 : !qlx.logical_qubit -> i1
    %404 = qlx.measure <Z> %377#0 : !qlx.logical_qubit -> i1
    %405 = qlx.measure <Z> %377#1 : !qlx.logical_qubit -> i1
    %406 = qlx.measure <Z> %378#0 : !qlx.logical_qubit -> i1
    %407 = qlx.measure <Z> %378#1 : !qlx.logical_qubit -> i1
    %408 = qlx.measure <Z> %379#0 : !qlx.logical_qubit -> i1
    %409 = qlx.measure <Z> %379#1 : !qlx.logical_qubit -> i1
    %410 = qlx.measure <Z> %380#0 : !qlx.logical_qubit -> i1
    %411 = qlx.measure <Z> %380#1 : !qlx.logical_qubit -> i1
    %412 = qlx.measure <Z> %381#0 : !qlx.logical_qubit -> i1
    %413 = qlx.measure <Z> %381#1 : !qlx.logical_qubit -> i1
  }
}
