module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @stage : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 8 : i64} : !qlx.logical_qubit
    %9 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 9 : i64} : !qlx.logical_qubit
    %10 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 10 : i64} : !qlx.logical_qubit
    %11 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 11 : i64} : !qlx.logical_qubit
    %12 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 12 : i64} : !qlx.logical_qubit
    %13 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 13 : i64} : !qlx.logical_qubit
    %14 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 14 : i64} : !qlx.logical_qubit
    %15 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 15 : i64} : !qlx.logical_qubit
    %16 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 16 : i64} : !qlx.logical_qubit
    %17 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 17 : i64} : !qlx.logical_qubit
    %18 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 18 : i64} : !qlx.logical_qubit
    %19 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 19 : i64} : !qlx.logical_qubit
    %20 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 20 : i64} : !qlx.logical_qubit
    %21 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 21 : i64} : !qlx.logical_qubit
    %22 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 22 : i64} : !qlx.logical_qubit
    %23 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 23 : i64} : !qlx.logical_qubit
    %24 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 24 : i64} : !qlx.logical_qubit
    %25 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 25 : i64} : !qlx.logical_qubit
    %26 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 26 : i64} : !qlx.logical_qubit
    %27 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 27 : i64} : !qlx.logical_qubit
    %28 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 28 : i64} : !qlx.logical_qubit
    %29 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 29 : i64} : !qlx.logical_qubit
    %30 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 30 : i64} : !qlx.logical_qubit
    %31 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 31 : i64} : !qlx.logical_qubit
    %32 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 32 : i64} : !qlx.logical_qubit
    %33 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 33 : i64} : !qlx.logical_qubit
    %34 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 34 : i64} : !qlx.logical_qubit
    %35 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 35 : i64} : !qlx.logical_qubit
    %36 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 36 : i64} : !qlx.logical_qubit
    %37 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 37 : i64} : !qlx.logical_qubit
    %38 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 38 : i64} : !qlx.logical_qubit
    %39:2 = qlx.apply #qlx.action<cx>(%0, %1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %40:2 = qlx.apply #qlx.action<cx>(%2, %3) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %41:2 = qlx.apply #qlx.action<cx>(%4, %5) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %42:2 = qlx.apply #qlx.action<cx>(%6, %7) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %43:2 = qlx.apply #qlx.action<cx>(%8, %9) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44:2 = qlx.apply #qlx.action<cx>(%10, %11) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %45:2 = qlx.apply #qlx.action<cx>(%12, %13) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %46:2 = qlx.apply #qlx.action<cx>(%14, %15) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %47:2 = qlx.apply #qlx.action<cx>(%16, %17) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %48:2 = qlx.apply #qlx.action<cx>(%18, %19) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %49:2 = qlx.apply #qlx.action<cx>(%20, %21) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %50:2 = qlx.apply #qlx.action<cx>(%22, %23) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %51:2 = qlx.apply #qlx.action<cx>(%24, %25) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %52:2 = qlx.apply #qlx.action<cx>(%26, %27) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %53:2 = qlx.apply #qlx.action<cx>(%28, %29) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %54:2 = qlx.apply #qlx.action<cx>(%30, %31) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %55:2 = qlx.apply #qlx.action<cx>(%39#1, %40#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %56:2 = qlx.apply #qlx.action<cx>(%55#0, %41#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %57 = qlx.apply #qlx.action<h>(%32) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %58 = qlx.apply #qlx.action<t>(%57) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %59:2 = qlx.apply #qlx.action<cx>(%56#1, %58) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %60 = qlx.apply #qlx.action<tdg>(%59#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %61:2 = qlx.apply #qlx.action<cx>(%55#1, %60) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %62 = qlx.apply #qlx.action<t>(%61#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %63:2 = qlx.apply #qlx.action<cx>(%59#0, %62) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<tdg>(%63#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %65 = qlx.apply #qlx.action<h>(%64) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<sdg>(%65) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %67:2 = qlx.apply #qlx.action<cx>(%56#0, %66) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %68:2 = qlx.apply #qlx.action<cx>(%61#0, %63#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %69:2 = qlx.apply #qlx.action<cx>(%67#0, %68#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %70:2 = qlx.apply #qlx.action<cx>(%42#1, %43#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %71:2 = qlx.apply #qlx.action<cx>(%70#0, %44#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %72 = qlx.apply #qlx.action<h>(%33) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<t>(%72) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %74:2 = qlx.apply #qlx.action<cx>(%71#1, %73) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %75 = qlx.apply #qlx.action<tdg>(%74#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %76:2 = qlx.apply #qlx.action<cx>(%70#1, %75) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %77 = qlx.apply #qlx.action<t>(%76#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %78:2 = qlx.apply #qlx.action<cx>(%74#0, %77) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %79 = qlx.apply #qlx.action<tdg>(%78#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %80 = qlx.apply #qlx.action<h>(%79) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %81 = qlx.apply #qlx.action<sdg>(%80) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %82:2 = qlx.apply #qlx.action<cx>(%71#0, %81) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %83:2 = qlx.apply #qlx.action<cx>(%76#0, %78#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %84:2 = qlx.apply #qlx.action<cx>(%82#0, %83#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %85:2 = qlx.apply #qlx.action<cx>(%45#1, %46#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %86:2 = qlx.apply #qlx.action<cx>(%85#0, %69#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %87 = qlx.apply #qlx.action<h>(%34) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %88 = qlx.apply #qlx.action<t>(%87) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %89:2 = qlx.apply #qlx.action<cx>(%86#1, %88) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %90 = qlx.apply #qlx.action<tdg>(%89#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %91:2 = qlx.apply #qlx.action<cx>(%85#1, %90) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %92 = qlx.apply #qlx.action<t>(%91#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %93:2 = qlx.apply #qlx.action<cx>(%89#0, %92) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %94 = qlx.apply #qlx.action<tdg>(%93#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %95 = qlx.apply #qlx.action<h>(%94) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %96 = qlx.apply #qlx.action<sdg>(%95) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %97:2 = qlx.apply #qlx.action<cx>(%86#0, %96) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %98:2 = qlx.apply #qlx.action<cx>(%91#0, %93#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %99:2 = qlx.apply #qlx.action<cx>(%97#0, %98#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %100 = qlx.apply #qlx.action<h>(%35) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %101 = qlx.apply #qlx.action<t>(%100) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %102:2 = qlx.apply #qlx.action<cx>(%99#1, %101) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %103 = qlx.apply #qlx.action<tdg>(%102#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %104:2 = qlx.apply #qlx.action<cx>(%84#1, %103) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %105 = qlx.apply #qlx.action<t>(%104#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %106:2 = qlx.apply #qlx.action<cx>(%102#0, %105) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %107 = qlx.apply #qlx.action<tdg>(%106#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %108 = qlx.apply #qlx.action<h>(%107) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %109 = qlx.apply #qlx.action<sdg>(%108) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %110:2 = qlx.apply #qlx.action<cx>(%104#0, %106#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %111:2 = qlx.apply #qlx.action<cx>(%67#1, %82#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %112:2 = qlx.apply #qlx.action<cx>(%111#0, %97#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %113 = qlx.apply #qlx.action<h>(%36) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %114 = qlx.apply #qlx.action<t>(%113) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %115:2 = qlx.apply #qlx.action<cx>(%112#1, %114) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %116 = qlx.apply #qlx.action<tdg>(%115#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %117:2 = qlx.apply #qlx.action<cx>(%111#1, %116) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %118 = qlx.apply #qlx.action<t>(%117#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %119:2 = qlx.apply #qlx.action<cx>(%115#0, %118) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %120 = qlx.apply #qlx.action<tdg>(%119#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %121 = qlx.apply #qlx.action<h>(%120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %122 = qlx.apply #qlx.action<sdg>(%121) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %123:2 = qlx.apply #qlx.action<cx>(%112#0, %122) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %124:2 = qlx.apply #qlx.action<cx>(%117#0, %119#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %125:2 = qlx.apply #qlx.action<cx>(%123#0, %124#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %126 = qlx.apply #qlx.action<h>(%37) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %127 = qlx.apply #qlx.action<t>(%126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %128:2 = qlx.apply #qlx.action<cx>(%125#1, %127) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %129 = qlx.apply #qlx.action<tdg>(%128#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %130:2 = qlx.apply #qlx.action<cx>(%109, %129) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %131 = qlx.apply #qlx.action<t>(%130#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %132:2 = qlx.apply #qlx.action<cx>(%128#0, %131) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %133 = qlx.apply #qlx.action<tdg>(%132#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %134 = qlx.apply #qlx.action<h>(%133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<sdg>(%134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %136:2 = qlx.apply #qlx.action<cx>(%130#0, %132#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %137 = qlx.apply #qlx.action<h>(%38) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %138 = qlx.apply #qlx.action<t>(%137) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %139:2 = qlx.apply #qlx.action<cx>(%135, %138) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %140 = qlx.apply #qlx.action<tdg>(%139#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %141:2 = qlx.apply #qlx.action<cx>(%123#1, %140) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %142 = qlx.apply #qlx.action<t>(%141#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %143:2 = qlx.apply #qlx.action<cx>(%139#0, %142) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %144 = qlx.apply #qlx.action<tdg>(%143#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %146 = qlx.apply #qlx.action<sdg>(%145) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %147:2 = qlx.apply #qlx.action<cx>(%141#0, %143#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst = arith.constant 0.055555555555555552 : f64
    %148 = qlx.apply #qlx.action<pauli_rotation>(%110#1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_0 = arith.constant 0.1111111111111111 : f64
    %149 = qlx.apply #qlx.action<pauli_rotation>(%136#1, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 0.22222222222222221 : f64
    %150 = qlx.apply #qlx.action<pauli_rotation>(%147#1, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 0.44444444444444442 : f64
    %151 = qlx.apply #qlx.action<pauli_rotation>(%146, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %152:2 = qlx.apply #qlx.action<cx>(%147#0, %150) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %153 = qlx.measure <X> %151 : !qlx.logical_qubit -> i1
    %154:2 = cflow.if %153 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%152#0, %152#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %152#0, %152#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %155:2 = qlx.apply #qlx.action<cx>(%136#0, %149) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %156 = qlx.measure <X> %154#1 : !qlx.logical_qubit -> i1
    %157:2 = cflow.if %156 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%155#0, %155#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %155#0, %155#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %158:2 = qlx.apply #qlx.action<cx>(%125#0, %157#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %159:2 = qlx.apply #qlx.action<cx>(%124#0, %158#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %160:2 = qlx.apply #qlx.action<cx>(%158#0, %154#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %161 = qlx.measure <X> %160#1 : !qlx.logical_qubit -> i1
    %162:2 = cflow.if %161 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%159#0, %159#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %159#0, %159#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %163:2 = qlx.apply #qlx.action<cx>(%160#0, %162#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %164:2 = qlx.apply #qlx.action<cx>(%163#0, %162#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %165:2 = qlx.apply #qlx.action<cx>(%110#0, %148) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %166 = qlx.measure <X> %157#0 : !qlx.logical_qubit -> i1
    %167:2 = cflow.if %166 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%165#0, %165#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %165#0, %165#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %168:2 = qlx.apply #qlx.action<cx>(%99#0, %167#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %169:2 = qlx.apply #qlx.action<cx>(%98#0, %168#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %170:2 = qlx.apply #qlx.action<cx>(%168#0, %163#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %171 = qlx.measure <X> %170#1 : !qlx.logical_qubit -> i1
    %172:2 = cflow.if %171 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%169#0, %169#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %169#0, %169#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %173:2 = qlx.apply #qlx.action<cx>(%170#0, %172#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %174:2 = qlx.apply #qlx.action<cx>(%173#0, %172#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %175:2 = qlx.apply #qlx.action<cx>(%84#0, %167#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %176:2 = qlx.apply #qlx.action<cx>(%83#0, %175#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %177:2 = qlx.apply #qlx.action<cx>(%175#0, %164#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %178 = qlx.measure <X> %177#1 : !qlx.logical_qubit -> i1
    %179:2 = cflow.if %178 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%176#0, %176#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %176#0, %176#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %180:2 = qlx.apply #qlx.action<cx>(%177#0, %179#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %181:2 = qlx.apply #qlx.action<cx>(%180#0, %179#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %182:2 = qlx.apply #qlx.action<cx>(%69#0, %173#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %183:2 = qlx.apply #qlx.action<cx>(%68#0, %182#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %184:2 = qlx.apply #qlx.action<cx>(%182#0, %164#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %185 = qlx.measure <X> %184#1 : !qlx.logical_qubit -> i1
    %186:2 = cflow.if %185 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%183#0, %183#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %183#0, %183#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %187:2 = qlx.apply #qlx.action<cx>(%184#0, %186#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %188:2 = qlx.apply #qlx.action<cx>(%187#0, %186#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %189:2 = qlx.apply #qlx.action<cx>(%47#1, %48#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %190:2 = qlx.apply #qlx.action<cx>(%189#0, %49#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %191 = qlx.prepare "zero" {allocation = 1 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %192 = qlx.apply #qlx.action<h>(%191) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %193 = qlx.apply #qlx.action<t>(%192) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %194:2 = qlx.apply #qlx.action<cx>(%190#1, %193) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %195 = qlx.apply #qlx.action<tdg>(%194#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %196:2 = qlx.apply #qlx.action<cx>(%189#1, %195) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %197 = qlx.apply #qlx.action<t>(%196#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %198:2 = qlx.apply #qlx.action<cx>(%194#0, %197) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %199 = qlx.apply #qlx.action<tdg>(%198#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %200 = qlx.apply #qlx.action<h>(%199) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %201 = qlx.apply #qlx.action<sdg>(%200) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %202:2 = qlx.apply #qlx.action<cx>(%190#0, %201) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %203:2 = qlx.apply #qlx.action<cx>(%196#0, %198#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %204:2 = qlx.apply #qlx.action<cx>(%202#0, %203#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %205:2 = qlx.apply #qlx.action<cx>(%50#1, %51#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %206:2 = qlx.apply #qlx.action<cx>(%205#0, %52#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %207 = qlx.prepare "zero" {allocation = 2 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %208 = qlx.apply #qlx.action<h>(%207) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %209 = qlx.apply #qlx.action<t>(%208) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %210:2 = qlx.apply #qlx.action<cx>(%206#1, %209) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %211 = qlx.apply #qlx.action<tdg>(%210#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %212:2 = qlx.apply #qlx.action<cx>(%205#1, %211) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %213 = qlx.apply #qlx.action<t>(%212#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %214:2 = qlx.apply #qlx.action<cx>(%210#0, %213) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %215 = qlx.apply #qlx.action<tdg>(%214#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %216 = qlx.apply #qlx.action<h>(%215) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %217 = qlx.apply #qlx.action<sdg>(%216) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %218:2 = qlx.apply #qlx.action<cx>(%206#0, %217) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %219:2 = qlx.apply #qlx.action<cx>(%212#0, %214#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %220:2 = qlx.apply #qlx.action<cx>(%218#0, %219#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %221:2 = qlx.apply #qlx.action<cx>(%53#1, %54#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %222:2 = qlx.apply #qlx.action<cx>(%221#0, %204#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %223 = qlx.prepare "zero" {allocation = 3 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %224 = qlx.apply #qlx.action<h>(%223) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %225 = qlx.apply #qlx.action<t>(%224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %226:2 = qlx.apply #qlx.action<cx>(%222#1, %225) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %227 = qlx.apply #qlx.action<tdg>(%226#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %228:2 = qlx.apply #qlx.action<cx>(%221#1, %227) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %229 = qlx.apply #qlx.action<t>(%228#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %230:2 = qlx.apply #qlx.action<cx>(%226#0, %229) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %231 = qlx.apply #qlx.action<tdg>(%230#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %232 = qlx.apply #qlx.action<h>(%231) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<sdg>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %234:2 = qlx.apply #qlx.action<cx>(%222#0, %233) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %235:2 = qlx.apply #qlx.action<cx>(%228#0, %230#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %236:2 = qlx.apply #qlx.action<cx>(%234#0, %235#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %237 = qlx.prepare "zero" {allocation = 4 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<h>(%237) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %239 = qlx.apply #qlx.action<t>(%238) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %240:2 = qlx.apply #qlx.action<cx>(%236#1, %239) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %241 = qlx.apply #qlx.action<tdg>(%240#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %242:2 = qlx.apply #qlx.action<cx>(%220#1, %241) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %243 = qlx.apply #qlx.action<t>(%242#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %244:2 = qlx.apply #qlx.action<cx>(%240#0, %243) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %245 = qlx.apply #qlx.action<tdg>(%244#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %246 = qlx.apply #qlx.action<h>(%245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %247 = qlx.apply #qlx.action<sdg>(%246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %248:2 = qlx.apply #qlx.action<cx>(%242#0, %244#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %249:2 = qlx.apply #qlx.action<cx>(%202#1, %218#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %250:2 = qlx.apply #qlx.action<cx>(%249#0, %234#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %251 = qlx.prepare "zero" {allocation = 5 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %252 = qlx.apply #qlx.action<h>(%251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %253 = qlx.apply #qlx.action<t>(%252) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %254:2 = qlx.apply #qlx.action<cx>(%250#1, %253) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %255 = qlx.apply #qlx.action<tdg>(%254#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %256:2 = qlx.apply #qlx.action<cx>(%249#1, %255) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<t>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %258:2 = qlx.apply #qlx.action<cx>(%254#0, %257) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %259 = qlx.apply #qlx.action<tdg>(%258#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%259) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %261 = qlx.apply #qlx.action<sdg>(%260) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %262:2 = qlx.apply #qlx.action<cx>(%250#0, %261) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %263:2 = qlx.apply #qlx.action<cx>(%256#0, %258#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %264:2 = qlx.apply #qlx.action<cx>(%262#0, %263#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %265 = qlx.prepare "zero" {allocation = 6 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %266 = qlx.apply #qlx.action<h>(%265) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %267 = qlx.apply #qlx.action<t>(%266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %268:2 = qlx.apply #qlx.action<cx>(%264#1, %267) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %269 = qlx.apply #qlx.action<tdg>(%268#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %270:2 = qlx.apply #qlx.action<cx>(%247, %269) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %271 = qlx.apply #qlx.action<t>(%270#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %272:2 = qlx.apply #qlx.action<cx>(%268#0, %271) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %273 = qlx.apply #qlx.action<tdg>(%272#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %274 = qlx.apply #qlx.action<h>(%273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %275 = qlx.apply #qlx.action<sdg>(%274) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %276:2 = qlx.apply #qlx.action<cx>(%270#0, %272#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %277 = qlx.prepare "zero" {allocation = 7 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %278 = qlx.apply #qlx.action<h>(%277) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %279 = qlx.apply #qlx.action<t>(%278) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %280:2 = qlx.apply #qlx.action<cx>(%275, %279) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %281 = qlx.apply #qlx.action<tdg>(%280#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %282:2 = qlx.apply #qlx.action<cx>(%262#1, %281) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %283 = qlx.apply #qlx.action<t>(%282#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %284:2 = qlx.apply #qlx.action<cx>(%280#0, %283) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %285 = qlx.apply #qlx.action<tdg>(%284#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %286 = qlx.apply #qlx.action<h>(%285) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %287 = qlx.apply #qlx.action<sdg>(%286) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %288:2 = qlx.apply #qlx.action<cx>(%282#0, %284#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_3 = arith.constant 0.055555555555555552 : f64
    %289 = qlx.apply #qlx.action<pauli_rotation>(%248#1, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_4 = arith.constant 0.1111111111111111 : f64
    %290 = qlx.apply #qlx.action<pauli_rotation>(%276#1, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.22222222222222221 : f64
    %291 = qlx.apply #qlx.action<pauli_rotation>(%288#1, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_6 = arith.constant 0.44444444444444442 : f64
    %292 = qlx.apply #qlx.action<pauli_rotation>(%287, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %293:2 = qlx.apply #qlx.action<cx>(%288#0, %291) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %294 = qlx.measure <X> %292 : !qlx.logical_qubit -> i1
    %295:2 = cflow.if %294 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%293#0, %293#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %293#0, %293#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %296:2 = qlx.apply #qlx.action<cx>(%276#0, %290) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %297 = qlx.measure <X> %295#1 : !qlx.logical_qubit -> i1
    %298:2 = cflow.if %297 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%296#0, %296#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %296#0, %296#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %299:2 = qlx.apply #qlx.action<cx>(%264#0, %298#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %300:2 = qlx.apply #qlx.action<cx>(%263#0, %299#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %301:2 = qlx.apply #qlx.action<cx>(%299#0, %295#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %302 = qlx.measure <X> %301#1 : !qlx.logical_qubit -> i1
    %303:2 = cflow.if %302 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%300#0, %300#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %300#0, %300#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %304:2 = qlx.apply #qlx.action<cx>(%301#0, %303#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %305:2 = qlx.apply #qlx.action<cx>(%304#0, %303#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %306:2 = qlx.apply #qlx.action<cx>(%248#0, %289) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %307 = qlx.measure <X> %298#0 : !qlx.logical_qubit -> i1
    %308:2 = cflow.if %307 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%306#0, %306#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %306#0, %306#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %309:2 = qlx.apply #qlx.action<cx>(%236#0, %308#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %310:2 = qlx.apply #qlx.action<cx>(%235#0, %309#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %311:2 = qlx.apply #qlx.action<cx>(%309#0, %304#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %312 = qlx.measure <X> %311#1 : !qlx.logical_qubit -> i1
    %313:2 = cflow.if %312 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%310#0, %310#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %310#0, %310#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %314:2 = qlx.apply #qlx.action<cx>(%311#0, %313#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %315:2 = qlx.apply #qlx.action<cx>(%314#0, %313#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %316:2 = qlx.apply #qlx.action<cx>(%220#0, %308#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %317:2 = qlx.apply #qlx.action<cx>(%219#0, %316#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %318:2 = qlx.apply #qlx.action<cx>(%316#0, %305#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %319 = qlx.measure <X> %318#1 : !qlx.logical_qubit -> i1
    %320:2 = cflow.if %319 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%317#0, %317#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %317#0, %317#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %321:2 = qlx.apply #qlx.action<cx>(%318#0, %320#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %322:2 = qlx.apply #qlx.action<cx>(%321#0, %320#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %323:2 = qlx.apply #qlx.action<cx>(%204#0, %314#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %324:2 = qlx.apply #qlx.action<cx>(%203#0, %323#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %325:2 = qlx.apply #qlx.action<cx>(%323#0, %305#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %326 = qlx.measure <X> %325#1 : !qlx.logical_qubit -> i1
    %327:2 = cflow.if %326 -> !qlx.logical_qubit, !qlx.logical_qubit {
      %378:2 = qlx.apply #qlx.action<cz>(%324#0, %324#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      cflow.yield %378#0, %378#1 : !qlx.logical_qubit, !qlx.logical_qubit
    } else {
      cflow.yield %324#0, %324#1 : !qlx.logical_qubit, !qlx.logical_qubit
    }
    %328:2 = qlx.apply #qlx.action<cx>(%325#0, %327#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %329:2 = qlx.apply #qlx.action<cx>(%328#0, %327#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %330:2 = qlx.apply #qlx.action<cx>(%39#0, %188#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %331:2 = qlx.apply #qlx.action<cx>(%40#0, %188#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %332:2 = qlx.apply #qlx.action<cx>(%41#0, %187#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %333:2 = qlx.apply #qlx.action<cx>(%42#0, %181#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %334:2 = qlx.apply #qlx.action<cx>(%43#0, %181#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %335:2 = qlx.apply #qlx.action<cx>(%44#0, %180#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %336:2 = qlx.apply #qlx.action<cx>(%45#0, %174#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %337:2 = qlx.apply #qlx.action<cx>(%46#0, %174#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %338:2 = qlx.apply #qlx.action<cx>(%47#0, %329#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %339:2 = qlx.apply #qlx.action<cx>(%48#0, %329#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %340:2 = qlx.apply #qlx.action<cx>(%49#0, %328#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %341:2 = qlx.apply #qlx.action<cx>(%50#0, %322#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %342:2 = qlx.apply #qlx.action<cx>(%51#0, %322#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %343:2 = qlx.apply #qlx.action<cx>(%52#0, %321#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %344:2 = qlx.apply #qlx.action<cx>(%53#0, %315#0) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %345:2 = qlx.apply #qlx.action<cx>(%54#0, %315#1) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %346 = qlx.measure <Z> %330#0 : !qlx.logical_qubit -> i1
    %347 = qlx.measure <Z> %330#1 : !qlx.logical_qubit -> i1
    %348 = qlx.measure <Z> %331#0 : !qlx.logical_qubit -> i1
    %349 = qlx.measure <Z> %331#1 : !qlx.logical_qubit -> i1
    %350 = qlx.measure <Z> %332#0 : !qlx.logical_qubit -> i1
    %351 = qlx.measure <Z> %332#1 : !qlx.logical_qubit -> i1
    %352 = qlx.measure <Z> %333#0 : !qlx.logical_qubit -> i1
    %353 = qlx.measure <Z> %333#1 : !qlx.logical_qubit -> i1
    %354 = qlx.measure <Z> %334#0 : !qlx.logical_qubit -> i1
    %355 = qlx.measure <Z> %334#1 : !qlx.logical_qubit -> i1
    %356 = qlx.measure <Z> %335#0 : !qlx.logical_qubit -> i1
    %357 = qlx.measure <Z> %335#1 : !qlx.logical_qubit -> i1
    %358 = qlx.measure <Z> %336#0 : !qlx.logical_qubit -> i1
    %359 = qlx.measure <Z> %336#1 : !qlx.logical_qubit -> i1
    %360 = qlx.measure <Z> %337#0 : !qlx.logical_qubit -> i1
    %361 = qlx.measure <Z> %337#1 : !qlx.logical_qubit -> i1
    %362 = qlx.measure <Z> %338#0 : !qlx.logical_qubit -> i1
    %363 = qlx.measure <Z> %338#1 : !qlx.logical_qubit -> i1
    %364 = qlx.measure <Z> %339#0 : !qlx.logical_qubit -> i1
    %365 = qlx.measure <Z> %339#1 : !qlx.logical_qubit -> i1
    %366 = qlx.measure <Z> %340#0 : !qlx.logical_qubit -> i1
    %367 = qlx.measure <Z> %340#1 : !qlx.logical_qubit -> i1
    %368 = qlx.measure <Z> %341#0 : !qlx.logical_qubit -> i1
    %369 = qlx.measure <Z> %341#1 : !qlx.logical_qubit -> i1
    %370 = qlx.measure <Z> %342#0 : !qlx.logical_qubit -> i1
    %371 = qlx.measure <Z> %342#1 : !qlx.logical_qubit -> i1
    %372 = qlx.measure <Z> %343#0 : !qlx.logical_qubit -> i1
    %373 = qlx.measure <Z> %343#1 : !qlx.logical_qubit -> i1
    %374 = qlx.measure <Z> %344#0 : !qlx.logical_qubit -> i1
    %375 = qlx.measure <Z> %344#1 : !qlx.logical_qubit -> i1
    %376 = qlx.measure <Z> %345#0 : !qlx.logical_qubit -> i1
    %377 = qlx.measure <Z> %345#1 : !qlx.logical_qubit -> i1
  }
}
