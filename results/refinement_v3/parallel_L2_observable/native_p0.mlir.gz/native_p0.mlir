module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<h>(%1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.apply #qlx.action<x>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %10 = qlx.apply #qlx.action<h>(%9) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 1.5707963267948966 : f64
    %11:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %10, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %12 = qlx.apply #qlx.action<pauli_rotation>(%11#0, %cst_0) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %13 = qlx.apply #qlx.action<pauli_rotation>(%11#1, %cst_1) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %14:2 = qlx.apply #qlx.action<pauli_rotation>(%12, %13, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %15 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %16 = qlx.apply #qlx.action<pauli_rotation>(%15, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %17 = qlx.apply #qlx.action<h>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %18 = qlx.apply #qlx.action<h>(%14#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %19 = qlx.apply #qlx.action<pauli_rotation>(%18, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %20 = qlx.apply #qlx.action<h>(%19) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %21:2 = qlx.apply #qlx.action<pauli_rotation>(%17, %20, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %22 = qlx.apply #qlx.action<pauli_rotation>(%21#0, %cst_6) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %23 = qlx.apply #qlx.action<pauli_rotation>(%21#1, %cst_7) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_8 = arith.constant 0.78539816339744828 : f64
    %24:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %23, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %25 = qlx.apply #qlx.action<h>(%14#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_9 = arith.constant 2.3561944901923448 : f64
    %26 = qlx.apply #qlx.action<pauli_rotation>(%25, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %27 = qlx.apply #qlx.action<h>(%26) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 0.78539816339744828 : f64
    %28 = qlx.apply #qlx.action<pauli_rotation>(%3, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %29 = qlx.apply #qlx.action<h>(%28) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %30:2 = qlx.apply #qlx.action<pauli_rotation>(%27, %29, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %31 = qlx.apply #qlx.action<pauli_rotation>(%30#0, %cst_12) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %32 = qlx.apply #qlx.action<pauli_rotation>(%30#1, %cst_13) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %33:2 = qlx.apply #qlx.action<pauli_rotation>(%31, %32, %cst_14) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %34 = qlx.apply #qlx.action<h>(%24#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_15 = arith.constant 2.3561944901923448 : f64
    %35 = qlx.apply #qlx.action<pauli_rotation>(%34, %cst_15) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %36 = qlx.apply #qlx.action<h>(%35) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %37 = qlx.apply #qlx.action<h>(%33#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_16 = arith.constant 0.78539816339744828 : f64
    %38 = qlx.apply #qlx.action<pauli_rotation>(%37, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %39 = qlx.apply #qlx.action<h>(%38) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_17 = arith.constant 5.000000e-01 : f64
    %40:2 = qlx.apply #qlx.action<pauli_rotation>(%36, %39, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %41 = qlx.apply #qlx.action<pauli_rotation>(%40#0, %cst_18) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %42 = qlx.apply #qlx.action<pauli_rotation>(%40#1, %cst_19) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_20 = arith.constant 5.000000e-01 : f64
    %43:2 = qlx.apply #qlx.action<pauli_rotation>(%41, %42, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44 = qlx.apply #qlx.action<h>(%24#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %45 = qlx.apply #qlx.action<pauli_rotation>(%44, %cst_21) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %46 = qlx.apply #qlx.action<h>(%45) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %47 = qlx.apply #qlx.action<h>(%43#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%47, %cst_22) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %49 = qlx.apply #qlx.action<h>(%48) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 0.78539816339744828 : f64
    %50:2 = qlx.apply #qlx.action<pauli_rotation>(%46, %49, %cst_23) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%50#0, %cst_24) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %52 = qlx.apply #qlx.action<pauli_rotation>(%50#1, %cst_25) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_26 = arith.constant 0.78539816339744828 : f64
    %53:2 = qlx.apply #qlx.action<pauli_rotation>(%51, %52, %cst_26) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %54 = qlx.apply #qlx.action<h>(%43#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 2.3561944901923448 : f64
    %55 = qlx.apply #qlx.action<pauli_rotation>(%54, %cst_27) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %56 = qlx.apply #qlx.action<h>(%55) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %57 = qlx.apply #qlx.action<h>(%33#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%57, %cst_28) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %59 = qlx.apply #qlx.action<h>(%58) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_29 = arith.constant 0.78539816339744828 : f64
    %60:2 = qlx.apply #qlx.action<pauli_rotation>(%56, %59, %cst_29) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%60#0, %cst_30) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_31 = arith.constant 1.5707963267948966 : f64
    %62 = qlx.apply #qlx.action<pauli_rotation>(%60#1, %cst_31) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_32 = arith.constant 0.78539816339744828 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%61, %62, %cst_32) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<x>(%5) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %65 = qlx.apply #qlx.action<h>(%64) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<h>(%6) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %67:2 = qlx.apply #qlx.action<pauli_rotation>(%65, %66, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 1.5707963267948966 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%67#0, %cst_34) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %69 = qlx.apply #qlx.action<pauli_rotation>(%67#1, %cst_35) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %70:2 = qlx.apply #qlx.action<pauli_rotation>(%68, %69, %cst_36) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_37 = arith.constant 0.78539816339744828 : f64
    %71 = qlx.apply #qlx.action<pauli_rotation>(%4, %cst_37) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %72 = qlx.apply #qlx.action<h>(%71) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<h>(%70#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_38 = arith.constant 2.3561944901923448 : f64
    %74 = qlx.apply #qlx.action<pauli_rotation>(%73, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %75 = qlx.apply #qlx.action<h>(%74) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 0.78539816339744828 : f64
    %76:2 = qlx.apply #qlx.action<pauli_rotation>(%72, %75, %cst_39) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %77 = qlx.apply #qlx.action<pauli_rotation>(%76#0, %cst_40) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %78 = qlx.apply #qlx.action<pauli_rotation>(%76#1, %cst_41) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_42 = arith.constant 0.78539816339744828 : f64
    %79:2 = qlx.apply #qlx.action<pauli_rotation>(%77, %78, %cst_42) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %80 = qlx.apply #qlx.action<h>(%70#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_43 = arith.constant 2.3561944901923448 : f64
    %81 = qlx.apply #qlx.action<pauli_rotation>(%80, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %82 = qlx.apply #qlx.action<h>(%81) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %83 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_44 = arith.constant 0.78539816339744828 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%83, %cst_44) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %85 = qlx.apply #qlx.action<h>(%84) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 0.78539816339744828 : f64
    %86:2 = qlx.apply #qlx.action<pauli_rotation>(%82, %85, %cst_45) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %87 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %cst_46) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_47 = arith.constant 1.5707963267948966 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%86#1, %cst_47) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_48 = arith.constant 0.78539816339744828 : f64
    %89:2 = qlx.apply #qlx.action<pauli_rotation>(%87, %88, %cst_48) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %90 = qlx.apply #qlx.action<h>(%79#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_49 = arith.constant 2.3561944901923448 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%90, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %92 = qlx.apply #qlx.action<h>(%91) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %93 = qlx.apply #qlx.action<h>(%89#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_50 = arith.constant 0.78539816339744828 : f64
    %94 = qlx.apply #qlx.action<pauli_rotation>(%93, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %95 = qlx.apply #qlx.action<h>(%94) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_51 = arith.constant 5.000000e-01 : f64
    %96:2 = qlx.apply #qlx.action<pauli_rotation>(%92, %95, %cst_51) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %97 = qlx.apply #qlx.action<pauli_rotation>(%96#0, %cst_52) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %98 = qlx.apply #qlx.action<pauli_rotation>(%96#1, %cst_53) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_54 = arith.constant 5.000000e-01 : f64
    %99:2 = qlx.apply #qlx.action<pauli_rotation>(%97, %98, %cst_54) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %100 = qlx.apply #qlx.action<h>(%79#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %101 = qlx.apply #qlx.action<pauli_rotation>(%100, %cst_55) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %102 = qlx.apply #qlx.action<h>(%101) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %103 = qlx.apply #qlx.action<h>(%99#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_56 = arith.constant 0.78539816339744828 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%103, %cst_56) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %105 = qlx.apply #qlx.action<h>(%104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_57 = arith.constant 0.78539816339744828 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%102, %105, %cst_57) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %107 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %cst_58) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%106#1, %cst_59) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_60 = arith.constant 0.78539816339744828 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%107, %108, %cst_60) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %110 = qlx.apply #qlx.action<h>(%99#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_61 = arith.constant 2.3561944901923448 : f64
    %111 = qlx.apply #qlx.action<pauli_rotation>(%110, %cst_61) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %112 = qlx.apply #qlx.action<h>(%111) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %113 = qlx.apply #qlx.action<h>(%89#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113, %cst_62) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %115 = qlx.apply #qlx.action<h>(%114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_63 = arith.constant 0.78539816339744828 : f64
    %116:2 = qlx.apply #qlx.action<pauli_rotation>(%112, %115, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 1.5707963267948966 : f64
    %117 = qlx.apply #qlx.action<pauli_rotation>(%116#0, %cst_64) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %118 = qlx.apply #qlx.action<pauli_rotation>(%116#1, %cst_65) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_66 = arith.constant 0.78539816339744828 : f64
    %119:2 = qlx.apply #qlx.action<pauli_rotation>(%117, %118, %cst_66) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %120 = qlx.apply #qlx.action<h>(%63#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_67 = arith.constant 2.3561944901923448 : f64
    %121 = qlx.apply #qlx.action<pauli_rotation>(%120, %cst_67) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %122 = qlx.apply #qlx.action<h>(%121) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %123 = qlx.apply #qlx.action<h>(%109#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_68 = arith.constant 2.3561944901923448 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%123, %cst_68) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %125 = qlx.apply #qlx.action<h>(%124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %126:2 = qlx.apply #qlx.action<pauli_rotation>(%122, %125, %cst_69) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_70 = arith.constant 1.5707963267948966 : f64
    %127 = qlx.apply #qlx.action<pauli_rotation>(%126#0, %cst_70) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_71 = arith.constant 1.5707963267948966 : f64
    %128 = qlx.apply #qlx.action<pauli_rotation>(%126#1, %cst_71) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %129:2 = qlx.apply #qlx.action<pauli_rotation>(%127, %128, %cst_72) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %130 = qlx.apply #qlx.action<h>(%63#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_73 = arith.constant 2.3561944901923448 : f64
    %131 = qlx.apply #qlx.action<pauli_rotation>(%130, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %132 = qlx.apply #qlx.action<h>(%131) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %133 = qlx.apply #qlx.action<h>(%129#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_74 = arith.constant 3.1415926535897931 : f64
    %134 = qlx.apply #qlx.action<pauli_rotation>(%133, %cst_74) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<h>(%134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %136:2 = qlx.apply #qlx.action<pauli_rotation>(%132, %135, %cst_75) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %137 = qlx.apply #qlx.action<pauli_rotation>(%136#0, %cst_76) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_77 = arith.constant 1.5707963267948966 : f64
    %138 = qlx.apply #qlx.action<pauli_rotation>(%136#1, %cst_77) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %139:2 = qlx.apply #qlx.action<pauli_rotation>(%137, %138, %cst_78) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %140 = qlx.apply #qlx.action<h>(%129#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 3.1415926535897931 : f64
    %141 = qlx.apply #qlx.action<pauli_rotation>(%140, %cst_79) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %142 = qlx.apply #qlx.action<h>(%141) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %143 = qlx.apply #qlx.action<h>(%109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_80 = arith.constant 2.3561944901923448 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_80) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %146:2 = qlx.apply #qlx.action<pauli_rotation>(%142, %145, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.5707963267948966 : f64
    %147 = qlx.apply #qlx.action<pauli_rotation>(%146#0, %cst_82) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %148 = qlx.apply #qlx.action<pauli_rotation>(%146#1, %cst_83) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %149:2 = qlx.apply #qlx.action<pauli_rotation>(%147, %148, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %150 = qlx.apply #qlx.action<h>(%53#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 2.3561944901923448 : f64
    %151 = qlx.apply #qlx.action<pauli_rotation>(%150, %cst_85) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %152 = qlx.apply #qlx.action<h>(%151) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %153 = qlx.apply #qlx.action<h>(%139#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_86 = arith.constant 3.1415926535897931 : f64
    %154 = qlx.apply #qlx.action<pauli_rotation>(%153, %cst_86) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %155 = qlx.apply #qlx.action<h>(%154) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %156:2 = qlx.apply #qlx.action<pauli_rotation>(%152, %155, %cst_87) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.5707963267948966 : f64
    %157 = qlx.apply #qlx.action<pauli_rotation>(%156#0, %cst_88) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %158 = qlx.apply #qlx.action<pauli_rotation>(%156#1, %cst_89) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %159:2 = qlx.apply #qlx.action<pauli_rotation>(%157, %158, %cst_90) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %160 = qlx.apply #qlx.action<h>(%139#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_91 = arith.constant 3.1415926535897931 : f64
    %161 = qlx.apply #qlx.action<pauli_rotation>(%160, %cst_91) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %162 = qlx.apply #qlx.action<h>(%161) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %163 = qlx.apply #qlx.action<h>(%149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_92 = arith.constant 3.1415926535897931 : f64
    %164 = qlx.apply #qlx.action<pauli_rotation>(%163, %cst_92) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %165 = qlx.apply #qlx.action<h>(%164) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %166:2 = qlx.apply #qlx.action<pauli_rotation>(%162, %165, %cst_93) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 1.5707963267948966 : f64
    %167 = qlx.apply #qlx.action<pauli_rotation>(%166#0, %cst_94) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %168 = qlx.apply #qlx.action<pauli_rotation>(%166#1, %cst_95) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %169:2 = qlx.apply #qlx.action<pauli_rotation>(%167, %168, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %170 = qlx.apply #qlx.action<h>(%149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_97 = arith.constant 3.1415926535897931 : f64
    %171 = qlx.apply #qlx.action<pauli_rotation>(%170, %cst_97) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %172 = qlx.apply #qlx.action<h>(%171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %173 = qlx.apply #qlx.action<h>(%119#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_98 = arith.constant 2.3561944901923448 : f64
    %174 = qlx.apply #qlx.action<pauli_rotation>(%173, %cst_98) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %175 = qlx.apply #qlx.action<h>(%174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %176:2 = qlx.apply #qlx.action<pauli_rotation>(%172, %175, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %177 = qlx.apply #qlx.action<pauli_rotation>(%176#0, %cst_100) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_101 = arith.constant 1.5707963267948966 : f64
    %178 = qlx.apply #qlx.action<pauli_rotation>(%176#1, %cst_101) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%177, %178, %cst_102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %180 = qlx.apply #qlx.action<h>(%53#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_103 = arith.constant 2.3561944901923448 : f64
    %181 = qlx.apply #qlx.action<pauli_rotation>(%180, %cst_103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %182 = qlx.apply #qlx.action<h>(%159#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_104 = arith.constant 3.1415926535897931 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%182, %cst_104) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_105 = arith.constant 5.000000e-01 : f64
    %184:2 = qlx.apply #qlx.action<pauli_rotation>(%181, %183, %cst_105) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %185 = qlx.apply #qlx.action<h>(%159#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_106 = arith.constant 3.1415926535897931 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%185, %cst_106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %187 = qlx.apply #qlx.action<h>(%169#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_107 = arith.constant 3.1415926535897931 : f64
    %188 = qlx.apply #qlx.action<pauli_rotation>(%187, %cst_107) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_108 = arith.constant 5.000000e-01 : f64
    %189:2 = qlx.apply #qlx.action<pauli_rotation>(%186, %188, %cst_108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %190 = qlx.apply #qlx.action<h>(%169#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_109 = arith.constant 3.1415926535897931 : f64
    %191 = qlx.apply #qlx.action<pauli_rotation>(%190, %cst_109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %192 = qlx.apply #qlx.action<h>(%179#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_110 = arith.constant 3.1415926535897931 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%192, %cst_110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_111 = arith.constant 5.000000e-01 : f64
    %194:2 = qlx.apply #qlx.action<pauli_rotation>(%191, %193, %cst_111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %195 = qlx.apply #qlx.action<h>(%179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 3.1415926535897931 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%195, %cst_112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<h>(%119#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_113 = arith.constant 2.3561944901923448 : f64
    %198 = qlx.apply #qlx.action<pauli_rotation>(%197, %cst_113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 5.000000e-01 : f64
    %199:2 = qlx.apply #qlx.action<pauli_rotation>(%196, %198, %cst_114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %200 = qlx.apply #qlx.action<h>(%184#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %201 = qlx.apply #qlx.action<h>(%189#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_115 = arith.constant 1.5707963267948966 : f64
    %202:2 = qlx.apply #qlx.action<pauli_rotation>(%200, %201, %cst_115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%202#0, %cst_116) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %204 = qlx.apply #qlx.action<pauli_rotation>(%202#1, %cst_117) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %205:2 = qlx.apply #qlx.action<pauli_rotation>(%203, %204, %cst_118) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %206 = qlx.apply #qlx.action<h>(%189#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%194#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %208:2 = qlx.apply #qlx.action<pauli_rotation>(%206, %207, %cst_119) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %209 = qlx.apply #qlx.action<pauli_rotation>(%208#0, %cst_120) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %210 = qlx.apply #qlx.action<pauli_rotation>(%208#1, %cst_121) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%209, %210, %cst_122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %212 = qlx.apply #qlx.action<h>(%194#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %213 = qlx.apply #qlx.action<h>(%199#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %214:2 = qlx.apply #qlx.action<pauli_rotation>(%212, %213, %cst_123) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %215 = qlx.apply #qlx.action<pauli_rotation>(%214#0, %cst_124) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 1.5707963267948966 : f64
    %216 = qlx.apply #qlx.action<pauli_rotation>(%214#1, %cst_125) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_126 = arith.constant 1.5707963267948966 : f64
    %217:2 = qlx.apply #qlx.action<pauli_rotation>(%215, %216, %cst_126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %218 = qlx.apply #qlx.action<h>(%205#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 3.1415926535897931 : f64
    %219 = qlx.apply #qlx.action<pauli_rotation>(%218, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<h>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %221 = qlx.apply #qlx.action<h>(%211#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_128 = arith.constant 3.1415926535897931 : f64
    %222 = qlx.apply #qlx.action<pauli_rotation>(%221, %cst_128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %223 = qlx.apply #qlx.action<h>(%222) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %224:2 = qlx.apply #qlx.action<pauli_rotation>(%220, %223, %cst_129) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %225 = qlx.apply #qlx.action<pauli_rotation>(%224#0, %cst_130) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 1.5707963267948966 : f64
    %226 = qlx.apply #qlx.action<pauli_rotation>(%224#1, %cst_131) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %227:2 = qlx.apply #qlx.action<pauli_rotation>(%225, %226, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %228 = qlx.apply #qlx.action<h>(%211#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_133 = arith.constant 3.1415926535897931 : f64
    %229 = qlx.apply #qlx.action<pauli_rotation>(%228, %cst_133) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %230 = qlx.apply #qlx.action<h>(%229) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %231 = qlx.apply #qlx.action<h>(%217#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_134 = arith.constant 3.1415926535897931 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231, %cst_134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<h>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %234:2 = qlx.apply #qlx.action<pauli_rotation>(%230, %233, %cst_135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %235 = qlx.apply #qlx.action<pauli_rotation>(%234#0, %cst_136) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %236 = qlx.apply #qlx.action<pauli_rotation>(%234#1, %cst_137) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_138 = arith.constant 1.5707963267948966 : f64
    %237:2 = qlx.apply #qlx.action<pauli_rotation>(%235, %236, %cst_138) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %238 = qlx.apply #qlx.action<h>(%227#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_139 = arith.constant 3.1415926535897931 : f64
    %239 = qlx.apply #qlx.action<pauli_rotation>(%238, %cst_139) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %240 = qlx.apply #qlx.action<h>(%239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %241 = qlx.apply #qlx.action<h>(%237#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_140 = arith.constant 3.1415926535897931 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%241, %cst_140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %243 = qlx.apply #qlx.action<h>(%242) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %244:2 = qlx.apply #qlx.action<pauli_rotation>(%240, %243, %cst_141) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 1.5707963267948966 : f64
    %245 = qlx.apply #qlx.action<pauli_rotation>(%244#0, %cst_142) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%244#1, %cst_143) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %247:2 = qlx.apply #qlx.action<pauli_rotation>(%245, %246, %cst_144) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_145 = arith.constant 0.78539816339744828 : f64
    %248 = qlx.apply #qlx.action<pauli_rotation>(%184#0, %cst_145) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %249 = qlx.apply #qlx.action<h>(%248) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %250 = qlx.apply #qlx.action<h>(%205#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_146 = arith.constant 2.3561944901923448 : f64
    %251 = qlx.apply #qlx.action<pauli_rotation>(%250, %cst_146) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %252 = qlx.apply #qlx.action<h>(%251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_147 = arith.constant 0.78539816339744828 : f64
    %253:2 = qlx.apply #qlx.action<pauli_rotation>(%249, %252, %cst_147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %254 = qlx.apply #qlx.action<pauli_rotation>(%253#0, %cst_148) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_149 = arith.constant 1.5707963267948966 : f64
    %255 = qlx.apply #qlx.action<pauli_rotation>(%253#1, %cst_149) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_150 = arith.constant 0.78539816339744828 : f64
    %256:2 = qlx.apply #qlx.action<pauli_rotation>(%254, %255, %cst_150) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<h>(%227#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_151 = arith.constant 2.3561944901923448 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%257, %cst_151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<h>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%247#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_152 = arith.constant 2.3561944901923448 : f64
    %261 = qlx.apply #qlx.action<pauli_rotation>(%260, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %262 = qlx.apply #qlx.action<h>(%261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_153 = arith.constant 0.78539816339744828 : f64
    %263:2 = qlx.apply #qlx.action<pauli_rotation>(%259, %262, %cst_153) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %264 = qlx.apply #qlx.action<pauli_rotation>(%263#0, %cst_154) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %265 = qlx.apply #qlx.action<pauli_rotation>(%263#1, %cst_155) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_156 = arith.constant 0.78539816339744828 : f64
    %266:2 = qlx.apply #qlx.action<pauli_rotation>(%264, %265, %cst_156) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %267 = qlx.apply #qlx.action<h>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_157 = arith.constant 2.3561944901923448 : f64
    %268 = qlx.apply #qlx.action<pauli_rotation>(%267, %cst_157) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %269 = qlx.apply #qlx.action<h>(%268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %270 = qlx.apply #qlx.action<h>(%266#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_158 = arith.constant 0.78539816339744828 : f64
    %271 = qlx.apply #qlx.action<pauli_rotation>(%270, %cst_158) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %272 = qlx.apply #qlx.action<h>(%271) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_159 = arith.constant 5.000000e-01 : f64
    %273:2 = qlx.apply #qlx.action<pauli_rotation>(%269, %272, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %274 = qlx.apply #qlx.action<pauli_rotation>(%273#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.5707963267948966 : f64
    %275 = qlx.apply #qlx.action<pauli_rotation>(%273#1, %cst_161) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 5.000000e-01 : f64
    %276:2 = qlx.apply #qlx.action<pauli_rotation>(%274, %275, %cst_162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %277 = qlx.apply #qlx.action<h>(%256#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 1.5707963267948966 : f64
    %278 = qlx.apply #qlx.action<pauli_rotation>(%277, %cst_163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %279 = qlx.apply #qlx.action<h>(%278) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %280 = qlx.apply #qlx.action<h>(%276#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_164 = arith.constant 0.78539816339744828 : f64
    %281 = qlx.apply #qlx.action<pauli_rotation>(%280, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %282 = qlx.apply #qlx.action<h>(%281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 0.78539816339744828 : f64
    %283:2 = qlx.apply #qlx.action<pauli_rotation>(%279, %282, %cst_165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %284 = qlx.apply #qlx.action<pauli_rotation>(%283#0, %cst_166) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %285 = qlx.apply #qlx.action<pauli_rotation>(%283#1, %cst_167) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_168 = arith.constant 0.78539816339744828 : f64
    %286:2 = qlx.apply #qlx.action<pauli_rotation>(%284, %285, %cst_168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %287 = qlx.apply #qlx.action<h>(%276#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 2.3561944901923448 : f64
    %288 = qlx.apply #qlx.action<pauli_rotation>(%287, %cst_169) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %289 = qlx.apply #qlx.action<h>(%288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %290 = qlx.apply #qlx.action<h>(%266#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_170 = arith.constant 1.5707963267948966 : f64
    %291 = qlx.apply #qlx.action<pauli_rotation>(%290, %cst_170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %292 = qlx.apply #qlx.action<h>(%291) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_171 = arith.constant 0.78539816339744828 : f64
    %293:2 = qlx.apply #qlx.action<pauli_rotation>(%289, %292, %cst_171) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %294 = qlx.apply #qlx.action<pauli_rotation>(%293#0, %cst_172) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_173 = arith.constant 1.5707963267948966 : f64
    %295 = qlx.apply #qlx.action<pauli_rotation>(%293#1, %cst_173) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_174 = arith.constant 0.78539816339744828 : f64
    %296:2 = qlx.apply #qlx.action<pauli_rotation>(%294, %295, %cst_174) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %297 = qlx.apply #qlx.action<h>(%247#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 2.3561944901923448 : f64
    %298 = qlx.apply #qlx.action<pauli_rotation>(%297, %cst_175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %299 = qlx.apply #qlx.action<h>(%298) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %300 = qlx.apply #qlx.action<h>(%237#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_176 = arith.constant 2.3561944901923448 : f64
    %301 = qlx.apply #qlx.action<pauli_rotation>(%300, %cst_176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %302 = qlx.apply #qlx.action<h>(%301) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_177 = arith.constant 0.78539816339744828 : f64
    %303:2 = qlx.apply #qlx.action<pauli_rotation>(%299, %302, %cst_177) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %304 = qlx.apply #qlx.action<pauli_rotation>(%303#0, %cst_178) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_179 = arith.constant 1.5707963267948966 : f64
    %305 = qlx.apply #qlx.action<pauli_rotation>(%303#1, %cst_179) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_180 = arith.constant 0.78539816339744828 : f64
    %306:2 = qlx.apply #qlx.action<pauli_rotation>(%304, %305, %cst_180) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %307 = qlx.apply #qlx.action<h>(%217#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_181 = arith.constant 2.3561944901923448 : f64
    %308 = qlx.apply #qlx.action<pauli_rotation>(%307, %cst_181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %309 = qlx.apply #qlx.action<h>(%308) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_182 = arith.constant 0.78539816339744828 : f64
    %310 = qlx.apply #qlx.action<pauli_rotation>(%199#1, %cst_182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %311 = qlx.apply #qlx.action<h>(%310) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_183 = arith.constant 0.78539816339744828 : f64
    %312:2 = qlx.apply #qlx.action<pauli_rotation>(%309, %311, %cst_183) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %313 = qlx.apply #qlx.action<pauli_rotation>(%312#0, %cst_184) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.5707963267948966 : f64
    %314 = qlx.apply #qlx.action<pauli_rotation>(%312#1, %cst_185) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_186 = arith.constant 0.78539816339744828 : f64
    %315:2 = qlx.apply #qlx.action<pauli_rotation>(%313, %314, %cst_186) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %316 = qlx.apply #qlx.action<h>(%306#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_187 = arith.constant 2.3561944901923448 : f64
    %317 = qlx.apply #qlx.action<pauli_rotation>(%316, %cst_187) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %318 = qlx.apply #qlx.action<h>(%317) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %319 = qlx.apply #qlx.action<h>(%315#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_188 = arith.constant 0.78539816339744828 : f64
    %320 = qlx.apply #qlx.action<pauli_rotation>(%319, %cst_188) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %321 = qlx.apply #qlx.action<h>(%320) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_189 = arith.constant 5.000000e-01 : f64
    %322:2 = qlx.apply #qlx.action<pauli_rotation>(%318, %321, %cst_189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %323 = qlx.apply #qlx.action<pauli_rotation>(%322#0, %cst_190) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_191 = arith.constant 1.5707963267948966 : f64
    %324 = qlx.apply #qlx.action<pauli_rotation>(%322#1, %cst_191) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_192 = arith.constant 5.000000e-01 : f64
    %325:2 = qlx.apply #qlx.action<pauli_rotation>(%323, %324, %cst_192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %326 = qlx.apply #qlx.action<h>(%306#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %327 = qlx.apply #qlx.action<pauli_rotation>(%326, %cst_193) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %328 = qlx.apply #qlx.action<h>(%327) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %329 = qlx.apply #qlx.action<h>(%325#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_194 = arith.constant 0.78539816339744828 : f64
    %330 = qlx.apply #qlx.action<pauli_rotation>(%329, %cst_194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %331 = qlx.apply #qlx.action<h>(%330) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_195 = arith.constant 0.78539816339744828 : f64
    %332:2 = qlx.apply #qlx.action<pauli_rotation>(%328, %331, %cst_195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %333 = qlx.apply #qlx.action<pauli_rotation>(%332#0, %cst_196) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.5707963267948966 : f64
    %334 = qlx.apply #qlx.action<pauli_rotation>(%332#1, %cst_197) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_198 = arith.constant 0.78539816339744828 : f64
    %335:2 = qlx.apply #qlx.action<pauli_rotation>(%333, %334, %cst_198) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %336 = qlx.apply #qlx.action<h>(%325#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_199 = arith.constant 2.3561944901923448 : f64
    %337 = qlx.apply #qlx.action<pauli_rotation>(%336, %cst_199) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %338 = qlx.apply #qlx.action<h>(%337) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %339 = qlx.apply #qlx.action<h>(%315#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_200 = arith.constant 1.5707963267948966 : f64
    %340 = qlx.apply #qlx.action<pauli_rotation>(%339, %cst_200) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %341 = qlx.apply #qlx.action<h>(%340) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 0.78539816339744828 : f64
    %342:2 = qlx.apply #qlx.action<pauli_rotation>(%338, %341, %cst_201) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_202 = arith.constant 1.5707963267948966 : f64
    %343 = qlx.apply #qlx.action<pauli_rotation>(%342#0, %cst_202) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %344 = qlx.apply #qlx.action<pauli_rotation>(%342#1, %cst_203) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_204 = arith.constant 0.78539816339744828 : f64
    %345:2 = qlx.apply #qlx.action<pauli_rotation>(%343, %344, %cst_204) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %346 = qlx.apply #qlx.action<h>(%296#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_205 = arith.constant 2.3561944901923448 : f64
    %347 = qlx.apply #qlx.action<pauli_rotation>(%346, %cst_205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %348 = qlx.apply #qlx.action<h>(%347) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %349 = qlx.apply #qlx.action<h>(%335#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_206 = arith.constant 2.3561944901923448 : f64
    %350 = qlx.apply #qlx.action<pauli_rotation>(%349, %cst_206) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %351 = qlx.apply #qlx.action<h>(%350) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %352:2 = qlx.apply #qlx.action<pauli_rotation>(%348, %351, %cst_207) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %353 = qlx.apply #qlx.action<pauli_rotation>(%352#0, %cst_208) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %354 = qlx.apply #qlx.action<pauli_rotation>(%352#1, %cst_209) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %355:2 = qlx.apply #qlx.action<pauli_rotation>(%353, %354, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %356 = qlx.apply #qlx.action<h>(%296#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_211 = arith.constant 2.3561944901923448 : f64
    %357 = qlx.apply #qlx.action<pauli_rotation>(%356, %cst_211) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %358 = qlx.apply #qlx.action<h>(%357) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %359 = qlx.apply #qlx.action<h>(%355#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 3.1415926535897931 : f64
    %360 = qlx.apply #qlx.action<pauli_rotation>(%359, %cst_212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %361 = qlx.apply #qlx.action<h>(%360) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 1.5707963267948966 : f64
    %362:2 = qlx.apply #qlx.action<pauli_rotation>(%358, %361, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %363 = qlx.apply #qlx.action<pauli_rotation>(%362#0, %cst_214) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %364 = qlx.apply #qlx.action<pauli_rotation>(%362#1, %cst_215) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %365:2 = qlx.apply #qlx.action<pauli_rotation>(%363, %364, %cst_216) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %366 = qlx.apply #qlx.action<h>(%355#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_217 = arith.constant 3.1415926535897931 : f64
    %367 = qlx.apply #qlx.action<pauli_rotation>(%366, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %368 = qlx.apply #qlx.action<h>(%367) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %369 = qlx.apply #qlx.action<h>(%335#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_218 = arith.constant 2.3561944901923448 : f64
    %370 = qlx.apply #qlx.action<pauli_rotation>(%369, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %371 = qlx.apply #qlx.action<h>(%370) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_219 = arith.constant 1.5707963267948966 : f64
    %372:2 = qlx.apply #qlx.action<pauli_rotation>(%368, %371, %cst_219) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %373 = qlx.apply #qlx.action<pauli_rotation>(%372#0, %cst_220) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_221 = arith.constant 1.5707963267948966 : f64
    %374 = qlx.apply #qlx.action<pauli_rotation>(%372#1, %cst_221) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_222 = arith.constant 1.5707963267948966 : f64
    %375:2 = qlx.apply #qlx.action<pauli_rotation>(%373, %374, %cst_222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %376 = qlx.apply #qlx.action<h>(%286#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_223 = arith.constant 2.3561944901923448 : f64
    %377 = qlx.apply #qlx.action<pauli_rotation>(%376, %cst_223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %378 = qlx.apply #qlx.action<h>(%377) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %379 = qlx.apply #qlx.action<h>(%365#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_224 = arith.constant 3.1415926535897931 : f64
    %380 = qlx.apply #qlx.action<pauli_rotation>(%379, %cst_224) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %381 = qlx.apply #qlx.action<h>(%380) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_225 = arith.constant 1.5707963267948966 : f64
    %382:2 = qlx.apply #qlx.action<pauli_rotation>(%378, %381, %cst_225) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %383 = qlx.apply #qlx.action<pauli_rotation>(%382#0, %cst_226) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_227 = arith.constant 1.5707963267948966 : f64
    %384 = qlx.apply #qlx.action<pauli_rotation>(%382#1, %cst_227) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_228 = arith.constant 1.5707963267948966 : f64
    %385:2 = qlx.apply #qlx.action<pauli_rotation>(%383, %384, %cst_228) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %386 = qlx.apply #qlx.action<h>(%365#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_229 = arith.constant 3.1415926535897931 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%386, %cst_229) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %388 = qlx.apply #qlx.action<h>(%387) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %389 = qlx.apply #qlx.action<h>(%375#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_230 = arith.constant 3.1415926535897931 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%389, %cst_230) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %392:2 = qlx.apply #qlx.action<pauli_rotation>(%388, %391, %cst_231) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_232 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %cst_232) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_233 = arith.constant 1.5707963267948966 : f64
    %394 = qlx.apply #qlx.action<pauli_rotation>(%392#1, %cst_233) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_234 = arith.constant 1.5707963267948966 : f64
    %395:2 = qlx.apply #qlx.action<pauli_rotation>(%393, %394, %cst_234) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %396 = qlx.apply #qlx.action<h>(%375#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_235 = arith.constant 3.1415926535897931 : f64
    %397 = qlx.apply #qlx.action<pauli_rotation>(%396, %cst_235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %398 = qlx.apply #qlx.action<h>(%397) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %399 = qlx.apply #qlx.action<h>(%345#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 2.3561944901923448 : f64
    %400 = qlx.apply #qlx.action<pauli_rotation>(%399, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %401 = qlx.apply #qlx.action<h>(%400) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_237 = arith.constant 1.5707963267948966 : f64
    %402:2 = qlx.apply #qlx.action<pauli_rotation>(%398, %401, %cst_237) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_238 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%402#0, %cst_238) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %404 = qlx.apply #qlx.action<pauli_rotation>(%402#1, %cst_239) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_240 = arith.constant 1.5707963267948966 : f64
    %405:2 = qlx.apply #qlx.action<pauli_rotation>(%403, %404, %cst_240) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %406 = qlx.apply #qlx.action<h>(%286#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 2.3561944901923448 : f64
    %407 = qlx.apply #qlx.action<pauli_rotation>(%406, %cst_241) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %408 = qlx.apply #qlx.action<h>(%385#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_242 = arith.constant 3.1415926535897931 : f64
    %409 = qlx.apply #qlx.action<pauli_rotation>(%408, %cst_242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_243 = arith.constant 5.000000e-01 : f64
    %410:2 = qlx.apply #qlx.action<pauli_rotation>(%407, %409, %cst_243) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %411 = qlx.apply #qlx.action<h>(%385#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_244 = arith.constant 3.1415926535897931 : f64
    %412 = qlx.apply #qlx.action<pauli_rotation>(%411, %cst_244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %413 = qlx.apply #qlx.action<h>(%395#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_245 = arith.constant 3.1415926535897931 : f64
    %414 = qlx.apply #qlx.action<pauli_rotation>(%413, %cst_245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_246 = arith.constant 5.000000e-01 : f64
    %415:2 = qlx.apply #qlx.action<pauli_rotation>(%412, %414, %cst_246) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %416 = qlx.apply #qlx.action<h>(%395#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_247 = arith.constant 3.1415926535897931 : f64
    %417 = qlx.apply #qlx.action<pauli_rotation>(%416, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %418 = qlx.apply #qlx.action<h>(%405#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_248 = arith.constant 3.1415926535897931 : f64
    %419 = qlx.apply #qlx.action<pauli_rotation>(%418, %cst_248) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_249 = arith.constant 5.000000e-01 : f64
    %420:2 = qlx.apply #qlx.action<pauli_rotation>(%417, %419, %cst_249) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %421 = qlx.apply #qlx.action<h>(%405#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_250 = arith.constant 3.1415926535897931 : f64
    %422 = qlx.apply #qlx.action<pauli_rotation>(%421, %cst_250) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %423 = qlx.apply #qlx.action<h>(%345#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_251 = arith.constant 2.3561944901923448 : f64
    %424 = qlx.apply #qlx.action<pauli_rotation>(%423, %cst_251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_252 = arith.constant 5.000000e-01 : f64
    %425:2 = qlx.apply #qlx.action<pauli_rotation>(%422, %424, %cst_252) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %426 = qlx.apply #qlx.action<h>(%410#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %427 = qlx.apply #qlx.action<h>(%415#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_253 = arith.constant 1.5707963267948966 : f64
    %428:2 = qlx.apply #qlx.action<pauli_rotation>(%426, %427, %cst_253) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_254 = arith.constant 1.5707963267948966 : f64
    %429 = qlx.apply #qlx.action<pauli_rotation>(%428#0, %cst_254) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_255 = arith.constant 1.5707963267948966 : f64
    %430 = qlx.apply #qlx.action<pauli_rotation>(%428#1, %cst_255) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %431:2 = qlx.apply #qlx.action<pauli_rotation>(%429, %430, %cst_256) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %432 = qlx.apply #qlx.action<h>(%415#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %433 = qlx.apply #qlx.action<h>(%420#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %434:2 = qlx.apply #qlx.action<pauli_rotation>(%432, %433, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_258 = arith.constant 1.5707963267948966 : f64
    %435 = qlx.apply #qlx.action<pauli_rotation>(%434#0, %cst_258) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_259 = arith.constant 1.5707963267948966 : f64
    %436 = qlx.apply #qlx.action<pauli_rotation>(%434#1, %cst_259) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %437:2 = qlx.apply #qlx.action<pauli_rotation>(%435, %436, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %438 = qlx.apply #qlx.action<h>(%420#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %439 = qlx.apply #qlx.action<h>(%425#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_261 = arith.constant 1.5707963267948966 : f64
    %440:2 = qlx.apply #qlx.action<pauli_rotation>(%438, %439, %cst_261) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %441 = qlx.apply #qlx.action<pauli_rotation>(%440#0, %cst_262) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %442 = qlx.apply #qlx.action<pauli_rotation>(%440#1, %cst_263) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_264 = arith.constant 1.5707963267948966 : f64
    %443:2 = qlx.apply #qlx.action<pauli_rotation>(%441, %442, %cst_264) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %444 = qlx.apply #qlx.action<h>(%431#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_265 = arith.constant 3.1415926535897931 : f64
    %445 = qlx.apply #qlx.action<pauli_rotation>(%444, %cst_265) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %446 = qlx.apply #qlx.action<h>(%445) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %447 = qlx.apply #qlx.action<h>(%437#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_266 = arith.constant 3.1415926535897931 : f64
    %448 = qlx.apply #qlx.action<pauli_rotation>(%447, %cst_266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %449 = qlx.apply #qlx.action<h>(%448) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %450:2 = qlx.apply #qlx.action<pauli_rotation>(%446, %449, %cst_267) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %451 = qlx.apply #qlx.action<pauli_rotation>(%450#0, %cst_268) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_269 = arith.constant 1.5707963267948966 : f64
    %452 = qlx.apply #qlx.action<pauli_rotation>(%450#1, %cst_269) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_270 = arith.constant 1.5707963267948966 : f64
    %453:2 = qlx.apply #qlx.action<pauli_rotation>(%451, %452, %cst_270) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %454 = qlx.apply #qlx.action<h>(%437#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_271 = arith.constant 3.1415926535897931 : f64
    %455 = qlx.apply #qlx.action<pauli_rotation>(%454, %cst_271) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %456 = qlx.apply #qlx.action<h>(%455) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %457 = qlx.apply #qlx.action<h>(%443#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_272 = arith.constant 3.1415926535897931 : f64
    %458 = qlx.apply #qlx.action<pauli_rotation>(%457, %cst_272) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %459 = qlx.apply #qlx.action<h>(%458) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %460:2 = qlx.apply #qlx.action<pauli_rotation>(%456, %459, %cst_273) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %461 = qlx.apply #qlx.action<pauli_rotation>(%460#0, %cst_274) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.5707963267948966 : f64
    %462 = qlx.apply #qlx.action<pauli_rotation>(%460#1, %cst_275) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %463:2 = qlx.apply #qlx.action<pauli_rotation>(%461, %462, %cst_276) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %464 = qlx.apply #qlx.action<h>(%453#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 3.1415926535897931 : f64
    %465 = qlx.apply #qlx.action<pauli_rotation>(%464, %cst_277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %466 = qlx.apply #qlx.action<h>(%465) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %467 = qlx.apply #qlx.action<h>(%463#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 3.1415926535897931 : f64
    %468 = qlx.apply #qlx.action<pauli_rotation>(%467, %cst_278) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %469 = qlx.apply #qlx.action<h>(%468) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %470:2 = qlx.apply #qlx.action<pauli_rotation>(%466, %469, %cst_279) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %471 = qlx.apply #qlx.action<pauli_rotation>(%470#0, %cst_280) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_281 = arith.constant 1.5707963267948966 : f64
    %472 = qlx.apply #qlx.action<pauli_rotation>(%470#1, %cst_281) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_282 = arith.constant 1.5707963267948966 : f64
    %473:2 = qlx.apply #qlx.action<pauli_rotation>(%471, %472, %cst_282) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_283 = arith.constant 0.78539816339744828 : f64
    %474 = qlx.apply #qlx.action<pauli_rotation>(%410#0, %cst_283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %475 = qlx.apply #qlx.action<h>(%474) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %476 = qlx.apply #qlx.action<h>(%431#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_284 = arith.constant 2.3561944901923448 : f64
    %477 = qlx.apply #qlx.action<pauli_rotation>(%476, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %478 = qlx.apply #qlx.action<h>(%477) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_285 = arith.constant 0.78539816339744828 : f64
    %479:2 = qlx.apply #qlx.action<pauli_rotation>(%475, %478, %cst_285) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %480 = qlx.apply #qlx.action<pauli_rotation>(%479#0, %cst_286) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.5707963267948966 : f64
    %481 = qlx.apply #qlx.action<pauli_rotation>(%479#1, %cst_287) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_288 = arith.constant 0.78539816339744828 : f64
    %482:2 = qlx.apply #qlx.action<pauli_rotation>(%480, %481, %cst_288) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %483 = qlx.apply #qlx.action<h>(%453#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 2.3561944901923448 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%483, %cst_289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %485 = qlx.apply #qlx.action<h>(%484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %486 = qlx.apply #qlx.action<h>(%473#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_290 = arith.constant 2.3561944901923448 : f64
    %487 = qlx.apply #qlx.action<pauli_rotation>(%486, %cst_290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %488 = qlx.apply #qlx.action<h>(%487) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_291 = arith.constant 0.78539816339744828 : f64
    %489:2 = qlx.apply #qlx.action<pauli_rotation>(%485, %488, %cst_291) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_292 = arith.constant 1.5707963267948966 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%489#0, %cst_292) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_293 = arith.constant 1.5707963267948966 : f64
    %491 = qlx.apply #qlx.action<pauli_rotation>(%489#1, %cst_293) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_294 = arith.constant 0.78539816339744828 : f64
    %492:2 = qlx.apply #qlx.action<pauli_rotation>(%490, %491, %cst_294) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %493 = qlx.apply #qlx.action<h>(%482#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 2.3561944901923448 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %495 = qlx.apply #qlx.action<h>(%494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %496 = qlx.apply #qlx.action<h>(%492#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_296 = arith.constant 0.78539816339744828 : f64
    %497 = qlx.apply #qlx.action<pauli_rotation>(%496, %cst_296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %498 = qlx.apply #qlx.action<h>(%497) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_297 = arith.constant 5.000000e-01 : f64
    %499:2 = qlx.apply #qlx.action<pauli_rotation>(%495, %498, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%499#0, %cst_298) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %501 = qlx.apply #qlx.action<pauli_rotation>(%499#1, %cst_299) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_300 = arith.constant 5.000000e-01 : f64
    %502:2 = qlx.apply #qlx.action<pauli_rotation>(%500, %501, %cst_300) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %503 = qlx.apply #qlx.action<h>(%482#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_301 = arith.constant 1.5707963267948966 : f64
    %504 = qlx.apply #qlx.action<pauli_rotation>(%503, %cst_301) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %505 = qlx.apply #qlx.action<h>(%504) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %506 = qlx.apply #qlx.action<h>(%502#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_302 = arith.constant 0.78539816339744828 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%506, %cst_302) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %508 = qlx.apply #qlx.action<h>(%507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_303 = arith.constant 0.78539816339744828 : f64
    %509:2 = qlx.apply #qlx.action<pauli_rotation>(%505, %508, %cst_303) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %510 = qlx.apply #qlx.action<pauli_rotation>(%509#0, %cst_304) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %511 = qlx.apply #qlx.action<pauli_rotation>(%509#1, %cst_305) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_306 = arith.constant 0.78539816339744828 : f64
    %512:2 = qlx.apply #qlx.action<pauli_rotation>(%510, %511, %cst_306) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %513 = qlx.apply #qlx.action<h>(%502#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 2.3561944901923448 : f64
    %514 = qlx.apply #qlx.action<pauli_rotation>(%513, %cst_307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %515 = qlx.apply #qlx.action<h>(%514) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %516 = qlx.apply #qlx.action<h>(%492#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %517 = qlx.apply #qlx.action<pauli_rotation>(%516, %cst_308) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %518 = qlx.apply #qlx.action<h>(%517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_309 = arith.constant 0.78539816339744828 : f64
    %519:2 = qlx.apply #qlx.action<pauli_rotation>(%515, %518, %cst_309) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%519#0, %cst_310) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_311 = arith.constant 1.5707963267948966 : f64
    %521 = qlx.apply #qlx.action<pauli_rotation>(%519#1, %cst_311) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_312 = arith.constant 0.78539816339744828 : f64
    %522:2 = qlx.apply #qlx.action<pauli_rotation>(%520, %521, %cst_312) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %523 = qlx.apply #qlx.action<h>(%473#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 2.3561944901923448 : f64
    %524 = qlx.apply #qlx.action<pauli_rotation>(%523, %cst_313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %525 = qlx.apply #qlx.action<h>(%524) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %526 = qlx.apply #qlx.action<h>(%463#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_314 = arith.constant 2.3561944901923448 : f64
    %527 = qlx.apply #qlx.action<pauli_rotation>(%526, %cst_314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %528 = qlx.apply #qlx.action<h>(%527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_315 = arith.constant 0.78539816339744828 : f64
    %529:2 = qlx.apply #qlx.action<pauli_rotation>(%525, %528, %cst_315) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%529#0, %cst_316) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_317 = arith.constant 1.5707963267948966 : f64
    %531 = qlx.apply #qlx.action<pauli_rotation>(%529#1, %cst_317) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_318 = arith.constant 0.78539816339744828 : f64
    %532:2 = qlx.apply #qlx.action<pauli_rotation>(%530, %531, %cst_318) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %533 = qlx.apply #qlx.action<h>(%443#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 2.3561944901923448 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%533, %cst_319) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %535 = qlx.apply #qlx.action<h>(%534) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_320 = arith.constant 0.78539816339744828 : f64
    %536 = qlx.apply #qlx.action<pauli_rotation>(%425#1, %cst_320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %537 = qlx.apply #qlx.action<h>(%536) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_321 = arith.constant 0.78539816339744828 : f64
    %538:2 = qlx.apply #qlx.action<pauli_rotation>(%535, %537, %cst_321) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %539 = qlx.apply #qlx.action<pauli_rotation>(%538#0, %cst_322) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %540 = qlx.apply #qlx.action<pauli_rotation>(%538#1, %cst_323) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_324 = arith.constant 0.78539816339744828 : f64
    %541:2 = qlx.apply #qlx.action<pauli_rotation>(%539, %540, %cst_324) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %542 = qlx.apply #qlx.action<h>(%532#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_325 = arith.constant 2.3561944901923448 : f64
    %543 = qlx.apply #qlx.action<pauli_rotation>(%542, %cst_325) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %544 = qlx.apply #qlx.action<h>(%543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %545 = qlx.apply #qlx.action<h>(%541#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_326 = arith.constant 0.78539816339744828 : f64
    %546 = qlx.apply #qlx.action<pauli_rotation>(%545, %cst_326) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %547 = qlx.apply #qlx.action<h>(%546) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_327 = arith.constant 5.000000e-01 : f64
    %548:2 = qlx.apply #qlx.action<pauli_rotation>(%544, %547, %cst_327) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %549 = qlx.apply #qlx.action<pauli_rotation>(%548#0, %cst_328) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_329 = arith.constant 1.5707963267948966 : f64
    %550 = qlx.apply #qlx.action<pauli_rotation>(%548#1, %cst_329) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_330 = arith.constant 5.000000e-01 : f64
    %551:2 = qlx.apply #qlx.action<pauli_rotation>(%549, %550, %cst_330) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %552 = qlx.apply #qlx.action<h>(%532#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_331 = arith.constant 1.5707963267948966 : f64
    %553 = qlx.apply #qlx.action<pauli_rotation>(%552, %cst_331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %554 = qlx.apply #qlx.action<h>(%553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %555 = qlx.apply #qlx.action<h>(%551#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_332 = arith.constant 0.78539816339744828 : f64
    %556 = qlx.apply #qlx.action<pauli_rotation>(%555, %cst_332) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %557 = qlx.apply #qlx.action<h>(%556) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_333 = arith.constant 0.78539816339744828 : f64
    %558:2 = qlx.apply #qlx.action<pauli_rotation>(%554, %557, %cst_333) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %559 = qlx.apply #qlx.action<pauli_rotation>(%558#0, %cst_334) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %560 = qlx.apply #qlx.action<pauli_rotation>(%558#1, %cst_335) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_336 = arith.constant 0.78539816339744828 : f64
    %561:2 = qlx.apply #qlx.action<pauli_rotation>(%559, %560, %cst_336) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %562 = qlx.apply #qlx.action<h>(%551#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_337 = arith.constant 2.3561944901923448 : f64
    %563 = qlx.apply #qlx.action<pauli_rotation>(%562, %cst_337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %564 = qlx.apply #qlx.action<h>(%563) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %565 = qlx.apply #qlx.action<h>(%541#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %566 = qlx.apply #qlx.action<pauli_rotation>(%565, %cst_338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %567 = qlx.apply #qlx.action<h>(%566) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_339 = arith.constant 0.78539816339744828 : f64
    %568:2 = qlx.apply #qlx.action<pauli_rotation>(%564, %567, %cst_339) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %569 = qlx.apply #qlx.action<pauli_rotation>(%568#0, %cst_340) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%568#1, %cst_341) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_342 = arith.constant 0.78539816339744828 : f64
    %571:2 = qlx.apply #qlx.action<pauli_rotation>(%569, %570, %cst_342) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %572 = qlx.apply #qlx.action<h>(%522#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_343 = arith.constant 2.3561944901923448 : f64
    %573 = qlx.apply #qlx.action<pauli_rotation>(%572, %cst_343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %574 = qlx.apply #qlx.action<h>(%573) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %575 = qlx.apply #qlx.action<h>(%561#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_344 = arith.constant 2.3561944901923448 : f64
    %576 = qlx.apply #qlx.action<pauli_rotation>(%575, %cst_344) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %577 = qlx.apply #qlx.action<h>(%576) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %578:2 = qlx.apply #qlx.action<pauli_rotation>(%574, %577, %cst_345) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_346 = arith.constant 1.5707963267948966 : f64
    %579 = qlx.apply #qlx.action<pauli_rotation>(%578#0, %cst_346) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_347 = arith.constant 1.5707963267948966 : f64
    %580 = qlx.apply #qlx.action<pauli_rotation>(%578#1, %cst_347) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %581:2 = qlx.apply #qlx.action<pauli_rotation>(%579, %580, %cst_348) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %582 = qlx.apply #qlx.action<h>(%522#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_349 = arith.constant 2.3561944901923448 : f64
    %583 = qlx.apply #qlx.action<pauli_rotation>(%582, %cst_349) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %584 = qlx.apply #qlx.action<h>(%583) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %585 = qlx.apply #qlx.action<h>(%581#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_350 = arith.constant 3.1415926535897931 : f64
    %586 = qlx.apply #qlx.action<pauli_rotation>(%585, %cst_350) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %587 = qlx.apply #qlx.action<h>(%586) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_351 = arith.constant 1.5707963267948966 : f64
    %588:2 = qlx.apply #qlx.action<pauli_rotation>(%584, %587, %cst_351) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %589 = qlx.apply #qlx.action<pauli_rotation>(%588#0, %cst_352) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_353 = arith.constant 1.5707963267948966 : f64
    %590 = qlx.apply #qlx.action<pauli_rotation>(%588#1, %cst_353) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %591:2 = qlx.apply #qlx.action<pauli_rotation>(%589, %590, %cst_354) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %592 = qlx.apply #qlx.action<h>(%581#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_355 = arith.constant 3.1415926535897931 : f64
    %593 = qlx.apply #qlx.action<pauli_rotation>(%592, %cst_355) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %594 = qlx.apply #qlx.action<h>(%593) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %595 = qlx.apply #qlx.action<h>(%561#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_356 = arith.constant 2.3561944901923448 : f64
    %596 = qlx.apply #qlx.action<pauli_rotation>(%595, %cst_356) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %597 = qlx.apply #qlx.action<h>(%596) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_357 = arith.constant 1.5707963267948966 : f64
    %598:2 = qlx.apply #qlx.action<pauli_rotation>(%594, %597, %cst_357) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%598#0, %cst_358) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %600 = qlx.apply #qlx.action<pauli_rotation>(%598#1, %cst_359) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %601:2 = qlx.apply #qlx.action<pauli_rotation>(%599, %600, %cst_360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %602 = qlx.apply #qlx.action<h>(%512#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_361 = arith.constant 2.3561944901923448 : f64
    %603 = qlx.apply #qlx.action<pauli_rotation>(%602, %cst_361) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %604 = qlx.apply #qlx.action<h>(%603) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %605 = qlx.apply #qlx.action<h>(%591#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_362 = arith.constant 3.1415926535897931 : f64
    %606 = qlx.apply #qlx.action<pauli_rotation>(%605, %cst_362) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %607 = qlx.apply #qlx.action<h>(%606) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %608:2 = qlx.apply #qlx.action<pauli_rotation>(%604, %607, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_364 = arith.constant 1.5707963267948966 : f64
    %609 = qlx.apply #qlx.action<pauli_rotation>(%608#0, %cst_364) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_365 = arith.constant 1.5707963267948966 : f64
    %610 = qlx.apply #qlx.action<pauli_rotation>(%608#1, %cst_365) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %611:2 = qlx.apply #qlx.action<pauli_rotation>(%609, %610, %cst_366) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %612 = qlx.apply #qlx.action<h>(%591#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_367 = arith.constant 3.1415926535897931 : f64
    %613 = qlx.apply #qlx.action<pauli_rotation>(%612, %cst_367) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %614 = qlx.apply #qlx.action<h>(%613) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %615 = qlx.apply #qlx.action<h>(%601#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_368 = arith.constant 3.1415926535897931 : f64
    %616 = qlx.apply #qlx.action<pauli_rotation>(%615, %cst_368) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %617 = qlx.apply #qlx.action<h>(%616) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_369 = arith.constant 1.5707963267948966 : f64
    %618:2 = qlx.apply #qlx.action<pauli_rotation>(%614, %617, %cst_369) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %619 = qlx.apply #qlx.action<pauli_rotation>(%618#0, %cst_370) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %620 = qlx.apply #qlx.action<pauli_rotation>(%618#1, %cst_371) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_372 = arith.constant 1.5707963267948966 : f64
    %621:2 = qlx.apply #qlx.action<pauli_rotation>(%619, %620, %cst_372) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %622 = qlx.apply #qlx.action<h>(%601#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_373 = arith.constant 3.1415926535897931 : f64
    %623 = qlx.apply #qlx.action<pauli_rotation>(%622, %cst_373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %624 = qlx.apply #qlx.action<h>(%623) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %625 = qlx.apply #qlx.action<h>(%571#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_374 = arith.constant 2.3561944901923448 : f64
    %626 = qlx.apply #qlx.action<pauli_rotation>(%625, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %627 = qlx.apply #qlx.action<h>(%626) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_375 = arith.constant 1.5707963267948966 : f64
    %628:2 = qlx.apply #qlx.action<pauli_rotation>(%624, %627, %cst_375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %629 = qlx.apply #qlx.action<pauli_rotation>(%628#0, %cst_376) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%628#1, %cst_377) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_378 = arith.constant 1.5707963267948966 : f64
    %631:2 = qlx.apply #qlx.action<pauli_rotation>(%629, %630, %cst_378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %632 = qlx.apply #qlx.action<h>(%512#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_379 = arith.constant 2.3561944901923448 : f64
    %633 = qlx.apply #qlx.action<pauli_rotation>(%632, %cst_379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %634 = qlx.apply #qlx.action<h>(%611#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_380 = arith.constant 3.1415926535897931 : f64
    %635 = qlx.apply #qlx.action<pauli_rotation>(%634, %cst_380) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_381 = arith.constant 5.000000e-01 : f64
    %636:2 = qlx.apply #qlx.action<pauli_rotation>(%633, %635, %cst_381) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %637 = qlx.apply #qlx.action<h>(%611#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_382 = arith.constant 3.1415926535897931 : f64
    %638 = qlx.apply #qlx.action<pauli_rotation>(%637, %cst_382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %639 = qlx.apply #qlx.action<h>(%621#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_383 = arith.constant 3.1415926535897931 : f64
    %640 = qlx.apply #qlx.action<pauli_rotation>(%639, %cst_383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_384 = arith.constant 5.000000e-01 : f64
    %641:2 = qlx.apply #qlx.action<pauli_rotation>(%638, %640, %cst_384) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %642 = qlx.apply #qlx.action<h>(%621#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_385 = arith.constant 3.1415926535897931 : f64
    %643 = qlx.apply #qlx.action<pauli_rotation>(%642, %cst_385) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %644 = qlx.apply #qlx.action<h>(%631#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_386 = arith.constant 3.1415926535897931 : f64
    %645 = qlx.apply #qlx.action<pauli_rotation>(%644, %cst_386) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_387 = arith.constant 5.000000e-01 : f64
    %646:2 = qlx.apply #qlx.action<pauli_rotation>(%643, %645, %cst_387) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %647 = qlx.apply #qlx.action<h>(%631#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_388 = arith.constant 3.1415926535897931 : f64
    %648 = qlx.apply #qlx.action<pauli_rotation>(%647, %cst_388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %649 = qlx.apply #qlx.action<h>(%571#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_389 = arith.constant 2.3561944901923448 : f64
    %650 = qlx.apply #qlx.action<pauli_rotation>(%649, %cst_389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_390 = arith.constant 5.000000e-01 : f64
    %651:2 = qlx.apply #qlx.action<pauli_rotation>(%648, %650, %cst_390) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %652 = qlx.apply #qlx.action<h>(%636#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %653 = qlx.apply #qlx.action<h>(%641#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %654:2 = qlx.apply #qlx.action<pauli_rotation>(%652, %653, %cst_391) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_392 = arith.constant 1.5707963267948966 : f64
    %655 = qlx.apply #qlx.action<pauli_rotation>(%654#0, %cst_392) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_393 = arith.constant 1.5707963267948966 : f64
    %656 = qlx.apply #qlx.action<pauli_rotation>(%654#1, %cst_393) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_394 = arith.constant 1.5707963267948966 : f64
    %657:2 = qlx.apply #qlx.action<pauli_rotation>(%655, %656, %cst_394) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %658 = qlx.apply #qlx.action<h>(%641#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %659 = qlx.apply #qlx.action<h>(%646#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_395 = arith.constant 1.5707963267948966 : f64
    %660:2 = qlx.apply #qlx.action<pauli_rotation>(%658, %659, %cst_395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_396 = arith.constant 1.5707963267948966 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%660#0, %cst_396) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %662 = qlx.apply #qlx.action<pauli_rotation>(%660#1, %cst_397) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %663:2 = qlx.apply #qlx.action<pauli_rotation>(%661, %662, %cst_398) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %664 = qlx.apply #qlx.action<h>(%646#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%651#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_399 = arith.constant 1.5707963267948966 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%664, %665, %cst_399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_400 = arith.constant 1.5707963267948966 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%666#0, %cst_400) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.5707963267948966 : f64
    %668 = qlx.apply #qlx.action<pauli_rotation>(%666#1, %cst_401) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %669:2 = qlx.apply #qlx.action<pauli_rotation>(%667, %668, %cst_402) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %670 = qlx.apply #qlx.action<h>(%657#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_403 = arith.constant 3.1415926535897931 : f64
    %671 = qlx.apply #qlx.action<pauli_rotation>(%670, %cst_403) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %672 = qlx.apply #qlx.action<h>(%671) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %673 = qlx.apply #qlx.action<h>(%663#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_404 = arith.constant 3.1415926535897931 : f64
    %674 = qlx.apply #qlx.action<pauli_rotation>(%673, %cst_404) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %675 = qlx.apply #qlx.action<h>(%674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_405 = arith.constant 1.5707963267948966 : f64
    %676:2 = qlx.apply #qlx.action<pauli_rotation>(%672, %675, %cst_405) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_406 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676#0, %cst_406) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %678 = qlx.apply #qlx.action<pauli_rotation>(%676#1, %cst_407) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %679:2 = qlx.apply #qlx.action<pauli_rotation>(%677, %678, %cst_408) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %680 = qlx.apply #qlx.action<h>(%663#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_409 = arith.constant 3.1415926535897931 : f64
    %681 = qlx.apply #qlx.action<pauli_rotation>(%680, %cst_409) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %682 = qlx.apply #qlx.action<h>(%681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %683 = qlx.apply #qlx.action<h>(%669#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_410 = arith.constant 3.1415926535897931 : f64
    %684 = qlx.apply #qlx.action<pauli_rotation>(%683, %cst_410) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %685 = qlx.apply #qlx.action<h>(%684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 1.5707963267948966 : f64
    %686:2 = qlx.apply #qlx.action<pauli_rotation>(%682, %685, %cst_411) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_412 = arith.constant 1.5707963267948966 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686#0, %cst_412) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %688 = qlx.apply #qlx.action<pauli_rotation>(%686#1, %cst_413) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %689:2 = qlx.apply #qlx.action<pauli_rotation>(%687, %688, %cst_414) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %690 = qlx.apply #qlx.action<h>(%679#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_415 = arith.constant 3.1415926535897931 : f64
    %691 = qlx.apply #qlx.action<pauli_rotation>(%690, %cst_415) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %692 = qlx.apply #qlx.action<h>(%691) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %693 = qlx.apply #qlx.action<h>(%689#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_416 = arith.constant 3.1415926535897931 : f64
    %694 = qlx.apply #qlx.action<pauli_rotation>(%693, %cst_416) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %695 = qlx.apply #qlx.action<h>(%694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %696:2 = qlx.apply #qlx.action<pauli_rotation>(%692, %695, %cst_417) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %697 = qlx.apply #qlx.action<pauli_rotation>(%696#0, %cst_418) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.5707963267948966 : f64
    %698 = qlx.apply #qlx.action<pauli_rotation>(%696#1, %cst_419) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %699:2 = qlx.apply #qlx.action<pauli_rotation>(%697, %698, %cst_420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_421 = arith.constant 0.78539816339744828 : f64
    %700 = qlx.apply #qlx.action<pauli_rotation>(%636#0, %cst_421) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %701 = qlx.apply #qlx.action<h>(%700) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %702 = qlx.apply #qlx.action<h>(%657#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 2.3561944901923448 : f64
    %703 = qlx.apply #qlx.action<pauli_rotation>(%702, %cst_422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %704 = qlx.apply #qlx.action<h>(%703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_423 = arith.constant 0.78539816339744828 : f64
    %705:2 = qlx.apply #qlx.action<pauli_rotation>(%701, %704, %cst_423) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705#0, %cst_424) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %707 = qlx.apply #qlx.action<pauli_rotation>(%705#1, %cst_425) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_426 = arith.constant 0.78539816339744828 : f64
    %708:2 = qlx.apply #qlx.action<pauli_rotation>(%706, %707, %cst_426) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %709 = qlx.apply #qlx.action<h>(%679#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 2.3561944901923448 : f64
    %710 = qlx.apply #qlx.action<pauli_rotation>(%709, %cst_427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %711 = qlx.apply #qlx.action<h>(%710) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%699#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_428 = arith.constant 2.3561944901923448 : f64
    %713 = qlx.apply #qlx.action<pauli_rotation>(%712, %cst_428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %714 = qlx.apply #qlx.action<h>(%713) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_429 = arith.constant 0.78539816339744828 : f64
    %715:2 = qlx.apply #qlx.action<pauli_rotation>(%711, %714, %cst_429) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_430 = arith.constant 1.5707963267948966 : f64
    %716 = qlx.apply #qlx.action<pauli_rotation>(%715#0, %cst_430) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_431 = arith.constant 1.5707963267948966 : f64
    %717 = qlx.apply #qlx.action<pauli_rotation>(%715#1, %cst_431) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_432 = arith.constant 0.78539816339744828 : f64
    %718:2 = qlx.apply #qlx.action<pauli_rotation>(%716, %717, %cst_432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %719 = qlx.apply #qlx.action<h>(%708#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_433 = arith.constant 2.3561944901923448 : f64
    %720 = qlx.apply #qlx.action<pauli_rotation>(%719, %cst_433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %721 = qlx.apply #qlx.action<h>(%720) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %722 = qlx.apply #qlx.action<h>(%718#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_434 = arith.constant 0.78539816339744828 : f64
    %723 = qlx.apply #qlx.action<pauli_rotation>(%722, %cst_434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %724 = qlx.apply #qlx.action<h>(%723) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_435 = arith.constant 5.000000e-01 : f64
    %725:2 = qlx.apply #qlx.action<pauli_rotation>(%721, %724, %cst_435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_436 = arith.constant 1.5707963267948966 : f64
    %726 = qlx.apply #qlx.action<pauli_rotation>(%725#0, %cst_436) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %727 = qlx.apply #qlx.action<pauli_rotation>(%725#1, %cst_437) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_438 = arith.constant 5.000000e-01 : f64
    %728:2 = qlx.apply #qlx.action<pauli_rotation>(%726, %727, %cst_438) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %729 = qlx.apply #qlx.action<h>(%708#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_439 = arith.constant 1.5707963267948966 : f64
    %730 = qlx.apply #qlx.action<pauli_rotation>(%729, %cst_439) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %731 = qlx.apply #qlx.action<h>(%730) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %732 = qlx.apply #qlx.action<h>(%728#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_440 = arith.constant 0.78539816339744828 : f64
    %733 = qlx.apply #qlx.action<pauli_rotation>(%732, %cst_440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %734 = qlx.apply #qlx.action<h>(%733) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 0.78539816339744828 : f64
    %735:2 = qlx.apply #qlx.action<pauli_rotation>(%731, %734, %cst_441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %736 = qlx.apply #qlx.action<pauli_rotation>(%735#0, %cst_442) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %737 = qlx.apply #qlx.action<pauli_rotation>(%735#1, %cst_443) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_444 = arith.constant 0.78539816339744828 : f64
    %738:2 = qlx.apply #qlx.action<pauli_rotation>(%736, %737, %cst_444) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %739 = qlx.apply #qlx.action<h>(%699#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_445 = arith.constant 2.3561944901923448 : f64
    %740 = qlx.apply #qlx.action<pauli_rotation>(%739, %cst_445) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %741 = qlx.apply #qlx.action<h>(%740) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%689#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_446 = arith.constant 2.3561944901923448 : f64
    %743 = qlx.apply #qlx.action<pauli_rotation>(%742, %cst_446) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %744 = qlx.apply #qlx.action<h>(%743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_447 = arith.constant 0.78539816339744828 : f64
    %745:2 = qlx.apply #qlx.action<pauli_rotation>(%741, %744, %cst_447) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_448 = arith.constant 1.5707963267948966 : f64
    %746 = qlx.apply #qlx.action<pauli_rotation>(%745#0, %cst_448) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %747 = qlx.apply #qlx.action<pauli_rotation>(%745#1, %cst_449) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_450 = arith.constant 0.78539816339744828 : f64
    %748:2 = qlx.apply #qlx.action<pauli_rotation>(%746, %747, %cst_450) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %749 = qlx.apply #qlx.action<h>(%669#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_451 = arith.constant 2.3561944901923448 : f64
    %750 = qlx.apply #qlx.action<pauli_rotation>(%749, %cst_451) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %751 = qlx.apply #qlx.action<h>(%750) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_452 = arith.constant 0.78539816339744828 : f64
    %752 = qlx.apply #qlx.action<pauli_rotation>(%651#1, %cst_452) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %753 = qlx.apply #qlx.action<h>(%752) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_453 = arith.constant 0.78539816339744828 : f64
    %754:2 = qlx.apply #qlx.action<pauli_rotation>(%751, %753, %cst_453) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %755 = qlx.apply #qlx.action<pauli_rotation>(%754#0, %cst_454) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %756 = qlx.apply #qlx.action<pauli_rotation>(%754#1, %cst_455) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_456 = arith.constant 0.78539816339744828 : f64
    %757:2 = qlx.apply #qlx.action<pauli_rotation>(%755, %756, %cst_456) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %758 = qlx.apply #qlx.action<h>(%748#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 2.3561944901923448 : f64
    %759 = qlx.apply #qlx.action<pauli_rotation>(%758, %cst_457) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %760 = qlx.apply #qlx.action<h>(%759) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %761 = qlx.apply #qlx.action<h>(%757#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_458 = arith.constant 0.78539816339744828 : f64
    %762 = qlx.apply #qlx.action<pauli_rotation>(%761, %cst_458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %763 = qlx.apply #qlx.action<h>(%762) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_459 = arith.constant 5.000000e-01 : f64
    %764:2 = qlx.apply #qlx.action<pauli_rotation>(%760, %763, %cst_459) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %765 = qlx.apply #qlx.action<pauli_rotation>(%764#0, %cst_460) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_461 = arith.constant 1.5707963267948966 : f64
    %766 = qlx.apply #qlx.action<pauli_rotation>(%764#1, %cst_461) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_462 = arith.constant 5.000000e-01 : f64
    %767:2 = qlx.apply #qlx.action<pauli_rotation>(%765, %766, %cst_462) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %768 = qlx.apply #qlx.action<h>(%748#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_463 = arith.constant 1.5707963267948966 : f64
    %769 = qlx.apply #qlx.action<pauli_rotation>(%768, %cst_463) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %770 = qlx.apply #qlx.action<h>(%769) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %771 = qlx.apply #qlx.action<h>(%767#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_464 = arith.constant 0.78539816339744828 : f64
    %772 = qlx.apply #qlx.action<pauli_rotation>(%771, %cst_464) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %773 = qlx.apply #qlx.action<h>(%772) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_465 = arith.constant 0.78539816339744828 : f64
    %774:2 = qlx.apply #qlx.action<pauli_rotation>(%770, %773, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_466 = arith.constant 1.5707963267948966 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%774#0, %cst_466) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_467 = arith.constant 1.5707963267948966 : f64
    %776 = qlx.apply #qlx.action<pauli_rotation>(%774#1, %cst_467) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_468 = arith.constant 0.78539816339744828 : f64
    %777:2 = qlx.apply #qlx.action<pauli_rotation>(%775, %776, %cst_468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %778 = qlx.apply #qlx.action<h>(%738#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_469 = arith.constant 2.3561944901923448 : f64
    %779 = qlx.apply #qlx.action<pauli_rotation>(%778, %cst_469) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %780 = qlx.apply #qlx.action<h>(%738#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_470 = arith.constant 2.3561944901923448 : f64
    %781 = qlx.apply #qlx.action<pauli_rotation>(%780, %cst_470) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %782 = qlx.apply #qlx.action<h>(%728#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_471 = arith.constant 3.1415926535897931 : f64
    %783 = qlx.apply #qlx.action<pauli_rotation>(%782, %cst_471) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %784 = qlx.apply #qlx.action<h>(%718#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 2.3561944901923448 : f64
    %785 = qlx.apply #qlx.action<pauli_rotation>(%784, %cst_472) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %786 = qlx.apply #qlx.action<h>(%777#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_473 = arith.constant 2.3561944901923448 : f64
    %787 = qlx.apply #qlx.action<pauli_rotation>(%786, %cst_473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %788 = qlx.apply #qlx.action<h>(%777#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_474 = arith.constant 2.3561944901923448 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%788, %cst_474) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %790 = qlx.apply #qlx.action<h>(%767#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_475 = arith.constant 3.1415926535897931 : f64
    %791 = qlx.apply #qlx.action<pauli_rotation>(%790, %cst_475) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %792 = qlx.apply #qlx.action<h>(%757#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_476 = arith.constant 2.3561944901923448 : f64
    %793 = qlx.apply #qlx.action<pauli_rotation>(%792, %cst_476) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %794 = qlx.measure <Z> %779 : !qlx.logical_qubit -> i1
    %795 = qlx.measure <Z> %781 : !qlx.logical_qubit -> i1
    %796 = qlx.measure <Z> %783 : !qlx.logical_qubit -> i1
    %797 = qlx.measure <Z> %785 : !qlx.logical_qubit -> i1
    %798 = qlx.measure <Z> %787 : !qlx.logical_qubit -> i1
    %799 = qlx.measure <Z> %789 : !qlx.logical_qubit -> i1
    %800 = qlx.measure <Z> %791 : !qlx.logical_qubit -> i1
    %801 = qlx.measure <Z> %793 : !qlx.logical_qubit -> i1
  }
}
