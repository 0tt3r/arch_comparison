module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<h>(%1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.apply #qlx.action<x>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %10 = qlx.apply #qlx.action<h>(%9) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 1.5707963267948966 : f64
    %11:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %10, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %12 = qlx.apply #qlx.action<pauli_rotation>(%11#0, %cst_0) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %13 = qlx.apply #qlx.action<pauli_rotation>(%11#1, %cst_1) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %14:2 = qlx.apply #qlx.action<pauli_rotation>(%12, %13, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %15 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %16 = qlx.apply #qlx.action<pauli_rotation>(%15, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %17 = qlx.apply #qlx.action<h>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %18 = qlx.apply #qlx.action<h>(%14#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_4 = arith.constant 2.3561944901923448 : f64
    %19 = qlx.apply #qlx.action<pauli_rotation>(%18, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %20 = qlx.apply #qlx.action<h>(%19) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %21:2 = qlx.apply #qlx.action<pauli_rotation>(%17, %20, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %22 = qlx.apply #qlx.action<pauli_rotation>(%21#0, %cst_6) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %23 = qlx.apply #qlx.action<pauli_rotation>(%21#1, %cst_7) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_8 = arith.constant 0.78539816339744828 : f64
    %24:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %23, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %25 = qlx.apply #qlx.action<h>(%14#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_9 = arith.constant 2.3561944901923448 : f64
    %26 = qlx.apply #qlx.action<pauli_rotation>(%25, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %27 = qlx.apply #qlx.action<h>(%26) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 0.78539816339744828 : f64
    %28 = qlx.apply #qlx.action<pauli_rotation>(%3, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %29 = qlx.apply #qlx.action<h>(%28) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %30:2 = qlx.apply #qlx.action<pauli_rotation>(%27, %29, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %31 = qlx.apply #qlx.action<pauli_rotation>(%30#0, %cst_12) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %32 = qlx.apply #qlx.action<pauli_rotation>(%30#1, %cst_13) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %33:2 = qlx.apply #qlx.action<pauli_rotation>(%31, %32, %cst_14) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %34 = qlx.apply #qlx.action<h>(%24#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_15 = arith.constant 2.3561944901923448 : f64
    %35 = qlx.apply #qlx.action<pauli_rotation>(%34, %cst_15) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %36 = qlx.apply #qlx.action<h>(%35) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %37 = qlx.apply #qlx.action<h>(%33#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_16 = arith.constant 0.78539816339744828 : f64
    %38 = qlx.apply #qlx.action<pauli_rotation>(%37, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %39 = qlx.apply #qlx.action<h>(%38) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_17 = arith.constant 1.250000e-01 : f64
    %40:2 = qlx.apply #qlx.action<pauli_rotation>(%36, %39, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %41 = qlx.apply #qlx.action<pauli_rotation>(%40#0, %cst_18) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %42 = qlx.apply #qlx.action<pauli_rotation>(%40#1, %cst_19) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_20 = arith.constant 1.250000e-01 : f64
    %43:2 = qlx.apply #qlx.action<pauli_rotation>(%41, %42, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44 = qlx.apply #qlx.action<h>(%24#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %45 = qlx.apply #qlx.action<pauli_rotation>(%44, %cst_21) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %46 = qlx.apply #qlx.action<h>(%45) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %47 = qlx.apply #qlx.action<h>(%43#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%47, %cst_22) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %49 = qlx.apply #qlx.action<h>(%48) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 0.78539816339744828 : f64
    %50:2 = qlx.apply #qlx.action<pauli_rotation>(%46, %49, %cst_23) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%50#0, %cst_24) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %52 = qlx.apply #qlx.action<pauli_rotation>(%50#1, %cst_25) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_26 = arith.constant 0.78539816339744828 : f64
    %53:2 = qlx.apply #qlx.action<pauli_rotation>(%51, %52, %cst_26) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %54 = qlx.apply #qlx.action<h>(%43#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 2.3561944901923448 : f64
    %55 = qlx.apply #qlx.action<pauli_rotation>(%54, %cst_27) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %56 = qlx.apply #qlx.action<h>(%55) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %57 = qlx.apply #qlx.action<h>(%33#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%57, %cst_28) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %59 = qlx.apply #qlx.action<h>(%58) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_29 = arith.constant 0.78539816339744828 : f64
    %60:2 = qlx.apply #qlx.action<pauli_rotation>(%56, %59, %cst_29) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%60#0, %cst_30) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_31 = arith.constant 1.5707963267948966 : f64
    %62 = qlx.apply #qlx.action<pauli_rotation>(%60#1, %cst_31) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_32 = arith.constant 0.78539816339744828 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%61, %62, %cst_32) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<x>(%5) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %65 = qlx.apply #qlx.action<h>(%64) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<h>(%6) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %67:2 = qlx.apply #qlx.action<pauli_rotation>(%65, %66, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 1.5707963267948966 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%67#0, %cst_34) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %69 = qlx.apply #qlx.action<pauli_rotation>(%67#1, %cst_35) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %70:2 = qlx.apply #qlx.action<pauli_rotation>(%68, %69, %cst_36) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_37 = arith.constant 0.78539816339744828 : f64
    %71 = qlx.apply #qlx.action<pauli_rotation>(%4, %cst_37) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %72 = qlx.apply #qlx.action<h>(%71) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<h>(%70#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_38 = arith.constant 2.3561944901923448 : f64
    %74 = qlx.apply #qlx.action<pauli_rotation>(%73, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %75 = qlx.apply #qlx.action<h>(%74) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 0.78539816339744828 : f64
    %76:2 = qlx.apply #qlx.action<pauli_rotation>(%72, %75, %cst_39) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %77 = qlx.apply #qlx.action<pauli_rotation>(%76#0, %cst_40) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %78 = qlx.apply #qlx.action<pauli_rotation>(%76#1, %cst_41) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_42 = arith.constant 0.78539816339744828 : f64
    %79:2 = qlx.apply #qlx.action<pauli_rotation>(%77, %78, %cst_42) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %80 = qlx.apply #qlx.action<h>(%70#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_43 = arith.constant 2.3561944901923448 : f64
    %81 = qlx.apply #qlx.action<pauli_rotation>(%80, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %82 = qlx.apply #qlx.action<h>(%81) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %83 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_44 = arith.constant 0.78539816339744828 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%83, %cst_44) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %85 = qlx.apply #qlx.action<h>(%84) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 0.78539816339744828 : f64
    %86:2 = qlx.apply #qlx.action<pauli_rotation>(%82, %85, %cst_45) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %87 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %cst_46) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_47 = arith.constant 1.5707963267948966 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%86#1, %cst_47) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_48 = arith.constant 0.78539816339744828 : f64
    %89:2 = qlx.apply #qlx.action<pauli_rotation>(%87, %88, %cst_48) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %90 = qlx.apply #qlx.action<h>(%79#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_49 = arith.constant 2.3561944901923448 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%90, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %92 = qlx.apply #qlx.action<h>(%91) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %93 = qlx.apply #qlx.action<h>(%89#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_50 = arith.constant 0.78539816339744828 : f64
    %94 = qlx.apply #qlx.action<pauli_rotation>(%93, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %95 = qlx.apply #qlx.action<h>(%94) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_51 = arith.constant 1.250000e-01 : f64
    %96:2 = qlx.apply #qlx.action<pauli_rotation>(%92, %95, %cst_51) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %97 = qlx.apply #qlx.action<pauli_rotation>(%96#0, %cst_52) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %98 = qlx.apply #qlx.action<pauli_rotation>(%96#1, %cst_53) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_54 = arith.constant 1.250000e-01 : f64
    %99:2 = qlx.apply #qlx.action<pauli_rotation>(%97, %98, %cst_54) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %100 = qlx.apply #qlx.action<h>(%79#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %101 = qlx.apply #qlx.action<pauli_rotation>(%100, %cst_55) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %102 = qlx.apply #qlx.action<h>(%101) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %103 = qlx.apply #qlx.action<h>(%99#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_56 = arith.constant 0.78539816339744828 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%103, %cst_56) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %105 = qlx.apply #qlx.action<h>(%104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_57 = arith.constant 0.78539816339744828 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%102, %105, %cst_57) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %107 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %cst_58) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%106#1, %cst_59) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_60 = arith.constant 0.78539816339744828 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%107, %108, %cst_60) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %110 = qlx.apply #qlx.action<h>(%99#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_61 = arith.constant 2.3561944901923448 : f64
    %111 = qlx.apply #qlx.action<pauli_rotation>(%110, %cst_61) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %112 = qlx.apply #qlx.action<h>(%111) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %113 = qlx.apply #qlx.action<h>(%89#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113, %cst_62) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %115 = qlx.apply #qlx.action<h>(%114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_63 = arith.constant 0.78539816339744828 : f64
    %116:2 = qlx.apply #qlx.action<pauli_rotation>(%112, %115, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 1.5707963267948966 : f64
    %117 = qlx.apply #qlx.action<pauli_rotation>(%116#0, %cst_64) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %118 = qlx.apply #qlx.action<pauli_rotation>(%116#1, %cst_65) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_66 = arith.constant 0.78539816339744828 : f64
    %119:2 = qlx.apply #qlx.action<pauli_rotation>(%117, %118, %cst_66) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %120 = qlx.apply #qlx.action<h>(%63#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_67 = arith.constant 2.3561944901923448 : f64
    %121 = qlx.apply #qlx.action<pauli_rotation>(%120, %cst_67) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %122 = qlx.apply #qlx.action<h>(%121) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %123 = qlx.apply #qlx.action<h>(%109#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_68 = arith.constant 2.3561944901923448 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%123, %cst_68) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %125 = qlx.apply #qlx.action<h>(%124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %126:2 = qlx.apply #qlx.action<pauli_rotation>(%122, %125, %cst_69) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_70 = arith.constant 1.5707963267948966 : f64
    %127 = qlx.apply #qlx.action<pauli_rotation>(%126#0, %cst_70) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_71 = arith.constant 1.5707963267948966 : f64
    %128 = qlx.apply #qlx.action<pauli_rotation>(%126#1, %cst_71) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %129:2 = qlx.apply #qlx.action<pauli_rotation>(%127, %128, %cst_72) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %130 = qlx.apply #qlx.action<h>(%63#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_73 = arith.constant 2.3561944901923448 : f64
    %131 = qlx.apply #qlx.action<pauli_rotation>(%130, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %132 = qlx.apply #qlx.action<h>(%131) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %133 = qlx.apply #qlx.action<h>(%129#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_74 = arith.constant 3.1415926535897931 : f64
    %134 = qlx.apply #qlx.action<pauli_rotation>(%133, %cst_74) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<h>(%134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %136:2 = qlx.apply #qlx.action<pauli_rotation>(%132, %135, %cst_75) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %137 = qlx.apply #qlx.action<pauli_rotation>(%136#0, %cst_76) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_77 = arith.constant 1.5707963267948966 : f64
    %138 = qlx.apply #qlx.action<pauli_rotation>(%136#1, %cst_77) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %139:2 = qlx.apply #qlx.action<pauli_rotation>(%137, %138, %cst_78) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %140 = qlx.apply #qlx.action<h>(%129#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 3.1415926535897931 : f64
    %141 = qlx.apply #qlx.action<pauli_rotation>(%140, %cst_79) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %142 = qlx.apply #qlx.action<h>(%141) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %143 = qlx.apply #qlx.action<h>(%109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_80 = arith.constant 2.3561944901923448 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_80) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %146:2 = qlx.apply #qlx.action<pauli_rotation>(%142, %145, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.5707963267948966 : f64
    %147 = qlx.apply #qlx.action<pauli_rotation>(%146#0, %cst_82) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %148 = qlx.apply #qlx.action<pauli_rotation>(%146#1, %cst_83) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %149:2 = qlx.apply #qlx.action<pauli_rotation>(%147, %148, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %150 = qlx.apply #qlx.action<h>(%53#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 2.3561944901923448 : f64
    %151 = qlx.apply #qlx.action<pauli_rotation>(%150, %cst_85) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %152 = qlx.apply #qlx.action<h>(%151) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %153 = qlx.apply #qlx.action<h>(%139#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_86 = arith.constant 3.1415926535897931 : f64
    %154 = qlx.apply #qlx.action<pauli_rotation>(%153, %cst_86) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %155 = qlx.apply #qlx.action<h>(%154) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %156:2 = qlx.apply #qlx.action<pauli_rotation>(%152, %155, %cst_87) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.5707963267948966 : f64
    %157 = qlx.apply #qlx.action<pauli_rotation>(%156#0, %cst_88) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %158 = qlx.apply #qlx.action<pauli_rotation>(%156#1, %cst_89) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %159:2 = qlx.apply #qlx.action<pauli_rotation>(%157, %158, %cst_90) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %160 = qlx.apply #qlx.action<h>(%139#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_91 = arith.constant 3.1415926535897931 : f64
    %161 = qlx.apply #qlx.action<pauli_rotation>(%160, %cst_91) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %162 = qlx.apply #qlx.action<h>(%161) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %163 = qlx.apply #qlx.action<h>(%149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_92 = arith.constant 3.1415926535897931 : f64
    %164 = qlx.apply #qlx.action<pauli_rotation>(%163, %cst_92) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %165 = qlx.apply #qlx.action<h>(%164) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %166:2 = qlx.apply #qlx.action<pauli_rotation>(%162, %165, %cst_93) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 1.5707963267948966 : f64
    %167 = qlx.apply #qlx.action<pauli_rotation>(%166#0, %cst_94) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %168 = qlx.apply #qlx.action<pauli_rotation>(%166#1, %cst_95) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %169:2 = qlx.apply #qlx.action<pauli_rotation>(%167, %168, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %170 = qlx.apply #qlx.action<h>(%149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_97 = arith.constant 3.1415926535897931 : f64
    %171 = qlx.apply #qlx.action<pauli_rotation>(%170, %cst_97) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %172 = qlx.apply #qlx.action<h>(%171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %173 = qlx.apply #qlx.action<h>(%119#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_98 = arith.constant 2.3561944901923448 : f64
    %174 = qlx.apply #qlx.action<pauli_rotation>(%173, %cst_98) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %175 = qlx.apply #qlx.action<h>(%174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %176:2 = qlx.apply #qlx.action<pauli_rotation>(%172, %175, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %177 = qlx.apply #qlx.action<pauli_rotation>(%176#0, %cst_100) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_101 = arith.constant 1.5707963267948966 : f64
    %178 = qlx.apply #qlx.action<pauli_rotation>(%176#1, %cst_101) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%177, %178, %cst_102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %180 = qlx.apply #qlx.action<h>(%53#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_103 = arith.constant 2.3561944901923448 : f64
    %181 = qlx.apply #qlx.action<pauli_rotation>(%180, %cst_103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %182 = qlx.apply #qlx.action<h>(%159#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_104 = arith.constant 3.1415926535897931 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%182, %cst_104) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_105 = arith.constant 1.250000e-01 : f64
    %184:2 = qlx.apply #qlx.action<pauli_rotation>(%181, %183, %cst_105) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %185 = qlx.apply #qlx.action<h>(%159#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_106 = arith.constant 3.1415926535897931 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%185, %cst_106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %187 = qlx.apply #qlx.action<h>(%169#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_107 = arith.constant 3.1415926535897931 : f64
    %188 = qlx.apply #qlx.action<pauli_rotation>(%187, %cst_107) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_108 = arith.constant 1.250000e-01 : f64
    %189:2 = qlx.apply #qlx.action<pauli_rotation>(%186, %188, %cst_108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %190 = qlx.apply #qlx.action<h>(%169#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_109 = arith.constant 3.1415926535897931 : f64
    %191 = qlx.apply #qlx.action<pauli_rotation>(%190, %cst_109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %192 = qlx.apply #qlx.action<h>(%179#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_110 = arith.constant 3.1415926535897931 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%192, %cst_110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_111 = arith.constant 1.250000e-01 : f64
    %194:2 = qlx.apply #qlx.action<pauli_rotation>(%191, %193, %cst_111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %195 = qlx.apply #qlx.action<h>(%179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 3.1415926535897931 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%195, %cst_112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<h>(%119#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_113 = arith.constant 2.3561944901923448 : f64
    %198 = qlx.apply #qlx.action<pauli_rotation>(%197, %cst_113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 1.250000e-01 : f64
    %199:2 = qlx.apply #qlx.action<pauli_rotation>(%196, %198, %cst_114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %200 = qlx.apply #qlx.action<h>(%184#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %201 = qlx.apply #qlx.action<h>(%189#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_115 = arith.constant 1.5707963267948966 : f64
    %202:2 = qlx.apply #qlx.action<pauli_rotation>(%200, %201, %cst_115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%202#0, %cst_116) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %204 = qlx.apply #qlx.action<pauli_rotation>(%202#1, %cst_117) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %205:2 = qlx.apply #qlx.action<pauli_rotation>(%203, %204, %cst_118) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %206 = qlx.apply #qlx.action<h>(%189#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%194#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %208:2 = qlx.apply #qlx.action<pauli_rotation>(%206, %207, %cst_119) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %209 = qlx.apply #qlx.action<pauli_rotation>(%208#0, %cst_120) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %210 = qlx.apply #qlx.action<pauli_rotation>(%208#1, %cst_121) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%209, %210, %cst_122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %212 = qlx.apply #qlx.action<h>(%194#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %213 = qlx.apply #qlx.action<h>(%199#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %214:2 = qlx.apply #qlx.action<pauli_rotation>(%212, %213, %cst_123) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %215 = qlx.apply #qlx.action<pauli_rotation>(%214#0, %cst_124) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 1.5707963267948966 : f64
    %216 = qlx.apply #qlx.action<pauli_rotation>(%214#1, %cst_125) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_126 = arith.constant 1.5707963267948966 : f64
    %217:2 = qlx.apply #qlx.action<pauli_rotation>(%215, %216, %cst_126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %218 = qlx.apply #qlx.action<h>(%205#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 3.1415926535897931 : f64
    %219 = qlx.apply #qlx.action<pauli_rotation>(%218, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<h>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %221 = qlx.apply #qlx.action<h>(%211#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_128 = arith.constant 3.1415926535897931 : f64
    %222 = qlx.apply #qlx.action<pauli_rotation>(%221, %cst_128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %223 = qlx.apply #qlx.action<h>(%222) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %224:2 = qlx.apply #qlx.action<pauli_rotation>(%220, %223, %cst_129) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %225 = qlx.apply #qlx.action<pauli_rotation>(%224#0, %cst_130) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 1.5707963267948966 : f64
    %226 = qlx.apply #qlx.action<pauli_rotation>(%224#1, %cst_131) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %227:2 = qlx.apply #qlx.action<pauli_rotation>(%225, %226, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %228 = qlx.apply #qlx.action<h>(%211#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_133 = arith.constant 3.1415926535897931 : f64
    %229 = qlx.apply #qlx.action<pauli_rotation>(%228, %cst_133) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %230 = qlx.apply #qlx.action<h>(%229) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %231 = qlx.apply #qlx.action<h>(%217#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_134 = arith.constant 3.1415926535897931 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231, %cst_134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<h>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %234:2 = qlx.apply #qlx.action<pauli_rotation>(%230, %233, %cst_135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %235 = qlx.apply #qlx.action<pauli_rotation>(%234#0, %cst_136) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %236 = qlx.apply #qlx.action<pauli_rotation>(%234#1, %cst_137) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_138 = arith.constant 1.5707963267948966 : f64
    %237:2 = qlx.apply #qlx.action<pauli_rotation>(%235, %236, %cst_138) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %238 = qlx.apply #qlx.action<h>(%227#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_139 = arith.constant 3.1415926535897931 : f64
    %239 = qlx.apply #qlx.action<pauli_rotation>(%238, %cst_139) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %240 = qlx.apply #qlx.action<h>(%239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %241 = qlx.apply #qlx.action<h>(%237#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_140 = arith.constant 3.1415926535897931 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%241, %cst_140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %243 = qlx.apply #qlx.action<h>(%242) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %244:2 = qlx.apply #qlx.action<pauli_rotation>(%240, %243, %cst_141) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 1.5707963267948966 : f64
    %245 = qlx.apply #qlx.action<pauli_rotation>(%244#0, %cst_142) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%244#1, %cst_143) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %247:2 = qlx.apply #qlx.action<pauli_rotation>(%245, %246, %cst_144) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_145 = arith.constant 0.78539816339744828 : f64
    %248 = qlx.apply #qlx.action<pauli_rotation>(%184#0, %cst_145) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %249 = qlx.apply #qlx.action<h>(%248) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %250 = qlx.apply #qlx.action<h>(%205#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_146 = arith.constant 2.3561944901923448 : f64
    %251 = qlx.apply #qlx.action<pauli_rotation>(%250, %cst_146) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %252 = qlx.apply #qlx.action<h>(%251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_147 = arith.constant 0.78539816339744828 : f64
    %253:2 = qlx.apply #qlx.action<pauli_rotation>(%249, %252, %cst_147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %254 = qlx.apply #qlx.action<pauli_rotation>(%253#0, %cst_148) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_149 = arith.constant 1.5707963267948966 : f64
    %255 = qlx.apply #qlx.action<pauli_rotation>(%253#1, %cst_149) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_150 = arith.constant 0.78539816339744828 : f64
    %256:2 = qlx.apply #qlx.action<pauli_rotation>(%254, %255, %cst_150) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<h>(%227#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_151 = arith.constant 2.3561944901923448 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%257, %cst_151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<h>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%247#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_152 = arith.constant 2.3561944901923448 : f64
    %261 = qlx.apply #qlx.action<pauli_rotation>(%260, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %262 = qlx.apply #qlx.action<h>(%261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_153 = arith.constant 0.78539816339744828 : f64
    %263:2 = qlx.apply #qlx.action<pauli_rotation>(%259, %262, %cst_153) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %264 = qlx.apply #qlx.action<pauli_rotation>(%263#0, %cst_154) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %265 = qlx.apply #qlx.action<pauli_rotation>(%263#1, %cst_155) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_156 = arith.constant 0.78539816339744828 : f64
    %266:2 = qlx.apply #qlx.action<pauli_rotation>(%264, %265, %cst_156) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %267 = qlx.apply #qlx.action<h>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_157 = arith.constant 2.3561944901923448 : f64
    %268 = qlx.apply #qlx.action<pauli_rotation>(%267, %cst_157) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %269 = qlx.apply #qlx.action<h>(%268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %270 = qlx.apply #qlx.action<h>(%266#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_158 = arith.constant 0.78539816339744828 : f64
    %271 = qlx.apply #qlx.action<pauli_rotation>(%270, %cst_158) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %272 = qlx.apply #qlx.action<h>(%271) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_159 = arith.constant 1.250000e-01 : f64
    %273:2 = qlx.apply #qlx.action<pauli_rotation>(%269, %272, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %274 = qlx.apply #qlx.action<pauli_rotation>(%273#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.5707963267948966 : f64
    %275 = qlx.apply #qlx.action<pauli_rotation>(%273#1, %cst_161) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 1.250000e-01 : f64
    %276:2 = qlx.apply #qlx.action<pauli_rotation>(%274, %275, %cst_162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %277 = qlx.apply #qlx.action<h>(%256#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 1.5707963267948966 : f64
    %278 = qlx.apply #qlx.action<pauli_rotation>(%277, %cst_163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %279 = qlx.apply #qlx.action<h>(%278) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %280 = qlx.apply #qlx.action<h>(%276#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_164 = arith.constant 0.78539816339744828 : f64
    %281 = qlx.apply #qlx.action<pauli_rotation>(%280, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %282 = qlx.apply #qlx.action<h>(%281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 0.78539816339744828 : f64
    %283:2 = qlx.apply #qlx.action<pauli_rotation>(%279, %282, %cst_165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %284 = qlx.apply #qlx.action<pauli_rotation>(%283#0, %cst_166) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %285 = qlx.apply #qlx.action<pauli_rotation>(%283#1, %cst_167) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_168 = arith.constant 0.78539816339744828 : f64
    %286:2 = qlx.apply #qlx.action<pauli_rotation>(%284, %285, %cst_168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %287 = qlx.apply #qlx.action<h>(%276#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 2.3561944901923448 : f64
    %288 = qlx.apply #qlx.action<pauli_rotation>(%287, %cst_169) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %289 = qlx.apply #qlx.action<h>(%288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %290 = qlx.apply #qlx.action<h>(%266#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_170 = arith.constant 1.5707963267948966 : f64
    %291 = qlx.apply #qlx.action<pauli_rotation>(%290, %cst_170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %292 = qlx.apply #qlx.action<h>(%291) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_171 = arith.constant 0.78539816339744828 : f64
    %293:2 = qlx.apply #qlx.action<pauli_rotation>(%289, %292, %cst_171) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %294 = qlx.apply #qlx.action<pauli_rotation>(%293#0, %cst_172) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_173 = arith.constant 1.5707963267948966 : f64
    %295 = qlx.apply #qlx.action<pauli_rotation>(%293#1, %cst_173) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_174 = arith.constant 0.78539816339744828 : f64
    %296:2 = qlx.apply #qlx.action<pauli_rotation>(%294, %295, %cst_174) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %297 = qlx.apply #qlx.action<h>(%247#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 2.3561944901923448 : f64
    %298 = qlx.apply #qlx.action<pauli_rotation>(%297, %cst_175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %299 = qlx.apply #qlx.action<h>(%298) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %300 = qlx.apply #qlx.action<h>(%237#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_176 = arith.constant 2.3561944901923448 : f64
    %301 = qlx.apply #qlx.action<pauli_rotation>(%300, %cst_176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %302 = qlx.apply #qlx.action<h>(%301) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_177 = arith.constant 0.78539816339744828 : f64
    %303:2 = qlx.apply #qlx.action<pauli_rotation>(%299, %302, %cst_177) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %304 = qlx.apply #qlx.action<pauli_rotation>(%303#0, %cst_178) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_179 = arith.constant 1.5707963267948966 : f64
    %305 = qlx.apply #qlx.action<pauli_rotation>(%303#1, %cst_179) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_180 = arith.constant 0.78539816339744828 : f64
    %306:2 = qlx.apply #qlx.action<pauli_rotation>(%304, %305, %cst_180) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %307 = qlx.apply #qlx.action<h>(%217#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_181 = arith.constant 2.3561944901923448 : f64
    %308 = qlx.apply #qlx.action<pauli_rotation>(%307, %cst_181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %309 = qlx.apply #qlx.action<h>(%308) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_182 = arith.constant 0.78539816339744828 : f64
    %310 = qlx.apply #qlx.action<pauli_rotation>(%199#1, %cst_182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %311 = qlx.apply #qlx.action<h>(%310) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_183 = arith.constant 0.78539816339744828 : f64
    %312:2 = qlx.apply #qlx.action<pauli_rotation>(%309, %311, %cst_183) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %313 = qlx.apply #qlx.action<pauli_rotation>(%312#0, %cst_184) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.5707963267948966 : f64
    %314 = qlx.apply #qlx.action<pauli_rotation>(%312#1, %cst_185) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_186 = arith.constant 0.78539816339744828 : f64
    %315:2 = qlx.apply #qlx.action<pauli_rotation>(%313, %314, %cst_186) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %316 = qlx.apply #qlx.action<h>(%306#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_187 = arith.constant 2.3561944901923448 : f64
    %317 = qlx.apply #qlx.action<pauli_rotation>(%316, %cst_187) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %318 = qlx.apply #qlx.action<h>(%317) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %319 = qlx.apply #qlx.action<h>(%315#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_188 = arith.constant 0.78539816339744828 : f64
    %320 = qlx.apply #qlx.action<pauli_rotation>(%319, %cst_188) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %321 = qlx.apply #qlx.action<h>(%320) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_189 = arith.constant 1.250000e-01 : f64
    %322:2 = qlx.apply #qlx.action<pauli_rotation>(%318, %321, %cst_189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %323 = qlx.apply #qlx.action<pauli_rotation>(%322#0, %cst_190) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_191 = arith.constant 1.5707963267948966 : f64
    %324 = qlx.apply #qlx.action<pauli_rotation>(%322#1, %cst_191) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_192 = arith.constant 1.250000e-01 : f64
    %325:2 = qlx.apply #qlx.action<pauli_rotation>(%323, %324, %cst_192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %326 = qlx.apply #qlx.action<h>(%306#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %327 = qlx.apply #qlx.action<pauli_rotation>(%326, %cst_193) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %328 = qlx.apply #qlx.action<h>(%327) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %329 = qlx.apply #qlx.action<h>(%325#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_194 = arith.constant 0.78539816339744828 : f64
    %330 = qlx.apply #qlx.action<pauli_rotation>(%329, %cst_194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %331 = qlx.apply #qlx.action<h>(%330) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_195 = arith.constant 0.78539816339744828 : f64
    %332:2 = qlx.apply #qlx.action<pauli_rotation>(%328, %331, %cst_195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %333 = qlx.apply #qlx.action<pauli_rotation>(%332#0, %cst_196) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.5707963267948966 : f64
    %334 = qlx.apply #qlx.action<pauli_rotation>(%332#1, %cst_197) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_198 = arith.constant 0.78539816339744828 : f64
    %335:2 = qlx.apply #qlx.action<pauli_rotation>(%333, %334, %cst_198) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %336 = qlx.apply #qlx.action<h>(%325#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_199 = arith.constant 2.3561944901923448 : f64
    %337 = qlx.apply #qlx.action<pauli_rotation>(%336, %cst_199) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %338 = qlx.apply #qlx.action<h>(%337) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %339 = qlx.apply #qlx.action<h>(%315#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_200 = arith.constant 1.5707963267948966 : f64
    %340 = qlx.apply #qlx.action<pauli_rotation>(%339, %cst_200) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %341 = qlx.apply #qlx.action<h>(%340) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 0.78539816339744828 : f64
    %342:2 = qlx.apply #qlx.action<pauli_rotation>(%338, %341, %cst_201) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_202 = arith.constant 1.5707963267948966 : f64
    %343 = qlx.apply #qlx.action<pauli_rotation>(%342#0, %cst_202) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %344 = qlx.apply #qlx.action<pauli_rotation>(%342#1, %cst_203) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_204 = arith.constant 0.78539816339744828 : f64
    %345:2 = qlx.apply #qlx.action<pauli_rotation>(%343, %344, %cst_204) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %346 = qlx.apply #qlx.action<h>(%296#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_205 = arith.constant 2.3561944901923448 : f64
    %347 = qlx.apply #qlx.action<pauli_rotation>(%346, %cst_205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %348 = qlx.apply #qlx.action<h>(%347) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %349 = qlx.apply #qlx.action<h>(%335#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_206 = arith.constant 2.3561944901923448 : f64
    %350 = qlx.apply #qlx.action<pauli_rotation>(%349, %cst_206) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %351 = qlx.apply #qlx.action<h>(%350) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %352:2 = qlx.apply #qlx.action<pauli_rotation>(%348, %351, %cst_207) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %353 = qlx.apply #qlx.action<pauli_rotation>(%352#0, %cst_208) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %354 = qlx.apply #qlx.action<pauli_rotation>(%352#1, %cst_209) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %355:2 = qlx.apply #qlx.action<pauli_rotation>(%353, %354, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %356 = qlx.apply #qlx.action<h>(%296#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_211 = arith.constant 2.3561944901923448 : f64
    %357 = qlx.apply #qlx.action<pauli_rotation>(%356, %cst_211) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %358 = qlx.apply #qlx.action<h>(%357) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %359 = qlx.apply #qlx.action<h>(%355#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 3.1415926535897931 : f64
    %360 = qlx.apply #qlx.action<pauli_rotation>(%359, %cst_212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %361 = qlx.apply #qlx.action<h>(%360) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 1.5707963267948966 : f64
    %362:2 = qlx.apply #qlx.action<pauli_rotation>(%358, %361, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %363 = qlx.apply #qlx.action<pauli_rotation>(%362#0, %cst_214) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %364 = qlx.apply #qlx.action<pauli_rotation>(%362#1, %cst_215) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %365:2 = qlx.apply #qlx.action<pauli_rotation>(%363, %364, %cst_216) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %366 = qlx.apply #qlx.action<h>(%355#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_217 = arith.constant 3.1415926535897931 : f64
    %367 = qlx.apply #qlx.action<pauli_rotation>(%366, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %368 = qlx.apply #qlx.action<h>(%367) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %369 = qlx.apply #qlx.action<h>(%335#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_218 = arith.constant 2.3561944901923448 : f64
    %370 = qlx.apply #qlx.action<pauli_rotation>(%369, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %371 = qlx.apply #qlx.action<h>(%370) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_219 = arith.constant 1.5707963267948966 : f64
    %372:2 = qlx.apply #qlx.action<pauli_rotation>(%368, %371, %cst_219) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %373 = qlx.apply #qlx.action<pauli_rotation>(%372#0, %cst_220) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_221 = arith.constant 1.5707963267948966 : f64
    %374 = qlx.apply #qlx.action<pauli_rotation>(%372#1, %cst_221) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_222 = arith.constant 1.5707963267948966 : f64
    %375:2 = qlx.apply #qlx.action<pauli_rotation>(%373, %374, %cst_222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %376 = qlx.apply #qlx.action<h>(%286#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_223 = arith.constant 2.3561944901923448 : f64
    %377 = qlx.apply #qlx.action<pauli_rotation>(%376, %cst_223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %378 = qlx.apply #qlx.action<h>(%377) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %379 = qlx.apply #qlx.action<h>(%365#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_224 = arith.constant 3.1415926535897931 : f64
    %380 = qlx.apply #qlx.action<pauli_rotation>(%379, %cst_224) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %381 = qlx.apply #qlx.action<h>(%380) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_225 = arith.constant 1.5707963267948966 : f64
    %382:2 = qlx.apply #qlx.action<pauli_rotation>(%378, %381, %cst_225) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %383 = qlx.apply #qlx.action<pauli_rotation>(%382#0, %cst_226) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_227 = arith.constant 1.5707963267948966 : f64
    %384 = qlx.apply #qlx.action<pauli_rotation>(%382#1, %cst_227) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_228 = arith.constant 1.5707963267948966 : f64
    %385:2 = qlx.apply #qlx.action<pauli_rotation>(%383, %384, %cst_228) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %386 = qlx.apply #qlx.action<h>(%365#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_229 = arith.constant 3.1415926535897931 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%386, %cst_229) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %388 = qlx.apply #qlx.action<h>(%387) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %389 = qlx.apply #qlx.action<h>(%375#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_230 = arith.constant 3.1415926535897931 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%389, %cst_230) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %392:2 = qlx.apply #qlx.action<pauli_rotation>(%388, %391, %cst_231) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_232 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %cst_232) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_233 = arith.constant 1.5707963267948966 : f64
    %394 = qlx.apply #qlx.action<pauli_rotation>(%392#1, %cst_233) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_234 = arith.constant 1.5707963267948966 : f64
    %395:2 = qlx.apply #qlx.action<pauli_rotation>(%393, %394, %cst_234) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %396 = qlx.apply #qlx.action<h>(%375#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_235 = arith.constant 3.1415926535897931 : f64
    %397 = qlx.apply #qlx.action<pauli_rotation>(%396, %cst_235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %398 = qlx.apply #qlx.action<h>(%397) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %399 = qlx.apply #qlx.action<h>(%345#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 2.3561944901923448 : f64
    %400 = qlx.apply #qlx.action<pauli_rotation>(%399, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %401 = qlx.apply #qlx.action<h>(%400) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_237 = arith.constant 1.5707963267948966 : f64
    %402:2 = qlx.apply #qlx.action<pauli_rotation>(%398, %401, %cst_237) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_238 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%402#0, %cst_238) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %404 = qlx.apply #qlx.action<pauli_rotation>(%402#1, %cst_239) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_240 = arith.constant 1.5707963267948966 : f64
    %405:2 = qlx.apply #qlx.action<pauli_rotation>(%403, %404, %cst_240) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %406 = qlx.apply #qlx.action<h>(%286#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 2.3561944901923448 : f64
    %407 = qlx.apply #qlx.action<pauli_rotation>(%406, %cst_241) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %408 = qlx.apply #qlx.action<h>(%385#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_242 = arith.constant 3.1415926535897931 : f64
    %409 = qlx.apply #qlx.action<pauli_rotation>(%408, %cst_242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_243 = arith.constant 1.250000e-01 : f64
    %410:2 = qlx.apply #qlx.action<pauli_rotation>(%407, %409, %cst_243) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %411 = qlx.apply #qlx.action<h>(%385#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_244 = arith.constant 3.1415926535897931 : f64
    %412 = qlx.apply #qlx.action<pauli_rotation>(%411, %cst_244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %413 = qlx.apply #qlx.action<h>(%395#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_245 = arith.constant 3.1415926535897931 : f64
    %414 = qlx.apply #qlx.action<pauli_rotation>(%413, %cst_245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_246 = arith.constant 1.250000e-01 : f64
    %415:2 = qlx.apply #qlx.action<pauli_rotation>(%412, %414, %cst_246) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %416 = qlx.apply #qlx.action<h>(%395#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_247 = arith.constant 3.1415926535897931 : f64
    %417 = qlx.apply #qlx.action<pauli_rotation>(%416, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %418 = qlx.apply #qlx.action<h>(%405#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_248 = arith.constant 3.1415926535897931 : f64
    %419 = qlx.apply #qlx.action<pauli_rotation>(%418, %cst_248) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_249 = arith.constant 1.250000e-01 : f64
    %420:2 = qlx.apply #qlx.action<pauli_rotation>(%417, %419, %cst_249) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %421 = qlx.apply #qlx.action<h>(%405#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_250 = arith.constant 3.1415926535897931 : f64
    %422 = qlx.apply #qlx.action<pauli_rotation>(%421, %cst_250) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %423 = qlx.apply #qlx.action<h>(%345#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_251 = arith.constant 2.3561944901923448 : f64
    %424 = qlx.apply #qlx.action<pauli_rotation>(%423, %cst_251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_252 = arith.constant 1.250000e-01 : f64
    %425:2 = qlx.apply #qlx.action<pauli_rotation>(%422, %424, %cst_252) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %426 = qlx.apply #qlx.action<h>(%410#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %427 = qlx.apply #qlx.action<h>(%415#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_253 = arith.constant 1.5707963267948966 : f64
    %428:2 = qlx.apply #qlx.action<pauli_rotation>(%426, %427, %cst_253) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_254 = arith.constant 1.5707963267948966 : f64
    %429 = qlx.apply #qlx.action<pauli_rotation>(%428#0, %cst_254) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_255 = arith.constant 1.5707963267948966 : f64
    %430 = qlx.apply #qlx.action<pauli_rotation>(%428#1, %cst_255) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %431:2 = qlx.apply #qlx.action<pauli_rotation>(%429, %430, %cst_256) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %432 = qlx.apply #qlx.action<h>(%415#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %433 = qlx.apply #qlx.action<h>(%420#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %434:2 = qlx.apply #qlx.action<pauli_rotation>(%432, %433, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_258 = arith.constant 1.5707963267948966 : f64
    %435 = qlx.apply #qlx.action<pauli_rotation>(%434#0, %cst_258) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_259 = arith.constant 1.5707963267948966 : f64
    %436 = qlx.apply #qlx.action<pauli_rotation>(%434#1, %cst_259) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %437:2 = qlx.apply #qlx.action<pauli_rotation>(%435, %436, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %438 = qlx.apply #qlx.action<h>(%420#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %439 = qlx.apply #qlx.action<h>(%425#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_261 = arith.constant 1.5707963267948966 : f64
    %440:2 = qlx.apply #qlx.action<pauli_rotation>(%438, %439, %cst_261) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %441 = qlx.apply #qlx.action<pauli_rotation>(%440#0, %cst_262) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %442 = qlx.apply #qlx.action<pauli_rotation>(%440#1, %cst_263) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_264 = arith.constant 1.5707963267948966 : f64
    %443:2 = qlx.apply #qlx.action<pauli_rotation>(%441, %442, %cst_264) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %444 = qlx.apply #qlx.action<h>(%431#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_265 = arith.constant 3.1415926535897931 : f64
    %445 = qlx.apply #qlx.action<pauli_rotation>(%444, %cst_265) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %446 = qlx.apply #qlx.action<h>(%445) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %447 = qlx.apply #qlx.action<h>(%437#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_266 = arith.constant 3.1415926535897931 : f64
    %448 = qlx.apply #qlx.action<pauli_rotation>(%447, %cst_266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %449 = qlx.apply #qlx.action<h>(%448) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %450:2 = qlx.apply #qlx.action<pauli_rotation>(%446, %449, %cst_267) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %451 = qlx.apply #qlx.action<pauli_rotation>(%450#0, %cst_268) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_269 = arith.constant 1.5707963267948966 : f64
    %452 = qlx.apply #qlx.action<pauli_rotation>(%450#1, %cst_269) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_270 = arith.constant 1.5707963267948966 : f64
    %453:2 = qlx.apply #qlx.action<pauli_rotation>(%451, %452, %cst_270) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %454 = qlx.apply #qlx.action<h>(%437#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_271 = arith.constant 3.1415926535897931 : f64
    %455 = qlx.apply #qlx.action<pauli_rotation>(%454, %cst_271) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %456 = qlx.apply #qlx.action<h>(%455) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %457 = qlx.apply #qlx.action<h>(%443#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_272 = arith.constant 3.1415926535897931 : f64
    %458 = qlx.apply #qlx.action<pauli_rotation>(%457, %cst_272) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %459 = qlx.apply #qlx.action<h>(%458) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %460:2 = qlx.apply #qlx.action<pauli_rotation>(%456, %459, %cst_273) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %461 = qlx.apply #qlx.action<pauli_rotation>(%460#0, %cst_274) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.5707963267948966 : f64
    %462 = qlx.apply #qlx.action<pauli_rotation>(%460#1, %cst_275) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %463:2 = qlx.apply #qlx.action<pauli_rotation>(%461, %462, %cst_276) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %464 = qlx.apply #qlx.action<h>(%453#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 3.1415926535897931 : f64
    %465 = qlx.apply #qlx.action<pauli_rotation>(%464, %cst_277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %466 = qlx.apply #qlx.action<h>(%465) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %467 = qlx.apply #qlx.action<h>(%463#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 3.1415926535897931 : f64
    %468 = qlx.apply #qlx.action<pauli_rotation>(%467, %cst_278) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %469 = qlx.apply #qlx.action<h>(%468) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %470:2 = qlx.apply #qlx.action<pauli_rotation>(%466, %469, %cst_279) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %471 = qlx.apply #qlx.action<pauli_rotation>(%470#0, %cst_280) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_281 = arith.constant 1.5707963267948966 : f64
    %472 = qlx.apply #qlx.action<pauli_rotation>(%470#1, %cst_281) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_282 = arith.constant 1.5707963267948966 : f64
    %473:2 = qlx.apply #qlx.action<pauli_rotation>(%471, %472, %cst_282) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_283 = arith.constant 0.78539816339744828 : f64
    %474 = qlx.apply #qlx.action<pauli_rotation>(%410#0, %cst_283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %475 = qlx.apply #qlx.action<h>(%474) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %476 = qlx.apply #qlx.action<h>(%431#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_284 = arith.constant 2.3561944901923448 : f64
    %477 = qlx.apply #qlx.action<pauli_rotation>(%476, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %478 = qlx.apply #qlx.action<h>(%477) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_285 = arith.constant 0.78539816339744828 : f64
    %479:2 = qlx.apply #qlx.action<pauli_rotation>(%475, %478, %cst_285) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %480 = qlx.apply #qlx.action<pauli_rotation>(%479#0, %cst_286) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.5707963267948966 : f64
    %481 = qlx.apply #qlx.action<pauli_rotation>(%479#1, %cst_287) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_288 = arith.constant 0.78539816339744828 : f64
    %482:2 = qlx.apply #qlx.action<pauli_rotation>(%480, %481, %cst_288) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %483 = qlx.apply #qlx.action<h>(%453#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 2.3561944901923448 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%483, %cst_289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %485 = qlx.apply #qlx.action<h>(%484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %486 = qlx.apply #qlx.action<h>(%473#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_290 = arith.constant 2.3561944901923448 : f64
    %487 = qlx.apply #qlx.action<pauli_rotation>(%486, %cst_290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %488 = qlx.apply #qlx.action<h>(%487) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_291 = arith.constant 0.78539816339744828 : f64
    %489:2 = qlx.apply #qlx.action<pauli_rotation>(%485, %488, %cst_291) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_292 = arith.constant 1.5707963267948966 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%489#0, %cst_292) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_293 = arith.constant 1.5707963267948966 : f64
    %491 = qlx.apply #qlx.action<pauli_rotation>(%489#1, %cst_293) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_294 = arith.constant 0.78539816339744828 : f64
    %492:2 = qlx.apply #qlx.action<pauli_rotation>(%490, %491, %cst_294) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %493 = qlx.apply #qlx.action<h>(%482#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 2.3561944901923448 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %495 = qlx.apply #qlx.action<h>(%494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %496 = qlx.apply #qlx.action<h>(%492#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_296 = arith.constant 0.78539816339744828 : f64
    %497 = qlx.apply #qlx.action<pauli_rotation>(%496, %cst_296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %498 = qlx.apply #qlx.action<h>(%497) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_297 = arith.constant 1.250000e-01 : f64
    %499:2 = qlx.apply #qlx.action<pauli_rotation>(%495, %498, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%499#0, %cst_298) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %501 = qlx.apply #qlx.action<pauli_rotation>(%499#1, %cst_299) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_300 = arith.constant 1.250000e-01 : f64
    %502:2 = qlx.apply #qlx.action<pauli_rotation>(%500, %501, %cst_300) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %503 = qlx.apply #qlx.action<h>(%482#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_301 = arith.constant 1.5707963267948966 : f64
    %504 = qlx.apply #qlx.action<pauli_rotation>(%503, %cst_301) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %505 = qlx.apply #qlx.action<h>(%504) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %506 = qlx.apply #qlx.action<h>(%502#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_302 = arith.constant 0.78539816339744828 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%506, %cst_302) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %508 = qlx.apply #qlx.action<h>(%507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_303 = arith.constant 0.78539816339744828 : f64
    %509:2 = qlx.apply #qlx.action<pauli_rotation>(%505, %508, %cst_303) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %510 = qlx.apply #qlx.action<pauli_rotation>(%509#0, %cst_304) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %511 = qlx.apply #qlx.action<pauli_rotation>(%509#1, %cst_305) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_306 = arith.constant 0.78539816339744828 : f64
    %512:2 = qlx.apply #qlx.action<pauli_rotation>(%510, %511, %cst_306) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %513 = qlx.apply #qlx.action<h>(%502#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 2.3561944901923448 : f64
    %514 = qlx.apply #qlx.action<pauli_rotation>(%513, %cst_307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %515 = qlx.apply #qlx.action<h>(%514) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %516 = qlx.apply #qlx.action<h>(%492#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %517 = qlx.apply #qlx.action<pauli_rotation>(%516, %cst_308) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %518 = qlx.apply #qlx.action<h>(%517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_309 = arith.constant 0.78539816339744828 : f64
    %519:2 = qlx.apply #qlx.action<pauli_rotation>(%515, %518, %cst_309) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%519#0, %cst_310) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_311 = arith.constant 1.5707963267948966 : f64
    %521 = qlx.apply #qlx.action<pauli_rotation>(%519#1, %cst_311) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_312 = arith.constant 0.78539816339744828 : f64
    %522:2 = qlx.apply #qlx.action<pauli_rotation>(%520, %521, %cst_312) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %523 = qlx.apply #qlx.action<h>(%473#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 2.3561944901923448 : f64
    %524 = qlx.apply #qlx.action<pauli_rotation>(%523, %cst_313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %525 = qlx.apply #qlx.action<h>(%524) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %526 = qlx.apply #qlx.action<h>(%463#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_314 = arith.constant 2.3561944901923448 : f64
    %527 = qlx.apply #qlx.action<pauli_rotation>(%526, %cst_314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %528 = qlx.apply #qlx.action<h>(%527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_315 = arith.constant 0.78539816339744828 : f64
    %529:2 = qlx.apply #qlx.action<pauli_rotation>(%525, %528, %cst_315) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%529#0, %cst_316) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_317 = arith.constant 1.5707963267948966 : f64
    %531 = qlx.apply #qlx.action<pauli_rotation>(%529#1, %cst_317) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_318 = arith.constant 0.78539816339744828 : f64
    %532:2 = qlx.apply #qlx.action<pauli_rotation>(%530, %531, %cst_318) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %533 = qlx.apply #qlx.action<h>(%443#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 2.3561944901923448 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%533, %cst_319) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %535 = qlx.apply #qlx.action<h>(%534) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_320 = arith.constant 0.78539816339744828 : f64
    %536 = qlx.apply #qlx.action<pauli_rotation>(%425#1, %cst_320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %537 = qlx.apply #qlx.action<h>(%536) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_321 = arith.constant 0.78539816339744828 : f64
    %538:2 = qlx.apply #qlx.action<pauli_rotation>(%535, %537, %cst_321) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %539 = qlx.apply #qlx.action<pauli_rotation>(%538#0, %cst_322) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %540 = qlx.apply #qlx.action<pauli_rotation>(%538#1, %cst_323) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_324 = arith.constant 0.78539816339744828 : f64
    %541:2 = qlx.apply #qlx.action<pauli_rotation>(%539, %540, %cst_324) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %542 = qlx.apply #qlx.action<h>(%532#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_325 = arith.constant 2.3561944901923448 : f64
    %543 = qlx.apply #qlx.action<pauli_rotation>(%542, %cst_325) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %544 = qlx.apply #qlx.action<h>(%543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %545 = qlx.apply #qlx.action<h>(%541#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_326 = arith.constant 0.78539816339744828 : f64
    %546 = qlx.apply #qlx.action<pauli_rotation>(%545, %cst_326) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %547 = qlx.apply #qlx.action<h>(%546) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_327 = arith.constant 1.250000e-01 : f64
    %548:2 = qlx.apply #qlx.action<pauli_rotation>(%544, %547, %cst_327) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %549 = qlx.apply #qlx.action<pauli_rotation>(%548#0, %cst_328) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_329 = arith.constant 1.5707963267948966 : f64
    %550 = qlx.apply #qlx.action<pauli_rotation>(%548#1, %cst_329) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_330 = arith.constant 1.250000e-01 : f64
    %551:2 = qlx.apply #qlx.action<pauli_rotation>(%549, %550, %cst_330) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %552 = qlx.apply #qlx.action<h>(%532#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_331 = arith.constant 1.5707963267948966 : f64
    %553 = qlx.apply #qlx.action<pauli_rotation>(%552, %cst_331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %554 = qlx.apply #qlx.action<h>(%553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %555 = qlx.apply #qlx.action<h>(%551#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_332 = arith.constant 0.78539816339744828 : f64
    %556 = qlx.apply #qlx.action<pauli_rotation>(%555, %cst_332) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %557 = qlx.apply #qlx.action<h>(%556) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_333 = arith.constant 0.78539816339744828 : f64
    %558:2 = qlx.apply #qlx.action<pauli_rotation>(%554, %557, %cst_333) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %559 = qlx.apply #qlx.action<pauli_rotation>(%558#0, %cst_334) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %560 = qlx.apply #qlx.action<pauli_rotation>(%558#1, %cst_335) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_336 = arith.constant 0.78539816339744828 : f64
    %561:2 = qlx.apply #qlx.action<pauli_rotation>(%559, %560, %cst_336) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %562 = qlx.apply #qlx.action<h>(%551#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_337 = arith.constant 2.3561944901923448 : f64
    %563 = qlx.apply #qlx.action<pauli_rotation>(%562, %cst_337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %564 = qlx.apply #qlx.action<h>(%563) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %565 = qlx.apply #qlx.action<h>(%541#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %566 = qlx.apply #qlx.action<pauli_rotation>(%565, %cst_338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %567 = qlx.apply #qlx.action<h>(%566) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_339 = arith.constant 0.78539816339744828 : f64
    %568:2 = qlx.apply #qlx.action<pauli_rotation>(%564, %567, %cst_339) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %569 = qlx.apply #qlx.action<pauli_rotation>(%568#0, %cst_340) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%568#1, %cst_341) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_342 = arith.constant 0.78539816339744828 : f64
    %571:2 = qlx.apply #qlx.action<pauli_rotation>(%569, %570, %cst_342) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %572 = qlx.apply #qlx.action<h>(%522#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_343 = arith.constant 2.3561944901923448 : f64
    %573 = qlx.apply #qlx.action<pauli_rotation>(%572, %cst_343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %574 = qlx.apply #qlx.action<h>(%573) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %575 = qlx.apply #qlx.action<h>(%561#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_344 = arith.constant 2.3561944901923448 : f64
    %576 = qlx.apply #qlx.action<pauli_rotation>(%575, %cst_344) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %577 = qlx.apply #qlx.action<h>(%576) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %578:2 = qlx.apply #qlx.action<pauli_rotation>(%574, %577, %cst_345) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_346 = arith.constant 1.5707963267948966 : f64
    %579 = qlx.apply #qlx.action<pauli_rotation>(%578#0, %cst_346) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_347 = arith.constant 1.5707963267948966 : f64
    %580 = qlx.apply #qlx.action<pauli_rotation>(%578#1, %cst_347) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %581:2 = qlx.apply #qlx.action<pauli_rotation>(%579, %580, %cst_348) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %582 = qlx.apply #qlx.action<h>(%522#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_349 = arith.constant 2.3561944901923448 : f64
    %583 = qlx.apply #qlx.action<pauli_rotation>(%582, %cst_349) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %584 = qlx.apply #qlx.action<h>(%583) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %585 = qlx.apply #qlx.action<h>(%581#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_350 = arith.constant 3.1415926535897931 : f64
    %586 = qlx.apply #qlx.action<pauli_rotation>(%585, %cst_350) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %587 = qlx.apply #qlx.action<h>(%586) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_351 = arith.constant 1.5707963267948966 : f64
    %588:2 = qlx.apply #qlx.action<pauli_rotation>(%584, %587, %cst_351) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %589 = qlx.apply #qlx.action<pauli_rotation>(%588#0, %cst_352) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_353 = arith.constant 1.5707963267948966 : f64
    %590 = qlx.apply #qlx.action<pauli_rotation>(%588#1, %cst_353) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %591:2 = qlx.apply #qlx.action<pauli_rotation>(%589, %590, %cst_354) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %592 = qlx.apply #qlx.action<h>(%581#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_355 = arith.constant 3.1415926535897931 : f64
    %593 = qlx.apply #qlx.action<pauli_rotation>(%592, %cst_355) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %594 = qlx.apply #qlx.action<h>(%593) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %595 = qlx.apply #qlx.action<h>(%561#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_356 = arith.constant 2.3561944901923448 : f64
    %596 = qlx.apply #qlx.action<pauli_rotation>(%595, %cst_356) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %597 = qlx.apply #qlx.action<h>(%596) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_357 = arith.constant 1.5707963267948966 : f64
    %598:2 = qlx.apply #qlx.action<pauli_rotation>(%594, %597, %cst_357) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%598#0, %cst_358) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %600 = qlx.apply #qlx.action<pauli_rotation>(%598#1, %cst_359) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %601:2 = qlx.apply #qlx.action<pauli_rotation>(%599, %600, %cst_360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %602 = qlx.apply #qlx.action<h>(%512#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_361 = arith.constant 2.3561944901923448 : f64
    %603 = qlx.apply #qlx.action<pauli_rotation>(%602, %cst_361) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %604 = qlx.apply #qlx.action<h>(%603) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %605 = qlx.apply #qlx.action<h>(%591#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_362 = arith.constant 3.1415926535897931 : f64
    %606 = qlx.apply #qlx.action<pauli_rotation>(%605, %cst_362) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %607 = qlx.apply #qlx.action<h>(%606) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %608:2 = qlx.apply #qlx.action<pauli_rotation>(%604, %607, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_364 = arith.constant 1.5707963267948966 : f64
    %609 = qlx.apply #qlx.action<pauli_rotation>(%608#0, %cst_364) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_365 = arith.constant 1.5707963267948966 : f64
    %610 = qlx.apply #qlx.action<pauli_rotation>(%608#1, %cst_365) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %611:2 = qlx.apply #qlx.action<pauli_rotation>(%609, %610, %cst_366) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %612 = qlx.apply #qlx.action<h>(%591#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_367 = arith.constant 3.1415926535897931 : f64
    %613 = qlx.apply #qlx.action<pauli_rotation>(%612, %cst_367) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %614 = qlx.apply #qlx.action<h>(%613) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %615 = qlx.apply #qlx.action<h>(%601#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_368 = arith.constant 3.1415926535897931 : f64
    %616 = qlx.apply #qlx.action<pauli_rotation>(%615, %cst_368) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %617 = qlx.apply #qlx.action<h>(%616) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_369 = arith.constant 1.5707963267948966 : f64
    %618:2 = qlx.apply #qlx.action<pauli_rotation>(%614, %617, %cst_369) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %619 = qlx.apply #qlx.action<pauli_rotation>(%618#0, %cst_370) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %620 = qlx.apply #qlx.action<pauli_rotation>(%618#1, %cst_371) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_372 = arith.constant 1.5707963267948966 : f64
    %621:2 = qlx.apply #qlx.action<pauli_rotation>(%619, %620, %cst_372) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %622 = qlx.apply #qlx.action<h>(%601#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_373 = arith.constant 3.1415926535897931 : f64
    %623 = qlx.apply #qlx.action<pauli_rotation>(%622, %cst_373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %624 = qlx.apply #qlx.action<h>(%623) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %625 = qlx.apply #qlx.action<h>(%571#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_374 = arith.constant 2.3561944901923448 : f64
    %626 = qlx.apply #qlx.action<pauli_rotation>(%625, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %627 = qlx.apply #qlx.action<h>(%626) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_375 = arith.constant 1.5707963267948966 : f64
    %628:2 = qlx.apply #qlx.action<pauli_rotation>(%624, %627, %cst_375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %629 = qlx.apply #qlx.action<pauli_rotation>(%628#0, %cst_376) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%628#1, %cst_377) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_378 = arith.constant 1.5707963267948966 : f64
    %631:2 = qlx.apply #qlx.action<pauli_rotation>(%629, %630, %cst_378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %632 = qlx.apply #qlx.action<h>(%512#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_379 = arith.constant 2.3561944901923448 : f64
    %633 = qlx.apply #qlx.action<pauli_rotation>(%632, %cst_379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %634 = qlx.apply #qlx.action<h>(%611#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_380 = arith.constant 3.1415926535897931 : f64
    %635 = qlx.apply #qlx.action<pauli_rotation>(%634, %cst_380) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_381 = arith.constant 1.250000e-01 : f64
    %636:2 = qlx.apply #qlx.action<pauli_rotation>(%633, %635, %cst_381) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %637 = qlx.apply #qlx.action<h>(%611#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_382 = arith.constant 3.1415926535897931 : f64
    %638 = qlx.apply #qlx.action<pauli_rotation>(%637, %cst_382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %639 = qlx.apply #qlx.action<h>(%621#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_383 = arith.constant 3.1415926535897931 : f64
    %640 = qlx.apply #qlx.action<pauli_rotation>(%639, %cst_383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_384 = arith.constant 1.250000e-01 : f64
    %641:2 = qlx.apply #qlx.action<pauli_rotation>(%638, %640, %cst_384) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %642 = qlx.apply #qlx.action<h>(%621#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_385 = arith.constant 3.1415926535897931 : f64
    %643 = qlx.apply #qlx.action<pauli_rotation>(%642, %cst_385) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %644 = qlx.apply #qlx.action<h>(%631#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_386 = arith.constant 3.1415926535897931 : f64
    %645 = qlx.apply #qlx.action<pauli_rotation>(%644, %cst_386) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_387 = arith.constant 1.250000e-01 : f64
    %646:2 = qlx.apply #qlx.action<pauli_rotation>(%643, %645, %cst_387) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %647 = qlx.apply #qlx.action<h>(%631#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_388 = arith.constant 3.1415926535897931 : f64
    %648 = qlx.apply #qlx.action<pauli_rotation>(%647, %cst_388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %649 = qlx.apply #qlx.action<h>(%571#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_389 = arith.constant 2.3561944901923448 : f64
    %650 = qlx.apply #qlx.action<pauli_rotation>(%649, %cst_389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_390 = arith.constant 1.250000e-01 : f64
    %651:2 = qlx.apply #qlx.action<pauli_rotation>(%648, %650, %cst_390) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %652 = qlx.apply #qlx.action<h>(%636#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %653 = qlx.apply #qlx.action<h>(%641#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %654:2 = qlx.apply #qlx.action<pauli_rotation>(%652, %653, %cst_391) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_392 = arith.constant 1.5707963267948966 : f64
    %655 = qlx.apply #qlx.action<pauli_rotation>(%654#0, %cst_392) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_393 = arith.constant 1.5707963267948966 : f64
    %656 = qlx.apply #qlx.action<pauli_rotation>(%654#1, %cst_393) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_394 = arith.constant 1.5707963267948966 : f64
    %657:2 = qlx.apply #qlx.action<pauli_rotation>(%655, %656, %cst_394) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %658 = qlx.apply #qlx.action<h>(%641#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %659 = qlx.apply #qlx.action<h>(%646#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_395 = arith.constant 1.5707963267948966 : f64
    %660:2 = qlx.apply #qlx.action<pauli_rotation>(%658, %659, %cst_395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_396 = arith.constant 1.5707963267948966 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%660#0, %cst_396) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %662 = qlx.apply #qlx.action<pauli_rotation>(%660#1, %cst_397) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %663:2 = qlx.apply #qlx.action<pauli_rotation>(%661, %662, %cst_398) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %664 = qlx.apply #qlx.action<h>(%646#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%651#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_399 = arith.constant 1.5707963267948966 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%664, %665, %cst_399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_400 = arith.constant 1.5707963267948966 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%666#0, %cst_400) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.5707963267948966 : f64
    %668 = qlx.apply #qlx.action<pauli_rotation>(%666#1, %cst_401) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %669:2 = qlx.apply #qlx.action<pauli_rotation>(%667, %668, %cst_402) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %670 = qlx.apply #qlx.action<h>(%657#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_403 = arith.constant 3.1415926535897931 : f64
    %671 = qlx.apply #qlx.action<pauli_rotation>(%670, %cst_403) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %672 = qlx.apply #qlx.action<h>(%671) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %673 = qlx.apply #qlx.action<h>(%663#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_404 = arith.constant 3.1415926535897931 : f64
    %674 = qlx.apply #qlx.action<pauli_rotation>(%673, %cst_404) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %675 = qlx.apply #qlx.action<h>(%674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_405 = arith.constant 1.5707963267948966 : f64
    %676:2 = qlx.apply #qlx.action<pauli_rotation>(%672, %675, %cst_405) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_406 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676#0, %cst_406) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %678 = qlx.apply #qlx.action<pauli_rotation>(%676#1, %cst_407) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %679:2 = qlx.apply #qlx.action<pauli_rotation>(%677, %678, %cst_408) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %680 = qlx.apply #qlx.action<h>(%663#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_409 = arith.constant 3.1415926535897931 : f64
    %681 = qlx.apply #qlx.action<pauli_rotation>(%680, %cst_409) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %682 = qlx.apply #qlx.action<h>(%681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %683 = qlx.apply #qlx.action<h>(%669#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_410 = arith.constant 3.1415926535897931 : f64
    %684 = qlx.apply #qlx.action<pauli_rotation>(%683, %cst_410) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %685 = qlx.apply #qlx.action<h>(%684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 1.5707963267948966 : f64
    %686:2 = qlx.apply #qlx.action<pauli_rotation>(%682, %685, %cst_411) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_412 = arith.constant 1.5707963267948966 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686#0, %cst_412) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %688 = qlx.apply #qlx.action<pauli_rotation>(%686#1, %cst_413) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %689:2 = qlx.apply #qlx.action<pauli_rotation>(%687, %688, %cst_414) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %690 = qlx.apply #qlx.action<h>(%679#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_415 = arith.constant 3.1415926535897931 : f64
    %691 = qlx.apply #qlx.action<pauli_rotation>(%690, %cst_415) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %692 = qlx.apply #qlx.action<h>(%691) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %693 = qlx.apply #qlx.action<h>(%689#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_416 = arith.constant 3.1415926535897931 : f64
    %694 = qlx.apply #qlx.action<pauli_rotation>(%693, %cst_416) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %695 = qlx.apply #qlx.action<h>(%694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %696:2 = qlx.apply #qlx.action<pauli_rotation>(%692, %695, %cst_417) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %697 = qlx.apply #qlx.action<pauli_rotation>(%696#0, %cst_418) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.5707963267948966 : f64
    %698 = qlx.apply #qlx.action<pauli_rotation>(%696#1, %cst_419) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %699:2 = qlx.apply #qlx.action<pauli_rotation>(%697, %698, %cst_420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_421 = arith.constant 0.78539816339744828 : f64
    %700 = qlx.apply #qlx.action<pauli_rotation>(%636#0, %cst_421) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %701 = qlx.apply #qlx.action<h>(%700) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %702 = qlx.apply #qlx.action<h>(%657#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 2.3561944901923448 : f64
    %703 = qlx.apply #qlx.action<pauli_rotation>(%702, %cst_422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %704 = qlx.apply #qlx.action<h>(%703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_423 = arith.constant 0.78539816339744828 : f64
    %705:2 = qlx.apply #qlx.action<pauli_rotation>(%701, %704, %cst_423) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705#0, %cst_424) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %707 = qlx.apply #qlx.action<pauli_rotation>(%705#1, %cst_425) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_426 = arith.constant 0.78539816339744828 : f64
    %708:2 = qlx.apply #qlx.action<pauli_rotation>(%706, %707, %cst_426) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %709 = qlx.apply #qlx.action<h>(%679#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 2.3561944901923448 : f64
    %710 = qlx.apply #qlx.action<pauli_rotation>(%709, %cst_427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %711 = qlx.apply #qlx.action<h>(%710) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%699#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_428 = arith.constant 2.3561944901923448 : f64
    %713 = qlx.apply #qlx.action<pauli_rotation>(%712, %cst_428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %714 = qlx.apply #qlx.action<h>(%713) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_429 = arith.constant 0.78539816339744828 : f64
    %715:2 = qlx.apply #qlx.action<pauli_rotation>(%711, %714, %cst_429) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_430 = arith.constant 1.5707963267948966 : f64
    %716 = qlx.apply #qlx.action<pauli_rotation>(%715#0, %cst_430) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_431 = arith.constant 1.5707963267948966 : f64
    %717 = qlx.apply #qlx.action<pauli_rotation>(%715#1, %cst_431) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_432 = arith.constant 0.78539816339744828 : f64
    %718:2 = qlx.apply #qlx.action<pauli_rotation>(%716, %717, %cst_432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %719 = qlx.apply #qlx.action<h>(%708#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_433 = arith.constant 2.3561944901923448 : f64
    %720 = qlx.apply #qlx.action<pauli_rotation>(%719, %cst_433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %721 = qlx.apply #qlx.action<h>(%720) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %722 = qlx.apply #qlx.action<h>(%718#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_434 = arith.constant 0.78539816339744828 : f64
    %723 = qlx.apply #qlx.action<pauli_rotation>(%722, %cst_434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %724 = qlx.apply #qlx.action<h>(%723) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_435 = arith.constant 1.250000e-01 : f64
    %725:2 = qlx.apply #qlx.action<pauli_rotation>(%721, %724, %cst_435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_436 = arith.constant 1.5707963267948966 : f64
    %726 = qlx.apply #qlx.action<pauli_rotation>(%725#0, %cst_436) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %727 = qlx.apply #qlx.action<pauli_rotation>(%725#1, %cst_437) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_438 = arith.constant 1.250000e-01 : f64
    %728:2 = qlx.apply #qlx.action<pauli_rotation>(%726, %727, %cst_438) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %729 = qlx.apply #qlx.action<h>(%708#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_439 = arith.constant 1.5707963267948966 : f64
    %730 = qlx.apply #qlx.action<pauli_rotation>(%729, %cst_439) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %731 = qlx.apply #qlx.action<h>(%730) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %732 = qlx.apply #qlx.action<h>(%728#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_440 = arith.constant 0.78539816339744828 : f64
    %733 = qlx.apply #qlx.action<pauli_rotation>(%732, %cst_440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %734 = qlx.apply #qlx.action<h>(%733) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 0.78539816339744828 : f64
    %735:2 = qlx.apply #qlx.action<pauli_rotation>(%731, %734, %cst_441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %736 = qlx.apply #qlx.action<pauli_rotation>(%735#0, %cst_442) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %737 = qlx.apply #qlx.action<pauli_rotation>(%735#1, %cst_443) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_444 = arith.constant 0.78539816339744828 : f64
    %738:2 = qlx.apply #qlx.action<pauli_rotation>(%736, %737, %cst_444) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %739 = qlx.apply #qlx.action<h>(%728#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_445 = arith.constant 2.3561944901923448 : f64
    %740 = qlx.apply #qlx.action<pauli_rotation>(%739, %cst_445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %741 = qlx.apply #qlx.action<h>(%740) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%718#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_446 = arith.constant 1.5707963267948966 : f64
    %743 = qlx.apply #qlx.action<pauli_rotation>(%742, %cst_446) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %744 = qlx.apply #qlx.action<h>(%743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_447 = arith.constant 0.78539816339744828 : f64
    %745:2 = qlx.apply #qlx.action<pauli_rotation>(%741, %744, %cst_447) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_448 = arith.constant 1.5707963267948966 : f64
    %746 = qlx.apply #qlx.action<pauli_rotation>(%745#0, %cst_448) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %747 = qlx.apply #qlx.action<pauli_rotation>(%745#1, %cst_449) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_450 = arith.constant 0.78539816339744828 : f64
    %748:2 = qlx.apply #qlx.action<pauli_rotation>(%746, %747, %cst_450) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %749 = qlx.apply #qlx.action<h>(%699#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_451 = arith.constant 2.3561944901923448 : f64
    %750 = qlx.apply #qlx.action<pauli_rotation>(%749, %cst_451) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %751 = qlx.apply #qlx.action<h>(%750) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %752 = qlx.apply #qlx.action<h>(%689#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_452 = arith.constant 2.3561944901923448 : f64
    %753 = qlx.apply #qlx.action<pauli_rotation>(%752, %cst_452) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %754 = qlx.apply #qlx.action<h>(%753) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_453 = arith.constant 0.78539816339744828 : f64
    %755:2 = qlx.apply #qlx.action<pauli_rotation>(%751, %754, %cst_453) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %756 = qlx.apply #qlx.action<pauli_rotation>(%755#0, %cst_454) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %757 = qlx.apply #qlx.action<pauli_rotation>(%755#1, %cst_455) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_456 = arith.constant 0.78539816339744828 : f64
    %758:2 = qlx.apply #qlx.action<pauli_rotation>(%756, %757, %cst_456) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %759 = qlx.apply #qlx.action<h>(%669#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 2.3561944901923448 : f64
    %760 = qlx.apply #qlx.action<pauli_rotation>(%759, %cst_457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %761 = qlx.apply #qlx.action<h>(%760) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_458 = arith.constant 0.78539816339744828 : f64
    %762 = qlx.apply #qlx.action<pauli_rotation>(%651#1, %cst_458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %763 = qlx.apply #qlx.action<h>(%762) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_459 = arith.constant 0.78539816339744828 : f64
    %764:2 = qlx.apply #qlx.action<pauli_rotation>(%761, %763, %cst_459) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %765 = qlx.apply #qlx.action<pauli_rotation>(%764#0, %cst_460) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_461 = arith.constant 1.5707963267948966 : f64
    %766 = qlx.apply #qlx.action<pauli_rotation>(%764#1, %cst_461) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_462 = arith.constant 0.78539816339744828 : f64
    %767:2 = qlx.apply #qlx.action<pauli_rotation>(%765, %766, %cst_462) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %768 = qlx.apply #qlx.action<h>(%758#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_463 = arith.constant 2.3561944901923448 : f64
    %769 = qlx.apply #qlx.action<pauli_rotation>(%768, %cst_463) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %770 = qlx.apply #qlx.action<h>(%769) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %771 = qlx.apply #qlx.action<h>(%767#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_464 = arith.constant 0.78539816339744828 : f64
    %772 = qlx.apply #qlx.action<pauli_rotation>(%771, %cst_464) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %773 = qlx.apply #qlx.action<h>(%772) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_465 = arith.constant 1.250000e-01 : f64
    %774:2 = qlx.apply #qlx.action<pauli_rotation>(%770, %773, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_466 = arith.constant 1.5707963267948966 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%774#0, %cst_466) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_467 = arith.constant 1.5707963267948966 : f64
    %776 = qlx.apply #qlx.action<pauli_rotation>(%774#1, %cst_467) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_468 = arith.constant 1.250000e-01 : f64
    %777:2 = qlx.apply #qlx.action<pauli_rotation>(%775, %776, %cst_468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %778 = qlx.apply #qlx.action<h>(%758#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_469 = arith.constant 1.5707963267948966 : f64
    %779 = qlx.apply #qlx.action<pauli_rotation>(%778, %cst_469) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %780 = qlx.apply #qlx.action<h>(%779) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %781 = qlx.apply #qlx.action<h>(%777#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_470 = arith.constant 0.78539816339744828 : f64
    %782 = qlx.apply #qlx.action<pauli_rotation>(%781, %cst_470) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %783 = qlx.apply #qlx.action<h>(%782) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_471 = arith.constant 0.78539816339744828 : f64
    %784:2 = qlx.apply #qlx.action<pauli_rotation>(%780, %783, %cst_471) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_472 = arith.constant 1.5707963267948966 : f64
    %785 = qlx.apply #qlx.action<pauli_rotation>(%784#0, %cst_472) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_473 = arith.constant 1.5707963267948966 : f64
    %786 = qlx.apply #qlx.action<pauli_rotation>(%784#1, %cst_473) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_474 = arith.constant 0.78539816339744828 : f64
    %787:2 = qlx.apply #qlx.action<pauli_rotation>(%785, %786, %cst_474) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %788 = qlx.apply #qlx.action<h>(%777#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_475 = arith.constant 2.3561944901923448 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%788, %cst_475) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %790 = qlx.apply #qlx.action<h>(%789) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %791 = qlx.apply #qlx.action<h>(%767#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %792 = qlx.apply #qlx.action<pauli_rotation>(%791, %cst_476) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %793 = qlx.apply #qlx.action<h>(%792) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_477 = arith.constant 0.78539816339744828 : f64
    %794:2 = qlx.apply #qlx.action<pauli_rotation>(%790, %793, %cst_477) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_478 = arith.constant 1.5707963267948966 : f64
    %795 = qlx.apply #qlx.action<pauli_rotation>(%794#0, %cst_478) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_479 = arith.constant 1.5707963267948966 : f64
    %796 = qlx.apply #qlx.action<pauli_rotation>(%794#1, %cst_479) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_480 = arith.constant 0.78539816339744828 : f64
    %797:2 = qlx.apply #qlx.action<pauli_rotation>(%795, %796, %cst_480) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %798 = qlx.apply #qlx.action<h>(%748#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_481 = arith.constant 2.3561944901923448 : f64
    %799 = qlx.apply #qlx.action<pauli_rotation>(%798, %cst_481) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %800 = qlx.apply #qlx.action<h>(%799) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %801 = qlx.apply #qlx.action<h>(%787#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_482 = arith.constant 2.3561944901923448 : f64
    %802 = qlx.apply #qlx.action<pauli_rotation>(%801, %cst_482) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %803 = qlx.apply #qlx.action<h>(%802) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_483 = arith.constant 1.5707963267948966 : f64
    %804:2 = qlx.apply #qlx.action<pauli_rotation>(%800, %803, %cst_483) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_484 = arith.constant 1.5707963267948966 : f64
    %805 = qlx.apply #qlx.action<pauli_rotation>(%804#0, %cst_484) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_485 = arith.constant 1.5707963267948966 : f64
    %806 = qlx.apply #qlx.action<pauli_rotation>(%804#1, %cst_485) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %807:2 = qlx.apply #qlx.action<pauli_rotation>(%805, %806, %cst_486) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %808 = qlx.apply #qlx.action<h>(%748#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_487 = arith.constant 2.3561944901923448 : f64
    %809 = qlx.apply #qlx.action<pauli_rotation>(%808, %cst_487) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %810 = qlx.apply #qlx.action<h>(%809) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %811 = qlx.apply #qlx.action<h>(%807#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_488 = arith.constant 3.1415926535897931 : f64
    %812 = qlx.apply #qlx.action<pauli_rotation>(%811, %cst_488) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %813 = qlx.apply #qlx.action<h>(%812) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_489 = arith.constant 1.5707963267948966 : f64
    %814:2 = qlx.apply #qlx.action<pauli_rotation>(%810, %813, %cst_489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_490 = arith.constant 1.5707963267948966 : f64
    %815 = qlx.apply #qlx.action<pauli_rotation>(%814#0, %cst_490) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_491 = arith.constant 1.5707963267948966 : f64
    %816 = qlx.apply #qlx.action<pauli_rotation>(%814#1, %cst_491) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_492 = arith.constant 1.5707963267948966 : f64
    %817:2 = qlx.apply #qlx.action<pauli_rotation>(%815, %816, %cst_492) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %818 = qlx.apply #qlx.action<h>(%807#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_493 = arith.constant 3.1415926535897931 : f64
    %819 = qlx.apply #qlx.action<pauli_rotation>(%818, %cst_493) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %820 = qlx.apply #qlx.action<h>(%819) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %821 = qlx.apply #qlx.action<h>(%787#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_494 = arith.constant 2.3561944901923448 : f64
    %822 = qlx.apply #qlx.action<pauli_rotation>(%821, %cst_494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %823 = qlx.apply #qlx.action<h>(%822) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_495 = arith.constant 1.5707963267948966 : f64
    %824:2 = qlx.apply #qlx.action<pauli_rotation>(%820, %823, %cst_495) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_496 = arith.constant 1.5707963267948966 : f64
    %825 = qlx.apply #qlx.action<pauli_rotation>(%824#0, %cst_496) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_497 = arith.constant 1.5707963267948966 : f64
    %826 = qlx.apply #qlx.action<pauli_rotation>(%824#1, %cst_497) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %827:2 = qlx.apply #qlx.action<pauli_rotation>(%825, %826, %cst_498) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %828 = qlx.apply #qlx.action<h>(%738#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_499 = arith.constant 2.3561944901923448 : f64
    %829 = qlx.apply #qlx.action<pauli_rotation>(%828, %cst_499) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %830 = qlx.apply #qlx.action<h>(%829) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %831 = qlx.apply #qlx.action<h>(%817#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_500 = arith.constant 3.1415926535897931 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%831, %cst_500) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %833 = qlx.apply #qlx.action<h>(%832) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_501 = arith.constant 1.5707963267948966 : f64
    %834:2 = qlx.apply #qlx.action<pauli_rotation>(%830, %833, %cst_501) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_502 = arith.constant 1.5707963267948966 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%834#0, %cst_502) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_503 = arith.constant 1.5707963267948966 : f64
    %836 = qlx.apply #qlx.action<pauli_rotation>(%834#1, %cst_503) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_504 = arith.constant 1.5707963267948966 : f64
    %837:2 = qlx.apply #qlx.action<pauli_rotation>(%835, %836, %cst_504) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %838 = qlx.apply #qlx.action<h>(%817#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_505 = arith.constant 3.1415926535897931 : f64
    %839 = qlx.apply #qlx.action<pauli_rotation>(%838, %cst_505) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %840 = qlx.apply #qlx.action<h>(%839) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %841 = qlx.apply #qlx.action<h>(%827#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_506 = arith.constant 3.1415926535897931 : f64
    %842 = qlx.apply #qlx.action<pauli_rotation>(%841, %cst_506) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %843 = qlx.apply #qlx.action<h>(%842) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_507 = arith.constant 1.5707963267948966 : f64
    %844:2 = qlx.apply #qlx.action<pauli_rotation>(%840, %843, %cst_507) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_508 = arith.constant 1.5707963267948966 : f64
    %845 = qlx.apply #qlx.action<pauli_rotation>(%844#0, %cst_508) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_509 = arith.constant 1.5707963267948966 : f64
    %846 = qlx.apply #qlx.action<pauli_rotation>(%844#1, %cst_509) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %847:2 = qlx.apply #qlx.action<pauli_rotation>(%845, %846, %cst_510) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %848 = qlx.apply #qlx.action<h>(%827#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_511 = arith.constant 3.1415926535897931 : f64
    %849 = qlx.apply #qlx.action<pauli_rotation>(%848, %cst_511) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %850 = qlx.apply #qlx.action<h>(%849) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %851 = qlx.apply #qlx.action<h>(%797#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_512 = arith.constant 2.3561944901923448 : f64
    %852 = qlx.apply #qlx.action<pauli_rotation>(%851, %cst_512) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %853 = qlx.apply #qlx.action<h>(%852) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_513 = arith.constant 1.5707963267948966 : f64
    %854:2 = qlx.apply #qlx.action<pauli_rotation>(%850, %853, %cst_513) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_514 = arith.constant 1.5707963267948966 : f64
    %855 = qlx.apply #qlx.action<pauli_rotation>(%854#0, %cst_514) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_515 = arith.constant 1.5707963267948966 : f64
    %856 = qlx.apply #qlx.action<pauli_rotation>(%854#1, %cst_515) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %857:2 = qlx.apply #qlx.action<pauli_rotation>(%855, %856, %cst_516) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %858 = qlx.apply #qlx.action<h>(%738#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_517 = arith.constant 2.3561944901923448 : f64
    %859 = qlx.apply #qlx.action<pauli_rotation>(%858, %cst_517) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %860 = qlx.apply #qlx.action<h>(%837#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_518 = arith.constant 3.1415926535897931 : f64
    %861 = qlx.apply #qlx.action<pauli_rotation>(%860, %cst_518) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_519 = arith.constant 1.250000e-01 : f64
    %862:2 = qlx.apply #qlx.action<pauli_rotation>(%859, %861, %cst_519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %863 = qlx.apply #qlx.action<h>(%837#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_520 = arith.constant 3.1415926535897931 : f64
    %864 = qlx.apply #qlx.action<pauli_rotation>(%863, %cst_520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %865 = qlx.apply #qlx.action<h>(%847#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_521 = arith.constant 3.1415926535897931 : f64
    %866 = qlx.apply #qlx.action<pauli_rotation>(%865, %cst_521) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_522 = arith.constant 1.250000e-01 : f64
    %867:2 = qlx.apply #qlx.action<pauli_rotation>(%864, %866, %cst_522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %868 = qlx.apply #qlx.action<h>(%847#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_523 = arith.constant 3.1415926535897931 : f64
    %869 = qlx.apply #qlx.action<pauli_rotation>(%868, %cst_523) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %870 = qlx.apply #qlx.action<h>(%857#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_524 = arith.constant 3.1415926535897931 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%870, %cst_524) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_525 = arith.constant 1.250000e-01 : f64
    %872:2 = qlx.apply #qlx.action<pauli_rotation>(%869, %871, %cst_525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %873 = qlx.apply #qlx.action<h>(%857#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_526 = arith.constant 3.1415926535897931 : f64
    %874 = qlx.apply #qlx.action<pauli_rotation>(%873, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %875 = qlx.apply #qlx.action<h>(%797#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_527 = arith.constant 2.3561944901923448 : f64
    %876 = qlx.apply #qlx.action<pauli_rotation>(%875, %cst_527) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_528 = arith.constant 1.250000e-01 : f64
    %877:2 = qlx.apply #qlx.action<pauli_rotation>(%874, %876, %cst_528) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %878 = qlx.apply #qlx.action<h>(%862#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %879 = qlx.apply #qlx.action<h>(%867#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %880:2 = qlx.apply #qlx.action<pauli_rotation>(%878, %879, %cst_529) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_530 = arith.constant 1.5707963267948966 : f64
    %881 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %cst_530) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_531 = arith.constant 1.5707963267948966 : f64
    %882 = qlx.apply #qlx.action<pauli_rotation>(%880#1, %cst_531) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_532 = arith.constant 1.5707963267948966 : f64
    %883:2 = qlx.apply #qlx.action<pauli_rotation>(%881, %882, %cst_532) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %884 = qlx.apply #qlx.action<h>(%867#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %885 = qlx.apply #qlx.action<h>(%872#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %886:2 = qlx.apply #qlx.action<pauli_rotation>(%884, %885, %cst_533) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_534 = arith.constant 1.5707963267948966 : f64
    %887 = qlx.apply #qlx.action<pauli_rotation>(%886#0, %cst_534) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %888 = qlx.apply #qlx.action<pauli_rotation>(%886#1, %cst_535) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_536 = arith.constant 1.5707963267948966 : f64
    %889:2 = qlx.apply #qlx.action<pauli_rotation>(%887, %888, %cst_536) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %890 = qlx.apply #qlx.action<h>(%872#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %891 = qlx.apply #qlx.action<h>(%877#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_537 = arith.constant 1.5707963267948966 : f64
    %892:2 = qlx.apply #qlx.action<pauli_rotation>(%890, %891, %cst_537) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_538 = arith.constant 1.5707963267948966 : f64
    %893 = qlx.apply #qlx.action<pauli_rotation>(%892#0, %cst_538) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_539 = arith.constant 1.5707963267948966 : f64
    %894 = qlx.apply #qlx.action<pauli_rotation>(%892#1, %cst_539) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_540 = arith.constant 1.5707963267948966 : f64
    %895:2 = qlx.apply #qlx.action<pauli_rotation>(%893, %894, %cst_540) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %896 = qlx.apply #qlx.action<h>(%883#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_541 = arith.constant 3.1415926535897931 : f64
    %897 = qlx.apply #qlx.action<pauli_rotation>(%896, %cst_541) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %898 = qlx.apply #qlx.action<h>(%897) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %899 = qlx.apply #qlx.action<h>(%889#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_542 = arith.constant 3.1415926535897931 : f64
    %900 = qlx.apply #qlx.action<pauli_rotation>(%899, %cst_542) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %901 = qlx.apply #qlx.action<h>(%900) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_543 = arith.constant 1.5707963267948966 : f64
    %902:2 = qlx.apply #qlx.action<pauli_rotation>(%898, %901, %cst_543) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_544 = arith.constant 1.5707963267948966 : f64
    %903 = qlx.apply #qlx.action<pauli_rotation>(%902#0, %cst_544) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_545 = arith.constant 1.5707963267948966 : f64
    %904 = qlx.apply #qlx.action<pauli_rotation>(%902#1, %cst_545) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_546 = arith.constant 1.5707963267948966 : f64
    %905:2 = qlx.apply #qlx.action<pauli_rotation>(%903, %904, %cst_546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %906 = qlx.apply #qlx.action<h>(%889#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_547 = arith.constant 3.1415926535897931 : f64
    %907 = qlx.apply #qlx.action<pauli_rotation>(%906, %cst_547) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %908 = qlx.apply #qlx.action<h>(%907) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%895#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_548 = arith.constant 3.1415926535897931 : f64
    %910 = qlx.apply #qlx.action<pauli_rotation>(%909, %cst_548) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %911 = qlx.apply #qlx.action<h>(%910) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_549 = arith.constant 1.5707963267948966 : f64
    %912:2 = qlx.apply #qlx.action<pauli_rotation>(%908, %911, %cst_549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_550 = arith.constant 1.5707963267948966 : f64
    %913 = qlx.apply #qlx.action<pauli_rotation>(%912#0, %cst_550) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_551 = arith.constant 1.5707963267948966 : f64
    %914 = qlx.apply #qlx.action<pauli_rotation>(%912#1, %cst_551) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_552 = arith.constant 1.5707963267948966 : f64
    %915:2 = qlx.apply #qlx.action<pauli_rotation>(%913, %914, %cst_552) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %916 = qlx.apply #qlx.action<h>(%905#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_553 = arith.constant 3.1415926535897931 : f64
    %917 = qlx.apply #qlx.action<pauli_rotation>(%916, %cst_553) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %918 = qlx.apply #qlx.action<h>(%917) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %919 = qlx.apply #qlx.action<h>(%915#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_554 = arith.constant 3.1415926535897931 : f64
    %920 = qlx.apply #qlx.action<pauli_rotation>(%919, %cst_554) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %921 = qlx.apply #qlx.action<h>(%920) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_555 = arith.constant 1.5707963267948966 : f64
    %922:2 = qlx.apply #qlx.action<pauli_rotation>(%918, %921, %cst_555) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_556 = arith.constant 1.5707963267948966 : f64
    %923 = qlx.apply #qlx.action<pauli_rotation>(%922#0, %cst_556) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_557 = arith.constant 1.5707963267948966 : f64
    %924 = qlx.apply #qlx.action<pauli_rotation>(%922#1, %cst_557) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_558 = arith.constant 1.5707963267948966 : f64
    %925:2 = qlx.apply #qlx.action<pauli_rotation>(%923, %924, %cst_558) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_559 = arith.constant 0.78539816339744828 : f64
    %926 = qlx.apply #qlx.action<pauli_rotation>(%862#0, %cst_559) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %927 = qlx.apply #qlx.action<h>(%926) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %928 = qlx.apply #qlx.action<h>(%883#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_560 = arith.constant 2.3561944901923448 : f64
    %929 = qlx.apply #qlx.action<pauli_rotation>(%928, %cst_560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %930 = qlx.apply #qlx.action<h>(%929) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_561 = arith.constant 0.78539816339744828 : f64
    %931:2 = qlx.apply #qlx.action<pauli_rotation>(%927, %930, %cst_561) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_562 = arith.constant 1.5707963267948966 : f64
    %932 = qlx.apply #qlx.action<pauli_rotation>(%931#0, %cst_562) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_563 = arith.constant 1.5707963267948966 : f64
    %933 = qlx.apply #qlx.action<pauli_rotation>(%931#1, %cst_563) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_564 = arith.constant 0.78539816339744828 : f64
    %934:2 = qlx.apply #qlx.action<pauli_rotation>(%932, %933, %cst_564) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %935 = qlx.apply #qlx.action<h>(%905#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_565 = arith.constant 2.3561944901923448 : f64
    %936 = qlx.apply #qlx.action<pauli_rotation>(%935, %cst_565) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %937 = qlx.apply #qlx.action<h>(%936) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %938 = qlx.apply #qlx.action<h>(%925#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_566 = arith.constant 2.3561944901923448 : f64
    %939 = qlx.apply #qlx.action<pauli_rotation>(%938, %cst_566) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %940 = qlx.apply #qlx.action<h>(%939) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_567 = arith.constant 0.78539816339744828 : f64
    %941:2 = qlx.apply #qlx.action<pauli_rotation>(%937, %940, %cst_567) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_568 = arith.constant 1.5707963267948966 : f64
    %942 = qlx.apply #qlx.action<pauli_rotation>(%941#0, %cst_568) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_569 = arith.constant 1.5707963267948966 : f64
    %943 = qlx.apply #qlx.action<pauli_rotation>(%941#1, %cst_569) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_570 = arith.constant 0.78539816339744828 : f64
    %944:2 = qlx.apply #qlx.action<pauli_rotation>(%942, %943, %cst_570) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %945 = qlx.apply #qlx.action<h>(%934#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_571 = arith.constant 2.3561944901923448 : f64
    %946 = qlx.apply #qlx.action<pauli_rotation>(%945, %cst_571) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %947 = qlx.apply #qlx.action<h>(%946) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %948 = qlx.apply #qlx.action<h>(%944#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_572 = arith.constant 0.78539816339744828 : f64
    %949 = qlx.apply #qlx.action<pauli_rotation>(%948, %cst_572) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %950 = qlx.apply #qlx.action<h>(%949) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_573 = arith.constant 1.250000e-01 : f64
    %951:2 = qlx.apply #qlx.action<pauli_rotation>(%947, %950, %cst_573) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_574 = arith.constant 1.5707963267948966 : f64
    %952 = qlx.apply #qlx.action<pauli_rotation>(%951#0, %cst_574) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_575 = arith.constant 1.5707963267948966 : f64
    %953 = qlx.apply #qlx.action<pauli_rotation>(%951#1, %cst_575) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_576 = arith.constant 1.250000e-01 : f64
    %954:2 = qlx.apply #qlx.action<pauli_rotation>(%952, %953, %cst_576) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %955 = qlx.apply #qlx.action<h>(%934#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_577 = arith.constant 1.5707963267948966 : f64
    %956 = qlx.apply #qlx.action<pauli_rotation>(%955, %cst_577) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %957 = qlx.apply #qlx.action<h>(%956) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %958 = qlx.apply #qlx.action<h>(%954#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_578 = arith.constant 0.78539816339744828 : f64
    %959 = qlx.apply #qlx.action<pauli_rotation>(%958, %cst_578) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %960 = qlx.apply #qlx.action<h>(%959) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_579 = arith.constant 0.78539816339744828 : f64
    %961:2 = qlx.apply #qlx.action<pauli_rotation>(%957, %960, %cst_579) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_580 = arith.constant 1.5707963267948966 : f64
    %962 = qlx.apply #qlx.action<pauli_rotation>(%961#0, %cst_580) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_581 = arith.constant 1.5707963267948966 : f64
    %963 = qlx.apply #qlx.action<pauli_rotation>(%961#1, %cst_581) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_582 = arith.constant 0.78539816339744828 : f64
    %964:2 = qlx.apply #qlx.action<pauli_rotation>(%962, %963, %cst_582) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %965 = qlx.apply #qlx.action<h>(%954#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_583 = arith.constant 2.3561944901923448 : f64
    %966 = qlx.apply #qlx.action<pauli_rotation>(%965, %cst_583) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %967 = qlx.apply #qlx.action<h>(%966) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %968 = qlx.apply #qlx.action<h>(%944#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_584 = arith.constant 1.5707963267948966 : f64
    %969 = qlx.apply #qlx.action<pauli_rotation>(%968, %cst_584) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %970 = qlx.apply #qlx.action<h>(%969) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_585 = arith.constant 0.78539816339744828 : f64
    %971:2 = qlx.apply #qlx.action<pauli_rotation>(%967, %970, %cst_585) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_586 = arith.constant 1.5707963267948966 : f64
    %972 = qlx.apply #qlx.action<pauli_rotation>(%971#0, %cst_586) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_587 = arith.constant 1.5707963267948966 : f64
    %973 = qlx.apply #qlx.action<pauli_rotation>(%971#1, %cst_587) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_588 = arith.constant 0.78539816339744828 : f64
    %974:2 = qlx.apply #qlx.action<pauli_rotation>(%972, %973, %cst_588) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %975 = qlx.apply #qlx.action<h>(%925#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_589 = arith.constant 2.3561944901923448 : f64
    %976 = qlx.apply #qlx.action<pauli_rotation>(%975, %cst_589) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %977 = qlx.apply #qlx.action<h>(%976) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %978 = qlx.apply #qlx.action<h>(%915#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_590 = arith.constant 2.3561944901923448 : f64
    %979 = qlx.apply #qlx.action<pauli_rotation>(%978, %cst_590) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %980 = qlx.apply #qlx.action<h>(%979) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_591 = arith.constant 0.78539816339744828 : f64
    %981:2 = qlx.apply #qlx.action<pauli_rotation>(%977, %980, %cst_591) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_592 = arith.constant 1.5707963267948966 : f64
    %982 = qlx.apply #qlx.action<pauli_rotation>(%981#0, %cst_592) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_593 = arith.constant 1.5707963267948966 : f64
    %983 = qlx.apply #qlx.action<pauli_rotation>(%981#1, %cst_593) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_594 = arith.constant 0.78539816339744828 : f64
    %984:2 = qlx.apply #qlx.action<pauli_rotation>(%982, %983, %cst_594) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %985 = qlx.apply #qlx.action<h>(%895#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_595 = arith.constant 2.3561944901923448 : f64
    %986 = qlx.apply #qlx.action<pauli_rotation>(%985, %cst_595) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %987 = qlx.apply #qlx.action<h>(%986) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_596 = arith.constant 0.78539816339744828 : f64
    %988 = qlx.apply #qlx.action<pauli_rotation>(%877#1, %cst_596) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %989 = qlx.apply #qlx.action<h>(%988) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_597 = arith.constant 0.78539816339744828 : f64
    %990:2 = qlx.apply #qlx.action<pauli_rotation>(%987, %989, %cst_597) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_598 = arith.constant 1.5707963267948966 : f64
    %991 = qlx.apply #qlx.action<pauli_rotation>(%990#0, %cst_598) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_599 = arith.constant 1.5707963267948966 : f64
    %992 = qlx.apply #qlx.action<pauli_rotation>(%990#1, %cst_599) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_600 = arith.constant 0.78539816339744828 : f64
    %993:2 = qlx.apply #qlx.action<pauli_rotation>(%991, %992, %cst_600) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %994 = qlx.apply #qlx.action<h>(%984#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_601 = arith.constant 2.3561944901923448 : f64
    %995 = qlx.apply #qlx.action<pauli_rotation>(%994, %cst_601) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %996 = qlx.apply #qlx.action<h>(%995) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %997 = qlx.apply #qlx.action<h>(%993#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_602 = arith.constant 0.78539816339744828 : f64
    %998 = qlx.apply #qlx.action<pauli_rotation>(%997, %cst_602) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %999 = qlx.apply #qlx.action<h>(%998) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_603 = arith.constant 1.250000e-01 : f64
    %1000:2 = qlx.apply #qlx.action<pauli_rotation>(%996, %999, %cst_603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_604 = arith.constant 1.5707963267948966 : f64
    %1001 = qlx.apply #qlx.action<pauli_rotation>(%1000#0, %cst_604) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_605 = arith.constant 1.5707963267948966 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1000#1, %cst_605) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_606 = arith.constant 1.250000e-01 : f64
    %1003:2 = qlx.apply #qlx.action<pauli_rotation>(%1001, %1002, %cst_606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1004 = qlx.apply #qlx.action<h>(%984#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_607 = arith.constant 1.5707963267948966 : f64
    %1005 = qlx.apply #qlx.action<pauli_rotation>(%1004, %cst_607) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1006 = qlx.apply #qlx.action<h>(%1005) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1007 = qlx.apply #qlx.action<h>(%1003#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_608 = arith.constant 0.78539816339744828 : f64
    %1008 = qlx.apply #qlx.action<pauli_rotation>(%1007, %cst_608) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1009 = qlx.apply #qlx.action<h>(%1008) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_609 = arith.constant 0.78539816339744828 : f64
    %1010:2 = qlx.apply #qlx.action<pauli_rotation>(%1006, %1009, %cst_609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_610 = arith.constant 1.5707963267948966 : f64
    %1011 = qlx.apply #qlx.action<pauli_rotation>(%1010#0, %cst_610) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_611 = arith.constant 1.5707963267948966 : f64
    %1012 = qlx.apply #qlx.action<pauli_rotation>(%1010#1, %cst_611) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_612 = arith.constant 0.78539816339744828 : f64
    %1013:2 = qlx.apply #qlx.action<pauli_rotation>(%1011, %1012, %cst_612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1014 = qlx.apply #qlx.action<h>(%1003#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_613 = arith.constant 2.3561944901923448 : f64
    %1015 = qlx.apply #qlx.action<pauli_rotation>(%1014, %cst_613) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1016 = qlx.apply #qlx.action<h>(%1015) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1017 = qlx.apply #qlx.action<h>(%993#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_614 = arith.constant 1.5707963267948966 : f64
    %1018 = qlx.apply #qlx.action<pauli_rotation>(%1017, %cst_614) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1019 = qlx.apply #qlx.action<h>(%1018) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_615 = arith.constant 0.78539816339744828 : f64
    %1020:2 = qlx.apply #qlx.action<pauli_rotation>(%1016, %1019, %cst_615) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_616 = arith.constant 1.5707963267948966 : f64
    %1021 = qlx.apply #qlx.action<pauli_rotation>(%1020#0, %cst_616) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_617 = arith.constant 1.5707963267948966 : f64
    %1022 = qlx.apply #qlx.action<pauli_rotation>(%1020#1, %cst_617) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_618 = arith.constant 0.78539816339744828 : f64
    %1023:2 = qlx.apply #qlx.action<pauli_rotation>(%1021, %1022, %cst_618) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1024 = qlx.apply #qlx.action<h>(%974#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_619 = arith.constant 2.3561944901923448 : f64
    %1025 = qlx.apply #qlx.action<pauli_rotation>(%1024, %cst_619) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1026 = qlx.apply #qlx.action<h>(%1025) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1027 = qlx.apply #qlx.action<h>(%1013#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_620 = arith.constant 2.3561944901923448 : f64
    %1028 = qlx.apply #qlx.action<pauli_rotation>(%1027, %cst_620) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1029 = qlx.apply #qlx.action<h>(%1028) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_621 = arith.constant 1.5707963267948966 : f64
    %1030:2 = qlx.apply #qlx.action<pauli_rotation>(%1026, %1029, %cst_621) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_622 = arith.constant 1.5707963267948966 : f64
    %1031 = qlx.apply #qlx.action<pauli_rotation>(%1030#0, %cst_622) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_623 = arith.constant 1.5707963267948966 : f64
    %1032 = qlx.apply #qlx.action<pauli_rotation>(%1030#1, %cst_623) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_624 = arith.constant 1.5707963267948966 : f64
    %1033:2 = qlx.apply #qlx.action<pauli_rotation>(%1031, %1032, %cst_624) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1034 = qlx.apply #qlx.action<h>(%974#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_625 = arith.constant 2.3561944901923448 : f64
    %1035 = qlx.apply #qlx.action<pauli_rotation>(%1034, %cst_625) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1036 = qlx.apply #qlx.action<h>(%1035) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1037 = qlx.apply #qlx.action<h>(%1033#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_626 = arith.constant 3.1415926535897931 : f64
    %1038 = qlx.apply #qlx.action<pauli_rotation>(%1037, %cst_626) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1039 = qlx.apply #qlx.action<h>(%1038) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_627 = arith.constant 1.5707963267948966 : f64
    %1040:2 = qlx.apply #qlx.action<pauli_rotation>(%1036, %1039, %cst_627) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_628 = arith.constant 1.5707963267948966 : f64
    %1041 = qlx.apply #qlx.action<pauli_rotation>(%1040#0, %cst_628) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_629 = arith.constant 1.5707963267948966 : f64
    %1042 = qlx.apply #qlx.action<pauli_rotation>(%1040#1, %cst_629) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_630 = arith.constant 1.5707963267948966 : f64
    %1043:2 = qlx.apply #qlx.action<pauli_rotation>(%1041, %1042, %cst_630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1044 = qlx.apply #qlx.action<h>(%1033#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_631 = arith.constant 3.1415926535897931 : f64
    %1045 = qlx.apply #qlx.action<pauli_rotation>(%1044, %cst_631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1046 = qlx.apply #qlx.action<h>(%1045) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1047 = qlx.apply #qlx.action<h>(%1013#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_632 = arith.constant 2.3561944901923448 : f64
    %1048 = qlx.apply #qlx.action<pauli_rotation>(%1047, %cst_632) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1049 = qlx.apply #qlx.action<h>(%1048) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_633 = arith.constant 1.5707963267948966 : f64
    %1050:2 = qlx.apply #qlx.action<pauli_rotation>(%1046, %1049, %cst_633) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_634 = arith.constant 1.5707963267948966 : f64
    %1051 = qlx.apply #qlx.action<pauli_rotation>(%1050#0, %cst_634) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_635 = arith.constant 1.5707963267948966 : f64
    %1052 = qlx.apply #qlx.action<pauli_rotation>(%1050#1, %cst_635) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_636 = arith.constant 1.5707963267948966 : f64
    %1053:2 = qlx.apply #qlx.action<pauli_rotation>(%1051, %1052, %cst_636) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1054 = qlx.apply #qlx.action<h>(%964#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_637 = arith.constant 2.3561944901923448 : f64
    %1055 = qlx.apply #qlx.action<pauli_rotation>(%1054, %cst_637) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1056 = qlx.apply #qlx.action<h>(%1055) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1057 = qlx.apply #qlx.action<h>(%1043#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_638 = arith.constant 3.1415926535897931 : f64
    %1058 = qlx.apply #qlx.action<pauli_rotation>(%1057, %cst_638) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1059 = qlx.apply #qlx.action<h>(%1058) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_639 = arith.constant 1.5707963267948966 : f64
    %1060:2 = qlx.apply #qlx.action<pauli_rotation>(%1056, %1059, %cst_639) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_640 = arith.constant 1.5707963267948966 : f64
    %1061 = qlx.apply #qlx.action<pauli_rotation>(%1060#0, %cst_640) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_641 = arith.constant 1.5707963267948966 : f64
    %1062 = qlx.apply #qlx.action<pauli_rotation>(%1060#1, %cst_641) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_642 = arith.constant 1.5707963267948966 : f64
    %1063:2 = qlx.apply #qlx.action<pauli_rotation>(%1061, %1062, %cst_642) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1064 = qlx.apply #qlx.action<h>(%1043#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_643 = arith.constant 3.1415926535897931 : f64
    %1065 = qlx.apply #qlx.action<pauli_rotation>(%1064, %cst_643) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1066 = qlx.apply #qlx.action<h>(%1065) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1067 = qlx.apply #qlx.action<h>(%1053#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_644 = arith.constant 3.1415926535897931 : f64
    %1068 = qlx.apply #qlx.action<pauli_rotation>(%1067, %cst_644) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1069 = qlx.apply #qlx.action<h>(%1068) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_645 = arith.constant 1.5707963267948966 : f64
    %1070:2 = qlx.apply #qlx.action<pauli_rotation>(%1066, %1069, %cst_645) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_646 = arith.constant 1.5707963267948966 : f64
    %1071 = qlx.apply #qlx.action<pauli_rotation>(%1070#0, %cst_646) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_647 = arith.constant 1.5707963267948966 : f64
    %1072 = qlx.apply #qlx.action<pauli_rotation>(%1070#1, %cst_647) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_648 = arith.constant 1.5707963267948966 : f64
    %1073:2 = qlx.apply #qlx.action<pauli_rotation>(%1071, %1072, %cst_648) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1074 = qlx.apply #qlx.action<h>(%1053#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_649 = arith.constant 3.1415926535897931 : f64
    %1075 = qlx.apply #qlx.action<pauli_rotation>(%1074, %cst_649) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1076 = qlx.apply #qlx.action<h>(%1075) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1077 = qlx.apply #qlx.action<h>(%1023#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_650 = arith.constant 2.3561944901923448 : f64
    %1078 = qlx.apply #qlx.action<pauli_rotation>(%1077, %cst_650) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1079 = qlx.apply #qlx.action<h>(%1078) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_651 = arith.constant 1.5707963267948966 : f64
    %1080:2 = qlx.apply #qlx.action<pauli_rotation>(%1076, %1079, %cst_651) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_652 = arith.constant 1.5707963267948966 : f64
    %1081 = qlx.apply #qlx.action<pauli_rotation>(%1080#0, %cst_652) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_653 = arith.constant 1.5707963267948966 : f64
    %1082 = qlx.apply #qlx.action<pauli_rotation>(%1080#1, %cst_653) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_654 = arith.constant 1.5707963267948966 : f64
    %1083:2 = qlx.apply #qlx.action<pauli_rotation>(%1081, %1082, %cst_654) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1084 = qlx.apply #qlx.action<h>(%964#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_655 = arith.constant 2.3561944901923448 : f64
    %1085 = qlx.apply #qlx.action<pauli_rotation>(%1084, %cst_655) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1086 = qlx.apply #qlx.action<h>(%1063#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_656 = arith.constant 3.1415926535897931 : f64
    %1087 = qlx.apply #qlx.action<pauli_rotation>(%1086, %cst_656) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_657 = arith.constant 1.250000e-01 : f64
    %1088:2 = qlx.apply #qlx.action<pauli_rotation>(%1085, %1087, %cst_657) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1089 = qlx.apply #qlx.action<h>(%1063#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_658 = arith.constant 3.1415926535897931 : f64
    %1090 = qlx.apply #qlx.action<pauli_rotation>(%1089, %cst_658) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1091 = qlx.apply #qlx.action<h>(%1073#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_659 = arith.constant 3.1415926535897931 : f64
    %1092 = qlx.apply #qlx.action<pauli_rotation>(%1091, %cst_659) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_660 = arith.constant 1.250000e-01 : f64
    %1093:2 = qlx.apply #qlx.action<pauli_rotation>(%1090, %1092, %cst_660) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1094 = qlx.apply #qlx.action<h>(%1073#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_661 = arith.constant 3.1415926535897931 : f64
    %1095 = qlx.apply #qlx.action<pauli_rotation>(%1094, %cst_661) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1096 = qlx.apply #qlx.action<h>(%1083#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_662 = arith.constant 3.1415926535897931 : f64
    %1097 = qlx.apply #qlx.action<pauli_rotation>(%1096, %cst_662) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_663 = arith.constant 1.250000e-01 : f64
    %1098:2 = qlx.apply #qlx.action<pauli_rotation>(%1095, %1097, %cst_663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1099 = qlx.apply #qlx.action<h>(%1083#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_664 = arith.constant 3.1415926535897931 : f64
    %1100 = qlx.apply #qlx.action<pauli_rotation>(%1099, %cst_664) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1101 = qlx.apply #qlx.action<h>(%1023#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_665 = arith.constant 2.3561944901923448 : f64
    %1102 = qlx.apply #qlx.action<pauli_rotation>(%1101, %cst_665) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_666 = arith.constant 1.250000e-01 : f64
    %1103:2 = qlx.apply #qlx.action<pauli_rotation>(%1100, %1102, %cst_666) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1104 = qlx.apply #qlx.action<h>(%1088#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1105 = qlx.apply #qlx.action<h>(%1093#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_667 = arith.constant 1.5707963267948966 : f64
    %1106:2 = qlx.apply #qlx.action<pauli_rotation>(%1104, %1105, %cst_667) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_668 = arith.constant 1.5707963267948966 : f64
    %1107 = qlx.apply #qlx.action<pauli_rotation>(%1106#0, %cst_668) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_669 = arith.constant 1.5707963267948966 : f64
    %1108 = qlx.apply #qlx.action<pauli_rotation>(%1106#1, %cst_669) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_670 = arith.constant 1.5707963267948966 : f64
    %1109:2 = qlx.apply #qlx.action<pauli_rotation>(%1107, %1108, %cst_670) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1110 = qlx.apply #qlx.action<h>(%1093#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1111 = qlx.apply #qlx.action<h>(%1098#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_671 = arith.constant 1.5707963267948966 : f64
    %1112:2 = qlx.apply #qlx.action<pauli_rotation>(%1110, %1111, %cst_671) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_672 = arith.constant 1.5707963267948966 : f64
    %1113 = qlx.apply #qlx.action<pauli_rotation>(%1112#0, %cst_672) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_673 = arith.constant 1.5707963267948966 : f64
    %1114 = qlx.apply #qlx.action<pauli_rotation>(%1112#1, %cst_673) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_674 = arith.constant 1.5707963267948966 : f64
    %1115:2 = qlx.apply #qlx.action<pauli_rotation>(%1113, %1114, %cst_674) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1116 = qlx.apply #qlx.action<h>(%1098#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1117 = qlx.apply #qlx.action<h>(%1103#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_675 = arith.constant 1.5707963267948966 : f64
    %1118:2 = qlx.apply #qlx.action<pauli_rotation>(%1116, %1117, %cst_675) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_676 = arith.constant 1.5707963267948966 : f64
    %1119 = qlx.apply #qlx.action<pauli_rotation>(%1118#0, %cst_676) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_677 = arith.constant 1.5707963267948966 : f64
    %1120 = qlx.apply #qlx.action<pauli_rotation>(%1118#1, %cst_677) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_678 = arith.constant 1.5707963267948966 : f64
    %1121:2 = qlx.apply #qlx.action<pauli_rotation>(%1119, %1120, %cst_678) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1122 = qlx.apply #qlx.action<h>(%1109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_679 = arith.constant 3.1415926535897931 : f64
    %1123 = qlx.apply #qlx.action<pauli_rotation>(%1122, %cst_679) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1124 = qlx.apply #qlx.action<h>(%1123) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1125 = qlx.apply #qlx.action<h>(%1115#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_680 = arith.constant 3.1415926535897931 : f64
    %1126 = qlx.apply #qlx.action<pauli_rotation>(%1125, %cst_680) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1127 = qlx.apply #qlx.action<h>(%1126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_681 = arith.constant 1.5707963267948966 : f64
    %1128:2 = qlx.apply #qlx.action<pauli_rotation>(%1124, %1127, %cst_681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_682 = arith.constant 1.5707963267948966 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1128#0, %cst_682) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_683 = arith.constant 1.5707963267948966 : f64
    %1130 = qlx.apply #qlx.action<pauli_rotation>(%1128#1, %cst_683) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_684 = arith.constant 1.5707963267948966 : f64
    %1131:2 = qlx.apply #qlx.action<pauli_rotation>(%1129, %1130, %cst_684) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1132 = qlx.apply #qlx.action<h>(%1115#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_685 = arith.constant 3.1415926535897931 : f64
    %1133 = qlx.apply #qlx.action<pauli_rotation>(%1132, %cst_685) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1134 = qlx.apply #qlx.action<h>(%1133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1135 = qlx.apply #qlx.action<h>(%1121#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_686 = arith.constant 3.1415926535897931 : f64
    %1136 = qlx.apply #qlx.action<pauli_rotation>(%1135, %cst_686) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1137 = qlx.apply #qlx.action<h>(%1136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_687 = arith.constant 1.5707963267948966 : f64
    %1138:2 = qlx.apply #qlx.action<pauli_rotation>(%1134, %1137, %cst_687) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_688 = arith.constant 1.5707963267948966 : f64
    %1139 = qlx.apply #qlx.action<pauli_rotation>(%1138#0, %cst_688) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_689 = arith.constant 1.5707963267948966 : f64
    %1140 = qlx.apply #qlx.action<pauli_rotation>(%1138#1, %cst_689) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_690 = arith.constant 1.5707963267948966 : f64
    %1141:2 = qlx.apply #qlx.action<pauli_rotation>(%1139, %1140, %cst_690) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1142 = qlx.apply #qlx.action<h>(%1131#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_691 = arith.constant 3.1415926535897931 : f64
    %1143 = qlx.apply #qlx.action<pauli_rotation>(%1142, %cst_691) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1144 = qlx.apply #qlx.action<h>(%1143) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1145 = qlx.apply #qlx.action<h>(%1141#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_692 = arith.constant 3.1415926535897931 : f64
    %1146 = qlx.apply #qlx.action<pauli_rotation>(%1145, %cst_692) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1147 = qlx.apply #qlx.action<h>(%1146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_693 = arith.constant 1.5707963267948966 : f64
    %1148:2 = qlx.apply #qlx.action<pauli_rotation>(%1144, %1147, %cst_693) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_694 = arith.constant 1.5707963267948966 : f64
    %1149 = qlx.apply #qlx.action<pauli_rotation>(%1148#0, %cst_694) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_695 = arith.constant 1.5707963267948966 : f64
    %1150 = qlx.apply #qlx.action<pauli_rotation>(%1148#1, %cst_695) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_696 = arith.constant 1.5707963267948966 : f64
    %1151:2 = qlx.apply #qlx.action<pauli_rotation>(%1149, %1150, %cst_696) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_697 = arith.constant 0.78539816339744828 : f64
    %1152 = qlx.apply #qlx.action<pauli_rotation>(%1088#0, %cst_697) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1153 = qlx.apply #qlx.action<h>(%1152) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1154 = qlx.apply #qlx.action<h>(%1109#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_698 = arith.constant 2.3561944901923448 : f64
    %1155 = qlx.apply #qlx.action<pauli_rotation>(%1154, %cst_698) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1156 = qlx.apply #qlx.action<h>(%1155) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_699 = arith.constant 0.78539816339744828 : f64
    %1157:2 = qlx.apply #qlx.action<pauli_rotation>(%1153, %1156, %cst_699) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_700 = arith.constant 1.5707963267948966 : f64
    %1158 = qlx.apply #qlx.action<pauli_rotation>(%1157#0, %cst_700) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_701 = arith.constant 1.5707963267948966 : f64
    %1159 = qlx.apply #qlx.action<pauli_rotation>(%1157#1, %cst_701) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_702 = arith.constant 0.78539816339744828 : f64
    %1160:2 = qlx.apply #qlx.action<pauli_rotation>(%1158, %1159, %cst_702) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1161 = qlx.apply #qlx.action<h>(%1131#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_703 = arith.constant 2.3561944901923448 : f64
    %1162 = qlx.apply #qlx.action<pauli_rotation>(%1161, %cst_703) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1163 = qlx.apply #qlx.action<h>(%1162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1164 = qlx.apply #qlx.action<h>(%1151#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_704 = arith.constant 2.3561944901923448 : f64
    %1165 = qlx.apply #qlx.action<pauli_rotation>(%1164, %cst_704) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1166 = qlx.apply #qlx.action<h>(%1165) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_705 = arith.constant 0.78539816339744828 : f64
    %1167:2 = qlx.apply #qlx.action<pauli_rotation>(%1163, %1166, %cst_705) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_706 = arith.constant 1.5707963267948966 : f64
    %1168 = qlx.apply #qlx.action<pauli_rotation>(%1167#0, %cst_706) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_707 = arith.constant 1.5707963267948966 : f64
    %1169 = qlx.apply #qlx.action<pauli_rotation>(%1167#1, %cst_707) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_708 = arith.constant 0.78539816339744828 : f64
    %1170:2 = qlx.apply #qlx.action<pauli_rotation>(%1168, %1169, %cst_708) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1171 = qlx.apply #qlx.action<h>(%1160#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_709 = arith.constant 2.3561944901923448 : f64
    %1172 = qlx.apply #qlx.action<pauli_rotation>(%1171, %cst_709) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1173 = qlx.apply #qlx.action<h>(%1172) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1174 = qlx.apply #qlx.action<h>(%1170#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_710 = arith.constant 0.78539816339744828 : f64
    %1175 = qlx.apply #qlx.action<pauli_rotation>(%1174, %cst_710) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1176 = qlx.apply #qlx.action<h>(%1175) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_711 = arith.constant 1.250000e-01 : f64
    %1177:2 = qlx.apply #qlx.action<pauli_rotation>(%1173, %1176, %cst_711) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_712 = arith.constant 1.5707963267948966 : f64
    %1178 = qlx.apply #qlx.action<pauli_rotation>(%1177#0, %cst_712) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_713 = arith.constant 1.5707963267948966 : f64
    %1179 = qlx.apply #qlx.action<pauli_rotation>(%1177#1, %cst_713) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_714 = arith.constant 1.250000e-01 : f64
    %1180:2 = qlx.apply #qlx.action<pauli_rotation>(%1178, %1179, %cst_714) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1181 = qlx.apply #qlx.action<h>(%1160#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_715 = arith.constant 1.5707963267948966 : f64
    %1182 = qlx.apply #qlx.action<pauli_rotation>(%1181, %cst_715) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1183 = qlx.apply #qlx.action<h>(%1182) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1184 = qlx.apply #qlx.action<h>(%1180#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_716 = arith.constant 0.78539816339744828 : f64
    %1185 = qlx.apply #qlx.action<pauli_rotation>(%1184, %cst_716) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1186 = qlx.apply #qlx.action<h>(%1185) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_717 = arith.constant 0.78539816339744828 : f64
    %1187:2 = qlx.apply #qlx.action<pauli_rotation>(%1183, %1186, %cst_717) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_718 = arith.constant 1.5707963267948966 : f64
    %1188 = qlx.apply #qlx.action<pauli_rotation>(%1187#0, %cst_718) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_719 = arith.constant 1.5707963267948966 : f64
    %1189 = qlx.apply #qlx.action<pauli_rotation>(%1187#1, %cst_719) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_720 = arith.constant 0.78539816339744828 : f64
    %1190:2 = qlx.apply #qlx.action<pauli_rotation>(%1188, %1189, %cst_720) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1191 = qlx.apply #qlx.action<h>(%1180#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_721 = arith.constant 2.3561944901923448 : f64
    %1192 = qlx.apply #qlx.action<pauli_rotation>(%1191, %cst_721) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1193 = qlx.apply #qlx.action<h>(%1192) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1194 = qlx.apply #qlx.action<h>(%1170#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_722 = arith.constant 1.5707963267948966 : f64
    %1195 = qlx.apply #qlx.action<pauli_rotation>(%1194, %cst_722) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1196 = qlx.apply #qlx.action<h>(%1195) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_723 = arith.constant 0.78539816339744828 : f64
    %1197:2 = qlx.apply #qlx.action<pauli_rotation>(%1193, %1196, %cst_723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_724 = arith.constant 1.5707963267948966 : f64
    %1198 = qlx.apply #qlx.action<pauli_rotation>(%1197#0, %cst_724) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_725 = arith.constant 1.5707963267948966 : f64
    %1199 = qlx.apply #qlx.action<pauli_rotation>(%1197#1, %cst_725) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_726 = arith.constant 0.78539816339744828 : f64
    %1200:2 = qlx.apply #qlx.action<pauli_rotation>(%1198, %1199, %cst_726) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1201 = qlx.apply #qlx.action<h>(%1151#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_727 = arith.constant 2.3561944901923448 : f64
    %1202 = qlx.apply #qlx.action<pauli_rotation>(%1201, %cst_727) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1203 = qlx.apply #qlx.action<h>(%1202) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1204 = qlx.apply #qlx.action<h>(%1141#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_728 = arith.constant 2.3561944901923448 : f64
    %1205 = qlx.apply #qlx.action<pauli_rotation>(%1204, %cst_728) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1206 = qlx.apply #qlx.action<h>(%1205) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_729 = arith.constant 0.78539816339744828 : f64
    %1207:2 = qlx.apply #qlx.action<pauli_rotation>(%1203, %1206, %cst_729) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_730 = arith.constant 1.5707963267948966 : f64
    %1208 = qlx.apply #qlx.action<pauli_rotation>(%1207#0, %cst_730) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_731 = arith.constant 1.5707963267948966 : f64
    %1209 = qlx.apply #qlx.action<pauli_rotation>(%1207#1, %cst_731) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_732 = arith.constant 0.78539816339744828 : f64
    %1210:2 = qlx.apply #qlx.action<pauli_rotation>(%1208, %1209, %cst_732) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1211 = qlx.apply #qlx.action<h>(%1121#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_733 = arith.constant 2.3561944901923448 : f64
    %1212 = qlx.apply #qlx.action<pauli_rotation>(%1211, %cst_733) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1213 = qlx.apply #qlx.action<h>(%1212) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_734 = arith.constant 0.78539816339744828 : f64
    %1214 = qlx.apply #qlx.action<pauli_rotation>(%1103#1, %cst_734) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1215 = qlx.apply #qlx.action<h>(%1214) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_735 = arith.constant 0.78539816339744828 : f64
    %1216:2 = qlx.apply #qlx.action<pauli_rotation>(%1213, %1215, %cst_735) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_736 = arith.constant 1.5707963267948966 : f64
    %1217 = qlx.apply #qlx.action<pauli_rotation>(%1216#0, %cst_736) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_737 = arith.constant 1.5707963267948966 : f64
    %1218 = qlx.apply #qlx.action<pauli_rotation>(%1216#1, %cst_737) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_738 = arith.constant 0.78539816339744828 : f64
    %1219:2 = qlx.apply #qlx.action<pauli_rotation>(%1217, %1218, %cst_738) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1220 = qlx.apply #qlx.action<h>(%1210#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_739 = arith.constant 2.3561944901923448 : f64
    %1221 = qlx.apply #qlx.action<pauli_rotation>(%1220, %cst_739) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1222 = qlx.apply #qlx.action<h>(%1221) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1223 = qlx.apply #qlx.action<h>(%1219#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_740 = arith.constant 0.78539816339744828 : f64
    %1224 = qlx.apply #qlx.action<pauli_rotation>(%1223, %cst_740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1225 = qlx.apply #qlx.action<h>(%1224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_741 = arith.constant 1.250000e-01 : f64
    %1226:2 = qlx.apply #qlx.action<pauli_rotation>(%1222, %1225, %cst_741) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_742 = arith.constant 1.5707963267948966 : f64
    %1227 = qlx.apply #qlx.action<pauli_rotation>(%1226#0, %cst_742) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_743 = arith.constant 1.5707963267948966 : f64
    %1228 = qlx.apply #qlx.action<pauli_rotation>(%1226#1, %cst_743) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_744 = arith.constant 1.250000e-01 : f64
    %1229:2 = qlx.apply #qlx.action<pauli_rotation>(%1227, %1228, %cst_744) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1230 = qlx.apply #qlx.action<h>(%1210#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_745 = arith.constant 1.5707963267948966 : f64
    %1231 = qlx.apply #qlx.action<pauli_rotation>(%1230, %cst_745) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1232 = qlx.apply #qlx.action<h>(%1231) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1233 = qlx.apply #qlx.action<h>(%1229#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_746 = arith.constant 0.78539816339744828 : f64
    %1234 = qlx.apply #qlx.action<pauli_rotation>(%1233, %cst_746) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1235 = qlx.apply #qlx.action<h>(%1234) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_747 = arith.constant 0.78539816339744828 : f64
    %1236:2 = qlx.apply #qlx.action<pauli_rotation>(%1232, %1235, %cst_747) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_748 = arith.constant 1.5707963267948966 : f64
    %1237 = qlx.apply #qlx.action<pauli_rotation>(%1236#0, %cst_748) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_749 = arith.constant 1.5707963267948966 : f64
    %1238 = qlx.apply #qlx.action<pauli_rotation>(%1236#1, %cst_749) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_750 = arith.constant 0.78539816339744828 : f64
    %1239:2 = qlx.apply #qlx.action<pauli_rotation>(%1237, %1238, %cst_750) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1240 = qlx.apply #qlx.action<h>(%1229#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_751 = arith.constant 2.3561944901923448 : f64
    %1241 = qlx.apply #qlx.action<pauli_rotation>(%1240, %cst_751) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1242 = qlx.apply #qlx.action<h>(%1241) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1243 = qlx.apply #qlx.action<h>(%1219#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_752 = arith.constant 1.5707963267948966 : f64
    %1244 = qlx.apply #qlx.action<pauli_rotation>(%1243, %cst_752) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1245 = qlx.apply #qlx.action<h>(%1244) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_753 = arith.constant 0.78539816339744828 : f64
    %1246:2 = qlx.apply #qlx.action<pauli_rotation>(%1242, %1245, %cst_753) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_754 = arith.constant 1.5707963267948966 : f64
    %1247 = qlx.apply #qlx.action<pauli_rotation>(%1246#0, %cst_754) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_755 = arith.constant 1.5707963267948966 : f64
    %1248 = qlx.apply #qlx.action<pauli_rotation>(%1246#1, %cst_755) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_756 = arith.constant 0.78539816339744828 : f64
    %1249:2 = qlx.apply #qlx.action<pauli_rotation>(%1247, %1248, %cst_756) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1250 = qlx.apply #qlx.action<h>(%1200#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_757 = arith.constant 2.3561944901923448 : f64
    %1251 = qlx.apply #qlx.action<pauli_rotation>(%1250, %cst_757) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1252 = qlx.apply #qlx.action<h>(%1251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1253 = qlx.apply #qlx.action<h>(%1239#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_758 = arith.constant 2.3561944901923448 : f64
    %1254 = qlx.apply #qlx.action<pauli_rotation>(%1253, %cst_758) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1255 = qlx.apply #qlx.action<h>(%1254) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_759 = arith.constant 1.5707963267948966 : f64
    %1256:2 = qlx.apply #qlx.action<pauli_rotation>(%1252, %1255, %cst_759) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_760 = arith.constant 1.5707963267948966 : f64
    %1257 = qlx.apply #qlx.action<pauli_rotation>(%1256#0, %cst_760) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_761 = arith.constant 1.5707963267948966 : f64
    %1258 = qlx.apply #qlx.action<pauli_rotation>(%1256#1, %cst_761) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_762 = arith.constant 1.5707963267948966 : f64
    %1259:2 = qlx.apply #qlx.action<pauli_rotation>(%1257, %1258, %cst_762) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1260 = qlx.apply #qlx.action<h>(%1200#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_763 = arith.constant 2.3561944901923448 : f64
    %1261 = qlx.apply #qlx.action<pauli_rotation>(%1260, %cst_763) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1262 = qlx.apply #qlx.action<h>(%1261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1263 = qlx.apply #qlx.action<h>(%1259#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_764 = arith.constant 3.1415926535897931 : f64
    %1264 = qlx.apply #qlx.action<pauli_rotation>(%1263, %cst_764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1265 = qlx.apply #qlx.action<h>(%1264) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_765 = arith.constant 1.5707963267948966 : f64
    %1266:2 = qlx.apply #qlx.action<pauli_rotation>(%1262, %1265, %cst_765) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_766 = arith.constant 1.5707963267948966 : f64
    %1267 = qlx.apply #qlx.action<pauli_rotation>(%1266#0, %cst_766) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_767 = arith.constant 1.5707963267948966 : f64
    %1268 = qlx.apply #qlx.action<pauli_rotation>(%1266#1, %cst_767) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_768 = arith.constant 1.5707963267948966 : f64
    %1269:2 = qlx.apply #qlx.action<pauli_rotation>(%1267, %1268, %cst_768) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1270 = qlx.apply #qlx.action<h>(%1259#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_769 = arith.constant 3.1415926535897931 : f64
    %1271 = qlx.apply #qlx.action<pauli_rotation>(%1270, %cst_769) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1272 = qlx.apply #qlx.action<h>(%1271) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1273 = qlx.apply #qlx.action<h>(%1239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_770 = arith.constant 2.3561944901923448 : f64
    %1274 = qlx.apply #qlx.action<pauli_rotation>(%1273, %cst_770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1275 = qlx.apply #qlx.action<h>(%1274) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_771 = arith.constant 1.5707963267948966 : f64
    %1276:2 = qlx.apply #qlx.action<pauli_rotation>(%1272, %1275, %cst_771) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_772 = arith.constant 1.5707963267948966 : f64
    %1277 = qlx.apply #qlx.action<pauli_rotation>(%1276#0, %cst_772) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_773 = arith.constant 1.5707963267948966 : f64
    %1278 = qlx.apply #qlx.action<pauli_rotation>(%1276#1, %cst_773) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_774 = arith.constant 1.5707963267948966 : f64
    %1279:2 = qlx.apply #qlx.action<pauli_rotation>(%1277, %1278, %cst_774) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1280 = qlx.apply #qlx.action<h>(%1190#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_775 = arith.constant 2.3561944901923448 : f64
    %1281 = qlx.apply #qlx.action<pauli_rotation>(%1280, %cst_775) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1282 = qlx.apply #qlx.action<h>(%1281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1283 = qlx.apply #qlx.action<h>(%1269#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_776 = arith.constant 3.1415926535897931 : f64
    %1284 = qlx.apply #qlx.action<pauli_rotation>(%1283, %cst_776) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1285 = qlx.apply #qlx.action<h>(%1284) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_777 = arith.constant 1.5707963267948966 : f64
    %1286:2 = qlx.apply #qlx.action<pauli_rotation>(%1282, %1285, %cst_777) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_778 = arith.constant 1.5707963267948966 : f64
    %1287 = qlx.apply #qlx.action<pauli_rotation>(%1286#0, %cst_778) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_779 = arith.constant 1.5707963267948966 : f64
    %1288 = qlx.apply #qlx.action<pauli_rotation>(%1286#1, %cst_779) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_780 = arith.constant 1.5707963267948966 : f64
    %1289:2 = qlx.apply #qlx.action<pauli_rotation>(%1287, %1288, %cst_780) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1290 = qlx.apply #qlx.action<h>(%1269#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_781 = arith.constant 3.1415926535897931 : f64
    %1291 = qlx.apply #qlx.action<pauli_rotation>(%1290, %cst_781) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1292 = qlx.apply #qlx.action<h>(%1291) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1293 = qlx.apply #qlx.action<h>(%1279#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_782 = arith.constant 3.1415926535897931 : f64
    %1294 = qlx.apply #qlx.action<pauli_rotation>(%1293, %cst_782) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1295 = qlx.apply #qlx.action<h>(%1294) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_783 = arith.constant 1.5707963267948966 : f64
    %1296:2 = qlx.apply #qlx.action<pauli_rotation>(%1292, %1295, %cst_783) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_784 = arith.constant 1.5707963267948966 : f64
    %1297 = qlx.apply #qlx.action<pauli_rotation>(%1296#0, %cst_784) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_785 = arith.constant 1.5707963267948966 : f64
    %1298 = qlx.apply #qlx.action<pauli_rotation>(%1296#1, %cst_785) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_786 = arith.constant 1.5707963267948966 : f64
    %1299:2 = qlx.apply #qlx.action<pauli_rotation>(%1297, %1298, %cst_786) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1300 = qlx.apply #qlx.action<h>(%1279#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_787 = arith.constant 3.1415926535897931 : f64
    %1301 = qlx.apply #qlx.action<pauli_rotation>(%1300, %cst_787) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1302 = qlx.apply #qlx.action<h>(%1301) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1303 = qlx.apply #qlx.action<h>(%1249#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_788 = arith.constant 2.3561944901923448 : f64
    %1304 = qlx.apply #qlx.action<pauli_rotation>(%1303, %cst_788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1305 = qlx.apply #qlx.action<h>(%1304) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_789 = arith.constant 1.5707963267948966 : f64
    %1306:2 = qlx.apply #qlx.action<pauli_rotation>(%1302, %1305, %cst_789) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_790 = arith.constant 1.5707963267948966 : f64
    %1307 = qlx.apply #qlx.action<pauli_rotation>(%1306#0, %cst_790) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_791 = arith.constant 1.5707963267948966 : f64
    %1308 = qlx.apply #qlx.action<pauli_rotation>(%1306#1, %cst_791) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_792 = arith.constant 1.5707963267948966 : f64
    %1309:2 = qlx.apply #qlx.action<pauli_rotation>(%1307, %1308, %cst_792) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1310 = qlx.apply #qlx.action<h>(%1190#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_793 = arith.constant 2.3561944901923448 : f64
    %1311 = qlx.apply #qlx.action<pauli_rotation>(%1310, %cst_793) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1312 = qlx.apply #qlx.action<h>(%1289#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_794 = arith.constant 3.1415926535897931 : f64
    %1313 = qlx.apply #qlx.action<pauli_rotation>(%1312, %cst_794) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_795 = arith.constant 1.250000e-01 : f64
    %1314:2 = qlx.apply #qlx.action<pauli_rotation>(%1311, %1313, %cst_795) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1315 = qlx.apply #qlx.action<h>(%1289#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_796 = arith.constant 3.1415926535897931 : f64
    %1316 = qlx.apply #qlx.action<pauli_rotation>(%1315, %cst_796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1317 = qlx.apply #qlx.action<h>(%1299#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_797 = arith.constant 3.1415926535897931 : f64
    %1318 = qlx.apply #qlx.action<pauli_rotation>(%1317, %cst_797) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_798 = arith.constant 1.250000e-01 : f64
    %1319:2 = qlx.apply #qlx.action<pauli_rotation>(%1316, %1318, %cst_798) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1320 = qlx.apply #qlx.action<h>(%1299#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_799 = arith.constant 3.1415926535897931 : f64
    %1321 = qlx.apply #qlx.action<pauli_rotation>(%1320, %cst_799) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1322 = qlx.apply #qlx.action<h>(%1309#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_800 = arith.constant 3.1415926535897931 : f64
    %1323 = qlx.apply #qlx.action<pauli_rotation>(%1322, %cst_800) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_801 = arith.constant 1.250000e-01 : f64
    %1324:2 = qlx.apply #qlx.action<pauli_rotation>(%1321, %1323, %cst_801) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1325 = qlx.apply #qlx.action<h>(%1309#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_802 = arith.constant 3.1415926535897931 : f64
    %1326 = qlx.apply #qlx.action<pauli_rotation>(%1325, %cst_802) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1327 = qlx.apply #qlx.action<h>(%1249#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_803 = arith.constant 2.3561944901923448 : f64
    %1328 = qlx.apply #qlx.action<pauli_rotation>(%1327, %cst_803) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_804 = arith.constant 1.250000e-01 : f64
    %1329:2 = qlx.apply #qlx.action<pauli_rotation>(%1326, %1328, %cst_804) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1330 = qlx.apply #qlx.action<h>(%1314#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1331 = qlx.apply #qlx.action<h>(%1319#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_805 = arith.constant 1.5707963267948966 : f64
    %1332:2 = qlx.apply #qlx.action<pauli_rotation>(%1330, %1331, %cst_805) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_806 = arith.constant 1.5707963267948966 : f64
    %1333 = qlx.apply #qlx.action<pauli_rotation>(%1332#0, %cst_806) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_807 = arith.constant 1.5707963267948966 : f64
    %1334 = qlx.apply #qlx.action<pauli_rotation>(%1332#1, %cst_807) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_808 = arith.constant 1.5707963267948966 : f64
    %1335:2 = qlx.apply #qlx.action<pauli_rotation>(%1333, %1334, %cst_808) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1336 = qlx.apply #qlx.action<h>(%1319#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1337 = qlx.apply #qlx.action<h>(%1324#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_809 = arith.constant 1.5707963267948966 : f64
    %1338:2 = qlx.apply #qlx.action<pauli_rotation>(%1336, %1337, %cst_809) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_810 = arith.constant 1.5707963267948966 : f64
    %1339 = qlx.apply #qlx.action<pauli_rotation>(%1338#0, %cst_810) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_811 = arith.constant 1.5707963267948966 : f64
    %1340 = qlx.apply #qlx.action<pauli_rotation>(%1338#1, %cst_811) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_812 = arith.constant 1.5707963267948966 : f64
    %1341:2 = qlx.apply #qlx.action<pauli_rotation>(%1339, %1340, %cst_812) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1342 = qlx.apply #qlx.action<h>(%1324#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1343 = qlx.apply #qlx.action<h>(%1329#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_813 = arith.constant 1.5707963267948966 : f64
    %1344:2 = qlx.apply #qlx.action<pauli_rotation>(%1342, %1343, %cst_813) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_814 = arith.constant 1.5707963267948966 : f64
    %1345 = qlx.apply #qlx.action<pauli_rotation>(%1344#0, %cst_814) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_815 = arith.constant 1.5707963267948966 : f64
    %1346 = qlx.apply #qlx.action<pauli_rotation>(%1344#1, %cst_815) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_816 = arith.constant 1.5707963267948966 : f64
    %1347:2 = qlx.apply #qlx.action<pauli_rotation>(%1345, %1346, %cst_816) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1348 = qlx.apply #qlx.action<h>(%1335#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_817 = arith.constant 3.1415926535897931 : f64
    %1349 = qlx.apply #qlx.action<pauli_rotation>(%1348, %cst_817) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1350 = qlx.apply #qlx.action<h>(%1349) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1351 = qlx.apply #qlx.action<h>(%1341#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_818 = arith.constant 3.1415926535897931 : f64
    %1352 = qlx.apply #qlx.action<pauli_rotation>(%1351, %cst_818) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1353 = qlx.apply #qlx.action<h>(%1352) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_819 = arith.constant 1.5707963267948966 : f64
    %1354:2 = qlx.apply #qlx.action<pauli_rotation>(%1350, %1353, %cst_819) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_820 = arith.constant 1.5707963267948966 : f64
    %1355 = qlx.apply #qlx.action<pauli_rotation>(%1354#0, %cst_820) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_821 = arith.constant 1.5707963267948966 : f64
    %1356 = qlx.apply #qlx.action<pauli_rotation>(%1354#1, %cst_821) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_822 = arith.constant 1.5707963267948966 : f64
    %1357:2 = qlx.apply #qlx.action<pauli_rotation>(%1355, %1356, %cst_822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1358 = qlx.apply #qlx.action<h>(%1341#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_823 = arith.constant 3.1415926535897931 : f64
    %1359 = qlx.apply #qlx.action<pauli_rotation>(%1358, %cst_823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1360 = qlx.apply #qlx.action<h>(%1359) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1361 = qlx.apply #qlx.action<h>(%1347#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_824 = arith.constant 3.1415926535897931 : f64
    %1362 = qlx.apply #qlx.action<pauli_rotation>(%1361, %cst_824) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1363 = qlx.apply #qlx.action<h>(%1362) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_825 = arith.constant 1.5707963267948966 : f64
    %1364:2 = qlx.apply #qlx.action<pauli_rotation>(%1360, %1363, %cst_825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_826 = arith.constant 1.5707963267948966 : f64
    %1365 = qlx.apply #qlx.action<pauli_rotation>(%1364#0, %cst_826) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_827 = arith.constant 1.5707963267948966 : f64
    %1366 = qlx.apply #qlx.action<pauli_rotation>(%1364#1, %cst_827) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_828 = arith.constant 1.5707963267948966 : f64
    %1367:2 = qlx.apply #qlx.action<pauli_rotation>(%1365, %1366, %cst_828) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1368 = qlx.apply #qlx.action<h>(%1357#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_829 = arith.constant 3.1415926535897931 : f64
    %1369 = qlx.apply #qlx.action<pauli_rotation>(%1368, %cst_829) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1370 = qlx.apply #qlx.action<h>(%1369) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1371 = qlx.apply #qlx.action<h>(%1367#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_830 = arith.constant 3.1415926535897931 : f64
    %1372 = qlx.apply #qlx.action<pauli_rotation>(%1371, %cst_830) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1373 = qlx.apply #qlx.action<h>(%1372) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_831 = arith.constant 1.5707963267948966 : f64
    %1374:2 = qlx.apply #qlx.action<pauli_rotation>(%1370, %1373, %cst_831) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_832 = arith.constant 1.5707963267948966 : f64
    %1375 = qlx.apply #qlx.action<pauli_rotation>(%1374#0, %cst_832) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_833 = arith.constant 1.5707963267948966 : f64
    %1376 = qlx.apply #qlx.action<pauli_rotation>(%1374#1, %cst_833) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_834 = arith.constant 1.5707963267948966 : f64
    %1377:2 = qlx.apply #qlx.action<pauli_rotation>(%1375, %1376, %cst_834) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_835 = arith.constant 0.78539816339744828 : f64
    %1378 = qlx.apply #qlx.action<pauli_rotation>(%1314#0, %cst_835) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1379 = qlx.apply #qlx.action<h>(%1378) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1380 = qlx.apply #qlx.action<h>(%1335#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_836 = arith.constant 2.3561944901923448 : f64
    %1381 = qlx.apply #qlx.action<pauli_rotation>(%1380, %cst_836) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1382 = qlx.apply #qlx.action<h>(%1381) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_837 = arith.constant 0.78539816339744828 : f64
    %1383:2 = qlx.apply #qlx.action<pauli_rotation>(%1379, %1382, %cst_837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_838 = arith.constant 1.5707963267948966 : f64
    %1384 = qlx.apply #qlx.action<pauli_rotation>(%1383#0, %cst_838) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_839 = arith.constant 1.5707963267948966 : f64
    %1385 = qlx.apply #qlx.action<pauli_rotation>(%1383#1, %cst_839) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_840 = arith.constant 0.78539816339744828 : f64
    %1386:2 = qlx.apply #qlx.action<pauli_rotation>(%1384, %1385, %cst_840) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1387 = qlx.apply #qlx.action<h>(%1357#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_841 = arith.constant 2.3561944901923448 : f64
    %1388 = qlx.apply #qlx.action<pauli_rotation>(%1387, %cst_841) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1389 = qlx.apply #qlx.action<h>(%1388) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1390 = qlx.apply #qlx.action<h>(%1377#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_842 = arith.constant 2.3561944901923448 : f64
    %1391 = qlx.apply #qlx.action<pauli_rotation>(%1390, %cst_842) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1392 = qlx.apply #qlx.action<h>(%1391) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_843 = arith.constant 0.78539816339744828 : f64
    %1393:2 = qlx.apply #qlx.action<pauli_rotation>(%1389, %1392, %cst_843) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_844 = arith.constant 1.5707963267948966 : f64
    %1394 = qlx.apply #qlx.action<pauli_rotation>(%1393#0, %cst_844) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_845 = arith.constant 1.5707963267948966 : f64
    %1395 = qlx.apply #qlx.action<pauli_rotation>(%1393#1, %cst_845) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_846 = arith.constant 0.78539816339744828 : f64
    %1396:2 = qlx.apply #qlx.action<pauli_rotation>(%1394, %1395, %cst_846) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1397 = qlx.apply #qlx.action<h>(%1386#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_847 = arith.constant 2.3561944901923448 : f64
    %1398 = qlx.apply #qlx.action<pauli_rotation>(%1397, %cst_847) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1399 = qlx.apply #qlx.action<h>(%1398) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1400 = qlx.apply #qlx.action<h>(%1396#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_848 = arith.constant 0.78539816339744828 : f64
    %1401 = qlx.apply #qlx.action<pauli_rotation>(%1400, %cst_848) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1402 = qlx.apply #qlx.action<h>(%1401) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_849 = arith.constant 1.250000e-01 : f64
    %1403:2 = qlx.apply #qlx.action<pauli_rotation>(%1399, %1402, %cst_849) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_850 = arith.constant 1.5707963267948966 : f64
    %1404 = qlx.apply #qlx.action<pauli_rotation>(%1403#0, %cst_850) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_851 = arith.constant 1.5707963267948966 : f64
    %1405 = qlx.apply #qlx.action<pauli_rotation>(%1403#1, %cst_851) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_852 = arith.constant 1.250000e-01 : f64
    %1406:2 = qlx.apply #qlx.action<pauli_rotation>(%1404, %1405, %cst_852) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1407 = qlx.apply #qlx.action<h>(%1386#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_853 = arith.constant 1.5707963267948966 : f64
    %1408 = qlx.apply #qlx.action<pauli_rotation>(%1407, %cst_853) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1409 = qlx.apply #qlx.action<h>(%1408) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1410 = qlx.apply #qlx.action<h>(%1406#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_854 = arith.constant 0.78539816339744828 : f64
    %1411 = qlx.apply #qlx.action<pauli_rotation>(%1410, %cst_854) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1412 = qlx.apply #qlx.action<h>(%1411) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_855 = arith.constant 0.78539816339744828 : f64
    %1413:2 = qlx.apply #qlx.action<pauli_rotation>(%1409, %1412, %cst_855) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_856 = arith.constant 1.5707963267948966 : f64
    %1414 = qlx.apply #qlx.action<pauli_rotation>(%1413#0, %cst_856) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_857 = arith.constant 1.5707963267948966 : f64
    %1415 = qlx.apply #qlx.action<pauli_rotation>(%1413#1, %cst_857) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_858 = arith.constant 0.78539816339744828 : f64
    %1416:2 = qlx.apply #qlx.action<pauli_rotation>(%1414, %1415, %cst_858) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1417 = qlx.apply #qlx.action<h>(%1406#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_859 = arith.constant 2.3561944901923448 : f64
    %1418 = qlx.apply #qlx.action<pauli_rotation>(%1417, %cst_859) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1419 = qlx.apply #qlx.action<h>(%1418) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1420 = qlx.apply #qlx.action<h>(%1396#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_860 = arith.constant 1.5707963267948966 : f64
    %1421 = qlx.apply #qlx.action<pauli_rotation>(%1420, %cst_860) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1422 = qlx.apply #qlx.action<h>(%1421) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_861 = arith.constant 0.78539816339744828 : f64
    %1423:2 = qlx.apply #qlx.action<pauli_rotation>(%1419, %1422, %cst_861) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_862 = arith.constant 1.5707963267948966 : f64
    %1424 = qlx.apply #qlx.action<pauli_rotation>(%1423#0, %cst_862) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_863 = arith.constant 1.5707963267948966 : f64
    %1425 = qlx.apply #qlx.action<pauli_rotation>(%1423#1, %cst_863) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_864 = arith.constant 0.78539816339744828 : f64
    %1426:2 = qlx.apply #qlx.action<pauli_rotation>(%1424, %1425, %cst_864) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1427 = qlx.apply #qlx.action<h>(%1377#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_865 = arith.constant 2.3561944901923448 : f64
    %1428 = qlx.apply #qlx.action<pauli_rotation>(%1427, %cst_865) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1429 = qlx.apply #qlx.action<h>(%1428) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1430 = qlx.apply #qlx.action<h>(%1367#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_866 = arith.constant 2.3561944901923448 : f64
    %1431 = qlx.apply #qlx.action<pauli_rotation>(%1430, %cst_866) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1432 = qlx.apply #qlx.action<h>(%1431) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_867 = arith.constant 0.78539816339744828 : f64
    %1433:2 = qlx.apply #qlx.action<pauli_rotation>(%1429, %1432, %cst_867) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_868 = arith.constant 1.5707963267948966 : f64
    %1434 = qlx.apply #qlx.action<pauli_rotation>(%1433#0, %cst_868) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_869 = arith.constant 1.5707963267948966 : f64
    %1435 = qlx.apply #qlx.action<pauli_rotation>(%1433#1, %cst_869) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_870 = arith.constant 0.78539816339744828 : f64
    %1436:2 = qlx.apply #qlx.action<pauli_rotation>(%1434, %1435, %cst_870) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1437 = qlx.apply #qlx.action<h>(%1347#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_871 = arith.constant 2.3561944901923448 : f64
    %1438 = qlx.apply #qlx.action<pauli_rotation>(%1437, %cst_871) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1439 = qlx.apply #qlx.action<h>(%1438) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_872 = arith.constant 0.78539816339744828 : f64
    %1440 = qlx.apply #qlx.action<pauli_rotation>(%1329#1, %cst_872) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1441 = qlx.apply #qlx.action<h>(%1440) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_873 = arith.constant 0.78539816339744828 : f64
    %1442:2 = qlx.apply #qlx.action<pauli_rotation>(%1439, %1441, %cst_873) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_874 = arith.constant 1.5707963267948966 : f64
    %1443 = qlx.apply #qlx.action<pauli_rotation>(%1442#0, %cst_874) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_875 = arith.constant 1.5707963267948966 : f64
    %1444 = qlx.apply #qlx.action<pauli_rotation>(%1442#1, %cst_875) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_876 = arith.constant 0.78539816339744828 : f64
    %1445:2 = qlx.apply #qlx.action<pauli_rotation>(%1443, %1444, %cst_876) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1446 = qlx.apply #qlx.action<h>(%1436#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_877 = arith.constant 2.3561944901923448 : f64
    %1447 = qlx.apply #qlx.action<pauli_rotation>(%1446, %cst_877) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1448 = qlx.apply #qlx.action<h>(%1447) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1449 = qlx.apply #qlx.action<h>(%1445#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_878 = arith.constant 0.78539816339744828 : f64
    %1450 = qlx.apply #qlx.action<pauli_rotation>(%1449, %cst_878) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1451 = qlx.apply #qlx.action<h>(%1450) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_879 = arith.constant 1.250000e-01 : f64
    %1452:2 = qlx.apply #qlx.action<pauli_rotation>(%1448, %1451, %cst_879) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_880 = arith.constant 1.5707963267948966 : f64
    %1453 = qlx.apply #qlx.action<pauli_rotation>(%1452#0, %cst_880) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_881 = arith.constant 1.5707963267948966 : f64
    %1454 = qlx.apply #qlx.action<pauli_rotation>(%1452#1, %cst_881) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_882 = arith.constant 1.250000e-01 : f64
    %1455:2 = qlx.apply #qlx.action<pauli_rotation>(%1453, %1454, %cst_882) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1456 = qlx.apply #qlx.action<h>(%1436#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_883 = arith.constant 1.5707963267948966 : f64
    %1457 = qlx.apply #qlx.action<pauli_rotation>(%1456, %cst_883) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1458 = qlx.apply #qlx.action<h>(%1457) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1459 = qlx.apply #qlx.action<h>(%1455#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_884 = arith.constant 0.78539816339744828 : f64
    %1460 = qlx.apply #qlx.action<pauli_rotation>(%1459, %cst_884) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1461 = qlx.apply #qlx.action<h>(%1460) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_885 = arith.constant 0.78539816339744828 : f64
    %1462:2 = qlx.apply #qlx.action<pauli_rotation>(%1458, %1461, %cst_885) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_886 = arith.constant 1.5707963267948966 : f64
    %1463 = qlx.apply #qlx.action<pauli_rotation>(%1462#0, %cst_886) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_887 = arith.constant 1.5707963267948966 : f64
    %1464 = qlx.apply #qlx.action<pauli_rotation>(%1462#1, %cst_887) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_888 = arith.constant 0.78539816339744828 : f64
    %1465:2 = qlx.apply #qlx.action<pauli_rotation>(%1463, %1464, %cst_888) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1466 = qlx.apply #qlx.action<h>(%1455#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_889 = arith.constant 2.3561944901923448 : f64
    %1467 = qlx.apply #qlx.action<pauli_rotation>(%1466, %cst_889) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1468 = qlx.apply #qlx.action<h>(%1467) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1469 = qlx.apply #qlx.action<h>(%1445#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_890 = arith.constant 1.5707963267948966 : f64
    %1470 = qlx.apply #qlx.action<pauli_rotation>(%1469, %cst_890) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1471 = qlx.apply #qlx.action<h>(%1470) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_891 = arith.constant 0.78539816339744828 : f64
    %1472:2 = qlx.apply #qlx.action<pauli_rotation>(%1468, %1471, %cst_891) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_892 = arith.constant 1.5707963267948966 : f64
    %1473 = qlx.apply #qlx.action<pauli_rotation>(%1472#0, %cst_892) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_893 = arith.constant 1.5707963267948966 : f64
    %1474 = qlx.apply #qlx.action<pauli_rotation>(%1472#1, %cst_893) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_894 = arith.constant 0.78539816339744828 : f64
    %1475:2 = qlx.apply #qlx.action<pauli_rotation>(%1473, %1474, %cst_894) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1476 = qlx.apply #qlx.action<h>(%1426#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_895 = arith.constant 2.3561944901923448 : f64
    %1477 = qlx.apply #qlx.action<pauli_rotation>(%1476, %cst_895) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1478 = qlx.apply #qlx.action<h>(%1477) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1479 = qlx.apply #qlx.action<h>(%1465#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_896 = arith.constant 2.3561944901923448 : f64
    %1480 = qlx.apply #qlx.action<pauli_rotation>(%1479, %cst_896) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1481 = qlx.apply #qlx.action<h>(%1480) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_897 = arith.constant 1.5707963267948966 : f64
    %1482:2 = qlx.apply #qlx.action<pauli_rotation>(%1478, %1481, %cst_897) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_898 = arith.constant 1.5707963267948966 : f64
    %1483 = qlx.apply #qlx.action<pauli_rotation>(%1482#0, %cst_898) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_899 = arith.constant 1.5707963267948966 : f64
    %1484 = qlx.apply #qlx.action<pauli_rotation>(%1482#1, %cst_899) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_900 = arith.constant 1.5707963267948966 : f64
    %1485:2 = qlx.apply #qlx.action<pauli_rotation>(%1483, %1484, %cst_900) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1486 = qlx.apply #qlx.action<h>(%1426#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_901 = arith.constant 2.3561944901923448 : f64
    %1487 = qlx.apply #qlx.action<pauli_rotation>(%1486, %cst_901) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1488 = qlx.apply #qlx.action<h>(%1487) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1489 = qlx.apply #qlx.action<h>(%1485#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_902 = arith.constant 3.1415926535897931 : f64
    %1490 = qlx.apply #qlx.action<pauli_rotation>(%1489, %cst_902) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1491 = qlx.apply #qlx.action<h>(%1490) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_903 = arith.constant 1.5707963267948966 : f64
    %1492:2 = qlx.apply #qlx.action<pauli_rotation>(%1488, %1491, %cst_903) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_904 = arith.constant 1.5707963267948966 : f64
    %1493 = qlx.apply #qlx.action<pauli_rotation>(%1492#0, %cst_904) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_905 = arith.constant 1.5707963267948966 : f64
    %1494 = qlx.apply #qlx.action<pauli_rotation>(%1492#1, %cst_905) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_906 = arith.constant 1.5707963267948966 : f64
    %1495:2 = qlx.apply #qlx.action<pauli_rotation>(%1493, %1494, %cst_906) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1496 = qlx.apply #qlx.action<h>(%1485#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_907 = arith.constant 3.1415926535897931 : f64
    %1497 = qlx.apply #qlx.action<pauli_rotation>(%1496, %cst_907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1498 = qlx.apply #qlx.action<h>(%1497) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1499 = qlx.apply #qlx.action<h>(%1465#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_908 = arith.constant 2.3561944901923448 : f64
    %1500 = qlx.apply #qlx.action<pauli_rotation>(%1499, %cst_908) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1501 = qlx.apply #qlx.action<h>(%1500) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_909 = arith.constant 1.5707963267948966 : f64
    %1502:2 = qlx.apply #qlx.action<pauli_rotation>(%1498, %1501, %cst_909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_910 = arith.constant 1.5707963267948966 : f64
    %1503 = qlx.apply #qlx.action<pauli_rotation>(%1502#0, %cst_910) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_911 = arith.constant 1.5707963267948966 : f64
    %1504 = qlx.apply #qlx.action<pauli_rotation>(%1502#1, %cst_911) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_912 = arith.constant 1.5707963267948966 : f64
    %1505:2 = qlx.apply #qlx.action<pauli_rotation>(%1503, %1504, %cst_912) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1506 = qlx.apply #qlx.action<h>(%1416#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_913 = arith.constant 2.3561944901923448 : f64
    %1507 = qlx.apply #qlx.action<pauli_rotation>(%1506, %cst_913) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1508 = qlx.apply #qlx.action<h>(%1507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1509 = qlx.apply #qlx.action<h>(%1495#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_914 = arith.constant 3.1415926535897931 : f64
    %1510 = qlx.apply #qlx.action<pauli_rotation>(%1509, %cst_914) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1511 = qlx.apply #qlx.action<h>(%1510) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_915 = arith.constant 1.5707963267948966 : f64
    %1512:2 = qlx.apply #qlx.action<pauli_rotation>(%1508, %1511, %cst_915) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_916 = arith.constant 1.5707963267948966 : f64
    %1513 = qlx.apply #qlx.action<pauli_rotation>(%1512#0, %cst_916) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_917 = arith.constant 1.5707963267948966 : f64
    %1514 = qlx.apply #qlx.action<pauli_rotation>(%1512#1, %cst_917) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_918 = arith.constant 1.5707963267948966 : f64
    %1515:2 = qlx.apply #qlx.action<pauli_rotation>(%1513, %1514, %cst_918) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1516 = qlx.apply #qlx.action<h>(%1495#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_919 = arith.constant 3.1415926535897931 : f64
    %1517 = qlx.apply #qlx.action<pauli_rotation>(%1516, %cst_919) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1518 = qlx.apply #qlx.action<h>(%1517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1519 = qlx.apply #qlx.action<h>(%1505#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_920 = arith.constant 3.1415926535897931 : f64
    %1520 = qlx.apply #qlx.action<pauli_rotation>(%1519, %cst_920) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1521 = qlx.apply #qlx.action<h>(%1520) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_921 = arith.constant 1.5707963267948966 : f64
    %1522:2 = qlx.apply #qlx.action<pauli_rotation>(%1518, %1521, %cst_921) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_922 = arith.constant 1.5707963267948966 : f64
    %1523 = qlx.apply #qlx.action<pauli_rotation>(%1522#0, %cst_922) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_923 = arith.constant 1.5707963267948966 : f64
    %1524 = qlx.apply #qlx.action<pauli_rotation>(%1522#1, %cst_923) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_924 = arith.constant 1.5707963267948966 : f64
    %1525:2 = qlx.apply #qlx.action<pauli_rotation>(%1523, %1524, %cst_924) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1526 = qlx.apply #qlx.action<h>(%1505#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_925 = arith.constant 3.1415926535897931 : f64
    %1527 = qlx.apply #qlx.action<pauli_rotation>(%1526, %cst_925) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1528 = qlx.apply #qlx.action<h>(%1527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1529 = qlx.apply #qlx.action<h>(%1475#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_926 = arith.constant 2.3561944901923448 : f64
    %1530 = qlx.apply #qlx.action<pauli_rotation>(%1529, %cst_926) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1531 = qlx.apply #qlx.action<h>(%1530) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_927 = arith.constant 1.5707963267948966 : f64
    %1532:2 = qlx.apply #qlx.action<pauli_rotation>(%1528, %1531, %cst_927) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_928 = arith.constant 1.5707963267948966 : f64
    %1533 = qlx.apply #qlx.action<pauli_rotation>(%1532#0, %cst_928) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_929 = arith.constant 1.5707963267948966 : f64
    %1534 = qlx.apply #qlx.action<pauli_rotation>(%1532#1, %cst_929) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_930 = arith.constant 1.5707963267948966 : f64
    %1535:2 = qlx.apply #qlx.action<pauli_rotation>(%1533, %1534, %cst_930) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1536 = qlx.apply #qlx.action<h>(%1416#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_931 = arith.constant 2.3561944901923448 : f64
    %1537 = qlx.apply #qlx.action<pauli_rotation>(%1536, %cst_931) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1538 = qlx.apply #qlx.action<h>(%1515#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_932 = arith.constant 3.1415926535897931 : f64
    %1539 = qlx.apply #qlx.action<pauli_rotation>(%1538, %cst_932) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_933 = arith.constant 1.250000e-01 : f64
    %1540:2 = qlx.apply #qlx.action<pauli_rotation>(%1537, %1539, %cst_933) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1541 = qlx.apply #qlx.action<h>(%1515#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_934 = arith.constant 3.1415926535897931 : f64
    %1542 = qlx.apply #qlx.action<pauli_rotation>(%1541, %cst_934) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1543 = qlx.apply #qlx.action<h>(%1525#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_935 = arith.constant 3.1415926535897931 : f64
    %1544 = qlx.apply #qlx.action<pauli_rotation>(%1543, %cst_935) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_936 = arith.constant 1.250000e-01 : f64
    %1545:2 = qlx.apply #qlx.action<pauli_rotation>(%1542, %1544, %cst_936) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1546 = qlx.apply #qlx.action<h>(%1525#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_937 = arith.constant 3.1415926535897931 : f64
    %1547 = qlx.apply #qlx.action<pauli_rotation>(%1546, %cst_937) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1548 = qlx.apply #qlx.action<h>(%1535#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_938 = arith.constant 3.1415926535897931 : f64
    %1549 = qlx.apply #qlx.action<pauli_rotation>(%1548, %cst_938) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_939 = arith.constant 1.250000e-01 : f64
    %1550:2 = qlx.apply #qlx.action<pauli_rotation>(%1547, %1549, %cst_939) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1551 = qlx.apply #qlx.action<h>(%1535#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_940 = arith.constant 3.1415926535897931 : f64
    %1552 = qlx.apply #qlx.action<pauli_rotation>(%1551, %cst_940) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1553 = qlx.apply #qlx.action<h>(%1475#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_941 = arith.constant 2.3561944901923448 : f64
    %1554 = qlx.apply #qlx.action<pauli_rotation>(%1553, %cst_941) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_942 = arith.constant 1.250000e-01 : f64
    %1555:2 = qlx.apply #qlx.action<pauli_rotation>(%1552, %1554, %cst_942) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1556 = qlx.apply #qlx.action<h>(%1540#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1557 = qlx.apply #qlx.action<h>(%1545#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_943 = arith.constant 1.5707963267948966 : f64
    %1558:2 = qlx.apply #qlx.action<pauli_rotation>(%1556, %1557, %cst_943) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_944 = arith.constant 1.5707963267948966 : f64
    %1559 = qlx.apply #qlx.action<pauli_rotation>(%1558#0, %cst_944) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_945 = arith.constant 1.5707963267948966 : f64
    %1560 = qlx.apply #qlx.action<pauli_rotation>(%1558#1, %cst_945) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_946 = arith.constant 1.5707963267948966 : f64
    %1561:2 = qlx.apply #qlx.action<pauli_rotation>(%1559, %1560, %cst_946) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1562 = qlx.apply #qlx.action<h>(%1545#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1563 = qlx.apply #qlx.action<h>(%1550#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_947 = arith.constant 1.5707963267948966 : f64
    %1564:2 = qlx.apply #qlx.action<pauli_rotation>(%1562, %1563, %cst_947) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_948 = arith.constant 1.5707963267948966 : f64
    %1565 = qlx.apply #qlx.action<pauli_rotation>(%1564#0, %cst_948) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_949 = arith.constant 1.5707963267948966 : f64
    %1566 = qlx.apply #qlx.action<pauli_rotation>(%1564#1, %cst_949) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_950 = arith.constant 1.5707963267948966 : f64
    %1567:2 = qlx.apply #qlx.action<pauli_rotation>(%1565, %1566, %cst_950) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1568 = qlx.apply #qlx.action<h>(%1550#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1569 = qlx.apply #qlx.action<h>(%1555#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_951 = arith.constant 1.5707963267948966 : f64
    %1570:2 = qlx.apply #qlx.action<pauli_rotation>(%1568, %1569, %cst_951) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_952 = arith.constant 1.5707963267948966 : f64
    %1571 = qlx.apply #qlx.action<pauli_rotation>(%1570#0, %cst_952) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_953 = arith.constant 1.5707963267948966 : f64
    %1572 = qlx.apply #qlx.action<pauli_rotation>(%1570#1, %cst_953) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_954 = arith.constant 1.5707963267948966 : f64
    %1573:2 = qlx.apply #qlx.action<pauli_rotation>(%1571, %1572, %cst_954) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1574 = qlx.apply #qlx.action<h>(%1561#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_955 = arith.constant 3.1415926535897931 : f64
    %1575 = qlx.apply #qlx.action<pauli_rotation>(%1574, %cst_955) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1576 = qlx.apply #qlx.action<h>(%1575) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1577 = qlx.apply #qlx.action<h>(%1567#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_956 = arith.constant 3.1415926535897931 : f64
    %1578 = qlx.apply #qlx.action<pauli_rotation>(%1577, %cst_956) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1579 = qlx.apply #qlx.action<h>(%1578) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_957 = arith.constant 1.5707963267948966 : f64
    %1580:2 = qlx.apply #qlx.action<pauli_rotation>(%1576, %1579, %cst_957) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_958 = arith.constant 1.5707963267948966 : f64
    %1581 = qlx.apply #qlx.action<pauli_rotation>(%1580#0, %cst_958) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_959 = arith.constant 1.5707963267948966 : f64
    %1582 = qlx.apply #qlx.action<pauli_rotation>(%1580#1, %cst_959) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_960 = arith.constant 1.5707963267948966 : f64
    %1583:2 = qlx.apply #qlx.action<pauli_rotation>(%1581, %1582, %cst_960) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1584 = qlx.apply #qlx.action<h>(%1567#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_961 = arith.constant 3.1415926535897931 : f64
    %1585 = qlx.apply #qlx.action<pauli_rotation>(%1584, %cst_961) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1586 = qlx.apply #qlx.action<h>(%1585) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1587 = qlx.apply #qlx.action<h>(%1573#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_962 = arith.constant 3.1415926535897931 : f64
    %1588 = qlx.apply #qlx.action<pauli_rotation>(%1587, %cst_962) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1589 = qlx.apply #qlx.action<h>(%1588) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_963 = arith.constant 1.5707963267948966 : f64
    %1590:2 = qlx.apply #qlx.action<pauli_rotation>(%1586, %1589, %cst_963) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_964 = arith.constant 1.5707963267948966 : f64
    %1591 = qlx.apply #qlx.action<pauli_rotation>(%1590#0, %cst_964) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_965 = arith.constant 1.5707963267948966 : f64
    %1592 = qlx.apply #qlx.action<pauli_rotation>(%1590#1, %cst_965) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_966 = arith.constant 1.5707963267948966 : f64
    %1593:2 = qlx.apply #qlx.action<pauli_rotation>(%1591, %1592, %cst_966) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1594 = qlx.apply #qlx.action<h>(%1583#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_967 = arith.constant 3.1415926535897931 : f64
    %1595 = qlx.apply #qlx.action<pauli_rotation>(%1594, %cst_967) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1596 = qlx.apply #qlx.action<h>(%1595) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1597 = qlx.apply #qlx.action<h>(%1593#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_968 = arith.constant 3.1415926535897931 : f64
    %1598 = qlx.apply #qlx.action<pauli_rotation>(%1597, %cst_968) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1599 = qlx.apply #qlx.action<h>(%1598) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_969 = arith.constant 1.5707963267948966 : f64
    %1600:2 = qlx.apply #qlx.action<pauli_rotation>(%1596, %1599, %cst_969) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_970 = arith.constant 1.5707963267948966 : f64
    %1601 = qlx.apply #qlx.action<pauli_rotation>(%1600#0, %cst_970) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_971 = arith.constant 1.5707963267948966 : f64
    %1602 = qlx.apply #qlx.action<pauli_rotation>(%1600#1, %cst_971) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_972 = arith.constant 1.5707963267948966 : f64
    %1603:2 = qlx.apply #qlx.action<pauli_rotation>(%1601, %1602, %cst_972) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_973 = arith.constant 0.78539816339744828 : f64
    %1604 = qlx.apply #qlx.action<pauli_rotation>(%1540#0, %cst_973) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1605 = qlx.apply #qlx.action<h>(%1604) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1606 = qlx.apply #qlx.action<h>(%1561#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_974 = arith.constant 2.3561944901923448 : f64
    %1607 = qlx.apply #qlx.action<pauli_rotation>(%1606, %cst_974) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1608 = qlx.apply #qlx.action<h>(%1607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_975 = arith.constant 0.78539816339744828 : f64
    %1609:2 = qlx.apply #qlx.action<pauli_rotation>(%1605, %1608, %cst_975) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_976 = arith.constant 1.5707963267948966 : f64
    %1610 = qlx.apply #qlx.action<pauli_rotation>(%1609#0, %cst_976) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_977 = arith.constant 1.5707963267948966 : f64
    %1611 = qlx.apply #qlx.action<pauli_rotation>(%1609#1, %cst_977) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_978 = arith.constant 0.78539816339744828 : f64
    %1612:2 = qlx.apply #qlx.action<pauli_rotation>(%1610, %1611, %cst_978) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1613 = qlx.apply #qlx.action<h>(%1583#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_979 = arith.constant 2.3561944901923448 : f64
    %1614 = qlx.apply #qlx.action<pauli_rotation>(%1613, %cst_979) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1615 = qlx.apply #qlx.action<h>(%1614) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1616 = qlx.apply #qlx.action<h>(%1603#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_980 = arith.constant 2.3561944901923448 : f64
    %1617 = qlx.apply #qlx.action<pauli_rotation>(%1616, %cst_980) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1618 = qlx.apply #qlx.action<h>(%1617) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_981 = arith.constant 0.78539816339744828 : f64
    %1619:2 = qlx.apply #qlx.action<pauli_rotation>(%1615, %1618, %cst_981) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_982 = arith.constant 1.5707963267948966 : f64
    %1620 = qlx.apply #qlx.action<pauli_rotation>(%1619#0, %cst_982) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_983 = arith.constant 1.5707963267948966 : f64
    %1621 = qlx.apply #qlx.action<pauli_rotation>(%1619#1, %cst_983) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_984 = arith.constant 0.78539816339744828 : f64
    %1622:2 = qlx.apply #qlx.action<pauli_rotation>(%1620, %1621, %cst_984) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1623 = qlx.apply #qlx.action<h>(%1612#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_985 = arith.constant 2.3561944901923448 : f64
    %1624 = qlx.apply #qlx.action<pauli_rotation>(%1623, %cst_985) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1625 = qlx.apply #qlx.action<h>(%1624) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1626 = qlx.apply #qlx.action<h>(%1622#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_986 = arith.constant 0.78539816339744828 : f64
    %1627 = qlx.apply #qlx.action<pauli_rotation>(%1626, %cst_986) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1628 = qlx.apply #qlx.action<h>(%1627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_987 = arith.constant 1.250000e-01 : f64
    %1629:2 = qlx.apply #qlx.action<pauli_rotation>(%1625, %1628, %cst_987) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_988 = arith.constant 1.5707963267948966 : f64
    %1630 = qlx.apply #qlx.action<pauli_rotation>(%1629#0, %cst_988) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_989 = arith.constant 1.5707963267948966 : f64
    %1631 = qlx.apply #qlx.action<pauli_rotation>(%1629#1, %cst_989) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_990 = arith.constant 1.250000e-01 : f64
    %1632:2 = qlx.apply #qlx.action<pauli_rotation>(%1630, %1631, %cst_990) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1633 = qlx.apply #qlx.action<h>(%1612#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_991 = arith.constant 1.5707963267948966 : f64
    %1634 = qlx.apply #qlx.action<pauli_rotation>(%1633, %cst_991) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1635 = qlx.apply #qlx.action<h>(%1634) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1636 = qlx.apply #qlx.action<h>(%1632#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_992 = arith.constant 0.78539816339744828 : f64
    %1637 = qlx.apply #qlx.action<pauli_rotation>(%1636, %cst_992) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1638 = qlx.apply #qlx.action<h>(%1637) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_993 = arith.constant 0.78539816339744828 : f64
    %1639:2 = qlx.apply #qlx.action<pauli_rotation>(%1635, %1638, %cst_993) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_994 = arith.constant 1.5707963267948966 : f64
    %1640 = qlx.apply #qlx.action<pauli_rotation>(%1639#0, %cst_994) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_995 = arith.constant 1.5707963267948966 : f64
    %1641 = qlx.apply #qlx.action<pauli_rotation>(%1639#1, %cst_995) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_996 = arith.constant 0.78539816339744828 : f64
    %1642:2 = qlx.apply #qlx.action<pauli_rotation>(%1640, %1641, %cst_996) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1643 = qlx.apply #qlx.action<h>(%1632#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_997 = arith.constant 2.3561944901923448 : f64
    %1644 = qlx.apply #qlx.action<pauli_rotation>(%1643, %cst_997) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1645 = qlx.apply #qlx.action<h>(%1644) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1646 = qlx.apply #qlx.action<h>(%1622#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_998 = arith.constant 1.5707963267948966 : f64
    %1647 = qlx.apply #qlx.action<pauli_rotation>(%1646, %cst_998) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1648 = qlx.apply #qlx.action<h>(%1647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_999 = arith.constant 0.78539816339744828 : f64
    %1649:2 = qlx.apply #qlx.action<pauli_rotation>(%1645, %1648, %cst_999) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1000 = arith.constant 1.5707963267948966 : f64
    %1650 = qlx.apply #qlx.action<pauli_rotation>(%1649#0, %cst_1000) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1001 = arith.constant 1.5707963267948966 : f64
    %1651 = qlx.apply #qlx.action<pauli_rotation>(%1649#1, %cst_1001) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1002 = arith.constant 0.78539816339744828 : f64
    %1652:2 = qlx.apply #qlx.action<pauli_rotation>(%1650, %1651, %cst_1002) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1653 = qlx.apply #qlx.action<h>(%1603#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1003 = arith.constant 2.3561944901923448 : f64
    %1654 = qlx.apply #qlx.action<pauli_rotation>(%1653, %cst_1003) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1655 = qlx.apply #qlx.action<h>(%1654) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1656 = qlx.apply #qlx.action<h>(%1593#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1004 = arith.constant 2.3561944901923448 : f64
    %1657 = qlx.apply #qlx.action<pauli_rotation>(%1656, %cst_1004) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1658 = qlx.apply #qlx.action<h>(%1657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1005 = arith.constant 0.78539816339744828 : f64
    %1659:2 = qlx.apply #qlx.action<pauli_rotation>(%1655, %1658, %cst_1005) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1006 = arith.constant 1.5707963267948966 : f64
    %1660 = qlx.apply #qlx.action<pauli_rotation>(%1659#0, %cst_1006) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1007 = arith.constant 1.5707963267948966 : f64
    %1661 = qlx.apply #qlx.action<pauli_rotation>(%1659#1, %cst_1007) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1008 = arith.constant 0.78539816339744828 : f64
    %1662:2 = qlx.apply #qlx.action<pauli_rotation>(%1660, %1661, %cst_1008) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1663 = qlx.apply #qlx.action<h>(%1573#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1009 = arith.constant 2.3561944901923448 : f64
    %1664 = qlx.apply #qlx.action<pauli_rotation>(%1663, %cst_1009) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1665 = qlx.apply #qlx.action<h>(%1664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1010 = arith.constant 0.78539816339744828 : f64
    %1666 = qlx.apply #qlx.action<pauli_rotation>(%1555#1, %cst_1010) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1667 = qlx.apply #qlx.action<h>(%1666) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1011 = arith.constant 0.78539816339744828 : f64
    %1668:2 = qlx.apply #qlx.action<pauli_rotation>(%1665, %1667, %cst_1011) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1012 = arith.constant 1.5707963267948966 : f64
    %1669 = qlx.apply #qlx.action<pauli_rotation>(%1668#0, %cst_1012) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1013 = arith.constant 1.5707963267948966 : f64
    %1670 = qlx.apply #qlx.action<pauli_rotation>(%1668#1, %cst_1013) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1014 = arith.constant 0.78539816339744828 : f64
    %1671:2 = qlx.apply #qlx.action<pauli_rotation>(%1669, %1670, %cst_1014) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1672 = qlx.apply #qlx.action<h>(%1662#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1015 = arith.constant 2.3561944901923448 : f64
    %1673 = qlx.apply #qlx.action<pauli_rotation>(%1672, %cst_1015) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1674 = qlx.apply #qlx.action<h>(%1673) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1675 = qlx.apply #qlx.action<h>(%1671#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1016 = arith.constant 0.78539816339744828 : f64
    %1676 = qlx.apply #qlx.action<pauli_rotation>(%1675, %cst_1016) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1677 = qlx.apply #qlx.action<h>(%1676) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1017 = arith.constant 1.250000e-01 : f64
    %1678:2 = qlx.apply #qlx.action<pauli_rotation>(%1674, %1677, %cst_1017) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1018 = arith.constant 1.5707963267948966 : f64
    %1679 = qlx.apply #qlx.action<pauli_rotation>(%1678#0, %cst_1018) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1019 = arith.constant 1.5707963267948966 : f64
    %1680 = qlx.apply #qlx.action<pauli_rotation>(%1678#1, %cst_1019) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1020 = arith.constant 1.250000e-01 : f64
    %1681:2 = qlx.apply #qlx.action<pauli_rotation>(%1679, %1680, %cst_1020) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1682 = qlx.apply #qlx.action<h>(%1662#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1021 = arith.constant 1.5707963267948966 : f64
    %1683 = qlx.apply #qlx.action<pauli_rotation>(%1682, %cst_1021) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1684 = qlx.apply #qlx.action<h>(%1683) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1685 = qlx.apply #qlx.action<h>(%1681#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1022 = arith.constant 0.78539816339744828 : f64
    %1686 = qlx.apply #qlx.action<pauli_rotation>(%1685, %cst_1022) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1687 = qlx.apply #qlx.action<h>(%1686) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1023 = arith.constant 0.78539816339744828 : f64
    %1688:2 = qlx.apply #qlx.action<pauli_rotation>(%1684, %1687, %cst_1023) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1024 = arith.constant 1.5707963267948966 : f64
    %1689 = qlx.apply #qlx.action<pauli_rotation>(%1688#0, %cst_1024) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1025 = arith.constant 1.5707963267948966 : f64
    %1690 = qlx.apply #qlx.action<pauli_rotation>(%1688#1, %cst_1025) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1026 = arith.constant 0.78539816339744828 : f64
    %1691:2 = qlx.apply #qlx.action<pauli_rotation>(%1689, %1690, %cst_1026) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1692 = qlx.apply #qlx.action<h>(%1681#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1027 = arith.constant 2.3561944901923448 : f64
    %1693 = qlx.apply #qlx.action<pauli_rotation>(%1692, %cst_1027) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1694 = qlx.apply #qlx.action<h>(%1693) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1695 = qlx.apply #qlx.action<h>(%1671#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1028 = arith.constant 1.5707963267948966 : f64
    %1696 = qlx.apply #qlx.action<pauli_rotation>(%1695, %cst_1028) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1697 = qlx.apply #qlx.action<h>(%1696) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1029 = arith.constant 0.78539816339744828 : f64
    %1698:2 = qlx.apply #qlx.action<pauli_rotation>(%1694, %1697, %cst_1029) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1030 = arith.constant 1.5707963267948966 : f64
    %1699 = qlx.apply #qlx.action<pauli_rotation>(%1698#0, %cst_1030) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1031 = arith.constant 1.5707963267948966 : f64
    %1700 = qlx.apply #qlx.action<pauli_rotation>(%1698#1, %cst_1031) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1032 = arith.constant 0.78539816339744828 : f64
    %1701:2 = qlx.apply #qlx.action<pauli_rotation>(%1699, %1700, %cst_1032) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1702 = qlx.apply #qlx.action<h>(%1652#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1033 = arith.constant 2.3561944901923448 : f64
    %1703 = qlx.apply #qlx.action<pauli_rotation>(%1702, %cst_1033) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1704 = qlx.apply #qlx.action<h>(%1703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1705 = qlx.apply #qlx.action<h>(%1691#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1034 = arith.constant 2.3561944901923448 : f64
    %1706 = qlx.apply #qlx.action<pauli_rotation>(%1705, %cst_1034) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1707 = qlx.apply #qlx.action<h>(%1706) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1035 = arith.constant 1.5707963267948966 : f64
    %1708:2 = qlx.apply #qlx.action<pauli_rotation>(%1704, %1707, %cst_1035) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1036 = arith.constant 1.5707963267948966 : f64
    %1709 = qlx.apply #qlx.action<pauli_rotation>(%1708#0, %cst_1036) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1037 = arith.constant 1.5707963267948966 : f64
    %1710 = qlx.apply #qlx.action<pauli_rotation>(%1708#1, %cst_1037) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1038 = arith.constant 1.5707963267948966 : f64
    %1711:2 = qlx.apply #qlx.action<pauli_rotation>(%1709, %1710, %cst_1038) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1712 = qlx.apply #qlx.action<h>(%1652#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1039 = arith.constant 2.3561944901923448 : f64
    %1713 = qlx.apply #qlx.action<pauli_rotation>(%1712, %cst_1039) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1714 = qlx.apply #qlx.action<h>(%1713) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1715 = qlx.apply #qlx.action<h>(%1711#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1040 = arith.constant 3.1415926535897931 : f64
    %1716 = qlx.apply #qlx.action<pauli_rotation>(%1715, %cst_1040) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1717 = qlx.apply #qlx.action<h>(%1716) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1041 = arith.constant 1.5707963267948966 : f64
    %1718:2 = qlx.apply #qlx.action<pauli_rotation>(%1714, %1717, %cst_1041) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1042 = arith.constant 1.5707963267948966 : f64
    %1719 = qlx.apply #qlx.action<pauli_rotation>(%1718#0, %cst_1042) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1043 = arith.constant 1.5707963267948966 : f64
    %1720 = qlx.apply #qlx.action<pauli_rotation>(%1718#1, %cst_1043) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1044 = arith.constant 1.5707963267948966 : f64
    %1721:2 = qlx.apply #qlx.action<pauli_rotation>(%1719, %1720, %cst_1044) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1722 = qlx.apply #qlx.action<h>(%1711#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1045 = arith.constant 3.1415926535897931 : f64
    %1723 = qlx.apply #qlx.action<pauli_rotation>(%1722, %cst_1045) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1724 = qlx.apply #qlx.action<h>(%1723) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1725 = qlx.apply #qlx.action<h>(%1691#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1046 = arith.constant 2.3561944901923448 : f64
    %1726 = qlx.apply #qlx.action<pauli_rotation>(%1725, %cst_1046) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1727 = qlx.apply #qlx.action<h>(%1726) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1047 = arith.constant 1.5707963267948966 : f64
    %1728:2 = qlx.apply #qlx.action<pauli_rotation>(%1724, %1727, %cst_1047) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1048 = arith.constant 1.5707963267948966 : f64
    %1729 = qlx.apply #qlx.action<pauli_rotation>(%1728#0, %cst_1048) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1049 = arith.constant 1.5707963267948966 : f64
    %1730 = qlx.apply #qlx.action<pauli_rotation>(%1728#1, %cst_1049) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1050 = arith.constant 1.5707963267948966 : f64
    %1731:2 = qlx.apply #qlx.action<pauli_rotation>(%1729, %1730, %cst_1050) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1732 = qlx.apply #qlx.action<h>(%1642#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1051 = arith.constant 2.3561944901923448 : f64
    %1733 = qlx.apply #qlx.action<pauli_rotation>(%1732, %cst_1051) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1734 = qlx.apply #qlx.action<h>(%1733) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1735 = qlx.apply #qlx.action<h>(%1721#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1052 = arith.constant 3.1415926535897931 : f64
    %1736 = qlx.apply #qlx.action<pauli_rotation>(%1735, %cst_1052) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1737 = qlx.apply #qlx.action<h>(%1736) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1053 = arith.constant 1.5707963267948966 : f64
    %1738:2 = qlx.apply #qlx.action<pauli_rotation>(%1734, %1737, %cst_1053) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1054 = arith.constant 1.5707963267948966 : f64
    %1739 = qlx.apply #qlx.action<pauli_rotation>(%1738#0, %cst_1054) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1055 = arith.constant 1.5707963267948966 : f64
    %1740 = qlx.apply #qlx.action<pauli_rotation>(%1738#1, %cst_1055) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1056 = arith.constant 1.5707963267948966 : f64
    %1741:2 = qlx.apply #qlx.action<pauli_rotation>(%1739, %1740, %cst_1056) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1742 = qlx.apply #qlx.action<h>(%1721#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1057 = arith.constant 3.1415926535897931 : f64
    %1743 = qlx.apply #qlx.action<pauli_rotation>(%1742, %cst_1057) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1744 = qlx.apply #qlx.action<h>(%1743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1745 = qlx.apply #qlx.action<h>(%1731#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1058 = arith.constant 3.1415926535897931 : f64
    %1746 = qlx.apply #qlx.action<pauli_rotation>(%1745, %cst_1058) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1747 = qlx.apply #qlx.action<h>(%1746) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1059 = arith.constant 1.5707963267948966 : f64
    %1748:2 = qlx.apply #qlx.action<pauli_rotation>(%1744, %1747, %cst_1059) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1060 = arith.constant 1.5707963267948966 : f64
    %1749 = qlx.apply #qlx.action<pauli_rotation>(%1748#0, %cst_1060) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1061 = arith.constant 1.5707963267948966 : f64
    %1750 = qlx.apply #qlx.action<pauli_rotation>(%1748#1, %cst_1061) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1062 = arith.constant 1.5707963267948966 : f64
    %1751:2 = qlx.apply #qlx.action<pauli_rotation>(%1749, %1750, %cst_1062) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1752 = qlx.apply #qlx.action<h>(%1731#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1063 = arith.constant 3.1415926535897931 : f64
    %1753 = qlx.apply #qlx.action<pauli_rotation>(%1752, %cst_1063) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1754 = qlx.apply #qlx.action<h>(%1753) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1755 = qlx.apply #qlx.action<h>(%1701#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1064 = arith.constant 2.3561944901923448 : f64
    %1756 = qlx.apply #qlx.action<pauli_rotation>(%1755, %cst_1064) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1757 = qlx.apply #qlx.action<h>(%1756) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1065 = arith.constant 1.5707963267948966 : f64
    %1758:2 = qlx.apply #qlx.action<pauli_rotation>(%1754, %1757, %cst_1065) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1066 = arith.constant 1.5707963267948966 : f64
    %1759 = qlx.apply #qlx.action<pauli_rotation>(%1758#0, %cst_1066) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1067 = arith.constant 1.5707963267948966 : f64
    %1760 = qlx.apply #qlx.action<pauli_rotation>(%1758#1, %cst_1067) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1068 = arith.constant 1.5707963267948966 : f64
    %1761:2 = qlx.apply #qlx.action<pauli_rotation>(%1759, %1760, %cst_1068) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1762 = qlx.apply #qlx.action<h>(%1642#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1069 = arith.constant 2.3561944901923448 : f64
    %1763 = qlx.apply #qlx.action<pauli_rotation>(%1762, %cst_1069) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1764 = qlx.apply #qlx.action<h>(%1741#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1070 = arith.constant 3.1415926535897931 : f64
    %1765 = qlx.apply #qlx.action<pauli_rotation>(%1764, %cst_1070) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1071 = arith.constant 1.250000e-01 : f64
    %1766:2 = qlx.apply #qlx.action<pauli_rotation>(%1763, %1765, %cst_1071) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1767 = qlx.apply #qlx.action<h>(%1741#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1072 = arith.constant 3.1415926535897931 : f64
    %1768 = qlx.apply #qlx.action<pauli_rotation>(%1767, %cst_1072) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1769 = qlx.apply #qlx.action<h>(%1751#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1073 = arith.constant 3.1415926535897931 : f64
    %1770 = qlx.apply #qlx.action<pauli_rotation>(%1769, %cst_1073) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1074 = arith.constant 1.250000e-01 : f64
    %1771:2 = qlx.apply #qlx.action<pauli_rotation>(%1768, %1770, %cst_1074) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1772 = qlx.apply #qlx.action<h>(%1751#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1075 = arith.constant 3.1415926535897931 : f64
    %1773 = qlx.apply #qlx.action<pauli_rotation>(%1772, %cst_1075) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1774 = qlx.apply #qlx.action<h>(%1761#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1076 = arith.constant 3.1415926535897931 : f64
    %1775 = qlx.apply #qlx.action<pauli_rotation>(%1774, %cst_1076) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1077 = arith.constant 1.250000e-01 : f64
    %1776:2 = qlx.apply #qlx.action<pauli_rotation>(%1773, %1775, %cst_1077) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1777 = qlx.apply #qlx.action<h>(%1761#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1078 = arith.constant 3.1415926535897931 : f64
    %1778 = qlx.apply #qlx.action<pauli_rotation>(%1777, %cst_1078) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1779 = qlx.apply #qlx.action<h>(%1701#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1079 = arith.constant 2.3561944901923448 : f64
    %1780 = qlx.apply #qlx.action<pauli_rotation>(%1779, %cst_1079) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1080 = arith.constant 1.250000e-01 : f64
    %1781:2 = qlx.apply #qlx.action<pauli_rotation>(%1778, %1780, %cst_1080) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1782 = qlx.apply #qlx.action<h>(%1766#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1783 = qlx.apply #qlx.action<h>(%1771#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1081 = arith.constant 1.5707963267948966 : f64
    %1784:2 = qlx.apply #qlx.action<pauli_rotation>(%1782, %1783, %cst_1081) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1082 = arith.constant 1.5707963267948966 : f64
    %1785 = qlx.apply #qlx.action<pauli_rotation>(%1784#0, %cst_1082) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1083 = arith.constant 1.5707963267948966 : f64
    %1786 = qlx.apply #qlx.action<pauli_rotation>(%1784#1, %cst_1083) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1084 = arith.constant 1.5707963267948966 : f64
    %1787:2 = qlx.apply #qlx.action<pauli_rotation>(%1785, %1786, %cst_1084) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1788 = qlx.apply #qlx.action<h>(%1771#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1789 = qlx.apply #qlx.action<h>(%1776#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1085 = arith.constant 1.5707963267948966 : f64
    %1790:2 = qlx.apply #qlx.action<pauli_rotation>(%1788, %1789, %cst_1085) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1086 = arith.constant 1.5707963267948966 : f64
    %1791 = qlx.apply #qlx.action<pauli_rotation>(%1790#0, %cst_1086) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1087 = arith.constant 1.5707963267948966 : f64
    %1792 = qlx.apply #qlx.action<pauli_rotation>(%1790#1, %cst_1087) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1088 = arith.constant 1.5707963267948966 : f64
    %1793:2 = qlx.apply #qlx.action<pauli_rotation>(%1791, %1792, %cst_1088) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1794 = qlx.apply #qlx.action<h>(%1776#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1795 = qlx.apply #qlx.action<h>(%1781#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1089 = arith.constant 1.5707963267948966 : f64
    %1796:2 = qlx.apply #qlx.action<pauli_rotation>(%1794, %1795, %cst_1089) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1090 = arith.constant 1.5707963267948966 : f64
    %1797 = qlx.apply #qlx.action<pauli_rotation>(%1796#0, %cst_1090) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1091 = arith.constant 1.5707963267948966 : f64
    %1798 = qlx.apply #qlx.action<pauli_rotation>(%1796#1, %cst_1091) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1092 = arith.constant 1.5707963267948966 : f64
    %1799:2 = qlx.apply #qlx.action<pauli_rotation>(%1797, %1798, %cst_1092) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1800 = qlx.apply #qlx.action<h>(%1787#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1093 = arith.constant 3.1415926535897931 : f64
    %1801 = qlx.apply #qlx.action<pauli_rotation>(%1800, %cst_1093) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1802 = qlx.apply #qlx.action<h>(%1801) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1803 = qlx.apply #qlx.action<h>(%1793#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1094 = arith.constant 3.1415926535897931 : f64
    %1804 = qlx.apply #qlx.action<pauli_rotation>(%1803, %cst_1094) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1805 = qlx.apply #qlx.action<h>(%1804) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1095 = arith.constant 1.5707963267948966 : f64
    %1806:2 = qlx.apply #qlx.action<pauli_rotation>(%1802, %1805, %cst_1095) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1096 = arith.constant 1.5707963267948966 : f64
    %1807 = qlx.apply #qlx.action<pauli_rotation>(%1806#0, %cst_1096) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1097 = arith.constant 1.5707963267948966 : f64
    %1808 = qlx.apply #qlx.action<pauli_rotation>(%1806#1, %cst_1097) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1098 = arith.constant 1.5707963267948966 : f64
    %1809:2 = qlx.apply #qlx.action<pauli_rotation>(%1807, %1808, %cst_1098) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1810 = qlx.apply #qlx.action<h>(%1793#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1099 = arith.constant 3.1415926535897931 : f64
    %1811 = qlx.apply #qlx.action<pauli_rotation>(%1810, %cst_1099) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1812 = qlx.apply #qlx.action<h>(%1811) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1813 = qlx.apply #qlx.action<h>(%1799#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1100 = arith.constant 3.1415926535897931 : f64
    %1814 = qlx.apply #qlx.action<pauli_rotation>(%1813, %cst_1100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1815 = qlx.apply #qlx.action<h>(%1814) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1101 = arith.constant 1.5707963267948966 : f64
    %1816:2 = qlx.apply #qlx.action<pauli_rotation>(%1812, %1815, %cst_1101) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1102 = arith.constant 1.5707963267948966 : f64
    %1817 = qlx.apply #qlx.action<pauli_rotation>(%1816#0, %cst_1102) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1103 = arith.constant 1.5707963267948966 : f64
    %1818 = qlx.apply #qlx.action<pauli_rotation>(%1816#1, %cst_1103) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1104 = arith.constant 1.5707963267948966 : f64
    %1819:2 = qlx.apply #qlx.action<pauli_rotation>(%1817, %1818, %cst_1104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1820 = qlx.apply #qlx.action<h>(%1809#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1105 = arith.constant 3.1415926535897931 : f64
    %1821 = qlx.apply #qlx.action<pauli_rotation>(%1820, %cst_1105) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1822 = qlx.apply #qlx.action<h>(%1821) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1823 = qlx.apply #qlx.action<h>(%1819#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1106 = arith.constant 3.1415926535897931 : f64
    %1824 = qlx.apply #qlx.action<pauli_rotation>(%1823, %cst_1106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1825 = qlx.apply #qlx.action<h>(%1824) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1107 = arith.constant 1.5707963267948966 : f64
    %1826:2 = qlx.apply #qlx.action<pauli_rotation>(%1822, %1825, %cst_1107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1108 = arith.constant 1.5707963267948966 : f64
    %1827 = qlx.apply #qlx.action<pauli_rotation>(%1826#0, %cst_1108) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1109 = arith.constant 1.5707963267948966 : f64
    %1828 = qlx.apply #qlx.action<pauli_rotation>(%1826#1, %cst_1109) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1110 = arith.constant 1.5707963267948966 : f64
    %1829:2 = qlx.apply #qlx.action<pauli_rotation>(%1827, %1828, %cst_1110) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1111 = arith.constant 0.78539816339744828 : f64
    %1830 = qlx.apply #qlx.action<pauli_rotation>(%1766#0, %cst_1111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1831 = qlx.apply #qlx.action<h>(%1830) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1832 = qlx.apply #qlx.action<h>(%1787#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1112 = arith.constant 2.3561944901923448 : f64
    %1833 = qlx.apply #qlx.action<pauli_rotation>(%1832, %cst_1112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1834 = qlx.apply #qlx.action<h>(%1833) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1113 = arith.constant 0.78539816339744828 : f64
    %1835:2 = qlx.apply #qlx.action<pauli_rotation>(%1831, %1834, %cst_1113) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1114 = arith.constant 1.5707963267948966 : f64
    %1836 = qlx.apply #qlx.action<pauli_rotation>(%1835#0, %cst_1114) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1115 = arith.constant 1.5707963267948966 : f64
    %1837 = qlx.apply #qlx.action<pauli_rotation>(%1835#1, %cst_1115) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1116 = arith.constant 0.78539816339744828 : f64
    %1838:2 = qlx.apply #qlx.action<pauli_rotation>(%1836, %1837, %cst_1116) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1839 = qlx.apply #qlx.action<h>(%1809#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1117 = arith.constant 2.3561944901923448 : f64
    %1840 = qlx.apply #qlx.action<pauli_rotation>(%1839, %cst_1117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1841 = qlx.apply #qlx.action<h>(%1840) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1842 = qlx.apply #qlx.action<h>(%1829#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1118 = arith.constant 2.3561944901923448 : f64
    %1843 = qlx.apply #qlx.action<pauli_rotation>(%1842, %cst_1118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1844 = qlx.apply #qlx.action<h>(%1843) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1119 = arith.constant 0.78539816339744828 : f64
    %1845:2 = qlx.apply #qlx.action<pauli_rotation>(%1841, %1844, %cst_1119) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1120 = arith.constant 1.5707963267948966 : f64
    %1846 = qlx.apply #qlx.action<pauli_rotation>(%1845#0, %cst_1120) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1121 = arith.constant 1.5707963267948966 : f64
    %1847 = qlx.apply #qlx.action<pauli_rotation>(%1845#1, %cst_1121) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1122 = arith.constant 0.78539816339744828 : f64
    %1848:2 = qlx.apply #qlx.action<pauli_rotation>(%1846, %1847, %cst_1122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1849 = qlx.apply #qlx.action<h>(%1838#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1123 = arith.constant 2.3561944901923448 : f64
    %1850 = qlx.apply #qlx.action<pauli_rotation>(%1849, %cst_1123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1851 = qlx.apply #qlx.action<h>(%1850) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1852 = qlx.apply #qlx.action<h>(%1848#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1124 = arith.constant 0.78539816339744828 : f64
    %1853 = qlx.apply #qlx.action<pauli_rotation>(%1852, %cst_1124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1854 = qlx.apply #qlx.action<h>(%1853) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1125 = arith.constant 1.250000e-01 : f64
    %1855:2 = qlx.apply #qlx.action<pauli_rotation>(%1851, %1854, %cst_1125) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1126 = arith.constant 1.5707963267948966 : f64
    %1856 = qlx.apply #qlx.action<pauli_rotation>(%1855#0, %cst_1126) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1127 = arith.constant 1.5707963267948966 : f64
    %1857 = qlx.apply #qlx.action<pauli_rotation>(%1855#1, %cst_1127) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1128 = arith.constant 1.250000e-01 : f64
    %1858:2 = qlx.apply #qlx.action<pauli_rotation>(%1856, %1857, %cst_1128) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1859 = qlx.apply #qlx.action<h>(%1838#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1129 = arith.constant 1.5707963267948966 : f64
    %1860 = qlx.apply #qlx.action<pauli_rotation>(%1859, %cst_1129) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1861 = qlx.apply #qlx.action<h>(%1860) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1862 = qlx.apply #qlx.action<h>(%1858#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1130 = arith.constant 0.78539816339744828 : f64
    %1863 = qlx.apply #qlx.action<pauli_rotation>(%1862, %cst_1130) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1864 = qlx.apply #qlx.action<h>(%1863) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1131 = arith.constant 0.78539816339744828 : f64
    %1865:2 = qlx.apply #qlx.action<pauli_rotation>(%1861, %1864, %cst_1131) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1132 = arith.constant 1.5707963267948966 : f64
    %1866 = qlx.apply #qlx.action<pauli_rotation>(%1865#0, %cst_1132) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1133 = arith.constant 1.5707963267948966 : f64
    %1867 = qlx.apply #qlx.action<pauli_rotation>(%1865#1, %cst_1133) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1134 = arith.constant 0.78539816339744828 : f64
    %1868:2 = qlx.apply #qlx.action<pauli_rotation>(%1866, %1867, %cst_1134) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1869 = qlx.apply #qlx.action<h>(%1858#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1135 = arith.constant 2.3561944901923448 : f64
    %1870 = qlx.apply #qlx.action<pauli_rotation>(%1869, %cst_1135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1871 = qlx.apply #qlx.action<h>(%1870) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1872 = qlx.apply #qlx.action<h>(%1848#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1136 = arith.constant 1.5707963267948966 : f64
    %1873 = qlx.apply #qlx.action<pauli_rotation>(%1872, %cst_1136) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1874 = qlx.apply #qlx.action<h>(%1873) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1137 = arith.constant 0.78539816339744828 : f64
    %1875:2 = qlx.apply #qlx.action<pauli_rotation>(%1871, %1874, %cst_1137) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1138 = arith.constant 1.5707963267948966 : f64
    %1876 = qlx.apply #qlx.action<pauli_rotation>(%1875#0, %cst_1138) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1139 = arith.constant 1.5707963267948966 : f64
    %1877 = qlx.apply #qlx.action<pauli_rotation>(%1875#1, %cst_1139) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1140 = arith.constant 0.78539816339744828 : f64
    %1878:2 = qlx.apply #qlx.action<pauli_rotation>(%1876, %1877, %cst_1140) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1879 = qlx.apply #qlx.action<h>(%1829#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1141 = arith.constant 2.3561944901923448 : f64
    %1880 = qlx.apply #qlx.action<pauli_rotation>(%1879, %cst_1141) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1881 = qlx.apply #qlx.action<h>(%1880) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1882 = qlx.apply #qlx.action<h>(%1819#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1142 = arith.constant 2.3561944901923448 : f64
    %1883 = qlx.apply #qlx.action<pauli_rotation>(%1882, %cst_1142) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1884 = qlx.apply #qlx.action<h>(%1883) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1143 = arith.constant 0.78539816339744828 : f64
    %1885:2 = qlx.apply #qlx.action<pauli_rotation>(%1881, %1884, %cst_1143) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1144 = arith.constant 1.5707963267948966 : f64
    %1886 = qlx.apply #qlx.action<pauli_rotation>(%1885#0, %cst_1144) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1145 = arith.constant 1.5707963267948966 : f64
    %1887 = qlx.apply #qlx.action<pauli_rotation>(%1885#1, %cst_1145) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1146 = arith.constant 0.78539816339744828 : f64
    %1888:2 = qlx.apply #qlx.action<pauli_rotation>(%1886, %1887, %cst_1146) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1889 = qlx.apply #qlx.action<h>(%1799#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1147 = arith.constant 2.3561944901923448 : f64
    %1890 = qlx.apply #qlx.action<pauli_rotation>(%1889, %cst_1147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1891 = qlx.apply #qlx.action<h>(%1890) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1148 = arith.constant 0.78539816339744828 : f64
    %1892 = qlx.apply #qlx.action<pauli_rotation>(%1781#1, %cst_1148) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1893 = qlx.apply #qlx.action<h>(%1892) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1149 = arith.constant 0.78539816339744828 : f64
    %1894:2 = qlx.apply #qlx.action<pauli_rotation>(%1891, %1893, %cst_1149) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1150 = arith.constant 1.5707963267948966 : f64
    %1895 = qlx.apply #qlx.action<pauli_rotation>(%1894#0, %cst_1150) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1151 = arith.constant 1.5707963267948966 : f64
    %1896 = qlx.apply #qlx.action<pauli_rotation>(%1894#1, %cst_1151) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1152 = arith.constant 0.78539816339744828 : f64
    %1897:2 = qlx.apply #qlx.action<pauli_rotation>(%1895, %1896, %cst_1152) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1898 = qlx.apply #qlx.action<h>(%1888#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1153 = arith.constant 2.3561944901923448 : f64
    %1899 = qlx.apply #qlx.action<pauli_rotation>(%1898, %cst_1153) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1900 = qlx.apply #qlx.action<h>(%1899) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1901 = qlx.apply #qlx.action<h>(%1897#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1154 = arith.constant 0.78539816339744828 : f64
    %1902 = qlx.apply #qlx.action<pauli_rotation>(%1901, %cst_1154) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1903 = qlx.apply #qlx.action<h>(%1902) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1155 = arith.constant 1.250000e-01 : f64
    %1904:2 = qlx.apply #qlx.action<pauli_rotation>(%1900, %1903, %cst_1155) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1156 = arith.constant 1.5707963267948966 : f64
    %1905 = qlx.apply #qlx.action<pauli_rotation>(%1904#0, %cst_1156) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1157 = arith.constant 1.5707963267948966 : f64
    %1906 = qlx.apply #qlx.action<pauli_rotation>(%1904#1, %cst_1157) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1158 = arith.constant 1.250000e-01 : f64
    %1907:2 = qlx.apply #qlx.action<pauli_rotation>(%1905, %1906, %cst_1158) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1908 = qlx.apply #qlx.action<h>(%1888#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1159 = arith.constant 1.5707963267948966 : f64
    %1909 = qlx.apply #qlx.action<pauli_rotation>(%1908, %cst_1159) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1910 = qlx.apply #qlx.action<h>(%1909) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1911 = qlx.apply #qlx.action<h>(%1907#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1160 = arith.constant 0.78539816339744828 : f64
    %1912 = qlx.apply #qlx.action<pauli_rotation>(%1911, %cst_1160) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1913 = qlx.apply #qlx.action<h>(%1912) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1161 = arith.constant 0.78539816339744828 : f64
    %1914:2 = qlx.apply #qlx.action<pauli_rotation>(%1910, %1913, %cst_1161) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1162 = arith.constant 1.5707963267948966 : f64
    %1915 = qlx.apply #qlx.action<pauli_rotation>(%1914#0, %cst_1162) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1163 = arith.constant 1.5707963267948966 : f64
    %1916 = qlx.apply #qlx.action<pauli_rotation>(%1914#1, %cst_1163) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1164 = arith.constant 0.78539816339744828 : f64
    %1917:2 = qlx.apply #qlx.action<pauli_rotation>(%1915, %1916, %cst_1164) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1918 = qlx.apply #qlx.action<h>(%1907#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1165 = arith.constant 2.3561944901923448 : f64
    %1919 = qlx.apply #qlx.action<pauli_rotation>(%1918, %cst_1165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1920 = qlx.apply #qlx.action<h>(%1919) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1921 = qlx.apply #qlx.action<h>(%1897#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1166 = arith.constant 1.5707963267948966 : f64
    %1922 = qlx.apply #qlx.action<pauli_rotation>(%1921, %cst_1166) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1923 = qlx.apply #qlx.action<h>(%1922) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1167 = arith.constant 0.78539816339744828 : f64
    %1924:2 = qlx.apply #qlx.action<pauli_rotation>(%1920, %1923, %cst_1167) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1168 = arith.constant 1.5707963267948966 : f64
    %1925 = qlx.apply #qlx.action<pauli_rotation>(%1924#0, %cst_1168) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1169 = arith.constant 1.5707963267948966 : f64
    %1926 = qlx.apply #qlx.action<pauli_rotation>(%1924#1, %cst_1169) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1170 = arith.constant 0.78539816339744828 : f64
    %1927:2 = qlx.apply #qlx.action<pauli_rotation>(%1925, %1926, %cst_1170) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1928 = qlx.apply #qlx.action<h>(%1878#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1171 = arith.constant 2.3561944901923448 : f64
    %1929 = qlx.apply #qlx.action<pauli_rotation>(%1928, %cst_1171) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1930 = qlx.apply #qlx.action<h>(%1929) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1931 = qlx.apply #qlx.action<h>(%1917#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1172 = arith.constant 2.3561944901923448 : f64
    %1932 = qlx.apply #qlx.action<pauli_rotation>(%1931, %cst_1172) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1933 = qlx.apply #qlx.action<h>(%1932) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1173 = arith.constant 1.5707963267948966 : f64
    %1934:2 = qlx.apply #qlx.action<pauli_rotation>(%1930, %1933, %cst_1173) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1174 = arith.constant 1.5707963267948966 : f64
    %1935 = qlx.apply #qlx.action<pauli_rotation>(%1934#0, %cst_1174) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1175 = arith.constant 1.5707963267948966 : f64
    %1936 = qlx.apply #qlx.action<pauli_rotation>(%1934#1, %cst_1175) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1176 = arith.constant 1.5707963267948966 : f64
    %1937:2 = qlx.apply #qlx.action<pauli_rotation>(%1935, %1936, %cst_1176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1938 = qlx.apply #qlx.action<h>(%1878#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1177 = arith.constant 2.3561944901923448 : f64
    %1939 = qlx.apply #qlx.action<pauli_rotation>(%1938, %cst_1177) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1940 = qlx.apply #qlx.action<h>(%1939) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1941 = qlx.apply #qlx.action<h>(%1937#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1178 = arith.constant 3.1415926535897931 : f64
    %1942 = qlx.apply #qlx.action<pauli_rotation>(%1941, %cst_1178) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1943 = qlx.apply #qlx.action<h>(%1942) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1179 = arith.constant 1.5707963267948966 : f64
    %1944:2 = qlx.apply #qlx.action<pauli_rotation>(%1940, %1943, %cst_1179) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1180 = arith.constant 1.5707963267948966 : f64
    %1945 = qlx.apply #qlx.action<pauli_rotation>(%1944#0, %cst_1180) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1181 = arith.constant 1.5707963267948966 : f64
    %1946 = qlx.apply #qlx.action<pauli_rotation>(%1944#1, %cst_1181) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1182 = arith.constant 1.5707963267948966 : f64
    %1947:2 = qlx.apply #qlx.action<pauli_rotation>(%1945, %1946, %cst_1182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1948 = qlx.apply #qlx.action<h>(%1937#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1183 = arith.constant 3.1415926535897931 : f64
    %1949 = qlx.apply #qlx.action<pauli_rotation>(%1948, %cst_1183) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1950 = qlx.apply #qlx.action<h>(%1949) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1951 = qlx.apply #qlx.action<h>(%1917#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1184 = arith.constant 2.3561944901923448 : f64
    %1952 = qlx.apply #qlx.action<pauli_rotation>(%1951, %cst_1184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1953 = qlx.apply #qlx.action<h>(%1952) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1185 = arith.constant 1.5707963267948966 : f64
    %1954:2 = qlx.apply #qlx.action<pauli_rotation>(%1950, %1953, %cst_1185) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1186 = arith.constant 1.5707963267948966 : f64
    %1955 = qlx.apply #qlx.action<pauli_rotation>(%1954#0, %cst_1186) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1187 = arith.constant 1.5707963267948966 : f64
    %1956 = qlx.apply #qlx.action<pauli_rotation>(%1954#1, %cst_1187) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1188 = arith.constant 1.5707963267948966 : f64
    %1957:2 = qlx.apply #qlx.action<pauli_rotation>(%1955, %1956, %cst_1188) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1958 = qlx.apply #qlx.action<h>(%1868#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1189 = arith.constant 2.3561944901923448 : f64
    %1959 = qlx.apply #qlx.action<pauli_rotation>(%1958, %cst_1189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1960 = qlx.apply #qlx.action<h>(%1959) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1961 = qlx.apply #qlx.action<h>(%1947#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1190 = arith.constant 3.1415926535897931 : f64
    %1962 = qlx.apply #qlx.action<pauli_rotation>(%1961, %cst_1190) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1963 = qlx.apply #qlx.action<h>(%1962) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1191 = arith.constant 1.5707963267948966 : f64
    %1964:2 = qlx.apply #qlx.action<pauli_rotation>(%1960, %1963, %cst_1191) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1192 = arith.constant 1.5707963267948966 : f64
    %1965 = qlx.apply #qlx.action<pauli_rotation>(%1964#0, %cst_1192) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1193 = arith.constant 1.5707963267948966 : f64
    %1966 = qlx.apply #qlx.action<pauli_rotation>(%1964#1, %cst_1193) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1194 = arith.constant 1.5707963267948966 : f64
    %1967:2 = qlx.apply #qlx.action<pauli_rotation>(%1965, %1966, %cst_1194) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1968 = qlx.apply #qlx.action<h>(%1947#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1195 = arith.constant 3.1415926535897931 : f64
    %1969 = qlx.apply #qlx.action<pauli_rotation>(%1968, %cst_1195) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1970 = qlx.apply #qlx.action<h>(%1969) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1971 = qlx.apply #qlx.action<h>(%1957#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1196 = arith.constant 3.1415926535897931 : f64
    %1972 = qlx.apply #qlx.action<pauli_rotation>(%1971, %cst_1196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1973 = qlx.apply #qlx.action<h>(%1972) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1197 = arith.constant 1.5707963267948966 : f64
    %1974:2 = qlx.apply #qlx.action<pauli_rotation>(%1970, %1973, %cst_1197) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1198 = arith.constant 1.5707963267948966 : f64
    %1975 = qlx.apply #qlx.action<pauli_rotation>(%1974#0, %cst_1198) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1199 = arith.constant 1.5707963267948966 : f64
    %1976 = qlx.apply #qlx.action<pauli_rotation>(%1974#1, %cst_1199) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1200 = arith.constant 1.5707963267948966 : f64
    %1977:2 = qlx.apply #qlx.action<pauli_rotation>(%1975, %1976, %cst_1200) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1978 = qlx.apply #qlx.action<h>(%1957#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1201 = arith.constant 3.1415926535897931 : f64
    %1979 = qlx.apply #qlx.action<pauli_rotation>(%1978, %cst_1201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1980 = qlx.apply #qlx.action<h>(%1979) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1981 = qlx.apply #qlx.action<h>(%1927#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1202 = arith.constant 2.3561944901923448 : f64
    %1982 = qlx.apply #qlx.action<pauli_rotation>(%1981, %cst_1202) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1983 = qlx.apply #qlx.action<h>(%1982) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1203 = arith.constant 1.5707963267948966 : f64
    %1984:2 = qlx.apply #qlx.action<pauli_rotation>(%1980, %1983, %cst_1203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1204 = arith.constant 1.5707963267948966 : f64
    %1985 = qlx.apply #qlx.action<pauli_rotation>(%1984#0, %cst_1204) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1205 = arith.constant 1.5707963267948966 : f64
    %1986 = qlx.apply #qlx.action<pauli_rotation>(%1984#1, %cst_1205) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1206 = arith.constant 1.5707963267948966 : f64
    %1987:2 = qlx.apply #qlx.action<pauli_rotation>(%1985, %1986, %cst_1206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1988 = qlx.apply #qlx.action<h>(%1868#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1207 = arith.constant 2.3561944901923448 : f64
    %1989 = qlx.apply #qlx.action<pauli_rotation>(%1988, %cst_1207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1990 = qlx.apply #qlx.action<h>(%1967#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1208 = arith.constant 3.1415926535897931 : f64
    %1991 = qlx.apply #qlx.action<pauli_rotation>(%1990, %cst_1208) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1209 = arith.constant 1.250000e-01 : f64
    %1992:2 = qlx.apply #qlx.action<pauli_rotation>(%1989, %1991, %cst_1209) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1993 = qlx.apply #qlx.action<h>(%1967#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1210 = arith.constant 3.1415926535897931 : f64
    %1994 = qlx.apply #qlx.action<pauli_rotation>(%1993, %cst_1210) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1995 = qlx.apply #qlx.action<h>(%1977#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1211 = arith.constant 3.1415926535897931 : f64
    %1996 = qlx.apply #qlx.action<pauli_rotation>(%1995, %cst_1211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1212 = arith.constant 1.250000e-01 : f64
    %1997:2 = qlx.apply #qlx.action<pauli_rotation>(%1994, %1996, %cst_1212) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1998 = qlx.apply #qlx.action<h>(%1977#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1213 = arith.constant 3.1415926535897931 : f64
    %1999 = qlx.apply #qlx.action<pauli_rotation>(%1998, %cst_1213) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2000 = qlx.apply #qlx.action<h>(%1987#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1214 = arith.constant 3.1415926535897931 : f64
    %2001 = qlx.apply #qlx.action<pauli_rotation>(%2000, %cst_1214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1215 = arith.constant 1.250000e-01 : f64
    %2002:2 = qlx.apply #qlx.action<pauli_rotation>(%1999, %2001, %cst_1215) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2003 = qlx.apply #qlx.action<h>(%1987#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1216 = arith.constant 3.1415926535897931 : f64
    %2004 = qlx.apply #qlx.action<pauli_rotation>(%2003, %cst_1216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2005 = qlx.apply #qlx.action<h>(%1927#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1217 = arith.constant 2.3561944901923448 : f64
    %2006 = qlx.apply #qlx.action<pauli_rotation>(%2005, %cst_1217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1218 = arith.constant 1.250000e-01 : f64
    %2007:2 = qlx.apply #qlx.action<pauli_rotation>(%2004, %2006, %cst_1218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2008 = qlx.apply #qlx.action<h>(%1992#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2009 = qlx.apply #qlx.action<h>(%1997#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1219 = arith.constant 1.5707963267948966 : f64
    %2010:2 = qlx.apply #qlx.action<pauli_rotation>(%2008, %2009, %cst_1219) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1220 = arith.constant 1.5707963267948966 : f64
    %2011 = qlx.apply #qlx.action<pauli_rotation>(%2010#0, %cst_1220) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1221 = arith.constant 1.5707963267948966 : f64
    %2012 = qlx.apply #qlx.action<pauli_rotation>(%2010#1, %cst_1221) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1222 = arith.constant 1.5707963267948966 : f64
    %2013:2 = qlx.apply #qlx.action<pauli_rotation>(%2011, %2012, %cst_1222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2014 = qlx.apply #qlx.action<h>(%1997#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2015 = qlx.apply #qlx.action<h>(%2002#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1223 = arith.constant 1.5707963267948966 : f64
    %2016:2 = qlx.apply #qlx.action<pauli_rotation>(%2014, %2015, %cst_1223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1224 = arith.constant 1.5707963267948966 : f64
    %2017 = qlx.apply #qlx.action<pauli_rotation>(%2016#0, %cst_1224) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1225 = arith.constant 1.5707963267948966 : f64
    %2018 = qlx.apply #qlx.action<pauli_rotation>(%2016#1, %cst_1225) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1226 = arith.constant 1.5707963267948966 : f64
    %2019:2 = qlx.apply #qlx.action<pauli_rotation>(%2017, %2018, %cst_1226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2020 = qlx.apply #qlx.action<h>(%2002#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2021 = qlx.apply #qlx.action<h>(%2007#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1227 = arith.constant 1.5707963267948966 : f64
    %2022:2 = qlx.apply #qlx.action<pauli_rotation>(%2020, %2021, %cst_1227) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1228 = arith.constant 1.5707963267948966 : f64
    %2023 = qlx.apply #qlx.action<pauli_rotation>(%2022#0, %cst_1228) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1229 = arith.constant 1.5707963267948966 : f64
    %2024 = qlx.apply #qlx.action<pauli_rotation>(%2022#1, %cst_1229) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1230 = arith.constant 1.5707963267948966 : f64
    %2025:2 = qlx.apply #qlx.action<pauli_rotation>(%2023, %2024, %cst_1230) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2026 = qlx.apply #qlx.action<h>(%2013#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1231 = arith.constant 3.1415926535897931 : f64
    %2027 = qlx.apply #qlx.action<pauli_rotation>(%2026, %cst_1231) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2028 = qlx.apply #qlx.action<h>(%2027) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2029 = qlx.apply #qlx.action<h>(%2019#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1232 = arith.constant 3.1415926535897931 : f64
    %2030 = qlx.apply #qlx.action<pauli_rotation>(%2029, %cst_1232) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2031 = qlx.apply #qlx.action<h>(%2030) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1233 = arith.constant 1.5707963267948966 : f64
    %2032:2 = qlx.apply #qlx.action<pauli_rotation>(%2028, %2031, %cst_1233) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1234 = arith.constant 1.5707963267948966 : f64
    %2033 = qlx.apply #qlx.action<pauli_rotation>(%2032#0, %cst_1234) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1235 = arith.constant 1.5707963267948966 : f64
    %2034 = qlx.apply #qlx.action<pauli_rotation>(%2032#1, %cst_1235) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1236 = arith.constant 1.5707963267948966 : f64
    %2035:2 = qlx.apply #qlx.action<pauli_rotation>(%2033, %2034, %cst_1236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2036 = qlx.apply #qlx.action<h>(%2019#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1237 = arith.constant 3.1415926535897931 : f64
    %2037 = qlx.apply #qlx.action<pauli_rotation>(%2036, %cst_1237) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2038 = qlx.apply #qlx.action<h>(%2037) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2039 = qlx.apply #qlx.action<h>(%2025#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1238 = arith.constant 3.1415926535897931 : f64
    %2040 = qlx.apply #qlx.action<pauli_rotation>(%2039, %cst_1238) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2041 = qlx.apply #qlx.action<h>(%2040) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1239 = arith.constant 1.5707963267948966 : f64
    %2042:2 = qlx.apply #qlx.action<pauli_rotation>(%2038, %2041, %cst_1239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1240 = arith.constant 1.5707963267948966 : f64
    %2043 = qlx.apply #qlx.action<pauli_rotation>(%2042#0, %cst_1240) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1241 = arith.constant 1.5707963267948966 : f64
    %2044 = qlx.apply #qlx.action<pauli_rotation>(%2042#1, %cst_1241) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1242 = arith.constant 1.5707963267948966 : f64
    %2045:2 = qlx.apply #qlx.action<pauli_rotation>(%2043, %2044, %cst_1242) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2046 = qlx.apply #qlx.action<h>(%2035#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1243 = arith.constant 3.1415926535897931 : f64
    %2047 = qlx.apply #qlx.action<pauli_rotation>(%2046, %cst_1243) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2048 = qlx.apply #qlx.action<h>(%2047) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2049 = qlx.apply #qlx.action<h>(%2045#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1244 = arith.constant 3.1415926535897931 : f64
    %2050 = qlx.apply #qlx.action<pauli_rotation>(%2049, %cst_1244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2051 = qlx.apply #qlx.action<h>(%2050) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1245 = arith.constant 1.5707963267948966 : f64
    %2052:2 = qlx.apply #qlx.action<pauli_rotation>(%2048, %2051, %cst_1245) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1246 = arith.constant 1.5707963267948966 : f64
    %2053 = qlx.apply #qlx.action<pauli_rotation>(%2052#0, %cst_1246) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1247 = arith.constant 1.5707963267948966 : f64
    %2054 = qlx.apply #qlx.action<pauli_rotation>(%2052#1, %cst_1247) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1248 = arith.constant 1.5707963267948966 : f64
    %2055:2 = qlx.apply #qlx.action<pauli_rotation>(%2053, %2054, %cst_1248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1249 = arith.constant 0.78539816339744828 : f64
    %2056 = qlx.apply #qlx.action<pauli_rotation>(%1992#0, %cst_1249) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2057 = qlx.apply #qlx.action<h>(%2056) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2058 = qlx.apply #qlx.action<h>(%2013#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1250 = arith.constant 2.3561944901923448 : f64
    %2059 = qlx.apply #qlx.action<pauli_rotation>(%2058, %cst_1250) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2060 = qlx.apply #qlx.action<h>(%2059) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1251 = arith.constant 0.78539816339744828 : f64
    %2061:2 = qlx.apply #qlx.action<pauli_rotation>(%2057, %2060, %cst_1251) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1252 = arith.constant 1.5707963267948966 : f64
    %2062 = qlx.apply #qlx.action<pauli_rotation>(%2061#0, %cst_1252) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1253 = arith.constant 1.5707963267948966 : f64
    %2063 = qlx.apply #qlx.action<pauli_rotation>(%2061#1, %cst_1253) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1254 = arith.constant 0.78539816339744828 : f64
    %2064:2 = qlx.apply #qlx.action<pauli_rotation>(%2062, %2063, %cst_1254) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2065 = qlx.apply #qlx.action<h>(%2035#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1255 = arith.constant 2.3561944901923448 : f64
    %2066 = qlx.apply #qlx.action<pauli_rotation>(%2065, %cst_1255) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2067 = qlx.apply #qlx.action<h>(%2066) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2068 = qlx.apply #qlx.action<h>(%2055#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1256 = arith.constant 2.3561944901923448 : f64
    %2069 = qlx.apply #qlx.action<pauli_rotation>(%2068, %cst_1256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2070 = qlx.apply #qlx.action<h>(%2069) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1257 = arith.constant 0.78539816339744828 : f64
    %2071:2 = qlx.apply #qlx.action<pauli_rotation>(%2067, %2070, %cst_1257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1258 = arith.constant 1.5707963267948966 : f64
    %2072 = qlx.apply #qlx.action<pauli_rotation>(%2071#0, %cst_1258) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1259 = arith.constant 1.5707963267948966 : f64
    %2073 = qlx.apply #qlx.action<pauli_rotation>(%2071#1, %cst_1259) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1260 = arith.constant 0.78539816339744828 : f64
    %2074:2 = qlx.apply #qlx.action<pauli_rotation>(%2072, %2073, %cst_1260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2075 = qlx.apply #qlx.action<h>(%2064#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1261 = arith.constant 2.3561944901923448 : f64
    %2076 = qlx.apply #qlx.action<pauli_rotation>(%2075, %cst_1261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2077 = qlx.apply #qlx.action<h>(%2076) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2078 = qlx.apply #qlx.action<h>(%2074#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1262 = arith.constant 0.78539816339744828 : f64
    %2079 = qlx.apply #qlx.action<pauli_rotation>(%2078, %cst_1262) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2080 = qlx.apply #qlx.action<h>(%2079) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1263 = arith.constant 1.250000e-01 : f64
    %2081:2 = qlx.apply #qlx.action<pauli_rotation>(%2077, %2080, %cst_1263) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1264 = arith.constant 1.5707963267948966 : f64
    %2082 = qlx.apply #qlx.action<pauli_rotation>(%2081#0, %cst_1264) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1265 = arith.constant 1.5707963267948966 : f64
    %2083 = qlx.apply #qlx.action<pauli_rotation>(%2081#1, %cst_1265) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1266 = arith.constant 1.250000e-01 : f64
    %2084:2 = qlx.apply #qlx.action<pauli_rotation>(%2082, %2083, %cst_1266) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2085 = qlx.apply #qlx.action<h>(%2064#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1267 = arith.constant 1.5707963267948966 : f64
    %2086 = qlx.apply #qlx.action<pauli_rotation>(%2085, %cst_1267) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2087 = qlx.apply #qlx.action<h>(%2086) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2088 = qlx.apply #qlx.action<h>(%2084#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1268 = arith.constant 0.78539816339744828 : f64
    %2089 = qlx.apply #qlx.action<pauli_rotation>(%2088, %cst_1268) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2090 = qlx.apply #qlx.action<h>(%2089) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1269 = arith.constant 0.78539816339744828 : f64
    %2091:2 = qlx.apply #qlx.action<pauli_rotation>(%2087, %2090, %cst_1269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1270 = arith.constant 1.5707963267948966 : f64
    %2092 = qlx.apply #qlx.action<pauli_rotation>(%2091#0, %cst_1270) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1271 = arith.constant 1.5707963267948966 : f64
    %2093 = qlx.apply #qlx.action<pauli_rotation>(%2091#1, %cst_1271) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1272 = arith.constant 0.78539816339744828 : f64
    %2094:2 = qlx.apply #qlx.action<pauli_rotation>(%2092, %2093, %cst_1272) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2095 = qlx.apply #qlx.action<h>(%2084#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1273 = arith.constant 2.3561944901923448 : f64
    %2096 = qlx.apply #qlx.action<pauli_rotation>(%2095, %cst_1273) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2097 = qlx.apply #qlx.action<h>(%2096) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2098 = qlx.apply #qlx.action<h>(%2074#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1274 = arith.constant 1.5707963267948966 : f64
    %2099 = qlx.apply #qlx.action<pauli_rotation>(%2098, %cst_1274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2100 = qlx.apply #qlx.action<h>(%2099) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1275 = arith.constant 0.78539816339744828 : f64
    %2101:2 = qlx.apply #qlx.action<pauli_rotation>(%2097, %2100, %cst_1275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1276 = arith.constant 1.5707963267948966 : f64
    %2102 = qlx.apply #qlx.action<pauli_rotation>(%2101#0, %cst_1276) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1277 = arith.constant 1.5707963267948966 : f64
    %2103 = qlx.apply #qlx.action<pauli_rotation>(%2101#1, %cst_1277) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1278 = arith.constant 0.78539816339744828 : f64
    %2104:2 = qlx.apply #qlx.action<pauli_rotation>(%2102, %2103, %cst_1278) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2105 = qlx.apply #qlx.action<h>(%2055#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1279 = arith.constant 2.3561944901923448 : f64
    %2106 = qlx.apply #qlx.action<pauli_rotation>(%2105, %cst_1279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2107 = qlx.apply #qlx.action<h>(%2106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2108 = qlx.apply #qlx.action<h>(%2045#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1280 = arith.constant 2.3561944901923448 : f64
    %2109 = qlx.apply #qlx.action<pauli_rotation>(%2108, %cst_1280) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2110 = qlx.apply #qlx.action<h>(%2109) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1281 = arith.constant 0.78539816339744828 : f64
    %2111:2 = qlx.apply #qlx.action<pauli_rotation>(%2107, %2110, %cst_1281) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1282 = arith.constant 1.5707963267948966 : f64
    %2112 = qlx.apply #qlx.action<pauli_rotation>(%2111#0, %cst_1282) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1283 = arith.constant 1.5707963267948966 : f64
    %2113 = qlx.apply #qlx.action<pauli_rotation>(%2111#1, %cst_1283) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1284 = arith.constant 0.78539816339744828 : f64
    %2114:2 = qlx.apply #qlx.action<pauli_rotation>(%2112, %2113, %cst_1284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2115 = qlx.apply #qlx.action<h>(%2025#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1285 = arith.constant 2.3561944901923448 : f64
    %2116 = qlx.apply #qlx.action<pauli_rotation>(%2115, %cst_1285) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2117 = qlx.apply #qlx.action<h>(%2116) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1286 = arith.constant 0.78539816339744828 : f64
    %2118 = qlx.apply #qlx.action<pauli_rotation>(%2007#1, %cst_1286) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2119 = qlx.apply #qlx.action<h>(%2118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1287 = arith.constant 0.78539816339744828 : f64
    %2120:2 = qlx.apply #qlx.action<pauli_rotation>(%2117, %2119, %cst_1287) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1288 = arith.constant 1.5707963267948966 : f64
    %2121 = qlx.apply #qlx.action<pauli_rotation>(%2120#0, %cst_1288) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1289 = arith.constant 1.5707963267948966 : f64
    %2122 = qlx.apply #qlx.action<pauli_rotation>(%2120#1, %cst_1289) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1290 = arith.constant 0.78539816339744828 : f64
    %2123:2 = qlx.apply #qlx.action<pauli_rotation>(%2121, %2122, %cst_1290) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2124 = qlx.apply #qlx.action<h>(%2114#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1291 = arith.constant 2.3561944901923448 : f64
    %2125 = qlx.apply #qlx.action<pauli_rotation>(%2124, %cst_1291) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2126 = qlx.apply #qlx.action<h>(%2125) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2127 = qlx.apply #qlx.action<h>(%2123#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1292 = arith.constant 0.78539816339744828 : f64
    %2128 = qlx.apply #qlx.action<pauli_rotation>(%2127, %cst_1292) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2129 = qlx.apply #qlx.action<h>(%2128) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1293 = arith.constant 1.250000e-01 : f64
    %2130:2 = qlx.apply #qlx.action<pauli_rotation>(%2126, %2129, %cst_1293) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1294 = arith.constant 1.5707963267948966 : f64
    %2131 = qlx.apply #qlx.action<pauli_rotation>(%2130#0, %cst_1294) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1295 = arith.constant 1.5707963267948966 : f64
    %2132 = qlx.apply #qlx.action<pauli_rotation>(%2130#1, %cst_1295) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1296 = arith.constant 1.250000e-01 : f64
    %2133:2 = qlx.apply #qlx.action<pauli_rotation>(%2131, %2132, %cst_1296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2134 = qlx.apply #qlx.action<h>(%2114#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1297 = arith.constant 1.5707963267948966 : f64
    %2135 = qlx.apply #qlx.action<pauli_rotation>(%2134, %cst_1297) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2136 = qlx.apply #qlx.action<h>(%2135) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2137 = qlx.apply #qlx.action<h>(%2133#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1298 = arith.constant 0.78539816339744828 : f64
    %2138 = qlx.apply #qlx.action<pauli_rotation>(%2137, %cst_1298) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2139 = qlx.apply #qlx.action<h>(%2138) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1299 = arith.constant 0.78539816339744828 : f64
    %2140:2 = qlx.apply #qlx.action<pauli_rotation>(%2136, %2139, %cst_1299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1300 = arith.constant 1.5707963267948966 : f64
    %2141 = qlx.apply #qlx.action<pauli_rotation>(%2140#0, %cst_1300) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1301 = arith.constant 1.5707963267948966 : f64
    %2142 = qlx.apply #qlx.action<pauli_rotation>(%2140#1, %cst_1301) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1302 = arith.constant 0.78539816339744828 : f64
    %2143:2 = qlx.apply #qlx.action<pauli_rotation>(%2141, %2142, %cst_1302) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2144 = qlx.apply #qlx.action<h>(%2133#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1303 = arith.constant 2.3561944901923448 : f64
    %2145 = qlx.apply #qlx.action<pauli_rotation>(%2144, %cst_1303) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2146 = qlx.apply #qlx.action<h>(%2145) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2147 = qlx.apply #qlx.action<h>(%2123#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1304 = arith.constant 1.5707963267948966 : f64
    %2148 = qlx.apply #qlx.action<pauli_rotation>(%2147, %cst_1304) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2149 = qlx.apply #qlx.action<h>(%2148) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1305 = arith.constant 0.78539816339744828 : f64
    %2150:2 = qlx.apply #qlx.action<pauli_rotation>(%2146, %2149, %cst_1305) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1306 = arith.constant 1.5707963267948966 : f64
    %2151 = qlx.apply #qlx.action<pauli_rotation>(%2150#0, %cst_1306) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1307 = arith.constant 1.5707963267948966 : f64
    %2152 = qlx.apply #qlx.action<pauli_rotation>(%2150#1, %cst_1307) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1308 = arith.constant 0.78539816339744828 : f64
    %2153:2 = qlx.apply #qlx.action<pauli_rotation>(%2151, %2152, %cst_1308) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2154 = qlx.apply #qlx.action<h>(%2104#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1309 = arith.constant 2.3561944901923448 : f64
    %2155 = qlx.apply #qlx.action<pauli_rotation>(%2154, %cst_1309) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2156 = qlx.apply #qlx.action<h>(%2155) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2157 = qlx.apply #qlx.action<h>(%2143#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1310 = arith.constant 2.3561944901923448 : f64
    %2158 = qlx.apply #qlx.action<pauli_rotation>(%2157, %cst_1310) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2159 = qlx.apply #qlx.action<h>(%2158) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1311 = arith.constant 1.5707963267948966 : f64
    %2160:2 = qlx.apply #qlx.action<pauli_rotation>(%2156, %2159, %cst_1311) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1312 = arith.constant 1.5707963267948966 : f64
    %2161 = qlx.apply #qlx.action<pauli_rotation>(%2160#0, %cst_1312) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1313 = arith.constant 1.5707963267948966 : f64
    %2162 = qlx.apply #qlx.action<pauli_rotation>(%2160#1, %cst_1313) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1314 = arith.constant 1.5707963267948966 : f64
    %2163:2 = qlx.apply #qlx.action<pauli_rotation>(%2161, %2162, %cst_1314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2164 = qlx.apply #qlx.action<h>(%2104#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1315 = arith.constant 2.3561944901923448 : f64
    %2165 = qlx.apply #qlx.action<pauli_rotation>(%2164, %cst_1315) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2166 = qlx.apply #qlx.action<h>(%2165) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2167 = qlx.apply #qlx.action<h>(%2163#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1316 = arith.constant 3.1415926535897931 : f64
    %2168 = qlx.apply #qlx.action<pauli_rotation>(%2167, %cst_1316) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2169 = qlx.apply #qlx.action<h>(%2168) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1317 = arith.constant 1.5707963267948966 : f64
    %2170:2 = qlx.apply #qlx.action<pauli_rotation>(%2166, %2169, %cst_1317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1318 = arith.constant 1.5707963267948966 : f64
    %2171 = qlx.apply #qlx.action<pauli_rotation>(%2170#0, %cst_1318) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1319 = arith.constant 1.5707963267948966 : f64
    %2172 = qlx.apply #qlx.action<pauli_rotation>(%2170#1, %cst_1319) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1320 = arith.constant 1.5707963267948966 : f64
    %2173:2 = qlx.apply #qlx.action<pauli_rotation>(%2171, %2172, %cst_1320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2174 = qlx.apply #qlx.action<h>(%2163#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1321 = arith.constant 3.1415926535897931 : f64
    %2175 = qlx.apply #qlx.action<pauli_rotation>(%2174, %cst_1321) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2176 = qlx.apply #qlx.action<h>(%2175) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2177 = qlx.apply #qlx.action<h>(%2143#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1322 = arith.constant 2.3561944901923448 : f64
    %2178 = qlx.apply #qlx.action<pauli_rotation>(%2177, %cst_1322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2179 = qlx.apply #qlx.action<h>(%2178) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1323 = arith.constant 1.5707963267948966 : f64
    %2180:2 = qlx.apply #qlx.action<pauli_rotation>(%2176, %2179, %cst_1323) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1324 = arith.constant 1.5707963267948966 : f64
    %2181 = qlx.apply #qlx.action<pauli_rotation>(%2180#0, %cst_1324) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1325 = arith.constant 1.5707963267948966 : f64
    %2182 = qlx.apply #qlx.action<pauli_rotation>(%2180#1, %cst_1325) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1326 = arith.constant 1.5707963267948966 : f64
    %2183:2 = qlx.apply #qlx.action<pauli_rotation>(%2181, %2182, %cst_1326) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2184 = qlx.apply #qlx.action<h>(%2094#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1327 = arith.constant 2.3561944901923448 : f64
    %2185 = qlx.apply #qlx.action<pauli_rotation>(%2184, %cst_1327) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2186 = qlx.apply #qlx.action<h>(%2185) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2187 = qlx.apply #qlx.action<h>(%2173#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1328 = arith.constant 3.1415926535897931 : f64
    %2188 = qlx.apply #qlx.action<pauli_rotation>(%2187, %cst_1328) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2189 = qlx.apply #qlx.action<h>(%2188) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1329 = arith.constant 1.5707963267948966 : f64
    %2190:2 = qlx.apply #qlx.action<pauli_rotation>(%2186, %2189, %cst_1329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1330 = arith.constant 1.5707963267948966 : f64
    %2191 = qlx.apply #qlx.action<pauli_rotation>(%2190#0, %cst_1330) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1331 = arith.constant 1.5707963267948966 : f64
    %2192 = qlx.apply #qlx.action<pauli_rotation>(%2190#1, %cst_1331) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1332 = arith.constant 1.5707963267948966 : f64
    %2193:2 = qlx.apply #qlx.action<pauli_rotation>(%2191, %2192, %cst_1332) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2194 = qlx.apply #qlx.action<h>(%2173#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1333 = arith.constant 3.1415926535897931 : f64
    %2195 = qlx.apply #qlx.action<pauli_rotation>(%2194, %cst_1333) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2196 = qlx.apply #qlx.action<h>(%2195) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2197 = qlx.apply #qlx.action<h>(%2183#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1334 = arith.constant 3.1415926535897931 : f64
    %2198 = qlx.apply #qlx.action<pauli_rotation>(%2197, %cst_1334) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2199 = qlx.apply #qlx.action<h>(%2198) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1335 = arith.constant 1.5707963267948966 : f64
    %2200:2 = qlx.apply #qlx.action<pauli_rotation>(%2196, %2199, %cst_1335) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1336 = arith.constant 1.5707963267948966 : f64
    %2201 = qlx.apply #qlx.action<pauli_rotation>(%2200#0, %cst_1336) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1337 = arith.constant 1.5707963267948966 : f64
    %2202 = qlx.apply #qlx.action<pauli_rotation>(%2200#1, %cst_1337) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1338 = arith.constant 1.5707963267948966 : f64
    %2203:2 = qlx.apply #qlx.action<pauli_rotation>(%2201, %2202, %cst_1338) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2204 = qlx.apply #qlx.action<h>(%2183#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1339 = arith.constant 3.1415926535897931 : f64
    %2205 = qlx.apply #qlx.action<pauli_rotation>(%2204, %cst_1339) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2206 = qlx.apply #qlx.action<h>(%2205) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2207 = qlx.apply #qlx.action<h>(%2153#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1340 = arith.constant 2.3561944901923448 : f64
    %2208 = qlx.apply #qlx.action<pauli_rotation>(%2207, %cst_1340) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2209 = qlx.apply #qlx.action<h>(%2208) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1341 = arith.constant 1.5707963267948966 : f64
    %2210:2 = qlx.apply #qlx.action<pauli_rotation>(%2206, %2209, %cst_1341) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1342 = arith.constant 1.5707963267948966 : f64
    %2211 = qlx.apply #qlx.action<pauli_rotation>(%2210#0, %cst_1342) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1343 = arith.constant 1.5707963267948966 : f64
    %2212 = qlx.apply #qlx.action<pauli_rotation>(%2210#1, %cst_1343) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1344 = arith.constant 1.5707963267948966 : f64
    %2213:2 = qlx.apply #qlx.action<pauli_rotation>(%2211, %2212, %cst_1344) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2214 = qlx.apply #qlx.action<h>(%2094#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1345 = arith.constant 2.3561944901923448 : f64
    %2215 = qlx.apply #qlx.action<pauli_rotation>(%2214, %cst_1345) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2216 = qlx.apply #qlx.action<h>(%2193#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1346 = arith.constant 3.1415926535897931 : f64
    %2217 = qlx.apply #qlx.action<pauli_rotation>(%2216, %cst_1346) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1347 = arith.constant 1.250000e-01 : f64
    %2218:2 = qlx.apply #qlx.action<pauli_rotation>(%2215, %2217, %cst_1347) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2219 = qlx.apply #qlx.action<h>(%2193#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1348 = arith.constant 3.1415926535897931 : f64
    %2220 = qlx.apply #qlx.action<pauli_rotation>(%2219, %cst_1348) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2221 = qlx.apply #qlx.action<h>(%2203#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1349 = arith.constant 3.1415926535897931 : f64
    %2222 = qlx.apply #qlx.action<pauli_rotation>(%2221, %cst_1349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1350 = arith.constant 1.250000e-01 : f64
    %2223:2 = qlx.apply #qlx.action<pauli_rotation>(%2220, %2222, %cst_1350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2224 = qlx.apply #qlx.action<h>(%2203#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1351 = arith.constant 3.1415926535897931 : f64
    %2225 = qlx.apply #qlx.action<pauli_rotation>(%2224, %cst_1351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2226 = qlx.apply #qlx.action<h>(%2213#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1352 = arith.constant 3.1415926535897931 : f64
    %2227 = qlx.apply #qlx.action<pauli_rotation>(%2226, %cst_1352) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1353 = arith.constant 1.250000e-01 : f64
    %2228:2 = qlx.apply #qlx.action<pauli_rotation>(%2225, %2227, %cst_1353) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2229 = qlx.apply #qlx.action<h>(%2213#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1354 = arith.constant 3.1415926535897931 : f64
    %2230 = qlx.apply #qlx.action<pauli_rotation>(%2229, %cst_1354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2231 = qlx.apply #qlx.action<h>(%2153#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1355 = arith.constant 2.3561944901923448 : f64
    %2232 = qlx.apply #qlx.action<pauli_rotation>(%2231, %cst_1355) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1356 = arith.constant 1.250000e-01 : f64
    %2233:2 = qlx.apply #qlx.action<pauli_rotation>(%2230, %2232, %cst_1356) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2234 = qlx.apply #qlx.action<h>(%2218#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2235 = qlx.apply #qlx.action<h>(%2223#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1357 = arith.constant 1.5707963267948966 : f64
    %2236:2 = qlx.apply #qlx.action<pauli_rotation>(%2234, %2235, %cst_1357) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1358 = arith.constant 1.5707963267948966 : f64
    %2237 = qlx.apply #qlx.action<pauli_rotation>(%2236#0, %cst_1358) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1359 = arith.constant 1.5707963267948966 : f64
    %2238 = qlx.apply #qlx.action<pauli_rotation>(%2236#1, %cst_1359) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1360 = arith.constant 1.5707963267948966 : f64
    %2239:2 = qlx.apply #qlx.action<pauli_rotation>(%2237, %2238, %cst_1360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2240 = qlx.apply #qlx.action<h>(%2223#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2241 = qlx.apply #qlx.action<h>(%2228#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1361 = arith.constant 1.5707963267948966 : f64
    %2242:2 = qlx.apply #qlx.action<pauli_rotation>(%2240, %2241, %cst_1361) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1362 = arith.constant 1.5707963267948966 : f64
    %2243 = qlx.apply #qlx.action<pauli_rotation>(%2242#0, %cst_1362) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1363 = arith.constant 1.5707963267948966 : f64
    %2244 = qlx.apply #qlx.action<pauli_rotation>(%2242#1, %cst_1363) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1364 = arith.constant 1.5707963267948966 : f64
    %2245:2 = qlx.apply #qlx.action<pauli_rotation>(%2243, %2244, %cst_1364) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2246 = qlx.apply #qlx.action<h>(%2228#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2247 = qlx.apply #qlx.action<h>(%2233#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1365 = arith.constant 1.5707963267948966 : f64
    %2248:2 = qlx.apply #qlx.action<pauli_rotation>(%2246, %2247, %cst_1365) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1366 = arith.constant 1.5707963267948966 : f64
    %2249 = qlx.apply #qlx.action<pauli_rotation>(%2248#0, %cst_1366) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1367 = arith.constant 1.5707963267948966 : f64
    %2250 = qlx.apply #qlx.action<pauli_rotation>(%2248#1, %cst_1367) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1368 = arith.constant 1.5707963267948966 : f64
    %2251:2 = qlx.apply #qlx.action<pauli_rotation>(%2249, %2250, %cst_1368) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2252 = qlx.apply #qlx.action<h>(%2239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1369 = arith.constant 3.1415926535897931 : f64
    %2253 = qlx.apply #qlx.action<pauli_rotation>(%2252, %cst_1369) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2254 = qlx.apply #qlx.action<h>(%2253) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2255 = qlx.apply #qlx.action<h>(%2245#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1370 = arith.constant 3.1415926535897931 : f64
    %2256 = qlx.apply #qlx.action<pauli_rotation>(%2255, %cst_1370) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2257 = qlx.apply #qlx.action<h>(%2256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1371 = arith.constant 1.5707963267948966 : f64
    %2258:2 = qlx.apply #qlx.action<pauli_rotation>(%2254, %2257, %cst_1371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1372 = arith.constant 1.5707963267948966 : f64
    %2259 = qlx.apply #qlx.action<pauli_rotation>(%2258#0, %cst_1372) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1373 = arith.constant 1.5707963267948966 : f64
    %2260 = qlx.apply #qlx.action<pauli_rotation>(%2258#1, %cst_1373) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1374 = arith.constant 1.5707963267948966 : f64
    %2261:2 = qlx.apply #qlx.action<pauli_rotation>(%2259, %2260, %cst_1374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2262 = qlx.apply #qlx.action<h>(%2245#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1375 = arith.constant 3.1415926535897931 : f64
    %2263 = qlx.apply #qlx.action<pauli_rotation>(%2262, %cst_1375) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2264 = qlx.apply #qlx.action<h>(%2263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2265 = qlx.apply #qlx.action<h>(%2251#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1376 = arith.constant 3.1415926535897931 : f64
    %2266 = qlx.apply #qlx.action<pauli_rotation>(%2265, %cst_1376) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2267 = qlx.apply #qlx.action<h>(%2266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1377 = arith.constant 1.5707963267948966 : f64
    %2268:2 = qlx.apply #qlx.action<pauli_rotation>(%2264, %2267, %cst_1377) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1378 = arith.constant 1.5707963267948966 : f64
    %2269 = qlx.apply #qlx.action<pauli_rotation>(%2268#0, %cst_1378) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1379 = arith.constant 1.5707963267948966 : f64
    %2270 = qlx.apply #qlx.action<pauli_rotation>(%2268#1, %cst_1379) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1380 = arith.constant 1.5707963267948966 : f64
    %2271:2 = qlx.apply #qlx.action<pauli_rotation>(%2269, %2270, %cst_1380) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2272 = qlx.apply #qlx.action<h>(%2261#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1381 = arith.constant 3.1415926535897931 : f64
    %2273 = qlx.apply #qlx.action<pauli_rotation>(%2272, %cst_1381) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2274 = qlx.apply #qlx.action<h>(%2273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2275 = qlx.apply #qlx.action<h>(%2271#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1382 = arith.constant 3.1415926535897931 : f64
    %2276 = qlx.apply #qlx.action<pauli_rotation>(%2275, %cst_1382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2277 = qlx.apply #qlx.action<h>(%2276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1383 = arith.constant 1.5707963267948966 : f64
    %2278:2 = qlx.apply #qlx.action<pauli_rotation>(%2274, %2277, %cst_1383) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1384 = arith.constant 1.5707963267948966 : f64
    %2279 = qlx.apply #qlx.action<pauli_rotation>(%2278#0, %cst_1384) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1385 = arith.constant 1.5707963267948966 : f64
    %2280 = qlx.apply #qlx.action<pauli_rotation>(%2278#1, %cst_1385) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1386 = arith.constant 1.5707963267948966 : f64
    %2281:2 = qlx.apply #qlx.action<pauli_rotation>(%2279, %2280, %cst_1386) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1387 = arith.constant 0.78539816339744828 : f64
    %2282 = qlx.apply #qlx.action<pauli_rotation>(%2218#0, %cst_1387) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2283 = qlx.apply #qlx.action<h>(%2282) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2284 = qlx.apply #qlx.action<h>(%2239#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1388 = arith.constant 2.3561944901923448 : f64
    %2285 = qlx.apply #qlx.action<pauli_rotation>(%2284, %cst_1388) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2286 = qlx.apply #qlx.action<h>(%2285) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1389 = arith.constant 0.78539816339744828 : f64
    %2287:2 = qlx.apply #qlx.action<pauli_rotation>(%2283, %2286, %cst_1389) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1390 = arith.constant 1.5707963267948966 : f64
    %2288 = qlx.apply #qlx.action<pauli_rotation>(%2287#0, %cst_1390) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1391 = arith.constant 1.5707963267948966 : f64
    %2289 = qlx.apply #qlx.action<pauli_rotation>(%2287#1, %cst_1391) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1392 = arith.constant 0.78539816339744828 : f64
    %2290:2 = qlx.apply #qlx.action<pauli_rotation>(%2288, %2289, %cst_1392) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2291 = qlx.apply #qlx.action<h>(%2261#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1393 = arith.constant 2.3561944901923448 : f64
    %2292 = qlx.apply #qlx.action<pauli_rotation>(%2291, %cst_1393) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2293 = qlx.apply #qlx.action<h>(%2292) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2294 = qlx.apply #qlx.action<h>(%2281#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1394 = arith.constant 2.3561944901923448 : f64
    %2295 = qlx.apply #qlx.action<pauli_rotation>(%2294, %cst_1394) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2296 = qlx.apply #qlx.action<h>(%2295) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1395 = arith.constant 0.78539816339744828 : f64
    %2297:2 = qlx.apply #qlx.action<pauli_rotation>(%2293, %2296, %cst_1395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1396 = arith.constant 1.5707963267948966 : f64
    %2298 = qlx.apply #qlx.action<pauli_rotation>(%2297#0, %cst_1396) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1397 = arith.constant 1.5707963267948966 : f64
    %2299 = qlx.apply #qlx.action<pauli_rotation>(%2297#1, %cst_1397) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1398 = arith.constant 0.78539816339744828 : f64
    %2300:2 = qlx.apply #qlx.action<pauli_rotation>(%2298, %2299, %cst_1398) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2301 = qlx.apply #qlx.action<h>(%2290#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1399 = arith.constant 2.3561944901923448 : f64
    %2302 = qlx.apply #qlx.action<pauli_rotation>(%2301, %cst_1399) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2303 = qlx.apply #qlx.action<h>(%2302) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2304 = qlx.apply #qlx.action<h>(%2300#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1400 = arith.constant 0.78539816339744828 : f64
    %2305 = qlx.apply #qlx.action<pauli_rotation>(%2304, %cst_1400) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2306 = qlx.apply #qlx.action<h>(%2305) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1401 = arith.constant 1.250000e-01 : f64
    %2307:2 = qlx.apply #qlx.action<pauli_rotation>(%2303, %2306, %cst_1401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1402 = arith.constant 1.5707963267948966 : f64
    %2308 = qlx.apply #qlx.action<pauli_rotation>(%2307#0, %cst_1402) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1403 = arith.constant 1.5707963267948966 : f64
    %2309 = qlx.apply #qlx.action<pauli_rotation>(%2307#1, %cst_1403) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1404 = arith.constant 1.250000e-01 : f64
    %2310:2 = qlx.apply #qlx.action<pauli_rotation>(%2308, %2309, %cst_1404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2311 = qlx.apply #qlx.action<h>(%2290#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1405 = arith.constant 1.5707963267948966 : f64
    %2312 = qlx.apply #qlx.action<pauli_rotation>(%2311, %cst_1405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2313 = qlx.apply #qlx.action<h>(%2312) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2314 = qlx.apply #qlx.action<h>(%2310#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1406 = arith.constant 0.78539816339744828 : f64
    %2315 = qlx.apply #qlx.action<pauli_rotation>(%2314, %cst_1406) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2316 = qlx.apply #qlx.action<h>(%2315) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1407 = arith.constant 0.78539816339744828 : f64
    %2317:2 = qlx.apply #qlx.action<pauli_rotation>(%2313, %2316, %cst_1407) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1408 = arith.constant 1.5707963267948966 : f64
    %2318 = qlx.apply #qlx.action<pauli_rotation>(%2317#0, %cst_1408) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1409 = arith.constant 1.5707963267948966 : f64
    %2319 = qlx.apply #qlx.action<pauli_rotation>(%2317#1, %cst_1409) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1410 = arith.constant 0.78539816339744828 : f64
    %2320:2 = qlx.apply #qlx.action<pauli_rotation>(%2318, %2319, %cst_1410) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2321 = qlx.apply #qlx.action<h>(%2310#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1411 = arith.constant 2.3561944901923448 : f64
    %2322 = qlx.apply #qlx.action<pauli_rotation>(%2321, %cst_1411) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2323 = qlx.apply #qlx.action<h>(%2322) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2324 = qlx.apply #qlx.action<h>(%2300#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1412 = arith.constant 1.5707963267948966 : f64
    %2325 = qlx.apply #qlx.action<pauli_rotation>(%2324, %cst_1412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2326 = qlx.apply #qlx.action<h>(%2325) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1413 = arith.constant 0.78539816339744828 : f64
    %2327:2 = qlx.apply #qlx.action<pauli_rotation>(%2323, %2326, %cst_1413) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1414 = arith.constant 1.5707963267948966 : f64
    %2328 = qlx.apply #qlx.action<pauli_rotation>(%2327#0, %cst_1414) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1415 = arith.constant 1.5707963267948966 : f64
    %2329 = qlx.apply #qlx.action<pauli_rotation>(%2327#1, %cst_1415) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1416 = arith.constant 0.78539816339744828 : f64
    %2330:2 = qlx.apply #qlx.action<pauli_rotation>(%2328, %2329, %cst_1416) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2331 = qlx.apply #qlx.action<h>(%2281#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1417 = arith.constant 2.3561944901923448 : f64
    %2332 = qlx.apply #qlx.action<pauli_rotation>(%2331, %cst_1417) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2333 = qlx.apply #qlx.action<h>(%2332) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2334 = qlx.apply #qlx.action<h>(%2271#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1418 = arith.constant 2.3561944901923448 : f64
    %2335 = qlx.apply #qlx.action<pauli_rotation>(%2334, %cst_1418) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2336 = qlx.apply #qlx.action<h>(%2335) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1419 = arith.constant 0.78539816339744828 : f64
    %2337:2 = qlx.apply #qlx.action<pauli_rotation>(%2333, %2336, %cst_1419) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1420 = arith.constant 1.5707963267948966 : f64
    %2338 = qlx.apply #qlx.action<pauli_rotation>(%2337#0, %cst_1420) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1421 = arith.constant 1.5707963267948966 : f64
    %2339 = qlx.apply #qlx.action<pauli_rotation>(%2337#1, %cst_1421) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1422 = arith.constant 0.78539816339744828 : f64
    %2340:2 = qlx.apply #qlx.action<pauli_rotation>(%2338, %2339, %cst_1422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2341 = qlx.apply #qlx.action<h>(%2251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1423 = arith.constant 2.3561944901923448 : f64
    %2342 = qlx.apply #qlx.action<pauli_rotation>(%2341, %cst_1423) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2343 = qlx.apply #qlx.action<h>(%2342) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1424 = arith.constant 0.78539816339744828 : f64
    %2344 = qlx.apply #qlx.action<pauli_rotation>(%2233#1, %cst_1424) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2345 = qlx.apply #qlx.action<h>(%2344) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1425 = arith.constant 0.78539816339744828 : f64
    %2346:2 = qlx.apply #qlx.action<pauli_rotation>(%2343, %2345, %cst_1425) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1426 = arith.constant 1.5707963267948966 : f64
    %2347 = qlx.apply #qlx.action<pauli_rotation>(%2346#0, %cst_1426) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1427 = arith.constant 1.5707963267948966 : f64
    %2348 = qlx.apply #qlx.action<pauli_rotation>(%2346#1, %cst_1427) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1428 = arith.constant 0.78539816339744828 : f64
    %2349:2 = qlx.apply #qlx.action<pauli_rotation>(%2347, %2348, %cst_1428) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2350 = qlx.apply #qlx.action<h>(%2340#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1429 = arith.constant 2.3561944901923448 : f64
    %2351 = qlx.apply #qlx.action<pauli_rotation>(%2350, %cst_1429) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2352 = qlx.apply #qlx.action<h>(%2351) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2353 = qlx.apply #qlx.action<h>(%2349#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1430 = arith.constant 0.78539816339744828 : f64
    %2354 = qlx.apply #qlx.action<pauli_rotation>(%2353, %cst_1430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2355 = qlx.apply #qlx.action<h>(%2354) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1431 = arith.constant 1.250000e-01 : f64
    %2356:2 = qlx.apply #qlx.action<pauli_rotation>(%2352, %2355, %cst_1431) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1432 = arith.constant 1.5707963267948966 : f64
    %2357 = qlx.apply #qlx.action<pauli_rotation>(%2356#0, %cst_1432) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1433 = arith.constant 1.5707963267948966 : f64
    %2358 = qlx.apply #qlx.action<pauli_rotation>(%2356#1, %cst_1433) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1434 = arith.constant 1.250000e-01 : f64
    %2359:2 = qlx.apply #qlx.action<pauli_rotation>(%2357, %2358, %cst_1434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2360 = qlx.apply #qlx.action<h>(%2340#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1435 = arith.constant 1.5707963267948966 : f64
    %2361 = qlx.apply #qlx.action<pauli_rotation>(%2360, %cst_1435) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2362 = qlx.apply #qlx.action<h>(%2361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2363 = qlx.apply #qlx.action<h>(%2359#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1436 = arith.constant 0.78539816339744828 : f64
    %2364 = qlx.apply #qlx.action<pauli_rotation>(%2363, %cst_1436) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2365 = qlx.apply #qlx.action<h>(%2364) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1437 = arith.constant 0.78539816339744828 : f64
    %2366:2 = qlx.apply #qlx.action<pauli_rotation>(%2362, %2365, %cst_1437) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1438 = arith.constant 1.5707963267948966 : f64
    %2367 = qlx.apply #qlx.action<pauli_rotation>(%2366#0, %cst_1438) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1439 = arith.constant 1.5707963267948966 : f64
    %2368 = qlx.apply #qlx.action<pauli_rotation>(%2366#1, %cst_1439) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1440 = arith.constant 0.78539816339744828 : f64
    %2369:2 = qlx.apply #qlx.action<pauli_rotation>(%2367, %2368, %cst_1440) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2370 = qlx.apply #qlx.action<h>(%2359#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1441 = arith.constant 2.3561944901923448 : f64
    %2371 = qlx.apply #qlx.action<pauli_rotation>(%2370, %cst_1441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2372 = qlx.apply #qlx.action<h>(%2371) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2373 = qlx.apply #qlx.action<h>(%2349#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1442 = arith.constant 1.5707963267948966 : f64
    %2374 = qlx.apply #qlx.action<pauli_rotation>(%2373, %cst_1442) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2375 = qlx.apply #qlx.action<h>(%2374) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1443 = arith.constant 0.78539816339744828 : f64
    %2376:2 = qlx.apply #qlx.action<pauli_rotation>(%2372, %2375, %cst_1443) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1444 = arith.constant 1.5707963267948966 : f64
    %2377 = qlx.apply #qlx.action<pauli_rotation>(%2376#0, %cst_1444) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1445 = arith.constant 1.5707963267948966 : f64
    %2378 = qlx.apply #qlx.action<pauli_rotation>(%2376#1, %cst_1445) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1446 = arith.constant 0.78539816339744828 : f64
    %2379:2 = qlx.apply #qlx.action<pauli_rotation>(%2377, %2378, %cst_1446) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2380 = qlx.apply #qlx.action<h>(%2330#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1447 = arith.constant 2.3561944901923448 : f64
    %2381 = qlx.apply #qlx.action<pauli_rotation>(%2380, %cst_1447) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2382 = qlx.apply #qlx.action<h>(%2381) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2383 = qlx.apply #qlx.action<h>(%2369#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1448 = arith.constant 2.3561944901923448 : f64
    %2384 = qlx.apply #qlx.action<pauli_rotation>(%2383, %cst_1448) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2385 = qlx.apply #qlx.action<h>(%2384) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1449 = arith.constant 1.5707963267948966 : f64
    %2386:2 = qlx.apply #qlx.action<pauli_rotation>(%2382, %2385, %cst_1449) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1450 = arith.constant 1.5707963267948966 : f64
    %2387 = qlx.apply #qlx.action<pauli_rotation>(%2386#0, %cst_1450) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1451 = arith.constant 1.5707963267948966 : f64
    %2388 = qlx.apply #qlx.action<pauli_rotation>(%2386#1, %cst_1451) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1452 = arith.constant 1.5707963267948966 : f64
    %2389:2 = qlx.apply #qlx.action<pauli_rotation>(%2387, %2388, %cst_1452) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2390 = qlx.apply #qlx.action<h>(%2330#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1453 = arith.constant 2.3561944901923448 : f64
    %2391 = qlx.apply #qlx.action<pauli_rotation>(%2390, %cst_1453) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2392 = qlx.apply #qlx.action<h>(%2391) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2393 = qlx.apply #qlx.action<h>(%2389#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1454 = arith.constant 3.1415926535897931 : f64
    %2394 = qlx.apply #qlx.action<pauli_rotation>(%2393, %cst_1454) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2395 = qlx.apply #qlx.action<h>(%2394) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1455 = arith.constant 1.5707963267948966 : f64
    %2396:2 = qlx.apply #qlx.action<pauli_rotation>(%2392, %2395, %cst_1455) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1456 = arith.constant 1.5707963267948966 : f64
    %2397 = qlx.apply #qlx.action<pauli_rotation>(%2396#0, %cst_1456) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1457 = arith.constant 1.5707963267948966 : f64
    %2398 = qlx.apply #qlx.action<pauli_rotation>(%2396#1, %cst_1457) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1458 = arith.constant 1.5707963267948966 : f64
    %2399:2 = qlx.apply #qlx.action<pauli_rotation>(%2397, %2398, %cst_1458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2400 = qlx.apply #qlx.action<h>(%2389#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1459 = arith.constant 3.1415926535897931 : f64
    %2401 = qlx.apply #qlx.action<pauli_rotation>(%2400, %cst_1459) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2402 = qlx.apply #qlx.action<h>(%2401) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2403 = qlx.apply #qlx.action<h>(%2369#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1460 = arith.constant 2.3561944901923448 : f64
    %2404 = qlx.apply #qlx.action<pauli_rotation>(%2403, %cst_1460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2405 = qlx.apply #qlx.action<h>(%2404) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1461 = arith.constant 1.5707963267948966 : f64
    %2406:2 = qlx.apply #qlx.action<pauli_rotation>(%2402, %2405, %cst_1461) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1462 = arith.constant 1.5707963267948966 : f64
    %2407 = qlx.apply #qlx.action<pauli_rotation>(%2406#0, %cst_1462) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1463 = arith.constant 1.5707963267948966 : f64
    %2408 = qlx.apply #qlx.action<pauli_rotation>(%2406#1, %cst_1463) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1464 = arith.constant 1.5707963267948966 : f64
    %2409:2 = qlx.apply #qlx.action<pauli_rotation>(%2407, %2408, %cst_1464) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2410 = qlx.apply #qlx.action<h>(%2320#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1465 = arith.constant 2.3561944901923448 : f64
    %2411 = qlx.apply #qlx.action<pauli_rotation>(%2410, %cst_1465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2412 = qlx.apply #qlx.action<h>(%2411) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2413 = qlx.apply #qlx.action<h>(%2399#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1466 = arith.constant 3.1415926535897931 : f64
    %2414 = qlx.apply #qlx.action<pauli_rotation>(%2413, %cst_1466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2415 = qlx.apply #qlx.action<h>(%2414) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1467 = arith.constant 1.5707963267948966 : f64
    %2416:2 = qlx.apply #qlx.action<pauli_rotation>(%2412, %2415, %cst_1467) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1468 = arith.constant 1.5707963267948966 : f64
    %2417 = qlx.apply #qlx.action<pauli_rotation>(%2416#0, %cst_1468) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1469 = arith.constant 1.5707963267948966 : f64
    %2418 = qlx.apply #qlx.action<pauli_rotation>(%2416#1, %cst_1469) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1470 = arith.constant 1.5707963267948966 : f64
    %2419:2 = qlx.apply #qlx.action<pauli_rotation>(%2417, %2418, %cst_1470) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2420 = qlx.apply #qlx.action<h>(%2399#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1471 = arith.constant 3.1415926535897931 : f64
    %2421 = qlx.apply #qlx.action<pauli_rotation>(%2420, %cst_1471) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2422 = qlx.apply #qlx.action<h>(%2421) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2423 = qlx.apply #qlx.action<h>(%2409#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1472 = arith.constant 3.1415926535897931 : f64
    %2424 = qlx.apply #qlx.action<pauli_rotation>(%2423, %cst_1472) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2425 = qlx.apply #qlx.action<h>(%2424) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1473 = arith.constant 1.5707963267948966 : f64
    %2426:2 = qlx.apply #qlx.action<pauli_rotation>(%2422, %2425, %cst_1473) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1474 = arith.constant 1.5707963267948966 : f64
    %2427 = qlx.apply #qlx.action<pauli_rotation>(%2426#0, %cst_1474) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1475 = arith.constant 1.5707963267948966 : f64
    %2428 = qlx.apply #qlx.action<pauli_rotation>(%2426#1, %cst_1475) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1476 = arith.constant 1.5707963267948966 : f64
    %2429:2 = qlx.apply #qlx.action<pauli_rotation>(%2427, %2428, %cst_1476) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2430 = qlx.apply #qlx.action<h>(%2409#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1477 = arith.constant 3.1415926535897931 : f64
    %2431 = qlx.apply #qlx.action<pauli_rotation>(%2430, %cst_1477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2432 = qlx.apply #qlx.action<h>(%2431) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2433 = qlx.apply #qlx.action<h>(%2379#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1478 = arith.constant 2.3561944901923448 : f64
    %2434 = qlx.apply #qlx.action<pauli_rotation>(%2433, %cst_1478) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2435 = qlx.apply #qlx.action<h>(%2434) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1479 = arith.constant 1.5707963267948966 : f64
    %2436:2 = qlx.apply #qlx.action<pauli_rotation>(%2432, %2435, %cst_1479) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1480 = arith.constant 1.5707963267948966 : f64
    %2437 = qlx.apply #qlx.action<pauli_rotation>(%2436#0, %cst_1480) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1481 = arith.constant 1.5707963267948966 : f64
    %2438 = qlx.apply #qlx.action<pauli_rotation>(%2436#1, %cst_1481) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1482 = arith.constant 1.5707963267948966 : f64
    %2439:2 = qlx.apply #qlx.action<pauli_rotation>(%2437, %2438, %cst_1482) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2440 = qlx.apply #qlx.action<h>(%2320#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1483 = arith.constant 2.3561944901923448 : f64
    %2441 = qlx.apply #qlx.action<pauli_rotation>(%2440, %cst_1483) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2442 = qlx.apply #qlx.action<h>(%2419#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1484 = arith.constant 3.1415926535897931 : f64
    %2443 = qlx.apply #qlx.action<pauli_rotation>(%2442, %cst_1484) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1485 = arith.constant 1.250000e-01 : f64
    %2444:2 = qlx.apply #qlx.action<pauli_rotation>(%2441, %2443, %cst_1485) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2445 = qlx.apply #qlx.action<h>(%2419#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1486 = arith.constant 3.1415926535897931 : f64
    %2446 = qlx.apply #qlx.action<pauli_rotation>(%2445, %cst_1486) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2447 = qlx.apply #qlx.action<h>(%2429#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1487 = arith.constant 3.1415926535897931 : f64
    %2448 = qlx.apply #qlx.action<pauli_rotation>(%2447, %cst_1487) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1488 = arith.constant 1.250000e-01 : f64
    %2449:2 = qlx.apply #qlx.action<pauli_rotation>(%2446, %2448, %cst_1488) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2450 = qlx.apply #qlx.action<h>(%2429#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1489 = arith.constant 3.1415926535897931 : f64
    %2451 = qlx.apply #qlx.action<pauli_rotation>(%2450, %cst_1489) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2452 = qlx.apply #qlx.action<h>(%2439#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1490 = arith.constant 3.1415926535897931 : f64
    %2453 = qlx.apply #qlx.action<pauli_rotation>(%2452, %cst_1490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1491 = arith.constant 1.250000e-01 : f64
    %2454:2 = qlx.apply #qlx.action<pauli_rotation>(%2451, %2453, %cst_1491) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2455 = qlx.apply #qlx.action<h>(%2439#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1492 = arith.constant 3.1415926535897931 : f64
    %2456 = qlx.apply #qlx.action<pauli_rotation>(%2455, %cst_1492) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2457 = qlx.apply #qlx.action<h>(%2379#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1493 = arith.constant 2.3561944901923448 : f64
    %2458 = qlx.apply #qlx.action<pauli_rotation>(%2457, %cst_1493) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1494 = arith.constant 1.250000e-01 : f64
    %2459:2 = qlx.apply #qlx.action<pauli_rotation>(%2456, %2458, %cst_1494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2460 = qlx.apply #qlx.action<h>(%2444#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2461 = qlx.apply #qlx.action<h>(%2449#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1495 = arith.constant 1.5707963267948966 : f64
    %2462:2 = qlx.apply #qlx.action<pauli_rotation>(%2460, %2461, %cst_1495) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1496 = arith.constant 1.5707963267948966 : f64
    %2463 = qlx.apply #qlx.action<pauli_rotation>(%2462#0, %cst_1496) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1497 = arith.constant 1.5707963267948966 : f64
    %2464 = qlx.apply #qlx.action<pauli_rotation>(%2462#1, %cst_1497) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1498 = arith.constant 1.5707963267948966 : f64
    %2465:2 = qlx.apply #qlx.action<pauli_rotation>(%2463, %2464, %cst_1498) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2466 = qlx.apply #qlx.action<h>(%2449#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2467 = qlx.apply #qlx.action<h>(%2454#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1499 = arith.constant 1.5707963267948966 : f64
    %2468:2 = qlx.apply #qlx.action<pauli_rotation>(%2466, %2467, %cst_1499) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1500 = arith.constant 1.5707963267948966 : f64
    %2469 = qlx.apply #qlx.action<pauli_rotation>(%2468#0, %cst_1500) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1501 = arith.constant 1.5707963267948966 : f64
    %2470 = qlx.apply #qlx.action<pauli_rotation>(%2468#1, %cst_1501) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1502 = arith.constant 1.5707963267948966 : f64
    %2471:2 = qlx.apply #qlx.action<pauli_rotation>(%2469, %2470, %cst_1502) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2472 = qlx.apply #qlx.action<h>(%2454#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2473 = qlx.apply #qlx.action<h>(%2459#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1503 = arith.constant 1.5707963267948966 : f64
    %2474:2 = qlx.apply #qlx.action<pauli_rotation>(%2472, %2473, %cst_1503) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1504 = arith.constant 1.5707963267948966 : f64
    %2475 = qlx.apply #qlx.action<pauli_rotation>(%2474#0, %cst_1504) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1505 = arith.constant 1.5707963267948966 : f64
    %2476 = qlx.apply #qlx.action<pauli_rotation>(%2474#1, %cst_1505) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1506 = arith.constant 1.5707963267948966 : f64
    %2477:2 = qlx.apply #qlx.action<pauli_rotation>(%2475, %2476, %cst_1506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2478 = qlx.apply #qlx.action<h>(%2465#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1507 = arith.constant 3.1415926535897931 : f64
    %2479 = qlx.apply #qlx.action<pauli_rotation>(%2478, %cst_1507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2480 = qlx.apply #qlx.action<h>(%2479) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2481 = qlx.apply #qlx.action<h>(%2471#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1508 = arith.constant 3.1415926535897931 : f64
    %2482 = qlx.apply #qlx.action<pauli_rotation>(%2481, %cst_1508) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2483 = qlx.apply #qlx.action<h>(%2482) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1509 = arith.constant 1.5707963267948966 : f64
    %2484:2 = qlx.apply #qlx.action<pauli_rotation>(%2480, %2483, %cst_1509) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1510 = arith.constant 1.5707963267948966 : f64
    %2485 = qlx.apply #qlx.action<pauli_rotation>(%2484#0, %cst_1510) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1511 = arith.constant 1.5707963267948966 : f64
    %2486 = qlx.apply #qlx.action<pauli_rotation>(%2484#1, %cst_1511) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1512 = arith.constant 1.5707963267948966 : f64
    %2487:2 = qlx.apply #qlx.action<pauli_rotation>(%2485, %2486, %cst_1512) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2488 = qlx.apply #qlx.action<h>(%2471#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1513 = arith.constant 3.1415926535897931 : f64
    %2489 = qlx.apply #qlx.action<pauli_rotation>(%2488, %cst_1513) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2490 = qlx.apply #qlx.action<h>(%2489) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2491 = qlx.apply #qlx.action<h>(%2477#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1514 = arith.constant 3.1415926535897931 : f64
    %2492 = qlx.apply #qlx.action<pauli_rotation>(%2491, %cst_1514) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2493 = qlx.apply #qlx.action<h>(%2492) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1515 = arith.constant 1.5707963267948966 : f64
    %2494:2 = qlx.apply #qlx.action<pauli_rotation>(%2490, %2493, %cst_1515) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1516 = arith.constant 1.5707963267948966 : f64
    %2495 = qlx.apply #qlx.action<pauli_rotation>(%2494#0, %cst_1516) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1517 = arith.constant 1.5707963267948966 : f64
    %2496 = qlx.apply #qlx.action<pauli_rotation>(%2494#1, %cst_1517) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1518 = arith.constant 1.5707963267948966 : f64
    %2497:2 = qlx.apply #qlx.action<pauli_rotation>(%2495, %2496, %cst_1518) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2498 = qlx.apply #qlx.action<h>(%2487#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1519 = arith.constant 3.1415926535897931 : f64
    %2499 = qlx.apply #qlx.action<pauli_rotation>(%2498, %cst_1519) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2500 = qlx.apply #qlx.action<h>(%2499) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2501 = qlx.apply #qlx.action<h>(%2497#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1520 = arith.constant 3.1415926535897931 : f64
    %2502 = qlx.apply #qlx.action<pauli_rotation>(%2501, %cst_1520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2503 = qlx.apply #qlx.action<h>(%2502) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1521 = arith.constant 1.5707963267948966 : f64
    %2504:2 = qlx.apply #qlx.action<pauli_rotation>(%2500, %2503, %cst_1521) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1522 = arith.constant 1.5707963267948966 : f64
    %2505 = qlx.apply #qlx.action<pauli_rotation>(%2504#0, %cst_1522) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1523 = arith.constant 1.5707963267948966 : f64
    %2506 = qlx.apply #qlx.action<pauli_rotation>(%2504#1, %cst_1523) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1524 = arith.constant 1.5707963267948966 : f64
    %2507:2 = qlx.apply #qlx.action<pauli_rotation>(%2505, %2506, %cst_1524) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1525 = arith.constant 0.78539816339744828 : f64
    %2508 = qlx.apply #qlx.action<pauli_rotation>(%2444#0, %cst_1525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2509 = qlx.apply #qlx.action<h>(%2508) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2510 = qlx.apply #qlx.action<h>(%2465#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1526 = arith.constant 2.3561944901923448 : f64
    %2511 = qlx.apply #qlx.action<pauli_rotation>(%2510, %cst_1526) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2512 = qlx.apply #qlx.action<h>(%2511) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1527 = arith.constant 0.78539816339744828 : f64
    %2513:2 = qlx.apply #qlx.action<pauli_rotation>(%2509, %2512, %cst_1527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1528 = arith.constant 1.5707963267948966 : f64
    %2514 = qlx.apply #qlx.action<pauli_rotation>(%2513#0, %cst_1528) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1529 = arith.constant 1.5707963267948966 : f64
    %2515 = qlx.apply #qlx.action<pauli_rotation>(%2513#1, %cst_1529) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1530 = arith.constant 0.78539816339744828 : f64
    %2516:2 = qlx.apply #qlx.action<pauli_rotation>(%2514, %2515, %cst_1530) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2517 = qlx.apply #qlx.action<h>(%2487#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1531 = arith.constant 2.3561944901923448 : f64
    %2518 = qlx.apply #qlx.action<pauli_rotation>(%2517, %cst_1531) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2519 = qlx.apply #qlx.action<h>(%2518) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2520 = qlx.apply #qlx.action<h>(%2507#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1532 = arith.constant 2.3561944901923448 : f64
    %2521 = qlx.apply #qlx.action<pauli_rotation>(%2520, %cst_1532) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2522 = qlx.apply #qlx.action<h>(%2521) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1533 = arith.constant 0.78539816339744828 : f64
    %2523:2 = qlx.apply #qlx.action<pauli_rotation>(%2519, %2522, %cst_1533) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1534 = arith.constant 1.5707963267948966 : f64
    %2524 = qlx.apply #qlx.action<pauli_rotation>(%2523#0, %cst_1534) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1535 = arith.constant 1.5707963267948966 : f64
    %2525 = qlx.apply #qlx.action<pauli_rotation>(%2523#1, %cst_1535) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1536 = arith.constant 0.78539816339744828 : f64
    %2526:2 = qlx.apply #qlx.action<pauli_rotation>(%2524, %2525, %cst_1536) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2527 = qlx.apply #qlx.action<h>(%2516#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1537 = arith.constant 2.3561944901923448 : f64
    %2528 = qlx.apply #qlx.action<pauli_rotation>(%2527, %cst_1537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2529 = qlx.apply #qlx.action<h>(%2528) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2530 = qlx.apply #qlx.action<h>(%2526#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1538 = arith.constant 0.78539816339744828 : f64
    %2531 = qlx.apply #qlx.action<pauli_rotation>(%2530, %cst_1538) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2532 = qlx.apply #qlx.action<h>(%2531) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1539 = arith.constant 1.250000e-01 : f64
    %2533:2 = qlx.apply #qlx.action<pauli_rotation>(%2529, %2532, %cst_1539) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1540 = arith.constant 1.5707963267948966 : f64
    %2534 = qlx.apply #qlx.action<pauli_rotation>(%2533#0, %cst_1540) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1541 = arith.constant 1.5707963267948966 : f64
    %2535 = qlx.apply #qlx.action<pauli_rotation>(%2533#1, %cst_1541) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1542 = arith.constant 1.250000e-01 : f64
    %2536:2 = qlx.apply #qlx.action<pauli_rotation>(%2534, %2535, %cst_1542) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2537 = qlx.apply #qlx.action<h>(%2516#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1543 = arith.constant 1.5707963267948966 : f64
    %2538 = qlx.apply #qlx.action<pauli_rotation>(%2537, %cst_1543) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2539 = qlx.apply #qlx.action<h>(%2538) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2540 = qlx.apply #qlx.action<h>(%2536#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1544 = arith.constant 0.78539816339744828 : f64
    %2541 = qlx.apply #qlx.action<pauli_rotation>(%2540, %cst_1544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2542 = qlx.apply #qlx.action<h>(%2541) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1545 = arith.constant 0.78539816339744828 : f64
    %2543:2 = qlx.apply #qlx.action<pauli_rotation>(%2539, %2542, %cst_1545) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1546 = arith.constant 1.5707963267948966 : f64
    %2544 = qlx.apply #qlx.action<pauli_rotation>(%2543#0, %cst_1546) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1547 = arith.constant 1.5707963267948966 : f64
    %2545 = qlx.apply #qlx.action<pauli_rotation>(%2543#1, %cst_1547) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1548 = arith.constant 0.78539816339744828 : f64
    %2546:2 = qlx.apply #qlx.action<pauli_rotation>(%2544, %2545, %cst_1548) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2547 = qlx.apply #qlx.action<h>(%2536#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1549 = arith.constant 2.3561944901923448 : f64
    %2548 = qlx.apply #qlx.action<pauli_rotation>(%2547, %cst_1549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2549 = qlx.apply #qlx.action<h>(%2548) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2550 = qlx.apply #qlx.action<h>(%2526#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1550 = arith.constant 1.5707963267948966 : f64
    %2551 = qlx.apply #qlx.action<pauli_rotation>(%2550, %cst_1550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2552 = qlx.apply #qlx.action<h>(%2551) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1551 = arith.constant 0.78539816339744828 : f64
    %2553:2 = qlx.apply #qlx.action<pauli_rotation>(%2549, %2552, %cst_1551) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1552 = arith.constant 1.5707963267948966 : f64
    %2554 = qlx.apply #qlx.action<pauli_rotation>(%2553#0, %cst_1552) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1553 = arith.constant 1.5707963267948966 : f64
    %2555 = qlx.apply #qlx.action<pauli_rotation>(%2553#1, %cst_1553) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1554 = arith.constant 0.78539816339744828 : f64
    %2556:2 = qlx.apply #qlx.action<pauli_rotation>(%2554, %2555, %cst_1554) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2557 = qlx.apply #qlx.action<h>(%2507#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1555 = arith.constant 2.3561944901923448 : f64
    %2558 = qlx.apply #qlx.action<pauli_rotation>(%2557, %cst_1555) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2559 = qlx.apply #qlx.action<h>(%2558) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2560 = qlx.apply #qlx.action<h>(%2497#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1556 = arith.constant 2.3561944901923448 : f64
    %2561 = qlx.apply #qlx.action<pauli_rotation>(%2560, %cst_1556) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2562 = qlx.apply #qlx.action<h>(%2561) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1557 = arith.constant 0.78539816339744828 : f64
    %2563:2 = qlx.apply #qlx.action<pauli_rotation>(%2559, %2562, %cst_1557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1558 = arith.constant 1.5707963267948966 : f64
    %2564 = qlx.apply #qlx.action<pauli_rotation>(%2563#0, %cst_1558) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1559 = arith.constant 1.5707963267948966 : f64
    %2565 = qlx.apply #qlx.action<pauli_rotation>(%2563#1, %cst_1559) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1560 = arith.constant 0.78539816339744828 : f64
    %2566:2 = qlx.apply #qlx.action<pauli_rotation>(%2564, %2565, %cst_1560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2567 = qlx.apply #qlx.action<h>(%2477#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1561 = arith.constant 2.3561944901923448 : f64
    %2568 = qlx.apply #qlx.action<pauli_rotation>(%2567, %cst_1561) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2569 = qlx.apply #qlx.action<h>(%2568) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1562 = arith.constant 0.78539816339744828 : f64
    %2570 = qlx.apply #qlx.action<pauli_rotation>(%2459#1, %cst_1562) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2571 = qlx.apply #qlx.action<h>(%2570) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1563 = arith.constant 0.78539816339744828 : f64
    %2572:2 = qlx.apply #qlx.action<pauli_rotation>(%2569, %2571, %cst_1563) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1564 = arith.constant 1.5707963267948966 : f64
    %2573 = qlx.apply #qlx.action<pauli_rotation>(%2572#0, %cst_1564) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1565 = arith.constant 1.5707963267948966 : f64
    %2574 = qlx.apply #qlx.action<pauli_rotation>(%2572#1, %cst_1565) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1566 = arith.constant 0.78539816339744828 : f64
    %2575:2 = qlx.apply #qlx.action<pauli_rotation>(%2573, %2574, %cst_1566) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2576 = qlx.apply #qlx.action<h>(%2566#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1567 = arith.constant 2.3561944901923448 : f64
    %2577 = qlx.apply #qlx.action<pauli_rotation>(%2576, %cst_1567) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2578 = qlx.apply #qlx.action<h>(%2577) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2579 = qlx.apply #qlx.action<h>(%2575#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1568 = arith.constant 0.78539816339744828 : f64
    %2580 = qlx.apply #qlx.action<pauli_rotation>(%2579, %cst_1568) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2581 = qlx.apply #qlx.action<h>(%2580) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1569 = arith.constant 1.250000e-01 : f64
    %2582:2 = qlx.apply #qlx.action<pauli_rotation>(%2578, %2581, %cst_1569) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1570 = arith.constant 1.5707963267948966 : f64
    %2583 = qlx.apply #qlx.action<pauli_rotation>(%2582#0, %cst_1570) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1571 = arith.constant 1.5707963267948966 : f64
    %2584 = qlx.apply #qlx.action<pauli_rotation>(%2582#1, %cst_1571) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1572 = arith.constant 1.250000e-01 : f64
    %2585:2 = qlx.apply #qlx.action<pauli_rotation>(%2583, %2584, %cst_1572) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2586 = qlx.apply #qlx.action<h>(%2566#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1573 = arith.constant 1.5707963267948966 : f64
    %2587 = qlx.apply #qlx.action<pauli_rotation>(%2586, %cst_1573) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2588 = qlx.apply #qlx.action<h>(%2587) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2589 = qlx.apply #qlx.action<h>(%2585#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1574 = arith.constant 0.78539816339744828 : f64
    %2590 = qlx.apply #qlx.action<pauli_rotation>(%2589, %cst_1574) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2591 = qlx.apply #qlx.action<h>(%2590) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1575 = arith.constant 0.78539816339744828 : f64
    %2592:2 = qlx.apply #qlx.action<pauli_rotation>(%2588, %2591, %cst_1575) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1576 = arith.constant 1.5707963267948966 : f64
    %2593 = qlx.apply #qlx.action<pauli_rotation>(%2592#0, %cst_1576) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1577 = arith.constant 1.5707963267948966 : f64
    %2594 = qlx.apply #qlx.action<pauli_rotation>(%2592#1, %cst_1577) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1578 = arith.constant 0.78539816339744828 : f64
    %2595:2 = qlx.apply #qlx.action<pauli_rotation>(%2593, %2594, %cst_1578) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2596 = qlx.apply #qlx.action<h>(%2585#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1579 = arith.constant 2.3561944901923448 : f64
    %2597 = qlx.apply #qlx.action<pauli_rotation>(%2596, %cst_1579) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2598 = qlx.apply #qlx.action<h>(%2597) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2599 = qlx.apply #qlx.action<h>(%2575#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1580 = arith.constant 1.5707963267948966 : f64
    %2600 = qlx.apply #qlx.action<pauli_rotation>(%2599, %cst_1580) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2601 = qlx.apply #qlx.action<h>(%2600) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1581 = arith.constant 0.78539816339744828 : f64
    %2602:2 = qlx.apply #qlx.action<pauli_rotation>(%2598, %2601, %cst_1581) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1582 = arith.constant 1.5707963267948966 : f64
    %2603 = qlx.apply #qlx.action<pauli_rotation>(%2602#0, %cst_1582) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1583 = arith.constant 1.5707963267948966 : f64
    %2604 = qlx.apply #qlx.action<pauli_rotation>(%2602#1, %cst_1583) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1584 = arith.constant 0.78539816339744828 : f64
    %2605:2 = qlx.apply #qlx.action<pauli_rotation>(%2603, %2604, %cst_1584) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2606 = qlx.apply #qlx.action<h>(%2556#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1585 = arith.constant 2.3561944901923448 : f64
    %2607 = qlx.apply #qlx.action<pauli_rotation>(%2606, %cst_1585) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2608 = qlx.apply #qlx.action<h>(%2607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2609 = qlx.apply #qlx.action<h>(%2595#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1586 = arith.constant 2.3561944901923448 : f64
    %2610 = qlx.apply #qlx.action<pauli_rotation>(%2609, %cst_1586) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2611 = qlx.apply #qlx.action<h>(%2610) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1587 = arith.constant 1.5707963267948966 : f64
    %2612:2 = qlx.apply #qlx.action<pauli_rotation>(%2608, %2611, %cst_1587) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1588 = arith.constant 1.5707963267948966 : f64
    %2613 = qlx.apply #qlx.action<pauli_rotation>(%2612#0, %cst_1588) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1589 = arith.constant 1.5707963267948966 : f64
    %2614 = qlx.apply #qlx.action<pauli_rotation>(%2612#1, %cst_1589) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1590 = arith.constant 1.5707963267948966 : f64
    %2615:2 = qlx.apply #qlx.action<pauli_rotation>(%2613, %2614, %cst_1590) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2616 = qlx.apply #qlx.action<h>(%2556#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1591 = arith.constant 2.3561944901923448 : f64
    %2617 = qlx.apply #qlx.action<pauli_rotation>(%2616, %cst_1591) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2618 = qlx.apply #qlx.action<h>(%2617) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2619 = qlx.apply #qlx.action<h>(%2615#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1592 = arith.constant 3.1415926535897931 : f64
    %2620 = qlx.apply #qlx.action<pauli_rotation>(%2619, %cst_1592) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2621 = qlx.apply #qlx.action<h>(%2620) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1593 = arith.constant 1.5707963267948966 : f64
    %2622:2 = qlx.apply #qlx.action<pauli_rotation>(%2618, %2621, %cst_1593) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1594 = arith.constant 1.5707963267948966 : f64
    %2623 = qlx.apply #qlx.action<pauli_rotation>(%2622#0, %cst_1594) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1595 = arith.constant 1.5707963267948966 : f64
    %2624 = qlx.apply #qlx.action<pauli_rotation>(%2622#1, %cst_1595) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1596 = arith.constant 1.5707963267948966 : f64
    %2625:2 = qlx.apply #qlx.action<pauli_rotation>(%2623, %2624, %cst_1596) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2626 = qlx.apply #qlx.action<h>(%2615#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1597 = arith.constant 3.1415926535897931 : f64
    %2627 = qlx.apply #qlx.action<pauli_rotation>(%2626, %cst_1597) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2628 = qlx.apply #qlx.action<h>(%2627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2629 = qlx.apply #qlx.action<h>(%2595#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1598 = arith.constant 2.3561944901923448 : f64
    %2630 = qlx.apply #qlx.action<pauli_rotation>(%2629, %cst_1598) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2631 = qlx.apply #qlx.action<h>(%2630) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1599 = arith.constant 1.5707963267948966 : f64
    %2632:2 = qlx.apply #qlx.action<pauli_rotation>(%2628, %2631, %cst_1599) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1600 = arith.constant 1.5707963267948966 : f64
    %2633 = qlx.apply #qlx.action<pauli_rotation>(%2632#0, %cst_1600) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1601 = arith.constant 1.5707963267948966 : f64
    %2634 = qlx.apply #qlx.action<pauli_rotation>(%2632#1, %cst_1601) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1602 = arith.constant 1.5707963267948966 : f64
    %2635:2 = qlx.apply #qlx.action<pauli_rotation>(%2633, %2634, %cst_1602) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2636 = qlx.apply #qlx.action<h>(%2546#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1603 = arith.constant 2.3561944901923448 : f64
    %2637 = qlx.apply #qlx.action<pauli_rotation>(%2636, %cst_1603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2638 = qlx.apply #qlx.action<h>(%2637) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2639 = qlx.apply #qlx.action<h>(%2625#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1604 = arith.constant 3.1415926535897931 : f64
    %2640 = qlx.apply #qlx.action<pauli_rotation>(%2639, %cst_1604) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2641 = qlx.apply #qlx.action<h>(%2640) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1605 = arith.constant 1.5707963267948966 : f64
    %2642:2 = qlx.apply #qlx.action<pauli_rotation>(%2638, %2641, %cst_1605) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1606 = arith.constant 1.5707963267948966 : f64
    %2643 = qlx.apply #qlx.action<pauli_rotation>(%2642#0, %cst_1606) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1607 = arith.constant 1.5707963267948966 : f64
    %2644 = qlx.apply #qlx.action<pauli_rotation>(%2642#1, %cst_1607) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1608 = arith.constant 1.5707963267948966 : f64
    %2645:2 = qlx.apply #qlx.action<pauli_rotation>(%2643, %2644, %cst_1608) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2646 = qlx.apply #qlx.action<h>(%2625#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1609 = arith.constant 3.1415926535897931 : f64
    %2647 = qlx.apply #qlx.action<pauli_rotation>(%2646, %cst_1609) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2648 = qlx.apply #qlx.action<h>(%2647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2649 = qlx.apply #qlx.action<h>(%2635#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1610 = arith.constant 3.1415926535897931 : f64
    %2650 = qlx.apply #qlx.action<pauli_rotation>(%2649, %cst_1610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2651 = qlx.apply #qlx.action<h>(%2650) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1611 = arith.constant 1.5707963267948966 : f64
    %2652:2 = qlx.apply #qlx.action<pauli_rotation>(%2648, %2651, %cst_1611) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1612 = arith.constant 1.5707963267948966 : f64
    %2653 = qlx.apply #qlx.action<pauli_rotation>(%2652#0, %cst_1612) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1613 = arith.constant 1.5707963267948966 : f64
    %2654 = qlx.apply #qlx.action<pauli_rotation>(%2652#1, %cst_1613) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1614 = arith.constant 1.5707963267948966 : f64
    %2655:2 = qlx.apply #qlx.action<pauli_rotation>(%2653, %2654, %cst_1614) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2656 = qlx.apply #qlx.action<h>(%2635#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1615 = arith.constant 3.1415926535897931 : f64
    %2657 = qlx.apply #qlx.action<pauli_rotation>(%2656, %cst_1615) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2658 = qlx.apply #qlx.action<h>(%2657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2659 = qlx.apply #qlx.action<h>(%2605#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1616 = arith.constant 2.3561944901923448 : f64
    %2660 = qlx.apply #qlx.action<pauli_rotation>(%2659, %cst_1616) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2661 = qlx.apply #qlx.action<h>(%2660) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1617 = arith.constant 1.5707963267948966 : f64
    %2662:2 = qlx.apply #qlx.action<pauli_rotation>(%2658, %2661, %cst_1617) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1618 = arith.constant 1.5707963267948966 : f64
    %2663 = qlx.apply #qlx.action<pauli_rotation>(%2662#0, %cst_1618) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1619 = arith.constant 1.5707963267948966 : f64
    %2664 = qlx.apply #qlx.action<pauli_rotation>(%2662#1, %cst_1619) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1620 = arith.constant 1.5707963267948966 : f64
    %2665:2 = qlx.apply #qlx.action<pauli_rotation>(%2663, %2664, %cst_1620) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2666 = qlx.apply #qlx.action<h>(%2546#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1621 = arith.constant 2.3561944901923448 : f64
    %2667 = qlx.apply #qlx.action<pauli_rotation>(%2666, %cst_1621) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2668 = qlx.apply #qlx.action<h>(%2645#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1622 = arith.constant 3.1415926535897931 : f64
    %2669 = qlx.apply #qlx.action<pauli_rotation>(%2668, %cst_1622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1623 = arith.constant 1.250000e-01 : f64
    %2670:2 = qlx.apply #qlx.action<pauli_rotation>(%2667, %2669, %cst_1623) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2671 = qlx.apply #qlx.action<h>(%2645#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1624 = arith.constant 3.1415926535897931 : f64
    %2672 = qlx.apply #qlx.action<pauli_rotation>(%2671, %cst_1624) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2673 = qlx.apply #qlx.action<h>(%2655#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1625 = arith.constant 3.1415926535897931 : f64
    %2674 = qlx.apply #qlx.action<pauli_rotation>(%2673, %cst_1625) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1626 = arith.constant 1.250000e-01 : f64
    %2675:2 = qlx.apply #qlx.action<pauli_rotation>(%2672, %2674, %cst_1626) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2676 = qlx.apply #qlx.action<h>(%2655#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1627 = arith.constant 3.1415926535897931 : f64
    %2677 = qlx.apply #qlx.action<pauli_rotation>(%2676, %cst_1627) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2678 = qlx.apply #qlx.action<h>(%2665#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1628 = arith.constant 3.1415926535897931 : f64
    %2679 = qlx.apply #qlx.action<pauli_rotation>(%2678, %cst_1628) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1629 = arith.constant 1.250000e-01 : f64
    %2680:2 = qlx.apply #qlx.action<pauli_rotation>(%2677, %2679, %cst_1629) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2681 = qlx.apply #qlx.action<h>(%2665#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1630 = arith.constant 3.1415926535897931 : f64
    %2682 = qlx.apply #qlx.action<pauli_rotation>(%2681, %cst_1630) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2683 = qlx.apply #qlx.action<h>(%2605#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1631 = arith.constant 2.3561944901923448 : f64
    %2684 = qlx.apply #qlx.action<pauli_rotation>(%2683, %cst_1631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1632 = arith.constant 1.250000e-01 : f64
    %2685:2 = qlx.apply #qlx.action<pauli_rotation>(%2682, %2684, %cst_1632) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2686 = qlx.apply #qlx.action<h>(%2670#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2687 = qlx.apply #qlx.action<h>(%2675#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1633 = arith.constant 1.5707963267948966 : f64
    %2688:2 = qlx.apply #qlx.action<pauli_rotation>(%2686, %2687, %cst_1633) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1634 = arith.constant 1.5707963267948966 : f64
    %2689 = qlx.apply #qlx.action<pauli_rotation>(%2688#0, %cst_1634) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1635 = arith.constant 1.5707963267948966 : f64
    %2690 = qlx.apply #qlx.action<pauli_rotation>(%2688#1, %cst_1635) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1636 = arith.constant 1.5707963267948966 : f64
    %2691:2 = qlx.apply #qlx.action<pauli_rotation>(%2689, %2690, %cst_1636) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2692 = qlx.apply #qlx.action<h>(%2675#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2693 = qlx.apply #qlx.action<h>(%2680#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1637 = arith.constant 1.5707963267948966 : f64
    %2694:2 = qlx.apply #qlx.action<pauli_rotation>(%2692, %2693, %cst_1637) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1638 = arith.constant 1.5707963267948966 : f64
    %2695 = qlx.apply #qlx.action<pauli_rotation>(%2694#0, %cst_1638) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1639 = arith.constant 1.5707963267948966 : f64
    %2696 = qlx.apply #qlx.action<pauli_rotation>(%2694#1, %cst_1639) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1640 = arith.constant 1.5707963267948966 : f64
    %2697:2 = qlx.apply #qlx.action<pauli_rotation>(%2695, %2696, %cst_1640) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2698 = qlx.apply #qlx.action<h>(%2680#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2699 = qlx.apply #qlx.action<h>(%2685#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1641 = arith.constant 1.5707963267948966 : f64
    %2700:2 = qlx.apply #qlx.action<pauli_rotation>(%2698, %2699, %cst_1641) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1642 = arith.constant 1.5707963267948966 : f64
    %2701 = qlx.apply #qlx.action<pauli_rotation>(%2700#0, %cst_1642) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1643 = arith.constant 1.5707963267948966 : f64
    %2702 = qlx.apply #qlx.action<pauli_rotation>(%2700#1, %cst_1643) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1644 = arith.constant 1.5707963267948966 : f64
    %2703:2 = qlx.apply #qlx.action<pauli_rotation>(%2701, %2702, %cst_1644) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2704 = qlx.apply #qlx.action<h>(%2691#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1645 = arith.constant 3.1415926535897931 : f64
    %2705 = qlx.apply #qlx.action<pauli_rotation>(%2704, %cst_1645) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2706 = qlx.apply #qlx.action<h>(%2705) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2707 = qlx.apply #qlx.action<h>(%2697#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1646 = arith.constant 3.1415926535897931 : f64
    %2708 = qlx.apply #qlx.action<pauli_rotation>(%2707, %cst_1646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2709 = qlx.apply #qlx.action<h>(%2708) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1647 = arith.constant 1.5707963267948966 : f64
    %2710:2 = qlx.apply #qlx.action<pauli_rotation>(%2706, %2709, %cst_1647) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1648 = arith.constant 1.5707963267948966 : f64
    %2711 = qlx.apply #qlx.action<pauli_rotation>(%2710#0, %cst_1648) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1649 = arith.constant 1.5707963267948966 : f64
    %2712 = qlx.apply #qlx.action<pauli_rotation>(%2710#1, %cst_1649) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1650 = arith.constant 1.5707963267948966 : f64
    %2713:2 = qlx.apply #qlx.action<pauli_rotation>(%2711, %2712, %cst_1650) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2714 = qlx.apply #qlx.action<h>(%2697#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1651 = arith.constant 3.1415926535897931 : f64
    %2715 = qlx.apply #qlx.action<pauli_rotation>(%2714, %cst_1651) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2716 = qlx.apply #qlx.action<h>(%2715) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2717 = qlx.apply #qlx.action<h>(%2703#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1652 = arith.constant 3.1415926535897931 : f64
    %2718 = qlx.apply #qlx.action<pauli_rotation>(%2717, %cst_1652) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2719 = qlx.apply #qlx.action<h>(%2718) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1653 = arith.constant 1.5707963267948966 : f64
    %2720:2 = qlx.apply #qlx.action<pauli_rotation>(%2716, %2719, %cst_1653) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1654 = arith.constant 1.5707963267948966 : f64
    %2721 = qlx.apply #qlx.action<pauli_rotation>(%2720#0, %cst_1654) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1655 = arith.constant 1.5707963267948966 : f64
    %2722 = qlx.apply #qlx.action<pauli_rotation>(%2720#1, %cst_1655) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1656 = arith.constant 1.5707963267948966 : f64
    %2723:2 = qlx.apply #qlx.action<pauli_rotation>(%2721, %2722, %cst_1656) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2724 = qlx.apply #qlx.action<h>(%2713#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1657 = arith.constant 3.1415926535897931 : f64
    %2725 = qlx.apply #qlx.action<pauli_rotation>(%2724, %cst_1657) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2726 = qlx.apply #qlx.action<h>(%2725) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2727 = qlx.apply #qlx.action<h>(%2723#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1658 = arith.constant 3.1415926535897931 : f64
    %2728 = qlx.apply #qlx.action<pauli_rotation>(%2727, %cst_1658) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2729 = qlx.apply #qlx.action<h>(%2728) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1659 = arith.constant 1.5707963267948966 : f64
    %2730:2 = qlx.apply #qlx.action<pauli_rotation>(%2726, %2729, %cst_1659) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1660 = arith.constant 1.5707963267948966 : f64
    %2731 = qlx.apply #qlx.action<pauli_rotation>(%2730#0, %cst_1660) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1661 = arith.constant 1.5707963267948966 : f64
    %2732 = qlx.apply #qlx.action<pauli_rotation>(%2730#1, %cst_1661) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1662 = arith.constant 1.5707963267948966 : f64
    %2733:2 = qlx.apply #qlx.action<pauli_rotation>(%2731, %2732, %cst_1662) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1663 = arith.constant 0.78539816339744828 : f64
    %2734 = qlx.apply #qlx.action<pauli_rotation>(%2670#0, %cst_1663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2735 = qlx.apply #qlx.action<h>(%2734) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2736 = qlx.apply #qlx.action<h>(%2691#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1664 = arith.constant 2.3561944901923448 : f64
    %2737 = qlx.apply #qlx.action<pauli_rotation>(%2736, %cst_1664) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2738 = qlx.apply #qlx.action<h>(%2737) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1665 = arith.constant 0.78539816339744828 : f64
    %2739:2 = qlx.apply #qlx.action<pauli_rotation>(%2735, %2738, %cst_1665) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1666 = arith.constant 1.5707963267948966 : f64
    %2740 = qlx.apply #qlx.action<pauli_rotation>(%2739#0, %cst_1666) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1667 = arith.constant 1.5707963267948966 : f64
    %2741 = qlx.apply #qlx.action<pauli_rotation>(%2739#1, %cst_1667) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1668 = arith.constant 0.78539816339744828 : f64
    %2742:2 = qlx.apply #qlx.action<pauli_rotation>(%2740, %2741, %cst_1668) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2743 = qlx.apply #qlx.action<h>(%2713#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1669 = arith.constant 2.3561944901923448 : f64
    %2744 = qlx.apply #qlx.action<pauli_rotation>(%2743, %cst_1669) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2745 = qlx.apply #qlx.action<h>(%2744) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2746 = qlx.apply #qlx.action<h>(%2733#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1670 = arith.constant 2.3561944901923448 : f64
    %2747 = qlx.apply #qlx.action<pauli_rotation>(%2746, %cst_1670) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2748 = qlx.apply #qlx.action<h>(%2747) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1671 = arith.constant 0.78539816339744828 : f64
    %2749:2 = qlx.apply #qlx.action<pauli_rotation>(%2745, %2748, %cst_1671) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1672 = arith.constant 1.5707963267948966 : f64
    %2750 = qlx.apply #qlx.action<pauli_rotation>(%2749#0, %cst_1672) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1673 = arith.constant 1.5707963267948966 : f64
    %2751 = qlx.apply #qlx.action<pauli_rotation>(%2749#1, %cst_1673) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1674 = arith.constant 0.78539816339744828 : f64
    %2752:2 = qlx.apply #qlx.action<pauli_rotation>(%2750, %2751, %cst_1674) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2753 = qlx.apply #qlx.action<h>(%2742#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1675 = arith.constant 2.3561944901923448 : f64
    %2754 = qlx.apply #qlx.action<pauli_rotation>(%2753, %cst_1675) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2755 = qlx.apply #qlx.action<h>(%2754) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2756 = qlx.apply #qlx.action<h>(%2752#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1676 = arith.constant 0.78539816339744828 : f64
    %2757 = qlx.apply #qlx.action<pauli_rotation>(%2756, %cst_1676) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2758 = qlx.apply #qlx.action<h>(%2757) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1677 = arith.constant 1.250000e-01 : f64
    %2759:2 = qlx.apply #qlx.action<pauli_rotation>(%2755, %2758, %cst_1677) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1678 = arith.constant 1.5707963267948966 : f64
    %2760 = qlx.apply #qlx.action<pauli_rotation>(%2759#0, %cst_1678) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1679 = arith.constant 1.5707963267948966 : f64
    %2761 = qlx.apply #qlx.action<pauli_rotation>(%2759#1, %cst_1679) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1680 = arith.constant 1.250000e-01 : f64
    %2762:2 = qlx.apply #qlx.action<pauli_rotation>(%2760, %2761, %cst_1680) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2763 = qlx.apply #qlx.action<h>(%2742#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1681 = arith.constant 1.5707963267948966 : f64
    %2764 = qlx.apply #qlx.action<pauli_rotation>(%2763, %cst_1681) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2765 = qlx.apply #qlx.action<h>(%2764) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2766 = qlx.apply #qlx.action<h>(%2762#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1682 = arith.constant 0.78539816339744828 : f64
    %2767 = qlx.apply #qlx.action<pauli_rotation>(%2766, %cst_1682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2768 = qlx.apply #qlx.action<h>(%2767) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1683 = arith.constant 0.78539816339744828 : f64
    %2769:2 = qlx.apply #qlx.action<pauli_rotation>(%2765, %2768, %cst_1683) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1684 = arith.constant 1.5707963267948966 : f64
    %2770 = qlx.apply #qlx.action<pauli_rotation>(%2769#0, %cst_1684) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1685 = arith.constant 1.5707963267948966 : f64
    %2771 = qlx.apply #qlx.action<pauli_rotation>(%2769#1, %cst_1685) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1686 = arith.constant 0.78539816339744828 : f64
    %2772:2 = qlx.apply #qlx.action<pauli_rotation>(%2770, %2771, %cst_1686) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2773 = qlx.apply #qlx.action<h>(%2762#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1687 = arith.constant 2.3561944901923448 : f64
    %2774 = qlx.apply #qlx.action<pauli_rotation>(%2773, %cst_1687) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2775 = qlx.apply #qlx.action<h>(%2774) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2776 = qlx.apply #qlx.action<h>(%2752#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1688 = arith.constant 1.5707963267948966 : f64
    %2777 = qlx.apply #qlx.action<pauli_rotation>(%2776, %cst_1688) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2778 = qlx.apply #qlx.action<h>(%2777) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1689 = arith.constant 0.78539816339744828 : f64
    %2779:2 = qlx.apply #qlx.action<pauli_rotation>(%2775, %2778, %cst_1689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1690 = arith.constant 1.5707963267948966 : f64
    %2780 = qlx.apply #qlx.action<pauli_rotation>(%2779#0, %cst_1690) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1691 = arith.constant 1.5707963267948966 : f64
    %2781 = qlx.apply #qlx.action<pauli_rotation>(%2779#1, %cst_1691) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1692 = arith.constant 0.78539816339744828 : f64
    %2782:2 = qlx.apply #qlx.action<pauli_rotation>(%2780, %2781, %cst_1692) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2783 = qlx.apply #qlx.action<h>(%2733#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1693 = arith.constant 2.3561944901923448 : f64
    %2784 = qlx.apply #qlx.action<pauli_rotation>(%2783, %cst_1693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2785 = qlx.apply #qlx.action<h>(%2784) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2786 = qlx.apply #qlx.action<h>(%2723#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1694 = arith.constant 2.3561944901923448 : f64
    %2787 = qlx.apply #qlx.action<pauli_rotation>(%2786, %cst_1694) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2788 = qlx.apply #qlx.action<h>(%2787) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1695 = arith.constant 0.78539816339744828 : f64
    %2789:2 = qlx.apply #qlx.action<pauli_rotation>(%2785, %2788, %cst_1695) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1696 = arith.constant 1.5707963267948966 : f64
    %2790 = qlx.apply #qlx.action<pauli_rotation>(%2789#0, %cst_1696) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1697 = arith.constant 1.5707963267948966 : f64
    %2791 = qlx.apply #qlx.action<pauli_rotation>(%2789#1, %cst_1697) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1698 = arith.constant 0.78539816339744828 : f64
    %2792:2 = qlx.apply #qlx.action<pauli_rotation>(%2790, %2791, %cst_1698) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2793 = qlx.apply #qlx.action<h>(%2703#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1699 = arith.constant 2.3561944901923448 : f64
    %2794 = qlx.apply #qlx.action<pauli_rotation>(%2793, %cst_1699) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2795 = qlx.apply #qlx.action<h>(%2794) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1700 = arith.constant 0.78539816339744828 : f64
    %2796 = qlx.apply #qlx.action<pauli_rotation>(%2685#1, %cst_1700) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2797 = qlx.apply #qlx.action<h>(%2796) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1701 = arith.constant 0.78539816339744828 : f64
    %2798:2 = qlx.apply #qlx.action<pauli_rotation>(%2795, %2797, %cst_1701) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1702 = arith.constant 1.5707963267948966 : f64
    %2799 = qlx.apply #qlx.action<pauli_rotation>(%2798#0, %cst_1702) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1703 = arith.constant 1.5707963267948966 : f64
    %2800 = qlx.apply #qlx.action<pauli_rotation>(%2798#1, %cst_1703) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1704 = arith.constant 0.78539816339744828 : f64
    %2801:2 = qlx.apply #qlx.action<pauli_rotation>(%2799, %2800, %cst_1704) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2802 = qlx.apply #qlx.action<h>(%2792#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1705 = arith.constant 2.3561944901923448 : f64
    %2803 = qlx.apply #qlx.action<pauli_rotation>(%2802, %cst_1705) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2804 = qlx.apply #qlx.action<h>(%2803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2805 = qlx.apply #qlx.action<h>(%2801#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1706 = arith.constant 0.78539816339744828 : f64
    %2806 = qlx.apply #qlx.action<pauli_rotation>(%2805, %cst_1706) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2807 = qlx.apply #qlx.action<h>(%2806) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1707 = arith.constant 1.250000e-01 : f64
    %2808:2 = qlx.apply #qlx.action<pauli_rotation>(%2804, %2807, %cst_1707) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1708 = arith.constant 1.5707963267948966 : f64
    %2809 = qlx.apply #qlx.action<pauli_rotation>(%2808#0, %cst_1708) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1709 = arith.constant 1.5707963267948966 : f64
    %2810 = qlx.apply #qlx.action<pauli_rotation>(%2808#1, %cst_1709) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1710 = arith.constant 1.250000e-01 : f64
    %2811:2 = qlx.apply #qlx.action<pauli_rotation>(%2809, %2810, %cst_1710) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2812 = qlx.apply #qlx.action<h>(%2792#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1711 = arith.constant 1.5707963267948966 : f64
    %2813 = qlx.apply #qlx.action<pauli_rotation>(%2812, %cst_1711) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2814 = qlx.apply #qlx.action<h>(%2813) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2815 = qlx.apply #qlx.action<h>(%2811#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1712 = arith.constant 0.78539816339744828 : f64
    %2816 = qlx.apply #qlx.action<pauli_rotation>(%2815, %cst_1712) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2817 = qlx.apply #qlx.action<h>(%2816) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1713 = arith.constant 0.78539816339744828 : f64
    %2818:2 = qlx.apply #qlx.action<pauli_rotation>(%2814, %2817, %cst_1713) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1714 = arith.constant 1.5707963267948966 : f64
    %2819 = qlx.apply #qlx.action<pauli_rotation>(%2818#0, %cst_1714) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1715 = arith.constant 1.5707963267948966 : f64
    %2820 = qlx.apply #qlx.action<pauli_rotation>(%2818#1, %cst_1715) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1716 = arith.constant 0.78539816339744828 : f64
    %2821:2 = qlx.apply #qlx.action<pauli_rotation>(%2819, %2820, %cst_1716) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2822 = qlx.apply #qlx.action<h>(%2811#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1717 = arith.constant 2.3561944901923448 : f64
    %2823 = qlx.apply #qlx.action<pauli_rotation>(%2822, %cst_1717) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2824 = qlx.apply #qlx.action<h>(%2823) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2825 = qlx.apply #qlx.action<h>(%2801#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1718 = arith.constant 1.5707963267948966 : f64
    %2826 = qlx.apply #qlx.action<pauli_rotation>(%2825, %cst_1718) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2827 = qlx.apply #qlx.action<h>(%2826) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1719 = arith.constant 0.78539816339744828 : f64
    %2828:2 = qlx.apply #qlx.action<pauli_rotation>(%2824, %2827, %cst_1719) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1720 = arith.constant 1.5707963267948966 : f64
    %2829 = qlx.apply #qlx.action<pauli_rotation>(%2828#0, %cst_1720) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1721 = arith.constant 1.5707963267948966 : f64
    %2830 = qlx.apply #qlx.action<pauli_rotation>(%2828#1, %cst_1721) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1722 = arith.constant 0.78539816339744828 : f64
    %2831:2 = qlx.apply #qlx.action<pauli_rotation>(%2829, %2830, %cst_1722) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2832 = qlx.apply #qlx.action<h>(%2782#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1723 = arith.constant 2.3561944901923448 : f64
    %2833 = qlx.apply #qlx.action<pauli_rotation>(%2832, %cst_1723) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2834 = qlx.apply #qlx.action<h>(%2833) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2835 = qlx.apply #qlx.action<h>(%2821#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1724 = arith.constant 2.3561944901923448 : f64
    %2836 = qlx.apply #qlx.action<pauli_rotation>(%2835, %cst_1724) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2837 = qlx.apply #qlx.action<h>(%2836) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1725 = arith.constant 1.5707963267948966 : f64
    %2838:2 = qlx.apply #qlx.action<pauli_rotation>(%2834, %2837, %cst_1725) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1726 = arith.constant 1.5707963267948966 : f64
    %2839 = qlx.apply #qlx.action<pauli_rotation>(%2838#0, %cst_1726) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1727 = arith.constant 1.5707963267948966 : f64
    %2840 = qlx.apply #qlx.action<pauli_rotation>(%2838#1, %cst_1727) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1728 = arith.constant 1.5707963267948966 : f64
    %2841:2 = qlx.apply #qlx.action<pauli_rotation>(%2839, %2840, %cst_1728) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2842 = qlx.apply #qlx.action<h>(%2782#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1729 = arith.constant 2.3561944901923448 : f64
    %2843 = qlx.apply #qlx.action<pauli_rotation>(%2842, %cst_1729) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2844 = qlx.apply #qlx.action<h>(%2843) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2845 = qlx.apply #qlx.action<h>(%2841#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1730 = arith.constant 3.1415926535897931 : f64
    %2846 = qlx.apply #qlx.action<pauli_rotation>(%2845, %cst_1730) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2847 = qlx.apply #qlx.action<h>(%2846) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1731 = arith.constant 1.5707963267948966 : f64
    %2848:2 = qlx.apply #qlx.action<pauli_rotation>(%2844, %2847, %cst_1731) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1732 = arith.constant 1.5707963267948966 : f64
    %2849 = qlx.apply #qlx.action<pauli_rotation>(%2848#0, %cst_1732) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1733 = arith.constant 1.5707963267948966 : f64
    %2850 = qlx.apply #qlx.action<pauli_rotation>(%2848#1, %cst_1733) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1734 = arith.constant 1.5707963267948966 : f64
    %2851:2 = qlx.apply #qlx.action<pauli_rotation>(%2849, %2850, %cst_1734) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2852 = qlx.apply #qlx.action<h>(%2841#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1735 = arith.constant 3.1415926535897931 : f64
    %2853 = qlx.apply #qlx.action<pauli_rotation>(%2852, %cst_1735) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2854 = qlx.apply #qlx.action<h>(%2853) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2855 = qlx.apply #qlx.action<h>(%2821#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1736 = arith.constant 2.3561944901923448 : f64
    %2856 = qlx.apply #qlx.action<pauli_rotation>(%2855, %cst_1736) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2857 = qlx.apply #qlx.action<h>(%2856) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1737 = arith.constant 1.5707963267948966 : f64
    %2858:2 = qlx.apply #qlx.action<pauli_rotation>(%2854, %2857, %cst_1737) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1738 = arith.constant 1.5707963267948966 : f64
    %2859 = qlx.apply #qlx.action<pauli_rotation>(%2858#0, %cst_1738) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1739 = arith.constant 1.5707963267948966 : f64
    %2860 = qlx.apply #qlx.action<pauli_rotation>(%2858#1, %cst_1739) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1740 = arith.constant 1.5707963267948966 : f64
    %2861:2 = qlx.apply #qlx.action<pauli_rotation>(%2859, %2860, %cst_1740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2862 = qlx.apply #qlx.action<h>(%2772#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1741 = arith.constant 2.3561944901923448 : f64
    %2863 = qlx.apply #qlx.action<pauli_rotation>(%2862, %cst_1741) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2864 = qlx.apply #qlx.action<h>(%2863) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2865 = qlx.apply #qlx.action<h>(%2851#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1742 = arith.constant 3.1415926535897931 : f64
    %2866 = qlx.apply #qlx.action<pauli_rotation>(%2865, %cst_1742) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2867 = qlx.apply #qlx.action<h>(%2866) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1743 = arith.constant 1.5707963267948966 : f64
    %2868:2 = qlx.apply #qlx.action<pauli_rotation>(%2864, %2867, %cst_1743) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1744 = arith.constant 1.5707963267948966 : f64
    %2869 = qlx.apply #qlx.action<pauli_rotation>(%2868#0, %cst_1744) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1745 = arith.constant 1.5707963267948966 : f64
    %2870 = qlx.apply #qlx.action<pauli_rotation>(%2868#1, %cst_1745) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1746 = arith.constant 1.5707963267948966 : f64
    %2871:2 = qlx.apply #qlx.action<pauli_rotation>(%2869, %2870, %cst_1746) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2872 = qlx.apply #qlx.action<h>(%2851#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1747 = arith.constant 3.1415926535897931 : f64
    %2873 = qlx.apply #qlx.action<pauli_rotation>(%2872, %cst_1747) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2874 = qlx.apply #qlx.action<h>(%2873) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2875 = qlx.apply #qlx.action<h>(%2861#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1748 = arith.constant 3.1415926535897931 : f64
    %2876 = qlx.apply #qlx.action<pauli_rotation>(%2875, %cst_1748) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2877 = qlx.apply #qlx.action<h>(%2876) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1749 = arith.constant 1.5707963267948966 : f64
    %2878:2 = qlx.apply #qlx.action<pauli_rotation>(%2874, %2877, %cst_1749) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1750 = arith.constant 1.5707963267948966 : f64
    %2879 = qlx.apply #qlx.action<pauli_rotation>(%2878#0, %cst_1750) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1751 = arith.constant 1.5707963267948966 : f64
    %2880 = qlx.apply #qlx.action<pauli_rotation>(%2878#1, %cst_1751) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1752 = arith.constant 1.5707963267948966 : f64
    %2881:2 = qlx.apply #qlx.action<pauli_rotation>(%2879, %2880, %cst_1752) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2882 = qlx.apply #qlx.action<h>(%2861#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1753 = arith.constant 3.1415926535897931 : f64
    %2883 = qlx.apply #qlx.action<pauli_rotation>(%2882, %cst_1753) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2884 = qlx.apply #qlx.action<h>(%2883) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2885 = qlx.apply #qlx.action<h>(%2831#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1754 = arith.constant 2.3561944901923448 : f64
    %2886 = qlx.apply #qlx.action<pauli_rotation>(%2885, %cst_1754) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2887 = qlx.apply #qlx.action<h>(%2886) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1755 = arith.constant 1.5707963267948966 : f64
    %2888:2 = qlx.apply #qlx.action<pauli_rotation>(%2884, %2887, %cst_1755) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1756 = arith.constant 1.5707963267948966 : f64
    %2889 = qlx.apply #qlx.action<pauli_rotation>(%2888#0, %cst_1756) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1757 = arith.constant 1.5707963267948966 : f64
    %2890 = qlx.apply #qlx.action<pauli_rotation>(%2888#1, %cst_1757) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1758 = arith.constant 1.5707963267948966 : f64
    %2891:2 = qlx.apply #qlx.action<pauli_rotation>(%2889, %2890, %cst_1758) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2892 = qlx.apply #qlx.action<h>(%2772#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1759 = arith.constant 2.3561944901923448 : f64
    %2893 = qlx.apply #qlx.action<pauli_rotation>(%2892, %cst_1759) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2894 = qlx.apply #qlx.action<h>(%2871#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1760 = arith.constant 3.1415926535897931 : f64
    %2895 = qlx.apply #qlx.action<pauli_rotation>(%2894, %cst_1760) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1761 = arith.constant 1.250000e-01 : f64
    %2896:2 = qlx.apply #qlx.action<pauli_rotation>(%2893, %2895, %cst_1761) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2897 = qlx.apply #qlx.action<h>(%2871#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1762 = arith.constant 3.1415926535897931 : f64
    %2898 = qlx.apply #qlx.action<pauli_rotation>(%2897, %cst_1762) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2899 = qlx.apply #qlx.action<h>(%2881#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1763 = arith.constant 3.1415926535897931 : f64
    %2900 = qlx.apply #qlx.action<pauli_rotation>(%2899, %cst_1763) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1764 = arith.constant 1.250000e-01 : f64
    %2901:2 = qlx.apply #qlx.action<pauli_rotation>(%2898, %2900, %cst_1764) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2902 = qlx.apply #qlx.action<h>(%2881#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1765 = arith.constant 3.1415926535897931 : f64
    %2903 = qlx.apply #qlx.action<pauli_rotation>(%2902, %cst_1765) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2904 = qlx.apply #qlx.action<h>(%2891#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1766 = arith.constant 3.1415926535897931 : f64
    %2905 = qlx.apply #qlx.action<pauli_rotation>(%2904, %cst_1766) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1767 = arith.constant 1.250000e-01 : f64
    %2906:2 = qlx.apply #qlx.action<pauli_rotation>(%2903, %2905, %cst_1767) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2907 = qlx.apply #qlx.action<h>(%2891#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1768 = arith.constant 3.1415926535897931 : f64
    %2908 = qlx.apply #qlx.action<pauli_rotation>(%2907, %cst_1768) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2909 = qlx.apply #qlx.action<h>(%2831#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1769 = arith.constant 2.3561944901923448 : f64
    %2910 = qlx.apply #qlx.action<pauli_rotation>(%2909, %cst_1769) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1770 = arith.constant 1.250000e-01 : f64
    %2911:2 = qlx.apply #qlx.action<pauli_rotation>(%2908, %2910, %cst_1770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2912 = qlx.apply #qlx.action<h>(%2896#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2913 = qlx.apply #qlx.action<h>(%2901#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1771 = arith.constant 1.5707963267948966 : f64
    %2914:2 = qlx.apply #qlx.action<pauli_rotation>(%2912, %2913, %cst_1771) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1772 = arith.constant 1.5707963267948966 : f64
    %2915 = qlx.apply #qlx.action<pauli_rotation>(%2914#0, %cst_1772) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1773 = arith.constant 1.5707963267948966 : f64
    %2916 = qlx.apply #qlx.action<pauli_rotation>(%2914#1, %cst_1773) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1774 = arith.constant 1.5707963267948966 : f64
    %2917:2 = qlx.apply #qlx.action<pauli_rotation>(%2915, %2916, %cst_1774) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2918 = qlx.apply #qlx.action<h>(%2901#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2919 = qlx.apply #qlx.action<h>(%2906#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1775 = arith.constant 1.5707963267948966 : f64
    %2920:2 = qlx.apply #qlx.action<pauli_rotation>(%2918, %2919, %cst_1775) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1776 = arith.constant 1.5707963267948966 : f64
    %2921 = qlx.apply #qlx.action<pauli_rotation>(%2920#0, %cst_1776) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1777 = arith.constant 1.5707963267948966 : f64
    %2922 = qlx.apply #qlx.action<pauli_rotation>(%2920#1, %cst_1777) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1778 = arith.constant 1.5707963267948966 : f64
    %2923:2 = qlx.apply #qlx.action<pauli_rotation>(%2921, %2922, %cst_1778) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2924 = qlx.apply #qlx.action<h>(%2906#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2925 = qlx.apply #qlx.action<h>(%2911#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1779 = arith.constant 1.5707963267948966 : f64
    %2926:2 = qlx.apply #qlx.action<pauli_rotation>(%2924, %2925, %cst_1779) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1780 = arith.constant 1.5707963267948966 : f64
    %2927 = qlx.apply #qlx.action<pauli_rotation>(%2926#0, %cst_1780) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1781 = arith.constant 1.5707963267948966 : f64
    %2928 = qlx.apply #qlx.action<pauli_rotation>(%2926#1, %cst_1781) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1782 = arith.constant 1.5707963267948966 : f64
    %2929:2 = qlx.apply #qlx.action<pauli_rotation>(%2927, %2928, %cst_1782) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2930 = qlx.apply #qlx.action<h>(%2917#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1783 = arith.constant 3.1415926535897931 : f64
    %2931 = qlx.apply #qlx.action<pauli_rotation>(%2930, %cst_1783) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2932 = qlx.apply #qlx.action<h>(%2931) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2933 = qlx.apply #qlx.action<h>(%2923#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1784 = arith.constant 3.1415926535897931 : f64
    %2934 = qlx.apply #qlx.action<pauli_rotation>(%2933, %cst_1784) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2935 = qlx.apply #qlx.action<h>(%2934) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1785 = arith.constant 1.5707963267948966 : f64
    %2936:2 = qlx.apply #qlx.action<pauli_rotation>(%2932, %2935, %cst_1785) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1786 = arith.constant 1.5707963267948966 : f64
    %2937 = qlx.apply #qlx.action<pauli_rotation>(%2936#0, %cst_1786) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1787 = arith.constant 1.5707963267948966 : f64
    %2938 = qlx.apply #qlx.action<pauli_rotation>(%2936#1, %cst_1787) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1788 = arith.constant 1.5707963267948966 : f64
    %2939:2 = qlx.apply #qlx.action<pauli_rotation>(%2937, %2938, %cst_1788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2940 = qlx.apply #qlx.action<h>(%2923#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1789 = arith.constant 3.1415926535897931 : f64
    %2941 = qlx.apply #qlx.action<pauli_rotation>(%2940, %cst_1789) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2942 = qlx.apply #qlx.action<h>(%2941) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2943 = qlx.apply #qlx.action<h>(%2929#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1790 = arith.constant 3.1415926535897931 : f64
    %2944 = qlx.apply #qlx.action<pauli_rotation>(%2943, %cst_1790) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2945 = qlx.apply #qlx.action<h>(%2944) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1791 = arith.constant 1.5707963267948966 : f64
    %2946:2 = qlx.apply #qlx.action<pauli_rotation>(%2942, %2945, %cst_1791) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1792 = arith.constant 1.5707963267948966 : f64
    %2947 = qlx.apply #qlx.action<pauli_rotation>(%2946#0, %cst_1792) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1793 = arith.constant 1.5707963267948966 : f64
    %2948 = qlx.apply #qlx.action<pauli_rotation>(%2946#1, %cst_1793) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1794 = arith.constant 1.5707963267948966 : f64
    %2949:2 = qlx.apply #qlx.action<pauli_rotation>(%2947, %2948, %cst_1794) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2950 = qlx.apply #qlx.action<h>(%2939#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1795 = arith.constant 3.1415926535897931 : f64
    %2951 = qlx.apply #qlx.action<pauli_rotation>(%2950, %cst_1795) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2952 = qlx.apply #qlx.action<h>(%2951) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2953 = qlx.apply #qlx.action<h>(%2949#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1796 = arith.constant 3.1415926535897931 : f64
    %2954 = qlx.apply #qlx.action<pauli_rotation>(%2953, %cst_1796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2955 = qlx.apply #qlx.action<h>(%2954) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1797 = arith.constant 1.5707963267948966 : f64
    %2956:2 = qlx.apply #qlx.action<pauli_rotation>(%2952, %2955, %cst_1797) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1798 = arith.constant 1.5707963267948966 : f64
    %2957 = qlx.apply #qlx.action<pauli_rotation>(%2956#0, %cst_1798) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1799 = arith.constant 1.5707963267948966 : f64
    %2958 = qlx.apply #qlx.action<pauli_rotation>(%2956#1, %cst_1799) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1800 = arith.constant 1.5707963267948966 : f64
    %2959:2 = qlx.apply #qlx.action<pauli_rotation>(%2957, %2958, %cst_1800) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1801 = arith.constant 0.78539816339744828 : f64
    %2960 = qlx.apply #qlx.action<pauli_rotation>(%2896#0, %cst_1801) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2961 = qlx.apply #qlx.action<h>(%2960) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2962 = qlx.apply #qlx.action<h>(%2917#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1802 = arith.constant 2.3561944901923448 : f64
    %2963 = qlx.apply #qlx.action<pauli_rotation>(%2962, %cst_1802) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2964 = qlx.apply #qlx.action<h>(%2963) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1803 = arith.constant 0.78539816339744828 : f64
    %2965:2 = qlx.apply #qlx.action<pauli_rotation>(%2961, %2964, %cst_1803) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1804 = arith.constant 1.5707963267948966 : f64
    %2966 = qlx.apply #qlx.action<pauli_rotation>(%2965#0, %cst_1804) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1805 = arith.constant 1.5707963267948966 : f64
    %2967 = qlx.apply #qlx.action<pauli_rotation>(%2965#1, %cst_1805) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1806 = arith.constant 0.78539816339744828 : f64
    %2968:2 = qlx.apply #qlx.action<pauli_rotation>(%2966, %2967, %cst_1806) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2969 = qlx.apply #qlx.action<h>(%2939#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1807 = arith.constant 2.3561944901923448 : f64
    %2970 = qlx.apply #qlx.action<pauli_rotation>(%2969, %cst_1807) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2971 = qlx.apply #qlx.action<h>(%2970) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2972 = qlx.apply #qlx.action<h>(%2959#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1808 = arith.constant 2.3561944901923448 : f64
    %2973 = qlx.apply #qlx.action<pauli_rotation>(%2972, %cst_1808) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2974 = qlx.apply #qlx.action<h>(%2973) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1809 = arith.constant 0.78539816339744828 : f64
    %2975:2 = qlx.apply #qlx.action<pauli_rotation>(%2971, %2974, %cst_1809) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1810 = arith.constant 1.5707963267948966 : f64
    %2976 = qlx.apply #qlx.action<pauli_rotation>(%2975#0, %cst_1810) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1811 = arith.constant 1.5707963267948966 : f64
    %2977 = qlx.apply #qlx.action<pauli_rotation>(%2975#1, %cst_1811) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1812 = arith.constant 0.78539816339744828 : f64
    %2978:2 = qlx.apply #qlx.action<pauli_rotation>(%2976, %2977, %cst_1812) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2979 = qlx.apply #qlx.action<h>(%2968#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1813 = arith.constant 2.3561944901923448 : f64
    %2980 = qlx.apply #qlx.action<pauli_rotation>(%2979, %cst_1813) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2981 = qlx.apply #qlx.action<h>(%2980) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2982 = qlx.apply #qlx.action<h>(%2978#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1814 = arith.constant 0.78539816339744828 : f64
    %2983 = qlx.apply #qlx.action<pauli_rotation>(%2982, %cst_1814) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2984 = qlx.apply #qlx.action<h>(%2983) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1815 = arith.constant 1.250000e-01 : f64
    %2985:2 = qlx.apply #qlx.action<pauli_rotation>(%2981, %2984, %cst_1815) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1816 = arith.constant 1.5707963267948966 : f64
    %2986 = qlx.apply #qlx.action<pauli_rotation>(%2985#0, %cst_1816) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1817 = arith.constant 1.5707963267948966 : f64
    %2987 = qlx.apply #qlx.action<pauli_rotation>(%2985#1, %cst_1817) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1818 = arith.constant 1.250000e-01 : f64
    %2988:2 = qlx.apply #qlx.action<pauli_rotation>(%2986, %2987, %cst_1818) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2989 = qlx.apply #qlx.action<h>(%2968#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1819 = arith.constant 1.5707963267948966 : f64
    %2990 = qlx.apply #qlx.action<pauli_rotation>(%2989, %cst_1819) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2991 = qlx.apply #qlx.action<h>(%2990) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2992 = qlx.apply #qlx.action<h>(%2988#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1820 = arith.constant 0.78539816339744828 : f64
    %2993 = qlx.apply #qlx.action<pauli_rotation>(%2992, %cst_1820) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2994 = qlx.apply #qlx.action<h>(%2993) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1821 = arith.constant 0.78539816339744828 : f64
    %2995:2 = qlx.apply #qlx.action<pauli_rotation>(%2991, %2994, %cst_1821) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1822 = arith.constant 1.5707963267948966 : f64
    %2996 = qlx.apply #qlx.action<pauli_rotation>(%2995#0, %cst_1822) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1823 = arith.constant 1.5707963267948966 : f64
    %2997 = qlx.apply #qlx.action<pauli_rotation>(%2995#1, %cst_1823) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1824 = arith.constant 0.78539816339744828 : f64
    %2998:2 = qlx.apply #qlx.action<pauli_rotation>(%2996, %2997, %cst_1824) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2999 = qlx.apply #qlx.action<h>(%2988#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1825 = arith.constant 2.3561944901923448 : f64
    %3000 = qlx.apply #qlx.action<pauli_rotation>(%2999, %cst_1825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3001 = qlx.apply #qlx.action<h>(%3000) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3002 = qlx.apply #qlx.action<h>(%2978#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1826 = arith.constant 1.5707963267948966 : f64
    %3003 = qlx.apply #qlx.action<pauli_rotation>(%3002, %cst_1826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3004 = qlx.apply #qlx.action<h>(%3003) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1827 = arith.constant 0.78539816339744828 : f64
    %3005:2 = qlx.apply #qlx.action<pauli_rotation>(%3001, %3004, %cst_1827) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1828 = arith.constant 1.5707963267948966 : f64
    %3006 = qlx.apply #qlx.action<pauli_rotation>(%3005#0, %cst_1828) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1829 = arith.constant 1.5707963267948966 : f64
    %3007 = qlx.apply #qlx.action<pauli_rotation>(%3005#1, %cst_1829) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1830 = arith.constant 0.78539816339744828 : f64
    %3008:2 = qlx.apply #qlx.action<pauli_rotation>(%3006, %3007, %cst_1830) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3009 = qlx.apply #qlx.action<h>(%2959#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1831 = arith.constant 2.3561944901923448 : f64
    %3010 = qlx.apply #qlx.action<pauli_rotation>(%3009, %cst_1831) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3011 = qlx.apply #qlx.action<h>(%3010) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3012 = qlx.apply #qlx.action<h>(%2949#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1832 = arith.constant 2.3561944901923448 : f64
    %3013 = qlx.apply #qlx.action<pauli_rotation>(%3012, %cst_1832) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3014 = qlx.apply #qlx.action<h>(%3013) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1833 = arith.constant 0.78539816339744828 : f64
    %3015:2 = qlx.apply #qlx.action<pauli_rotation>(%3011, %3014, %cst_1833) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1834 = arith.constant 1.5707963267948966 : f64
    %3016 = qlx.apply #qlx.action<pauli_rotation>(%3015#0, %cst_1834) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1835 = arith.constant 1.5707963267948966 : f64
    %3017 = qlx.apply #qlx.action<pauli_rotation>(%3015#1, %cst_1835) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1836 = arith.constant 0.78539816339744828 : f64
    %3018:2 = qlx.apply #qlx.action<pauli_rotation>(%3016, %3017, %cst_1836) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3019 = qlx.apply #qlx.action<h>(%2929#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1837 = arith.constant 2.3561944901923448 : f64
    %3020 = qlx.apply #qlx.action<pauli_rotation>(%3019, %cst_1837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3021 = qlx.apply #qlx.action<h>(%3020) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1838 = arith.constant 0.78539816339744828 : f64
    %3022 = qlx.apply #qlx.action<pauli_rotation>(%2911#1, %cst_1838) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3023 = qlx.apply #qlx.action<h>(%3022) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1839 = arith.constant 0.78539816339744828 : f64
    %3024:2 = qlx.apply #qlx.action<pauli_rotation>(%3021, %3023, %cst_1839) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1840 = arith.constant 1.5707963267948966 : f64
    %3025 = qlx.apply #qlx.action<pauli_rotation>(%3024#0, %cst_1840) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1841 = arith.constant 1.5707963267948966 : f64
    %3026 = qlx.apply #qlx.action<pauli_rotation>(%3024#1, %cst_1841) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1842 = arith.constant 0.78539816339744828 : f64
    %3027:2 = qlx.apply #qlx.action<pauli_rotation>(%3025, %3026, %cst_1842) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3028 = qlx.apply #qlx.action<h>(%3018#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1843 = arith.constant 2.3561944901923448 : f64
    %3029 = qlx.apply #qlx.action<pauli_rotation>(%3028, %cst_1843) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3030 = qlx.apply #qlx.action<h>(%3029) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3031 = qlx.apply #qlx.action<h>(%3027#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1844 = arith.constant 0.78539816339744828 : f64
    %3032 = qlx.apply #qlx.action<pauli_rotation>(%3031, %cst_1844) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3033 = qlx.apply #qlx.action<h>(%3032) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1845 = arith.constant 1.250000e-01 : f64
    %3034:2 = qlx.apply #qlx.action<pauli_rotation>(%3030, %3033, %cst_1845) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1846 = arith.constant 1.5707963267948966 : f64
    %3035 = qlx.apply #qlx.action<pauli_rotation>(%3034#0, %cst_1846) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1847 = arith.constant 1.5707963267948966 : f64
    %3036 = qlx.apply #qlx.action<pauli_rotation>(%3034#1, %cst_1847) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1848 = arith.constant 1.250000e-01 : f64
    %3037:2 = qlx.apply #qlx.action<pauli_rotation>(%3035, %3036, %cst_1848) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3038 = qlx.apply #qlx.action<h>(%3018#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1849 = arith.constant 1.5707963267948966 : f64
    %3039 = qlx.apply #qlx.action<pauli_rotation>(%3038, %cst_1849) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3040 = qlx.apply #qlx.action<h>(%3039) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3041 = qlx.apply #qlx.action<h>(%3037#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1850 = arith.constant 0.78539816339744828 : f64
    %3042 = qlx.apply #qlx.action<pauli_rotation>(%3041, %cst_1850) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3043 = qlx.apply #qlx.action<h>(%3042) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1851 = arith.constant 0.78539816339744828 : f64
    %3044:2 = qlx.apply #qlx.action<pauli_rotation>(%3040, %3043, %cst_1851) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1852 = arith.constant 1.5707963267948966 : f64
    %3045 = qlx.apply #qlx.action<pauli_rotation>(%3044#0, %cst_1852) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1853 = arith.constant 1.5707963267948966 : f64
    %3046 = qlx.apply #qlx.action<pauli_rotation>(%3044#1, %cst_1853) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1854 = arith.constant 0.78539816339744828 : f64
    %3047:2 = qlx.apply #qlx.action<pauli_rotation>(%3045, %3046, %cst_1854) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3048 = qlx.apply #qlx.action<h>(%3037#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1855 = arith.constant 2.3561944901923448 : f64
    %3049 = qlx.apply #qlx.action<pauli_rotation>(%3048, %cst_1855) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3050 = qlx.apply #qlx.action<h>(%3049) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3051 = qlx.apply #qlx.action<h>(%3027#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1856 = arith.constant 1.5707963267948966 : f64
    %3052 = qlx.apply #qlx.action<pauli_rotation>(%3051, %cst_1856) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3053 = qlx.apply #qlx.action<h>(%3052) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1857 = arith.constant 0.78539816339744828 : f64
    %3054:2 = qlx.apply #qlx.action<pauli_rotation>(%3050, %3053, %cst_1857) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1858 = arith.constant 1.5707963267948966 : f64
    %3055 = qlx.apply #qlx.action<pauli_rotation>(%3054#0, %cst_1858) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1859 = arith.constant 1.5707963267948966 : f64
    %3056 = qlx.apply #qlx.action<pauli_rotation>(%3054#1, %cst_1859) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1860 = arith.constant 0.78539816339744828 : f64
    %3057:2 = qlx.apply #qlx.action<pauli_rotation>(%3055, %3056, %cst_1860) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3058 = qlx.apply #qlx.action<h>(%3008#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1861 = arith.constant 2.3561944901923448 : f64
    %3059 = qlx.apply #qlx.action<pauli_rotation>(%3058, %cst_1861) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3060 = qlx.apply #qlx.action<h>(%3059) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3061 = qlx.apply #qlx.action<h>(%3047#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1862 = arith.constant 2.3561944901923448 : f64
    %3062 = qlx.apply #qlx.action<pauli_rotation>(%3061, %cst_1862) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3063 = qlx.apply #qlx.action<h>(%3062) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1863 = arith.constant 1.5707963267948966 : f64
    %3064:2 = qlx.apply #qlx.action<pauli_rotation>(%3060, %3063, %cst_1863) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1864 = arith.constant 1.5707963267948966 : f64
    %3065 = qlx.apply #qlx.action<pauli_rotation>(%3064#0, %cst_1864) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1865 = arith.constant 1.5707963267948966 : f64
    %3066 = qlx.apply #qlx.action<pauli_rotation>(%3064#1, %cst_1865) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1866 = arith.constant 1.5707963267948966 : f64
    %3067:2 = qlx.apply #qlx.action<pauli_rotation>(%3065, %3066, %cst_1866) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3068 = qlx.apply #qlx.action<h>(%3008#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1867 = arith.constant 2.3561944901923448 : f64
    %3069 = qlx.apply #qlx.action<pauli_rotation>(%3068, %cst_1867) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3070 = qlx.apply #qlx.action<h>(%3069) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3071 = qlx.apply #qlx.action<h>(%3067#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1868 = arith.constant 3.1415926535897931 : f64
    %3072 = qlx.apply #qlx.action<pauli_rotation>(%3071, %cst_1868) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3073 = qlx.apply #qlx.action<h>(%3072) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1869 = arith.constant 1.5707963267948966 : f64
    %3074:2 = qlx.apply #qlx.action<pauli_rotation>(%3070, %3073, %cst_1869) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1870 = arith.constant 1.5707963267948966 : f64
    %3075 = qlx.apply #qlx.action<pauli_rotation>(%3074#0, %cst_1870) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1871 = arith.constant 1.5707963267948966 : f64
    %3076 = qlx.apply #qlx.action<pauli_rotation>(%3074#1, %cst_1871) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1872 = arith.constant 1.5707963267948966 : f64
    %3077:2 = qlx.apply #qlx.action<pauli_rotation>(%3075, %3076, %cst_1872) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3078 = qlx.apply #qlx.action<h>(%3067#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1873 = arith.constant 3.1415926535897931 : f64
    %3079 = qlx.apply #qlx.action<pauli_rotation>(%3078, %cst_1873) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3080 = qlx.apply #qlx.action<h>(%3079) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3081 = qlx.apply #qlx.action<h>(%3047#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1874 = arith.constant 2.3561944901923448 : f64
    %3082 = qlx.apply #qlx.action<pauli_rotation>(%3081, %cst_1874) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3083 = qlx.apply #qlx.action<h>(%3082) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1875 = arith.constant 1.5707963267948966 : f64
    %3084:2 = qlx.apply #qlx.action<pauli_rotation>(%3080, %3083, %cst_1875) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1876 = arith.constant 1.5707963267948966 : f64
    %3085 = qlx.apply #qlx.action<pauli_rotation>(%3084#0, %cst_1876) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1877 = arith.constant 1.5707963267948966 : f64
    %3086 = qlx.apply #qlx.action<pauli_rotation>(%3084#1, %cst_1877) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1878 = arith.constant 1.5707963267948966 : f64
    %3087:2 = qlx.apply #qlx.action<pauli_rotation>(%3085, %3086, %cst_1878) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3088 = qlx.apply #qlx.action<h>(%2998#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1879 = arith.constant 2.3561944901923448 : f64
    %3089 = qlx.apply #qlx.action<pauli_rotation>(%3088, %cst_1879) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3090 = qlx.apply #qlx.action<h>(%3089) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3091 = qlx.apply #qlx.action<h>(%3077#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1880 = arith.constant 3.1415926535897931 : f64
    %3092 = qlx.apply #qlx.action<pauli_rotation>(%3091, %cst_1880) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3093 = qlx.apply #qlx.action<h>(%3092) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1881 = arith.constant 1.5707963267948966 : f64
    %3094:2 = qlx.apply #qlx.action<pauli_rotation>(%3090, %3093, %cst_1881) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1882 = arith.constant 1.5707963267948966 : f64
    %3095 = qlx.apply #qlx.action<pauli_rotation>(%3094#0, %cst_1882) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1883 = arith.constant 1.5707963267948966 : f64
    %3096 = qlx.apply #qlx.action<pauli_rotation>(%3094#1, %cst_1883) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1884 = arith.constant 1.5707963267948966 : f64
    %3097:2 = qlx.apply #qlx.action<pauli_rotation>(%3095, %3096, %cst_1884) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3098 = qlx.apply #qlx.action<h>(%3077#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1885 = arith.constant 3.1415926535897931 : f64
    %3099 = qlx.apply #qlx.action<pauli_rotation>(%3098, %cst_1885) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3100 = qlx.apply #qlx.action<h>(%3099) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3101 = qlx.apply #qlx.action<h>(%3087#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1886 = arith.constant 3.1415926535897931 : f64
    %3102 = qlx.apply #qlx.action<pauli_rotation>(%3101, %cst_1886) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3103 = qlx.apply #qlx.action<h>(%3102) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1887 = arith.constant 1.5707963267948966 : f64
    %3104:2 = qlx.apply #qlx.action<pauli_rotation>(%3100, %3103, %cst_1887) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1888 = arith.constant 1.5707963267948966 : f64
    %3105 = qlx.apply #qlx.action<pauli_rotation>(%3104#0, %cst_1888) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1889 = arith.constant 1.5707963267948966 : f64
    %3106 = qlx.apply #qlx.action<pauli_rotation>(%3104#1, %cst_1889) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1890 = arith.constant 1.5707963267948966 : f64
    %3107:2 = qlx.apply #qlx.action<pauli_rotation>(%3105, %3106, %cst_1890) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3108 = qlx.apply #qlx.action<h>(%3087#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1891 = arith.constant 3.1415926535897931 : f64
    %3109 = qlx.apply #qlx.action<pauli_rotation>(%3108, %cst_1891) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3110 = qlx.apply #qlx.action<h>(%3109) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3111 = qlx.apply #qlx.action<h>(%3057#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1892 = arith.constant 2.3561944901923448 : f64
    %3112 = qlx.apply #qlx.action<pauli_rotation>(%3111, %cst_1892) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3113 = qlx.apply #qlx.action<h>(%3112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1893 = arith.constant 1.5707963267948966 : f64
    %3114:2 = qlx.apply #qlx.action<pauli_rotation>(%3110, %3113, %cst_1893) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1894 = arith.constant 1.5707963267948966 : f64
    %3115 = qlx.apply #qlx.action<pauli_rotation>(%3114#0, %cst_1894) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1895 = arith.constant 1.5707963267948966 : f64
    %3116 = qlx.apply #qlx.action<pauli_rotation>(%3114#1, %cst_1895) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1896 = arith.constant 1.5707963267948966 : f64
    %3117:2 = qlx.apply #qlx.action<pauli_rotation>(%3115, %3116, %cst_1896) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3118 = qlx.apply #qlx.action<h>(%2998#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1897 = arith.constant 2.3561944901923448 : f64
    %3119 = qlx.apply #qlx.action<pauli_rotation>(%3118, %cst_1897) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3120 = qlx.apply #qlx.action<h>(%3097#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1898 = arith.constant 3.1415926535897931 : f64
    %3121 = qlx.apply #qlx.action<pauli_rotation>(%3120, %cst_1898) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1899 = arith.constant 1.250000e-01 : f64
    %3122:2 = qlx.apply #qlx.action<pauli_rotation>(%3119, %3121, %cst_1899) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3123 = qlx.apply #qlx.action<h>(%3097#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1900 = arith.constant 3.1415926535897931 : f64
    %3124 = qlx.apply #qlx.action<pauli_rotation>(%3123, %cst_1900) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3125 = qlx.apply #qlx.action<h>(%3107#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1901 = arith.constant 3.1415926535897931 : f64
    %3126 = qlx.apply #qlx.action<pauli_rotation>(%3125, %cst_1901) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1902 = arith.constant 1.250000e-01 : f64
    %3127:2 = qlx.apply #qlx.action<pauli_rotation>(%3124, %3126, %cst_1902) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3128 = qlx.apply #qlx.action<h>(%3107#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1903 = arith.constant 3.1415926535897931 : f64
    %3129 = qlx.apply #qlx.action<pauli_rotation>(%3128, %cst_1903) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3130 = qlx.apply #qlx.action<h>(%3117#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1904 = arith.constant 3.1415926535897931 : f64
    %3131 = qlx.apply #qlx.action<pauli_rotation>(%3130, %cst_1904) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1905 = arith.constant 1.250000e-01 : f64
    %3132:2 = qlx.apply #qlx.action<pauli_rotation>(%3129, %3131, %cst_1905) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3133 = qlx.apply #qlx.action<h>(%3117#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1906 = arith.constant 3.1415926535897931 : f64
    %3134 = qlx.apply #qlx.action<pauli_rotation>(%3133, %cst_1906) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3135 = qlx.apply #qlx.action<h>(%3057#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1907 = arith.constant 2.3561944901923448 : f64
    %3136 = qlx.apply #qlx.action<pauli_rotation>(%3135, %cst_1907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1908 = arith.constant 1.250000e-01 : f64
    %3137:2 = qlx.apply #qlx.action<pauli_rotation>(%3134, %3136, %cst_1908) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3138 = qlx.apply #qlx.action<h>(%3122#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3139 = qlx.apply #qlx.action<h>(%3127#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1909 = arith.constant 1.5707963267948966 : f64
    %3140:2 = qlx.apply #qlx.action<pauli_rotation>(%3138, %3139, %cst_1909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1910 = arith.constant 1.5707963267948966 : f64
    %3141 = qlx.apply #qlx.action<pauli_rotation>(%3140#0, %cst_1910) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1911 = arith.constant 1.5707963267948966 : f64
    %3142 = qlx.apply #qlx.action<pauli_rotation>(%3140#1, %cst_1911) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1912 = arith.constant 1.5707963267948966 : f64
    %3143:2 = qlx.apply #qlx.action<pauli_rotation>(%3141, %3142, %cst_1912) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3144 = qlx.apply #qlx.action<h>(%3127#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3145 = qlx.apply #qlx.action<h>(%3132#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1913 = arith.constant 1.5707963267948966 : f64
    %3146:2 = qlx.apply #qlx.action<pauli_rotation>(%3144, %3145, %cst_1913) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1914 = arith.constant 1.5707963267948966 : f64
    %3147 = qlx.apply #qlx.action<pauli_rotation>(%3146#0, %cst_1914) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1915 = arith.constant 1.5707963267948966 : f64
    %3148 = qlx.apply #qlx.action<pauli_rotation>(%3146#1, %cst_1915) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1916 = arith.constant 1.5707963267948966 : f64
    %3149:2 = qlx.apply #qlx.action<pauli_rotation>(%3147, %3148, %cst_1916) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3150 = qlx.apply #qlx.action<h>(%3132#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3151 = qlx.apply #qlx.action<h>(%3137#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1917 = arith.constant 1.5707963267948966 : f64
    %3152:2 = qlx.apply #qlx.action<pauli_rotation>(%3150, %3151, %cst_1917) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1918 = arith.constant 1.5707963267948966 : f64
    %3153 = qlx.apply #qlx.action<pauli_rotation>(%3152#0, %cst_1918) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1919 = arith.constant 1.5707963267948966 : f64
    %3154 = qlx.apply #qlx.action<pauli_rotation>(%3152#1, %cst_1919) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1920 = arith.constant 1.5707963267948966 : f64
    %3155:2 = qlx.apply #qlx.action<pauli_rotation>(%3153, %3154, %cst_1920) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3156 = qlx.apply #qlx.action<h>(%3143#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1921 = arith.constant 3.1415926535897931 : f64
    %3157 = qlx.apply #qlx.action<pauli_rotation>(%3156, %cst_1921) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3158 = qlx.apply #qlx.action<h>(%3157) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3159 = qlx.apply #qlx.action<h>(%3149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1922 = arith.constant 3.1415926535897931 : f64
    %3160 = qlx.apply #qlx.action<pauli_rotation>(%3159, %cst_1922) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3161 = qlx.apply #qlx.action<h>(%3160) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1923 = arith.constant 1.5707963267948966 : f64
    %3162:2 = qlx.apply #qlx.action<pauli_rotation>(%3158, %3161, %cst_1923) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1924 = arith.constant 1.5707963267948966 : f64
    %3163 = qlx.apply #qlx.action<pauli_rotation>(%3162#0, %cst_1924) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1925 = arith.constant 1.5707963267948966 : f64
    %3164 = qlx.apply #qlx.action<pauli_rotation>(%3162#1, %cst_1925) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1926 = arith.constant 1.5707963267948966 : f64
    %3165:2 = qlx.apply #qlx.action<pauli_rotation>(%3163, %3164, %cst_1926) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3166 = qlx.apply #qlx.action<h>(%3149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1927 = arith.constant 3.1415926535897931 : f64
    %3167 = qlx.apply #qlx.action<pauli_rotation>(%3166, %cst_1927) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3168 = qlx.apply #qlx.action<h>(%3167) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3169 = qlx.apply #qlx.action<h>(%3155#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1928 = arith.constant 3.1415926535897931 : f64
    %3170 = qlx.apply #qlx.action<pauli_rotation>(%3169, %cst_1928) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3171 = qlx.apply #qlx.action<h>(%3170) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1929 = arith.constant 1.5707963267948966 : f64
    %3172:2 = qlx.apply #qlx.action<pauli_rotation>(%3168, %3171, %cst_1929) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1930 = arith.constant 1.5707963267948966 : f64
    %3173 = qlx.apply #qlx.action<pauli_rotation>(%3172#0, %cst_1930) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1931 = arith.constant 1.5707963267948966 : f64
    %3174 = qlx.apply #qlx.action<pauli_rotation>(%3172#1, %cst_1931) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1932 = arith.constant 1.5707963267948966 : f64
    %3175:2 = qlx.apply #qlx.action<pauli_rotation>(%3173, %3174, %cst_1932) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3176 = qlx.apply #qlx.action<h>(%3165#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1933 = arith.constant 3.1415926535897931 : f64
    %3177 = qlx.apply #qlx.action<pauli_rotation>(%3176, %cst_1933) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3178 = qlx.apply #qlx.action<h>(%3177) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3179 = qlx.apply #qlx.action<h>(%3175#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1934 = arith.constant 3.1415926535897931 : f64
    %3180 = qlx.apply #qlx.action<pauli_rotation>(%3179, %cst_1934) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3181 = qlx.apply #qlx.action<h>(%3180) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1935 = arith.constant 1.5707963267948966 : f64
    %3182:2 = qlx.apply #qlx.action<pauli_rotation>(%3178, %3181, %cst_1935) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1936 = arith.constant 1.5707963267948966 : f64
    %3183 = qlx.apply #qlx.action<pauli_rotation>(%3182#0, %cst_1936) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1937 = arith.constant 1.5707963267948966 : f64
    %3184 = qlx.apply #qlx.action<pauli_rotation>(%3182#1, %cst_1937) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1938 = arith.constant 1.5707963267948966 : f64
    %3185:2 = qlx.apply #qlx.action<pauli_rotation>(%3183, %3184, %cst_1938) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1939 = arith.constant 0.78539816339744828 : f64
    %3186 = qlx.apply #qlx.action<pauli_rotation>(%3122#0, %cst_1939) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3187 = qlx.apply #qlx.action<h>(%3186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3188 = qlx.apply #qlx.action<h>(%3143#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1940 = arith.constant 2.3561944901923448 : f64
    %3189 = qlx.apply #qlx.action<pauli_rotation>(%3188, %cst_1940) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3190 = qlx.apply #qlx.action<h>(%3189) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1941 = arith.constant 0.78539816339744828 : f64
    %3191:2 = qlx.apply #qlx.action<pauli_rotation>(%3187, %3190, %cst_1941) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1942 = arith.constant 1.5707963267948966 : f64
    %3192 = qlx.apply #qlx.action<pauli_rotation>(%3191#0, %cst_1942) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1943 = arith.constant 1.5707963267948966 : f64
    %3193 = qlx.apply #qlx.action<pauli_rotation>(%3191#1, %cst_1943) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1944 = arith.constant 0.78539816339744828 : f64
    %3194:2 = qlx.apply #qlx.action<pauli_rotation>(%3192, %3193, %cst_1944) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3195 = qlx.apply #qlx.action<h>(%3165#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1945 = arith.constant 2.3561944901923448 : f64
    %3196 = qlx.apply #qlx.action<pauli_rotation>(%3195, %cst_1945) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3197 = qlx.apply #qlx.action<h>(%3196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3198 = qlx.apply #qlx.action<h>(%3185#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1946 = arith.constant 2.3561944901923448 : f64
    %3199 = qlx.apply #qlx.action<pauli_rotation>(%3198, %cst_1946) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3200 = qlx.apply #qlx.action<h>(%3199) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1947 = arith.constant 0.78539816339744828 : f64
    %3201:2 = qlx.apply #qlx.action<pauli_rotation>(%3197, %3200, %cst_1947) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1948 = arith.constant 1.5707963267948966 : f64
    %3202 = qlx.apply #qlx.action<pauli_rotation>(%3201#0, %cst_1948) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1949 = arith.constant 1.5707963267948966 : f64
    %3203 = qlx.apply #qlx.action<pauli_rotation>(%3201#1, %cst_1949) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1950 = arith.constant 0.78539816339744828 : f64
    %3204:2 = qlx.apply #qlx.action<pauli_rotation>(%3202, %3203, %cst_1950) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3205 = qlx.apply #qlx.action<h>(%3194#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1951 = arith.constant 2.3561944901923448 : f64
    %3206 = qlx.apply #qlx.action<pauli_rotation>(%3205, %cst_1951) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3207 = qlx.apply #qlx.action<h>(%3206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3208 = qlx.apply #qlx.action<h>(%3204#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1952 = arith.constant 0.78539816339744828 : f64
    %3209 = qlx.apply #qlx.action<pauli_rotation>(%3208, %cst_1952) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3210 = qlx.apply #qlx.action<h>(%3209) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1953 = arith.constant 1.250000e-01 : f64
    %3211:2 = qlx.apply #qlx.action<pauli_rotation>(%3207, %3210, %cst_1953) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1954 = arith.constant 1.5707963267948966 : f64
    %3212 = qlx.apply #qlx.action<pauli_rotation>(%3211#0, %cst_1954) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1955 = arith.constant 1.5707963267948966 : f64
    %3213 = qlx.apply #qlx.action<pauli_rotation>(%3211#1, %cst_1955) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1956 = arith.constant 1.250000e-01 : f64
    %3214:2 = qlx.apply #qlx.action<pauli_rotation>(%3212, %3213, %cst_1956) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3215 = qlx.apply #qlx.action<h>(%3194#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1957 = arith.constant 1.5707963267948966 : f64
    %3216 = qlx.apply #qlx.action<pauli_rotation>(%3215, %cst_1957) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3217 = qlx.apply #qlx.action<h>(%3216) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3218 = qlx.apply #qlx.action<h>(%3214#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1958 = arith.constant 0.78539816339744828 : f64
    %3219 = qlx.apply #qlx.action<pauli_rotation>(%3218, %cst_1958) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3220 = qlx.apply #qlx.action<h>(%3219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1959 = arith.constant 0.78539816339744828 : f64
    %3221:2 = qlx.apply #qlx.action<pauli_rotation>(%3217, %3220, %cst_1959) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1960 = arith.constant 1.5707963267948966 : f64
    %3222 = qlx.apply #qlx.action<pauli_rotation>(%3221#0, %cst_1960) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1961 = arith.constant 1.5707963267948966 : f64
    %3223 = qlx.apply #qlx.action<pauli_rotation>(%3221#1, %cst_1961) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1962 = arith.constant 0.78539816339744828 : f64
    %3224:2 = qlx.apply #qlx.action<pauli_rotation>(%3222, %3223, %cst_1962) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3225 = qlx.apply #qlx.action<h>(%3214#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1963 = arith.constant 2.3561944901923448 : f64
    %3226 = qlx.apply #qlx.action<pauli_rotation>(%3225, %cst_1963) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3227 = qlx.apply #qlx.action<h>(%3226) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3228 = qlx.apply #qlx.action<h>(%3204#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1964 = arith.constant 1.5707963267948966 : f64
    %3229 = qlx.apply #qlx.action<pauli_rotation>(%3228, %cst_1964) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3230 = qlx.apply #qlx.action<h>(%3229) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1965 = arith.constant 0.78539816339744828 : f64
    %3231:2 = qlx.apply #qlx.action<pauli_rotation>(%3227, %3230, %cst_1965) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1966 = arith.constant 1.5707963267948966 : f64
    %3232 = qlx.apply #qlx.action<pauli_rotation>(%3231#0, %cst_1966) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1967 = arith.constant 1.5707963267948966 : f64
    %3233 = qlx.apply #qlx.action<pauli_rotation>(%3231#1, %cst_1967) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1968 = arith.constant 0.78539816339744828 : f64
    %3234:2 = qlx.apply #qlx.action<pauli_rotation>(%3232, %3233, %cst_1968) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3235 = qlx.apply #qlx.action<h>(%3185#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1969 = arith.constant 2.3561944901923448 : f64
    %3236 = qlx.apply #qlx.action<pauli_rotation>(%3235, %cst_1969) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3237 = qlx.apply #qlx.action<h>(%3236) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3238 = qlx.apply #qlx.action<h>(%3175#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1970 = arith.constant 2.3561944901923448 : f64
    %3239 = qlx.apply #qlx.action<pauli_rotation>(%3238, %cst_1970) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3240 = qlx.apply #qlx.action<h>(%3239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1971 = arith.constant 0.78539816339744828 : f64
    %3241:2 = qlx.apply #qlx.action<pauli_rotation>(%3237, %3240, %cst_1971) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1972 = arith.constant 1.5707963267948966 : f64
    %3242 = qlx.apply #qlx.action<pauli_rotation>(%3241#0, %cst_1972) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1973 = arith.constant 1.5707963267948966 : f64
    %3243 = qlx.apply #qlx.action<pauli_rotation>(%3241#1, %cst_1973) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1974 = arith.constant 0.78539816339744828 : f64
    %3244:2 = qlx.apply #qlx.action<pauli_rotation>(%3242, %3243, %cst_1974) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3245 = qlx.apply #qlx.action<h>(%3155#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1975 = arith.constant 2.3561944901923448 : f64
    %3246 = qlx.apply #qlx.action<pauli_rotation>(%3245, %cst_1975) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3247 = qlx.apply #qlx.action<h>(%3246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1976 = arith.constant 0.78539816339744828 : f64
    %3248 = qlx.apply #qlx.action<pauli_rotation>(%3137#1, %cst_1976) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3249 = qlx.apply #qlx.action<h>(%3248) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1977 = arith.constant 0.78539816339744828 : f64
    %3250:2 = qlx.apply #qlx.action<pauli_rotation>(%3247, %3249, %cst_1977) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1978 = arith.constant 1.5707963267948966 : f64
    %3251 = qlx.apply #qlx.action<pauli_rotation>(%3250#0, %cst_1978) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1979 = arith.constant 1.5707963267948966 : f64
    %3252 = qlx.apply #qlx.action<pauli_rotation>(%3250#1, %cst_1979) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1980 = arith.constant 0.78539816339744828 : f64
    %3253:2 = qlx.apply #qlx.action<pauli_rotation>(%3251, %3252, %cst_1980) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3254 = qlx.apply #qlx.action<h>(%3244#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1981 = arith.constant 2.3561944901923448 : f64
    %3255 = qlx.apply #qlx.action<pauli_rotation>(%3254, %cst_1981) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3256 = qlx.apply #qlx.action<h>(%3255) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3257 = qlx.apply #qlx.action<h>(%3253#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1982 = arith.constant 0.78539816339744828 : f64
    %3258 = qlx.apply #qlx.action<pauli_rotation>(%3257, %cst_1982) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3259 = qlx.apply #qlx.action<h>(%3258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1983 = arith.constant 1.250000e-01 : f64
    %3260:2 = qlx.apply #qlx.action<pauli_rotation>(%3256, %3259, %cst_1983) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1984 = arith.constant 1.5707963267948966 : f64
    %3261 = qlx.apply #qlx.action<pauli_rotation>(%3260#0, %cst_1984) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1985 = arith.constant 1.5707963267948966 : f64
    %3262 = qlx.apply #qlx.action<pauli_rotation>(%3260#1, %cst_1985) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1986 = arith.constant 1.250000e-01 : f64
    %3263:2 = qlx.apply #qlx.action<pauli_rotation>(%3261, %3262, %cst_1986) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3264 = qlx.apply #qlx.action<h>(%3244#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1987 = arith.constant 1.5707963267948966 : f64
    %3265 = qlx.apply #qlx.action<pauli_rotation>(%3264, %cst_1987) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3266 = qlx.apply #qlx.action<h>(%3265) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3267 = qlx.apply #qlx.action<h>(%3263#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1988 = arith.constant 0.78539816339744828 : f64
    %3268 = qlx.apply #qlx.action<pauli_rotation>(%3267, %cst_1988) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3269 = qlx.apply #qlx.action<h>(%3268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1989 = arith.constant 0.78539816339744828 : f64
    %3270:2 = qlx.apply #qlx.action<pauli_rotation>(%3266, %3269, %cst_1989) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1990 = arith.constant 1.5707963267948966 : f64
    %3271 = qlx.apply #qlx.action<pauli_rotation>(%3270#0, %cst_1990) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1991 = arith.constant 1.5707963267948966 : f64
    %3272 = qlx.apply #qlx.action<pauli_rotation>(%3270#1, %cst_1991) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1992 = arith.constant 0.78539816339744828 : f64
    %3273:2 = qlx.apply #qlx.action<pauli_rotation>(%3271, %3272, %cst_1992) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3274 = qlx.apply #qlx.action<h>(%3263#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1993 = arith.constant 2.3561944901923448 : f64
    %3275 = qlx.apply #qlx.action<pauli_rotation>(%3274, %cst_1993) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3276 = qlx.apply #qlx.action<h>(%3275) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3277 = qlx.apply #qlx.action<h>(%3253#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1994 = arith.constant 1.5707963267948966 : f64
    %3278 = qlx.apply #qlx.action<pauli_rotation>(%3277, %cst_1994) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3279 = qlx.apply #qlx.action<h>(%3278) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1995 = arith.constant 0.78539816339744828 : f64
    %3280:2 = qlx.apply #qlx.action<pauli_rotation>(%3276, %3279, %cst_1995) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1996 = arith.constant 1.5707963267948966 : f64
    %3281 = qlx.apply #qlx.action<pauli_rotation>(%3280#0, %cst_1996) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1997 = arith.constant 1.5707963267948966 : f64
    %3282 = qlx.apply #qlx.action<pauli_rotation>(%3280#1, %cst_1997) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1998 = arith.constant 0.78539816339744828 : f64
    %3283:2 = qlx.apply #qlx.action<pauli_rotation>(%3281, %3282, %cst_1998) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3284 = qlx.apply #qlx.action<h>(%3234#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1999 = arith.constant 2.3561944901923448 : f64
    %3285 = qlx.apply #qlx.action<pauli_rotation>(%3284, %cst_1999) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3286 = qlx.apply #qlx.action<h>(%3285) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3287 = qlx.apply #qlx.action<h>(%3273#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2000 = arith.constant 2.3561944901923448 : f64
    %3288 = qlx.apply #qlx.action<pauli_rotation>(%3287, %cst_2000) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3289 = qlx.apply #qlx.action<h>(%3288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2001 = arith.constant 1.5707963267948966 : f64
    %3290:2 = qlx.apply #qlx.action<pauli_rotation>(%3286, %3289, %cst_2001) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2002 = arith.constant 1.5707963267948966 : f64
    %3291 = qlx.apply #qlx.action<pauli_rotation>(%3290#0, %cst_2002) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2003 = arith.constant 1.5707963267948966 : f64
    %3292 = qlx.apply #qlx.action<pauli_rotation>(%3290#1, %cst_2003) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2004 = arith.constant 1.5707963267948966 : f64
    %3293:2 = qlx.apply #qlx.action<pauli_rotation>(%3291, %3292, %cst_2004) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3294 = qlx.apply #qlx.action<h>(%3234#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2005 = arith.constant 2.3561944901923448 : f64
    %3295 = qlx.apply #qlx.action<pauli_rotation>(%3294, %cst_2005) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3296 = qlx.apply #qlx.action<h>(%3295) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3297 = qlx.apply #qlx.action<h>(%3293#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2006 = arith.constant 3.1415926535897931 : f64
    %3298 = qlx.apply #qlx.action<pauli_rotation>(%3297, %cst_2006) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3299 = qlx.apply #qlx.action<h>(%3298) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2007 = arith.constant 1.5707963267948966 : f64
    %3300:2 = qlx.apply #qlx.action<pauli_rotation>(%3296, %3299, %cst_2007) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2008 = arith.constant 1.5707963267948966 : f64
    %3301 = qlx.apply #qlx.action<pauli_rotation>(%3300#0, %cst_2008) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2009 = arith.constant 1.5707963267948966 : f64
    %3302 = qlx.apply #qlx.action<pauli_rotation>(%3300#1, %cst_2009) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2010 = arith.constant 1.5707963267948966 : f64
    %3303:2 = qlx.apply #qlx.action<pauli_rotation>(%3301, %3302, %cst_2010) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3304 = qlx.apply #qlx.action<h>(%3293#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2011 = arith.constant 3.1415926535897931 : f64
    %3305 = qlx.apply #qlx.action<pauli_rotation>(%3304, %cst_2011) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3306 = qlx.apply #qlx.action<h>(%3305) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3307 = qlx.apply #qlx.action<h>(%3273#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2012 = arith.constant 2.3561944901923448 : f64
    %3308 = qlx.apply #qlx.action<pauli_rotation>(%3307, %cst_2012) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3309 = qlx.apply #qlx.action<h>(%3308) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2013 = arith.constant 1.5707963267948966 : f64
    %3310:2 = qlx.apply #qlx.action<pauli_rotation>(%3306, %3309, %cst_2013) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2014 = arith.constant 1.5707963267948966 : f64
    %3311 = qlx.apply #qlx.action<pauli_rotation>(%3310#0, %cst_2014) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2015 = arith.constant 1.5707963267948966 : f64
    %3312 = qlx.apply #qlx.action<pauli_rotation>(%3310#1, %cst_2015) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2016 = arith.constant 1.5707963267948966 : f64
    %3313:2 = qlx.apply #qlx.action<pauli_rotation>(%3311, %3312, %cst_2016) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3314 = qlx.apply #qlx.action<h>(%3224#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2017 = arith.constant 2.3561944901923448 : f64
    %3315 = qlx.apply #qlx.action<pauli_rotation>(%3314, %cst_2017) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3316 = qlx.apply #qlx.action<h>(%3315) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3317 = qlx.apply #qlx.action<h>(%3303#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2018 = arith.constant 3.1415926535897931 : f64
    %3318 = qlx.apply #qlx.action<pauli_rotation>(%3317, %cst_2018) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3319 = qlx.apply #qlx.action<h>(%3318) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2019 = arith.constant 1.5707963267948966 : f64
    %3320:2 = qlx.apply #qlx.action<pauli_rotation>(%3316, %3319, %cst_2019) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2020 = arith.constant 1.5707963267948966 : f64
    %3321 = qlx.apply #qlx.action<pauli_rotation>(%3320#0, %cst_2020) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2021 = arith.constant 1.5707963267948966 : f64
    %3322 = qlx.apply #qlx.action<pauli_rotation>(%3320#1, %cst_2021) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2022 = arith.constant 1.5707963267948966 : f64
    %3323:2 = qlx.apply #qlx.action<pauli_rotation>(%3321, %3322, %cst_2022) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3324 = qlx.apply #qlx.action<h>(%3303#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2023 = arith.constant 3.1415926535897931 : f64
    %3325 = qlx.apply #qlx.action<pauli_rotation>(%3324, %cst_2023) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3326 = qlx.apply #qlx.action<h>(%3325) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3327 = qlx.apply #qlx.action<h>(%3313#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2024 = arith.constant 3.1415926535897931 : f64
    %3328 = qlx.apply #qlx.action<pauli_rotation>(%3327, %cst_2024) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3329 = qlx.apply #qlx.action<h>(%3328) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2025 = arith.constant 1.5707963267948966 : f64
    %3330:2 = qlx.apply #qlx.action<pauli_rotation>(%3326, %3329, %cst_2025) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2026 = arith.constant 1.5707963267948966 : f64
    %3331 = qlx.apply #qlx.action<pauli_rotation>(%3330#0, %cst_2026) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2027 = arith.constant 1.5707963267948966 : f64
    %3332 = qlx.apply #qlx.action<pauli_rotation>(%3330#1, %cst_2027) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2028 = arith.constant 1.5707963267948966 : f64
    %3333:2 = qlx.apply #qlx.action<pauli_rotation>(%3331, %3332, %cst_2028) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3334 = qlx.apply #qlx.action<h>(%3313#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2029 = arith.constant 3.1415926535897931 : f64
    %3335 = qlx.apply #qlx.action<pauli_rotation>(%3334, %cst_2029) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3336 = qlx.apply #qlx.action<h>(%3335) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3337 = qlx.apply #qlx.action<h>(%3283#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2030 = arith.constant 2.3561944901923448 : f64
    %3338 = qlx.apply #qlx.action<pauli_rotation>(%3337, %cst_2030) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3339 = qlx.apply #qlx.action<h>(%3338) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2031 = arith.constant 1.5707963267948966 : f64
    %3340:2 = qlx.apply #qlx.action<pauli_rotation>(%3336, %3339, %cst_2031) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2032 = arith.constant 1.5707963267948966 : f64
    %3341 = qlx.apply #qlx.action<pauli_rotation>(%3340#0, %cst_2032) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2033 = arith.constant 1.5707963267948966 : f64
    %3342 = qlx.apply #qlx.action<pauli_rotation>(%3340#1, %cst_2033) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2034 = arith.constant 1.5707963267948966 : f64
    %3343:2 = qlx.apply #qlx.action<pauli_rotation>(%3341, %3342, %cst_2034) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3344 = qlx.apply #qlx.action<h>(%3224#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2035 = arith.constant 2.3561944901923448 : f64
    %3345 = qlx.apply #qlx.action<pauli_rotation>(%3344, %cst_2035) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3346 = qlx.apply #qlx.action<h>(%3323#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2036 = arith.constant 3.1415926535897931 : f64
    %3347 = qlx.apply #qlx.action<pauli_rotation>(%3346, %cst_2036) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2037 = arith.constant 1.250000e-01 : f64
    %3348:2 = qlx.apply #qlx.action<pauli_rotation>(%3345, %3347, %cst_2037) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3349 = qlx.apply #qlx.action<h>(%3323#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2038 = arith.constant 3.1415926535897931 : f64
    %3350 = qlx.apply #qlx.action<pauli_rotation>(%3349, %cst_2038) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3351 = qlx.apply #qlx.action<h>(%3333#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2039 = arith.constant 3.1415926535897931 : f64
    %3352 = qlx.apply #qlx.action<pauli_rotation>(%3351, %cst_2039) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2040 = arith.constant 1.250000e-01 : f64
    %3353:2 = qlx.apply #qlx.action<pauli_rotation>(%3350, %3352, %cst_2040) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3354 = qlx.apply #qlx.action<h>(%3333#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2041 = arith.constant 3.1415926535897931 : f64
    %3355 = qlx.apply #qlx.action<pauli_rotation>(%3354, %cst_2041) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3356 = qlx.apply #qlx.action<h>(%3343#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2042 = arith.constant 3.1415926535897931 : f64
    %3357 = qlx.apply #qlx.action<pauli_rotation>(%3356, %cst_2042) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2043 = arith.constant 1.250000e-01 : f64
    %3358:2 = qlx.apply #qlx.action<pauli_rotation>(%3355, %3357, %cst_2043) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3359 = qlx.apply #qlx.action<h>(%3343#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2044 = arith.constant 3.1415926535897931 : f64
    %3360 = qlx.apply #qlx.action<pauli_rotation>(%3359, %cst_2044) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3361 = qlx.apply #qlx.action<h>(%3283#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2045 = arith.constant 2.3561944901923448 : f64
    %3362 = qlx.apply #qlx.action<pauli_rotation>(%3361, %cst_2045) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2046 = arith.constant 1.250000e-01 : f64
    %3363:2 = qlx.apply #qlx.action<pauli_rotation>(%3360, %3362, %cst_2046) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3364 = qlx.apply #qlx.action<h>(%3348#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3365 = qlx.apply #qlx.action<h>(%3353#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2047 = arith.constant 1.5707963267948966 : f64
    %3366:2 = qlx.apply #qlx.action<pauli_rotation>(%3364, %3365, %cst_2047) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2048 = arith.constant 1.5707963267948966 : f64
    %3367 = qlx.apply #qlx.action<pauli_rotation>(%3366#0, %cst_2048) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2049 = arith.constant 1.5707963267948966 : f64
    %3368 = qlx.apply #qlx.action<pauli_rotation>(%3366#1, %cst_2049) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2050 = arith.constant 1.5707963267948966 : f64
    %3369:2 = qlx.apply #qlx.action<pauli_rotation>(%3367, %3368, %cst_2050) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3370 = qlx.apply #qlx.action<h>(%3353#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3371 = qlx.apply #qlx.action<h>(%3358#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2051 = arith.constant 1.5707963267948966 : f64
    %3372:2 = qlx.apply #qlx.action<pauli_rotation>(%3370, %3371, %cst_2051) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2052 = arith.constant 1.5707963267948966 : f64
    %3373 = qlx.apply #qlx.action<pauli_rotation>(%3372#0, %cst_2052) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2053 = arith.constant 1.5707963267948966 : f64
    %3374 = qlx.apply #qlx.action<pauli_rotation>(%3372#1, %cst_2053) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2054 = arith.constant 1.5707963267948966 : f64
    %3375:2 = qlx.apply #qlx.action<pauli_rotation>(%3373, %3374, %cst_2054) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3376 = qlx.apply #qlx.action<h>(%3358#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3377 = qlx.apply #qlx.action<h>(%3363#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2055 = arith.constant 1.5707963267948966 : f64
    %3378:2 = qlx.apply #qlx.action<pauli_rotation>(%3376, %3377, %cst_2055) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2056 = arith.constant 1.5707963267948966 : f64
    %3379 = qlx.apply #qlx.action<pauli_rotation>(%3378#0, %cst_2056) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2057 = arith.constant 1.5707963267948966 : f64
    %3380 = qlx.apply #qlx.action<pauli_rotation>(%3378#1, %cst_2057) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2058 = arith.constant 1.5707963267948966 : f64
    %3381:2 = qlx.apply #qlx.action<pauli_rotation>(%3379, %3380, %cst_2058) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3382 = qlx.apply #qlx.action<h>(%3369#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2059 = arith.constant 3.1415926535897931 : f64
    %3383 = qlx.apply #qlx.action<pauli_rotation>(%3382, %cst_2059) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3384 = qlx.apply #qlx.action<h>(%3383) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3385 = qlx.apply #qlx.action<h>(%3375#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2060 = arith.constant 3.1415926535897931 : f64
    %3386 = qlx.apply #qlx.action<pauli_rotation>(%3385, %cst_2060) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3387 = qlx.apply #qlx.action<h>(%3386) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2061 = arith.constant 1.5707963267948966 : f64
    %3388:2 = qlx.apply #qlx.action<pauli_rotation>(%3384, %3387, %cst_2061) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2062 = arith.constant 1.5707963267948966 : f64
    %3389 = qlx.apply #qlx.action<pauli_rotation>(%3388#0, %cst_2062) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2063 = arith.constant 1.5707963267948966 : f64
    %3390 = qlx.apply #qlx.action<pauli_rotation>(%3388#1, %cst_2063) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2064 = arith.constant 1.5707963267948966 : f64
    %3391:2 = qlx.apply #qlx.action<pauli_rotation>(%3389, %3390, %cst_2064) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3392 = qlx.apply #qlx.action<h>(%3375#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2065 = arith.constant 3.1415926535897931 : f64
    %3393 = qlx.apply #qlx.action<pauli_rotation>(%3392, %cst_2065) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3394 = qlx.apply #qlx.action<h>(%3393) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3395 = qlx.apply #qlx.action<h>(%3381#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2066 = arith.constant 3.1415926535897931 : f64
    %3396 = qlx.apply #qlx.action<pauli_rotation>(%3395, %cst_2066) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3397 = qlx.apply #qlx.action<h>(%3396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2067 = arith.constant 1.5707963267948966 : f64
    %3398:2 = qlx.apply #qlx.action<pauli_rotation>(%3394, %3397, %cst_2067) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2068 = arith.constant 1.5707963267948966 : f64
    %3399 = qlx.apply #qlx.action<pauli_rotation>(%3398#0, %cst_2068) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2069 = arith.constant 1.5707963267948966 : f64
    %3400 = qlx.apply #qlx.action<pauli_rotation>(%3398#1, %cst_2069) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2070 = arith.constant 1.5707963267948966 : f64
    %3401:2 = qlx.apply #qlx.action<pauli_rotation>(%3399, %3400, %cst_2070) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3402 = qlx.apply #qlx.action<h>(%3391#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2071 = arith.constant 3.1415926535897931 : f64
    %3403 = qlx.apply #qlx.action<pauli_rotation>(%3402, %cst_2071) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3404 = qlx.apply #qlx.action<h>(%3403) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3405 = qlx.apply #qlx.action<h>(%3401#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2072 = arith.constant 3.1415926535897931 : f64
    %3406 = qlx.apply #qlx.action<pauli_rotation>(%3405, %cst_2072) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3407 = qlx.apply #qlx.action<h>(%3406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2073 = arith.constant 1.5707963267948966 : f64
    %3408:2 = qlx.apply #qlx.action<pauli_rotation>(%3404, %3407, %cst_2073) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2074 = arith.constant 1.5707963267948966 : f64
    %3409 = qlx.apply #qlx.action<pauli_rotation>(%3408#0, %cst_2074) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2075 = arith.constant 1.5707963267948966 : f64
    %3410 = qlx.apply #qlx.action<pauli_rotation>(%3408#1, %cst_2075) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2076 = arith.constant 1.5707963267948966 : f64
    %3411:2 = qlx.apply #qlx.action<pauli_rotation>(%3409, %3410, %cst_2076) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2077 = arith.constant 0.78539816339744828 : f64
    %3412 = qlx.apply #qlx.action<pauli_rotation>(%3348#0, %cst_2077) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3413 = qlx.apply #qlx.action<h>(%3412) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3414 = qlx.apply #qlx.action<h>(%3369#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2078 = arith.constant 2.3561944901923448 : f64
    %3415 = qlx.apply #qlx.action<pauli_rotation>(%3414, %cst_2078) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3416 = qlx.apply #qlx.action<h>(%3415) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2079 = arith.constant 0.78539816339744828 : f64
    %3417:2 = qlx.apply #qlx.action<pauli_rotation>(%3413, %3416, %cst_2079) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2080 = arith.constant 1.5707963267948966 : f64
    %3418 = qlx.apply #qlx.action<pauli_rotation>(%3417#0, %cst_2080) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2081 = arith.constant 1.5707963267948966 : f64
    %3419 = qlx.apply #qlx.action<pauli_rotation>(%3417#1, %cst_2081) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2082 = arith.constant 0.78539816339744828 : f64
    %3420:2 = qlx.apply #qlx.action<pauli_rotation>(%3418, %3419, %cst_2082) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3421 = qlx.apply #qlx.action<h>(%3391#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2083 = arith.constant 2.3561944901923448 : f64
    %3422 = qlx.apply #qlx.action<pauli_rotation>(%3421, %cst_2083) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3423 = qlx.apply #qlx.action<h>(%3422) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3424 = qlx.apply #qlx.action<h>(%3411#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2084 = arith.constant 2.3561944901923448 : f64
    %3425 = qlx.apply #qlx.action<pauli_rotation>(%3424, %cst_2084) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3426 = qlx.apply #qlx.action<h>(%3425) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2085 = arith.constant 0.78539816339744828 : f64
    %3427:2 = qlx.apply #qlx.action<pauli_rotation>(%3423, %3426, %cst_2085) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2086 = arith.constant 1.5707963267948966 : f64
    %3428 = qlx.apply #qlx.action<pauli_rotation>(%3427#0, %cst_2086) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2087 = arith.constant 1.5707963267948966 : f64
    %3429 = qlx.apply #qlx.action<pauli_rotation>(%3427#1, %cst_2087) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2088 = arith.constant 0.78539816339744828 : f64
    %3430:2 = qlx.apply #qlx.action<pauli_rotation>(%3428, %3429, %cst_2088) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3431 = qlx.apply #qlx.action<h>(%3420#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2089 = arith.constant 2.3561944901923448 : f64
    %3432 = qlx.apply #qlx.action<pauli_rotation>(%3431, %cst_2089) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3433 = qlx.apply #qlx.action<h>(%3432) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3434 = qlx.apply #qlx.action<h>(%3430#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2090 = arith.constant 0.78539816339744828 : f64
    %3435 = qlx.apply #qlx.action<pauli_rotation>(%3434, %cst_2090) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3436 = qlx.apply #qlx.action<h>(%3435) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2091 = arith.constant 1.250000e-01 : f64
    %3437:2 = qlx.apply #qlx.action<pauli_rotation>(%3433, %3436, %cst_2091) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2092 = arith.constant 1.5707963267948966 : f64
    %3438 = qlx.apply #qlx.action<pauli_rotation>(%3437#0, %cst_2092) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2093 = arith.constant 1.5707963267948966 : f64
    %3439 = qlx.apply #qlx.action<pauli_rotation>(%3437#1, %cst_2093) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2094 = arith.constant 1.250000e-01 : f64
    %3440:2 = qlx.apply #qlx.action<pauli_rotation>(%3438, %3439, %cst_2094) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3441 = qlx.apply #qlx.action<h>(%3420#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2095 = arith.constant 1.5707963267948966 : f64
    %3442 = qlx.apply #qlx.action<pauli_rotation>(%3441, %cst_2095) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3443 = qlx.apply #qlx.action<h>(%3442) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3444 = qlx.apply #qlx.action<h>(%3440#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2096 = arith.constant 0.78539816339744828 : f64
    %3445 = qlx.apply #qlx.action<pauli_rotation>(%3444, %cst_2096) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3446 = qlx.apply #qlx.action<h>(%3445) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2097 = arith.constant 0.78539816339744828 : f64
    %3447:2 = qlx.apply #qlx.action<pauli_rotation>(%3443, %3446, %cst_2097) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2098 = arith.constant 1.5707963267948966 : f64
    %3448 = qlx.apply #qlx.action<pauli_rotation>(%3447#0, %cst_2098) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2099 = arith.constant 1.5707963267948966 : f64
    %3449 = qlx.apply #qlx.action<pauli_rotation>(%3447#1, %cst_2099) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2100 = arith.constant 0.78539816339744828 : f64
    %3450:2 = qlx.apply #qlx.action<pauli_rotation>(%3448, %3449, %cst_2100) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3451 = qlx.apply #qlx.action<h>(%3411#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2101 = arith.constant 2.3561944901923448 : f64
    %3452 = qlx.apply #qlx.action<pauli_rotation>(%3451, %cst_2101) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3453 = qlx.apply #qlx.action<h>(%3452) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3454 = qlx.apply #qlx.action<h>(%3401#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2102 = arith.constant 2.3561944901923448 : f64
    %3455 = qlx.apply #qlx.action<pauli_rotation>(%3454, %cst_2102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3456 = qlx.apply #qlx.action<h>(%3455) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2103 = arith.constant 0.78539816339744828 : f64
    %3457:2 = qlx.apply #qlx.action<pauli_rotation>(%3453, %3456, %cst_2103) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2104 = arith.constant 1.5707963267948966 : f64
    %3458 = qlx.apply #qlx.action<pauli_rotation>(%3457#0, %cst_2104) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2105 = arith.constant 1.5707963267948966 : f64
    %3459 = qlx.apply #qlx.action<pauli_rotation>(%3457#1, %cst_2105) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2106 = arith.constant 0.78539816339744828 : f64
    %3460:2 = qlx.apply #qlx.action<pauli_rotation>(%3458, %3459, %cst_2106) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3461 = qlx.apply #qlx.action<h>(%3381#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2107 = arith.constant 2.3561944901923448 : f64
    %3462 = qlx.apply #qlx.action<pauli_rotation>(%3461, %cst_2107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3463 = qlx.apply #qlx.action<h>(%3462) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2108 = arith.constant 0.78539816339744828 : f64
    %3464 = qlx.apply #qlx.action<pauli_rotation>(%3363#1, %cst_2108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3465 = qlx.apply #qlx.action<h>(%3464) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2109 = arith.constant 0.78539816339744828 : f64
    %3466:2 = qlx.apply #qlx.action<pauli_rotation>(%3463, %3465, %cst_2109) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2110 = arith.constant 1.5707963267948966 : f64
    %3467 = qlx.apply #qlx.action<pauli_rotation>(%3466#0, %cst_2110) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2111 = arith.constant 1.5707963267948966 : f64
    %3468 = qlx.apply #qlx.action<pauli_rotation>(%3466#1, %cst_2111) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2112 = arith.constant 0.78539816339744828 : f64
    %3469:2 = qlx.apply #qlx.action<pauli_rotation>(%3467, %3468, %cst_2112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3470 = qlx.apply #qlx.action<h>(%3460#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2113 = arith.constant 2.3561944901923448 : f64
    %3471 = qlx.apply #qlx.action<pauli_rotation>(%3470, %cst_2113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3472 = qlx.apply #qlx.action<h>(%3471) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3473 = qlx.apply #qlx.action<h>(%3469#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2114 = arith.constant 0.78539816339744828 : f64
    %3474 = qlx.apply #qlx.action<pauli_rotation>(%3473, %cst_2114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3475 = qlx.apply #qlx.action<h>(%3474) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2115 = arith.constant 1.250000e-01 : f64
    %3476:2 = qlx.apply #qlx.action<pauli_rotation>(%3472, %3475, %cst_2115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2116 = arith.constant 1.5707963267948966 : f64
    %3477 = qlx.apply #qlx.action<pauli_rotation>(%3476#0, %cst_2116) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2117 = arith.constant 1.5707963267948966 : f64
    %3478 = qlx.apply #qlx.action<pauli_rotation>(%3476#1, %cst_2117) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2118 = arith.constant 1.250000e-01 : f64
    %3479:2 = qlx.apply #qlx.action<pauli_rotation>(%3477, %3478, %cst_2118) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3480 = qlx.apply #qlx.action<h>(%3460#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2119 = arith.constant 1.5707963267948966 : f64
    %3481 = qlx.apply #qlx.action<pauli_rotation>(%3480, %cst_2119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3482 = qlx.apply #qlx.action<h>(%3481) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3483 = qlx.apply #qlx.action<h>(%3479#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2120 = arith.constant 0.78539816339744828 : f64
    %3484 = qlx.apply #qlx.action<pauli_rotation>(%3483, %cst_2120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3485 = qlx.apply #qlx.action<h>(%3484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2121 = arith.constant 0.78539816339744828 : f64
    %3486:2 = qlx.apply #qlx.action<pauli_rotation>(%3482, %3485, %cst_2121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2122 = arith.constant 1.5707963267948966 : f64
    %3487 = qlx.apply #qlx.action<pauli_rotation>(%3486#0, %cst_2122) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2123 = arith.constant 1.5707963267948966 : f64
    %3488 = qlx.apply #qlx.action<pauli_rotation>(%3486#1, %cst_2123) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2124 = arith.constant 0.78539816339744828 : f64
    %3489:2 = qlx.apply #qlx.action<pauli_rotation>(%3487, %3488, %cst_2124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3490 = qlx.apply #qlx.action<h>(%3450#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2125 = arith.constant 2.3561944901923448 : f64
    %3491 = qlx.apply #qlx.action<pauli_rotation>(%3490, %cst_2125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3492 = qlx.apply #qlx.action<h>(%3450#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2126 = arith.constant 2.3561944901923448 : f64
    %3493 = qlx.apply #qlx.action<pauli_rotation>(%3492, %cst_2126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3494 = qlx.apply #qlx.action<h>(%3440#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2127 = arith.constant 3.1415926535897931 : f64
    %3495 = qlx.apply #qlx.action<pauli_rotation>(%3494, %cst_2127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3496 = qlx.apply #qlx.action<h>(%3430#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2128 = arith.constant 2.3561944901923448 : f64
    %3497 = qlx.apply #qlx.action<pauli_rotation>(%3496, %cst_2128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3498 = qlx.apply #qlx.action<h>(%3489#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2129 = arith.constant 2.3561944901923448 : f64
    %3499 = qlx.apply #qlx.action<pauli_rotation>(%3498, %cst_2129) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3500 = qlx.apply #qlx.action<h>(%3489#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2130 = arith.constant 2.3561944901923448 : f64
    %3501 = qlx.apply #qlx.action<pauli_rotation>(%3500, %cst_2130) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3502 = qlx.apply #qlx.action<h>(%3479#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2131 = arith.constant 3.1415926535897931 : f64
    %3503 = qlx.apply #qlx.action<pauli_rotation>(%3502, %cst_2131) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3504 = qlx.apply #qlx.action<h>(%3469#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2132 = arith.constant 2.3561944901923448 : f64
    %3505 = qlx.apply #qlx.action<pauli_rotation>(%3504, %cst_2132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3506 = qlx.measure <Z> %3491 : !qlx.logical_qubit -> i1
    %3507 = qlx.measure <Z> %3493 : !qlx.logical_qubit -> i1
    %3508 = qlx.measure <Z> %3495 : !qlx.logical_qubit -> i1
    %3509 = qlx.measure <Z> %3497 : !qlx.logical_qubit -> i1
    %3510 = qlx.measure <Z> %3499 : !qlx.logical_qubit -> i1
    %3511 = qlx.measure <Z> %3501 : !qlx.logical_qubit -> i1
    %3512 = qlx.measure <Z> %3503 : !qlx.logical_qubit -> i1
    %3513 = qlx.measure <Z> %3505 : !qlx.logical_qubit -> i1
  }
}
