module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @rotation : () -> (i1, i1) attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.apply #qlx.action<h>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 1 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %3 = qlx.apply #qlx.action<h>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.740000e-01 : f64
    %4 = qlx.apply #qlx.action<pauli_rotation>(%3, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %5:2 = qlx.apply #qlx.action<cx>(%1, %4) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %6 = qlx.measure <Z> %5#1 : !qlx.logical_qubit -> i1
    %7:2 = cflow.if %6 -> !qlx.logical_qubit, i1 {
      %10 = qlx.prepare "zero" {allocation = 2 : i64, value_index = 0 : i64} : !qlx.logical_qubit
      %11 = qlx.apply #qlx.action<h>(%10) : (!qlx.logical_qubit) -> !qlx.logical_qubit
      %cst_0 = arith.constant 5.480000e-01 : f64
      %12 = qlx.apply #qlx.action<pauli_rotation>(%11, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
      %13:2 = qlx.apply #qlx.action<cx>(%5#0, %12) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      %14 = qlx.measure <Z> %13#1 : !qlx.logical_qubit -> i1
      %15:2 = cflow.if %14 -> !qlx.logical_qubit, i1 {
        %16 = qlx.prepare "zero" {allocation = 3 : i64, value_index = 0 : i64} : !qlx.logical_qubit
        %17 = qlx.apply #qlx.action<h>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
        %cst_1 = arith.constant 1.096000e+00 : f64
        %18 = qlx.apply #qlx.action<pauli_rotation>(%17, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
        %19:2 = qlx.apply #qlx.action<cx>(%13#0, %18) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
        %20 = qlx.measure <Z> %19#1 : !qlx.logical_qubit -> i1
        %21:2 = cflow.if %20 -> !qlx.logical_qubit, i1 {
          %22 = qlx.prepare "zero" {allocation = 4 : i64, value_index = 0 : i64} : !qlx.logical_qubit
          %23 = qlx.apply #qlx.action<h>(%22) : (!qlx.logical_qubit) -> !qlx.logical_qubit
          %cst_2 = arith.constant 2.192000e+00 : f64
          %24 = qlx.apply #qlx.action<pauli_rotation>(%23, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
          %25:2 = qlx.apply #qlx.action<cx>(%19#0, %24) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
          %26 = qlx.measure <Z> %25#1 : !qlx.logical_qubit -> i1
          %27:2 = cflow.if %26 -> !qlx.logical_qubit, i1 {
            %28 = qlx.prepare "zero" {allocation = 5 : i64, value_index = 0 : i64} : !qlx.logical_qubit
            %29 = qlx.apply #qlx.action<h>(%28) : (!qlx.logical_qubit) -> !qlx.logical_qubit
            %cst_3 = arith.constant 4.384000e+00 : f64
            %30 = qlx.apply #qlx.action<pauli_rotation>(%29, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
            %31:2 = qlx.apply #qlx.action<cx>(%25#0, %30) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
            %32 = qlx.measure <Z> %31#1 : !qlx.logical_qubit -> i1
            %33:2 = cflow.if %32 -> !qlx.logical_qubit, i1 {
              %34 = qlx.prepare "zero" {allocation = 6 : i64, value_index = 0 : i64} : !qlx.logical_qubit
              %35 = qlx.apply #qlx.action<h>(%34) : (!qlx.logical_qubit) -> !qlx.logical_qubit
              %cst_4 = arith.constant 8.768000e+00 : f64
              %36 = qlx.apply #qlx.action<pauli_rotation>(%35, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
              %37:2 = qlx.apply #qlx.action<cx>(%31#0, %36) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
              %38 = qlx.measure <Z> %37#1 : !qlx.logical_qubit -> i1
              %39:2 = cflow.if %38 -> !qlx.logical_qubit, i1 {
                %40 = qlx.prepare "zero" {allocation = 7 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                %41 = qlx.apply #qlx.action<h>(%40) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                %cst_5 = arith.constant 1.753600e+01 : f64
                %42 = qlx.apply #qlx.action<pauli_rotation>(%41, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                %43:2 = qlx.apply #qlx.action<cx>(%37#0, %42) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                %44 = qlx.measure <Z> %43#1 : !qlx.logical_qubit -> i1
                %45:2 = cflow.if %44 -> !qlx.logical_qubit, i1 {
                  %46 = qlx.prepare "zero" {allocation = 8 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                  %47 = qlx.apply #qlx.action<h>(%46) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                  %cst_6 = arith.constant 3.507200e+01 : f64
                  %48 = qlx.apply #qlx.action<pauli_rotation>(%47, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                  %49:2 = qlx.apply #qlx.action<cx>(%43#0, %48) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                  %50 = qlx.measure <Z> %49#1 : !qlx.logical_qubit -> i1
                  %51:2 = cflow.if %50 -> !qlx.logical_qubit, i1 {
                    %52 = qlx.prepare "zero" {allocation = 9 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                    %53 = qlx.apply #qlx.action<h>(%52) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                    %cst_7 = arith.constant 7.014400e+01 : f64
                    %54 = qlx.apply #qlx.action<pauli_rotation>(%53, %cst_7) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                    %55:2 = qlx.apply #qlx.action<cx>(%49#0, %54) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                    %56 = qlx.measure <Z> %55#1 : !qlx.logical_qubit -> i1
                    %57:2 = cflow.if %56 -> !qlx.logical_qubit, i1 {
                      %58 = qlx.prepare "zero" {allocation = 10 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                      %59 = qlx.apply #qlx.action<h>(%58) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                      %cst_8 = arith.constant 1.402880e+02 : f64
                      %60 = qlx.apply #qlx.action<pauli_rotation>(%59, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                      %61:2 = qlx.apply #qlx.action<cx>(%55#0, %60) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                      %62 = qlx.measure <Z> %61#1 : !qlx.logical_qubit -> i1
                      %63:2 = cflow.if %62 -> !qlx.logical_qubit, i1 {
                        %64 = qlx.prepare "zero" {allocation = 11 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                        %65 = qlx.apply #qlx.action<h>(%64) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                        %cst_9 = arith.constant 2.805760e+02 : f64
                        %66 = qlx.apply #qlx.action<pauli_rotation>(%65, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                        %67:2 = qlx.apply #qlx.action<cx>(%61#0, %66) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                        %68 = qlx.measure <Z> %67#1 : !qlx.logical_qubit -> i1
                        %69:2 = cflow.if %68 -> !qlx.logical_qubit, i1 {
                          %70 = qlx.prepare "zero" {allocation = 12 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                          %71 = qlx.apply #qlx.action<h>(%70) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                          %cst_10 = arith.constant 5.611520e+02 : f64
                          %72 = qlx.apply #qlx.action<pauli_rotation>(%71, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                          %73:2 = qlx.apply #qlx.action<cx>(%67#0, %72) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                          %74 = qlx.measure <Z> %73#1 : !qlx.logical_qubit -> i1
                          %75:2 = cflow.if %74 -> !qlx.logical_qubit, i1 {
                            %76 = qlx.prepare "zero" {allocation = 13 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                            %77 = qlx.apply #qlx.action<h>(%76) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                            %cst_11 = arith.constant 1122.3040000000001 : f64
                            %78 = qlx.apply #qlx.action<pauli_rotation>(%77, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                            %79:2 = qlx.apply #qlx.action<cx>(%73#0, %78) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                            %80 = qlx.measure <Z> %79#1 : !qlx.logical_qubit -> i1
                            %81:2 = cflow.if %80 -> !qlx.logical_qubit, i1 {
                              %82 = qlx.prepare "zero" {allocation = 14 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                              %83 = qlx.apply #qlx.action<h>(%82) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                              %cst_12 = arith.constant 2244.6080000000002 : f64
                              %84 = qlx.apply #qlx.action<pauli_rotation>(%83, %cst_12) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                              %85:2 = qlx.apply #qlx.action<cx>(%79#0, %84) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                              %86 = qlx.measure <Z> %85#1 : !qlx.logical_qubit -> i1
                              %87:2 = cflow.if %86 -> !qlx.logical_qubit, i1 {
                                %88 = qlx.prepare "zero" {allocation = 15 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                %89 = qlx.apply #qlx.action<h>(%88) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                %cst_13 = arith.constant 4489.2160000000003 : f64
                                %90 = qlx.apply #qlx.action<pauli_rotation>(%89, %cst_13) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                %91:2 = qlx.apply #qlx.action<cx>(%85#0, %90) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                %92 = qlx.measure <Z> %91#1 : !qlx.logical_qubit -> i1
                                %93:2 = cflow.if %92 -> !qlx.logical_qubit, i1 {
                                  %94 = qlx.prepare "zero" {allocation = 16 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                  %95 = qlx.apply #qlx.action<h>(%94) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                  %cst_14 = arith.constant 8978.4320000000007 : f64
                                  %96 = qlx.apply #qlx.action<pauli_rotation>(%95, %cst_14) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                  %97:2 = qlx.apply #qlx.action<cx>(%91#0, %96) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                  %98 = qlx.measure <Z> %97#1 : !qlx.logical_qubit -> i1
                                  %99:2 = cflow.if %98 -> !qlx.logical_qubit, i1 {
                                    %100 = qlx.prepare "zero" {allocation = 17 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                    %101 = qlx.apply #qlx.action<h>(%100) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                    %cst_15 = arith.constant 17956.864000000001 : f64
                                    %102 = qlx.apply #qlx.action<pauli_rotation>(%101, %cst_15) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                    %103:2 = qlx.apply #qlx.action<cx>(%97#0, %102) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                    %104 = qlx.measure <Z> %103#1 : !qlx.logical_qubit -> i1
                                    %105:2 = cflow.if %104 -> !qlx.logical_qubit, i1 {
                                      %106 = qlx.prepare "zero" {allocation = 18 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                      %107 = qlx.apply #qlx.action<h>(%106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                      %cst_16 = arith.constant 35913.728000000003 : f64
                                      %108 = qlx.apply #qlx.action<pauli_rotation>(%107, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                      %109:2 = qlx.apply #qlx.action<cx>(%103#0, %108) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                      %110 = qlx.measure <Z> %109#1 : !qlx.logical_qubit -> i1
                                      %111:2 = cflow.if %110 -> !qlx.logical_qubit, i1 {
                                        %112 = qlx.prepare "zero" {allocation = 19 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                        %113 = qlx.apply #qlx.action<h>(%112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                        %cst_17 = arith.constant 71827.456000000006 : f64
                                        %114 = qlx.apply #qlx.action<pauli_rotation>(%113, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                        %115:2 = qlx.apply #qlx.action<cx>(%109#0, %114) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                        %116 = qlx.measure <Z> %115#1 : !qlx.logical_qubit -> i1
                                        %117:2 = cflow.if %116 -> !qlx.logical_qubit, i1 {
                                          %118 = qlx.prepare "zero" {allocation = 20 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                          %119 = qlx.apply #qlx.action<h>(%118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                          %cst_18 = arith.constant 143654.91200000001 : f64
                                          %120 = qlx.apply #qlx.action<pauli_rotation>(%119, %cst_18) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                          %121:2 = qlx.apply #qlx.action<cx>(%115#0, %120) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                          %122 = qlx.measure <Z> %121#1 : !qlx.logical_qubit -> i1
                                          %123:2 = cflow.if %122 -> !qlx.logical_qubit, i1 {
                                            %124 = qlx.prepare "zero" {allocation = 21 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                            %125 = qlx.apply #qlx.action<h>(%124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                            %cst_19 = arith.constant 287309.82400000002 : f64
                                            %126 = qlx.apply #qlx.action<pauli_rotation>(%125, %cst_19) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                            %127:2 = qlx.apply #qlx.action<cx>(%121#0, %126) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                            %128 = qlx.measure <Z> %127#1 : !qlx.logical_qubit -> i1
                                            %129:2 = cflow.if %128 -> !qlx.logical_qubit, i1 {
                                              %130 = qlx.prepare "zero" {allocation = 22 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                              %131 = qlx.apply #qlx.action<h>(%130) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                              %cst_20 = arith.constant 574619.64800000004 : f64
                                              %132 = qlx.apply #qlx.action<pauli_rotation>(%131, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                              %133:2 = qlx.apply #qlx.action<cx>(%127#0, %132) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                              %134 = qlx.measure <Z> %133#1 : !qlx.logical_qubit -> i1
                                              %135:2 = cflow.if %134 -> !qlx.logical_qubit, i1 {
                                                %136 = qlx.prepare "zero" {allocation = 23 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                                %137 = qlx.apply #qlx.action<h>(%136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                                %cst_21 = arith.constant 1149239.2960000001 : f64
                                                %138 = qlx.apply #qlx.action<pauli_rotation>(%137, %cst_21) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                                %139:2 = qlx.apply #qlx.action<cx>(%133#0, %138) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                                %140 = qlx.measure <Z> %139#1 : !qlx.logical_qubit -> i1
                                                %141:2 = cflow.if %140 -> !qlx.logical_qubit, i1 {
                                                  %142 = qlx.prepare "zero" {allocation = 24 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                                                  %143 = qlx.apply #qlx.action<h>(%142) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                                                  %cst_22 = arith.constant 2298478.5920000002 : f64
                                                  %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_22) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                                                  %145:2 = qlx.apply #qlx.action<cx>(%139#0, %144) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                                                  %146 = qlx.measure <Z> %145#1 : !qlx.logical_qubit -> i1
                                                  cflow.yield %145#0, %146 : !qlx.logical_qubit, i1
                                                } else {
                                                  cflow.yield %139#0, %140 : !qlx.logical_qubit, i1
                                                }
                                                cflow.yield %141#0, %141#1 : !qlx.logical_qubit, i1
                                              } else {
                                                cflow.yield %133#0, %134 : !qlx.logical_qubit, i1
                                              }
                                              cflow.yield %135#0, %135#1 : !qlx.logical_qubit, i1
                                            } else {
                                              cflow.yield %127#0, %128 : !qlx.logical_qubit, i1
                                            }
                                            cflow.yield %129#0, %129#1 : !qlx.logical_qubit, i1
                                          } else {
                                            cflow.yield %121#0, %122 : !qlx.logical_qubit, i1
                                          }
                                          cflow.yield %123#0, %123#1 : !qlx.logical_qubit, i1
                                        } else {
                                          cflow.yield %115#0, %116 : !qlx.logical_qubit, i1
                                        }
                                        cflow.yield %117#0, %117#1 : !qlx.logical_qubit, i1
                                      } else {
                                        cflow.yield %109#0, %110 : !qlx.logical_qubit, i1
                                      }
                                      cflow.yield %111#0, %111#1 : !qlx.logical_qubit, i1
                                    } else {
                                      cflow.yield %103#0, %104 : !qlx.logical_qubit, i1
                                    }
                                    cflow.yield %105#0, %105#1 : !qlx.logical_qubit, i1
                                  } else {
                                    cflow.yield %97#0, %98 : !qlx.logical_qubit, i1
                                  }
                                  cflow.yield %99#0, %99#1 : !qlx.logical_qubit, i1
                                } else {
                                  cflow.yield %91#0, %92 : !qlx.logical_qubit, i1
                                }
                                cflow.yield %93#0, %93#1 : !qlx.logical_qubit, i1
                              } else {
                                cflow.yield %85#0, %86 : !qlx.logical_qubit, i1
                              }
                              cflow.yield %87#0, %87#1 : !qlx.logical_qubit, i1
                            } else {
                              cflow.yield %79#0, %80 : !qlx.logical_qubit, i1
                            }
                            cflow.yield %81#0, %81#1 : !qlx.logical_qubit, i1
                          } else {
                            cflow.yield %73#0, %74 : !qlx.logical_qubit, i1
                          }
                          cflow.yield %75#0, %75#1 : !qlx.logical_qubit, i1
                        } else {
                          cflow.yield %67#0, %68 : !qlx.logical_qubit, i1
                        }
                        cflow.yield %69#0, %69#1 : !qlx.logical_qubit, i1
                      } else {
                        cflow.yield %61#0, %62 : !qlx.logical_qubit, i1
                      }
                      cflow.yield %63#0, %63#1 : !qlx.logical_qubit, i1
                    } else {
                      cflow.yield %55#0, %56 : !qlx.logical_qubit, i1
                    }
                    cflow.yield %57#0, %57#1 : !qlx.logical_qubit, i1
                  } else {
                    cflow.yield %49#0, %50 : !qlx.logical_qubit, i1
                  }
                  cflow.yield %51#0, %51#1 : !qlx.logical_qubit, i1
                } else {
                  cflow.yield %43#0, %44 : !qlx.logical_qubit, i1
                }
                cflow.yield %45#0, %45#1 : !qlx.logical_qubit, i1
              } else {
                cflow.yield %37#0, %38 : !qlx.logical_qubit, i1
              }
              cflow.yield %39#0, %39#1 : !qlx.logical_qubit, i1
            } else {
              cflow.yield %31#0, %32 : !qlx.logical_qubit, i1
            }
            cflow.yield %33#0, %33#1 : !qlx.logical_qubit, i1
          } else {
            cflow.yield %25#0, %26 : !qlx.logical_qubit, i1
          }
          cflow.yield %27#0, %27#1 : !qlx.logical_qubit, i1
        } else {
          cflow.yield %19#0, %20 : !qlx.logical_qubit, i1
        }
        cflow.yield %21#0, %21#1 : !qlx.logical_qubit, i1
      } else {
        cflow.yield %13#0, %14 : !qlx.logical_qubit, i1
      }
      cflow.yield %15#0, %15#1 : !qlx.logical_qubit, i1
    } else {
      cflow.yield %5#0, %6 : !qlx.logical_qubit, i1
    }
    %8 = qlx.apply #qlx.action<h>(%7#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.measure <Z> %8 : !qlx.logical_qubit -> i1
    qlx.return %9, %7#1 : i1, i1
  }
}
