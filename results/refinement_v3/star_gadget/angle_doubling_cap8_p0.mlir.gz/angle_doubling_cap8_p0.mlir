module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @rotation : () -> (i1, i1) attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.apply #qlx.action<h>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 1 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %3 = qlx.apply #qlx.action<h>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.740000e-01 : f64
    %4 = qlx.apply #qlx.action<pauli_rotation>(%3, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %5:2 = qlx.apply #qlx.action<cx>(%1, %4) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %6 = qlx.measure <Z> %5#1 : !qlx.logical_qubit -> i1
    %7:2 = cflow.if %6 -> !qlx.logical_qubit, i1 {
      %10 = qlx.prepare "zero" {allocation = 2 : i64, value_index = 0 : i64} : !qlx.logical_qubit
      %11 = qlx.apply #qlx.action<h>(%10) : (!qlx.logical_qubit) -> !qlx.logical_qubit
      %cst_0 = arith.constant 5.480000e-01 : f64
      %12 = qlx.apply #qlx.action<pauli_rotation>(%11, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
      %13:2 = qlx.apply #qlx.action<cx>(%5#0, %12) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
      %14 = qlx.measure <Z> %13#1 : !qlx.logical_qubit -> i1
      %15:2 = cflow.if %14 -> !qlx.logical_qubit, i1 {
        %16 = qlx.prepare "zero" {allocation = 3 : i64, value_index = 0 : i64} : !qlx.logical_qubit
        %17 = qlx.apply #qlx.action<h>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
        %cst_1 = arith.constant 1.096000e+00 : f64
        %18 = qlx.apply #qlx.action<pauli_rotation>(%17, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
        %19:2 = qlx.apply #qlx.action<cx>(%13#0, %18) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
        %20 = qlx.measure <Z> %19#1 : !qlx.logical_qubit -> i1
        %21:2 = cflow.if %20 -> !qlx.logical_qubit, i1 {
          %22 = qlx.prepare "zero" {allocation = 4 : i64, value_index = 0 : i64} : !qlx.logical_qubit
          %23 = qlx.apply #qlx.action<h>(%22) : (!qlx.logical_qubit) -> !qlx.logical_qubit
          %cst_2 = arith.constant 2.192000e+00 : f64
          %24 = qlx.apply #qlx.action<pauli_rotation>(%23, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
          %25:2 = qlx.apply #qlx.action<cx>(%19#0, %24) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
          %26 = qlx.measure <Z> %25#1 : !qlx.logical_qubit -> i1
          %27:2 = cflow.if %26 -> !qlx.logical_qubit, i1 {
            %28 = qlx.prepare "zero" {allocation = 5 : i64, value_index = 0 : i64} : !qlx.logical_qubit
            %29 = qlx.apply #qlx.action<h>(%28) : (!qlx.logical_qubit) -> !qlx.logical_qubit
            %cst_3 = arith.constant 4.384000e+00 : f64
            %30 = qlx.apply #qlx.action<pauli_rotation>(%29, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
            %31:2 = qlx.apply #qlx.action<cx>(%25#0, %30) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
            %32 = qlx.measure <Z> %31#1 : !qlx.logical_qubit -> i1
            %33:2 = cflow.if %32 -> !qlx.logical_qubit, i1 {
              %34 = qlx.prepare "zero" {allocation = 6 : i64, value_index = 0 : i64} : !qlx.logical_qubit
              %35 = qlx.apply #qlx.action<h>(%34) : (!qlx.logical_qubit) -> !qlx.logical_qubit
              %cst_4 = arith.constant 8.768000e+00 : f64
              %36 = qlx.apply #qlx.action<pauli_rotation>(%35, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
              %37:2 = qlx.apply #qlx.action<cx>(%31#0, %36) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
              %38 = qlx.measure <Z> %37#1 : !qlx.logical_qubit -> i1
              %39:2 = cflow.if %38 -> !qlx.logical_qubit, i1 {
                %40 = qlx.prepare "zero" {allocation = 7 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                %41 = qlx.apply #qlx.action<h>(%40) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                %cst_5 = arith.constant 1.753600e+01 : f64
                %42 = qlx.apply #qlx.action<pauli_rotation>(%41, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                %43:2 = qlx.apply #qlx.action<cx>(%37#0, %42) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                %44 = qlx.measure <Z> %43#1 : !qlx.logical_qubit -> i1
                %45:2 = cflow.if %44 -> !qlx.logical_qubit, i1 {
                  %46 = qlx.prepare "zero" {allocation = 8 : i64, value_index = 0 : i64} : !qlx.logical_qubit
                  %47 = qlx.apply #qlx.action<h>(%46) : (!qlx.logical_qubit) -> !qlx.logical_qubit
                  %cst_6 = arith.constant 3.507200e+01 : f64
                  %48 = qlx.apply #qlx.action<pauli_rotation>(%47, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
                  %49:2 = qlx.apply #qlx.action<cx>(%43#0, %48) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
                  %50 = qlx.measure <Z> %49#1 : !qlx.logical_qubit -> i1
                  cflow.yield %49#0, %50 : !qlx.logical_qubit, i1
                } else {
                  cflow.yield %43#0, %44 : !qlx.logical_qubit, i1
                }
                cflow.yield %45#0, %45#1 : !qlx.logical_qubit, i1
              } else {
                cflow.yield %37#0, %38 : !qlx.logical_qubit, i1
              }
              cflow.yield %39#0, %39#1 : !qlx.logical_qubit, i1
            } else {
              cflow.yield %31#0, %32 : !qlx.logical_qubit, i1
            }
            cflow.yield %33#0, %33#1 : !qlx.logical_qubit, i1
          } else {
            cflow.yield %25#0, %26 : !qlx.logical_qubit, i1
          }
          cflow.yield %27#0, %27#1 : !qlx.logical_qubit, i1
        } else {
          cflow.yield %19#0, %20 : !qlx.logical_qubit, i1
        }
        cflow.yield %21#0, %21#1 : !qlx.logical_qubit, i1
      } else {
        cflow.yield %13#0, %14 : !qlx.logical_qubit, i1
      }
      cflow.yield %15#0, %15#1 : !qlx.logical_qubit, i1
    } else {
      cflow.yield %5#0, %6 : !qlx.logical_qubit, i1
    }
    %8 = qlx.apply #qlx.action<h>(%7#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.measure <Z> %8 : !qlx.logical_qubit -> i1
    qlx.return %9, %7#1 : i1, i1
  }
}
