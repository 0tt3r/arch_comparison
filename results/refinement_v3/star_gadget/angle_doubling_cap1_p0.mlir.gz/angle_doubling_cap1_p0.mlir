module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @rotation : () -> (i1, i1) attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.apply #qlx.action<h>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 1 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %3 = qlx.apply #qlx.action<h>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.740000e-01 : f64
    %4 = qlx.apply #qlx.action<pauli_rotation>(%3, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %5:2 = qlx.apply #qlx.action<cx>(%1, %4) : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %6 = qlx.measure <Z> %5#1 : !qlx.logical_qubit -> i1
    %7 = qlx.apply #qlx.action<h>(%5#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %8 = qlx.measure <Z> %7 : !qlx.logical_qubit -> i1
    qlx.return %8, %6 : i1, i1
  }
}
