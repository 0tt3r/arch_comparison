"""JSON configuration: every benchmark / architecture knob can be overridden from a file."""
from __future__ import annotations
import json
from .benchmarks import BENCHMARKS, HubbardBenchmark
from .costmodel import AnalyticHubbardCostModel, QualtranHubbardCostModel
from .architectures import (NISQArchitecture, FTQCArchitecture, STARArchitecture, WalkingCatArchitecture, BBCodeArchitecture, Factory)

ARCHS = {"nisq": NISQArchitecture, "ftqc": FTQCArchitecture, "star": STARArchitecture,
         "walking_cat": WalkingCatArchitecture, "ftqc_bb": BBCodeArchitecture}
COST_MODELS = {"analytic-fswap": AnalyticHubbardCostModel, "qualtran": QualtranHubbardCostModel}


def default_architectures():
    n = NISQArchitecture().to_dict()
    return [n,
            {**n, "name": "NISQ (p2=1e-4, optimistic)", "p2": 1e-4, "p1": 1e-5, "T2_s": 1e-3},
            STARArchitecture().to_dict(), FTQCArchitecture().to_dict()]


def default_config():
    return {"benchmarks": [{"kind": "hubbard"}],
            "grid": {"n_min": 10, "n_max": 1e8, "points": 80},
            "architectures": default_architectures()}


def build_arch(d):
    d = dict(d); kind = d.pop("kind")
    if d.get("factories") and isinstance(d["factories"][0], dict):
        d["factories"] = [Factory(**f) for f in d["factories"]]
    return ARCHS[kind](**d)


def build_benchmark(d):
    d = dict(d); kind = d.pop("kind")
    if kind == "hubbard" and "cost_model" in d:
        cm = d.pop("cost_model")
        if isinstance(cm, str):
            cm = {"name": cm}
        cm = dict(cm); d["cost_model"] = COST_MODELS[cm.pop("name")](**cm)
    return BENCHMARKS[kind](**d)


def load_config(path):
    with open(path) as f:
        cfg = json.load(f)
    base = default_config()
    benches = [build_benchmark(b) for b in cfg.get("benchmarks", base["benchmarks"])]
    grid = {**base["grid"], **cfg.get("grid", {})}
    archs = [build_arch(a) for a in cfg.get("architectures", base["architectures"])]
    return benches, grid, archs, cfg.get("title")


def dump_default(path):
    cfg = default_config()
    cfg["benchmarks"] = [b().to_dict() for b in BENCHMARKS.values()]
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2, default=lambda o: getattr(o, "__dict__", str(o)))
