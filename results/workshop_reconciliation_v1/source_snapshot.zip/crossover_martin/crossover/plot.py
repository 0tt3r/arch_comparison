"""Plotting: computational power (solvable problem size) vs physical qubit count."""
from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

COLORS = {"nisq": "#d62728", "star": "#ff9f1c", "ftqc": "#1f77b4", "walking_cat": "#2ca02c", "ftqc_bb": "#9467bd"}
STYLES = ["-", "--", "-.", ":"]


def plot_crossover(sweeps, bench, title=None, out="crossover.png", annotate=True, log_y=True, ax=None):
    own = ax is None
    if own:
        fig, ax = plt.subplots(figsize=(9.5, 6))
    seen = {}
    for sw, arch in sweeps:
        y = sw.problem_size.astype(float).copy()
        y[y == 0] = np.nan
        k = seen.get(arch.kind, 0); seen[arch.kind] = k + 1
        ax.plot(sw.n_phys, y, STYLES[k % len(STYLES)], marker="o", ms=3, lw=2,
                color=COLORS.get(arch.kind), label=arch.name)
    ax.set_xscale("log")
    if log_y:
        ax.set_yscale("log")
    ax.set_xlabel("physical qubits  $n$")
    ax.set_ylabel(bench.ylabel)
    ax.grid(True, which="both", alpha=0.3)
    if title is None:
        title = f"{bench.name}  (budget {bench.time_budget_s/86400:.0f} days)"
    ax.set_title(title, fontsize=11)
    if annotate:
        from .estimate import Estimator
        nisq = [sw for sw, a in sweeps if a.kind == "nisq"]
        if nisq:
            best = max(nisq, key=lambda s: s.problem_size.max())
            ylo, yhi = ax.get_ylim()
            j = 0
            for sw, a in sweeps:
                if a.kind in ("star", "ftqc", "walking_cat", "ftqc_bb"):
                    for n, msg in Estimator.crossovers(best, sw):
                        if "overtakes" in msg:
                            ax.axvline(n, ls="--", lw=1, color=COLORS[a.kind], alpha=0.7)
                            ax.annotate(f"{a.name.split(' (')[0]} ≥ NISQ\n@ n ≈ {n:,}", (n * 1.15, ylo * 1.6 ** (1 + 2 * j)),
                                        fontsize=8, color=COLORS[a.kind], ha="left")
                            j += 1
                            break
    ax.legend(loc="upper left", fontsize=8)
    if own:
        fig.tight_layout(); fig.savefig(out, dpi=150)
    return out


def plot_panel(results, out="crossover_panel.png", suptitle=None):
    """results: list of (bench, sweeps) -> one subplot each."""
    n = len(results)
    cols = 2 if n > 1 else 1
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(8 * cols, 5.2 * rows), squeeze=False)
    for ax, (bench, sweeps) in zip(axes.flat, results):
        plot_crossover(sweeps, bench, ax=ax)
    for ax in list(axes.flat)[n:]:
        ax.axis("off")
    if suptitle:
        fig.suptitle(suptitle, fontsize=14, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.97) if suptitle else None); fig.savefig(out, dpi=140)
    return out
