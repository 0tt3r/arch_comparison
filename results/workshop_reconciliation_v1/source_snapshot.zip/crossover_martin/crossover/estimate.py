"""Sweep n_phys for each architecture; collect the largest solvable problem size."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

from .benchmarks.base import Benchmark
from .architectures import Architecture


@dataclass
class SweepResult:
    arch_name: str
    n_phys: np.ndarray
    problem_size: np.ndarray       # 0 if nothing solvable
    size_param: np.ndarray
    details: list


@dataclass
class Estimator:
    bench: Benchmark

    def sweep(self, arch: Architecture, n_phys_grid) -> SweepResult:
        ps, sp, det = [], [], []
        for n in n_phys_grid:
            o = self.bench.evaluate(arch, int(n))
            ps.append(o.problem_size); sp.append(o.size_param); det.append(o.details)
        return SweepResult(arch.name, np.array(n_phys_grid), np.array(ps, float), np.array(sp), det)

    @staticmethod
    def default_grid(n_min=10, n_max=1e8, points=80):
        return np.unique(np.logspace(np.log10(n_min), np.log10(n_max), points).astype(int))

    @staticmethod
    def crossovers(a: SweepResult, b: SweepResult):
        """n_phys where b first meets/exceeds a (and vice versa)."""
        out, prev = [], None
        for n, xa, xb in zip(a.n_phys, a.problem_size, b.problem_size):
            cur = None if (xa == 0 and xb == 0) else (xb >= xa)
            if prev is not None and cur is not None and cur != prev:
                out.append((int(n), f"{b.arch_name} {'overtakes' if cur else 'falls below'} {a.arch_name}"))
            if cur is not None:
                prev = cur
        return out
