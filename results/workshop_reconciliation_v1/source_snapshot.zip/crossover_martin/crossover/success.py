"""
Success models: turn an architecture's circuit polarization F and per-shot time into a
required shot count and a feasibility verdict.  Each benchmark owns one of these.

  ExpectationValue   estimate <O> (|O|<=1) to additive eps; optional 1/F^2 error mitigation
  Needle             sample one specific n-bit string with confidence c (TTS_c of IonQ paper)
  Polarization       run circuits whose mean polarization must be >= alpha (QUOPS / XEB-type)
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math


@dataclass
class ExpectationValue:
    eps: float = 0.1
    stat_frac: float = 0.25          # share of eps for shot noise
    hw_frac: float = 0.5             # share of eps for hardware-induced bias (sets FTQC/STAR target)
    z_score: float = 2.0
    mitigation: str = "rescale"      # "rescale" (ZNE/PEC-type, shots x 1/F^2) | "none"
    mitigation_const: float = 1.0
    min_fidelity: float = 1e-6       # below this no mitigation is meaningful

    def infidelity_target(self) -> float:
        return self.hw_frac * self.eps

    def shots(self, F: float, n_bits: int):
        base = (self.z_score / (self.stat_frac * self.eps)) ** 2
        if self.mitigation == "none":
            if 1 - F > self.infidelity_target():
                return None, "unmitigated bias exceeds budget"
            return base, None
        if F < self.min_fidelity:
            return None, "fidelity below mitigation floor"
        return base * self.mitigation_const / F ** 2, None

    def to_dict(self): return {"kind": "expectation", **asdict(self)}


@dataclass
class Needle:
    confidence: float = 0.99
    min_success: float = 1e-9        # q below this: hopeless

    def infidelity_target(self) -> float:
        return 0.5                   # any O(1) polarization suffices for a needle problem

    def shots(self, F: float, n_bits: int):
        q = F + (1 - F) * 2.0 ** (-n_bits)      # P(sample the correct string) under global depolarizing
        if q < self.min_success:
            return None, "per-shot success probability too small"
        return math.log(1 - self.confidence) / math.log(1 - q), None

    def to_dict(self): return {"kind": "needle", **asdict(self)}


@dataclass
class Polarization:
    alpha: float = 1 / math.sqrt(math.e)    # QUOPS standard threshold ~0.607
    n_samples: float = 1000                 # circuit executions the task needs
    mitigation_overhead: bool = True        # x 1/F^2 when alpha < 1/sqrt(e) (QUOPS error-mitigated regions)

    def infidelity_target(self) -> float:
        return 1 - self.alpha

    def shots(self, F: float, n_bits: int):
        if F < self.alpha:
            return None, f"polarization {F:.3g} below threshold {self.alpha:.3g}"
        over = 1.0 / F ** 2 if (self.mitigation_overhead and self.alpha < 1 / math.sqrt(math.e)) else 1.0
        return self.n_samples * over, None

    def to_dict(self): return {"kind": "polarization", **asdict(self)}


SUCCESS_MODELS = {"expectation": ExpectationValue, "needle": Needle, "polarization": Polarization}
