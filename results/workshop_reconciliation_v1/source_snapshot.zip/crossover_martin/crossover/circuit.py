"""Architecture-independent description of a benchmark circuit (one execution / shot)."""
from __future__ import annotations
from dataclasses import dataclass, asdict


@dataclass
class CircuitSpec:
    n_logical: int             # qubits the algorithm needs (before encoding / layout)
    gates_2q_local: int = 0    # 2q Clifford gates between neighbours (already routed to a NN grid)
    gates_2q_nonlocal: int = 0 # 2q Clifford gates between arbitrary pairs (need routing on NN hardware)
    gates_1q: int = 0          # 1q gates (Clifford or rotation), NISQ view
    depth: int = 0             # total layers (NISQ-compiled, local gates)
    rotations: int = 0         # arbitrary-angle Pauli rotations (need synthesis on FTQC, analog on STAR)
    rotation_layers: int = 0   # sequential layers of rotations
    t_gates: int = 0           # fixed T gates (incl. Toffolis decomposed into T); no synthesis
    t_layers: int = 0          # sequential layers of those
    toffolis: int = 0          # Toffoli/CCZ count (subset of t_gates; consumed directly by CCZ factories)
    toffoli_layers: int = 0
    t_per_toffoli: int = 4     # how t_gates counted each Toffoli
    ancillas: int = 0          # extra work qubits (e.g. Toffoli v-chain)
    measured_qubits: int = -1  # qubits read out at the end (-1: all n_logical)

    def to_dict(self):
        return asdict(self)

    @property
    def n_measured(self) -> int:
        return self.n_logical if self.measured_qubits < 0 else self.measured_qubits

    @property
    def clifford_depth(self) -> int:
        return max(0, self.depth - self.rotation_layers - self.t_layers)
