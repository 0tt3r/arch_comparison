"""
Architecture models (ingredient 2).  Each architecture implements

    execute(spec: CircuitSpec, n_phys: int, infidelity_target: float) -> ExecResult | None

i.e. "how faithfully (polarization F) and how fast (t_shot, parallel copies) can this machine
run one shot of this circuit on n_phys physical qubits", where infidelity_target is the
largest 1-F the benchmark can tolerate (used by FTQC/STAR to pick code distance / factories).
Turning F and t_shot into shots and a pass/fail verdict is the benchmark's job (success.py).

NISQ  : bare qubits, depolarising gate noise, idle/T2, SWAP routing for non-local gates.
FTQC  : surface code, Ross–Selinger synthesis of rotations, Litinski factories, lattice-surgery
        Cliffords; p_L = A (p/p_th)^((d+1)/2) per patch per cycle (Fowler et al. 2012).
STAR  : Akahoshi et al., PRX Quantum 5, 010337 (2024): error-corrected Cliffords at small d,
        analog rotations (incl. T/Toffoli angles) with error O(p) each, no factories.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional
import math

from .circuit import CircuitSpec
from .costmodel import t_count_per_rotation


@dataclass
class ExecResult:
    F: float                    # circuit polarization / global-depolarizing fidelity
    t_shot_s: float             # wall-clock per shot (one copy)
    copies: int                 # independent copies run in parallel on spare qubits
    qubits_used: int
    details: dict = field(default_factory=dict)


class Architecture:
    name: str = "base"
    kind: str = "base"

    def execute(self, spec: CircuitSpec, n_phys: int, infidelity_target: float) -> Optional[ExecResult]:
        raise NotImplementedError

    def to_dict(self):
        d = asdict(self)
        d["kind"] = self.kind
        return d


def _routing(connectivity: str, n_logical: int, swap_gates: int, c_route: float):
    """Extra 2q gates per non-local 2q gate: SWAP chain of average length ~ c_route*sqrt(n) on a grid."""
    if connectivity == "all_to_all":
        return 0.0
    if connectivity == "grid":
        return swap_gates * c_route * math.sqrt(n_logical)
    if connectivity == "line":
        return swap_gates * c_route * n_logical
    raise ValueError(connectivity)


# ----------------------------------------------------------------------------------------
# NISQ
# ----------------------------------------------------------------------------------------
@dataclass
class NISQArchitecture(Architecture):
    name: str = "NISQ (superconducting)"
    kind: str = "nisq"
    p2: float = 1e-3
    p1: float = 1e-4
    p_meas: float = 1e-2             # readout error per measured qubit
    t_2q_s: float = 40e-9
    t_1q_s: float = 20e-9
    t_readout_s: float = 1e-6
    T2_s: float = 100e-6
    connectivity: str = "grid"       # "grid" | "line" | "all_to_all"
    swap_gates: int = 3              # native 2q gates per SWAP
    c_route: float = 0.5             # mean SWAP-chain length in units of sqrt(n) (grid) / n (line)
    layout_overhead: float = 1.0
    parallel_copies: bool = True

    def execute(self, spec, n_phys, infidelity_target):
        N = spec.n_logical + spec.ancillas
        q = math.ceil(N * self.layout_overhead)
        if q > n_phys:
            return None
        copies = max(1, n_phys // q) if self.parallel_copies else 1
        extra = _routing(self.connectivity, N, self.swap_gates, self.c_route)
        g2 = spec.gates_2q_local + spec.gates_2q_nonlocal * (1 + extra)
        g1 = spec.gates_1q
        depth = spec.depth + spec.gates_2q_nonlocal * extra / max(1, N / 2)   # routed layers, roughly parallel
        t_layer = self.t_2q_s + self.t_1q_s
        idle = N * depth * t_layer / self.T2_s
        n_meas = max(1, spec.n_measured)
        F = math.exp(-(g2 * self.p2 + g1 * self.p1 + idle + n_meas * self.p_meas))
        t_shot = depth * t_layer + self.t_readout_s
        return ExecResult(F, t_shot, copies, q, {"gates_2q": g2, "depth": depth, "idle_err": idle})


# ----------------------------------------------------------------------------------------
# FTQC
# ----------------------------------------------------------------------------------------
@dataclass
class Factory:
    """Magic-state factory (Litinski, Quantum 3, 128 (2019) numbers at p_ref = 1e-3)."""
    name: str
    qubits: int
    cycles_per_T: float
    output_error: float
    level: int = 1
    p_ref: float = 1e-3

    def error_at(self, p):
        return self.output_error * (p / self.p_ref) ** (3 ** self.level)


DEFAULT_FACTORIES = [
    Factory("15-to-1 (7,3,3)", 810, 18.1, 4.4e-8, 1),
    Factory("15-to-1 (9,3,3)", 1150, 18.1, 9.3e-10, 1),
    Factory("15-to-1 (11,5,5)", 2070, 30.0, 1.9e-11, 1),
    Factory("15-to-1x20-to-4 (9,3,3)x(15,7,9)", 16400, 90.3, 2.4e-15, 2),
    Factory("15-to-1x15-to-1 (9,5,5)x(21,9,11)", 30700, 82.5, 6.3e-25, 2),
]


@dataclass
class FTQCArchitecture(Architecture):
    name: str = "FTQC (surface code)"
    kind: str = "ftqc"
    p: float = 1e-3
    p_th: float = 1e-2
    A: float = 0.1
    t_cycle_s: float = 1e-6
    phys_per_logical: float = 2.0
    logical_overhead: float = 1.5           # routing / ancilla patches relative to data patches
    cycles_per_T_consumption: float = 1.0   # code cycles per T gate on a patch, in units of d
    cycles_per_clifford_layer: float = 1.0  # lattice-surgery CNOT layer, in units of d
    synth_prefactor: float = 3.0
    synth_const: float = 0.0
    synth_frac: float = 0.4                 # split of the infidelity target
    logical_frac: float = 0.3
    T_frac: float = 0.3
    d_max: int = 61
    factories: list = field(default_factory=lambda: list(DEFAULT_FACTORIES))
    parallel_copies: bool = True

    def _pL(self, d):
        return self.A * (self.p / self.p_th) ** ((d + 1) / 2)

    def execute(self, spec, n_phys, target):
        N_log = math.ceil((spec.n_logical + spec.ancillas) * self.logical_overhead)
        # --- non-Clifford compilation -------------------------------------------------
        if spec.rotations > 0:
            eps_synth = self.synth_frac * target / spec.rotations
            t_rot = t_count_per_rotation(eps_synth, self.synth_prefactor, self.synth_const)
            synth_err = spec.rotations * eps_synth
        else:
            t_rot, synth_err = 0, 0.0
        T_count = spec.rotations * t_rot + spec.t_gates
        T_layers = spec.rotation_layers * t_rot + spec.t_layers
        if T_count > 0:
            eps_T = self.T_frac * target / T_count
            facs = [f for f in self.factories if f.error_at(self.p) <= eps_T]
            if not facs:
                return None
        else:
            facs = [None]
        best = None
        for d in range(3, self.d_max + 1, 2):
            q_data = math.ceil(N_log * self.phys_per_logical * d * d)
            if q_data > n_phys:
                break
            cycles_logic = d * (T_layers * self.cycles_per_T_consumption
                                + spec.clifford_depth * self.cycles_per_clifford_layer)
            cycles_logic = max(cycles_logic, d)          # at least one round of QEC
            logical_err = N_log * cycles_logic * self._pL(d)
            if logical_err > self.logical_frac * target:
                continue
            for fac in facs:
                fq = fac.qubits if fac else 0
                per_copy = q_data + fq
                if per_copy > n_phys:
                    continue
                max_copies = n_phys // per_copy if self.parallel_copies else 1
                cands = {1, max_copies}
                c = 1
                while c < max_copies:
                    c *= 2; cands.add(min(c, max_copies))
                for copies in cands:
                    if fac:
                        n_fac = max(1, (n_phys // copies - q_data) // fq)
                        cycles_fac = T_count * fac.cycles_per_T / n_fac
                        T_err = T_count * fac.error_at(self.p)
                    else:
                        n_fac, cycles_fac, T_err = 0, 0.0, 0.0
                    cycles = max(cycles_logic, cycles_fac)
                    t_shot = cycles * self.t_cycle_s
                    score = t_shot / copies
                    if best is None or score < best[0]:
                        F = math.exp(-(logical_err + T_err + synth_err))
                        best = (score, ExecResult(F, t_shot, copies, copies * (q_data + n_fac * fq), {
                            "d": d, "factory": fac.name if fac else None, "n_factories": n_fac,
                            "T_count": T_count, "T_per_rotation": t_rot, "cycles_logic": cycles_logic,
                            "cycles_factory": cycles_fac, "logical_err": logical_err, "T_err": T_err,
                            "synth_err": synth_err, "n_logical_patches": N_log}))
        return best[1] if best else None


# ----------------------------------------------------------------------------------------
# STAR
# ----------------------------------------------------------------------------------------
@dataclass
class STARArchitecture(Architecture):
    name: str = "STAR (analog rotations)"
    kind: str = "star"
    p: float = 1e-3
    p_th: float = 1e-2
    A: float = 0.1
    t_cycle_s: float = 1e-6
    phys_per_logical: float = 2.0
    logical_overhead: float = 2.0
    rotation_error_coeff: float = 0.2      # error per analog rotation ~ coeff * p (O(p), Akahoshi et al.)
    cycles_per_rotation: float = 2.0       # expected RUS cycles per rotation, in units of d
    cycles_per_clifford_layer: float = 1.0
    logical_frac: float = 0.5              # share of the infidelity target for Clifford/memory errors
    d_max: int = 31
    parallel_copies: bool = True

    def _pL(self, d):
        return self.A * (self.p / self.p_th) ** ((d + 1) / 2)

    def execute(self, spec, n_phys, target):
        N_log = math.ceil((spec.n_logical + spec.ancillas) * self.logical_overhead)
        n_rot = spec.rotations + spec.t_gates          # T / Toffoli angles are analog rotations too
        rot_layers = spec.rotation_layers + spec.t_layers
        rot_err = n_rot * self.rotation_error_coeff * self.p
        best = None
        for d in range(3, self.d_max + 1, 2):
            q = math.ceil(N_log * self.phys_per_logical * d * d)
            if q > n_phys:
                break
            cycles = d * (rot_layers * self.cycles_per_rotation + spec.clifford_depth * self.cycles_per_clifford_layer)
            cycles = max(cycles, d)
            logical_err = N_log * cycles * self._pL(d)
            if logical_err > self.logical_frac * target:
                continue
            copies = max(1, n_phys // q) if self.parallel_copies else 1
            t_shot = cycles * self.t_cycle_s
            if best is None or t_shot / copies < best[0]:
                F = math.exp(-(logical_err + rot_err))
                best = (t_shot / copies, ExecResult(F, t_shot, copies, copies * q, {
                    "d": d, "rotations": n_rot, "rotation_err": rot_err, "logical_err": logical_err,
                    "cycles": cycles, "n_logical_patches": N_log}))
        return best[1] if best else None


# ----------------------------------------------------------------------------------------
# Walking Cat (IonQ trapped-ion LDPC architecture)
# ----------------------------------------------------------------------------------------
@dataclass
class LDPCBlock:
    """A walking-cat memory block: [[n,k,d]] LDPC code plus its companion cat/Bell resources."""
    name: str
    n: int; k: int; d: int
    block_qubits: int            # data + ancilla (+ beacon) + local reservoir
    cat_qubits: int              # companion cat factory (pipelined), per block
    sec_s: float                 # syndrome-extraction-cycle time (logical clock)
    p_logical_per_sec: float     # logical error per block per SEC at p_ref
    p_ref: float = 1e-4
    suppression_power: float = 5.0   # p_L ~ p^5 (d=9,10 codes; Q102/Q66 fits in arXiv:2609.05625)

    def p_logical(self, p):
        return self.p_logical_per_sec * (p / self.p_ref) ** self.suppression_power


@dataclass
class MagicFactory:
    name: str
    qubits: int                  # factory block incl. its cat factory
    seconds_per_T: float         # sustained T-state output per factory (1 / rate)
    error_per_T: float           # logical error per delivered T state at p_ref
    p_ref: float = 1e-4
    level: int = 1               # error scales as (p/p_ref)^(3^level)  (rough)
    ccz: bool = False            # factory produces CCZ states: Toffolis consume 1 each; T via |CCZ> -> 2|T> catalysis
    seconds_per_ccz: float = 0.0
    error_per_ccz: float = 0.0

    def error_at(self, p):
        return self.error_per_T * (p / self.p_ref) ** (3 ** self.level)

    def ccz_error_at(self, p):
        return self.error_per_ccz * (p / self.p_ref) ** (3 ** self.level)


WALKING_CAT_VARIANTS = {
    # arXiv:2604.19481 (anchor): Q102 memory, beacon loss protocol, CH2 factory (Table I/IV/V/VII)
    "baseline": dict(
        block=LDPCBlock("Q102 [[102,22,9]]", 102, 22, 9, block_qubits=316, cat_qubits=68,
                        sec_s=33.7 * 200e-6, p_logical_per_sec=1e-10),
        factory=MagicFactory("CH2 (Q54)", qubits=173 + 108, seconds_per_T=86400 / 1.0e6, error_per_T=7e-8),
        t_T_gate_s=0.1652 / 2,          # "T gate x2 (CH2)" with Q102 memory = 0.1652 s
        t_meas_layer_s=0.0495,          # LM2 (inter-block) Q102
        layers_per_crossblock_cx=3,     # PcP gate = 3 measurement layers + ancilla (Fig. 9c / Fig. 2)
        meas_per_block_parallel=1,
        p_meas_logical=1e-10,           # Viterbi measurement target error
    ),
    # arXiv:2609.05625 (secp256k1 device): swap-loss blocks (2n+3), Eastinthillation CCZ factory,
    # depth-one injection, 3 parallel measurements per block, CLAW ISA
    "optimized": dict(
        block=LDPCBlock("Q102 [[102,22,9]] swap-loss", 102, 22, 9, block_qubits=207, cat_qubits=40,
                        sec_s=27.0 * 200e-6, p_logical_per_sec=9.34e-12),
        factory=MagicFactory("Eastinthillation CCZ (CCZ->2T for rotations)", qubits=319,
                             seconds_per_T=0.028 / 2, error_per_T=1e-9 / 2,      # Gidney–Fowler |CCZ>->2|T>
                             ccz=True, seconds_per_ccz=0.028, error_per_ccz=1e-9),
        t_T_gate_s=0.0295,              # one measurement layer per injected magic state
        t_meas_layer_s=0.0295,
        layers_per_crossblock_cx=3,
        meas_per_block_parallel=3,
        p_meas_logical=1e-10,
    ),
}


@dataclass
class WalkingCatArchitecture(Architecture):
    """
    IonQ walking cat architecture (Tripier et al., arXiv:2604.19481; Häner et al., arXiv:2609.05625).
    Trapped-ion QCCD, moving-qubit model: high-rate LDPC memory blocks (Q102: 22 logical / 316 qubits),
    cat-state-based logical Pauli measurements, magic factories producing H/CCZ states directly in
    LDPC codes, Clifford frame tracking in-block, cross-block CNOT via 3 measurement layers.
    Code distance is fixed by the code (no d knob); the only space knobs are #blocks and #factories.
    """
    name: str = "Walking cat (IonQ, Q102 baseline)"
    kind: str = "walking_cat"
    variant: str = "baseline"
    p: float = 1e-4                       # two-qubit gate error of the moving-qubit model
    logical_ancilla_frac: float = 0.10    # extra logical qubits for routing/PcP ancillas
    inblock_frac_local: float = 0.7       # fraction of *local* 2q Cliffords that stay in-block (frame-tracked)
    inblock_frac_nonlocal: float = 0.0    # non-local 2q Cliffords always cross blocks
    synth_prefactor: float = 3.0
    synth_const: float = 0.0
    synth_frac: float = 0.4
    logical_frac: float = 0.3
    T_frac: float = 0.3
    reservoir_qubits: int = 200
    bell_qubits_per_block: float = 4.0
    transport_frac: float = 0.06
    max_factories: int = 2000
    parallel_copies: bool = True

    def _v(self):
        return WALKING_CAT_VARIANTS[self.variant]

    def execute(self, spec, n_phys, target):
        v = self._v(); blk: LDPCBlock = v["block"]; fac: MagicFactory = v["factory"]
        n_log = math.ceil((spec.n_logical + spec.ancillas) * (1 + self.logical_ancilla_frac))
        n_blocks = math.ceil(n_log / blk.k)
        q_mem = n_blocks * (blk.block_qubits + blk.cat_qubits + self.bell_qubits_per_block) + self.reservoir_qubits
        # --- non-Clifford compilation: rotations -> Clifford+T ---------------------------
        if spec.rotations > 0:
            eps_synth = self.synth_frac * target / spec.rotations
            t_rot = t_count_per_rotation(eps_synth, self.synth_prefactor, self.synth_const)
            synth_err = spec.rotations * eps_synth
        else:
            t_rot, synth_err = 0, 0.0
        if fac.ccz:      # Toffolis consume CCZ states directly (depth-one injection)
            T_count = spec.rotations * t_rot + (spec.t_gates - spec.toffolis * spec.t_per_toffoli)
            T_layers = spec.rotation_layers * t_rot + (spec.t_layers - spec.toffoli_layers * spec.t_per_toffoli)
            ccz_count, ccz_layers = spec.toffolis, spec.toffoli_layers
        else:
            T_count = spec.rotations * t_rot + spec.t_gates
            T_layers = spec.rotation_layers * t_rot + spec.t_layers
            ccz_count, ccz_layers = 0, 0
        # No distance knob: the design has one factory fidelity and one code, so we report the
        # polarization we get and let the benchmark's success model decide (mitigation may absorb F<1).
        T_err = T_count * fac.error_at(self.p) + ccz_count * fac.ccz_error_at(self.p)
        # --- Clifford part: in-block gates are free (frame tracking), cross-block cost measurements
        cross = (spec.gates_2q_local * (1 - self.inblock_frac_local)
                 + spec.gates_2q_nonlocal * (1 - self.inblock_frac_nonlocal))
        cx_layers_seq = spec.clifford_depth                  # depth bound
        cx_parallel = max(1, n_blocks * v["meas_per_block_parallel"] // 2)
        cx_layers = max(cx_layers_seq, cross / cx_parallel) * v["layers_per_crossblock_cx"]
        t_clifford = cx_layers * v["t_meas_layer_s"]
        n_meas = cross * v["layers_per_crossblock_cx"] + 2 * T_count + 3 * ccz_count
        meas_err = n_meas * v["p_meas_logical"]

        best = None
        need_fac = (T_count + ccz_count) > 0
        per_copy_min = q_mem + (fac.qubits if need_fac else 0)
        if per_copy_min > n_phys:
            return None
        max_copies = n_phys // per_copy_min if self.parallel_copies else 1
        cands = {1, max_copies}
        c = 1
        while c < max_copies:
            c *= 2; cands.add(min(c, max_copies))
        for copies in cands:
            q_avail = n_phys // copies
            if need_fac:
                n_fac = min(self.max_factories, max(1, (q_avail - q_mem) // fac.qubits))
                # magic gates on different blocks run in parallel; supply limited by factories
                t_T_latency = (T_layers + ccz_layers) * v["t_T_gate_s"]
                t_T_supply = (T_count * fac.seconds_per_T + ccz_count * fac.seconds_per_ccz) / n_fac
                t_T = max(t_T_latency, t_T_supply)
            else:
                n_fac, t_T = 0, 0.0
            t_shot = (t_T + t_clifford) * (1 + self.transport_frac)
            t_shot = max(t_shot, blk.sec_s)
            secs = t_shot / blk.sec_s
            logical_err = n_blocks * secs * blk.p_logical(self.p) + meas_err
            q_used = copies * (q_mem + n_fac * fac.qubits)
            score = t_shot / copies
            if best is None or score < best[0]:
                F = math.exp(-(logical_err + T_err + synth_err))
                if F < 1e-6:
                    continue
                best = (score, ExecResult(F, t_shot, copies, q_used, {
                    "variant": self.variant, "code": blk.name, "n_blocks": n_blocks, "factory": fac.name,
                    "n_factories": n_fac, "T_count": T_count, "CCZ_count": ccz_count, "T_per_rotation": t_rot,
                    "t_T_s": t_T, "t_clifford_s": t_clifford, "SECs_per_shot": secs,
                    "logical_err": logical_err, "T_err": T_err, "synth_err": synth_err}))
        return best[1] if best else None


# ----------------------------------------------------------------------------------------
# Bivariate-bicycle (gross-code family) FTQC for superconducting hardware
# ----------------------------------------------------------------------------------------
@dataclass
class BBCode:
    """[[n,k,d]] bivariate bicycle code; p_L per cycle at p_ref=1e-3 from Bravyi et al., Nature 627, 778 (2024)."""
    name: str
    n: int; k: int; d: int
    p_logical_per_cycle: float
    d_circ: int                 # circuit-level distance -> suppression exponent d_circ/2
    p_ref: float = 1e-3

    def p_logical(self, p):
        return self.p_logical_per_cycle * (p / self.p_ref) ** (self.d_circ / 2)


DEFAULT_BB_CODES = [
    BBCode("BB [[72,12,6]]", 72, 12, 6, 1e-4, 6),
    BBCode("BB [[90,8,10]]", 90, 8, 10, 2e-6, 8),
    BBCode("gross [[144,12,12]]", 144, 12, 12, 2e-7, 10),
    BBCode("two-gross [[288,12,18]]", 288, 12, 18, 2e-12, 16),
]


@dataclass
class BBCodeArchitecture(Architecture):
    """
    Superconducting FTQC built on bivariate-bicycle memory blocks (Bravyi et al. 2024) with
    QLDPC-surgery logical measurements and bridging to surface-code magic-state factories
    (Cross, He, Rall, Yoder, "Improved QLDPC surgery", 2024; Yoder et al., "Tour de gross", 2025).
    Pauli-based computation like the walking cat: each block = n data + n check qubits plus an
    adapter/LPU share; logical measurement = ~d code cycles; cross-block CNOT = 3 measurements;
    T states from Litinski surface-code factories bridged to the blocks.  Code choice replaces the
    surface-code distance knob.
    """
    name: str = "FTQC BB codes (gross family)"
    kind: str = "ftqc_bb"
    p: float = 1e-3
    t_cycle_s: float = 1e-6
    codes: list = field(default_factory=lambda: list(DEFAULT_BB_CODES))
    adapter_frac: float = 0.5             # LPU / surgery ancilla qubits relative to 2n block qubits
    logical_ancilla_frac: float = 0.10
    inblock_frac_local: float = 0.3       # fraction of local 2q Cliffords absorbed in-block (automorphism gates / frame)
    inblock_frac_nonlocal: float = 0.0
    cycles_per_measurement: float = 1.0   # in units of d (surgery needs ~d rounds)
    layers_per_crossblock_cx: int = 3
    meas_per_block_parallel: int = 1
    p_meas_logical_factor: float = 1.0    # logical-measurement error ~ factor * p_L(block)
    synth_prefactor: float = 3.0
    synth_const: float = 0.0
    synth_frac: float = 0.4
    logical_frac: float = 0.3
    T_frac: float = 0.3
    factories: list = field(default_factory=lambda: list(DEFAULT_FACTORIES))
    parallel_copies: bool = True

    def execute(self, spec, n_phys, target):
        n_log = math.ceil((spec.n_logical + spec.ancillas) * (1 + self.logical_ancilla_frac))
        if spec.rotations > 0:
            eps_synth = self.synth_frac * target / spec.rotations
            t_rot = t_count_per_rotation(eps_synth, self.synth_prefactor, self.synth_const)
            synth_err = spec.rotations * eps_synth
        else:
            t_rot, synth_err = 0, 0.0
        T_count = spec.rotations * t_rot + spec.t_gates
        T_layers = spec.rotation_layers * t_rot + spec.t_layers
        if T_count > 0:
            eps_T = self.T_frac * target / T_count
            facs = [f for f in self.factories if f.error_at(self.p) <= eps_T]
            if not facs:
                return None
        else:
            facs = [None]
        cross = (spec.gates_2q_local * (1 - self.inblock_frac_local)
                 + spec.gates_2q_nonlocal * (1 - self.inblock_frac_nonlocal))
        best = None
        for code in self.codes:
            n_blocks = math.ceil(n_log / code.k)
            q_mem = math.ceil(n_blocks * 2 * code.n * (1 + self.adapter_frac))
            if q_mem > n_phys:
                continue
            t_meas = code.d * self.cycles_per_measurement * self.t_cycle_s
            cx_parallel = max(1, n_blocks * self.meas_per_block_parallel // 2)
            cx_layers = max(spec.clifford_depth, cross / cx_parallel) * self.layers_per_crossblock_cx
            t_clifford = cx_layers * t_meas
            n_meas = cross * self.layers_per_crossblock_cx + 2 * T_count
            for fac in facs:
                fq = fac.qubits if fac else 0
                per_copy = q_mem + fq
                if per_copy > n_phys:
                    continue
                max_copies = n_phys // per_copy if self.parallel_copies else 1
                cands = {1, max_copies}
                c = 1
                while c < max_copies:
                    c *= 2; cands.add(min(c, max_copies))
                for copies in cands:
                    if fac:
                        n_fac = max(1, (n_phys // copies - q_mem) // fq)
                        t_T = max(T_layers * t_meas, T_count * fac.cycles_per_T * self.t_cycle_s / n_fac)
                        T_err = T_count * fac.error_at(self.p)
                    else:
                        n_fac, t_T, T_err = 0, 0.0, 0.0
                    t_shot = max(t_T + t_clifford, code.d * self.t_cycle_s)
                    cycles = t_shot / self.t_cycle_s
                    pL = code.p_logical(self.p)
                    logical_err = n_blocks * cycles * pL + n_meas * self.p_meas_logical_factor * pL
                    if logical_err > self.logical_frac * target:
                        continue
                    score = t_shot / copies
                    if best is None or score < best[0]:
                        F = math.exp(-(logical_err + T_err + synth_err))
                        best = (score, ExecResult(F, t_shot, copies, copies * (q_mem + n_fac * fq), {
                            "code": code.name, "n_blocks": n_blocks, "factory": fac.name if fac else None,
                            "n_factories": n_fac, "T_count": T_count, "T_per_rotation": t_rot,
                            "t_T_s": t_T, "t_clifford_s": t_clifford, "logical_err": logical_err,
                            "T_err": T_err, "synth_err": synth_err}))
        return best[1] if best else None
