"""
Circuit cost models: map (Benchmark, L) -> per-Trotter-step resource counts.

The analytic default follows the fermionic-swap-network compilation of the 2D Hubbard
Trotter step to a nearest-neighbour qubit grid (Kivlichan et al., PRL 120, 110501 (2018);
Clinton, Bausch, Cubitt, Nat. Commun. 12, 4989 (2021)).  A second implementation shows
how to plug in Qualtran call-graph costs instead (best-effort import; the API of
qualtran.bloqs.chemistry.trotter.hubbard changes between versions).
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Protocol
import math


@dataclass
class StepCosts:
    """Resources of ONE second-order Trotter step for the L x L Hubbard model."""
    gates_2q: int           # native two-qubit gates (NISQ view)
    gates_1q: int           # native single-qubit gates (NISQ view)
    depth: int              # circuit depth in layers (2q-gate layers dominate)
    rotations: int          # arbitrary-angle Pauli rotations (FTQC / STAR view)
    rotation_layers: int    # sequential rotation layers (logical T-depth per rotation)
    clifford_2q: int        # Clifford 2q gates (CNOT/fSWAP) in the FT view (cheap)

    def to_dict(self):
        return asdict(self)


class CostModel(Protocol):
    def step_costs(self, L: int) -> StepCosts: ...
    name: str


@dataclass
class AnalyticHubbardCostModel:
    """
    Second-order Trotter step  U(dt) = e^{-i H_hop dt/2} e^{-i H_U dt} e^{-i H_hop dt/2}.

    Counting (open L x L lattice, JW with the snake ordering along rows, two spin sectors):
      bonds per spin:  n_bonds = 2 L (L-1)     -> 4 L (L-1) hopping terms total
      hopping term  e^{-i theta (XX+YY)/2}: `gates_per_hop` native 2q gates (2 for CZ/CX
          basis, 1 if an XX+YY / iSWAP-family gate is native) and 2 Pauli rotations.
      Vertical (inter-row) hopping is made local by a fermionic swap network:
          ~ n_sites fSWAPs per half-step, depth ~ L  (Kivlichan et al.).
      on-site term e^{-i phi Z_i↑ Z_i↓}: 1 two-qubit rotation per site (the two spin
          orbitals of a site are kept adjacent by interleaving the spin sectors).
    """
    name: str = "analytic-fswap"
    gates_per_hop: int = 2          # native 2q gates per hopping term
    gates_per_fswap: int = 3        # native 2q gates per fermionic swap
    gates_per_onsite: int = 2       # native 2q gates per exp(i phi ZZ)
    single_q_per_2q: float = 2.0    # bookkeeping ratio of 1q to 2q gates
    depth_per_L: float = 6.0        # depth of one step in units of L (swap network dominated)
    depth_const: int = 6            # + constant layers (on-site, basis changes)
    hop_rotation_layers: int = 8    # rotation layers for hopping per half-step (2 dirs x 2 parities x 2 rot)

    def step_costs(self, L: int) -> StepCosts:
        n_sites = L * L
        n_hop_terms = 4 * L * (L - 1)                 # both spins, both directions
        n_fswap = 2 * n_sites                         # one swap network per half-step
        gates_2q = (2 * n_hop_terms * self.gates_per_hop      # two half-steps of hopping
                    + n_fswap * self.gates_per_fswap
                    + n_sites * self.gates_per_onsite)
        gates_1q = int(self.single_q_per_2q * gates_2q)
        depth = int(self.depth_per_L * L) + self.depth_const
        rotations = 2 * (2 * n_hop_terms) + n_sites   # 2 rot / hop term, 1 rot / on-site
        rotation_layers = 2 * self.hop_rotation_layers + 1
        clifford_2q = n_fswap * 3 + 2 * n_hop_terms * 2
        return StepCosts(gates_2q, gates_1q, depth, rotations, rotation_layers, clifford_2q)


@dataclass
class QualtranHubbardCostModel:
    """
    Adapter: pull rotation counts from Qualtran's Hubbard Trotter bloqs and fall back to
    the analytic model for connectivity-dependent quantities (depth, SWAP overhead).
    Requires `pip install qualtran`; adjust the bloq names to your installed version.
    """
    name: str = "qualtran"
    fallback: AnalyticHubbardCostModel = field(default_factory=AnalyticHubbardCostModel)

    def step_costs(self, L: int) -> StepCosts:
        base = self.fallback.step_costs(L)
        try:  # pragma: no cover - depends on external package
            from qualtran.bloqs.chemistry.trotter.hubbard.trotter_step import build_plaq_unitary_second_order_suzuki
            from qualtran.resource_counting import get_cost_value, QECGatesCost
            bloq = build_plaq_unitary_second_order_suzuki(L, u=4.0, tau=0.1)
            cost = get_cost_value(bloq, QECGatesCost())
            rotations = int(cost.rotation)
            return StepCosts(base.gates_2q, base.gates_1q, base.depth, rotations,
                             base.rotation_layers, int(cost.clifford))
        except Exception:
            return base


def t_count_per_rotation(eps_synth: float, prefactor: float = 3.0, const: float = 0.0) -> int:
    """Ross–Selinger / gridsynth: T-count ~ 3 log2(1/eps) + O(log log). Knobs for other synthesizers."""
    return max(1, math.ceil(prefactor * math.log2(1.0 / eps_synth) + const))
