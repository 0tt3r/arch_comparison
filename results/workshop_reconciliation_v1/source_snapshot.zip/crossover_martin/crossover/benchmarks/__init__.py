from .base import Benchmark, Outcome
from .hubbard import HubbardBenchmark
from .hidden_shift import HiddenShiftBenchmark
from .iqp import IQPBenchmark
from .quops import QUOPSBenchmark

BENCHMARKS = {"hubbard": HubbardBenchmark, "hidden_shift": HiddenShiftBenchmark,
              "iqp": IQPBenchmark, "quops": QUOPSBenchmark}
