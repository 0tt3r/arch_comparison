"""
Benchmark interface.  A benchmark defines
  * a family of instances indexed by an integer size parameter,
  * the circuit (CircuitSpec) executed per shot for each instance,
  * a success model (how F, t_shot -> shots, pass/fail),
  * problem_size(size): the scalar plotted on the y-axis ("computational power witnessed").

The default `evaluate` scans sizes upward and returns the largest that fits the wall-clock
budget; benchmarks with a 2-parameter instance space (QUOPS: width x size) override it.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import math

from ..circuit import CircuitSpec
from ..success import ExpectationValue, Needle, Polarization

WEEK = 7 * 24 * 3600.0
INF = float("inf")


@dataclass
class Outcome:
    problem_size: float          # 0 if nothing feasible
    size_param: int
    runtime_s: float
    details: dict = field(default_factory=dict)


class Benchmark:
    name: str = "base"
    kind: str = "base"
    ylabel: str = "problem size"
    time_budget_s: float = WEEK
    size_min: int = 2
    size_max: int = 400
    size_step: int = 1

    # ---- to implement --------------------------------------------------------------
    def circuit(self, size: int) -> CircuitSpec: ...
    def problem_size(self, size: int) -> float: return size
    def success(self): ...                       # returns a success model

    # ---- generic machinery ----------------------------------------------------------
    size_points: int = 150       # geometric grid when the range is wide (>600 sizes)

    def sizes(self):
        if self.size_max - self.size_min <= 600:
            return range(self.size_min, self.size_max + 1, self.size_step)
        import numpy as np
        g = np.logspace(np.log10(self.size_min), np.log10(self.size_max), self.size_points)
        g = np.unique((np.round(g / self.size_step) * self.size_step).astype(int))
        return [int(x) for x in g if x >= self.size_min]

    def try_size(self, arch, size, n_phys):
        spec = self.circuit(size)
        sm = self.success()
        ex = arch.execute(spec, n_phys, sm.infidelity_target())
        if ex is None:
            return False, INF, {"reason": "does not fit / no code distance"}
        shots, why = sm.shots(ex.F, spec.n_logical)
        if shots is None:
            return False, INF, {"reason": why, "F": ex.F}
        runtime = shots * ex.t_shot_s / ex.copies
        ok = runtime <= self.time_budget_s
        det = {"F": ex.F, "shots": shots, "t_shot_s": ex.t_shot_s, "copies": ex.copies,
               "qubits_used": ex.qubits_used, "circuit": spec.to_dict(), **ex.details,
               "reason": None if ok else "runtime exceeds budget"}
        return ok, runtime, det

    def evaluate(self, arch, n_phys) -> Outcome:
        best = Outcome(0.0, 0, INF, {"reason": "nothing feasible"})
        misses = 0
        for s in self.sizes():
            ok, rt, det = self.try_size(arch, s, n_phys)
            if ok:
                best, misses = Outcome(self.problem_size(s), s, rt, det), 0
            else:
                if best.size_param == 0 and det.get("reason", "").startswith("does not fit"):
                    break
                misses += 1
                if misses >= 3:
                    break
        return best

    def to_dict(self):
        d = asdict(self)
        d["kind"] = self.kind
        return d
