"""
Hidden Shift Benchmark Problem (HSBP), as defined in the IonQ application-benchmark white paper
(Aboumrad et al., April 2026, §2.9; github.com/ionq-publications/apps-benchmark), based on
Rötteler's hidden-shift algorithm for Maiorana–McFarland bent functions f_pi(x) = x_o . pi(x_e).

Circuit on n = 2m qubits:  H^n -> U_g -> H^n -> U_dual -> H^n -> measure.
U_g computes (-1)^{f_pi(x ⊕ s)}: X gates for the shift s, the permutation pi on the even
qubits (CNOT / Toffoli network), a stack of m CZ gates (x_{2i-1}, x_{2i}), and pi^-1.
U_dual does the same with pi^-1.  The ideal output is exactly the hidden shift |s>; the
score is P(s), and the paper's Time-to-Solution metric is
      TTS_c = t_shot * ln(1-c) / ln(1 - q),  q = P(sample s)      -> `Needle` success model.

Permutation families (paper §2.9.3):
  cx_ladder  : pi = prod CNOT(x_2j, x_2j+2)              (m-1 CNOTs, Clifford)
  ccx_ladder : pi = prod CCX(x_2j, x_2j+2, x_2j+4)       (m-2 Toffolis)
  mcx        : one (m-1)-controlled X, v-chain decomposition (2(m-2) Toffolis, m-2 ancillas)
  random_cx  : k random CNOTs (paper uses fixed k = 10..100; here k = k0 + k_per_qubit*n so that
               difficulty scales with size, since we sweep n)
The size parameter is n (even); the plotted problem size is n.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

from .base import Benchmark, WEEK
from ..circuit import CircuitSpec
from ..success import Needle


@dataclass
class HiddenShiftBenchmark(Benchmark):
    name: str = "Hidden shift (random CX permutations)"
    kind: str = "hidden_shift"
    ylabel: str = "solvable hidden-shift width  $n$ (qubits)"
    time_budget_s: float = WEEK
    size_min: int = 4
    size_max: int = 200000
    size_step: int = 2
    family: str = "random_cx"        # cx_ladder | ccx_ladder | mcx | random_cx
    k0: int = 0                      # random_cx: k = k0 + k_per_qubit * n CNOTs per permutation
    k_per_qubit: float = 2.0
    confidence: float = 0.99         # TTS confidence level c
    toffoli_t_count: int = 4         # T per Toffoli (4 with measurement-based uncompute, 7 exact)
    toffoli_2q_gates: int = 6        # native 2q gates per Toffoli on NISQ
    perm_parallelism: float = 2.0    # random_cx: average CNOTs executable per layer

    def problem_size(self, n): return n

    def success(self): return Needle(self.confidence)

    def circuit(self, n):
        m = n // 2
        cz = m                                    # CZ stack
        h_layers = 3
        anc = 0
        if self.family == "random_cx":
            k = int(self.k0 + self.k_per_qubit * n)
            cx_local, cx_nonlocal, tof = 0, k, 0
            perm_depth = k / self.perm_parallelism
        elif self.family == "cx_ladder":
            cx_local, cx_nonlocal, tof = m - 1, 0, 0
            perm_depth = m - 1
        elif self.family == "ccx_ladder":
            cx_local, cx_nonlocal, tof = 0, 0, max(0, m - 2)
            perm_depth = max(1, m - 2)
        elif self.family == "mcx":
            cx_local, cx_nonlocal, tof = 0, 0, 2 * max(0, m - 2)
            perm_depth = 2 * max(1, m - 2)
            anc = max(0, m - 2)
        else:
            raise ValueError(self.family)
        # permutation appears as pi, pi^-1 in U_g and pi^-1, pi in U_dual -> 4 permutation blocks,
        # 2 CZ stacks, X gates for the shift, 3 Hadamard layers
        blocks = 4
        two_q_local = blocks * cx_local + 2 * cz
        two_q_nonlocal = blocks * cx_nonlocal
        toffolis = blocks * tof
        gates_1q = h_layers * n + m + toffolis * 8
        depth = h_layers + 2 + blocks * perm_depth * (3 if toffolis else 1)
        return CircuitSpec(n_logical=n, gates_2q_local=two_q_local + toffolis * self.toffoli_2q_gates,
                           gates_2q_nonlocal=two_q_nonlocal, gates_1q=gates_1q, depth=int(depth),
                           t_gates=toffolis * self.toffoli_t_count,
                           t_layers=blocks * perm_depth * self.toffoli_t_count if toffolis else 0,
                           toffolis=toffolis, toffoli_layers=int(blocks * perm_depth) if toffolis else 0,
                           t_per_toffoli=self.toffoli_t_count, ancillas=anc)
