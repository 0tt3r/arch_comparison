"""
QUOPS — Quantum Universal Operation Performance System (Proctor et al., arXiv:2609.12146,
Sandia / Quantinuum / NVIDIA, Sept 2026).

QUOPS circuits of shape (w, s): alternating layers of random single-qubit Pauli rotations
R_P(theta) on every qubit and layers of CNOTs on random pairs.  Size s = #R_P + 2 #CNOT, so
one (rotation layer + CNOT layer) pair on w qubits contributes 2w and depth D = s / (2w).
A shape passes if the mean process polarization gamma_bar(w,s) >= alpha, alpha = 1/sqrt(e)
(error-mitigated regions use a lower alpha with ~1/alpha^2 sampling overhead).  The QUOPS
score Q is the largest passing s inside the utility cone w^2 <= s <= w^3; the QUOPS rate
Omega is the operation throughput at that shape corrected for sampling overhead.

Here we *predict* Q(n_phys) for each architecture: polarization gamma is the architecture's
global-depolarizing fidelity F for the (w,s) circuit; the test itself (mirror circuits of
double size, `n_circuits` x `shots_per_circuit`) must fit the wall-clock budget.  For FTQC the
rotations are synthesized into T gates with the synthesis error charged against 1 - alpha,
matching the paper's treatment of approximate compilation.  Plotted size: Q.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

from .base import Benchmark, Outcome, WEEK, INF
from ..circuit import CircuitSpec
from ..success import Polarization


@dataclass
class QUOPSBenchmark(Benchmark):
    name: str = "QUOPS score"
    kind: str = "quops"
    ylabel: str = "QUOPS score  $Q$ (largest passing circuit size)"
    time_budget_s: float = WEEK
    alpha: float = 1 / math.sqrt(math.e)   # success threshold on mean polarization
    w_min: int = 3
    w_max: int = 4000
    n_circuits: int = 30                   # mirror circuits per shape in the test
    shots_per_circuit: int = 100
    cone_lo: float = 2.0                   # w^cone_lo <= s <= w^cone_hi
    cone_hi: float = 3.0
    s_points: int = 40                     # geometric grid of s inside the cone
    mirror_factor: float = 2.0             # mirror-circuit test costs ~2x the forward circuit per shot

    def success(self):
        return Polarization(alpha=self.alpha, n_samples=self.n_circuits * self.shots_per_circuit)

    def circuit_ws(self, w, s):
        D = max(1, round(s / (2 * w)))
        rotations = w * D
        cnots = (w // 2) * D
        return CircuitSpec(n_logical=w, gates_2q_nonlocal=cnots, gates_1q=rotations,
                           depth=2 * D, rotations=rotations, rotation_layers=D)

    def circuit(self, size):
        raise NotImplementedError("QUOPS instances are 2-parameter (w, s); use evaluate()")

    def _passes(self, arch, w, s, n_phys):
        spec = self.circuit_ws(w, s)
        sm = self.success()
        ex = arch.execute(spec, n_phys, sm.infidelity_target())
        if ex is None:
            return False, None
        shots, why = sm.shots(ex.F, w)
        if shots is None:
            return False, {"F": ex.F, "reason": why}
        # the test runs mirror circuits of double size ("embedded into mirror circuits with double the size")
        runtime = shots * self.mirror_factor * ex.t_shot_s / ex.copies
        if runtime > self.time_budget_s:
            return False, {"F": ex.F, "reason": "test exceeds budget"}
        # QUOPS rate: forward-circuit ops per second, corrected for sampling overhead ~1/gamma^2
        rate = (s / ex.t_shot_s) * ex.copies * ex.F ** 2
        return True, {"F": ex.F, "runtime_s": runtime, "quops_rate": rate, "copies": ex.copies,
                      "qubits_used": ex.qubits_used, **ex.details}

    def evaluate(self, arch, n_phys) -> Outcome:
        best = Outcome(0.0, 0, INF, {"reason": "no shape passes"})
        w = self.w_min
        dead = 0
        while w <= self.w_max:
            lo, hi = w ** self.cone_lo, w ** self.cone_hi
            if arch.execute(self.circuit_ws(w, int(lo)), n_phys, 1 - self.alpha) is None:
                break                                   # width does not fit -> larger widths won't either
            grid = sorted({int(round(lo * (hi / lo) ** (i / (self.s_points - 1)))) for i in range(self.s_points)})
            found = 0
            for s in grid:                              # polarization decreases with s: scan upward
                ok, det = self._passes(arch, w, s, n_phys)
                if not ok:
                    break
                found = s
                if s > best.problem_size:
                    best = Outcome(float(s), w, det["runtime_s"], {"w": w, "s": s, **det})
            dead = dead + 1 if found == 0 else 0
            if dead >= 3:
                break
            # step widths geometrically once they get large
            w = w + 1 if w < 32 else int(round(w * 1.15))
        return best
