"""
IQP sampling benchmark.

Family: "X-program" IQP circuits  H^n . D . H^n  with a diagonal phase polynomial
      D = prod_{(i,j) in E} exp(i theta_ij Z_i Z_j) . prod_i exp(i phi_i Z_i)
with angles from {k pi/8}.  With pi/8 multiples every ZZ term is CNOT.T.CNOT (1 T gate, no
synthesis) and every Z term is a power of T, so the FTQC cost is exactly |E| + n T gates.
  dense  : E = all pairs (Bremner–Jozsa–Shepherd 2011), classically hard to sample in the
           worst case; SWAP network of depth ~n on nearest-neighbour hardware.
  sparse : |E| = density * n random pairs (Bremner–Montanaro–Shepherd 2017, "sparse IQP":
           average-case hardness conjectures with O(log n)-degree graphs).
Task: produce n_samples samples from the output distribution with circuit polarization
F >= f_min (the fidelity one would certify with cross-entropy benchmarking at small n).  This
is a `Polarization` success model; error mitigation does not apply to sampling, so the
threshold is hard.  Size parameter and plotted size: n (qubits).
"""
from __future__ import annotations
from dataclasses import dataclass
import math

from .base import Benchmark, WEEK
from ..circuit import CircuitSpec
from ..success import Polarization


@dataclass
class IQPBenchmark(Benchmark):
    name: str = "IQP sampling (sparse, pi/8 angles)"
    kind: str = "iqp"
    ylabel: str = "solvable IQP width  $n$ (qubits)"
    time_budget_s: float = WEEK
    size_min: int = 4
    size_max: int = 200000
    size_step: int = 2
    family: str = "sparse"           # sparse | dense
    density: float = 3.0             # sparse: |E| = density * n
    f_min: float = 1e-2              # required circuit polarization (XEB-certifiable fidelity)
    n_samples: float = 1e6
    zz_2q_gates: int = 2             # CNOT.T.CNOT: 2 native 2q gates per ZZ term

    def problem_size(self, n): return n

    def success(self): return Polarization(alpha=self.f_min, n_samples=self.n_samples, mitigation_overhead=False)

    def circuit(self, n):
        if self.family == "dense":
            E = n * (n - 1) // 2
            # swap-network compilation (Kivlichan-style): all pairs become local; ~n^2/2 SWAPs
            local = E * self.zz_2q_gates + (n * (n - 1) // 2) * 3
            nonlocal_ = 0
            depth = 2 + n * (self.zz_2q_gates + 3)
            t_layers = n
        else:
            E = int(self.density * n)
            local, nonlocal_ = 0, E
            depth = 2 + int(2 * self.density) * self.zz_2q_gates
            t_layers = int(2 * self.density)
        return CircuitSpec(n_logical=n, gates_2q_local=local, gates_2q_nonlocal=nonlocal_,
                           gates_1q=2 * n + n + E, depth=depth,
                           t_gates=E + n, t_layers=t_layers + 1)
