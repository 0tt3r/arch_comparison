"""
2D Fermi–Hubbard dynamical correlator (see README §1 for the full list of assumptions).
L x L open lattice, JW encoding (2 qubits/site), Néel initial state (Z eigenstate, so
<Z_i(0) Z_j(t)> = ±<Z_j(t)> is one Z measurement), 2nd-order Trotter with r steps chosen so
the Trotter error is trotter_frac * eps, using err <= alpha n_sites t^3 / r^2.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import math

from .base import Benchmark, WEEK
from ..circuit import CircuitSpec
from ..costmodel import AnalyticHubbardCostModel
from ..success import ExpectationValue, Polarization


@dataclass
class HubbardBenchmark(Benchmark):
    name: str = "2D Fermi–Hubbard <Z_i(0)Z_j(t)>"
    kind: str = "hubbard"
    ylabel: str = r"solvable lattice sites  $n_{\mathrm{sites}}=L^2$"
    time_budget_s: float = WEEK
    size_min: int = 2
    size_max: int = 300
    eps: float = 1e-1
    J: float = 1.0
    U: float = 4.0
    t_evolve: float = 4.0
    trotter_prefactor: float = 0.1
    trotter_frac: float = 0.25
    stat_frac: float = 0.25
    z_score: float = 2.0
    mitigation: str = "rescale"       # NISQ/STAR error-mitigation policy for the expectation value
    qubits_per_site: int = 2
    amplitude_estimation: bool = False   # coherent AE: ~pi/(2 eps_stat) sequential repetitions of U(t), O(1) shots
    ae_shots: int = 30                   # repetitions of the AE circuit (median-of-means style)
    cost_model: AnalyticHubbardCostModel = field(default_factory=AnalyticHubbardCostModel)

    def trotter_steps(self, L):
        r = math.sqrt(self.trotter_prefactor * L * L * self.t_evolve ** 3 / (self.trotter_frac * self.eps))
        return max(1, math.ceil(r))

    def problem_size(self, L): return L * L

    def hw_frac(self): return 1 - self.trotter_frac - self.stat_frac

    def ae_queries(self):
        return math.ceil(math.pi / (2 * self.stat_frac * self.eps)) if self.amplitude_estimation else 1

    def success(self):
        if self.amplitude_estimation:   # AE needs the whole (long) circuit to have polarization ~1
            return Polarization(alpha=1 - self.hw_frac() * self.eps, n_samples=self.ae_shots, mitigation_overhead=False)
        return ExpectationValue(self.eps, self.stat_frac, self.hw_frac(), self.z_score, self.mitigation)

    def circuit(self, L):
        r = self.trotter_steps(L) * self.ae_queries()
        sc = self.cost_model.step_costs(L)
        return CircuitSpec(n_logical=self.qubits_per_site * L * L + (1 if self.amplitude_estimation else 0),
                           gates_2q_local=r * sc.gates_2q, gates_1q=r * sc.gates_1q, depth=r * sc.depth,
                           rotations=r * sc.rotations, rotation_layers=r * sc.rotation_layers,
                           measured_qubits=1)

    def to_dict(self):
        d = super().to_dict(); d["cost_model"] = self.cost_model.name; return d
