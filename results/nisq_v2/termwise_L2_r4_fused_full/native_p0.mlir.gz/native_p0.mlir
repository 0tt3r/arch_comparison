module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %9:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %10 = qlx.apply #qlx.action<h>(%9#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %11 = qlx.apply #qlx.action<h>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %12:2 = qlx.apply #qlx.action<pauli_rotation>(%11, %10, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %13 = qlx.apply #qlx.action<pauli_rotation>(%12#1, %cst_1) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %14 = qlx.apply #qlx.action<pauli_rotation>(%12#0, %cst_2) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %15:2 = qlx.apply #qlx.action<pauli_rotation>(%13, %14, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %16 = qlx.apply #qlx.action<pauli_rotation>(%9#0, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %17 = qlx.apply #qlx.action<h>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %18 = qlx.apply #qlx.action<h>(%15#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %19 = qlx.apply #qlx.action<pauli_rotation>(%18, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %20 = qlx.apply #qlx.action<h>(%19) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_6 = arith.constant 1.250000e-01 : f64
    %21:2 = qlx.apply #qlx.action<pauli_rotation>(%17, %20, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %22 = qlx.apply #qlx.action<pauli_rotation>(%21#0, %cst_7) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %23 = qlx.apply #qlx.action<pauli_rotation>(%21#1, %cst_8) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_9 = arith.constant 1.250000e-01 : f64
    %24:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %23, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %25 = qlx.apply #qlx.action<h>(%15#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %26 = qlx.apply #qlx.action<pauli_rotation>(%25, %cst_10) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %27 = qlx.apply #qlx.action<h>(%26) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %28 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 1.5707963267948966 : f64
    %29 = qlx.apply #qlx.action<pauli_rotation>(%28, %cst_11) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %30 = qlx.apply #qlx.action<h>(%29) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_12 = arith.constant 1.250000e-01 : f64
    %31:2 = qlx.apply #qlx.action<pauli_rotation>(%27, %30, %cst_12) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %32 = qlx.apply #qlx.action<pauli_rotation>(%31#0, %cst_13) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %33 = qlx.apply #qlx.action<pauli_rotation>(%31#1, %cst_14) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_15 = arith.constant 1.250000e-01 : f64
    %34:2 = qlx.apply #qlx.action<pauli_rotation>(%32, %33, %cst_15) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %35 = qlx.apply #qlx.action<h>(%5) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %36 = qlx.apply #qlx.action<h>(%6) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %37:2 = qlx.apply #qlx.action<pauli_rotation>(%35, %36, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %38 = qlx.apply #qlx.action<pauli_rotation>(%37#0, %cst_17) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %39 = qlx.apply #qlx.action<pauli_rotation>(%37#1, %cst_18) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %40:2 = qlx.apply #qlx.action<pauli_rotation>(%38, %39, %cst_19) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %41 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %42 = qlx.apply #qlx.action<h>(%41) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %43 = qlx.apply #qlx.action<h>(%40#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_20 = arith.constant 3.1415926535897931 : f64
    %44 = qlx.apply #qlx.action<pauli_rotation>(%43, %cst_20) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %45 = qlx.apply #qlx.action<h>(%44) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %46:2 = qlx.apply #qlx.action<pauli_rotation>(%42, %45, %cst_21) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %47 = qlx.apply #qlx.action<pauli_rotation>(%46#0, %cst_22) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%46#1, %cst_23) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %49:2 = qlx.apply #qlx.action<pauli_rotation>(%47, %48, %cst_24) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %50 = qlx.apply #qlx.action<h>(%34#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_25 = arith.constant 3.1415926535897931 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%50, %cst_25) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %52 = qlx.apply #qlx.action<h>(%51) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %53 = qlx.apply #qlx.action<h>(%49#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_26 = arith.constant 3.1415926535897931 : f64
    %54 = qlx.apply #qlx.action<pauli_rotation>(%53, %cst_26) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %55 = qlx.apply #qlx.action<h>(%54) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %56:2 = qlx.apply #qlx.action<pauli_rotation>(%52, %55, %cst_27) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %57 = qlx.apply #qlx.action<pauli_rotation>(%56#0, %cst_28) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_29 = arith.constant 1.5707963267948966 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%56#1, %cst_29) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %59:2 = qlx.apply #qlx.action<pauli_rotation>(%57, %58, %cst_30) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %60 = qlx.apply #qlx.action<h>(%59#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_31 = arith.constant 3.1415926535897931 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%60, %cst_31) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %62 = qlx.apply #qlx.action<h>(%61) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%34#0, %62, %cst_32) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %64 = qlx.apply #qlx.action<pauli_rotation>(%63#0, %cst_33) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_34 = arith.constant 1.5707963267948966 : f64
    %65 = qlx.apply #qlx.action<pauli_rotation>(%63#1, %cst_34) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %66:2 = qlx.apply #qlx.action<pauli_rotation>(%64, %65, %cst_35) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %67 = qlx.apply #qlx.action<h>(%24#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_36 = arith.constant 3.1415926535897931 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%67, %cst_36) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %69 = qlx.apply #qlx.action<h>(%68) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %70 = qlx.apply #qlx.action<h>(%66#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_37 = arith.constant 3.1415926535897931 : f64
    %71 = qlx.apply #qlx.action<pauli_rotation>(%70, %cst_37) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %72 = qlx.apply #qlx.action<h>(%71) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %73:2 = qlx.apply #qlx.action<pauli_rotation>(%69, %72, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_39 = arith.constant 1.5707963267948966 : f64
    %74 = qlx.apply #qlx.action<pauli_rotation>(%73#0, %cst_39) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %75 = qlx.apply #qlx.action<pauli_rotation>(%73#1, %cst_40) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %76:2 = qlx.apply #qlx.action<pauli_rotation>(%74, %75, %cst_41) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %77 = qlx.apply #qlx.action<h>(%24#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_42 = arith.constant 1.5707963267948966 : f64
    %78 = qlx.apply #qlx.action<pauli_rotation>(%77, %cst_42) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %79 = qlx.apply #qlx.action<h>(%78) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %80 = qlx.apply #qlx.action<h>(%76#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %81 = qlx.apply #qlx.action<pauli_rotation>(%80, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %82 = qlx.apply #qlx.action<h>(%81) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_44 = arith.constant 1.250000e-01 : f64
    %83:2 = qlx.apply #qlx.action<pauli_rotation>(%79, %82, %cst_44) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_45 = arith.constant 1.5707963267948966 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%83#0, %cst_45) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %85 = qlx.apply #qlx.action<pauli_rotation>(%83#1, %cst_46) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_47 = arith.constant 1.250000e-01 : f64
    %86:2 = qlx.apply #qlx.action<pauli_rotation>(%84, %85, %cst_47) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %87 = qlx.apply #qlx.action<h>(%66#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_48 = arith.constant 3.1415926535897931 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%87, %cst_48) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %89 = qlx.apply #qlx.action<h>(%88) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %90 = qlx.apply #qlx.action<h>(%59#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_49 = arith.constant 3.1415926535897931 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%90, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %92 = qlx.apply #qlx.action<h>(%91) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_50 = arith.constant 1.5707963267948966 : f64
    %93:2 = qlx.apply #qlx.action<pauli_rotation>(%89, %92, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 1.5707963267948966 : f64
    %94 = qlx.apply #qlx.action<pauli_rotation>(%93#0, %cst_51) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %95 = qlx.apply #qlx.action<pauli_rotation>(%93#1, %cst_52) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %96:2 = qlx.apply #qlx.action<pauli_rotation>(%94, %95, %cst_53) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %97 = qlx.apply #qlx.action<h>(%96#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_54 = arith.constant 3.1415926535897931 : f64
    %98 = qlx.apply #qlx.action<pauli_rotation>(%97, %cst_54) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %99 = qlx.apply #qlx.action<h>(%98) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %100 = qlx.apply #qlx.action<h>(%49#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 3.1415926535897931 : f64
    %101 = qlx.apply #qlx.action<pauli_rotation>(%100, %cst_55) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %102 = qlx.apply #qlx.action<h>(%101) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_56 = arith.constant 1.5707963267948966 : f64
    %103:2 = qlx.apply #qlx.action<pauli_rotation>(%99, %102, %cst_56) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_57 = arith.constant 1.5707963267948966 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%103#0, %cst_57) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %105 = qlx.apply #qlx.action<pauli_rotation>(%103#1, %cst_58) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%104, %105, %cst_59) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %107 = qlx.apply #qlx.action<h>(%106#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_60 = arith.constant 3.1415926535897931 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%107, %cst_60) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %109 = qlx.apply #qlx.action<h>(%108) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %110 = qlx.apply #qlx.action<h>(%40#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_61 = arith.constant 3.1415926535897931 : f64
    %111 = qlx.apply #qlx.action<pauli_rotation>(%110, %cst_61) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %112 = qlx.apply #qlx.action<h>(%111) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %113:2 = qlx.apply #qlx.action<pauli_rotation>(%109, %112, %cst_62) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_63 = arith.constant 1.5707963267948966 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113#0, %cst_63) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_64 = arith.constant 1.5707963267948966 : f64
    %115 = qlx.apply #qlx.action<pauli_rotation>(%113#1, %cst_64) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %116:2 = qlx.apply #qlx.action<pauli_rotation>(%114, %115, %cst_65) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %117 = qlx.apply #qlx.action<h>(%116#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_66 = arith.constant 3.1415926535897931 : f64
    %118 = qlx.apply #qlx.action<pauli_rotation>(%117, %cst_66) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %119 = qlx.apply #qlx.action<h>(%118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %120 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %121 = qlx.apply #qlx.action<h>(%120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_67 = arith.constant 1.4457963267948966 : f64
    %122:2 = qlx.apply #qlx.action<pauli_rotation>(%121, %119, %cst_67) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_68 = arith.constant 1.5707963267948966 : f64
    %123 = qlx.apply #qlx.action<pauli_rotation>(%122#1, %cst_68) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%122#0, %cst_69) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_70 = arith.constant 1.4457963267948966 : f64
    %125:2 = qlx.apply #qlx.action<pauli_rotation>(%123, %124, %cst_70) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %126 = qlx.apply #qlx.action<h>(%96#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_71 = arith.constant 3.1415926535897931 : f64
    %127 = qlx.apply #qlx.action<pauli_rotation>(%126, %cst_71) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %128 = qlx.apply #qlx.action<h>(%127) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %129 = qlx.apply #qlx.action<h>(%106#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_72 = arith.constant 3.1415926535897931 : f64
    %130 = qlx.apply #qlx.action<pauli_rotation>(%129, %cst_72) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %131 = qlx.apply #qlx.action<h>(%130) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_73 = arith.constant 1.5707963267948966 : f64
    %132:2 = qlx.apply #qlx.action<pauli_rotation>(%128, %131, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 1.5707963267948966 : f64
    %133 = qlx.apply #qlx.action<pauli_rotation>(%132#0, %cst_74) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %134 = qlx.apply #qlx.action<pauli_rotation>(%132#1, %cst_75) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %135:2 = qlx.apply #qlx.action<pauli_rotation>(%133, %134, %cst_76) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %136 = qlx.apply #qlx.action<h>(%76#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_77 = arith.constant 3.1415926535897931 : f64
    %137 = qlx.apply #qlx.action<pauli_rotation>(%136, %cst_77) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %138 = qlx.apply #qlx.action<h>(%137) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %139 = qlx.apply #qlx.action<h>(%135#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_78 = arith.constant 3.1415926535897931 : f64
    %140 = qlx.apply #qlx.action<pauli_rotation>(%139, %cst_78) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %141 = qlx.apply #qlx.action<h>(%140) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 1.4457963267948966 : f64
    %142:2 = qlx.apply #qlx.action<pauli_rotation>(%138, %141, %cst_79) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_80 = arith.constant 1.5707963267948966 : f64
    %143 = qlx.apply #qlx.action<pauli_rotation>(%142#0, %cst_80) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%142#1, %cst_81) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_82 = arith.constant 1.4457963267948966 : f64
    %145:2 = qlx.apply #qlx.action<pauli_rotation>(%143, %144, %cst_82) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %146 = qlx.apply #qlx.action<h>(%135#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %147 = qlx.apply #qlx.action<pauli_rotation>(%146, %cst_83) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %148 = qlx.apply #qlx.action<h>(%147) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %149 = qlx.apply #qlx.action<h>(%116#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %150 = qlx.apply #qlx.action<pauli_rotation>(%149, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %151 = qlx.apply #qlx.action<h>(%150) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 1.250000e-01 : f64
    %152:2 = qlx.apply #qlx.action<pauli_rotation>(%148, %151, %cst_85) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_86 = arith.constant 1.5707963267948966 : f64
    %153 = qlx.apply #qlx.action<pauli_rotation>(%152#0, %cst_86) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %154 = qlx.apply #qlx.action<pauli_rotation>(%152#1, %cst_87) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_88 = arith.constant 1.250000e-01 : f64
    %155:2 = qlx.apply #qlx.action<pauli_rotation>(%153, %154, %cst_88) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %156 = qlx.apply #qlx.action<h>(%86#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %157 = qlx.apply #qlx.action<pauli_rotation>(%156, %cst_89) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %158 = qlx.apply #qlx.action<h>(%157) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %159 = qlx.apply #qlx.action<h>(%145#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %160 = qlx.apply #qlx.action<pauli_rotation>(%159, %cst_90) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %161 = qlx.apply #qlx.action<h>(%160) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_91 = arith.constant 1.250000e-01 : f64
    %162:2 = qlx.apply #qlx.action<pauli_rotation>(%158, %161, %cst_91) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_92 = arith.constant 1.5707963267948966 : f64
    %163 = qlx.apply #qlx.action<pauli_rotation>(%162#0, %cst_92) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %164 = qlx.apply #qlx.action<pauli_rotation>(%162#1, %cst_93) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_94 = arith.constant 1.250000e-01 : f64
    %165:2 = qlx.apply #qlx.action<pauli_rotation>(%163, %164, %cst_94) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %166 = qlx.apply #qlx.action<h>(%155#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %167 = qlx.apply #qlx.action<pauli_rotation>(%166, %cst_95) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %168 = qlx.apply #qlx.action<h>(%167) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %169 = qlx.apply #qlx.action<h>(%125#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %170 = qlx.apply #qlx.action<pauli_rotation>(%169, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %171 = qlx.apply #qlx.action<h>(%170) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_97 = arith.constant 1.250000e-01 : f64
    %172:2 = qlx.apply #qlx.action<pauli_rotation>(%168, %171, %cst_97) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_98 = arith.constant 1.5707963267948966 : f64
    %173 = qlx.apply #qlx.action<pauli_rotation>(%172#0, %cst_98) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %174 = qlx.apply #qlx.action<pauli_rotation>(%172#1, %cst_99) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_100 = arith.constant 1.250000e-01 : f64
    %175:2 = qlx.apply #qlx.action<pauli_rotation>(%173, %174, %cst_100) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %176 = qlx.apply #qlx.action<h>(%145#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_101 = arith.constant 3.1415926535897931 : f64
    %177 = qlx.apply #qlx.action<pauli_rotation>(%176, %cst_101) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %178 = qlx.apply #qlx.action<h>(%155#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_102 = arith.constant 2.500000e-01 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%177, %178, %cst_102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %180 = qlx.apply #qlx.action<h>(%165#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_103 = arith.constant 3.1415926535897931 : f64
    %181 = qlx.apply #qlx.action<pauli_rotation>(%180, %cst_103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %182 = qlx.apply #qlx.action<h>(%181) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %183 = qlx.apply #qlx.action<h>(%179#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_104 = arith.constant 1.5707963267948966 : f64
    %184:2 = qlx.apply #qlx.action<pauli_rotation>(%182, %183, %cst_104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_105 = arith.constant 1.5707963267948966 : f64
    %185 = qlx.apply #qlx.action<pauli_rotation>(%184#0, %cst_105) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_106 = arith.constant 1.5707963267948966 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%184#1, %cst_106) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_107 = arith.constant 1.5707963267948966 : f64
    %187:2 = qlx.apply #qlx.action<pauli_rotation>(%185, %186, %cst_107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %188 = qlx.apply #qlx.action<h>(%179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_108 = arith.constant 1.5707963267948966 : f64
    %189:2 = qlx.apply #qlx.action<pauli_rotation>(%175#0, %188, %cst_108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_109 = arith.constant 1.5707963267948966 : f64
    %190 = qlx.apply #qlx.action<pauli_rotation>(%189#1, %cst_109) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_110 = arith.constant 1.5707963267948966 : f64
    %191 = qlx.apply #qlx.action<pauli_rotation>(%189#0, %cst_110) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_111 = arith.constant 1.5707963267948966 : f64
    %192:2 = qlx.apply #qlx.action<pauli_rotation>(%190, %191, %cst_111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %193 = qlx.apply #qlx.action<h>(%187#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 3.1415926535897931 : f64
    %194 = qlx.apply #qlx.action<pauli_rotation>(%193, %cst_112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %195 = qlx.apply #qlx.action<h>(%192#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_113 = arith.constant 3.1415926535897931 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%195, %cst_113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 2.500000e-01 : f64
    %197:2 = qlx.apply #qlx.action<pauli_rotation>(%194, %196, %cst_114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %198 = qlx.apply #qlx.action<h>(%187#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_115 = arith.constant 3.1415926535897931 : f64
    %199 = qlx.apply #qlx.action<pauli_rotation>(%198, %cst_115) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %200 = qlx.apply #qlx.action<h>(%199) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %201:2 = qlx.apply #qlx.action<pauli_rotation>(%165#0, %200, %cst_116) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %202 = qlx.apply #qlx.action<pauli_rotation>(%201#0, %cst_117) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%201#1, %cst_118) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %204:2 = qlx.apply #qlx.action<pauli_rotation>(%202, %203, %cst_119) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %205 = qlx.apply #qlx.action<h>(%204#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_120 = arith.constant 3.1415926535897931 : f64
    %206 = qlx.apply #qlx.action<pauli_rotation>(%205, %cst_120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %208 = qlx.apply #qlx.action<h>(%197#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %209:2 = qlx.apply #qlx.action<pauli_rotation>(%207, %208, %cst_121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %210 = qlx.apply #qlx.action<pauli_rotation>(%209#0, %cst_122) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %211 = qlx.apply #qlx.action<pauli_rotation>(%209#1, %cst_123) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %212:2 = qlx.apply #qlx.action<pauli_rotation>(%210, %211, %cst_124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %213 = qlx.apply #qlx.action<h>(%192#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_125 = arith.constant 3.1415926535897931 : f64
    %214 = qlx.apply #qlx.action<pauli_rotation>(%213, %cst_125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %215 = qlx.apply #qlx.action<h>(%214) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %216 = qlx.apply #qlx.action<h>(%175#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_126 = arith.constant 3.1415926535897931 : f64
    %217 = qlx.apply #qlx.action<pauli_rotation>(%216, %cst_126) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %218 = qlx.apply #qlx.action<h>(%217) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 1.5707963267948966 : f64
    %219:2 = qlx.apply #qlx.action<pauli_rotation>(%215, %218, %cst_127) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_128 = arith.constant 1.5707963267948966 : f64
    %220 = qlx.apply #qlx.action<pauli_rotation>(%219#0, %cst_128) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %221 = qlx.apply #qlx.action<pauli_rotation>(%219#1, %cst_129) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %222:2 = qlx.apply #qlx.action<pauli_rotation>(%220, %221, %cst_130) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %223 = qlx.apply #qlx.action<h>(%197#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %224 = qlx.apply #qlx.action<h>(%222#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_131 = arith.constant 3.1415926535897931 : f64
    %225 = qlx.apply #qlx.action<pauli_rotation>(%224, %cst_131) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %226 = qlx.apply #qlx.action<h>(%225) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %227:2 = qlx.apply #qlx.action<pauli_rotation>(%223, %226, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_133 = arith.constant 1.5707963267948966 : f64
    %228 = qlx.apply #qlx.action<pauli_rotation>(%227#0, %cst_133) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_134 = arith.constant 1.5707963267948966 : f64
    %229 = qlx.apply #qlx.action<pauli_rotation>(%227#1, %cst_134) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %230:2 = qlx.apply #qlx.action<pauli_rotation>(%228, %229, %cst_135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %231 = qlx.apply #qlx.action<h>(%212#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_136 = arith.constant 3.1415926535897931 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231, %cst_136) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<h>(%230#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_137 = arith.constant 3.1415926535897931 : f64
    %234 = qlx.apply #qlx.action<pauli_rotation>(%233, %cst_137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_138 = arith.constant 5.000000e-01 : f64
    %235:2 = qlx.apply #qlx.action<pauli_rotation>(%232, %234, %cst_138) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %236 = qlx.apply #qlx.action<h>(%212#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_139 = arith.constant 3.1415926535897931 : f64
    %237 = qlx.apply #qlx.action<pauli_rotation>(%236, %cst_139) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<h>(%237) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %239 = qlx.apply #qlx.action<h>(%235#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_140 = arith.constant 1.5707963267948966 : f64
    %240:2 = qlx.apply #qlx.action<pauli_rotation>(%238, %239, %cst_140) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %241 = qlx.apply #qlx.action<pauli_rotation>(%240#0, %cst_141) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_142 = arith.constant 1.5707963267948966 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%240#1, %cst_142) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %243:2 = qlx.apply #qlx.action<pauli_rotation>(%241, %242, %cst_143) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %244 = qlx.apply #qlx.action<h>(%235#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %245 = qlx.apply #qlx.action<h>(%230#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_144 = arith.constant 3.1415926535897931 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%245, %cst_144) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %247 = qlx.apply #qlx.action<h>(%246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_145 = arith.constant 1.5707963267948966 : f64
    %248:2 = qlx.apply #qlx.action<pauli_rotation>(%244, %247, %cst_145) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_146 = arith.constant 1.5707963267948966 : f64
    %249 = qlx.apply #qlx.action<pauli_rotation>(%248#0, %cst_146) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_147 = arith.constant 1.5707963267948966 : f64
    %250 = qlx.apply #qlx.action<pauli_rotation>(%248#1, %cst_147) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %251:2 = qlx.apply #qlx.action<pauli_rotation>(%249, %250, %cst_148) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %252 = qlx.apply #qlx.action<h>(%243#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_149 = arith.constant 3.1415926535897931 : f64
    %253 = qlx.apply #qlx.action<pauli_rotation>(%252, %cst_149) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %254 = qlx.apply #qlx.action<h>(%251#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_150 = arith.constant 3.1415926535897931 : f64
    %255 = qlx.apply #qlx.action<pauli_rotation>(%254, %cst_150) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_151 = arith.constant 2.500000e-01 : f64
    %256:2 = qlx.apply #qlx.action<pauli_rotation>(%253, %255, %cst_151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<h>(%204#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_152 = arith.constant 3.1415926535897931 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%257, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<h>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%243#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_153 = arith.constant 3.1415926535897931 : f64
    %261 = qlx.apply #qlx.action<pauli_rotation>(%260, %cst_153) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %262 = qlx.apply #qlx.action<h>(%261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %263:2 = qlx.apply #qlx.action<pauli_rotation>(%259, %262, %cst_154) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %264 = qlx.apply #qlx.action<pauli_rotation>(%263#0, %cst_155) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_156 = arith.constant 1.5707963267948966 : f64
    %265 = qlx.apply #qlx.action<pauli_rotation>(%263#1, %cst_156) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_157 = arith.constant 1.5707963267948966 : f64
    %266:2 = qlx.apply #qlx.action<pauli_rotation>(%264, %265, %cst_157) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %267 = qlx.apply #qlx.action<h>(%266#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_158 = arith.constant 3.1415926535897931 : f64
    %268 = qlx.apply #qlx.action<pauli_rotation>(%267, %cst_158) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %269 = qlx.apply #qlx.action<h>(%268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %270 = qlx.apply #qlx.action<h>(%256#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_159 = arith.constant 1.5707963267948966 : f64
    %271:2 = qlx.apply #qlx.action<pauli_rotation>(%269, %270, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %272 = qlx.apply #qlx.action<pauli_rotation>(%271#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.5707963267948966 : f64
    %273 = qlx.apply #qlx.action<pauli_rotation>(%271#1, %cst_161) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 1.5707963267948966 : f64
    %274:2 = qlx.apply #qlx.action<pauli_rotation>(%272, %273, %cst_162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %275 = qlx.apply #qlx.action<h>(%251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 3.1415926535897931 : f64
    %276 = qlx.apply #qlx.action<pauli_rotation>(%275, %cst_163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %277 = qlx.apply #qlx.action<h>(%276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %278 = qlx.apply #qlx.action<h>(%222#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_164 = arith.constant 3.1415926535897931 : f64
    %279 = qlx.apply #qlx.action<pauli_rotation>(%278, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %280 = qlx.apply #qlx.action<h>(%279) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 1.5707963267948966 : f64
    %281:2 = qlx.apply #qlx.action<pauli_rotation>(%277, %280, %cst_165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %282 = qlx.apply #qlx.action<pauli_rotation>(%281#0, %cst_166) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %283 = qlx.apply #qlx.action<pauli_rotation>(%281#1, %cst_167) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_168 = arith.constant 1.5707963267948966 : f64
    %284:2 = qlx.apply #qlx.action<pauli_rotation>(%282, %283, %cst_168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %285 = qlx.apply #qlx.action<h>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %286 = qlx.apply #qlx.action<h>(%284#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 3.1415926535897931 : f64
    %287 = qlx.apply #qlx.action<pauli_rotation>(%286, %cst_169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %288 = qlx.apply #qlx.action<h>(%287) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_170 = arith.constant 1.5707963267948966 : f64
    %289:2 = qlx.apply #qlx.action<pauli_rotation>(%285, %288, %cst_170) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_171 = arith.constant 1.5707963267948966 : f64
    %290 = qlx.apply #qlx.action<pauli_rotation>(%289#0, %cst_171) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %291 = qlx.apply #qlx.action<pauli_rotation>(%289#1, %cst_172) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_173 = arith.constant 1.5707963267948966 : f64
    %292:2 = qlx.apply #qlx.action<pauli_rotation>(%290, %291, %cst_173) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %293 = qlx.apply #qlx.action<h>(%274#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_174 = arith.constant 3.1415926535897931 : f64
    %294 = qlx.apply #qlx.action<pauli_rotation>(%293, %cst_174) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %295 = qlx.apply #qlx.action<h>(%292#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 3.1415926535897931 : f64
    %296 = qlx.apply #qlx.action<pauli_rotation>(%295, %cst_175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_176 = arith.constant 2.500000e-01 : f64
    %297:2 = qlx.apply #qlx.action<pauli_rotation>(%294, %296, %cst_176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %298 = qlx.apply #qlx.action<h>(%292#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_177 = arith.constant 1.5707963267948966 : f64
    %299 = qlx.apply #qlx.action<pauli_rotation>(%298, %cst_177) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %300 = qlx.apply #qlx.action<h>(%299) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %301 = qlx.apply #qlx.action<h>(%284#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %302 = qlx.apply #qlx.action<pauli_rotation>(%301, %cst_178) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %303 = qlx.apply #qlx.action<h>(%302) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_179 = arith.constant 1.250000e-01 : f64
    %304:2 = qlx.apply #qlx.action<pauli_rotation>(%300, %303, %cst_179) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_180 = arith.constant 1.5707963267948966 : f64
    %305 = qlx.apply #qlx.action<pauli_rotation>(%304#0, %cst_180) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_181 = arith.constant 1.5707963267948966 : f64
    %306 = qlx.apply #qlx.action<pauli_rotation>(%304#1, %cst_181) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_182 = arith.constant 1.250000e-01 : f64
    %307:2 = qlx.apply #qlx.action<pauli_rotation>(%305, %306, %cst_182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %308 = qlx.apply #qlx.action<h>(%266#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_183 = arith.constant 1.5707963267948966 : f64
    %309 = qlx.apply #qlx.action<pauli_rotation>(%308, %cst_183) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %310 = qlx.apply #qlx.action<h>(%309) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %311 = qlx.apply #qlx.action<h>(%274#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %312 = qlx.apply #qlx.action<pauli_rotation>(%311, %cst_184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %313 = qlx.apply #qlx.action<h>(%312) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.250000e-01 : f64
    %314:2 = qlx.apply #qlx.action<pauli_rotation>(%310, %313, %cst_185) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_186 = arith.constant 1.5707963267948966 : f64
    %315 = qlx.apply #qlx.action<pauli_rotation>(%314#0, %cst_186) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_187 = arith.constant 1.5707963267948966 : f64
    %316 = qlx.apply #qlx.action<pauli_rotation>(%314#1, %cst_187) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_188 = arith.constant 1.250000e-01 : f64
    %317:2 = qlx.apply #qlx.action<pauli_rotation>(%315, %316, %cst_188) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_189 = arith.constant 1.5707963267948966 : f64
    %318 = qlx.apply #qlx.action<pauli_rotation>(%297#1, %cst_189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %319 = qlx.apply #qlx.action<h>(%318) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %320 = qlx.apply #qlx.action<h>(%307#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %321 = qlx.apply #qlx.action<pauli_rotation>(%320, %cst_190) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %322 = qlx.apply #qlx.action<h>(%321) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_191 = arith.constant 1.250000e-01 : f64
    %323:2 = qlx.apply #qlx.action<pauli_rotation>(%319, %322, %cst_191) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_192 = arith.constant 1.5707963267948966 : f64
    %324 = qlx.apply #qlx.action<pauli_rotation>(%323#0, %cst_192) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %325 = qlx.apply #qlx.action<pauli_rotation>(%323#1, %cst_193) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_194 = arith.constant 1.250000e-01 : f64
    %326:2 = qlx.apply #qlx.action<pauli_rotation>(%324, %325, %cst_194) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %327 = qlx.apply #qlx.action<h>(%317#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_195 = arith.constant 1.5707963267948966 : f64
    %328 = qlx.apply #qlx.action<pauli_rotation>(%327, %cst_195) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %329 = qlx.apply #qlx.action<h>(%328) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %330 = qlx.apply #qlx.action<pauli_rotation>(%297#0, %cst_196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %331 = qlx.apply #qlx.action<h>(%330) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.250000e-01 : f64
    %332:2 = qlx.apply #qlx.action<pauli_rotation>(%329, %331, %cst_197) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_198 = arith.constant 1.5707963267948966 : f64
    %333 = qlx.apply #qlx.action<pauli_rotation>(%332#0, %cst_198) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_199 = arith.constant 1.5707963267948966 : f64
    %334 = qlx.apply #qlx.action<pauli_rotation>(%332#1, %cst_199) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_200 = arith.constant 1.250000e-01 : f64
    %335:2 = qlx.apply #qlx.action<pauli_rotation>(%333, %334, %cst_200) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %336 = qlx.apply #qlx.action<h>(%307#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 3.1415926535897931 : f64
    %337 = qlx.apply #qlx.action<pauli_rotation>(%336, %cst_201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %338 = qlx.apply #qlx.action<h>(%337) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %339 = qlx.apply #qlx.action<h>(%125#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_202 = arith.constant 3.1415926535897931 : f64
    %340 = qlx.apply #qlx.action<pauli_rotation>(%339, %cst_202) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %341 = qlx.apply #qlx.action<h>(%340) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.4457963267948966 : f64
    %342:2 = qlx.apply #qlx.action<pauli_rotation>(%338, %341, %cst_203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_204 = arith.constant 1.5707963267948966 : f64
    %343 = qlx.apply #qlx.action<pauli_rotation>(%342#0, %cst_204) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_205 = arith.constant 1.5707963267948966 : f64
    %344 = qlx.apply #qlx.action<pauli_rotation>(%342#1, %cst_205) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_206 = arith.constant 1.4457963267948966 : f64
    %345:2 = qlx.apply #qlx.action<pauli_rotation>(%343, %344, %cst_206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_207 = arith.constant 1.4457963267948966 : f64
    %346:2 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %317#0, %cst_207) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %347 = qlx.apply #qlx.action<pauli_rotation>(%346#0, %cst_208) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %348 = qlx.apply #qlx.action<pauli_rotation>(%346#1, %cst_209) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.4457963267948966 : f64
    %349:2 = qlx.apply #qlx.action<pauli_rotation>(%347, %348, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %350 = qlx.apply #qlx.action<h>(%326#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_211 = arith.constant 3.1415926535897931 : f64
    %351 = qlx.apply #qlx.action<pauli_rotation>(%350, %cst_211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %352 = qlx.apply #qlx.action<h>(%351) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %353 = qlx.apply #qlx.action<h>(%345#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 3.1415926535897931 : f64
    %354 = qlx.apply #qlx.action<pauli_rotation>(%353, %cst_212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %355 = qlx.apply #qlx.action<h>(%354) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 1.5707963267948966 : f64
    %356:2 = qlx.apply #qlx.action<pauli_rotation>(%352, %355, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %357 = qlx.apply #qlx.action<pauli_rotation>(%356#0, %cst_214) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %358 = qlx.apply #qlx.action<pauli_rotation>(%356#1, %cst_215) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %359:2 = qlx.apply #qlx.action<pauli_rotation>(%357, %358, %cst_216) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %360 = qlx.apply #qlx.action<h>(%359#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_217 = arith.constant 3.1415926535897931 : f64
    %361 = qlx.apply #qlx.action<pauli_rotation>(%360, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %362 = qlx.apply #qlx.action<h>(%361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_218 = arith.constant 1.4457963267948966 : f64
    %363:2 = qlx.apply #qlx.action<pauli_rotation>(%326#0, %362, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_219 = arith.constant 1.5707963267948966 : f64
    %364 = qlx.apply #qlx.action<pauli_rotation>(%363#0, %cst_219) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %365 = qlx.apply #qlx.action<pauli_rotation>(%363#1, %cst_220) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_221 = arith.constant 1.4457963267948966 : f64
    %366:2 = qlx.apply #qlx.action<pauli_rotation>(%364, %365, %cst_221) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %367 = qlx.apply #qlx.action<h>(%349#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_222 = arith.constant 3.1415926535897931 : f64
    %368 = qlx.apply #qlx.action<pauli_rotation>(%367, %cst_222) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %369 = qlx.apply #qlx.action<h>(%368) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_223 = arith.constant 1.5707963267948966 : f64
    %370:2 = qlx.apply #qlx.action<pauli_rotation>(%335#0, %369, %cst_223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_224 = arith.constant 1.5707963267948966 : f64
    %371 = qlx.apply #qlx.action<pauli_rotation>(%370#1, %cst_224) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_225 = arith.constant 1.5707963267948966 : f64
    %372 = qlx.apply #qlx.action<pauli_rotation>(%370#0, %cst_225) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %373:2 = qlx.apply #qlx.action<pauli_rotation>(%371, %372, %cst_226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %374 = qlx.apply #qlx.action<h>(%373#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_227 = arith.constant 3.1415926535897931 : f64
    %375 = qlx.apply #qlx.action<pauli_rotation>(%374, %cst_227) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %376 = qlx.apply #qlx.action<h>(%375) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %377 = qlx.apply #qlx.action<h>(%335#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_228 = arith.constant 3.1415926535897931 : f64
    %378 = qlx.apply #qlx.action<pauli_rotation>(%377, %cst_228) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %379 = qlx.apply #qlx.action<h>(%378) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_229 = arith.constant 1.4457963267948966 : f64
    %380:2 = qlx.apply #qlx.action<pauli_rotation>(%376, %379, %cst_229) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_230 = arith.constant 1.5707963267948966 : f64
    %381 = qlx.apply #qlx.action<pauli_rotation>(%380#0, %cst_230) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %382 = qlx.apply #qlx.action<pauli_rotation>(%380#1, %cst_231) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_232 = arith.constant 1.4457963267948966 : f64
    %383:2 = qlx.apply #qlx.action<pauli_rotation>(%381, %382, %cst_232) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %384 = qlx.apply #qlx.action<h>(%383#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_233 = arith.constant 3.1415926535897931 : f64
    %385 = qlx.apply #qlx.action<pauli_rotation>(%384, %cst_233) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %386 = qlx.apply #qlx.action<h>(%366#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_234 = arith.constant 3.1415926535897931 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%386, %cst_234) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_235 = arith.constant 5.000000e-01 : f64
    %388:2 = qlx.apply #qlx.action<pauli_rotation>(%385, %387, %cst_235) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %389 = qlx.apply #qlx.action<h>(%383#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 3.1415926535897931 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%389, %cst_236) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %392 = qlx.apply #qlx.action<h>(%388#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_237 = arith.constant 1.4457963267948966 : f64
    %393:2 = qlx.apply #qlx.action<pauli_rotation>(%391, %392, %cst_237) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_238 = arith.constant 1.5707963267948966 : f64
    %394 = qlx.apply #qlx.action<pauli_rotation>(%393#0, %cst_238) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %395 = qlx.apply #qlx.action<pauli_rotation>(%393#1, %cst_239) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_240 = arith.constant 1.4457963267948966 : f64
    %396:2 = qlx.apply #qlx.action<pauli_rotation>(%394, %395, %cst_240) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %397 = qlx.apply #qlx.action<h>(%388#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %398 = qlx.apply #qlx.action<h>(%366#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 3.1415926535897931 : f64
    %399 = qlx.apply #qlx.action<pauli_rotation>(%398, %cst_241) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %400 = qlx.apply #qlx.action<h>(%399) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_242 = arith.constant 1.4457963267948966 : f64
    %401:2 = qlx.apply #qlx.action<pauli_rotation>(%397, %400, %cst_242) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_243 = arith.constant 1.5707963267948966 : f64
    %402 = qlx.apply #qlx.action<pauli_rotation>(%401#0, %cst_243) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_244 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%401#1, %cst_244) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_245 = arith.constant 1.4457963267948966 : f64
    %404:2 = qlx.apply #qlx.action<pauli_rotation>(%402, %403, %cst_245) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %405 = qlx.apply #qlx.action<h>(%373#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_246 = arith.constant 3.1415926535897931 : f64
    %406 = qlx.apply #qlx.action<pauli_rotation>(%405, %cst_246) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %407 = qlx.apply #qlx.action<h>(%406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %408 = qlx.apply #qlx.action<h>(%396#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_247 = arith.constant 3.1415926535897931 : f64
    %409 = qlx.apply #qlx.action<pauli_rotation>(%408, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %410 = qlx.apply #qlx.action<h>(%409) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_248 = arith.constant 1.5707963267948966 : f64
    %411:2 = qlx.apply #qlx.action<pauli_rotation>(%407, %410, %cst_248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_249 = arith.constant 1.5707963267948966 : f64
    %412 = qlx.apply #qlx.action<pauli_rotation>(%411#0, %cst_249) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_250 = arith.constant 1.5707963267948966 : f64
    %413 = qlx.apply #qlx.action<pauli_rotation>(%411#1, %cst_250) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_251 = arith.constant 1.5707963267948966 : f64
    %414:2 = qlx.apply #qlx.action<pauli_rotation>(%412, %413, %cst_251) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %415 = qlx.apply #qlx.action<h>(%349#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_252 = arith.constant 3.1415926535897931 : f64
    %416 = qlx.apply #qlx.action<pauli_rotation>(%415, %cst_252) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %417 = qlx.apply #qlx.action<h>(%416) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %418 = qlx.apply #qlx.action<h>(%414#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_253 = arith.constant 3.1415926535897931 : f64
    %419 = qlx.apply #qlx.action<pauli_rotation>(%418, %cst_253) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %420 = qlx.apply #qlx.action<h>(%419) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_254 = arith.constant 1.4457963267948966 : f64
    %421:2 = qlx.apply #qlx.action<pauli_rotation>(%417, %420, %cst_254) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_255 = arith.constant 1.5707963267948966 : f64
    %422 = qlx.apply #qlx.action<pauli_rotation>(%421#0, %cst_255) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %423 = qlx.apply #qlx.action<pauli_rotation>(%421#1, %cst_256) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.4457963267948966 : f64
    %424:2 = qlx.apply #qlx.action<pauli_rotation>(%422, %423, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %425 = qlx.apply #qlx.action<h>(%404#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_258 = arith.constant 3.1415926535897931 : f64
    %426 = qlx.apply #qlx.action<pauli_rotation>(%425, %cst_258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %427 = qlx.apply #qlx.action<h>(%426) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %428 = qlx.apply #qlx.action<h>(%359#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_259 = arith.constant 3.1415926535897931 : f64
    %429 = qlx.apply #qlx.action<pauli_rotation>(%428, %cst_259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %430 = qlx.apply #qlx.action<h>(%429) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %431:2 = qlx.apply #qlx.action<pauli_rotation>(%427, %430, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_261 = arith.constant 1.5707963267948966 : f64
    %432 = qlx.apply #qlx.action<pauli_rotation>(%431#0, %cst_261) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %433 = qlx.apply #qlx.action<pauli_rotation>(%431#1, %cst_262) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %434:2 = qlx.apply #qlx.action<pauli_rotation>(%432, %433, %cst_263) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %435 = qlx.apply #qlx.action<h>(%434#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_264 = arith.constant 3.1415926535897931 : f64
    %436 = qlx.apply #qlx.action<pauli_rotation>(%435, %cst_264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %437 = qlx.apply #qlx.action<h>(%436) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %438 = qlx.apply #qlx.action<h>(%345#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_265 = arith.constant 3.1415926535897931 : f64
    %439 = qlx.apply #qlx.action<pauli_rotation>(%438, %cst_265) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %440 = qlx.apply #qlx.action<h>(%439) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_266 = arith.constant 1.4457963267948966 : f64
    %441:2 = qlx.apply #qlx.action<pauli_rotation>(%437, %440, %cst_266) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %442 = qlx.apply #qlx.action<pauli_rotation>(%441#0, %cst_267) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %443 = qlx.apply #qlx.action<pauli_rotation>(%441#1, %cst_268) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_269 = arith.constant 1.4457963267948966 : f64
    %444:2 = qlx.apply #qlx.action<pauli_rotation>(%442, %443, %cst_269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %445 = qlx.apply #qlx.action<h>(%414#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_270 = arith.constant 1.5707963267948966 : f64
    %446 = qlx.apply #qlx.action<pauli_rotation>(%445, %cst_270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %447 = qlx.apply #qlx.action<h>(%446) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %448 = qlx.apply #qlx.action<h>(%396#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_271 = arith.constant 1.5707963267948966 : f64
    %449 = qlx.apply #qlx.action<pauli_rotation>(%448, %cst_271) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %450 = qlx.apply #qlx.action<h>(%449) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_272 = arith.constant 1.250000e-01 : f64
    %451:2 = qlx.apply #qlx.action<pauli_rotation>(%447, %450, %cst_272) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %452 = qlx.apply #qlx.action<pauli_rotation>(%451#0, %cst_273) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %453 = qlx.apply #qlx.action<pauli_rotation>(%451#1, %cst_274) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.250000e-01 : f64
    %454:2 = qlx.apply #qlx.action<pauli_rotation>(%452, %453, %cst_275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %455 = qlx.apply #qlx.action<h>(%404#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %456 = qlx.apply #qlx.action<pauli_rotation>(%455, %cst_276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %457 = qlx.apply #qlx.action<h>(%456) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %458 = qlx.apply #qlx.action<h>(%434#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 1.5707963267948966 : f64
    %459 = qlx.apply #qlx.action<pauli_rotation>(%458, %cst_277) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %460 = qlx.apply #qlx.action<h>(%459) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 1.250000e-01 : f64
    %461:2 = qlx.apply #qlx.action<pauli_rotation>(%457, %460, %cst_278) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %462 = qlx.apply #qlx.action<pauli_rotation>(%461#0, %cst_279) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %463 = qlx.apply #qlx.action<pauli_rotation>(%461#1, %cst_280) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_281 = arith.constant 1.250000e-01 : f64
    %464:2 = qlx.apply #qlx.action<pauli_rotation>(%462, %463, %cst_281) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %465 = qlx.apply #qlx.action<h>(%424#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_282 = arith.constant 1.5707963267948966 : f64
    %466 = qlx.apply #qlx.action<pauli_rotation>(%465, %cst_282) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %467 = qlx.apply #qlx.action<h>(%466) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %468 = qlx.apply #qlx.action<h>(%454#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_283 = arith.constant 1.5707963267948966 : f64
    %469 = qlx.apply #qlx.action<pauli_rotation>(%468, %cst_283) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %470 = qlx.apply #qlx.action<h>(%469) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_284 = arith.constant 1.250000e-01 : f64
    %471:2 = qlx.apply #qlx.action<pauli_rotation>(%467, %470, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_285 = arith.constant 1.5707963267948966 : f64
    %472 = qlx.apply #qlx.action<pauli_rotation>(%471#0, %cst_285) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %473 = qlx.apply #qlx.action<pauli_rotation>(%471#1, %cst_286) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.250000e-01 : f64
    %474:2 = qlx.apply #qlx.action<pauli_rotation>(%472, %473, %cst_287) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %475 = qlx.apply #qlx.action<h>(%464#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_288 = arith.constant 1.5707963267948966 : f64
    %476 = qlx.apply #qlx.action<pauli_rotation>(%475, %cst_288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %477 = qlx.apply #qlx.action<h>(%476) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %478 = qlx.apply #qlx.action<h>(%444#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 1.5707963267948966 : f64
    %479 = qlx.apply #qlx.action<pauli_rotation>(%478, %cst_289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %480 = qlx.apply #qlx.action<h>(%479) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_290 = arith.constant 1.250000e-01 : f64
    %481:2 = qlx.apply #qlx.action<pauli_rotation>(%477, %480, %cst_290) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_291 = arith.constant 1.5707963267948966 : f64
    %482 = qlx.apply #qlx.action<pauli_rotation>(%481#0, %cst_291) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_292 = arith.constant 1.5707963267948966 : f64
    %483 = qlx.apply #qlx.action<pauli_rotation>(%481#1, %cst_292) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_293 = arith.constant 1.250000e-01 : f64
    %484:2 = qlx.apply #qlx.action<pauli_rotation>(%482, %483, %cst_293) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %485 = qlx.apply #qlx.action<h>(%454#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_294 = arith.constant 3.1415926535897931 : f64
    %486 = qlx.apply #qlx.action<pauli_rotation>(%485, %cst_294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %487 = qlx.apply #qlx.action<h>(%464#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 2.500000e-01 : f64
    %488:2 = qlx.apply #qlx.action<pauli_rotation>(%486, %487, %cst_295) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %489 = qlx.apply #qlx.action<h>(%474#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_296 = arith.constant 3.1415926535897931 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%489, %cst_296) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %491 = qlx.apply #qlx.action<h>(%490) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %492 = qlx.apply #qlx.action<h>(%488#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_297 = arith.constant 1.5707963267948966 : f64
    %493:2 = qlx.apply #qlx.action<pauli_rotation>(%491, %492, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493#0, %cst_298) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %495 = qlx.apply #qlx.action<pauli_rotation>(%493#1, %cst_299) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_300 = arith.constant 1.5707963267948966 : f64
    %496:2 = qlx.apply #qlx.action<pauli_rotation>(%494, %495, %cst_300) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %497 = qlx.apply #qlx.action<h>(%488#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_301 = arith.constant 1.5707963267948966 : f64
    %498:2 = qlx.apply #qlx.action<pauli_rotation>(%484#0, %497, %cst_301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_302 = arith.constant 1.5707963267948966 : f64
    %499 = qlx.apply #qlx.action<pauli_rotation>(%498#1, %cst_302) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_303 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%498#0, %cst_303) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %501:2 = qlx.apply #qlx.action<pauli_rotation>(%499, %500, %cst_304) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %502 = qlx.apply #qlx.action<h>(%496#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_305 = arith.constant 3.1415926535897931 : f64
    %503 = qlx.apply #qlx.action<pauli_rotation>(%502, %cst_305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %504 = qlx.apply #qlx.action<h>(%501#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_306 = arith.constant 3.1415926535897931 : f64
    %505 = qlx.apply #qlx.action<pauli_rotation>(%504, %cst_306) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_307 = arith.constant 2.500000e-01 : f64
    %506:2 = qlx.apply #qlx.action<pauli_rotation>(%503, %505, %cst_307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %507 = qlx.apply #qlx.action<h>(%496#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_308 = arith.constant 3.1415926535897931 : f64
    %508 = qlx.apply #qlx.action<pauli_rotation>(%507, %cst_308) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %509 = qlx.apply #qlx.action<h>(%508) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_309 = arith.constant 1.5707963267948966 : f64
    %510:2 = qlx.apply #qlx.action<pauli_rotation>(%474#0, %509, %cst_309) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %511 = qlx.apply #qlx.action<pauli_rotation>(%510#0, %cst_310) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_311 = arith.constant 1.5707963267948966 : f64
    %512 = qlx.apply #qlx.action<pauli_rotation>(%510#1, %cst_311) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_312 = arith.constant 1.5707963267948966 : f64
    %513:2 = qlx.apply #qlx.action<pauli_rotation>(%511, %512, %cst_312) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %514 = qlx.apply #qlx.action<h>(%513#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 3.1415926535897931 : f64
    %515 = qlx.apply #qlx.action<pauli_rotation>(%514, %cst_313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %516 = qlx.apply #qlx.action<h>(%515) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %517 = qlx.apply #qlx.action<h>(%506#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_314 = arith.constant 1.5707963267948966 : f64
    %518:2 = qlx.apply #qlx.action<pauli_rotation>(%516, %517, %cst_314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_315 = arith.constant 1.5707963267948966 : f64
    %519 = qlx.apply #qlx.action<pauli_rotation>(%518#0, %cst_315) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%518#1, %cst_316) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_317 = arith.constant 1.5707963267948966 : f64
    %521:2 = qlx.apply #qlx.action<pauli_rotation>(%519, %520, %cst_317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %522 = qlx.apply #qlx.action<h>(%501#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_318 = arith.constant 3.1415926535897931 : f64
    %523 = qlx.apply #qlx.action<pauli_rotation>(%522, %cst_318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %524 = qlx.apply #qlx.action<h>(%523) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %525 = qlx.apply #qlx.action<h>(%484#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 3.1415926535897931 : f64
    %526 = qlx.apply #qlx.action<pauli_rotation>(%525, %cst_319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %527 = qlx.apply #qlx.action<h>(%526) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_320 = arith.constant 1.5707963267948966 : f64
    %528:2 = qlx.apply #qlx.action<pauli_rotation>(%524, %527, %cst_320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_321 = arith.constant 1.5707963267948966 : f64
    %529 = qlx.apply #qlx.action<pauli_rotation>(%528#0, %cst_321) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%528#1, %cst_322) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %531:2 = qlx.apply #qlx.action<pauli_rotation>(%529, %530, %cst_323) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %532 = qlx.apply #qlx.action<h>(%506#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %533 = qlx.apply #qlx.action<h>(%531#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_324 = arith.constant 3.1415926535897931 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%533, %cst_324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %535 = qlx.apply #qlx.action<h>(%534) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_325 = arith.constant 1.5707963267948966 : f64
    %536:2 = qlx.apply #qlx.action<pauli_rotation>(%532, %535, %cst_325) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_326 = arith.constant 1.5707963267948966 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%536#0, %cst_326) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_327 = arith.constant 1.5707963267948966 : f64
    %538 = qlx.apply #qlx.action<pauli_rotation>(%536#1, %cst_327) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %539:2 = qlx.apply #qlx.action<pauli_rotation>(%537, %538, %cst_328) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %540 = qlx.apply #qlx.action<h>(%521#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_329 = arith.constant 3.1415926535897931 : f64
    %541 = qlx.apply #qlx.action<pauli_rotation>(%540, %cst_329) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %542 = qlx.apply #qlx.action<h>(%539#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_330 = arith.constant 3.1415926535897931 : f64
    %543 = qlx.apply #qlx.action<pauli_rotation>(%542, %cst_330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_331 = arith.constant 5.000000e-01 : f64
    %544:2 = qlx.apply #qlx.action<pauli_rotation>(%541, %543, %cst_331) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %545 = qlx.apply #qlx.action<h>(%521#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_332 = arith.constant 3.1415926535897931 : f64
    %546 = qlx.apply #qlx.action<pauli_rotation>(%545, %cst_332) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %547 = qlx.apply #qlx.action<h>(%546) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %548 = qlx.apply #qlx.action<h>(%544#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_333 = arith.constant 1.5707963267948966 : f64
    %549:2 = qlx.apply #qlx.action<pauli_rotation>(%547, %548, %cst_333) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %550 = qlx.apply #qlx.action<pauli_rotation>(%549#0, %cst_334) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %551 = qlx.apply #qlx.action<pauli_rotation>(%549#1, %cst_335) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_336 = arith.constant 1.5707963267948966 : f64
    %552:2 = qlx.apply #qlx.action<pauli_rotation>(%550, %551, %cst_336) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %553 = qlx.apply #qlx.action<h>(%544#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %554 = qlx.apply #qlx.action<h>(%539#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_337 = arith.constant 3.1415926535897931 : f64
    %555 = qlx.apply #qlx.action<pauli_rotation>(%554, %cst_337) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %556 = qlx.apply #qlx.action<h>(%555) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %557:2 = qlx.apply #qlx.action<pauli_rotation>(%553, %556, %cst_338) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_339 = arith.constant 1.5707963267948966 : f64
    %558 = qlx.apply #qlx.action<pauli_rotation>(%557#0, %cst_339) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %559 = qlx.apply #qlx.action<pauli_rotation>(%557#1, %cst_340) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %560:2 = qlx.apply #qlx.action<pauli_rotation>(%558, %559, %cst_341) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %561 = qlx.apply #qlx.action<h>(%552#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_342 = arith.constant 3.1415926535897931 : f64
    %562 = qlx.apply #qlx.action<pauli_rotation>(%561, %cst_342) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %563 = qlx.apply #qlx.action<h>(%560#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_343 = arith.constant 3.1415926535897931 : f64
    %564 = qlx.apply #qlx.action<pauli_rotation>(%563, %cst_343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_344 = arith.constant 2.500000e-01 : f64
    %565:2 = qlx.apply #qlx.action<pauli_rotation>(%562, %564, %cst_344) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %566 = qlx.apply #qlx.action<h>(%513#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_345 = arith.constant 3.1415926535897931 : f64
    %567 = qlx.apply #qlx.action<pauli_rotation>(%566, %cst_345) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %568 = qlx.apply #qlx.action<h>(%567) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %569 = qlx.apply #qlx.action<h>(%552#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_346 = arith.constant 3.1415926535897931 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%569, %cst_346) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %571 = qlx.apply #qlx.action<h>(%570) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_347 = arith.constant 1.5707963267948966 : f64
    %572:2 = qlx.apply #qlx.action<pauli_rotation>(%568, %571, %cst_347) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %573 = qlx.apply #qlx.action<pauli_rotation>(%572#0, %cst_348) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_349 = arith.constant 1.5707963267948966 : f64
    %574 = qlx.apply #qlx.action<pauli_rotation>(%572#1, %cst_349) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_350 = arith.constant 1.5707963267948966 : f64
    %575:2 = qlx.apply #qlx.action<pauli_rotation>(%573, %574, %cst_350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %576 = qlx.apply #qlx.action<h>(%575#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_351 = arith.constant 3.1415926535897931 : f64
    %577 = qlx.apply #qlx.action<pauli_rotation>(%576, %cst_351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %578 = qlx.apply #qlx.action<h>(%577) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %579 = qlx.apply #qlx.action<h>(%565#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %580:2 = qlx.apply #qlx.action<pauli_rotation>(%578, %579, %cst_352) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_353 = arith.constant 1.5707963267948966 : f64
    %581 = qlx.apply #qlx.action<pauli_rotation>(%580#0, %cst_353) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %582 = qlx.apply #qlx.action<pauli_rotation>(%580#1, %cst_354) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_355 = arith.constant 1.5707963267948966 : f64
    %583:2 = qlx.apply #qlx.action<pauli_rotation>(%581, %582, %cst_355) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %584 = qlx.apply #qlx.action<h>(%560#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_356 = arith.constant 3.1415926535897931 : f64
    %585 = qlx.apply #qlx.action<pauli_rotation>(%584, %cst_356) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %586 = qlx.apply #qlx.action<h>(%585) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %587 = qlx.apply #qlx.action<h>(%531#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_357 = arith.constant 3.1415926535897931 : f64
    %588 = qlx.apply #qlx.action<pauli_rotation>(%587, %cst_357) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %589 = qlx.apply #qlx.action<h>(%588) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %590:2 = qlx.apply #qlx.action<pauli_rotation>(%586, %589, %cst_358) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %591 = qlx.apply #qlx.action<pauli_rotation>(%590#0, %cst_359) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %592 = qlx.apply #qlx.action<pauli_rotation>(%590#1, %cst_360) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_361 = arith.constant 1.5707963267948966 : f64
    %593:2 = qlx.apply #qlx.action<pauli_rotation>(%591, %592, %cst_361) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %594 = qlx.apply #qlx.action<h>(%565#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %595 = qlx.apply #qlx.action<h>(%593#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_362 = arith.constant 3.1415926535897931 : f64
    %596 = qlx.apply #qlx.action<pauli_rotation>(%595, %cst_362) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %597 = qlx.apply #qlx.action<h>(%596) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %598:2 = qlx.apply #qlx.action<pauli_rotation>(%594, %597, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_364 = arith.constant 1.5707963267948966 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%598#0, %cst_364) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_365 = arith.constant 1.5707963267948966 : f64
    %600 = qlx.apply #qlx.action<pauli_rotation>(%598#1, %cst_365) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %601:2 = qlx.apply #qlx.action<pauli_rotation>(%599, %600, %cst_366) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %602 = qlx.apply #qlx.action<h>(%583#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_367 = arith.constant 3.1415926535897931 : f64
    %603 = qlx.apply #qlx.action<pauli_rotation>(%602, %cst_367) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %604 = qlx.apply #qlx.action<h>(%601#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_368 = arith.constant 3.1415926535897931 : f64
    %605 = qlx.apply #qlx.action<pauli_rotation>(%604, %cst_368) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_369 = arith.constant 2.500000e-01 : f64
    %606:2 = qlx.apply #qlx.action<pauli_rotation>(%603, %605, %cst_369) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %607 = qlx.apply #qlx.action<h>(%601#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %608 = qlx.apply #qlx.action<pauli_rotation>(%607, %cst_370) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %609 = qlx.apply #qlx.action<h>(%608) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %610 = qlx.apply #qlx.action<h>(%593#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %611 = qlx.apply #qlx.action<pauli_rotation>(%610, %cst_371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %612 = qlx.apply #qlx.action<h>(%611) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_372 = arith.constant 1.250000e-01 : f64
    %613:2 = qlx.apply #qlx.action<pauli_rotation>(%609, %612, %cst_372) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_373 = arith.constant 1.5707963267948966 : f64
    %614 = qlx.apply #qlx.action<pauli_rotation>(%613#0, %cst_373) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_374 = arith.constant 1.5707963267948966 : f64
    %615 = qlx.apply #qlx.action<pauli_rotation>(%613#1, %cst_374) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_375 = arith.constant 1.250000e-01 : f64
    %616:2 = qlx.apply #qlx.action<pauli_rotation>(%614, %615, %cst_375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %617 = qlx.apply #qlx.action<h>(%575#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %618 = qlx.apply #qlx.action<pauli_rotation>(%617, %cst_376) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %619 = qlx.apply #qlx.action<h>(%618) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %620 = qlx.apply #qlx.action<h>(%583#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %621 = qlx.apply #qlx.action<pauli_rotation>(%620, %cst_377) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %622 = qlx.apply #qlx.action<h>(%621) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_378 = arith.constant 1.250000e-01 : f64
    %623:2 = qlx.apply #qlx.action<pauli_rotation>(%619, %622, %cst_378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_379 = arith.constant 1.5707963267948966 : f64
    %624 = qlx.apply #qlx.action<pauli_rotation>(%623#0, %cst_379) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_380 = arith.constant 1.5707963267948966 : f64
    %625 = qlx.apply #qlx.action<pauli_rotation>(%623#1, %cst_380) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_381 = arith.constant 1.250000e-01 : f64
    %626:2 = qlx.apply #qlx.action<pauli_rotation>(%624, %625, %cst_381) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_382 = arith.constant 1.5707963267948966 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%606#1, %cst_382) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %628 = qlx.apply #qlx.action<h>(%627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %629 = qlx.apply #qlx.action<h>(%616#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_383 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%629, %cst_383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %631 = qlx.apply #qlx.action<h>(%630) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_384 = arith.constant 1.250000e-01 : f64
    %632:2 = qlx.apply #qlx.action<pauli_rotation>(%628, %631, %cst_384) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_385 = arith.constant 1.5707963267948966 : f64
    %633 = qlx.apply #qlx.action<pauli_rotation>(%632#0, %cst_385) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_386 = arith.constant 1.5707963267948966 : f64
    %634 = qlx.apply #qlx.action<pauli_rotation>(%632#1, %cst_386) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_387 = arith.constant 1.250000e-01 : f64
    %635:2 = qlx.apply #qlx.action<pauli_rotation>(%633, %634, %cst_387) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %636 = qlx.apply #qlx.action<h>(%626#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_388 = arith.constant 1.5707963267948966 : f64
    %637 = qlx.apply #qlx.action<pauli_rotation>(%636, %cst_388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %638 = qlx.apply #qlx.action<h>(%637) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_389 = arith.constant 1.5707963267948966 : f64
    %639 = qlx.apply #qlx.action<pauli_rotation>(%606#0, %cst_389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %640 = qlx.apply #qlx.action<h>(%639) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_390 = arith.constant 1.250000e-01 : f64
    %641:2 = qlx.apply #qlx.action<pauli_rotation>(%638, %640, %cst_390) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %642 = qlx.apply #qlx.action<pauli_rotation>(%641#0, %cst_391) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_392 = arith.constant 1.5707963267948966 : f64
    %643 = qlx.apply #qlx.action<pauli_rotation>(%641#1, %cst_392) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_393 = arith.constant 1.250000e-01 : f64
    %644:2 = qlx.apply #qlx.action<pauli_rotation>(%642, %643, %cst_393) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %645 = qlx.apply #qlx.action<h>(%616#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_394 = arith.constant 3.1415926535897931 : f64
    %646 = qlx.apply #qlx.action<pauli_rotation>(%645, %cst_394) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %647 = qlx.apply #qlx.action<h>(%646) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %648 = qlx.apply #qlx.action<h>(%444#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_395 = arith.constant 3.1415926535897931 : f64
    %649 = qlx.apply #qlx.action<pauli_rotation>(%648, %cst_395) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %650 = qlx.apply #qlx.action<h>(%649) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_396 = arith.constant 1.4457963267948966 : f64
    %651:2 = qlx.apply #qlx.action<pauli_rotation>(%647, %650, %cst_396) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %652 = qlx.apply #qlx.action<pauli_rotation>(%651#0, %cst_397) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %653 = qlx.apply #qlx.action<pauli_rotation>(%651#1, %cst_398) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_399 = arith.constant 1.4457963267948966 : f64
    %654:2 = qlx.apply #qlx.action<pauli_rotation>(%652, %653, %cst_399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %655 = qlx.apply #qlx.action<h>(%424#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_400 = arith.constant 3.1415926535897931 : f64
    %656 = qlx.apply #qlx.action<pauli_rotation>(%655, %cst_400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %657 = qlx.apply #qlx.action<h>(%656) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.4457963267948966 : f64
    %658:2 = qlx.apply #qlx.action<pauli_rotation>(%626#0, %657, %cst_401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %659 = qlx.apply #qlx.action<pauli_rotation>(%658#1, %cst_402) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_403 = arith.constant 1.5707963267948966 : f64
    %660 = qlx.apply #qlx.action<pauli_rotation>(%658#0, %cst_403) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_404 = arith.constant 1.4457963267948966 : f64
    %661:2 = qlx.apply #qlx.action<pauli_rotation>(%659, %660, %cst_404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %662 = qlx.apply #qlx.action<h>(%635#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_405 = arith.constant 3.1415926535897931 : f64
    %663 = qlx.apply #qlx.action<pauli_rotation>(%662, %cst_405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %664 = qlx.apply #qlx.action<h>(%663) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%654#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_406 = arith.constant 3.1415926535897931 : f64
    %666 = qlx.apply #qlx.action<pauli_rotation>(%665, %cst_406) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %667 = qlx.apply #qlx.action<h>(%666) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %668:2 = qlx.apply #qlx.action<pauli_rotation>(%664, %667, %cst_407) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %669 = qlx.apply #qlx.action<pauli_rotation>(%668#0, %cst_408) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_409 = arith.constant 1.5707963267948966 : f64
    %670 = qlx.apply #qlx.action<pauli_rotation>(%668#1, %cst_409) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_410 = arith.constant 1.5707963267948966 : f64
    %671:2 = qlx.apply #qlx.action<pauli_rotation>(%669, %670, %cst_410) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %672 = qlx.apply #qlx.action<h>(%671#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 3.1415926535897931 : f64
    %673 = qlx.apply #qlx.action<pauli_rotation>(%672, %cst_411) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %674 = qlx.apply #qlx.action<h>(%673) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_412 = arith.constant 1.4457963267948966 : f64
    %675:2 = qlx.apply #qlx.action<pauli_rotation>(%635#0, %674, %cst_412) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %676 = qlx.apply #qlx.action<pauli_rotation>(%675#0, %cst_413) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%675#1, %cst_414) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_415 = arith.constant 1.4457963267948966 : f64
    %678:2 = qlx.apply #qlx.action<pauli_rotation>(%676, %677, %cst_415) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %679 = qlx.apply #qlx.action<h>(%661#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_416 = arith.constant 3.1415926535897931 : f64
    %680 = qlx.apply #qlx.action<pauli_rotation>(%679, %cst_416) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %681 = qlx.apply #qlx.action<h>(%680) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %682:2 = qlx.apply #qlx.action<pauli_rotation>(%644#0, %681, %cst_417) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %683 = qlx.apply #qlx.action<pauli_rotation>(%682#1, %cst_418) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.5707963267948966 : f64
    %684 = qlx.apply #qlx.action<pauli_rotation>(%682#0, %cst_419) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %685:2 = qlx.apply #qlx.action<pauli_rotation>(%683, %684, %cst_420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %686 = qlx.apply #qlx.action<h>(%685#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_421 = arith.constant 3.1415926535897931 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686, %cst_421) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %688 = qlx.apply #qlx.action<h>(%687) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %689 = qlx.apply #qlx.action<h>(%644#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 3.1415926535897931 : f64
    %690 = qlx.apply #qlx.action<pauli_rotation>(%689, %cst_422) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %691 = qlx.apply #qlx.action<h>(%690) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_423 = arith.constant 1.4457963267948966 : f64
    %692:2 = qlx.apply #qlx.action<pauli_rotation>(%688, %691, %cst_423) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %693 = qlx.apply #qlx.action<pauli_rotation>(%692#0, %cst_424) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %694 = qlx.apply #qlx.action<pauli_rotation>(%692#1, %cst_425) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_426 = arith.constant 1.4457963267948966 : f64
    %695:2 = qlx.apply #qlx.action<pauli_rotation>(%693, %694, %cst_426) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %696 = qlx.apply #qlx.action<h>(%695#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 3.1415926535897931 : f64
    %697 = qlx.apply #qlx.action<pauli_rotation>(%696, %cst_427) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %698 = qlx.apply #qlx.action<h>(%678#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_428 = arith.constant 3.1415926535897931 : f64
    %699 = qlx.apply #qlx.action<pauli_rotation>(%698, %cst_428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_429 = arith.constant 5.000000e-01 : f64
    %700:2 = qlx.apply #qlx.action<pauli_rotation>(%697, %699, %cst_429) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %701 = qlx.apply #qlx.action<h>(%695#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_430 = arith.constant 3.1415926535897931 : f64
    %702 = qlx.apply #qlx.action<pauli_rotation>(%701, %cst_430) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %703 = qlx.apply #qlx.action<h>(%702) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %704 = qlx.apply #qlx.action<h>(%700#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_431 = arith.constant 1.4457963267948966 : f64
    %705:2 = qlx.apply #qlx.action<pauli_rotation>(%703, %704, %cst_431) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_432 = arith.constant 1.5707963267948966 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705#0, %cst_432) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_433 = arith.constant 1.5707963267948966 : f64
    %707 = qlx.apply #qlx.action<pauli_rotation>(%705#1, %cst_433) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_434 = arith.constant 1.4457963267948966 : f64
    %708:2 = qlx.apply #qlx.action<pauli_rotation>(%706, %707, %cst_434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %709 = qlx.apply #qlx.action<h>(%700#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %710 = qlx.apply #qlx.action<h>(%678#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_435 = arith.constant 3.1415926535897931 : f64
    %711 = qlx.apply #qlx.action<pauli_rotation>(%710, %cst_435) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%711) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_436 = arith.constant 1.4457963267948966 : f64
    %713:2 = qlx.apply #qlx.action<pauli_rotation>(%709, %712, %cst_436) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %714 = qlx.apply #qlx.action<pauli_rotation>(%713#0, %cst_437) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_438 = arith.constant 1.5707963267948966 : f64
    %715 = qlx.apply #qlx.action<pauli_rotation>(%713#1, %cst_438) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_439 = arith.constant 1.4457963267948966 : f64
    %716:2 = qlx.apply #qlx.action<pauli_rotation>(%714, %715, %cst_439) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %717 = qlx.apply #qlx.action<h>(%685#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_440 = arith.constant 3.1415926535897931 : f64
    %718 = qlx.apply #qlx.action<pauli_rotation>(%717, %cst_440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %719 = qlx.apply #qlx.action<h>(%718) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %720 = qlx.apply #qlx.action<h>(%708#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 3.1415926535897931 : f64
    %721 = qlx.apply #qlx.action<pauli_rotation>(%720, %cst_441) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %722 = qlx.apply #qlx.action<h>(%721) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %723:2 = qlx.apply #qlx.action<pauli_rotation>(%719, %722, %cst_442) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %724 = qlx.apply #qlx.action<pauli_rotation>(%723#0, %cst_443) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_444 = arith.constant 1.5707963267948966 : f64
    %725 = qlx.apply #qlx.action<pauli_rotation>(%723#1, %cst_444) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_445 = arith.constant 1.5707963267948966 : f64
    %726:2 = qlx.apply #qlx.action<pauli_rotation>(%724, %725, %cst_445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %727 = qlx.apply #qlx.action<h>(%661#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_446 = arith.constant 3.1415926535897931 : f64
    %728 = qlx.apply #qlx.action<pauli_rotation>(%727, %cst_446) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %729 = qlx.apply #qlx.action<h>(%728) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %730 = qlx.apply #qlx.action<h>(%726#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_447 = arith.constant 3.1415926535897931 : f64
    %731 = qlx.apply #qlx.action<pauli_rotation>(%730, %cst_447) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %732 = qlx.apply #qlx.action<h>(%731) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_448 = arith.constant 1.4457963267948966 : f64
    %733:2 = qlx.apply #qlx.action<pauli_rotation>(%729, %732, %cst_448) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %734 = qlx.apply #qlx.action<pauli_rotation>(%733#0, %cst_449) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_450 = arith.constant 1.5707963267948966 : f64
    %735 = qlx.apply #qlx.action<pauli_rotation>(%733#1, %cst_450) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_451 = arith.constant 1.4457963267948966 : f64
    %736:2 = qlx.apply #qlx.action<pauli_rotation>(%734, %735, %cst_451) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %737 = qlx.apply #qlx.action<h>(%716#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_452 = arith.constant 3.1415926535897931 : f64
    %738 = qlx.apply #qlx.action<pauli_rotation>(%737, %cst_452) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %739 = qlx.apply #qlx.action<h>(%738) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %740 = qlx.apply #qlx.action<h>(%671#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_453 = arith.constant 3.1415926535897931 : f64
    %741 = qlx.apply #qlx.action<pauli_rotation>(%740, %cst_453) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%741) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %743:2 = qlx.apply #qlx.action<pauli_rotation>(%739, %742, %cst_454) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %744 = qlx.apply #qlx.action<pauli_rotation>(%743#0, %cst_455) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_456 = arith.constant 1.5707963267948966 : f64
    %745 = qlx.apply #qlx.action<pauli_rotation>(%743#1, %cst_456) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_457 = arith.constant 1.5707963267948966 : f64
    %746:2 = qlx.apply #qlx.action<pauli_rotation>(%744, %745, %cst_457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %747 = qlx.apply #qlx.action<h>(%746#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_458 = arith.constant 3.1415926535897931 : f64
    %748 = qlx.apply #qlx.action<pauli_rotation>(%747, %cst_458) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %749 = qlx.apply #qlx.action<h>(%748) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %750 = qlx.apply #qlx.action<h>(%654#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_459 = arith.constant 3.1415926535897931 : f64
    %751 = qlx.apply #qlx.action<pauli_rotation>(%750, %cst_459) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %752 = qlx.apply #qlx.action<h>(%751) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_460 = arith.constant 1.4457963267948966 : f64
    %753:2 = qlx.apply #qlx.action<pauli_rotation>(%749, %752, %cst_460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_461 = arith.constant 1.5707963267948966 : f64
    %754 = qlx.apply #qlx.action<pauli_rotation>(%753#0, %cst_461) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_462 = arith.constant 1.5707963267948966 : f64
    %755 = qlx.apply #qlx.action<pauli_rotation>(%753#1, %cst_462) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_463 = arith.constant 1.4457963267948966 : f64
    %756:2 = qlx.apply #qlx.action<pauli_rotation>(%754, %755, %cst_463) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %757 = qlx.apply #qlx.action<h>(%726#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_464 = arith.constant 1.5707963267948966 : f64
    %758 = qlx.apply #qlx.action<pauli_rotation>(%757, %cst_464) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %759 = qlx.apply #qlx.action<h>(%758) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %760 = qlx.apply #qlx.action<h>(%708#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_465 = arith.constant 1.5707963267948966 : f64
    %761 = qlx.apply #qlx.action<pauli_rotation>(%760, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %762 = qlx.apply #qlx.action<h>(%761) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_466 = arith.constant 1.250000e-01 : f64
    %763:2 = qlx.apply #qlx.action<pauli_rotation>(%759, %762, %cst_466) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_467 = arith.constant 1.5707963267948966 : f64
    %764 = qlx.apply #qlx.action<pauli_rotation>(%763#0, %cst_467) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_468 = arith.constant 1.5707963267948966 : f64
    %765 = qlx.apply #qlx.action<pauli_rotation>(%763#1, %cst_468) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_469 = arith.constant 1.250000e-01 : f64
    %766:2 = qlx.apply #qlx.action<pauli_rotation>(%764, %765, %cst_469) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %767 = qlx.apply #qlx.action<h>(%716#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_470 = arith.constant 1.5707963267948966 : f64
    %768 = qlx.apply #qlx.action<pauli_rotation>(%767, %cst_470) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %769 = qlx.apply #qlx.action<h>(%768) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %770 = qlx.apply #qlx.action<h>(%746#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_471 = arith.constant 1.5707963267948966 : f64
    %771 = qlx.apply #qlx.action<pauli_rotation>(%770, %cst_471) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %772 = qlx.apply #qlx.action<h>(%771) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 1.250000e-01 : f64
    %773:2 = qlx.apply #qlx.action<pauli_rotation>(%769, %772, %cst_472) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_473 = arith.constant 1.5707963267948966 : f64
    %774 = qlx.apply #qlx.action<pauli_rotation>(%773#0, %cst_473) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_474 = arith.constant 1.5707963267948966 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%773#1, %cst_474) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_475 = arith.constant 1.250000e-01 : f64
    %776:2 = qlx.apply #qlx.action<pauli_rotation>(%774, %775, %cst_475) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %777 = qlx.apply #qlx.action<h>(%736#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %778 = qlx.apply #qlx.action<pauli_rotation>(%777, %cst_476) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %779 = qlx.apply #qlx.action<h>(%778) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %780 = qlx.apply #qlx.action<h>(%766#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_477 = arith.constant 1.5707963267948966 : f64
    %781 = qlx.apply #qlx.action<pauli_rotation>(%780, %cst_477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %782 = qlx.apply #qlx.action<h>(%781) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_478 = arith.constant 1.250000e-01 : f64
    %783:2 = qlx.apply #qlx.action<pauli_rotation>(%779, %782, %cst_478) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_479 = arith.constant 1.5707963267948966 : f64
    %784 = qlx.apply #qlx.action<pauli_rotation>(%783#0, %cst_479) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_480 = arith.constant 1.5707963267948966 : f64
    %785 = qlx.apply #qlx.action<pauli_rotation>(%783#1, %cst_480) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_481 = arith.constant 1.250000e-01 : f64
    %786:2 = qlx.apply #qlx.action<pauli_rotation>(%784, %785, %cst_481) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %787 = qlx.apply #qlx.action<h>(%776#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_482 = arith.constant 1.5707963267948966 : f64
    %788 = qlx.apply #qlx.action<pauli_rotation>(%787, %cst_482) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %789 = qlx.apply #qlx.action<h>(%788) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %790 = qlx.apply #qlx.action<h>(%756#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_483 = arith.constant 1.5707963267948966 : f64
    %791 = qlx.apply #qlx.action<pauli_rotation>(%790, %cst_483) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %792 = qlx.apply #qlx.action<h>(%791) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_484 = arith.constant 1.250000e-01 : f64
    %793:2 = qlx.apply #qlx.action<pauli_rotation>(%789, %792, %cst_484) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_485 = arith.constant 1.5707963267948966 : f64
    %794 = qlx.apply #qlx.action<pauli_rotation>(%793#0, %cst_485) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %795 = qlx.apply #qlx.action<pauli_rotation>(%793#1, %cst_486) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_487 = arith.constant 1.250000e-01 : f64
    %796:2 = qlx.apply #qlx.action<pauli_rotation>(%794, %795, %cst_487) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %797 = qlx.apply #qlx.action<h>(%766#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_488 = arith.constant 3.1415926535897931 : f64
    %798 = qlx.apply #qlx.action<pauli_rotation>(%797, %cst_488) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %799 = qlx.apply #qlx.action<h>(%776#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_489 = arith.constant 2.500000e-01 : f64
    %800:2 = qlx.apply #qlx.action<pauli_rotation>(%798, %799, %cst_489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %801 = qlx.apply #qlx.action<h>(%786#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_490 = arith.constant 3.1415926535897931 : f64
    %802 = qlx.apply #qlx.action<pauli_rotation>(%801, %cst_490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %803 = qlx.apply #qlx.action<h>(%802) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %804 = qlx.apply #qlx.action<h>(%800#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_491 = arith.constant 1.5707963267948966 : f64
    %805:2 = qlx.apply #qlx.action<pauli_rotation>(%803, %804, %cst_491) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_492 = arith.constant 1.5707963267948966 : f64
    %806 = qlx.apply #qlx.action<pauli_rotation>(%805#0, %cst_492) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_493 = arith.constant 1.5707963267948966 : f64
    %807 = qlx.apply #qlx.action<pauli_rotation>(%805#1, %cst_493) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_494 = arith.constant 1.5707963267948966 : f64
    %808:2 = qlx.apply #qlx.action<pauli_rotation>(%806, %807, %cst_494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %809 = qlx.apply #qlx.action<h>(%800#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_495 = arith.constant 1.5707963267948966 : f64
    %810:2 = qlx.apply #qlx.action<pauli_rotation>(%796#0, %809, %cst_495) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_496 = arith.constant 1.5707963267948966 : f64
    %811 = qlx.apply #qlx.action<pauli_rotation>(%810#1, %cst_496) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_497 = arith.constant 1.5707963267948966 : f64
    %812 = qlx.apply #qlx.action<pauli_rotation>(%810#0, %cst_497) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %813:2 = qlx.apply #qlx.action<pauli_rotation>(%811, %812, %cst_498) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %814 = qlx.apply #qlx.action<h>(%808#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_499 = arith.constant 3.1415926535897931 : f64
    %815 = qlx.apply #qlx.action<pauli_rotation>(%814, %cst_499) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %816 = qlx.apply #qlx.action<h>(%813#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_500 = arith.constant 3.1415926535897931 : f64
    %817 = qlx.apply #qlx.action<pauli_rotation>(%816, %cst_500) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_501 = arith.constant 2.500000e-01 : f64
    %818:2 = qlx.apply #qlx.action<pauli_rotation>(%815, %817, %cst_501) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %819 = qlx.apply #qlx.action<h>(%808#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_502 = arith.constant 3.1415926535897931 : f64
    %820 = qlx.apply #qlx.action<pauli_rotation>(%819, %cst_502) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %821 = qlx.apply #qlx.action<h>(%820) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_503 = arith.constant 1.5707963267948966 : f64
    %822:2 = qlx.apply #qlx.action<pauli_rotation>(%786#0, %821, %cst_503) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_504 = arith.constant 1.5707963267948966 : f64
    %823 = qlx.apply #qlx.action<pauli_rotation>(%822#0, %cst_504) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_505 = arith.constant 1.5707963267948966 : f64
    %824 = qlx.apply #qlx.action<pauli_rotation>(%822#1, %cst_505) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_506 = arith.constant 1.5707963267948966 : f64
    %825:2 = qlx.apply #qlx.action<pauli_rotation>(%823, %824, %cst_506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %826 = qlx.apply #qlx.action<h>(%825#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_507 = arith.constant 3.1415926535897931 : f64
    %827 = qlx.apply #qlx.action<pauli_rotation>(%826, %cst_507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %828 = qlx.apply #qlx.action<h>(%827) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %829 = qlx.apply #qlx.action<h>(%818#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_508 = arith.constant 1.5707963267948966 : f64
    %830:2 = qlx.apply #qlx.action<pauli_rotation>(%828, %829, %cst_508) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_509 = arith.constant 1.5707963267948966 : f64
    %831 = qlx.apply #qlx.action<pauli_rotation>(%830#0, %cst_509) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%830#1, %cst_510) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_511 = arith.constant 1.5707963267948966 : f64
    %833:2 = qlx.apply #qlx.action<pauli_rotation>(%831, %832, %cst_511) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %834 = qlx.apply #qlx.action<h>(%813#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_512 = arith.constant 3.1415926535897931 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%834, %cst_512) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %836 = qlx.apply #qlx.action<h>(%835) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %837 = qlx.apply #qlx.action<h>(%796#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_513 = arith.constant 3.1415926535897931 : f64
    %838 = qlx.apply #qlx.action<pauli_rotation>(%837, %cst_513) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %839 = qlx.apply #qlx.action<h>(%838) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_514 = arith.constant 1.5707963267948966 : f64
    %840:2 = qlx.apply #qlx.action<pauli_rotation>(%836, %839, %cst_514) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_515 = arith.constant 1.5707963267948966 : f64
    %841 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %cst_515) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %842 = qlx.apply #qlx.action<pauli_rotation>(%840#1, %cst_516) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_517 = arith.constant 1.5707963267948966 : f64
    %843:2 = qlx.apply #qlx.action<pauli_rotation>(%841, %842, %cst_517) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %844 = qlx.apply #qlx.action<h>(%818#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %845 = qlx.apply #qlx.action<h>(%843#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_518 = arith.constant 3.1415926535897931 : f64
    %846 = qlx.apply #qlx.action<pauli_rotation>(%845, %cst_518) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %847 = qlx.apply #qlx.action<h>(%846) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_519 = arith.constant 1.5707963267948966 : f64
    %848:2 = qlx.apply #qlx.action<pauli_rotation>(%844, %847, %cst_519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_520 = arith.constant 1.5707963267948966 : f64
    %849 = qlx.apply #qlx.action<pauli_rotation>(%848#0, %cst_520) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_521 = arith.constant 1.5707963267948966 : f64
    %850 = qlx.apply #qlx.action<pauli_rotation>(%848#1, %cst_521) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_522 = arith.constant 1.5707963267948966 : f64
    %851:2 = qlx.apply #qlx.action<pauli_rotation>(%849, %850, %cst_522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %852 = qlx.apply #qlx.action<h>(%833#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_523 = arith.constant 3.1415926535897931 : f64
    %853 = qlx.apply #qlx.action<pauli_rotation>(%852, %cst_523) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %854 = qlx.apply #qlx.action<h>(%851#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_524 = arith.constant 3.1415926535897931 : f64
    %855 = qlx.apply #qlx.action<pauli_rotation>(%854, %cst_524) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_525 = arith.constant 5.000000e-01 : f64
    %856:2 = qlx.apply #qlx.action<pauli_rotation>(%853, %855, %cst_525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %857 = qlx.apply #qlx.action<h>(%833#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_526 = arith.constant 3.1415926535897931 : f64
    %858 = qlx.apply #qlx.action<pauli_rotation>(%857, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %859 = qlx.apply #qlx.action<h>(%858) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %860 = qlx.apply #qlx.action<h>(%856#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_527 = arith.constant 1.5707963267948966 : f64
    %861:2 = qlx.apply #qlx.action<pauli_rotation>(%859, %860, %cst_527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_528 = arith.constant 1.5707963267948966 : f64
    %862 = qlx.apply #qlx.action<pauli_rotation>(%861#0, %cst_528) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %863 = qlx.apply #qlx.action<pauli_rotation>(%861#1, %cst_529) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_530 = arith.constant 1.5707963267948966 : f64
    %864:2 = qlx.apply #qlx.action<pauli_rotation>(%862, %863, %cst_530) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %865 = qlx.apply #qlx.action<h>(%856#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %866 = qlx.apply #qlx.action<h>(%851#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_531 = arith.constant 3.1415926535897931 : f64
    %867 = qlx.apply #qlx.action<pauli_rotation>(%866, %cst_531) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %868 = qlx.apply #qlx.action<h>(%867) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_532 = arith.constant 1.5707963267948966 : f64
    %869:2 = qlx.apply #qlx.action<pauli_rotation>(%865, %868, %cst_532) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %870 = qlx.apply #qlx.action<pauli_rotation>(%869#0, %cst_533) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_534 = arith.constant 1.5707963267948966 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%869#1, %cst_534) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %872:2 = qlx.apply #qlx.action<pauli_rotation>(%870, %871, %cst_535) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %873 = qlx.apply #qlx.action<h>(%864#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_536 = arith.constant 3.1415926535897931 : f64
    %874 = qlx.apply #qlx.action<pauli_rotation>(%873, %cst_536) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %875 = qlx.apply #qlx.action<h>(%872#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_537 = arith.constant 3.1415926535897931 : f64
    %876 = qlx.apply #qlx.action<pauli_rotation>(%875, %cst_537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_538 = arith.constant 2.500000e-01 : f64
    %877:2 = qlx.apply #qlx.action<pauli_rotation>(%874, %876, %cst_538) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %878 = qlx.apply #qlx.action<h>(%825#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_539 = arith.constant 3.1415926535897931 : f64
    %879 = qlx.apply #qlx.action<pauli_rotation>(%878, %cst_539) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %880 = qlx.apply #qlx.action<h>(%879) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %881 = qlx.apply #qlx.action<h>(%864#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_540 = arith.constant 3.1415926535897931 : f64
    %882 = qlx.apply #qlx.action<pauli_rotation>(%881, %cst_540) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %883 = qlx.apply #qlx.action<h>(%882) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_541 = arith.constant 1.5707963267948966 : f64
    %884:2 = qlx.apply #qlx.action<pauli_rotation>(%880, %883, %cst_541) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_542 = arith.constant 1.5707963267948966 : f64
    %885 = qlx.apply #qlx.action<pauli_rotation>(%884#0, %cst_542) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_543 = arith.constant 1.5707963267948966 : f64
    %886 = qlx.apply #qlx.action<pauli_rotation>(%884#1, %cst_543) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_544 = arith.constant 1.5707963267948966 : f64
    %887:2 = qlx.apply #qlx.action<pauli_rotation>(%885, %886, %cst_544) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %888 = qlx.apply #qlx.action<h>(%887#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_545 = arith.constant 3.1415926535897931 : f64
    %889 = qlx.apply #qlx.action<pauli_rotation>(%888, %cst_545) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %890 = qlx.apply #qlx.action<h>(%889) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %891 = qlx.apply #qlx.action<h>(%877#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_546 = arith.constant 1.5707963267948966 : f64
    %892:2 = qlx.apply #qlx.action<pauli_rotation>(%890, %891, %cst_546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_547 = arith.constant 1.5707963267948966 : f64
    %893 = qlx.apply #qlx.action<pauli_rotation>(%892#0, %cst_547) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_548 = arith.constant 1.5707963267948966 : f64
    %894 = qlx.apply #qlx.action<pauli_rotation>(%892#1, %cst_548) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_549 = arith.constant 1.5707963267948966 : f64
    %895:2 = qlx.apply #qlx.action<pauli_rotation>(%893, %894, %cst_549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %896 = qlx.apply #qlx.action<h>(%872#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_550 = arith.constant 3.1415926535897931 : f64
    %897 = qlx.apply #qlx.action<pauli_rotation>(%896, %cst_550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %898 = qlx.apply #qlx.action<h>(%897) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %899 = qlx.apply #qlx.action<h>(%843#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_551 = arith.constant 3.1415926535897931 : f64
    %900 = qlx.apply #qlx.action<pauli_rotation>(%899, %cst_551) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %901 = qlx.apply #qlx.action<h>(%900) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_552 = arith.constant 1.5707963267948966 : f64
    %902:2 = qlx.apply #qlx.action<pauli_rotation>(%898, %901, %cst_552) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_553 = arith.constant 1.5707963267948966 : f64
    %903 = qlx.apply #qlx.action<pauli_rotation>(%902#0, %cst_553) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_554 = arith.constant 1.5707963267948966 : f64
    %904 = qlx.apply #qlx.action<pauli_rotation>(%902#1, %cst_554) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_555 = arith.constant 1.5707963267948966 : f64
    %905:2 = qlx.apply #qlx.action<pauli_rotation>(%903, %904, %cst_555) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %906 = qlx.apply #qlx.action<h>(%877#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %907 = qlx.apply #qlx.action<h>(%905#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_556 = arith.constant 3.1415926535897931 : f64
    %908 = qlx.apply #qlx.action<pauli_rotation>(%907, %cst_556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%908) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_557 = arith.constant 1.5707963267948966 : f64
    %910:2 = qlx.apply #qlx.action<pauli_rotation>(%906, %909, %cst_557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_558 = arith.constant 1.5707963267948966 : f64
    %911 = qlx.apply #qlx.action<pauli_rotation>(%910#0, %cst_558) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_559 = arith.constant 1.5707963267948966 : f64
    %912 = qlx.apply #qlx.action<pauli_rotation>(%910#1, %cst_559) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_560 = arith.constant 1.5707963267948966 : f64
    %913:2 = qlx.apply #qlx.action<pauli_rotation>(%911, %912, %cst_560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %914 = qlx.apply #qlx.action<h>(%895#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_561 = arith.constant 3.1415926535897931 : f64
    %915 = qlx.apply #qlx.action<pauli_rotation>(%914, %cst_561) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %916 = qlx.apply #qlx.action<h>(%913#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_562 = arith.constant 3.1415926535897931 : f64
    %917 = qlx.apply #qlx.action<pauli_rotation>(%916, %cst_562) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_563 = arith.constant 2.500000e-01 : f64
    %918:2 = qlx.apply #qlx.action<pauli_rotation>(%915, %917, %cst_563) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %919 = qlx.apply #qlx.action<h>(%913#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_564 = arith.constant 1.5707963267948966 : f64
    %920 = qlx.apply #qlx.action<pauli_rotation>(%919, %cst_564) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %921 = qlx.apply #qlx.action<h>(%920) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %922 = qlx.apply #qlx.action<h>(%905#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_565 = arith.constant 1.5707963267948966 : f64
    %923 = qlx.apply #qlx.action<pauli_rotation>(%922, %cst_565) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %924 = qlx.apply #qlx.action<h>(%923) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_566 = arith.constant 1.250000e-01 : f64
    %925:2 = qlx.apply #qlx.action<pauli_rotation>(%921, %924, %cst_566) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_567 = arith.constant 1.5707963267948966 : f64
    %926 = qlx.apply #qlx.action<pauli_rotation>(%925#0, %cst_567) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_568 = arith.constant 1.5707963267948966 : f64
    %927 = qlx.apply #qlx.action<pauli_rotation>(%925#1, %cst_568) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_569 = arith.constant 1.250000e-01 : f64
    %928:2 = qlx.apply #qlx.action<pauli_rotation>(%926, %927, %cst_569) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %929 = qlx.apply #qlx.action<h>(%887#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_570 = arith.constant 1.5707963267948966 : f64
    %930 = qlx.apply #qlx.action<pauli_rotation>(%929, %cst_570) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %931 = qlx.apply #qlx.action<h>(%930) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %932 = qlx.apply #qlx.action<h>(%895#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_571 = arith.constant 1.5707963267948966 : f64
    %933 = qlx.apply #qlx.action<pauli_rotation>(%932, %cst_571) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %934 = qlx.apply #qlx.action<h>(%933) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_572 = arith.constant 1.250000e-01 : f64
    %935:2 = qlx.apply #qlx.action<pauli_rotation>(%931, %934, %cst_572) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_573 = arith.constant 1.5707963267948966 : f64
    %936 = qlx.apply #qlx.action<pauli_rotation>(%935#0, %cst_573) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_574 = arith.constant 1.5707963267948966 : f64
    %937 = qlx.apply #qlx.action<pauli_rotation>(%935#1, %cst_574) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_575 = arith.constant 1.250000e-01 : f64
    %938:2 = qlx.apply #qlx.action<pauli_rotation>(%936, %937, %cst_575) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_576 = arith.constant 1.5707963267948966 : f64
    %939 = qlx.apply #qlx.action<pauli_rotation>(%918#1, %cst_576) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %940 = qlx.apply #qlx.action<h>(%939) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %941 = qlx.apply #qlx.action<h>(%928#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_577 = arith.constant 1.5707963267948966 : f64
    %942 = qlx.apply #qlx.action<pauli_rotation>(%941, %cst_577) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %943 = qlx.apply #qlx.action<h>(%942) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_578 = arith.constant 1.250000e-01 : f64
    %944:2 = qlx.apply #qlx.action<pauli_rotation>(%940, %943, %cst_578) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_579 = arith.constant 1.5707963267948966 : f64
    %945 = qlx.apply #qlx.action<pauli_rotation>(%944#0, %cst_579) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_580 = arith.constant 1.5707963267948966 : f64
    %946 = qlx.apply #qlx.action<pauli_rotation>(%944#1, %cst_580) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_581 = arith.constant 1.250000e-01 : f64
    %947:2 = qlx.apply #qlx.action<pauli_rotation>(%945, %946, %cst_581) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %948 = qlx.apply #qlx.action<h>(%938#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_582 = arith.constant 1.5707963267948966 : f64
    %949 = qlx.apply #qlx.action<pauli_rotation>(%948, %cst_582) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %950 = qlx.apply #qlx.action<h>(%949) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_583 = arith.constant 1.5707963267948966 : f64
    %951 = qlx.apply #qlx.action<pauli_rotation>(%918#0, %cst_583) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %952 = qlx.apply #qlx.action<h>(%951) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_584 = arith.constant 1.250000e-01 : f64
    %953:2 = qlx.apply #qlx.action<pauli_rotation>(%950, %952, %cst_584) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_585 = arith.constant 1.5707963267948966 : f64
    %954 = qlx.apply #qlx.action<pauli_rotation>(%953#0, %cst_585) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_586 = arith.constant 1.5707963267948966 : f64
    %955 = qlx.apply #qlx.action<pauli_rotation>(%953#1, %cst_586) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_587 = arith.constant 1.250000e-01 : f64
    %956:2 = qlx.apply #qlx.action<pauli_rotation>(%954, %955, %cst_587) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %957 = qlx.apply #qlx.action<h>(%928#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_588 = arith.constant 3.1415926535897931 : f64
    %958 = qlx.apply #qlx.action<pauli_rotation>(%957, %cst_588) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %959 = qlx.apply #qlx.action<h>(%958) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %960 = qlx.apply #qlx.action<h>(%756#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_589 = arith.constant 3.1415926535897931 : f64
    %961 = qlx.apply #qlx.action<pauli_rotation>(%960, %cst_589) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %962 = qlx.apply #qlx.action<h>(%961) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_590 = arith.constant 1.4457963267948966 : f64
    %963:2 = qlx.apply #qlx.action<pauli_rotation>(%959, %962, %cst_590) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_591 = arith.constant 1.5707963267948966 : f64
    %964 = qlx.apply #qlx.action<pauli_rotation>(%963#0, %cst_591) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_592 = arith.constant 1.5707963267948966 : f64
    %965 = qlx.apply #qlx.action<pauli_rotation>(%963#1, %cst_592) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_593 = arith.constant 1.4457963267948966 : f64
    %966:2 = qlx.apply #qlx.action<pauli_rotation>(%964, %965, %cst_593) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %967 = qlx.apply #qlx.action<h>(%736#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_594 = arith.constant 3.1415926535897931 : f64
    %968 = qlx.apply #qlx.action<pauli_rotation>(%967, %cst_594) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %969 = qlx.apply #qlx.action<h>(%968) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_595 = arith.constant 1.4457963267948966 : f64
    %970:2 = qlx.apply #qlx.action<pauli_rotation>(%938#0, %969, %cst_595) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_596 = arith.constant 1.5707963267948966 : f64
    %971 = qlx.apply #qlx.action<pauli_rotation>(%970#1, %cst_596) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_597 = arith.constant 1.5707963267948966 : f64
    %972 = qlx.apply #qlx.action<pauli_rotation>(%970#0, %cst_597) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_598 = arith.constant 1.4457963267948966 : f64
    %973:2 = qlx.apply #qlx.action<pauli_rotation>(%971, %972, %cst_598) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %974 = qlx.apply #qlx.action<h>(%947#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_599 = arith.constant 3.1415926535897931 : f64
    %975 = qlx.apply #qlx.action<pauli_rotation>(%974, %cst_599) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %976 = qlx.apply #qlx.action<h>(%975) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %977 = qlx.apply #qlx.action<h>(%966#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_600 = arith.constant 3.1415926535897931 : f64
    %978 = qlx.apply #qlx.action<pauli_rotation>(%977, %cst_600) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %979 = qlx.apply #qlx.action<h>(%978) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_601 = arith.constant 1.5707963267948966 : f64
    %980:2 = qlx.apply #qlx.action<pauli_rotation>(%976, %979, %cst_601) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_602 = arith.constant 1.5707963267948966 : f64
    %981 = qlx.apply #qlx.action<pauli_rotation>(%980#0, %cst_602) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_603 = arith.constant 1.5707963267948966 : f64
    %982 = qlx.apply #qlx.action<pauli_rotation>(%980#1, %cst_603) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_604 = arith.constant 1.5707963267948966 : f64
    %983:2 = qlx.apply #qlx.action<pauli_rotation>(%981, %982, %cst_604) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %984 = qlx.apply #qlx.action<h>(%983#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_605 = arith.constant 3.1415926535897931 : f64
    %985 = qlx.apply #qlx.action<pauli_rotation>(%984, %cst_605) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %986 = qlx.apply #qlx.action<h>(%985) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_606 = arith.constant 1.4457963267948966 : f64
    %987:2 = qlx.apply #qlx.action<pauli_rotation>(%947#0, %986, %cst_606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_607 = arith.constant 1.5707963267948966 : f64
    %988 = qlx.apply #qlx.action<pauli_rotation>(%987#0, %cst_607) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_608 = arith.constant 1.5707963267948966 : f64
    %989 = qlx.apply #qlx.action<pauli_rotation>(%987#1, %cst_608) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_609 = arith.constant 1.4457963267948966 : f64
    %990:2 = qlx.apply #qlx.action<pauli_rotation>(%988, %989, %cst_609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %991 = qlx.apply #qlx.action<h>(%973#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_610 = arith.constant 3.1415926535897931 : f64
    %992 = qlx.apply #qlx.action<pauli_rotation>(%991, %cst_610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %993 = qlx.apply #qlx.action<h>(%992) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_611 = arith.constant 1.5707963267948966 : f64
    %994:2 = qlx.apply #qlx.action<pauli_rotation>(%956#0, %993, %cst_611) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_612 = arith.constant 1.5707963267948966 : f64
    %995 = qlx.apply #qlx.action<pauli_rotation>(%994#1, %cst_612) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_613 = arith.constant 1.5707963267948966 : f64
    %996 = qlx.apply #qlx.action<pauli_rotation>(%994#0, %cst_613) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_614 = arith.constant 1.5707963267948966 : f64
    %997:2 = qlx.apply #qlx.action<pauli_rotation>(%995, %996, %cst_614) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %998 = qlx.apply #qlx.action<h>(%997#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_615 = arith.constant 3.1415926535897931 : f64
    %999 = qlx.apply #qlx.action<pauli_rotation>(%998, %cst_615) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1000 = qlx.apply #qlx.action<h>(%999) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1001 = qlx.apply #qlx.action<h>(%956#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_616 = arith.constant 3.1415926535897931 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1001, %cst_616) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1003 = qlx.apply #qlx.action<h>(%1002) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_617 = arith.constant 1.4457963267948966 : f64
    %1004:2 = qlx.apply #qlx.action<pauli_rotation>(%1000, %1003, %cst_617) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_618 = arith.constant 1.5707963267948966 : f64
    %1005 = qlx.apply #qlx.action<pauli_rotation>(%1004#0, %cst_618) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_619 = arith.constant 1.5707963267948966 : f64
    %1006 = qlx.apply #qlx.action<pauli_rotation>(%1004#1, %cst_619) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_620 = arith.constant 1.4457963267948966 : f64
    %1007:2 = qlx.apply #qlx.action<pauli_rotation>(%1005, %1006, %cst_620) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1008 = qlx.apply #qlx.action<h>(%1007#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_621 = arith.constant 3.1415926535897931 : f64
    %1009 = qlx.apply #qlx.action<pauli_rotation>(%1008, %cst_621) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1010 = qlx.apply #qlx.action<h>(%990#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_622 = arith.constant 3.1415926535897931 : f64
    %1011 = qlx.apply #qlx.action<pauli_rotation>(%1010, %cst_622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_623 = arith.constant 5.000000e-01 : f64
    %1012:2 = qlx.apply #qlx.action<pauli_rotation>(%1009, %1011, %cst_623) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1013 = qlx.apply #qlx.action<h>(%1007#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_624 = arith.constant 3.1415926535897931 : f64
    %1014 = qlx.apply #qlx.action<pauli_rotation>(%1013, %cst_624) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1015 = qlx.apply #qlx.action<h>(%1014) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1016 = qlx.apply #qlx.action<h>(%1012#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_625 = arith.constant 1.4457963267948966 : f64
    %1017:2 = qlx.apply #qlx.action<pauli_rotation>(%1015, %1016, %cst_625) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_626 = arith.constant 1.5707963267948966 : f64
    %1018 = qlx.apply #qlx.action<pauli_rotation>(%1017#0, %cst_626) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_627 = arith.constant 1.5707963267948966 : f64
    %1019 = qlx.apply #qlx.action<pauli_rotation>(%1017#1, %cst_627) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_628 = arith.constant 1.4457963267948966 : f64
    %1020:2 = qlx.apply #qlx.action<pauli_rotation>(%1018, %1019, %cst_628) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1021 = qlx.apply #qlx.action<h>(%1012#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1022 = qlx.apply #qlx.action<h>(%990#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_629 = arith.constant 3.1415926535897931 : f64
    %1023 = qlx.apply #qlx.action<pauli_rotation>(%1022, %cst_629) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1024 = qlx.apply #qlx.action<h>(%1023) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_630 = arith.constant 1.4457963267948966 : f64
    %1025:2 = qlx.apply #qlx.action<pauli_rotation>(%1021, %1024, %cst_630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_631 = arith.constant 1.5707963267948966 : f64
    %1026 = qlx.apply #qlx.action<pauli_rotation>(%1025#0, %cst_631) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_632 = arith.constant 1.5707963267948966 : f64
    %1027 = qlx.apply #qlx.action<pauli_rotation>(%1025#1, %cst_632) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_633 = arith.constant 1.4457963267948966 : f64
    %1028:2 = qlx.apply #qlx.action<pauli_rotation>(%1026, %1027, %cst_633) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1029 = qlx.apply #qlx.action<h>(%997#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_634 = arith.constant 3.1415926535897931 : f64
    %1030 = qlx.apply #qlx.action<pauli_rotation>(%1029, %cst_634) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1031 = qlx.apply #qlx.action<h>(%1030) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1032 = qlx.apply #qlx.action<h>(%1020#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_635 = arith.constant 3.1415926535897931 : f64
    %1033 = qlx.apply #qlx.action<pauli_rotation>(%1032, %cst_635) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1034 = qlx.apply #qlx.action<h>(%1033) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_636 = arith.constant 1.5707963267948966 : f64
    %1035:2 = qlx.apply #qlx.action<pauli_rotation>(%1031, %1034, %cst_636) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_637 = arith.constant 1.5707963267948966 : f64
    %1036 = qlx.apply #qlx.action<pauli_rotation>(%1035#0, %cst_637) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_638 = arith.constant 1.5707963267948966 : f64
    %1037 = qlx.apply #qlx.action<pauli_rotation>(%1035#1, %cst_638) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_639 = arith.constant 1.5707963267948966 : f64
    %1038:2 = qlx.apply #qlx.action<pauli_rotation>(%1036, %1037, %cst_639) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1039 = qlx.apply #qlx.action<h>(%973#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_640 = arith.constant 3.1415926535897931 : f64
    %1040 = qlx.apply #qlx.action<pauli_rotation>(%1039, %cst_640) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1041 = qlx.apply #qlx.action<h>(%1040) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1042 = qlx.apply #qlx.action<h>(%1038#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_641 = arith.constant 3.1415926535897931 : f64
    %1043 = qlx.apply #qlx.action<pauli_rotation>(%1042, %cst_641) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1044 = qlx.apply #qlx.action<h>(%1043) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_642 = arith.constant 1.4457963267948966 : f64
    %1045:2 = qlx.apply #qlx.action<pauli_rotation>(%1041, %1044, %cst_642) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_643 = arith.constant 1.5707963267948966 : f64
    %1046 = qlx.apply #qlx.action<pauli_rotation>(%1045#0, %cst_643) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_644 = arith.constant 1.5707963267948966 : f64
    %1047 = qlx.apply #qlx.action<pauli_rotation>(%1045#1, %cst_644) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_645 = arith.constant 1.4457963267948966 : f64
    %1048:2 = qlx.apply #qlx.action<pauli_rotation>(%1046, %1047, %cst_645) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1049 = qlx.apply #qlx.action<h>(%1028#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_646 = arith.constant 3.1415926535897931 : f64
    %1050 = qlx.apply #qlx.action<pauli_rotation>(%1049, %cst_646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1051 = qlx.apply #qlx.action<h>(%1050) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1052 = qlx.apply #qlx.action<h>(%983#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_647 = arith.constant 3.1415926535897931 : f64
    %1053 = qlx.apply #qlx.action<pauli_rotation>(%1052, %cst_647) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1054 = qlx.apply #qlx.action<h>(%1053) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_648 = arith.constant 1.5707963267948966 : f64
    %1055:2 = qlx.apply #qlx.action<pauli_rotation>(%1051, %1054, %cst_648) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_649 = arith.constant 1.5707963267948966 : f64
    %1056 = qlx.apply #qlx.action<pauli_rotation>(%1055#0, %cst_649) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_650 = arith.constant 1.5707963267948966 : f64
    %1057 = qlx.apply #qlx.action<pauli_rotation>(%1055#1, %cst_650) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_651 = arith.constant 1.5707963267948966 : f64
    %1058:2 = qlx.apply #qlx.action<pauli_rotation>(%1056, %1057, %cst_651) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1059 = qlx.apply #qlx.action<h>(%1058#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_652 = arith.constant 3.1415926535897931 : f64
    %1060 = qlx.apply #qlx.action<pauli_rotation>(%1059, %cst_652) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1061 = qlx.apply #qlx.action<h>(%1060) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1062 = qlx.apply #qlx.action<h>(%966#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_653 = arith.constant 3.1415926535897931 : f64
    %1063 = qlx.apply #qlx.action<pauli_rotation>(%1062, %cst_653) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1064 = qlx.apply #qlx.action<h>(%1063) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_654 = arith.constant 1.4457963267948966 : f64
    %1065:2 = qlx.apply #qlx.action<pauli_rotation>(%1061, %1064, %cst_654) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_655 = arith.constant 1.5707963267948966 : f64
    %1066 = qlx.apply #qlx.action<pauli_rotation>(%1065#0, %cst_655) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_656 = arith.constant 1.5707963267948966 : f64
    %1067 = qlx.apply #qlx.action<pauli_rotation>(%1065#1, %cst_656) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_657 = arith.constant 1.4457963267948966 : f64
    %1068:2 = qlx.apply #qlx.action<pauli_rotation>(%1066, %1067, %cst_657) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1069 = qlx.apply #qlx.action<h>(%1038#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_658 = arith.constant 1.5707963267948966 : f64
    %1070 = qlx.apply #qlx.action<pauli_rotation>(%1069, %cst_658) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1071 = qlx.apply #qlx.action<h>(%1070) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1072 = qlx.apply #qlx.action<h>(%1020#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_659 = arith.constant 1.5707963267948966 : f64
    %1073 = qlx.apply #qlx.action<pauli_rotation>(%1072, %cst_659) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1074 = qlx.apply #qlx.action<h>(%1073) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_660 = arith.constant 1.250000e-01 : f64
    %1075:2 = qlx.apply #qlx.action<pauli_rotation>(%1071, %1074, %cst_660) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_661 = arith.constant 1.5707963267948966 : f64
    %1076 = qlx.apply #qlx.action<pauli_rotation>(%1075#0, %cst_661) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_662 = arith.constant 1.5707963267948966 : f64
    %1077 = qlx.apply #qlx.action<pauli_rotation>(%1075#1, %cst_662) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_663 = arith.constant 1.250000e-01 : f64
    %1078:2 = qlx.apply #qlx.action<pauli_rotation>(%1076, %1077, %cst_663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1079 = qlx.apply #qlx.action<h>(%1028#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_664 = arith.constant 1.5707963267948966 : f64
    %1080 = qlx.apply #qlx.action<pauli_rotation>(%1079, %cst_664) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1081 = qlx.apply #qlx.action<h>(%1080) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1082 = qlx.apply #qlx.action<h>(%1058#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_665 = arith.constant 1.5707963267948966 : f64
    %1083 = qlx.apply #qlx.action<pauli_rotation>(%1082, %cst_665) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1084 = qlx.apply #qlx.action<h>(%1083) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_666 = arith.constant 1.250000e-01 : f64
    %1085:2 = qlx.apply #qlx.action<pauli_rotation>(%1081, %1084, %cst_666) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_667 = arith.constant 1.5707963267948966 : f64
    %1086 = qlx.apply #qlx.action<pauli_rotation>(%1085#0, %cst_667) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_668 = arith.constant 1.5707963267948966 : f64
    %1087 = qlx.apply #qlx.action<pauli_rotation>(%1085#1, %cst_668) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_669 = arith.constant 1.250000e-01 : f64
    %1088:2 = qlx.apply #qlx.action<pauli_rotation>(%1086, %1087, %cst_669) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1089 = qlx.apply #qlx.action<h>(%1048#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_670 = arith.constant 1.5707963267948966 : f64
    %1090 = qlx.apply #qlx.action<pauli_rotation>(%1089, %cst_670) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1091 = qlx.apply #qlx.action<h>(%1090) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1092 = qlx.apply #qlx.action<h>(%1078#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_671 = arith.constant 1.5707963267948966 : f64
    %1093 = qlx.apply #qlx.action<pauli_rotation>(%1092, %cst_671) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1094 = qlx.apply #qlx.action<h>(%1093) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_672 = arith.constant 1.250000e-01 : f64
    %1095:2 = qlx.apply #qlx.action<pauli_rotation>(%1091, %1094, %cst_672) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_673 = arith.constant 1.5707963267948966 : f64
    %1096 = qlx.apply #qlx.action<pauli_rotation>(%1095#0, %cst_673) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_674 = arith.constant 1.5707963267948966 : f64
    %1097 = qlx.apply #qlx.action<pauli_rotation>(%1095#1, %cst_674) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_675 = arith.constant 1.250000e-01 : f64
    %1098:2 = qlx.apply #qlx.action<pauli_rotation>(%1096, %1097, %cst_675) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1099 = qlx.apply #qlx.action<h>(%1088#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_676 = arith.constant 1.5707963267948966 : f64
    %1100 = qlx.apply #qlx.action<pauli_rotation>(%1099, %cst_676) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1101 = qlx.apply #qlx.action<h>(%1100) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1102 = qlx.apply #qlx.action<h>(%1068#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_677 = arith.constant 1.5707963267948966 : f64
    %1103 = qlx.apply #qlx.action<pauli_rotation>(%1102, %cst_677) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1104 = qlx.apply #qlx.action<h>(%1103) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_678 = arith.constant 1.250000e-01 : f64
    %1105:2 = qlx.apply #qlx.action<pauli_rotation>(%1101, %1104, %cst_678) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_679 = arith.constant 1.5707963267948966 : f64
    %1106 = qlx.apply #qlx.action<pauli_rotation>(%1105#0, %cst_679) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_680 = arith.constant 1.5707963267948966 : f64
    %1107 = qlx.apply #qlx.action<pauli_rotation>(%1105#1, %cst_680) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_681 = arith.constant 1.250000e-01 : f64
    %1108:2 = qlx.apply #qlx.action<pauli_rotation>(%1106, %1107, %cst_681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1109 = qlx.apply #qlx.action<h>(%1078#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_682 = arith.constant 3.1415926535897931 : f64
    %1110 = qlx.apply #qlx.action<pauli_rotation>(%1109, %cst_682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1111 = qlx.apply #qlx.action<h>(%1088#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_683 = arith.constant 2.500000e-01 : f64
    %1112:2 = qlx.apply #qlx.action<pauli_rotation>(%1110, %1111, %cst_683) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1113 = qlx.apply #qlx.action<h>(%1098#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_684 = arith.constant 3.1415926535897931 : f64
    %1114 = qlx.apply #qlx.action<pauli_rotation>(%1113, %cst_684) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1115 = qlx.apply #qlx.action<h>(%1114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1116 = qlx.apply #qlx.action<h>(%1112#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_685 = arith.constant 1.5707963267948966 : f64
    %1117:2 = qlx.apply #qlx.action<pauli_rotation>(%1115, %1116, %cst_685) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_686 = arith.constant 1.5707963267948966 : f64
    %1118 = qlx.apply #qlx.action<pauli_rotation>(%1117#0, %cst_686) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_687 = arith.constant 1.5707963267948966 : f64
    %1119 = qlx.apply #qlx.action<pauli_rotation>(%1117#1, %cst_687) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_688 = arith.constant 1.5707963267948966 : f64
    %1120:2 = qlx.apply #qlx.action<pauli_rotation>(%1118, %1119, %cst_688) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1121 = qlx.apply #qlx.action<h>(%1112#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_689 = arith.constant 1.5707963267948966 : f64
    %1122:2 = qlx.apply #qlx.action<pauli_rotation>(%1108#0, %1121, %cst_689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_690 = arith.constant 1.5707963267948966 : f64
    %1123 = qlx.apply #qlx.action<pauli_rotation>(%1122#1, %cst_690) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_691 = arith.constant 1.5707963267948966 : f64
    %1124 = qlx.apply #qlx.action<pauli_rotation>(%1122#0, %cst_691) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_692 = arith.constant 1.5707963267948966 : f64
    %1125:2 = qlx.apply #qlx.action<pauli_rotation>(%1123, %1124, %cst_692) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1126 = qlx.apply #qlx.action<h>(%1120#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_693 = arith.constant 3.1415926535897931 : f64
    %1127 = qlx.apply #qlx.action<pauli_rotation>(%1126, %cst_693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1128 = qlx.apply #qlx.action<h>(%1125#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_694 = arith.constant 3.1415926535897931 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1128, %cst_694) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_695 = arith.constant 2.500000e-01 : f64
    %1130:2 = qlx.apply #qlx.action<pauli_rotation>(%1127, %1129, %cst_695) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1131 = qlx.apply #qlx.action<h>(%1120#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_696 = arith.constant 3.1415926535897931 : f64
    %1132 = qlx.apply #qlx.action<pauli_rotation>(%1131, %cst_696) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1133 = qlx.apply #qlx.action<h>(%1132) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_697 = arith.constant 1.5707963267948966 : f64
    %1134:2 = qlx.apply #qlx.action<pauli_rotation>(%1098#0, %1133, %cst_697) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_698 = arith.constant 1.5707963267948966 : f64
    %1135 = qlx.apply #qlx.action<pauli_rotation>(%1134#0, %cst_698) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_699 = arith.constant 1.5707963267948966 : f64
    %1136 = qlx.apply #qlx.action<pauli_rotation>(%1134#1, %cst_699) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_700 = arith.constant 1.5707963267948966 : f64
    %1137:2 = qlx.apply #qlx.action<pauli_rotation>(%1135, %1136, %cst_700) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1138 = qlx.apply #qlx.action<h>(%1137#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_701 = arith.constant 3.1415926535897931 : f64
    %1139 = qlx.apply #qlx.action<pauli_rotation>(%1138, %cst_701) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1140 = qlx.apply #qlx.action<h>(%1139) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1141 = qlx.apply #qlx.action<h>(%1130#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_702 = arith.constant 1.5707963267948966 : f64
    %1142:2 = qlx.apply #qlx.action<pauli_rotation>(%1140, %1141, %cst_702) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_703 = arith.constant 1.5707963267948966 : f64
    %1143 = qlx.apply #qlx.action<pauli_rotation>(%1142#0, %cst_703) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_704 = arith.constant 1.5707963267948966 : f64
    %1144 = qlx.apply #qlx.action<pauli_rotation>(%1142#1, %cst_704) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_705 = arith.constant 1.5707963267948966 : f64
    %1145:2 = qlx.apply #qlx.action<pauli_rotation>(%1143, %1144, %cst_705) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1146 = qlx.apply #qlx.action<h>(%1125#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_706 = arith.constant 3.1415926535897931 : f64
    %1147 = qlx.apply #qlx.action<pauli_rotation>(%1146, %cst_706) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1148 = qlx.apply #qlx.action<h>(%1147) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1149 = qlx.apply #qlx.action<h>(%1108#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_707 = arith.constant 3.1415926535897931 : f64
    %1150 = qlx.apply #qlx.action<pauli_rotation>(%1149, %cst_707) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1151 = qlx.apply #qlx.action<h>(%1150) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_708 = arith.constant 1.5707963267948966 : f64
    %1152:2 = qlx.apply #qlx.action<pauli_rotation>(%1148, %1151, %cst_708) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_709 = arith.constant 1.5707963267948966 : f64
    %1153 = qlx.apply #qlx.action<pauli_rotation>(%1152#0, %cst_709) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_710 = arith.constant 1.5707963267948966 : f64
    %1154 = qlx.apply #qlx.action<pauli_rotation>(%1152#1, %cst_710) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_711 = arith.constant 1.5707963267948966 : f64
    %1155:2 = qlx.apply #qlx.action<pauli_rotation>(%1153, %1154, %cst_711) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1156 = qlx.apply #qlx.action<h>(%1130#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1157 = qlx.apply #qlx.action<h>(%1155#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_712 = arith.constant 3.1415926535897931 : f64
    %1158 = qlx.apply #qlx.action<pauli_rotation>(%1157, %cst_712) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1159 = qlx.apply #qlx.action<h>(%1158) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_713 = arith.constant 1.5707963267948966 : f64
    %1160:2 = qlx.apply #qlx.action<pauli_rotation>(%1156, %1159, %cst_713) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_714 = arith.constant 1.5707963267948966 : f64
    %1161 = qlx.apply #qlx.action<pauli_rotation>(%1160#0, %cst_714) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_715 = arith.constant 1.5707963267948966 : f64
    %1162 = qlx.apply #qlx.action<pauli_rotation>(%1160#1, %cst_715) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_716 = arith.constant 1.5707963267948966 : f64
    %1163:2 = qlx.apply #qlx.action<pauli_rotation>(%1161, %1162, %cst_716) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1164 = qlx.apply #qlx.action<h>(%1145#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_717 = arith.constant 3.1415926535897931 : f64
    %1165 = qlx.apply #qlx.action<pauli_rotation>(%1164, %cst_717) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1166 = qlx.apply #qlx.action<h>(%1163#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_718 = arith.constant 3.1415926535897931 : f64
    %1167 = qlx.apply #qlx.action<pauli_rotation>(%1166, %cst_718) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_719 = arith.constant 5.000000e-01 : f64
    %1168:2 = qlx.apply #qlx.action<pauli_rotation>(%1165, %1167, %cst_719) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1169 = qlx.apply #qlx.action<h>(%1145#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_720 = arith.constant 3.1415926535897931 : f64
    %1170 = qlx.apply #qlx.action<pauli_rotation>(%1169, %cst_720) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1171 = qlx.apply #qlx.action<h>(%1170) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1172 = qlx.apply #qlx.action<h>(%1168#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_721 = arith.constant 1.5707963267948966 : f64
    %1173:2 = qlx.apply #qlx.action<pauli_rotation>(%1171, %1172, %cst_721) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_722 = arith.constant 1.5707963267948966 : f64
    %1174 = qlx.apply #qlx.action<pauli_rotation>(%1173#0, %cst_722) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_723 = arith.constant 1.5707963267948966 : f64
    %1175 = qlx.apply #qlx.action<pauli_rotation>(%1173#1, %cst_723) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_724 = arith.constant 1.5707963267948966 : f64
    %1176:2 = qlx.apply #qlx.action<pauli_rotation>(%1174, %1175, %cst_724) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1177 = qlx.apply #qlx.action<h>(%1168#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1178 = qlx.apply #qlx.action<h>(%1163#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_725 = arith.constant 3.1415926535897931 : f64
    %1179 = qlx.apply #qlx.action<pauli_rotation>(%1178, %cst_725) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1180 = qlx.apply #qlx.action<h>(%1179) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_726 = arith.constant 1.5707963267948966 : f64
    %1181:2 = qlx.apply #qlx.action<pauli_rotation>(%1177, %1180, %cst_726) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_727 = arith.constant 1.5707963267948966 : f64
    %1182 = qlx.apply #qlx.action<pauli_rotation>(%1181#0, %cst_727) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_728 = arith.constant 1.5707963267948966 : f64
    %1183 = qlx.apply #qlx.action<pauli_rotation>(%1181#1, %cst_728) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_729 = arith.constant 1.5707963267948966 : f64
    %1184:2 = qlx.apply #qlx.action<pauli_rotation>(%1182, %1183, %cst_729) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1185 = qlx.apply #qlx.action<h>(%1176#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_730 = arith.constant 3.1415926535897931 : f64
    %1186 = qlx.apply #qlx.action<pauli_rotation>(%1185, %cst_730) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1187 = qlx.apply #qlx.action<h>(%1184#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_731 = arith.constant 3.1415926535897931 : f64
    %1188 = qlx.apply #qlx.action<pauli_rotation>(%1187, %cst_731) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_732 = arith.constant 2.500000e-01 : f64
    %1189:2 = qlx.apply #qlx.action<pauli_rotation>(%1186, %1188, %cst_732) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1190 = qlx.apply #qlx.action<h>(%1137#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_733 = arith.constant 3.1415926535897931 : f64
    %1191 = qlx.apply #qlx.action<pauli_rotation>(%1190, %cst_733) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1192 = qlx.apply #qlx.action<h>(%1191) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1193 = qlx.apply #qlx.action<h>(%1176#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_734 = arith.constant 3.1415926535897931 : f64
    %1194 = qlx.apply #qlx.action<pauli_rotation>(%1193, %cst_734) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1195 = qlx.apply #qlx.action<h>(%1194) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_735 = arith.constant 1.5707963267948966 : f64
    %1196:2 = qlx.apply #qlx.action<pauli_rotation>(%1192, %1195, %cst_735) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_736 = arith.constant 1.5707963267948966 : f64
    %1197 = qlx.apply #qlx.action<pauli_rotation>(%1196#0, %cst_736) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_737 = arith.constant 1.5707963267948966 : f64
    %1198 = qlx.apply #qlx.action<pauli_rotation>(%1196#1, %cst_737) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_738 = arith.constant 1.5707963267948966 : f64
    %1199:2 = qlx.apply #qlx.action<pauli_rotation>(%1197, %1198, %cst_738) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1200 = qlx.apply #qlx.action<h>(%1199#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_739 = arith.constant 3.1415926535897931 : f64
    %1201 = qlx.apply #qlx.action<pauli_rotation>(%1200, %cst_739) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1202 = qlx.apply #qlx.action<h>(%1201) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1203 = qlx.apply #qlx.action<h>(%1189#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_740 = arith.constant 1.5707963267948966 : f64
    %1204:2 = qlx.apply #qlx.action<pauli_rotation>(%1202, %1203, %cst_740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_741 = arith.constant 1.5707963267948966 : f64
    %1205 = qlx.apply #qlx.action<pauli_rotation>(%1204#0, %cst_741) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_742 = arith.constant 1.5707963267948966 : f64
    %1206 = qlx.apply #qlx.action<pauli_rotation>(%1204#1, %cst_742) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_743 = arith.constant 1.5707963267948966 : f64
    %1207:2 = qlx.apply #qlx.action<pauli_rotation>(%1205, %1206, %cst_743) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1208 = qlx.apply #qlx.action<h>(%1184#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_744 = arith.constant 3.1415926535897931 : f64
    %1209 = qlx.apply #qlx.action<pauli_rotation>(%1208, %cst_744) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1210 = qlx.apply #qlx.action<h>(%1209) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1211 = qlx.apply #qlx.action<h>(%1155#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_745 = arith.constant 3.1415926535897931 : f64
    %1212 = qlx.apply #qlx.action<pauli_rotation>(%1211, %cst_745) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1213 = qlx.apply #qlx.action<h>(%1212) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_746 = arith.constant 1.5707963267948966 : f64
    %1214:2 = qlx.apply #qlx.action<pauli_rotation>(%1210, %1213, %cst_746) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_747 = arith.constant 1.5707963267948966 : f64
    %1215 = qlx.apply #qlx.action<pauli_rotation>(%1214#0, %cst_747) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_748 = arith.constant 1.5707963267948966 : f64
    %1216 = qlx.apply #qlx.action<pauli_rotation>(%1214#1, %cst_748) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_749 = arith.constant 1.5707963267948966 : f64
    %1217:2 = qlx.apply #qlx.action<pauli_rotation>(%1215, %1216, %cst_749) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1218 = qlx.apply #qlx.action<h>(%1189#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1219 = qlx.apply #qlx.action<h>(%1217#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_750 = arith.constant 3.1415926535897931 : f64
    %1220 = qlx.apply #qlx.action<pauli_rotation>(%1219, %cst_750) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1221 = qlx.apply #qlx.action<h>(%1220) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_751 = arith.constant 1.5707963267948966 : f64
    %1222:2 = qlx.apply #qlx.action<pauli_rotation>(%1218, %1221, %cst_751) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_752 = arith.constant 1.5707963267948966 : f64
    %1223 = qlx.apply #qlx.action<pauli_rotation>(%1222#0, %cst_752) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_753 = arith.constant 1.5707963267948966 : f64
    %1224 = qlx.apply #qlx.action<pauli_rotation>(%1222#1, %cst_753) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_754 = arith.constant 1.5707963267948966 : f64
    %1225:2 = qlx.apply #qlx.action<pauli_rotation>(%1223, %1224, %cst_754) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1226 = qlx.apply #qlx.action<h>(%1207#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_755 = arith.constant 3.1415926535897931 : f64
    %1227 = qlx.apply #qlx.action<pauli_rotation>(%1226, %cst_755) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1228 = qlx.apply #qlx.action<h>(%1225#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_756 = arith.constant 3.1415926535897931 : f64
    %1229 = qlx.apply #qlx.action<pauli_rotation>(%1228, %cst_756) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_757 = arith.constant 2.500000e-01 : f64
    %1230:2 = qlx.apply #qlx.action<pauli_rotation>(%1227, %1229, %cst_757) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1231 = qlx.apply #qlx.action<h>(%1225#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_758 = arith.constant 1.5707963267948966 : f64
    %1232 = qlx.apply #qlx.action<pauli_rotation>(%1231, %cst_758) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1233 = qlx.apply #qlx.action<h>(%1232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1234 = qlx.apply #qlx.action<h>(%1217#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_759 = arith.constant 1.5707963267948966 : f64
    %1235 = qlx.apply #qlx.action<pauli_rotation>(%1234, %cst_759) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1236 = qlx.apply #qlx.action<h>(%1235) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_760 = arith.constant 1.250000e-01 : f64
    %1237:2 = qlx.apply #qlx.action<pauli_rotation>(%1233, %1236, %cst_760) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_761 = arith.constant 1.5707963267948966 : f64
    %1238 = qlx.apply #qlx.action<pauli_rotation>(%1237#0, %cst_761) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_762 = arith.constant 1.5707963267948966 : f64
    %1239 = qlx.apply #qlx.action<pauli_rotation>(%1237#1, %cst_762) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_763 = arith.constant 1.250000e-01 : f64
    %1240:2 = qlx.apply #qlx.action<pauli_rotation>(%1238, %1239, %cst_763) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1241 = qlx.apply #qlx.action<h>(%1199#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_764 = arith.constant 1.5707963267948966 : f64
    %1242 = qlx.apply #qlx.action<pauli_rotation>(%1241, %cst_764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1243 = qlx.apply #qlx.action<h>(%1242) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1244 = qlx.apply #qlx.action<h>(%1207#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_765 = arith.constant 1.5707963267948966 : f64
    %1245 = qlx.apply #qlx.action<pauli_rotation>(%1244, %cst_765) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1246 = qlx.apply #qlx.action<h>(%1245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_766 = arith.constant 1.250000e-01 : f64
    %1247:2 = qlx.apply #qlx.action<pauli_rotation>(%1243, %1246, %cst_766) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_767 = arith.constant 1.5707963267948966 : f64
    %1248 = qlx.apply #qlx.action<pauli_rotation>(%1247#0, %cst_767) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_768 = arith.constant 1.5707963267948966 : f64
    %1249 = qlx.apply #qlx.action<pauli_rotation>(%1247#1, %cst_768) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_769 = arith.constant 1.250000e-01 : f64
    %1250:2 = qlx.apply #qlx.action<pauli_rotation>(%1248, %1249, %cst_769) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_770 = arith.constant 1.5707963267948966 : f64
    %1251 = qlx.apply #qlx.action<pauli_rotation>(%1230#1, %cst_770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1252 = qlx.apply #qlx.action<h>(%1251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1253 = qlx.apply #qlx.action<h>(%1240#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_771 = arith.constant 1.5707963267948966 : f64
    %1254 = qlx.apply #qlx.action<pauli_rotation>(%1253, %cst_771) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1255 = qlx.apply #qlx.action<h>(%1254) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_772 = arith.constant 1.250000e-01 : f64
    %1256:2 = qlx.apply #qlx.action<pauli_rotation>(%1252, %1255, %cst_772) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_773 = arith.constant 1.5707963267948966 : f64
    %1257 = qlx.apply #qlx.action<pauli_rotation>(%1256#0, %cst_773) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_774 = arith.constant 1.5707963267948966 : f64
    %1258 = qlx.apply #qlx.action<pauli_rotation>(%1256#1, %cst_774) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_775 = arith.constant 1.250000e-01 : f64
    %1259:2 = qlx.apply #qlx.action<pauli_rotation>(%1257, %1258, %cst_775) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1260 = qlx.apply #qlx.action<h>(%1250#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_776 = arith.constant 1.5707963267948966 : f64
    %1261 = qlx.apply #qlx.action<pauli_rotation>(%1260, %cst_776) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1262 = qlx.apply #qlx.action<h>(%1261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_777 = arith.constant 1.5707963267948966 : f64
    %1263 = qlx.apply #qlx.action<pauli_rotation>(%1230#0, %cst_777) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1264 = qlx.apply #qlx.action<h>(%1263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_778 = arith.constant 1.250000e-01 : f64
    %1265:2 = qlx.apply #qlx.action<pauli_rotation>(%1262, %1264, %cst_778) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_779 = arith.constant 1.5707963267948966 : f64
    %1266 = qlx.apply #qlx.action<pauli_rotation>(%1265#0, %cst_779) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_780 = arith.constant 1.5707963267948966 : f64
    %1267 = qlx.apply #qlx.action<pauli_rotation>(%1265#1, %cst_780) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_781 = arith.constant 1.250000e-01 : f64
    %1268:2 = qlx.apply #qlx.action<pauli_rotation>(%1266, %1267, %cst_781) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1269 = qlx.apply #qlx.action<h>(%1240#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_782 = arith.constant 3.1415926535897931 : f64
    %1270 = qlx.apply #qlx.action<pauli_rotation>(%1269, %cst_782) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1271 = qlx.apply #qlx.action<h>(%1270) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1272 = qlx.apply #qlx.action<h>(%1068#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_783 = arith.constant 3.1415926535897931 : f64
    %1273 = qlx.apply #qlx.action<pauli_rotation>(%1272, %cst_783) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1274 = qlx.apply #qlx.action<h>(%1273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_784 = arith.constant 1.4457963267948966 : f64
    %1275:2 = qlx.apply #qlx.action<pauli_rotation>(%1271, %1274, %cst_784) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_785 = arith.constant 1.5707963267948966 : f64
    %1276 = qlx.apply #qlx.action<pauli_rotation>(%1275#0, %cst_785) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_786 = arith.constant 1.5707963267948966 : f64
    %1277 = qlx.apply #qlx.action<pauli_rotation>(%1275#1, %cst_786) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_787 = arith.constant 1.4457963267948966 : f64
    %1278:2 = qlx.apply #qlx.action<pauli_rotation>(%1276, %1277, %cst_787) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1279 = qlx.apply #qlx.action<h>(%1048#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_788 = arith.constant 3.1415926535897931 : f64
    %1280 = qlx.apply #qlx.action<pauli_rotation>(%1279, %cst_788) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1281 = qlx.apply #qlx.action<h>(%1280) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_789 = arith.constant 1.4457963267948966 : f64
    %1282:2 = qlx.apply #qlx.action<pauli_rotation>(%1250#0, %1281, %cst_789) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_790 = arith.constant 1.5707963267948966 : f64
    %1283 = qlx.apply #qlx.action<pauli_rotation>(%1282#1, %cst_790) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_791 = arith.constant 1.5707963267948966 : f64
    %1284 = qlx.apply #qlx.action<pauli_rotation>(%1282#0, %cst_791) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_792 = arith.constant 1.4457963267948966 : f64
    %1285:2 = qlx.apply #qlx.action<pauli_rotation>(%1283, %1284, %cst_792) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1286 = qlx.apply #qlx.action<h>(%1259#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_793 = arith.constant 3.1415926535897931 : f64
    %1287 = qlx.apply #qlx.action<pauli_rotation>(%1286, %cst_793) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1288 = qlx.apply #qlx.action<h>(%1287) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1289 = qlx.apply #qlx.action<h>(%1278#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_794 = arith.constant 3.1415926535897931 : f64
    %1290 = qlx.apply #qlx.action<pauli_rotation>(%1289, %cst_794) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1291 = qlx.apply #qlx.action<h>(%1290) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_795 = arith.constant 1.5707963267948966 : f64
    %1292:2 = qlx.apply #qlx.action<pauli_rotation>(%1288, %1291, %cst_795) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_796 = arith.constant 1.5707963267948966 : f64
    %1293 = qlx.apply #qlx.action<pauli_rotation>(%1292#0, %cst_796) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_797 = arith.constant 1.5707963267948966 : f64
    %1294 = qlx.apply #qlx.action<pauli_rotation>(%1292#1, %cst_797) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_798 = arith.constant 1.5707963267948966 : f64
    %1295:2 = qlx.apply #qlx.action<pauli_rotation>(%1293, %1294, %cst_798) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1296 = qlx.apply #qlx.action<h>(%1295#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_799 = arith.constant 3.1415926535897931 : f64
    %1297 = qlx.apply #qlx.action<pauli_rotation>(%1296, %cst_799) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1298 = qlx.apply #qlx.action<h>(%1297) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_800 = arith.constant 1.4457963267948966 : f64
    %1299:2 = qlx.apply #qlx.action<pauli_rotation>(%1259#0, %1298, %cst_800) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_801 = arith.constant 1.5707963267948966 : f64
    %1300 = qlx.apply #qlx.action<pauli_rotation>(%1299#0, %cst_801) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_802 = arith.constant 1.5707963267948966 : f64
    %1301 = qlx.apply #qlx.action<pauli_rotation>(%1299#1, %cst_802) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_803 = arith.constant 1.4457963267948966 : f64
    %1302:2 = qlx.apply #qlx.action<pauli_rotation>(%1300, %1301, %cst_803) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1303 = qlx.apply #qlx.action<h>(%1285#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_804 = arith.constant 3.1415926535897931 : f64
    %1304 = qlx.apply #qlx.action<pauli_rotation>(%1303, %cst_804) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1305 = qlx.apply #qlx.action<h>(%1304) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_805 = arith.constant 1.5707963267948966 : f64
    %1306:2 = qlx.apply #qlx.action<pauli_rotation>(%1268#0, %1305, %cst_805) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_806 = arith.constant 1.5707963267948966 : f64
    %1307 = qlx.apply #qlx.action<pauli_rotation>(%1306#1, %cst_806) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_807 = arith.constant 1.5707963267948966 : f64
    %1308 = qlx.apply #qlx.action<pauli_rotation>(%1306#0, %cst_807) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_808 = arith.constant 1.5707963267948966 : f64
    %1309:2 = qlx.apply #qlx.action<pauli_rotation>(%1307, %1308, %cst_808) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1310 = qlx.apply #qlx.action<h>(%1309#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_809 = arith.constant 1.5707963267948966 : f64
    %1311 = qlx.apply #qlx.action<pauli_rotation>(%1310, %cst_809) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1312 = qlx.apply #qlx.action<h>(%1311) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1313 = qlx.apply #qlx.action<h>(%1268#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_810 = arith.constant 1.5707963267948966 : f64
    %1314 = qlx.apply #qlx.action<pauli_rotation>(%1313, %cst_810) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1315 = qlx.apply #qlx.action<h>(%1314) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_811 = arith.constant 1.250000e-01 : f64
    %1316:2 = qlx.apply #qlx.action<pauli_rotation>(%1312, %1315, %cst_811) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_812 = arith.constant 1.5707963267948966 : f64
    %1317 = qlx.apply #qlx.action<pauli_rotation>(%1316#0, %cst_812) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_813 = arith.constant 1.5707963267948966 : f64
    %1318 = qlx.apply #qlx.action<pauli_rotation>(%1316#1, %cst_813) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_814 = arith.constant 1.250000e-01 : f64
    %1319:2 = qlx.apply #qlx.action<pauli_rotation>(%1317, %1318, %cst_814) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1320 = qlx.apply #qlx.action<h>(%1319#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_815 = arith.constant 3.1415926535897931 : f64
    %1321 = qlx.apply #qlx.action<pauli_rotation>(%1320, %cst_815) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1322 = qlx.apply #qlx.action<h>(%1321) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1323 = qlx.apply #qlx.action<h>(%1302#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_816 = arith.constant 3.1415926535897931 : f64
    %1324 = qlx.apply #qlx.action<pauli_rotation>(%1323, %cst_816) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1325 = qlx.apply #qlx.action<h>(%1324) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_817 = arith.constant 1.5707963267948966 : f64
    %1326:2 = qlx.apply #qlx.action<pauli_rotation>(%1322, %1325, %cst_817) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_818 = arith.constant 1.5707963267948966 : f64
    %1327 = qlx.apply #qlx.action<pauli_rotation>(%1326#0, %cst_818) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_819 = arith.constant 1.5707963267948966 : f64
    %1328 = qlx.apply #qlx.action<pauli_rotation>(%1326#1, %cst_819) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_820 = arith.constant 1.5707963267948966 : f64
    %1329:2 = qlx.apply #qlx.action<pauli_rotation>(%1327, %1328, %cst_820) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1330 = qlx.apply #qlx.action<h>(%1319#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1331 = qlx.apply #qlx.action<h>(%1329#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_821 = arith.constant 3.1415926535897931 : f64
    %1332 = qlx.apply #qlx.action<pauli_rotation>(%1331, %cst_821) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_822 = arith.constant 2.500000e-01 : f64
    %1333:2 = qlx.apply #qlx.action<pauli_rotation>(%1330, %1332, %cst_822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1334 = qlx.apply #qlx.action<h>(%1285#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_823 = arith.constant 3.1415926535897931 : f64
    %1335 = qlx.apply #qlx.action<pauli_rotation>(%1334, %cst_823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1336 = qlx.apply #qlx.action<h>(%1309#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_824 = arith.constant 3.1415926535897931 : f64
    %1337 = qlx.apply #qlx.action<pauli_rotation>(%1336, %cst_824) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1338 = qlx.apply #qlx.action<h>(%1329#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_825 = arith.constant 3.1415926535897931 : f64
    %1339 = qlx.apply #qlx.action<pauli_rotation>(%1338, %cst_825) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1340 = qlx.apply #qlx.action<h>(%1302#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_826 = arith.constant 3.1415926535897931 : f64
    %1341 = qlx.apply #qlx.action<pauli_rotation>(%1340, %cst_826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1342 = qlx.apply #qlx.action<h>(%1295#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_827 = arith.constant 3.1415926535897931 : f64
    %1343 = qlx.apply #qlx.action<pauli_rotation>(%1342, %cst_827) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1344 = qlx.apply #qlx.action<h>(%1278#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_828 = arith.constant 3.1415926535897931 : f64
    %1345 = qlx.apply #qlx.action<pauli_rotation>(%1344, %cst_828) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1346 = qlx.measure <Z> %1335 : !qlx.logical_qubit -> i1
    %1347 = qlx.measure <Z> %1337 : !qlx.logical_qubit -> i1
    %1348 = qlx.measure <Z> %1333#0 : !qlx.logical_qubit -> i1
    %1349 = qlx.measure <Z> %1333#1 : !qlx.logical_qubit -> i1
    %1350 = qlx.measure <Z> %1339 : !qlx.logical_qubit -> i1
    %1351 = qlx.measure <Z> %1341 : !qlx.logical_qubit -> i1
    %1352 = qlx.measure <Z> %1343 : !qlx.logical_qubit -> i1
    %1353 = qlx.measure <Z> %1345 : !qlx.logical_qubit -> i1
  }
}
