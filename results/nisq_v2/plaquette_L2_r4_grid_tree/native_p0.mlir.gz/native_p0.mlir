module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %9:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %10 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_0 = arith.constant 2.500000e-01 : f64
    %11:2 = qlx.apply #qlx.action<pauli_rotation>(%2, %10, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %12 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1 = arith.constant 2.500000e-01 : f64
    %13:2 = qlx.apply #qlx.action<pauli_rotation>(%12, %5, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %14 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2 = arith.constant 2.500000e-01 : f64
    %15:2 = qlx.apply #qlx.action<pauli_rotation>(%6, %14, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %16 = qlx.apply #qlx.action<h>(%11#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %17:2 = qlx.apply #qlx.action<pauli_rotation>(%11#1, %16, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %18 = qlx.apply #qlx.action<pauli_rotation>(%9#0, %cst_4) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %19 = qlx.apply #qlx.action<h>(%18) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %20 = qlx.apply #qlx.action<h>(%9#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %21:2 = qlx.apply #qlx.action<pauli_rotation>(%19, %20, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %22 = qlx.apply #qlx.action<h>(%13#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %23 = qlx.apply #qlx.action<pauli_rotation>(%21#1, %cst_6) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %24:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %23, %cst_7) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %25 = qlx.apply #qlx.action<pauli_rotation>(%24#1, %cst_8) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %26 = qlx.apply #qlx.action<h>(%25) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %27 = qlx.apply #qlx.action<pauli_rotation>(%17#1, %cst_9) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %28 = qlx.apply #qlx.action<h>(%27) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 0.78539816339744828 : f64
    %29:2 = qlx.apply #qlx.action<pauli_rotation>(%26, %28, %cst_10) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_11 = arith.constant 1.5707963267948966 : f64
    %30 = qlx.apply #qlx.action<pauli_rotation>(%24#0, %cst_11) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %31 = qlx.apply #qlx.action<h>(%29#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %32:2 = qlx.apply #qlx.action<pauli_rotation>(%30, %31, %cst_12) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %33 = qlx.apply #qlx.action<pauli_rotation>(%21#0, %cst_13) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %34 = qlx.apply #qlx.action<pauli_rotation>(%32#1, %cst_14) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %35:2 = qlx.apply #qlx.action<pauli_rotation>(%33, %34, %cst_15) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %36 = qlx.apply #qlx.action<pauli_rotation>(%17#0, %cst_16) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %37 = qlx.apply #qlx.action<h>(%29#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %38:2 = qlx.apply #qlx.action<pauli_rotation>(%36, %37, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %39 = qlx.apply #qlx.action<pauli_rotation>(%38#0, %cst_18) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %40 = qlx.apply #qlx.action<pauli_rotation>(%38#1, %cst_19) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %41:2 = qlx.apply #qlx.action<pauli_rotation>(%39, %40, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %42 = qlx.apply #qlx.action<pauli_rotation>(%35#0, %cst_21) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %43 = qlx.apply #qlx.action<h>(%42) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %44 = qlx.apply #qlx.action<pauli_rotation>(%43, %cst_22) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %45 = qlx.apply #qlx.action<h>(%44) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %46 = qlx.apply #qlx.action<pauli_rotation>(%35#1, %cst_23) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %47:2 = qlx.apply #qlx.action<pauli_rotation>(%45, %46, %cst_24) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%32#0, %cst_25) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %49 = qlx.apply #qlx.action<h>(%48) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %50 = qlx.apply #qlx.action<pauli_rotation>(%49, %cst_26) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %51 = qlx.apply #qlx.action<h>(%50) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %52 = qlx.apply #qlx.action<pauli_rotation>(%47#1, %cst_27) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %53:2 = qlx.apply #qlx.action<pauli_rotation>(%51, %52, %cst_28) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_29 = arith.constant 1.5707963267948966 : f64
    %54 = qlx.apply #qlx.action<pauli_rotation>(%53#1, %cst_29) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %55 = qlx.apply #qlx.action<h>(%54) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %56 = qlx.apply #qlx.action<pauli_rotation>(%41#1, %cst_30) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %57 = qlx.apply #qlx.action<h>(%56) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_31 = arith.constant 0.78539816339744828 : f64
    %58:2 = qlx.apply #qlx.action<pauli_rotation>(%55, %57, %cst_31) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %59 = qlx.apply #qlx.action<pauli_rotation>(%53#0, %cst_32) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %60 = qlx.apply #qlx.action<h>(%58#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %61:2 = qlx.apply #qlx.action<pauli_rotation>(%59, %60, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 1.5707963267948966 : f64
    %62 = qlx.apply #qlx.action<pauli_rotation>(%47#0, %cst_34) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %63 = qlx.apply #qlx.action<pauli_rotation>(%61#1, %cst_35) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %64:2 = qlx.apply #qlx.action<pauli_rotation>(%62, %63, %cst_36) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %65 = qlx.apply #qlx.action<pauli_rotation>(%41#0, %cst_37) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<h>(%58#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %67:2 = qlx.apply #qlx.action<pauli_rotation>(%65, %66, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_39 = arith.constant 1.5707963267948966 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%67#1, %cst_39) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %69 = qlx.apply #qlx.action<pauli_rotation>(%67#0, %cst_40) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %70 = qlx.apply #qlx.action<h>(%69) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %71:2 = qlx.apply #qlx.action<pauli_rotation>(%68, %70, %cst_41) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_42 = arith.constant 1.5707963267948966 : f64
    %72 = qlx.apply #qlx.action<pauli_rotation>(%15#0, %cst_42) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<h>(%72) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %74 = qlx.apply #qlx.action<h>(%13#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %75:2 = qlx.apply #qlx.action<pauli_rotation>(%73, %74, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_44 = arith.constant 1.5707963267948966 : f64
    %76 = qlx.apply #qlx.action<pauli_rotation>(%75#1, %cst_44) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %77 = qlx.apply #qlx.action<h>(%76) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 1.5707963267948966 : f64
    %78 = qlx.apply #qlx.action<pauli_rotation>(%61#0, %cst_45) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %79 = qlx.apply #qlx.action<h>(%78) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %80 = qlx.apply #qlx.action<pauli_rotation>(%79, %cst_46) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %81 = qlx.apply #qlx.action<h>(%80) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_47 = arith.constant 1.5707963267948966 : f64
    %82:2 = qlx.apply #qlx.action<pauli_rotation>(%77, %81, %cst_47) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %83 = qlx.apply #qlx.action<pauli_rotation>(%82#1, %cst_48) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %84 = qlx.apply #qlx.action<h>(%83) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_49 = arith.constant 1.5707963267948966 : f64
    %85 = qlx.apply #qlx.action<pauli_rotation>(%71#1, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %86 = qlx.apply #qlx.action<h>(%85) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_50 = arith.constant 0.78539816339744828 : f64
    %87:2 = qlx.apply #qlx.action<pauli_rotation>(%84, %86, %cst_50) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 1.5707963267948966 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%82#0, %cst_51) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %89 = qlx.apply #qlx.action<h>(%87#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %90:2 = qlx.apply #qlx.action<pauli_rotation>(%88, %89, %cst_52) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%75#0, %cst_53) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_54 = arith.constant 1.5707963267948966 : f64
    %92 = qlx.apply #qlx.action<pauli_rotation>(%90#0, %cst_54) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %93 = qlx.apply #qlx.action<h>(%92) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %94:2 = qlx.apply #qlx.action<pauli_rotation>(%91, %93, %cst_55) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_56 = arith.constant 1.5707963267948966 : f64
    %95 = qlx.apply #qlx.action<pauli_rotation>(%71#0, %cst_56) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %96 = qlx.apply #qlx.action<h>(%87#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_57 = arith.constant 1.5707963267948966 : f64
    %97:2 = qlx.apply #qlx.action<pauli_rotation>(%95, %96, %cst_57) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %98 = qlx.apply #qlx.action<pauli_rotation>(%97#0, %cst_58) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %99 = qlx.apply #qlx.action<h>(%98) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %100 = qlx.apply #qlx.action<pauli_rotation>(%99, %cst_59) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %101 = qlx.apply #qlx.action<h>(%100) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_60 = arith.constant 1.5707963267948966 : f64
    %102 = qlx.apply #qlx.action<pauli_rotation>(%97#1, %cst_60) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_61 = arith.constant 1.5707963267948966 : f64
    %103:2 = qlx.apply #qlx.action<pauli_rotation>(%101, %102, %cst_61) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%94#0, %cst_62) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %105 = qlx.apply #qlx.action<h>(%104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_63 = arith.constant 1.5707963267948966 : f64
    %106 = qlx.apply #qlx.action<pauli_rotation>(%105, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %107 = qlx.apply #qlx.action<h>(%106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_64 = arith.constant 1.5707963267948966 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%94#1, %cst_64) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%107, %108, %cst_65) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 1.5707963267948966 : f64
    %110 = qlx.apply #qlx.action<pauli_rotation>(%109#1, %cst_66) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %111 = qlx.apply #qlx.action<h>(%110) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_67 = arith.constant 1.5707963267948966 : f64
    %112 = qlx.apply #qlx.action<pauli_rotation>(%90#1, %cst_67) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_68 = arith.constant 1.5707963267948966 : f64
    %113:2 = qlx.apply #qlx.action<pauli_rotation>(%111, %112, %cst_68) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113#1, %cst_69) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %115 = qlx.apply #qlx.action<h>(%114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_70 = arith.constant 1.5707963267948966 : f64
    %116 = qlx.apply #qlx.action<pauli_rotation>(%103#1, %cst_70) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %117 = qlx.apply #qlx.action<h>(%116) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_71 = arith.constant 0.78539816339744828 : f64
    %118:2 = qlx.apply #qlx.action<pauli_rotation>(%115, %117, %cst_71) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %119 = qlx.apply #qlx.action<pauli_rotation>(%113#0, %cst_72) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %120 = qlx.apply #qlx.action<h>(%118#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_73 = arith.constant 1.5707963267948966 : f64
    %121:2 = qlx.apply #qlx.action<pauli_rotation>(%119, %120, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 1.5707963267948966 : f64
    %122 = qlx.apply #qlx.action<pauli_rotation>(%109#0, %cst_74) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %123 = qlx.apply #qlx.action<pauli_rotation>(%121#0, %cst_75) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %124 = qlx.apply #qlx.action<h>(%123) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %125:2 = qlx.apply #qlx.action<pauli_rotation>(%122, %124, %cst_76) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_77 = arith.constant 1.5707963267948966 : f64
    %126 = qlx.apply #qlx.action<pauli_rotation>(%103#0, %cst_77) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %127 = qlx.apply #qlx.action<h>(%118#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %128:2 = qlx.apply #qlx.action<pauli_rotation>(%126, %127, %cst_78) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_79 = arith.constant 1.5707963267948966 : f64
    %129 = qlx.apply #qlx.action<pauli_rotation>(%121#1, %cst_79) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_80 = arith.constant 1.5707963267948966 : f64
    %130 = qlx.apply #qlx.action<pauli_rotation>(%128#1, %cst_80) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %131:2 = qlx.apply #qlx.action<pauli_rotation>(%129, %130, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.5707963267948966 : f64
    %132 = qlx.apply #qlx.action<pauli_rotation>(%131#1, %cst_82) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %133 = qlx.apply #qlx.action<h>(%132) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %134 = qlx.apply #qlx.action<pauli_rotation>(%128#0, %cst_83) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<h>(%134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %136 = qlx.apply #qlx.action<pauli_rotation>(%135, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %137 = qlx.apply #qlx.action<h>(%136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 5.000000e-01 : f64
    %138:2 = qlx.apply #qlx.action<pauli_rotation>(%133, %137, %cst_85) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_86 = arith.constant 1.5707963267948966 : f64
    %139 = qlx.apply #qlx.action<pauli_rotation>(%131#0, %cst_86) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %140 = qlx.apply #qlx.action<h>(%138#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %141:2 = qlx.apply #qlx.action<pauli_rotation>(%139, %140, %cst_87) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.5707963267948966 : f64
    %142 = qlx.apply #qlx.action<pauli_rotation>(%141#0, %cst_88) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %143 = qlx.apply #qlx.action<h>(%142) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_89) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %146 = qlx.apply #qlx.action<pauli_rotation>(%141#1, %cst_90) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_91 = arith.constant 1.5707963267948966 : f64
    %147:2 = qlx.apply #qlx.action<pauli_rotation>(%145, %146, %cst_91) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_92 = arith.constant 1.5707963267948966 : f64
    %148 = qlx.apply #qlx.action<pauli_rotation>(%147#1, %cst_92) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %149 = qlx.apply #qlx.action<h>(%148) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %150 = qlx.apply #qlx.action<h>(%138#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %151 = qlx.apply #qlx.action<pauli_rotation>(%150, %cst_93) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %152 = qlx.apply #qlx.action<h>(%151) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_94 = arith.constant 5.000000e-01 : f64
    %153:2 = qlx.apply #qlx.action<pauli_rotation>(%149, %152, %cst_94) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %154 = qlx.apply #qlx.action<pauli_rotation>(%147#0, %cst_95) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %155 = qlx.apply #qlx.action<h>(%153#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %156:2 = qlx.apply #qlx.action<pauli_rotation>(%154, %155, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_97 = arith.constant 1.5707963267948966 : f64
    %157 = qlx.apply #qlx.action<pauli_rotation>(%156#1, %cst_97) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %158 = qlx.apply #qlx.action<h>(%157) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %159 = qlx.apply #qlx.action<h>(%153#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_98 = arith.constant 1.5707963267948966 : f64
    %160 = qlx.apply #qlx.action<pauli_rotation>(%159, %cst_98) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %161 = qlx.apply #qlx.action<h>(%160) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %162:2 = qlx.apply #qlx.action<pauli_rotation>(%158, %161, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %163 = qlx.apply #qlx.action<pauli_rotation>(%64#0, %cst_100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %164 = qlx.apply #qlx.action<h>(%163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_101 = arith.constant 1.5707963267948966 : f64
    %165 = qlx.apply #qlx.action<pauli_rotation>(%164, %cst_101) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %166 = qlx.apply #qlx.action<h>(%165) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %167 = qlx.apply #qlx.action<pauli_rotation>(%64#1, %cst_102) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_103 = arith.constant 1.5707963267948966 : f64
    %168:2 = qlx.apply #qlx.action<pauli_rotation>(%166, %167, %cst_103) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_104 = arith.constant 1.5707963267948966 : f64
    %169 = qlx.apply #qlx.action<pauli_rotation>(%156#0, %cst_104) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %170 = qlx.apply #qlx.action<h>(%169) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_105 = arith.constant 1.5707963267948966 : f64
    %171 = qlx.apply #qlx.action<pauli_rotation>(%170, %cst_105) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %172 = qlx.apply #qlx.action<h>(%171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_106 = arith.constant 1.5707963267948966 : f64
    %173 = qlx.apply #qlx.action<pauli_rotation>(%168#1, %cst_106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_107 = arith.constant 1.5707963267948966 : f64
    %174:2 = qlx.apply #qlx.action<pauli_rotation>(%172, %173, %cst_107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_108 = arith.constant 1.5707963267948966 : f64
    %175 = qlx.apply #qlx.action<pauli_rotation>(%174#1, %cst_108) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %176 = qlx.apply #qlx.action<h>(%175) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_109 = arith.constant 1.5707963267948966 : f64
    %177 = qlx.apply #qlx.action<pauli_rotation>(%162#1, %cst_109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %178 = qlx.apply #qlx.action<h>(%177) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_110 = arith.constant 0.78539816339744828 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%176, %178, %cst_110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_111 = arith.constant 1.5707963267948966 : f64
    %180 = qlx.apply #qlx.action<pauli_rotation>(%174#0, %cst_111) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %181 = qlx.apply #qlx.action<h>(%179#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 1.5707963267948966 : f64
    %182:2 = qlx.apply #qlx.action<pauli_rotation>(%180, %181, %cst_112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_113 = arith.constant 1.5707963267948966 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%168#0, %cst_113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 1.5707963267948966 : f64
    %184 = qlx.apply #qlx.action<pauli_rotation>(%182#1, %cst_114) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_115 = arith.constant 1.5707963267948966 : f64
    %185:2 = qlx.apply #qlx.action<pauli_rotation>(%183, %184, %cst_115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%162#0, %cst_116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %187 = qlx.apply #qlx.action<h>(%179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %188:2 = qlx.apply #qlx.action<pauli_rotation>(%186, %187, %cst_117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %189 = qlx.apply #qlx.action<pauli_rotation>(%188#0, %cst_118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %190 = qlx.apply #qlx.action<pauli_rotation>(%188#1, %cst_119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %191:2 = qlx.apply #qlx.action<pauli_rotation>(%189, %190, %cst_120) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %192 = qlx.apply #qlx.action<pauli_rotation>(%185#0, %cst_121) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %193 = qlx.apply #qlx.action<h>(%192) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %194 = qlx.apply #qlx.action<pauli_rotation>(%193, %cst_122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %195 = qlx.apply #qlx.action<h>(%194) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%185#1, %cst_123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %197:2 = qlx.apply #qlx.action<pauli_rotation>(%195, %196, %cst_124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_125 = arith.constant 1.5707963267948966 : f64
    %198 = qlx.apply #qlx.action<pauli_rotation>(%182#0, %cst_125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %199 = qlx.apply #qlx.action<h>(%198) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_126 = arith.constant 1.5707963267948966 : f64
    %200 = qlx.apply #qlx.action<pauli_rotation>(%199, %cst_126) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %201 = qlx.apply #qlx.action<h>(%200) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 1.5707963267948966 : f64
    %202 = qlx.apply #qlx.action<pauli_rotation>(%197#1, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_128 = arith.constant 1.5707963267948966 : f64
    %203:2 = qlx.apply #qlx.action<pauli_rotation>(%201, %202, %cst_128) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %204 = qlx.apply #qlx.action<pauli_rotation>(%203#1, %cst_129) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %205 = qlx.apply #qlx.action<h>(%204) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %206 = qlx.apply #qlx.action<pauli_rotation>(%191#1, %cst_130) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_131 = arith.constant 0.78539816339744828 : f64
    %208:2 = qlx.apply #qlx.action<pauli_rotation>(%205, %207, %cst_131) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %209 = qlx.apply #qlx.action<pauli_rotation>(%203#0, %cst_132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %210 = qlx.apply #qlx.action<h>(%208#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_133 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%209, %210, %cst_133) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_134 = arith.constant 1.5707963267948966 : f64
    %212 = qlx.apply #qlx.action<pauli_rotation>(%197#0, %cst_134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %213 = qlx.apply #qlx.action<pauli_rotation>(%211#1, %cst_135) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %214:2 = qlx.apply #qlx.action<pauli_rotation>(%212, %213, %cst_136) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %215 = qlx.apply #qlx.action<pauli_rotation>(%191#0, %cst_137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %216 = qlx.apply #qlx.action<h>(%208#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_138 = arith.constant 1.5707963267948966 : f64
    %217:2 = qlx.apply #qlx.action<pauli_rotation>(%215, %216, %cst_138) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_139 = arith.constant 1.5707963267948966 : f64
    %218 = qlx.apply #qlx.action<pauli_rotation>(%217#1, %cst_139) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_140 = arith.constant 1.5707963267948966 : f64
    %219 = qlx.apply #qlx.action<pauli_rotation>(%217#0, %cst_140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<h>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %221:2 = qlx.apply #qlx.action<pauli_rotation>(%218, %220, %cst_141) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 1.5707963267948966 : f64
    %222 = qlx.apply #qlx.action<pauli_rotation>(%125#0, %cst_142) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %223 = qlx.apply #qlx.action<h>(%222) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %224 = qlx.apply #qlx.action<pauli_rotation>(%223, %cst_143) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %225 = qlx.apply #qlx.action<h>(%224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %226 = qlx.apply #qlx.action<pauli_rotation>(%125#1, %cst_144) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_145 = arith.constant 1.5707963267948966 : f64
    %227:2 = qlx.apply #qlx.action<pauli_rotation>(%225, %226, %cst_145) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_146 = arith.constant 1.5707963267948966 : f64
    %228 = qlx.apply #qlx.action<pauli_rotation>(%227#1, %cst_146) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %229 = qlx.apply #qlx.action<h>(%228) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_147 = arith.constant 1.5707963267948966 : f64
    %230 = qlx.apply #qlx.action<pauli_rotation>(%211#0, %cst_147) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %231 = qlx.apply #qlx.action<h>(%230) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231, %cst_148) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %233 = qlx.apply #qlx.action<h>(%232) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_149 = arith.constant 1.5707963267948966 : f64
    %234:2 = qlx.apply #qlx.action<pauli_rotation>(%229, %233, %cst_149) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_150 = arith.constant 1.5707963267948966 : f64
    %235 = qlx.apply #qlx.action<pauli_rotation>(%234#1, %cst_150) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %236 = qlx.apply #qlx.action<h>(%235) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_151 = arith.constant 1.5707963267948966 : f64
    %237 = qlx.apply #qlx.action<pauli_rotation>(%221#1, %cst_151) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<h>(%237) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_152 = arith.constant 0.78539816339744828 : f64
    %239:2 = qlx.apply #qlx.action<pauli_rotation>(%236, %238, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_153 = arith.constant 1.5707963267948966 : f64
    %240 = qlx.apply #qlx.action<pauli_rotation>(%234#0, %cst_153) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %241 = qlx.apply #qlx.action<h>(%239#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %242:2 = qlx.apply #qlx.action<pauli_rotation>(%240, %241, %cst_154) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %243 = qlx.apply #qlx.action<pauli_rotation>(%227#0, %cst_155) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_156 = arith.constant 1.5707963267948966 : f64
    %244 = qlx.apply #qlx.action<pauli_rotation>(%242#0, %cst_156) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %245 = qlx.apply #qlx.action<h>(%244) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_157 = arith.constant 1.5707963267948966 : f64
    %246:2 = qlx.apply #qlx.action<pauli_rotation>(%243, %245, %cst_157) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_158 = arith.constant 1.5707963267948966 : f64
    %247 = qlx.apply #qlx.action<pauli_rotation>(%221#0, %cst_158) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %248 = qlx.apply #qlx.action<h>(%239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_159 = arith.constant 1.5707963267948966 : f64
    %249:2 = qlx.apply #qlx.action<pauli_rotation>(%247, %248, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %250 = qlx.apply #qlx.action<pauli_rotation>(%249#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %251 = qlx.apply #qlx.action<h>(%250) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.5707963267948966 : f64
    %252 = qlx.apply #qlx.action<pauli_rotation>(%251, %cst_161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %253 = qlx.apply #qlx.action<h>(%252) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_162 = arith.constant 1.5707963267948966 : f64
    %254 = qlx.apply #qlx.action<pauli_rotation>(%249#1, %cst_162) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_163 = arith.constant 1.5707963267948966 : f64
    %255:2 = qlx.apply #qlx.action<pauli_rotation>(%253, %254, %cst_163) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_164 = arith.constant 1.5707963267948966 : f64
    %256 = qlx.apply #qlx.action<pauli_rotation>(%246#0, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %257 = qlx.apply #qlx.action<h>(%256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 1.5707963267948966 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%257, %cst_165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<h>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %260 = qlx.apply #qlx.action<pauli_rotation>(%246#1, %cst_166) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %261:2 = qlx.apply #qlx.action<pauli_rotation>(%259, %260, %cst_167) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_168 = arith.constant 1.5707963267948966 : f64
    %262 = qlx.apply #qlx.action<pauli_rotation>(%261#1, %cst_168) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %263 = qlx.apply #qlx.action<h>(%262) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 1.5707963267948966 : f64
    %264 = qlx.apply #qlx.action<pauli_rotation>(%242#1, %cst_169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_170 = arith.constant 1.5707963267948966 : f64
    %265:2 = qlx.apply #qlx.action<pauli_rotation>(%263, %264, %cst_170) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_171 = arith.constant 1.5707963267948966 : f64
    %266 = qlx.apply #qlx.action<pauli_rotation>(%265#1, %cst_171) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %267 = qlx.apply #qlx.action<h>(%266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %268 = qlx.apply #qlx.action<pauli_rotation>(%255#1, %cst_172) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %269 = qlx.apply #qlx.action<h>(%268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_173 = arith.constant 0.78539816339744828 : f64
    %270:2 = qlx.apply #qlx.action<pauli_rotation>(%267, %269, %cst_173) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_174 = arith.constant 1.5707963267948966 : f64
    %271 = qlx.apply #qlx.action<pauli_rotation>(%265#0, %cst_174) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %272 = qlx.apply #qlx.action<h>(%270#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 1.5707963267948966 : f64
    %273:2 = qlx.apply #qlx.action<pauli_rotation>(%271, %272, %cst_175) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_176 = arith.constant 1.5707963267948966 : f64
    %274 = qlx.apply #qlx.action<pauli_rotation>(%261#0, %cst_176) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_177 = arith.constant 1.5707963267948966 : f64
    %275 = qlx.apply #qlx.action<pauli_rotation>(%273#0, %cst_177) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %276 = qlx.apply #qlx.action<h>(%275) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %277:2 = qlx.apply #qlx.action<pauli_rotation>(%274, %276, %cst_178) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_179 = arith.constant 1.5707963267948966 : f64
    %278 = qlx.apply #qlx.action<pauli_rotation>(%255#0, %cst_179) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %279 = qlx.apply #qlx.action<h>(%270#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_180 = arith.constant 1.5707963267948966 : f64
    %280:2 = qlx.apply #qlx.action<pauli_rotation>(%278, %279, %cst_180) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_181 = arith.constant 1.5707963267948966 : f64
    %281 = qlx.apply #qlx.action<pauli_rotation>(%280#0, %cst_181) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %282 = qlx.apply #qlx.action<h>(%281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_182 = arith.constant 1.5707963267948966 : f64
    %283 = qlx.apply #qlx.action<pauli_rotation>(%282, %cst_182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_183 = arith.constant 1.5707963267948966 : f64
    %284 = qlx.apply #qlx.action<pauli_rotation>(%214#1, %cst_183) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %285 = qlx.apply #qlx.action<h>(%284) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %286 = qlx.apply #qlx.action<pauli_rotation>(%285, %cst_184) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.5707963267948966 : f64
    %287:2 = qlx.apply #qlx.action<pauli_rotation>(%283, %286, %cst_185) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_186 = arith.constant 1.5707963267948966 : f64
    %288 = qlx.apply #qlx.action<pauli_rotation>(%280#1, %cst_186) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %289 = qlx.apply #qlx.action<h>(%288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_187 = arith.constant 1.5707963267948966 : f64
    %290 = qlx.apply #qlx.action<pauli_rotation>(%273#1, %cst_187) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_188 = arith.constant 1.5707963267948966 : f64
    %291:2 = qlx.apply #qlx.action<pauli_rotation>(%289, %290, %cst_188) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_189 = arith.constant 1.5707963267948966 : f64
    %292 = qlx.apply #qlx.action<pauli_rotation>(%277#1, %cst_189) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %293 = qlx.apply #qlx.action<pauli_rotation>(%291#1, %cst_190) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_191 = arith.constant 1.5707963267948966 : f64
    %294:2 = qlx.apply #qlx.action<pauli_rotation>(%292, %293, %cst_191) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_192 = arith.constant 1.5707963267948966 : f64
    %295 = qlx.apply #qlx.action<pauli_rotation>(%294#1, %cst_192) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %296 = qlx.apply #qlx.action<h>(%295) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %297 = qlx.apply #qlx.action<pauli_rotation>(%287#1, %cst_193) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %298 = qlx.apply #qlx.action<h>(%297) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_194 = arith.constant 0.78539816339744828 : f64
    %299:2 = qlx.apply #qlx.action<pauli_rotation>(%296, %298, %cst_194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_195 = arith.constant 1.5707963267948966 : f64
    %300 = qlx.apply #qlx.action<pauli_rotation>(%294#0, %cst_195) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %301 = qlx.apply #qlx.action<h>(%299#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %302:2 = qlx.apply #qlx.action<pauli_rotation>(%300, %301, %cst_196) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_197 = arith.constant 1.5707963267948966 : f64
    %303 = qlx.apply #qlx.action<pauli_rotation>(%291#0, %cst_197) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_198 = arith.constant 1.5707963267948966 : f64
    %304 = qlx.apply #qlx.action<pauli_rotation>(%302#1, %cst_198) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_199 = arith.constant 1.5707963267948966 : f64
    %305:2 = qlx.apply #qlx.action<pauli_rotation>(%303, %304, %cst_199) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_200 = arith.constant 1.5707963267948966 : f64
    %306 = qlx.apply #qlx.action<pauli_rotation>(%287#0, %cst_200) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %307 = qlx.apply #qlx.action<h>(%299#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 1.5707963267948966 : f64
    %308:2 = qlx.apply #qlx.action<pauli_rotation>(%306, %307, %cst_201) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_202 = arith.constant 1.5707963267948966 : f64
    %309 = qlx.apply #qlx.action<pauli_rotation>(%308#0, %cst_202) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %310:2 = qlx.apply #qlx.action<pauli_rotation>(%308#1, %309, %cst_203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_204 = arith.constant 1.5707963267948966 : f64
    %311 = qlx.apply #qlx.action<pauli_rotation>(%305#0, %cst_204) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_205 = arith.constant 1.5707963267948966 : f64
    %312 = qlx.apply #qlx.action<pauli_rotation>(%305#1, %cst_205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_206 = arith.constant 1.5707963267948966 : f64
    %313:2 = qlx.apply #qlx.action<pauli_rotation>(%311, %312, %cst_206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %314 = qlx.apply #qlx.action<pauli_rotation>(%302#0, %cst_207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %315 = qlx.apply #qlx.action<h>(%314) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %316 = qlx.apply #qlx.action<pauli_rotation>(%315, %cst_208) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %317 = qlx.apply #qlx.action<h>(%316) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %318 = qlx.apply #qlx.action<pauli_rotation>(%313#1, %cst_209) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %319:2 = qlx.apply #qlx.action<pauli_rotation>(%317, %318, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_211 = arith.constant 1.5707963267948966 : f64
    %320 = qlx.apply #qlx.action<pauli_rotation>(%319#1, %cst_211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %321 = qlx.apply #qlx.action<h>(%320) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 1.5707963267948966 : f64
    %322 = qlx.apply #qlx.action<pauli_rotation>(%310#0, %cst_212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %323 = qlx.apply #qlx.action<h>(%322) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 0.78539816339744828 : f64
    %324:2 = qlx.apply #qlx.action<pauli_rotation>(%321, %323, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %325 = qlx.apply #qlx.action<pauli_rotation>(%319#0, %cst_214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %326 = qlx.apply #qlx.action<h>(%324#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %327:2 = qlx.apply #qlx.action<pauli_rotation>(%325, %326, %cst_215) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %328 = qlx.apply #qlx.action<pauli_rotation>(%313#0, %cst_216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_217 = arith.constant 1.5707963267948966 : f64
    %329 = qlx.apply #qlx.action<pauli_rotation>(%327#1, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_218 = arith.constant 1.5707963267948966 : f64
    %330:2 = qlx.apply #qlx.action<pauli_rotation>(%328, %329, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_219 = arith.constant 1.5707963267948966 : f64
    %331 = qlx.apply #qlx.action<pauli_rotation>(%310#1, %cst_219) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %332 = qlx.apply #qlx.action<h>(%324#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %333:2 = qlx.apply #qlx.action<pauli_rotation>(%331, %332, %cst_220) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_221 = arith.constant 1.5707963267948966 : f64
    %334 = qlx.apply #qlx.action<pauli_rotation>(%277#0, %cst_221) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %335 = qlx.apply #qlx.action<h>(%334) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_222 = arith.constant 3.1415926535897931 : f64
    %336 = qlx.apply #qlx.action<pauli_rotation>(%335, %cst_222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_223 = arith.constant 1.5707963267948966 : f64
    %337 = qlx.apply #qlx.action<pauli_rotation>(%327#0, %cst_223) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %338 = qlx.apply #qlx.action<h>(%337) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_224 = arith.constant 1.5707963267948966 : f64
    %339 = qlx.apply #qlx.action<pauli_rotation>(%338, %cst_224) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %340 = qlx.apply #qlx.action<h>(%339) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_225 = arith.constant 1.5707963267948966 : f64
    %341:2 = qlx.apply #qlx.action<pauli_rotation>(%336, %340, %cst_225) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %342 = qlx.apply #qlx.action<pauli_rotation>(%330#0, %cst_226) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %343 = qlx.apply #qlx.action<h>(%342) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_227 = arith.constant 1.5707963267948966 : f64
    %344 = qlx.apply #qlx.action<pauli_rotation>(%330#1, %cst_227) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_228 = arith.constant 1.5707963267948966 : f64
    %345:2 = qlx.apply #qlx.action<pauli_rotation>(%343, %344, %cst_228) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_229 = arith.constant 1.5707963267948966 : f64
    %346 = qlx.apply #qlx.action<pauli_rotation>(%15#1, %cst_229) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %347 = qlx.apply #qlx.action<h>(%346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_230 = arith.constant 1.5707963267948966 : f64
    %348 = qlx.apply #qlx.action<pauli_rotation>(%345#1, %cst_230) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %349:2 = qlx.apply #qlx.action<pauli_rotation>(%347, %348, %cst_231) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_232 = arith.constant 1.5707963267948966 : f64
    %350 = qlx.apply #qlx.action<pauli_rotation>(%349#1, %cst_232) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %351 = qlx.apply #qlx.action<h>(%350) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_233 = arith.constant 1.5707963267948966 : f64
    %352 = qlx.apply #qlx.action<pauli_rotation>(%341#1, %cst_233) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %353 = qlx.apply #qlx.action<h>(%352) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_234 = arith.constant 0.78539816339744828 : f64
    %354:2 = qlx.apply #qlx.action<pauli_rotation>(%351, %353, %cst_234) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_235 = arith.constant 1.5707963267948966 : f64
    %355 = qlx.apply #qlx.action<pauli_rotation>(%349#0, %cst_235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %356 = qlx.apply #qlx.action<h>(%354#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 1.5707963267948966 : f64
    %357:2 = qlx.apply #qlx.action<pauli_rotation>(%355, %356, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_237 = arith.constant 1.5707963267948966 : f64
    %358 = qlx.apply #qlx.action<pauli_rotation>(%345#0, %cst_237) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_238 = arith.constant 1.5707963267948966 : f64
    %359 = qlx.apply #qlx.action<pauli_rotation>(%357#1, %cst_238) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %360:2 = qlx.apply #qlx.action<pauli_rotation>(%358, %359, %cst_239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_240 = arith.constant 1.5707963267948966 : f64
    %361 = qlx.apply #qlx.action<pauli_rotation>(%341#0, %cst_240) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %362 = qlx.apply #qlx.action<h>(%354#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 1.5707963267948966 : f64
    %363:2 = qlx.apply #qlx.action<pauli_rotation>(%361, %362, %cst_241) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_242 = arith.constant 1.5707963267948966 : f64
    %364 = qlx.apply #qlx.action<pauli_rotation>(%363#0, %cst_242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_243 = arith.constant 1.5707963267948966 : f64
    %365 = qlx.apply #qlx.action<pauli_rotation>(%363#1, %cst_243) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_244 = arith.constant 1.5707963267948966 : f64
    %366:2 = qlx.apply #qlx.action<pauli_rotation>(%364, %365, %cst_244) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_245 = arith.constant 1.5707963267948966 : f64
    %367 = qlx.apply #qlx.action<pauli_rotation>(%360#0, %cst_245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %368 = qlx.apply #qlx.action<h>(%367) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_246 = arith.constant 1.5707963267948966 : f64
    %369 = qlx.apply #qlx.action<pauli_rotation>(%368, %cst_246) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %370 = qlx.apply #qlx.action<h>(%369) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_247 = arith.constant 1.5707963267948966 : f64
    %371 = qlx.apply #qlx.action<pauli_rotation>(%360#1, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_248 = arith.constant 1.5707963267948966 : f64
    %372:2 = qlx.apply #qlx.action<pauli_rotation>(%370, %371, %cst_248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_249 = arith.constant 1.5707963267948966 : f64
    %373 = qlx.apply #qlx.action<pauli_rotation>(%357#0, %cst_249) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %374 = qlx.apply #qlx.action<h>(%373) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_250 = arith.constant 1.5707963267948966 : f64
    %375 = qlx.apply #qlx.action<pauli_rotation>(%374, %cst_250) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %376 = qlx.apply #qlx.action<h>(%375) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_251 = arith.constant 1.5707963267948966 : f64
    %377 = qlx.apply #qlx.action<pauli_rotation>(%372#1, %cst_251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_252 = arith.constant 1.5707963267948966 : f64
    %378:2 = qlx.apply #qlx.action<pauli_rotation>(%376, %377, %cst_252) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_253 = arith.constant 1.5707963267948966 : f64
    %379 = qlx.apply #qlx.action<pauli_rotation>(%378#1, %cst_253) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %380 = qlx.apply #qlx.action<h>(%379) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_254 = arith.constant 1.5707963267948966 : f64
    %381 = qlx.apply #qlx.action<pauli_rotation>(%366#1, %cst_254) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %382 = qlx.apply #qlx.action<h>(%381) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_255 = arith.constant 0.78539816339744828 : f64
    %383:2 = qlx.apply #qlx.action<pauli_rotation>(%380, %382, %cst_255) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %384 = qlx.apply #qlx.action<pauli_rotation>(%378#0, %cst_256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %385 = qlx.apply #qlx.action<h>(%383#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %386:2 = qlx.apply #qlx.action<pauli_rotation>(%384, %385, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_258 = arith.constant 1.5707963267948966 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%372#0, %cst_258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_259 = arith.constant 1.5707963267948966 : f64
    %388 = qlx.apply #qlx.action<pauli_rotation>(%386#1, %cst_259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %389:2 = qlx.apply #qlx.action<pauli_rotation>(%387, %388, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_261 = arith.constant 1.5707963267948966 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%366#0, %cst_261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%383#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %392:2 = qlx.apply #qlx.action<pauli_rotation>(%390, %391, %cst_262) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%392#1, %cst_263) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_264 = arith.constant 1.5707963267948966 : f64
    %394 = qlx.apply #qlx.action<pauli_rotation>(%389#1, %cst_264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_265 = arith.constant 1.5707963267948966 : f64
    %395:2 = qlx.apply #qlx.action<pauli_rotation>(%393, %394, %cst_265) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_266 = arith.constant 1.5707963267948966 : f64
    %396 = qlx.apply #qlx.action<pauli_rotation>(%395#1, %cst_266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %397 = qlx.apply #qlx.action<h>(%396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %398 = qlx.apply #qlx.action<pauli_rotation>(%389#0, %cst_267) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %399 = qlx.apply #qlx.action<h>(%398) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %400 = qlx.apply #qlx.action<pauli_rotation>(%399, %cst_268) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %401 = qlx.apply #qlx.action<h>(%400) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_269 = arith.constant 5.000000e-01 : f64
    %402:2 = qlx.apply #qlx.action<pauli_rotation>(%397, %401, %cst_269) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_270 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%395#0, %cst_270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %404 = qlx.apply #qlx.action<h>(%402#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_271 = arith.constant 1.5707963267948966 : f64
    %405:2 = qlx.apply #qlx.action<pauli_rotation>(%403, %404, %cst_271) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_272 = arith.constant 1.5707963267948966 : f64
    %406 = qlx.apply #qlx.action<pauli_rotation>(%405#0, %cst_272) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %407 = qlx.apply #qlx.action<h>(%406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %408 = qlx.apply #qlx.action<pauli_rotation>(%407, %cst_273) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %409 = qlx.apply #qlx.action<h>(%408) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %410 = qlx.apply #qlx.action<pauli_rotation>(%405#1, %cst_274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.5707963267948966 : f64
    %411:2 = qlx.apply #qlx.action<pauli_rotation>(%409, %410, %cst_275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %412 = qlx.apply #qlx.action<pauli_rotation>(%411#1, %cst_276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %413 = qlx.apply #qlx.action<h>(%412) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %414 = qlx.apply #qlx.action<h>(%402#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 1.5707963267948966 : f64
    %415 = qlx.apply #qlx.action<pauli_rotation>(%414, %cst_277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %416 = qlx.apply #qlx.action<h>(%415) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 5.000000e-01 : f64
    %417:2 = qlx.apply #qlx.action<pauli_rotation>(%413, %416, %cst_278) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %418 = qlx.apply #qlx.action<pauli_rotation>(%411#0, %cst_279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %419 = qlx.apply #qlx.action<h>(%417#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %420:2 = qlx.apply #qlx.action<pauli_rotation>(%418, %419, %cst_280) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_281 = arith.constant 1.5707963267948966 : f64
    %421 = qlx.apply #qlx.action<pauli_rotation>(%333#0, %cst_281) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_282 = arith.constant 1.5707963267948966 : f64
    %422:2 = qlx.apply #qlx.action<pauli_rotation>(%333#1, %421, %cst_282) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %423 = qlx.apply #qlx.action<h>(%417#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_283 = arith.constant 1.5707963267948966 : f64
    %424 = qlx.apply #qlx.action<pauli_rotation>(%423, %cst_283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_284 = arith.constant 1.5707963267948966 : f64
    %425 = qlx.apply #qlx.action<pauli_rotation>(%420#1, %cst_284) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_285 = arith.constant 1.5707963267948966 : f64
    %426:2 = qlx.apply #qlx.action<pauli_rotation>(%424, %425, %cst_285) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %427 = qlx.apply #qlx.action<pauli_rotation>(%420#0, %cst_286) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %428 = qlx.apply #qlx.action<h>(%427) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.5707963267948966 : f64
    %429 = qlx.apply #qlx.action<pauli_rotation>(%428, %cst_287) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %430 = qlx.apply #qlx.action<h>(%429) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_288 = arith.constant 1.5707963267948966 : f64
    %431 = qlx.apply #qlx.action<pauli_rotation>(%426#1, %cst_288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_289 = arith.constant 1.5707963267948966 : f64
    %432:2 = qlx.apply #qlx.action<pauli_rotation>(%430, %431, %cst_289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_290 = arith.constant 1.5707963267948966 : f64
    %433 = qlx.apply #qlx.action<pauli_rotation>(%432#1, %cst_290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %434 = qlx.apply #qlx.action<h>(%433) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_291 = arith.constant 1.5707963267948966 : f64
    %435 = qlx.apply #qlx.action<pauli_rotation>(%422#0, %cst_291) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %436 = qlx.apply #qlx.action<h>(%435) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_292 = arith.constant 0.78539816339744828 : f64
    %437:2 = qlx.apply #qlx.action<pauli_rotation>(%434, %436, %cst_292) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_293 = arith.constant 1.5707963267948966 : f64
    %438 = qlx.apply #qlx.action<pauli_rotation>(%432#0, %cst_293) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %439 = qlx.apply #qlx.action<h>(%437#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_294 = arith.constant 1.5707963267948966 : f64
    %440:2 = qlx.apply #qlx.action<pauli_rotation>(%438, %439, %cst_294) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_295 = arith.constant 1.5707963267948966 : f64
    %441 = qlx.apply #qlx.action<pauli_rotation>(%426#0, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_296 = arith.constant 1.5707963267948966 : f64
    %442 = qlx.apply #qlx.action<pauli_rotation>(%440#1, %cst_296) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_297 = arith.constant 1.5707963267948966 : f64
    %443:2 = qlx.apply #qlx.action<pauli_rotation>(%441, %442, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %444 = qlx.apply #qlx.action<pauli_rotation>(%422#1, %cst_298) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %445 = qlx.apply #qlx.action<h>(%437#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %446:2 = qlx.apply #qlx.action<pauli_rotation>(%444, %445, %cst_299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_300 = arith.constant 1.5707963267948966 : f64
    %447 = qlx.apply #qlx.action<pauli_rotation>(%446#0, %cst_300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_301 = arith.constant 1.5707963267948966 : f64
    %448:2 = qlx.apply #qlx.action<pauli_rotation>(%446#1, %447, %cst_301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_302 = arith.constant 1.5707963267948966 : f64
    %449 = qlx.apply #qlx.action<pauli_rotation>(%443#0, %cst_302) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_303 = arith.constant 1.5707963267948966 : f64
    %450 = qlx.apply #qlx.action<pauli_rotation>(%443#1, %cst_303) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %451:2 = qlx.apply #qlx.action<pauli_rotation>(%449, %450, %cst_304) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %452 = qlx.apply #qlx.action<pauli_rotation>(%440#0, %cst_305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %453 = qlx.apply #qlx.action<h>(%452) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_306 = arith.constant 1.5707963267948966 : f64
    %454 = qlx.apply #qlx.action<pauli_rotation>(%453, %cst_306) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %455 = qlx.apply #qlx.action<h>(%454) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 1.5707963267948966 : f64
    %456 = qlx.apply #qlx.action<pauli_rotation>(%451#1, %cst_307) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %457:2 = qlx.apply #qlx.action<pauli_rotation>(%455, %456, %cst_308) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_309 = arith.constant 1.5707963267948966 : f64
    %458 = qlx.apply #qlx.action<pauli_rotation>(%457#1, %cst_309) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %459 = qlx.apply #qlx.action<h>(%458) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %460 = qlx.apply #qlx.action<pauli_rotation>(%448#0, %cst_310) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %461 = qlx.apply #qlx.action<h>(%460) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_311 = arith.constant 0.78539816339744828 : f64
    %462:2 = qlx.apply #qlx.action<pauli_rotation>(%459, %461, %cst_311) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_312 = arith.constant 1.5707963267948966 : f64
    %463 = qlx.apply #qlx.action<pauli_rotation>(%457#0, %cst_312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %464 = qlx.apply #qlx.action<h>(%462#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 1.5707963267948966 : f64
    %465:2 = qlx.apply #qlx.action<pauli_rotation>(%463, %464, %cst_313) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_314 = arith.constant 1.5707963267948966 : f64
    %466 = qlx.apply #qlx.action<pauli_rotation>(%451#0, %cst_314) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_315 = arith.constant 1.5707963267948966 : f64
    %467 = qlx.apply #qlx.action<pauli_rotation>(%465#1, %cst_315) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %468:2 = qlx.apply #qlx.action<pauli_rotation>(%466, %467, %cst_316) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_317 = arith.constant 1.5707963267948966 : f64
    %469 = qlx.apply #qlx.action<pauli_rotation>(%448#1, %cst_317) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %470 = qlx.apply #qlx.action<h>(%462#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_318 = arith.constant 1.5707963267948966 : f64
    %471:2 = qlx.apply #qlx.action<pauli_rotation>(%469, %470, %cst_318) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_319 = arith.constant 1.5707963267948966 : f64
    %472 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %cst_319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_320 = arith.constant 1.5707963267948966 : f64
    %473 = qlx.apply #qlx.action<pauli_rotation>(%465#0, %cst_320) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %474 = qlx.apply #qlx.action<h>(%473) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_321 = arith.constant 1.5707963267948966 : f64
    %475 = qlx.apply #qlx.action<pauli_rotation>(%474, %cst_321) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %476 = qlx.apply #qlx.action<h>(%475) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %477:2 = qlx.apply #qlx.action<pauli_rotation>(%472, %476, %cst_322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %478 = qlx.apply #qlx.action<pauli_rotation>(%468#0, %cst_323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %479 = qlx.apply #qlx.action<h>(%478) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_324 = arith.constant 1.5707963267948966 : f64
    %480 = qlx.apply #qlx.action<pauli_rotation>(%468#1, %cst_324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_325 = arith.constant 1.5707963267948966 : f64
    %481:2 = qlx.apply #qlx.action<pauli_rotation>(%479, %480, %cst_325) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_326 = arith.constant 1.5707963267948966 : f64
    %482 = qlx.apply #qlx.action<pauli_rotation>(%386#0, %cst_326) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %483 = qlx.apply #qlx.action<h>(%482) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_327 = arith.constant 1.5707963267948966 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%483, %cst_327) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %485 = qlx.apply #qlx.action<h>(%484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %486 = qlx.apply #qlx.action<pauli_rotation>(%481#1, %cst_328) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_329 = arith.constant 1.5707963267948966 : f64
    %487:2 = qlx.apply #qlx.action<pauli_rotation>(%485, %486, %cst_329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_330 = arith.constant 1.5707963267948966 : f64
    %488 = qlx.apply #qlx.action<pauli_rotation>(%487#1, %cst_330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %489 = qlx.apply #qlx.action<h>(%488) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_331 = arith.constant 1.5707963267948966 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%477#1, %cst_331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %491 = qlx.apply #qlx.action<h>(%490) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_332 = arith.constant 0.78539816339744828 : f64
    %492:2 = qlx.apply #qlx.action<pauli_rotation>(%489, %491, %cst_332) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_333 = arith.constant 1.5707963267948966 : f64
    %493 = qlx.apply #qlx.action<pauli_rotation>(%487#0, %cst_333) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %494 = qlx.apply #qlx.action<h>(%492#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %495:2 = qlx.apply #qlx.action<pauli_rotation>(%493, %494, %cst_334) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %496 = qlx.apply #qlx.action<pauli_rotation>(%481#0, %cst_335) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_336 = arith.constant 1.5707963267948966 : f64
    %497 = qlx.apply #qlx.action<pauli_rotation>(%495#1, %cst_336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_337 = arith.constant 1.5707963267948966 : f64
    %498:2 = qlx.apply #qlx.action<pauli_rotation>(%496, %497, %cst_337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %499 = qlx.apply #qlx.action<pauli_rotation>(%477#0, %cst_338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %500 = qlx.apply #qlx.action<h>(%492#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_339 = arith.constant 1.5707963267948966 : f64
    %501:2 = qlx.apply #qlx.action<pauli_rotation>(%499, %500, %cst_339) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %502 = qlx.apply #qlx.action<pauli_rotation>(%501#0, %cst_340) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %503 = qlx.apply #qlx.action<pauli_rotation>(%501#1, %cst_341) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_342 = arith.constant 1.5707963267948966 : f64
    %504:2 = qlx.apply #qlx.action<pauli_rotation>(%502, %503, %cst_342) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_343 = arith.constant 1.5707963267948966 : f64
    %505 = qlx.apply #qlx.action<pauli_rotation>(%498#0, %cst_343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %506 = qlx.apply #qlx.action<h>(%505) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_344 = arith.constant 1.5707963267948966 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%506, %cst_344) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %508 = qlx.apply #qlx.action<h>(%507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %509 = qlx.apply #qlx.action<pauli_rotation>(%498#1, %cst_345) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_346 = arith.constant 1.5707963267948966 : f64
    %510:2 = qlx.apply #qlx.action<pauli_rotation>(%508, %509, %cst_346) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_347 = arith.constant 1.5707963267948966 : f64
    %511 = qlx.apply #qlx.action<pauli_rotation>(%495#0, %cst_347) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %512 = qlx.apply #qlx.action<h>(%511) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %513 = qlx.apply #qlx.action<pauli_rotation>(%512, %cst_348) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %514 = qlx.apply #qlx.action<h>(%513) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_349 = arith.constant 1.5707963267948966 : f64
    %515 = qlx.apply #qlx.action<pauli_rotation>(%510#1, %cst_349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_350 = arith.constant 1.5707963267948966 : f64
    %516:2 = qlx.apply #qlx.action<pauli_rotation>(%514, %515, %cst_350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_351 = arith.constant 1.5707963267948966 : f64
    %517 = qlx.apply #qlx.action<pauli_rotation>(%516#1, %cst_351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %518 = qlx.apply #qlx.action<h>(%517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %519 = qlx.apply #qlx.action<pauli_rotation>(%504#1, %cst_352) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %520 = qlx.apply #qlx.action<h>(%519) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_353 = arith.constant 0.78539816339744828 : f64
    %521:2 = qlx.apply #qlx.action<pauli_rotation>(%518, %520, %cst_353) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %522 = qlx.apply #qlx.action<pauli_rotation>(%516#0, %cst_354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %523 = qlx.apply #qlx.action<h>(%521#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_355 = arith.constant 1.5707963267948966 : f64
    %524:2 = qlx.apply #qlx.action<pauli_rotation>(%522, %523, %cst_355) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_356 = arith.constant 1.5707963267948966 : f64
    %525 = qlx.apply #qlx.action<pauli_rotation>(%510#0, %cst_356) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_357 = arith.constant 1.5707963267948966 : f64
    %526 = qlx.apply #qlx.action<pauli_rotation>(%524#1, %cst_357) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %527:2 = qlx.apply #qlx.action<pauli_rotation>(%525, %526, %cst_358) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %528 = qlx.apply #qlx.action<pauli_rotation>(%504#0, %cst_359) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %529 = qlx.apply #qlx.action<h>(%521#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %530:2 = qlx.apply #qlx.action<pauli_rotation>(%528, %529, %cst_360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_361 = arith.constant 1.5707963267948966 : f64
    %531 = qlx.apply #qlx.action<pauli_rotation>(%214#0, %cst_361) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %532 = qlx.apply #qlx.action<h>(%531) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_362 = arith.constant 3.1415926535897931 : f64
    %533 = qlx.apply #qlx.action<pauli_rotation>(%532, %cst_362) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%471#1, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_364 = arith.constant 5.000000e-01 : f64
    %535:2 = qlx.apply #qlx.action<pauli_rotation>(%533, %534, %cst_364) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_365 = arith.constant 1.5707963267948966 : f64
    %536 = qlx.apply #qlx.action<pauli_rotation>(%471#0, %cst_365) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%527#0, %cst_366) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %538 = qlx.apply #qlx.action<h>(%537) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_367 = arith.constant 1.5707963267948966 : f64
    %539 = qlx.apply #qlx.action<pauli_rotation>(%538, %cst_367) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_368 = arith.constant 5.000000e-01 : f64
    %540:2 = qlx.apply #qlx.action<pauli_rotation>(%536, %539, %cst_368) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_369 = arith.constant 1.5707963267948966 : f64
    %541 = qlx.apply #qlx.action<pauli_rotation>(%527#1, %cst_369) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %542 = qlx.apply #qlx.action<h>(%541) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %543 = qlx.apply #qlx.action<pauli_rotation>(%530#1, %cst_370) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %544 = qlx.apply #qlx.action<h>(%543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_371 = arith.constant 5.000000e-01 : f64
    %545:2 = qlx.apply #qlx.action<pauli_rotation>(%542, %544, %cst_371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_372 = arith.constant 1.5707963267948966 : f64
    %546 = qlx.apply #qlx.action<pauli_rotation>(%530#0, %cst_372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_373 = arith.constant 1.5707963267948966 : f64
    %547 = qlx.apply #qlx.action<pauli_rotation>(%524#0, %cst_373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %548 = qlx.apply #qlx.action<h>(%547) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_374 = arith.constant 3.1415926535897931 : f64
    %549 = qlx.apply #qlx.action<pauli_rotation>(%548, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_375 = arith.constant 5.000000e-01 : f64
    %550:2 = qlx.apply #qlx.action<pauli_rotation>(%546, %549, %cst_375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %551 = qlx.apply #qlx.action<h>(%540#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %552:2 = qlx.apply #qlx.action<pauli_rotation>(%540#1, %551, %cst_376) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %553 = qlx.apply #qlx.action<pauli_rotation>(%535#0, %cst_377) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %554 = qlx.apply #qlx.action<h>(%553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %555 = qlx.apply #qlx.action<h>(%535#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_378 = arith.constant 1.5707963267948966 : f64
    %556:2 = qlx.apply #qlx.action<pauli_rotation>(%554, %555, %cst_378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %557 = qlx.apply #qlx.action<h>(%545#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_379 = arith.constant 1.5707963267948966 : f64
    %558 = qlx.apply #qlx.action<pauli_rotation>(%556#1, %cst_379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_380 = arith.constant 1.5707963267948966 : f64
    %559:2 = qlx.apply #qlx.action<pauli_rotation>(%557, %558, %cst_380) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_381 = arith.constant 1.5707963267948966 : f64
    %560 = qlx.apply #qlx.action<pauli_rotation>(%559#1, %cst_381) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %561 = qlx.apply #qlx.action<h>(%560) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_382 = arith.constant 1.5707963267948966 : f64
    %562 = qlx.apply #qlx.action<pauli_rotation>(%552#1, %cst_382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %563 = qlx.apply #qlx.action<h>(%562) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_383 = arith.constant 0.78539816339744828 : f64
    %564:2 = qlx.apply #qlx.action<pauli_rotation>(%561, %563, %cst_383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_384 = arith.constant 1.5707963267948966 : f64
    %565 = qlx.apply #qlx.action<pauli_rotation>(%559#0, %cst_384) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %566 = qlx.apply #qlx.action<h>(%564#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_385 = arith.constant 1.5707963267948966 : f64
    %567:2 = qlx.apply #qlx.action<pauli_rotation>(%565, %566, %cst_385) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_386 = arith.constant 1.5707963267948966 : f64
    %568 = qlx.apply #qlx.action<pauli_rotation>(%556#0, %cst_386) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_387 = arith.constant 1.5707963267948966 : f64
    %569 = qlx.apply #qlx.action<pauli_rotation>(%567#1, %cst_387) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_388 = arith.constant 1.5707963267948966 : f64
    %570:2 = qlx.apply #qlx.action<pauli_rotation>(%568, %569, %cst_388) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_389 = arith.constant 1.5707963267948966 : f64
    %571 = qlx.apply #qlx.action<pauli_rotation>(%552#0, %cst_389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %572 = qlx.apply #qlx.action<h>(%564#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_390 = arith.constant 1.5707963267948966 : f64
    %573:2 = qlx.apply #qlx.action<pauli_rotation>(%571, %572, %cst_390) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %574 = qlx.apply #qlx.action<pauli_rotation>(%573#0, %cst_391) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_392 = arith.constant 1.5707963267948966 : f64
    %575 = qlx.apply #qlx.action<pauli_rotation>(%573#1, %cst_392) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_393 = arith.constant 1.5707963267948966 : f64
    %576:2 = qlx.apply #qlx.action<pauli_rotation>(%574, %575, %cst_393) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_394 = arith.constant 1.5707963267948966 : f64
    %577 = qlx.apply #qlx.action<pauli_rotation>(%570#0, %cst_394) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %578 = qlx.apply #qlx.action<h>(%577) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_395 = arith.constant 1.5707963267948966 : f64
    %579 = qlx.apply #qlx.action<pauli_rotation>(%578, %cst_395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %580 = qlx.apply #qlx.action<h>(%579) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_396 = arith.constant 1.5707963267948966 : f64
    %581 = qlx.apply #qlx.action<pauli_rotation>(%570#1, %cst_396) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %582:2 = qlx.apply #qlx.action<pauli_rotation>(%580, %581, %cst_397) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %583 = qlx.apply #qlx.action<pauli_rotation>(%567#0, %cst_398) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %584 = qlx.apply #qlx.action<h>(%583) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_399 = arith.constant 1.5707963267948966 : f64
    %585 = qlx.apply #qlx.action<pauli_rotation>(%584, %cst_399) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %586 = qlx.apply #qlx.action<h>(%585) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_400 = arith.constant 1.5707963267948966 : f64
    %587 = qlx.apply #qlx.action<pauli_rotation>(%582#1, %cst_400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.5707963267948966 : f64
    %588:2 = qlx.apply #qlx.action<pauli_rotation>(%586, %587, %cst_401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %589 = qlx.apply #qlx.action<pauli_rotation>(%588#1, %cst_402) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %590 = qlx.apply #qlx.action<h>(%589) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_403 = arith.constant 1.5707963267948966 : f64
    %591 = qlx.apply #qlx.action<pauli_rotation>(%576#1, %cst_403) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %592 = qlx.apply #qlx.action<h>(%591) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_404 = arith.constant 0.78539816339744828 : f64
    %593:2 = qlx.apply #qlx.action<pauli_rotation>(%590, %592, %cst_404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_405 = arith.constant 1.5707963267948966 : f64
    %594 = qlx.apply #qlx.action<pauli_rotation>(%588#0, %cst_405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %595 = qlx.apply #qlx.action<h>(%593#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_406 = arith.constant 1.5707963267948966 : f64
    %596:2 = qlx.apply #qlx.action<pauli_rotation>(%594, %595, %cst_406) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %597 = qlx.apply #qlx.action<pauli_rotation>(%582#0, %cst_407) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %598 = qlx.apply #qlx.action<pauli_rotation>(%596#1, %cst_408) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_409 = arith.constant 1.5707963267948966 : f64
    %599:2 = qlx.apply #qlx.action<pauli_rotation>(%597, %598, %cst_409) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_410 = arith.constant 1.5707963267948966 : f64
    %600 = qlx.apply #qlx.action<pauli_rotation>(%576#0, %cst_410) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %601 = qlx.apply #qlx.action<h>(%593#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 1.5707963267948966 : f64
    %602:2 = qlx.apply #qlx.action<pauli_rotation>(%600, %601, %cst_411) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_412 = arith.constant 1.5707963267948966 : f64
    %603 = qlx.apply #qlx.action<pauli_rotation>(%602#1, %cst_412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %604 = qlx.apply #qlx.action<pauli_rotation>(%602#0, %cst_413) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %605 = qlx.apply #qlx.action<h>(%604) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %606:2 = qlx.apply #qlx.action<pauli_rotation>(%603, %605, %cst_414) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_415 = arith.constant 1.5707963267948966 : f64
    %607 = qlx.apply #qlx.action<pauli_rotation>(%550#0, %cst_415) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %608 = qlx.apply #qlx.action<h>(%607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %609 = qlx.apply #qlx.action<h>(%545#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_416 = arith.constant 1.5707963267948966 : f64
    %610:2 = qlx.apply #qlx.action<pauli_rotation>(%608, %609, %cst_416) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %611 = qlx.apply #qlx.action<pauli_rotation>(%610#1, %cst_417) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %612 = qlx.apply #qlx.action<h>(%611) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %613 = qlx.apply #qlx.action<pauli_rotation>(%596#0, %cst_418) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %614 = qlx.apply #qlx.action<h>(%613) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.5707963267948966 : f64
    %615 = qlx.apply #qlx.action<pauli_rotation>(%614, %cst_419) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %616 = qlx.apply #qlx.action<h>(%615) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %617:2 = qlx.apply #qlx.action<pauli_rotation>(%612, %616, %cst_420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_421 = arith.constant 1.5707963267948966 : f64
    %618 = qlx.apply #qlx.action<pauli_rotation>(%617#1, %cst_421) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %619 = qlx.apply #qlx.action<h>(%618) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 1.5707963267948966 : f64
    %620 = qlx.apply #qlx.action<pauli_rotation>(%606#1, %cst_422) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %621 = qlx.apply #qlx.action<h>(%620) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_423 = arith.constant 0.78539816339744828 : f64
    %622:2 = qlx.apply #qlx.action<pauli_rotation>(%619, %621, %cst_423) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %623 = qlx.apply #qlx.action<pauli_rotation>(%617#0, %cst_424) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %624 = qlx.apply #qlx.action<h>(%622#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %625:2 = qlx.apply #qlx.action<pauli_rotation>(%623, %624, %cst_425) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_426 = arith.constant 1.5707963267948966 : f64
    %626 = qlx.apply #qlx.action<pauli_rotation>(%610#0, %cst_426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_427 = arith.constant 1.5707963267948966 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%625#0, %cst_427) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %628 = qlx.apply #qlx.action<h>(%627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_428 = arith.constant 1.5707963267948966 : f64
    %629:2 = qlx.apply #qlx.action<pauli_rotation>(%626, %628, %cst_428) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_429 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%606#0, %cst_429) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %631 = qlx.apply #qlx.action<h>(%622#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_430 = arith.constant 1.5707963267948966 : f64
    %632:2 = qlx.apply #qlx.action<pauli_rotation>(%630, %631, %cst_430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_431 = arith.constant 1.5707963267948966 : f64
    %633 = qlx.apply #qlx.action<pauli_rotation>(%632#0, %cst_431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %634 = qlx.apply #qlx.action<h>(%633) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_432 = arith.constant 1.5707963267948966 : f64
    %635 = qlx.apply #qlx.action<pauli_rotation>(%634, %cst_432) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %636 = qlx.apply #qlx.action<h>(%635) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_433 = arith.constant 1.5707963267948966 : f64
    %637 = qlx.apply #qlx.action<pauli_rotation>(%632#1, %cst_433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_434 = arith.constant 1.5707963267948966 : f64
    %638:2 = qlx.apply #qlx.action<pauli_rotation>(%636, %637, %cst_434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_435 = arith.constant 1.5707963267948966 : f64
    %639 = qlx.apply #qlx.action<pauli_rotation>(%629#0, %cst_435) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %640 = qlx.apply #qlx.action<h>(%639) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_436 = arith.constant 1.5707963267948966 : f64
    %641 = qlx.apply #qlx.action<pauli_rotation>(%640, %cst_436) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %642 = qlx.apply #qlx.action<h>(%641) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %643 = qlx.apply #qlx.action<pauli_rotation>(%629#1, %cst_437) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_438 = arith.constant 1.5707963267948966 : f64
    %644:2 = qlx.apply #qlx.action<pauli_rotation>(%642, %643, %cst_438) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_439 = arith.constant 1.5707963267948966 : f64
    %645 = qlx.apply #qlx.action<pauli_rotation>(%644#1, %cst_439) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %646 = qlx.apply #qlx.action<h>(%645) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_440 = arith.constant 1.5707963267948966 : f64
    %647 = qlx.apply #qlx.action<pauli_rotation>(%625#1, %cst_440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_441 = arith.constant 1.5707963267948966 : f64
    %648:2 = qlx.apply #qlx.action<pauli_rotation>(%646, %647, %cst_441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %649 = qlx.apply #qlx.action<pauli_rotation>(%648#1, %cst_442) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %650 = qlx.apply #qlx.action<h>(%649) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %651 = qlx.apply #qlx.action<pauli_rotation>(%638#1, %cst_443) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %652 = qlx.apply #qlx.action<h>(%651) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_444 = arith.constant 0.78539816339744828 : f64
    %653:2 = qlx.apply #qlx.action<pauli_rotation>(%650, %652, %cst_444) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_445 = arith.constant 1.5707963267948966 : f64
    %654 = qlx.apply #qlx.action<pauli_rotation>(%648#0, %cst_445) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %655 = qlx.apply #qlx.action<h>(%653#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_446 = arith.constant 1.5707963267948966 : f64
    %656:2 = qlx.apply #qlx.action<pauli_rotation>(%654, %655, %cst_446) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_447 = arith.constant 1.5707963267948966 : f64
    %657 = qlx.apply #qlx.action<pauli_rotation>(%644#0, %cst_447) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_448 = arith.constant 1.5707963267948966 : f64
    %658 = qlx.apply #qlx.action<pauli_rotation>(%656#0, %cst_448) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %659 = qlx.apply #qlx.action<h>(%658) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %660:2 = qlx.apply #qlx.action<pauli_rotation>(%657, %659, %cst_449) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_450 = arith.constant 1.5707963267948966 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%638#0, %cst_450) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %662 = qlx.apply #qlx.action<h>(%653#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_451 = arith.constant 1.5707963267948966 : f64
    %663:2 = qlx.apply #qlx.action<pauli_rotation>(%661, %662, %cst_451) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_452 = arith.constant 1.5707963267948966 : f64
    %664 = qlx.apply #qlx.action<pauli_rotation>(%656#1, %cst_452) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_453 = arith.constant 1.5707963267948966 : f64
    %665 = qlx.apply #qlx.action<pauli_rotation>(%663#1, %cst_453) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%664, %665, %cst_454) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%666#1, %cst_455) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %668 = qlx.apply #qlx.action<h>(%667) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_456 = arith.constant 1.5707963267948966 : f64
    %669 = qlx.apply #qlx.action<pauli_rotation>(%663#0, %cst_456) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %670 = qlx.apply #qlx.action<h>(%669) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 1.5707963267948966 : f64
    %671 = qlx.apply #qlx.action<pauli_rotation>(%670, %cst_457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %672 = qlx.apply #qlx.action<h>(%671) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_458 = arith.constant 5.000000e-01 : f64
    %673:2 = qlx.apply #qlx.action<pauli_rotation>(%668, %672, %cst_458) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_459 = arith.constant 1.5707963267948966 : f64
    %674 = qlx.apply #qlx.action<pauli_rotation>(%666#0, %cst_459) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %675 = qlx.apply #qlx.action<h>(%673#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %676:2 = qlx.apply #qlx.action<pauli_rotation>(%674, %675, %cst_460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_461 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676#0, %cst_461) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %678 = qlx.apply #qlx.action<h>(%677) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_462 = arith.constant 1.5707963267948966 : f64
    %679 = qlx.apply #qlx.action<pauli_rotation>(%678, %cst_462) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %680 = qlx.apply #qlx.action<h>(%679) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_463 = arith.constant 1.5707963267948966 : f64
    %681 = qlx.apply #qlx.action<pauli_rotation>(%676#1, %cst_463) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_464 = arith.constant 1.5707963267948966 : f64
    %682:2 = qlx.apply #qlx.action<pauli_rotation>(%680, %681, %cst_464) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_465 = arith.constant 1.5707963267948966 : f64
    %683 = qlx.apply #qlx.action<pauli_rotation>(%682#1, %cst_465) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %684 = qlx.apply #qlx.action<h>(%683) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %685 = qlx.apply #qlx.action<h>(%673#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_466 = arith.constant 1.5707963267948966 : f64
    %686 = qlx.apply #qlx.action<pauli_rotation>(%685, %cst_466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %687 = qlx.apply #qlx.action<h>(%686) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_467 = arith.constant 5.000000e-01 : f64
    %688:2 = qlx.apply #qlx.action<pauli_rotation>(%684, %687, %cst_467) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_468 = arith.constant 1.5707963267948966 : f64
    %689 = qlx.apply #qlx.action<pauli_rotation>(%682#0, %cst_468) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %690 = qlx.apply #qlx.action<h>(%688#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_469 = arith.constant 1.5707963267948966 : f64
    %691:2 = qlx.apply #qlx.action<pauli_rotation>(%689, %690, %cst_469) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_470 = arith.constant 1.5707963267948966 : f64
    %692 = qlx.apply #qlx.action<pauli_rotation>(%691#1, %cst_470) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %693 = qlx.apply #qlx.action<h>(%692) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %694 = qlx.apply #qlx.action<h>(%688#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_471 = arith.constant 1.5707963267948966 : f64
    %695 = qlx.apply #qlx.action<pauli_rotation>(%694, %cst_471) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %696 = qlx.apply #qlx.action<h>(%695) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 1.5707963267948966 : f64
    %697:2 = qlx.apply #qlx.action<pauli_rotation>(%693, %696, %cst_472) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_473 = arith.constant 1.5707963267948966 : f64
    %698 = qlx.apply #qlx.action<pauli_rotation>(%599#0, %cst_473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %699 = qlx.apply #qlx.action<h>(%698) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_474 = arith.constant 1.5707963267948966 : f64
    %700 = qlx.apply #qlx.action<pauli_rotation>(%699, %cst_474) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %701 = qlx.apply #qlx.action<h>(%700) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_475 = arith.constant 1.5707963267948966 : f64
    %702 = qlx.apply #qlx.action<pauli_rotation>(%599#1, %cst_475) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %703:2 = qlx.apply #qlx.action<pauli_rotation>(%701, %702, %cst_476) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_477 = arith.constant 1.5707963267948966 : f64
    %704 = qlx.apply #qlx.action<pauli_rotation>(%691#0, %cst_477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %705 = qlx.apply #qlx.action<h>(%704) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_478 = arith.constant 1.5707963267948966 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705, %cst_478) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %707 = qlx.apply #qlx.action<h>(%706) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_479 = arith.constant 1.5707963267948966 : f64
    %708 = qlx.apply #qlx.action<pauli_rotation>(%703#1, %cst_479) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_480 = arith.constant 1.5707963267948966 : f64
    %709:2 = qlx.apply #qlx.action<pauli_rotation>(%707, %708, %cst_480) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_481 = arith.constant 1.5707963267948966 : f64
    %710 = qlx.apply #qlx.action<pauli_rotation>(%709#1, %cst_481) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %711 = qlx.apply #qlx.action<h>(%710) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_482 = arith.constant 1.5707963267948966 : f64
    %712 = qlx.apply #qlx.action<pauli_rotation>(%697#1, %cst_482) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %713 = qlx.apply #qlx.action<h>(%712) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_483 = arith.constant 0.78539816339744828 : f64
    %714:2 = qlx.apply #qlx.action<pauli_rotation>(%711, %713, %cst_483) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_484 = arith.constant 1.5707963267948966 : f64
    %715 = qlx.apply #qlx.action<pauli_rotation>(%709#0, %cst_484) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %716 = qlx.apply #qlx.action<h>(%714#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_485 = arith.constant 1.5707963267948966 : f64
    %717:2 = qlx.apply #qlx.action<pauli_rotation>(%715, %716, %cst_485) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %718 = qlx.apply #qlx.action<pauli_rotation>(%703#0, %cst_486) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_487 = arith.constant 1.5707963267948966 : f64
    %719 = qlx.apply #qlx.action<pauli_rotation>(%717#1, %cst_487) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_488 = arith.constant 1.5707963267948966 : f64
    %720:2 = qlx.apply #qlx.action<pauli_rotation>(%718, %719, %cst_488) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_489 = arith.constant 1.5707963267948966 : f64
    %721 = qlx.apply #qlx.action<pauli_rotation>(%697#0, %cst_489) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %722 = qlx.apply #qlx.action<h>(%714#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_490 = arith.constant 1.5707963267948966 : f64
    %723:2 = qlx.apply #qlx.action<pauli_rotation>(%721, %722, %cst_490) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_491 = arith.constant 1.5707963267948966 : f64
    %724 = qlx.apply #qlx.action<pauli_rotation>(%723#0, %cst_491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_492 = arith.constant 1.5707963267948966 : f64
    %725 = qlx.apply #qlx.action<pauli_rotation>(%723#1, %cst_492) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_493 = arith.constant 1.5707963267948966 : f64
    %726:2 = qlx.apply #qlx.action<pauli_rotation>(%724, %725, %cst_493) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_494 = arith.constant 1.5707963267948966 : f64
    %727 = qlx.apply #qlx.action<pauli_rotation>(%720#0, %cst_494) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %728 = qlx.apply #qlx.action<h>(%727) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_495 = arith.constant 1.5707963267948966 : f64
    %729 = qlx.apply #qlx.action<pauli_rotation>(%728, %cst_495) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %730 = qlx.apply #qlx.action<h>(%729) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_496 = arith.constant 1.5707963267948966 : f64
    %731 = qlx.apply #qlx.action<pauli_rotation>(%720#1, %cst_496) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_497 = arith.constant 1.5707963267948966 : f64
    %732:2 = qlx.apply #qlx.action<pauli_rotation>(%730, %731, %cst_497) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %733 = qlx.apply #qlx.action<pauli_rotation>(%717#0, %cst_498) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %734 = qlx.apply #qlx.action<h>(%733) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_499 = arith.constant 1.5707963267948966 : f64
    %735 = qlx.apply #qlx.action<pauli_rotation>(%734, %cst_499) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %736 = qlx.apply #qlx.action<h>(%735) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_500 = arith.constant 1.5707963267948966 : f64
    %737 = qlx.apply #qlx.action<pauli_rotation>(%732#1, %cst_500) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_501 = arith.constant 1.5707963267948966 : f64
    %738:2 = qlx.apply #qlx.action<pauli_rotation>(%736, %737, %cst_501) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_502 = arith.constant 1.5707963267948966 : f64
    %739 = qlx.apply #qlx.action<pauli_rotation>(%738#1, %cst_502) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %740 = qlx.apply #qlx.action<h>(%739) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_503 = arith.constant 1.5707963267948966 : f64
    %741 = qlx.apply #qlx.action<pauli_rotation>(%726#1, %cst_503) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%741) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_504 = arith.constant 0.78539816339744828 : f64
    %743:2 = qlx.apply #qlx.action<pauli_rotation>(%740, %742, %cst_504) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_505 = arith.constant 1.5707963267948966 : f64
    %744 = qlx.apply #qlx.action<pauli_rotation>(%738#0, %cst_505) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %745 = qlx.apply #qlx.action<h>(%743#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_506 = arith.constant 1.5707963267948966 : f64
    %746:2 = qlx.apply #qlx.action<pauli_rotation>(%744, %745, %cst_506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_507 = arith.constant 1.5707963267948966 : f64
    %747 = qlx.apply #qlx.action<pauli_rotation>(%732#0, %cst_507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_508 = arith.constant 1.5707963267948966 : f64
    %748 = qlx.apply #qlx.action<pauli_rotation>(%746#1, %cst_508) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_509 = arith.constant 1.5707963267948966 : f64
    %749:2 = qlx.apply #qlx.action<pauli_rotation>(%747, %748, %cst_509) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %750 = qlx.apply #qlx.action<pauli_rotation>(%726#0, %cst_510) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %751 = qlx.apply #qlx.action<h>(%743#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_511 = arith.constant 1.5707963267948966 : f64
    %752:2 = qlx.apply #qlx.action<pauli_rotation>(%750, %751, %cst_511) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_512 = arith.constant 1.5707963267948966 : f64
    %753 = qlx.apply #qlx.action<pauli_rotation>(%752#1, %cst_512) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_513 = arith.constant 1.5707963267948966 : f64
    %754 = qlx.apply #qlx.action<pauli_rotation>(%752#0, %cst_513) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %755 = qlx.apply #qlx.action<h>(%754) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_514 = arith.constant 1.5707963267948966 : f64
    %756:2 = qlx.apply #qlx.action<pauli_rotation>(%753, %755, %cst_514) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_515 = arith.constant 1.5707963267948966 : f64
    %757 = qlx.apply #qlx.action<pauli_rotation>(%660#0, %cst_515) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %758 = qlx.apply #qlx.action<h>(%757) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %759 = qlx.apply #qlx.action<pauli_rotation>(%758, %cst_516) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %760 = qlx.apply #qlx.action<h>(%759) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_517 = arith.constant 1.5707963267948966 : f64
    %761 = qlx.apply #qlx.action<pauli_rotation>(%660#1, %cst_517) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_518 = arith.constant 1.5707963267948966 : f64
    %762:2 = qlx.apply #qlx.action<pauli_rotation>(%760, %761, %cst_518) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_519 = arith.constant 1.5707963267948966 : f64
    %763 = qlx.apply #qlx.action<pauli_rotation>(%762#1, %cst_519) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %764 = qlx.apply #qlx.action<h>(%763) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_520 = arith.constant 1.5707963267948966 : f64
    %765 = qlx.apply #qlx.action<pauli_rotation>(%746#0, %cst_520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %766 = qlx.apply #qlx.action<h>(%765) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_521 = arith.constant 1.5707963267948966 : f64
    %767 = qlx.apply #qlx.action<pauli_rotation>(%766, %cst_521) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %768 = qlx.apply #qlx.action<h>(%767) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_522 = arith.constant 1.5707963267948966 : f64
    %769:2 = qlx.apply #qlx.action<pauli_rotation>(%764, %768, %cst_522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_523 = arith.constant 1.5707963267948966 : f64
    %770 = qlx.apply #qlx.action<pauli_rotation>(%769#1, %cst_523) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %771 = qlx.apply #qlx.action<h>(%770) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_524 = arith.constant 1.5707963267948966 : f64
    %772 = qlx.apply #qlx.action<pauli_rotation>(%756#1, %cst_524) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %773 = qlx.apply #qlx.action<h>(%772) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_525 = arith.constant 0.78539816339744828 : f64
    %774:2 = qlx.apply #qlx.action<pauli_rotation>(%771, %773, %cst_525) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_526 = arith.constant 1.5707963267948966 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%769#0, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %776 = qlx.apply #qlx.action<h>(%774#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_527 = arith.constant 1.5707963267948966 : f64
    %777:2 = qlx.apply #qlx.action<pauli_rotation>(%775, %776, %cst_527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_528 = arith.constant 1.5707963267948966 : f64
    %778 = qlx.apply #qlx.action<pauli_rotation>(%762#0, %cst_528) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %779 = qlx.apply #qlx.action<pauli_rotation>(%777#0, %cst_529) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %780 = qlx.apply #qlx.action<h>(%779) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_530 = arith.constant 1.5707963267948966 : f64
    %781:2 = qlx.apply #qlx.action<pauli_rotation>(%778, %780, %cst_530) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_531 = arith.constant 1.5707963267948966 : f64
    %782 = qlx.apply #qlx.action<pauli_rotation>(%756#0, %cst_531) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %783 = qlx.apply #qlx.action<h>(%774#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_532 = arith.constant 1.5707963267948966 : f64
    %784:2 = qlx.apply #qlx.action<pauli_rotation>(%782, %783, %cst_532) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %785 = qlx.apply #qlx.action<pauli_rotation>(%784#0, %cst_533) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %786 = qlx.apply #qlx.action<h>(%785) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_534 = arith.constant 1.5707963267948966 : f64
    %787 = qlx.apply #qlx.action<pauli_rotation>(%786, %cst_534) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %788 = qlx.apply #qlx.action<h>(%787) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%784#1, %cst_535) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_536 = arith.constant 1.5707963267948966 : f64
    %790:2 = qlx.apply #qlx.action<pauli_rotation>(%788, %789, %cst_536) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_537 = arith.constant 1.5707963267948966 : f64
    %791 = qlx.apply #qlx.action<pauli_rotation>(%781#0, %cst_537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %792 = qlx.apply #qlx.action<h>(%791) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_538 = arith.constant 1.5707963267948966 : f64
    %793 = qlx.apply #qlx.action<pauli_rotation>(%792, %cst_538) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %794 = qlx.apply #qlx.action<h>(%793) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_539 = arith.constant 1.5707963267948966 : f64
    %795 = qlx.apply #qlx.action<pauli_rotation>(%781#1, %cst_539) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_540 = arith.constant 1.5707963267948966 : f64
    %796:2 = qlx.apply #qlx.action<pauli_rotation>(%794, %795, %cst_540) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_541 = arith.constant 1.5707963267948966 : f64
    %797 = qlx.apply #qlx.action<pauli_rotation>(%796#1, %cst_541) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %798 = qlx.apply #qlx.action<h>(%797) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_542 = arith.constant 1.5707963267948966 : f64
    %799 = qlx.apply #qlx.action<pauli_rotation>(%777#1, %cst_542) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_543 = arith.constant 1.5707963267948966 : f64
    %800:2 = qlx.apply #qlx.action<pauli_rotation>(%798, %799, %cst_543) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_544 = arith.constant 1.5707963267948966 : f64
    %801 = qlx.apply #qlx.action<pauli_rotation>(%800#1, %cst_544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %802 = qlx.apply #qlx.action<h>(%801) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_545 = arith.constant 1.5707963267948966 : f64
    %803 = qlx.apply #qlx.action<pauli_rotation>(%790#1, %cst_545) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %804 = qlx.apply #qlx.action<h>(%803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_546 = arith.constant 0.78539816339744828 : f64
    %805:2 = qlx.apply #qlx.action<pauli_rotation>(%802, %804, %cst_546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_547 = arith.constant 1.5707963267948966 : f64
    %806 = qlx.apply #qlx.action<pauli_rotation>(%800#0, %cst_547) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %807 = qlx.apply #qlx.action<h>(%805#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_548 = arith.constant 1.5707963267948966 : f64
    %808:2 = qlx.apply #qlx.action<pauli_rotation>(%806, %807, %cst_548) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_549 = arith.constant 1.5707963267948966 : f64
    %809 = qlx.apply #qlx.action<pauli_rotation>(%796#0, %cst_549) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_550 = arith.constant 1.5707963267948966 : f64
    %810 = qlx.apply #qlx.action<pauli_rotation>(%808#0, %cst_550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %811 = qlx.apply #qlx.action<h>(%810) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_551 = arith.constant 1.5707963267948966 : f64
    %812:2 = qlx.apply #qlx.action<pauli_rotation>(%809, %811, %cst_551) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_552 = arith.constant 1.5707963267948966 : f64
    %813 = qlx.apply #qlx.action<pauli_rotation>(%790#0, %cst_552) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %814 = qlx.apply #qlx.action<h>(%805#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_553 = arith.constant 1.5707963267948966 : f64
    %815:2 = qlx.apply #qlx.action<pauli_rotation>(%813, %814, %cst_553) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_554 = arith.constant 1.5707963267948966 : f64
    %816 = qlx.apply #qlx.action<pauli_rotation>(%815#0, %cst_554) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %817 = qlx.apply #qlx.action<h>(%816) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_555 = arith.constant 1.5707963267948966 : f64
    %818 = qlx.apply #qlx.action<pauli_rotation>(%817, %cst_555) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_556 = arith.constant 1.5707963267948966 : f64
    %819 = qlx.apply #qlx.action<pauli_rotation>(%749#1, %cst_556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %820 = qlx.apply #qlx.action<h>(%819) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_557 = arith.constant 1.5707963267948966 : f64
    %821 = qlx.apply #qlx.action<pauli_rotation>(%820, %cst_557) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_558 = arith.constant 1.5707963267948966 : f64
    %822:2 = qlx.apply #qlx.action<pauli_rotation>(%818, %821, %cst_558) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_559 = arith.constant 1.5707963267948966 : f64
    %823 = qlx.apply #qlx.action<pauli_rotation>(%815#1, %cst_559) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %824 = qlx.apply #qlx.action<h>(%823) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_560 = arith.constant 1.5707963267948966 : f64
    %825 = qlx.apply #qlx.action<pauli_rotation>(%808#1, %cst_560) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_561 = arith.constant 1.5707963267948966 : f64
    %826:2 = qlx.apply #qlx.action<pauli_rotation>(%824, %825, %cst_561) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_562 = arith.constant 1.5707963267948966 : f64
    %827 = qlx.apply #qlx.action<pauli_rotation>(%812#1, %cst_562) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_563 = arith.constant 1.5707963267948966 : f64
    %828 = qlx.apply #qlx.action<pauli_rotation>(%826#1, %cst_563) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_564 = arith.constant 1.5707963267948966 : f64
    %829:2 = qlx.apply #qlx.action<pauli_rotation>(%827, %828, %cst_564) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_565 = arith.constant 1.5707963267948966 : f64
    %830 = qlx.apply #qlx.action<pauli_rotation>(%829#1, %cst_565) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %831 = qlx.apply #qlx.action<h>(%830) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_566 = arith.constant 1.5707963267948966 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%822#1, %cst_566) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %833 = qlx.apply #qlx.action<h>(%832) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_567 = arith.constant 0.78539816339744828 : f64
    %834:2 = qlx.apply #qlx.action<pauli_rotation>(%831, %833, %cst_567) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_568 = arith.constant 1.5707963267948966 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%829#0, %cst_568) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %836 = qlx.apply #qlx.action<h>(%834#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_569 = arith.constant 1.5707963267948966 : f64
    %837:2 = qlx.apply #qlx.action<pauli_rotation>(%835, %836, %cst_569) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_570 = arith.constant 1.5707963267948966 : f64
    %838 = qlx.apply #qlx.action<pauli_rotation>(%826#0, %cst_570) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_571 = arith.constant 1.5707963267948966 : f64
    %839 = qlx.apply #qlx.action<pauli_rotation>(%837#1, %cst_571) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_572 = arith.constant 1.5707963267948966 : f64
    %840:2 = qlx.apply #qlx.action<pauli_rotation>(%838, %839, %cst_572) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_573 = arith.constant 1.5707963267948966 : f64
    %841 = qlx.apply #qlx.action<pauli_rotation>(%822#0, %cst_573) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %842 = qlx.apply #qlx.action<h>(%834#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_574 = arith.constant 1.5707963267948966 : f64
    %843:2 = qlx.apply #qlx.action<pauli_rotation>(%841, %842, %cst_574) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_575 = arith.constant 1.5707963267948966 : f64
    %844 = qlx.apply #qlx.action<pauli_rotation>(%843#0, %cst_575) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_576 = arith.constant 1.5707963267948966 : f64
    %845:2 = qlx.apply #qlx.action<pauli_rotation>(%843#1, %844, %cst_576) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_577 = arith.constant 1.5707963267948966 : f64
    %846 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %cst_577) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_578 = arith.constant 1.5707963267948966 : f64
    %847 = qlx.apply #qlx.action<pauli_rotation>(%840#1, %cst_578) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_579 = arith.constant 1.5707963267948966 : f64
    %848:2 = qlx.apply #qlx.action<pauli_rotation>(%846, %847, %cst_579) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_580 = arith.constant 1.5707963267948966 : f64
    %849 = qlx.apply #qlx.action<pauli_rotation>(%837#0, %cst_580) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %850 = qlx.apply #qlx.action<h>(%849) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_581 = arith.constant 1.5707963267948966 : f64
    %851 = qlx.apply #qlx.action<pauli_rotation>(%850, %cst_581) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %852 = qlx.apply #qlx.action<h>(%851) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_582 = arith.constant 1.5707963267948966 : f64
    %853 = qlx.apply #qlx.action<pauli_rotation>(%848#1, %cst_582) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_583 = arith.constant 1.5707963267948966 : f64
    %854:2 = qlx.apply #qlx.action<pauli_rotation>(%852, %853, %cst_583) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_584 = arith.constant 1.5707963267948966 : f64
    %855 = qlx.apply #qlx.action<pauli_rotation>(%854#1, %cst_584) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %856 = qlx.apply #qlx.action<h>(%855) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_585 = arith.constant 1.5707963267948966 : f64
    %857 = qlx.apply #qlx.action<pauli_rotation>(%845#0, %cst_585) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %858 = qlx.apply #qlx.action<h>(%857) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_586 = arith.constant 0.78539816339744828 : f64
    %859:2 = qlx.apply #qlx.action<pauli_rotation>(%856, %858, %cst_586) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_587 = arith.constant 1.5707963267948966 : f64
    %860 = qlx.apply #qlx.action<pauli_rotation>(%854#0, %cst_587) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %861 = qlx.apply #qlx.action<h>(%859#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_588 = arith.constant 1.5707963267948966 : f64
    %862:2 = qlx.apply #qlx.action<pauli_rotation>(%860, %861, %cst_588) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_589 = arith.constant 1.5707963267948966 : f64
    %863 = qlx.apply #qlx.action<pauli_rotation>(%848#0, %cst_589) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_590 = arith.constant 1.5707963267948966 : f64
    %864 = qlx.apply #qlx.action<pauli_rotation>(%862#1, %cst_590) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_591 = arith.constant 1.5707963267948966 : f64
    %865:2 = qlx.apply #qlx.action<pauli_rotation>(%863, %864, %cst_591) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_592 = arith.constant 1.5707963267948966 : f64
    %866 = qlx.apply #qlx.action<pauli_rotation>(%845#1, %cst_592) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %867 = qlx.apply #qlx.action<h>(%859#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_593 = arith.constant 1.5707963267948966 : f64
    %868:2 = qlx.apply #qlx.action<pauli_rotation>(%866, %867, %cst_593) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_594 = arith.constant 1.5707963267948966 : f64
    %869 = qlx.apply #qlx.action<pauli_rotation>(%812#0, %cst_594) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %870 = qlx.apply #qlx.action<h>(%869) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_595 = arith.constant 3.1415926535897931 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%870, %cst_595) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_596 = arith.constant 1.5707963267948966 : f64
    %872 = qlx.apply #qlx.action<pauli_rotation>(%862#0, %cst_596) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %873 = qlx.apply #qlx.action<h>(%872) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_597 = arith.constant 1.5707963267948966 : f64
    %874 = qlx.apply #qlx.action<pauli_rotation>(%873, %cst_597) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %875 = qlx.apply #qlx.action<h>(%874) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_598 = arith.constant 1.5707963267948966 : f64
    %876:2 = qlx.apply #qlx.action<pauli_rotation>(%871, %875, %cst_598) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_599 = arith.constant 1.5707963267948966 : f64
    %877 = qlx.apply #qlx.action<pauli_rotation>(%865#0, %cst_599) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %878 = qlx.apply #qlx.action<h>(%877) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_600 = arith.constant 1.5707963267948966 : f64
    %879 = qlx.apply #qlx.action<pauli_rotation>(%865#1, %cst_600) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_601 = arith.constant 1.5707963267948966 : f64
    %880:2 = qlx.apply #qlx.action<pauli_rotation>(%878, %879, %cst_601) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_602 = arith.constant 1.5707963267948966 : f64
    %881 = qlx.apply #qlx.action<pauli_rotation>(%550#1, %cst_602) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %882 = qlx.apply #qlx.action<h>(%881) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_603 = arith.constant 1.5707963267948966 : f64
    %883 = qlx.apply #qlx.action<pauli_rotation>(%880#1, %cst_603) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_604 = arith.constant 1.5707963267948966 : f64
    %884:2 = qlx.apply #qlx.action<pauli_rotation>(%882, %883, %cst_604) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_605 = arith.constant 1.5707963267948966 : f64
    %885 = qlx.apply #qlx.action<pauli_rotation>(%884#1, %cst_605) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %886 = qlx.apply #qlx.action<h>(%885) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_606 = arith.constant 1.5707963267948966 : f64
    %887 = qlx.apply #qlx.action<pauli_rotation>(%876#1, %cst_606) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %888 = qlx.apply #qlx.action<h>(%887) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_607 = arith.constant 0.78539816339744828 : f64
    %889:2 = qlx.apply #qlx.action<pauli_rotation>(%886, %888, %cst_607) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_608 = arith.constant 1.5707963267948966 : f64
    %890 = qlx.apply #qlx.action<pauli_rotation>(%884#0, %cst_608) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %891 = qlx.apply #qlx.action<h>(%889#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_609 = arith.constant 1.5707963267948966 : f64
    %892:2 = qlx.apply #qlx.action<pauli_rotation>(%890, %891, %cst_609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_610 = arith.constant 1.5707963267948966 : f64
    %893 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %cst_610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_611 = arith.constant 1.5707963267948966 : f64
    %894 = qlx.apply #qlx.action<pauli_rotation>(%892#1, %cst_611) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_612 = arith.constant 1.5707963267948966 : f64
    %895:2 = qlx.apply #qlx.action<pauli_rotation>(%893, %894, %cst_612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_613 = arith.constant 1.5707963267948966 : f64
    %896 = qlx.apply #qlx.action<pauli_rotation>(%876#0, %cst_613) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %897 = qlx.apply #qlx.action<h>(%889#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_614 = arith.constant 1.5707963267948966 : f64
    %898:2 = qlx.apply #qlx.action<pauli_rotation>(%896, %897, %cst_614) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_615 = arith.constant 1.5707963267948966 : f64
    %899 = qlx.apply #qlx.action<pauli_rotation>(%898#0, %cst_615) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_616 = arith.constant 1.5707963267948966 : f64
    %900 = qlx.apply #qlx.action<pauli_rotation>(%898#1, %cst_616) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_617 = arith.constant 1.5707963267948966 : f64
    %901:2 = qlx.apply #qlx.action<pauli_rotation>(%899, %900, %cst_617) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_618 = arith.constant 1.5707963267948966 : f64
    %902 = qlx.apply #qlx.action<pauli_rotation>(%895#0, %cst_618) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %903 = qlx.apply #qlx.action<h>(%902) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_619 = arith.constant 1.5707963267948966 : f64
    %904 = qlx.apply #qlx.action<pauli_rotation>(%903, %cst_619) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %905 = qlx.apply #qlx.action<h>(%904) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_620 = arith.constant 1.5707963267948966 : f64
    %906 = qlx.apply #qlx.action<pauli_rotation>(%895#1, %cst_620) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_621 = arith.constant 1.5707963267948966 : f64
    %907:2 = qlx.apply #qlx.action<pauli_rotation>(%905, %906, %cst_621) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_622 = arith.constant 1.5707963267948966 : f64
    %908 = qlx.apply #qlx.action<pauli_rotation>(%892#0, %cst_622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%908) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_623 = arith.constant 1.5707963267948966 : f64
    %910 = qlx.apply #qlx.action<pauli_rotation>(%909, %cst_623) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %911 = qlx.apply #qlx.action<h>(%910) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_624 = arith.constant 1.5707963267948966 : f64
    %912 = qlx.apply #qlx.action<pauli_rotation>(%907#1, %cst_624) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_625 = arith.constant 1.5707963267948966 : f64
    %913:2 = qlx.apply #qlx.action<pauli_rotation>(%911, %912, %cst_625) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_626 = arith.constant 1.5707963267948966 : f64
    %914 = qlx.apply #qlx.action<pauli_rotation>(%913#1, %cst_626) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %915 = qlx.apply #qlx.action<h>(%914) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_627 = arith.constant 1.5707963267948966 : f64
    %916 = qlx.apply #qlx.action<pauli_rotation>(%901#1, %cst_627) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %917 = qlx.apply #qlx.action<h>(%916) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_628 = arith.constant 0.78539816339744828 : f64
    %918:2 = qlx.apply #qlx.action<pauli_rotation>(%915, %917, %cst_628) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_629 = arith.constant 1.5707963267948966 : f64
    %919 = qlx.apply #qlx.action<pauli_rotation>(%913#0, %cst_629) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %920 = qlx.apply #qlx.action<h>(%918#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_630 = arith.constant 1.5707963267948966 : f64
    %921:2 = qlx.apply #qlx.action<pauli_rotation>(%919, %920, %cst_630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_631 = arith.constant 1.5707963267948966 : f64
    %922 = qlx.apply #qlx.action<pauli_rotation>(%907#0, %cst_631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_632 = arith.constant 1.5707963267948966 : f64
    %923 = qlx.apply #qlx.action<pauli_rotation>(%921#1, %cst_632) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_633 = arith.constant 1.5707963267948966 : f64
    %924:2 = qlx.apply #qlx.action<pauli_rotation>(%922, %923, %cst_633) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_634 = arith.constant 1.5707963267948966 : f64
    %925 = qlx.apply #qlx.action<pauli_rotation>(%901#0, %cst_634) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %926 = qlx.apply #qlx.action<h>(%918#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_635 = arith.constant 1.5707963267948966 : f64
    %927:2 = qlx.apply #qlx.action<pauli_rotation>(%925, %926, %cst_635) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_636 = arith.constant 1.5707963267948966 : f64
    %928 = qlx.apply #qlx.action<pauli_rotation>(%927#1, %cst_636) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_637 = arith.constant 1.5707963267948966 : f64
    %929 = qlx.apply #qlx.action<pauli_rotation>(%924#1, %cst_637) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_638 = arith.constant 1.5707963267948966 : f64
    %930:2 = qlx.apply #qlx.action<pauli_rotation>(%928, %929, %cst_638) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_639 = arith.constant 1.5707963267948966 : f64
    %931 = qlx.apply #qlx.action<pauli_rotation>(%930#1, %cst_639) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %932 = qlx.apply #qlx.action<h>(%931) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_640 = arith.constant 1.5707963267948966 : f64
    %933 = qlx.apply #qlx.action<pauli_rotation>(%924#0, %cst_640) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %934 = qlx.apply #qlx.action<h>(%933) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_641 = arith.constant 1.5707963267948966 : f64
    %935 = qlx.apply #qlx.action<pauli_rotation>(%934, %cst_641) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %936 = qlx.apply #qlx.action<h>(%935) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_642 = arith.constant 5.000000e-01 : f64
    %937:2 = qlx.apply #qlx.action<pauli_rotation>(%932, %936, %cst_642) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_643 = arith.constant 1.5707963267948966 : f64
    %938 = qlx.apply #qlx.action<pauli_rotation>(%930#0, %cst_643) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %939 = qlx.apply #qlx.action<h>(%937#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_644 = arith.constant 1.5707963267948966 : f64
    %940:2 = qlx.apply #qlx.action<pauli_rotation>(%938, %939, %cst_644) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_645 = arith.constant 1.5707963267948966 : f64
    %941 = qlx.apply #qlx.action<pauli_rotation>(%940#0, %cst_645) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %942 = qlx.apply #qlx.action<h>(%941) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_646 = arith.constant 1.5707963267948966 : f64
    %943 = qlx.apply #qlx.action<pauli_rotation>(%942, %cst_646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %944 = qlx.apply #qlx.action<h>(%943) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_647 = arith.constant 1.5707963267948966 : f64
    %945 = qlx.apply #qlx.action<pauli_rotation>(%940#1, %cst_647) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_648 = arith.constant 1.5707963267948966 : f64
    %946:2 = qlx.apply #qlx.action<pauli_rotation>(%944, %945, %cst_648) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_649 = arith.constant 1.5707963267948966 : f64
    %947 = qlx.apply #qlx.action<pauli_rotation>(%946#1, %cst_649) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %948 = qlx.apply #qlx.action<h>(%947) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %949 = qlx.apply #qlx.action<h>(%937#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_650 = arith.constant 1.5707963267948966 : f64
    %950 = qlx.apply #qlx.action<pauli_rotation>(%949, %cst_650) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %951 = qlx.apply #qlx.action<h>(%950) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_651 = arith.constant 5.000000e-01 : f64
    %952:2 = qlx.apply #qlx.action<pauli_rotation>(%948, %951, %cst_651) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_652 = arith.constant 1.5707963267948966 : f64
    %953 = qlx.apply #qlx.action<pauli_rotation>(%946#0, %cst_652) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %954 = qlx.apply #qlx.action<h>(%952#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_653 = arith.constant 1.5707963267948966 : f64
    %955:2 = qlx.apply #qlx.action<pauli_rotation>(%953, %954, %cst_653) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_654 = arith.constant 1.5707963267948966 : f64
    %956 = qlx.apply #qlx.action<pauli_rotation>(%868#0, %cst_654) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_655 = arith.constant 1.5707963267948966 : f64
    %957:2 = qlx.apply #qlx.action<pauli_rotation>(%868#1, %956, %cst_655) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %958 = qlx.apply #qlx.action<h>(%952#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_656 = arith.constant 1.5707963267948966 : f64
    %959 = qlx.apply #qlx.action<pauli_rotation>(%958, %cst_656) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_657 = arith.constant 1.5707963267948966 : f64
    %960 = qlx.apply #qlx.action<pauli_rotation>(%955#1, %cst_657) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_658 = arith.constant 1.5707963267948966 : f64
    %961:2 = qlx.apply #qlx.action<pauli_rotation>(%959, %960, %cst_658) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_659 = arith.constant 1.5707963267948966 : f64
    %962 = qlx.apply #qlx.action<pauli_rotation>(%955#0, %cst_659) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %963 = qlx.apply #qlx.action<h>(%962) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_660 = arith.constant 1.5707963267948966 : f64
    %964 = qlx.apply #qlx.action<pauli_rotation>(%963, %cst_660) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %965 = qlx.apply #qlx.action<h>(%964) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_661 = arith.constant 1.5707963267948966 : f64
    %966 = qlx.apply #qlx.action<pauli_rotation>(%961#1, %cst_661) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_662 = arith.constant 1.5707963267948966 : f64
    %967:2 = qlx.apply #qlx.action<pauli_rotation>(%965, %966, %cst_662) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_663 = arith.constant 1.5707963267948966 : f64
    %968 = qlx.apply #qlx.action<pauli_rotation>(%967#1, %cst_663) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %969 = qlx.apply #qlx.action<h>(%968) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_664 = arith.constant 1.5707963267948966 : f64
    %970 = qlx.apply #qlx.action<pauli_rotation>(%957#0, %cst_664) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %971 = qlx.apply #qlx.action<h>(%970) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_665 = arith.constant 0.78539816339744828 : f64
    %972:2 = qlx.apply #qlx.action<pauli_rotation>(%969, %971, %cst_665) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_666 = arith.constant 1.5707963267948966 : f64
    %973 = qlx.apply #qlx.action<pauli_rotation>(%967#0, %cst_666) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %974 = qlx.apply #qlx.action<h>(%972#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_667 = arith.constant 1.5707963267948966 : f64
    %975:2 = qlx.apply #qlx.action<pauli_rotation>(%973, %974, %cst_667) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_668 = arith.constant 1.5707963267948966 : f64
    %976 = qlx.apply #qlx.action<pauli_rotation>(%961#0, %cst_668) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_669 = arith.constant 1.5707963267948966 : f64
    %977 = qlx.apply #qlx.action<pauli_rotation>(%975#1, %cst_669) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_670 = arith.constant 1.5707963267948966 : f64
    %978:2 = qlx.apply #qlx.action<pauli_rotation>(%976, %977, %cst_670) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_671 = arith.constant 1.5707963267948966 : f64
    %979 = qlx.apply #qlx.action<pauli_rotation>(%957#1, %cst_671) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %980 = qlx.apply #qlx.action<h>(%972#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_672 = arith.constant 1.5707963267948966 : f64
    %981:2 = qlx.apply #qlx.action<pauli_rotation>(%979, %980, %cst_672) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_673 = arith.constant 1.5707963267948966 : f64
    %982 = qlx.apply #qlx.action<pauli_rotation>(%981#0, %cst_673) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_674 = arith.constant 1.5707963267948966 : f64
    %983:2 = qlx.apply #qlx.action<pauli_rotation>(%981#1, %982, %cst_674) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_675 = arith.constant 1.5707963267948966 : f64
    %984 = qlx.apply #qlx.action<pauli_rotation>(%978#0, %cst_675) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_676 = arith.constant 1.5707963267948966 : f64
    %985 = qlx.apply #qlx.action<pauli_rotation>(%978#1, %cst_676) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_677 = arith.constant 1.5707963267948966 : f64
    %986:2 = qlx.apply #qlx.action<pauli_rotation>(%984, %985, %cst_677) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_678 = arith.constant 1.5707963267948966 : f64
    %987 = qlx.apply #qlx.action<pauli_rotation>(%975#0, %cst_678) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %988 = qlx.apply #qlx.action<h>(%987) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_679 = arith.constant 1.5707963267948966 : f64
    %989 = qlx.apply #qlx.action<pauli_rotation>(%988, %cst_679) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %990 = qlx.apply #qlx.action<h>(%989) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_680 = arith.constant 1.5707963267948966 : f64
    %991 = qlx.apply #qlx.action<pauli_rotation>(%986#1, %cst_680) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_681 = arith.constant 1.5707963267948966 : f64
    %992:2 = qlx.apply #qlx.action<pauli_rotation>(%990, %991, %cst_681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_682 = arith.constant 1.5707963267948966 : f64
    %993 = qlx.apply #qlx.action<pauli_rotation>(%992#1, %cst_682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %994 = qlx.apply #qlx.action<h>(%993) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_683 = arith.constant 1.5707963267948966 : f64
    %995 = qlx.apply #qlx.action<pauli_rotation>(%983#0, %cst_683) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %996 = qlx.apply #qlx.action<h>(%995) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_684 = arith.constant 0.78539816339744828 : f64
    %997:2 = qlx.apply #qlx.action<pauli_rotation>(%994, %996, %cst_684) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_685 = arith.constant 1.5707963267948966 : f64
    %998 = qlx.apply #qlx.action<pauli_rotation>(%992#0, %cst_685) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %999 = qlx.apply #qlx.action<h>(%997#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_686 = arith.constant 1.5707963267948966 : f64
    %1000:2 = qlx.apply #qlx.action<pauli_rotation>(%998, %999, %cst_686) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_687 = arith.constant 1.5707963267948966 : f64
    %1001 = qlx.apply #qlx.action<pauli_rotation>(%986#0, %cst_687) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_688 = arith.constant 1.5707963267948966 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1000#1, %cst_688) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_689 = arith.constant 1.5707963267948966 : f64
    %1003:2 = qlx.apply #qlx.action<pauli_rotation>(%1001, %1002, %cst_689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_690 = arith.constant 1.5707963267948966 : f64
    %1004 = qlx.apply #qlx.action<pauli_rotation>(%983#1, %cst_690) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1005 = qlx.apply #qlx.action<h>(%997#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_691 = arith.constant 1.5707963267948966 : f64
    %1006:2 = qlx.apply #qlx.action<pauli_rotation>(%1004, %1005, %cst_691) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_692 = arith.constant 1.5707963267948966 : f64
    %1007 = qlx.apply #qlx.action<pauli_rotation>(%927#0, %cst_692) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_693 = arith.constant 1.5707963267948966 : f64
    %1008 = qlx.apply #qlx.action<pauli_rotation>(%1000#0, %cst_693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1009 = qlx.apply #qlx.action<h>(%1008) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_694 = arith.constant 1.5707963267948966 : f64
    %1010 = qlx.apply #qlx.action<pauli_rotation>(%1009, %cst_694) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1011 = qlx.apply #qlx.action<h>(%1010) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_695 = arith.constant 1.5707963267948966 : f64
    %1012:2 = qlx.apply #qlx.action<pauli_rotation>(%1007, %1011, %cst_695) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_696 = arith.constant 1.5707963267948966 : f64
    %1013 = qlx.apply #qlx.action<pauli_rotation>(%1003#0, %cst_696) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1014 = qlx.apply #qlx.action<h>(%1013) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_697 = arith.constant 1.5707963267948966 : f64
    %1015 = qlx.apply #qlx.action<pauli_rotation>(%1003#1, %cst_697) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_698 = arith.constant 1.5707963267948966 : f64
    %1016:2 = qlx.apply #qlx.action<pauli_rotation>(%1014, %1015, %cst_698) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_699 = arith.constant 1.5707963267948966 : f64
    %1017 = qlx.apply #qlx.action<pauli_rotation>(%921#0, %cst_699) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1018 = qlx.apply #qlx.action<h>(%1017) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_700 = arith.constant 1.5707963267948966 : f64
    %1019 = qlx.apply #qlx.action<pauli_rotation>(%1018, %cst_700) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1020 = qlx.apply #qlx.action<h>(%1019) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_701 = arith.constant 1.5707963267948966 : f64
    %1021 = qlx.apply #qlx.action<pauli_rotation>(%1016#1, %cst_701) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_702 = arith.constant 1.5707963267948966 : f64
    %1022:2 = qlx.apply #qlx.action<pauli_rotation>(%1020, %1021, %cst_702) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_703 = arith.constant 1.5707963267948966 : f64
    %1023 = qlx.apply #qlx.action<pauli_rotation>(%1022#1, %cst_703) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1024 = qlx.apply #qlx.action<h>(%1023) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_704 = arith.constant 1.5707963267948966 : f64
    %1025 = qlx.apply #qlx.action<pauli_rotation>(%1012#1, %cst_704) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1026 = qlx.apply #qlx.action<h>(%1025) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_705 = arith.constant 0.78539816339744828 : f64
    %1027:2 = qlx.apply #qlx.action<pauli_rotation>(%1024, %1026, %cst_705) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_706 = arith.constant 1.5707963267948966 : f64
    %1028 = qlx.apply #qlx.action<pauli_rotation>(%1022#0, %cst_706) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1029 = qlx.apply #qlx.action<h>(%1027#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_707 = arith.constant 1.5707963267948966 : f64
    %1030:2 = qlx.apply #qlx.action<pauli_rotation>(%1028, %1029, %cst_707) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_708 = arith.constant 1.5707963267948966 : f64
    %1031 = qlx.apply #qlx.action<pauli_rotation>(%1016#0, %cst_708) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_709 = arith.constant 1.5707963267948966 : f64
    %1032 = qlx.apply #qlx.action<pauli_rotation>(%1030#1, %cst_709) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_710 = arith.constant 1.5707963267948966 : f64
    %1033:2 = qlx.apply #qlx.action<pauli_rotation>(%1031, %1032, %cst_710) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_711 = arith.constant 1.5707963267948966 : f64
    %1034 = qlx.apply #qlx.action<pauli_rotation>(%1012#0, %cst_711) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1035 = qlx.apply #qlx.action<h>(%1027#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_712 = arith.constant 1.5707963267948966 : f64
    %1036:2 = qlx.apply #qlx.action<pauli_rotation>(%1034, %1035, %cst_712) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_713 = arith.constant 1.5707963267948966 : f64
    %1037 = qlx.apply #qlx.action<pauli_rotation>(%1036#0, %cst_713) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_714 = arith.constant 1.5707963267948966 : f64
    %1038 = qlx.apply #qlx.action<pauli_rotation>(%1036#1, %cst_714) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_715 = arith.constant 1.5707963267948966 : f64
    %1039:2 = qlx.apply #qlx.action<pauli_rotation>(%1037, %1038, %cst_715) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_716 = arith.constant 1.5707963267948966 : f64
    %1040 = qlx.apply #qlx.action<pauli_rotation>(%1033#0, %cst_716) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1041 = qlx.apply #qlx.action<h>(%1040) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_717 = arith.constant 1.5707963267948966 : f64
    %1042 = qlx.apply #qlx.action<pauli_rotation>(%1041, %cst_717) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1043 = qlx.apply #qlx.action<h>(%1042) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_718 = arith.constant 1.5707963267948966 : f64
    %1044 = qlx.apply #qlx.action<pauli_rotation>(%1033#1, %cst_718) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_719 = arith.constant 1.5707963267948966 : f64
    %1045:2 = qlx.apply #qlx.action<pauli_rotation>(%1043, %1044, %cst_719) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_720 = arith.constant 1.5707963267948966 : f64
    %1046 = qlx.apply #qlx.action<pauli_rotation>(%1030#0, %cst_720) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1047 = qlx.apply #qlx.action<h>(%1046) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_721 = arith.constant 1.5707963267948966 : f64
    %1048 = qlx.apply #qlx.action<pauli_rotation>(%1047, %cst_721) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1049 = qlx.apply #qlx.action<h>(%1048) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_722 = arith.constant 1.5707963267948966 : f64
    %1050 = qlx.apply #qlx.action<pauli_rotation>(%1045#1, %cst_722) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_723 = arith.constant 1.5707963267948966 : f64
    %1051:2 = qlx.apply #qlx.action<pauli_rotation>(%1049, %1050, %cst_723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_724 = arith.constant 1.5707963267948966 : f64
    %1052 = qlx.apply #qlx.action<pauli_rotation>(%1051#1, %cst_724) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1053 = qlx.apply #qlx.action<h>(%1052) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_725 = arith.constant 1.5707963267948966 : f64
    %1054 = qlx.apply #qlx.action<pauli_rotation>(%1039#1, %cst_725) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1055 = qlx.apply #qlx.action<h>(%1054) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_726 = arith.constant 0.78539816339744828 : f64
    %1056:2 = qlx.apply #qlx.action<pauli_rotation>(%1053, %1055, %cst_726) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_727 = arith.constant 1.5707963267948966 : f64
    %1057 = qlx.apply #qlx.action<pauli_rotation>(%1051#0, %cst_727) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1058 = qlx.apply #qlx.action<h>(%1056#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_728 = arith.constant 1.5707963267948966 : f64
    %1059:2 = qlx.apply #qlx.action<pauli_rotation>(%1057, %1058, %cst_728) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_729 = arith.constant 1.5707963267948966 : f64
    %1060 = qlx.apply #qlx.action<pauli_rotation>(%1045#0, %cst_729) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_730 = arith.constant 1.5707963267948966 : f64
    %1061 = qlx.apply #qlx.action<pauli_rotation>(%1059#1, %cst_730) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_731 = arith.constant 1.5707963267948966 : f64
    %1062:2 = qlx.apply #qlx.action<pauli_rotation>(%1060, %1061, %cst_731) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_732 = arith.constant 1.5707963267948966 : f64
    %1063 = qlx.apply #qlx.action<pauli_rotation>(%1039#0, %cst_732) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1064 = qlx.apply #qlx.action<h>(%1056#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_733 = arith.constant 1.5707963267948966 : f64
    %1065:2 = qlx.apply #qlx.action<pauli_rotation>(%1063, %1064, %cst_733) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_734 = arith.constant 1.5707963267948966 : f64
    %1066 = qlx.apply #qlx.action<pauli_rotation>(%749#0, %cst_734) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1067 = qlx.apply #qlx.action<h>(%1066) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_735 = arith.constant 3.1415926535897931 : f64
    %1068 = qlx.apply #qlx.action<pauli_rotation>(%1067, %cst_735) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_736 = arith.constant 1.5707963267948966 : f64
    %1069 = qlx.apply #qlx.action<pauli_rotation>(%1006#1, %cst_736) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_737 = arith.constant 5.000000e-01 : f64
    %1070:2 = qlx.apply #qlx.action<pauli_rotation>(%1068, %1069, %cst_737) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_738 = arith.constant 1.5707963267948966 : f64
    %1071 = qlx.apply #qlx.action<pauli_rotation>(%1006#0, %cst_738) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_739 = arith.constant 1.5707963267948966 : f64
    %1072 = qlx.apply #qlx.action<pauli_rotation>(%1062#0, %cst_739) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1073 = qlx.apply #qlx.action<h>(%1072) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_740 = arith.constant 1.5707963267948966 : f64
    %1074 = qlx.apply #qlx.action<pauli_rotation>(%1073, %cst_740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_741 = arith.constant 5.000000e-01 : f64
    %1075:2 = qlx.apply #qlx.action<pauli_rotation>(%1071, %1074, %cst_741) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_742 = arith.constant 1.5707963267948966 : f64
    %1076 = qlx.apply #qlx.action<pauli_rotation>(%1062#1, %cst_742) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1077 = qlx.apply #qlx.action<h>(%1076) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_743 = arith.constant 1.5707963267948966 : f64
    %1078 = qlx.apply #qlx.action<pauli_rotation>(%1065#1, %cst_743) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1079 = qlx.apply #qlx.action<h>(%1078) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_744 = arith.constant 5.000000e-01 : f64
    %1080:2 = qlx.apply #qlx.action<pauli_rotation>(%1077, %1079, %cst_744) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_745 = arith.constant 1.5707963267948966 : f64
    %1081 = qlx.apply #qlx.action<pauli_rotation>(%1065#0, %cst_745) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_746 = arith.constant 1.5707963267948966 : f64
    %1082 = qlx.apply #qlx.action<pauli_rotation>(%1059#0, %cst_746) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1083 = qlx.apply #qlx.action<h>(%1082) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_747 = arith.constant 3.1415926535897931 : f64
    %1084 = qlx.apply #qlx.action<pauli_rotation>(%1083, %cst_747) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_748 = arith.constant 5.000000e-01 : f64
    %1085:2 = qlx.apply #qlx.action<pauli_rotation>(%1081, %1084, %cst_748) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1086 = qlx.apply #qlx.action<h>(%1075#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_749 = arith.constant 1.5707963267948966 : f64
    %1087:2 = qlx.apply #qlx.action<pauli_rotation>(%1075#1, %1086, %cst_749) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_750 = arith.constant 1.5707963267948966 : f64
    %1088 = qlx.apply #qlx.action<pauli_rotation>(%1070#0, %cst_750) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1089 = qlx.apply #qlx.action<h>(%1088) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1090 = qlx.apply #qlx.action<h>(%1070#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_751 = arith.constant 1.5707963267948966 : f64
    %1091:2 = qlx.apply #qlx.action<pauli_rotation>(%1089, %1090, %cst_751) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1092 = qlx.apply #qlx.action<h>(%1080#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_752 = arith.constant 1.5707963267948966 : f64
    %1093 = qlx.apply #qlx.action<pauli_rotation>(%1091#1, %cst_752) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_753 = arith.constant 1.5707963267948966 : f64
    %1094:2 = qlx.apply #qlx.action<pauli_rotation>(%1092, %1093, %cst_753) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_754 = arith.constant 1.5707963267948966 : f64
    %1095 = qlx.apply #qlx.action<pauli_rotation>(%1094#1, %cst_754) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1096 = qlx.apply #qlx.action<h>(%1095) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_755 = arith.constant 1.5707963267948966 : f64
    %1097 = qlx.apply #qlx.action<pauli_rotation>(%1087#1, %cst_755) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1098 = qlx.apply #qlx.action<h>(%1097) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_756 = arith.constant 0.78539816339744828 : f64
    %1099:2 = qlx.apply #qlx.action<pauli_rotation>(%1096, %1098, %cst_756) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_757 = arith.constant 1.5707963267948966 : f64
    %1100 = qlx.apply #qlx.action<pauli_rotation>(%1094#0, %cst_757) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1101 = qlx.apply #qlx.action<h>(%1099#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_758 = arith.constant 1.5707963267948966 : f64
    %1102:2 = qlx.apply #qlx.action<pauli_rotation>(%1100, %1101, %cst_758) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_759 = arith.constant 1.5707963267948966 : f64
    %1103 = qlx.apply #qlx.action<pauli_rotation>(%1091#0, %cst_759) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_760 = arith.constant 1.5707963267948966 : f64
    %1104 = qlx.apply #qlx.action<pauli_rotation>(%1102#1, %cst_760) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_761 = arith.constant 1.5707963267948966 : f64
    %1105:2 = qlx.apply #qlx.action<pauli_rotation>(%1103, %1104, %cst_761) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_762 = arith.constant 1.5707963267948966 : f64
    %1106 = qlx.apply #qlx.action<pauli_rotation>(%1087#0, %cst_762) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1107 = qlx.apply #qlx.action<h>(%1099#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_763 = arith.constant 1.5707963267948966 : f64
    %1108:2 = qlx.apply #qlx.action<pauli_rotation>(%1106, %1107, %cst_763) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_764 = arith.constant 1.5707963267948966 : f64
    %1109 = qlx.apply #qlx.action<pauli_rotation>(%1108#0, %cst_764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_765 = arith.constant 1.5707963267948966 : f64
    %1110 = qlx.apply #qlx.action<pauli_rotation>(%1108#1, %cst_765) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_766 = arith.constant 1.5707963267948966 : f64
    %1111:2 = qlx.apply #qlx.action<pauli_rotation>(%1109, %1110, %cst_766) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_767 = arith.constant 1.5707963267948966 : f64
    %1112 = qlx.apply #qlx.action<pauli_rotation>(%1105#0, %cst_767) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1113 = qlx.apply #qlx.action<h>(%1112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_768 = arith.constant 1.5707963267948966 : f64
    %1114 = qlx.apply #qlx.action<pauli_rotation>(%1113, %cst_768) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1115 = qlx.apply #qlx.action<h>(%1114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_769 = arith.constant 1.5707963267948966 : f64
    %1116 = qlx.apply #qlx.action<pauli_rotation>(%1105#1, %cst_769) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_770 = arith.constant 1.5707963267948966 : f64
    %1117:2 = qlx.apply #qlx.action<pauli_rotation>(%1115, %1116, %cst_770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_771 = arith.constant 1.5707963267948966 : f64
    %1118 = qlx.apply #qlx.action<pauli_rotation>(%1102#0, %cst_771) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1119 = qlx.apply #qlx.action<h>(%1118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_772 = arith.constant 1.5707963267948966 : f64
    %1120 = qlx.apply #qlx.action<pauli_rotation>(%1119, %cst_772) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1121 = qlx.apply #qlx.action<h>(%1120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_773 = arith.constant 1.5707963267948966 : f64
    %1122 = qlx.apply #qlx.action<pauli_rotation>(%1117#1, %cst_773) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_774 = arith.constant 1.5707963267948966 : f64
    %1123:2 = qlx.apply #qlx.action<pauli_rotation>(%1121, %1122, %cst_774) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_775 = arith.constant 1.5707963267948966 : f64
    %1124 = qlx.apply #qlx.action<pauli_rotation>(%1123#1, %cst_775) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1125 = qlx.apply #qlx.action<h>(%1124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_776 = arith.constant 1.5707963267948966 : f64
    %1126 = qlx.apply #qlx.action<pauli_rotation>(%1111#1, %cst_776) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1127 = qlx.apply #qlx.action<h>(%1126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_777 = arith.constant 0.78539816339744828 : f64
    %1128:2 = qlx.apply #qlx.action<pauli_rotation>(%1125, %1127, %cst_777) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_778 = arith.constant 1.5707963267948966 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1123#0, %cst_778) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1130 = qlx.apply #qlx.action<h>(%1128#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_779 = arith.constant 1.5707963267948966 : f64
    %1131:2 = qlx.apply #qlx.action<pauli_rotation>(%1129, %1130, %cst_779) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_780 = arith.constant 1.5707963267948966 : f64
    %1132 = qlx.apply #qlx.action<pauli_rotation>(%1117#0, %cst_780) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_781 = arith.constant 1.5707963267948966 : f64
    %1133 = qlx.apply #qlx.action<pauli_rotation>(%1131#1, %cst_781) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_782 = arith.constant 1.5707963267948966 : f64
    %1134:2 = qlx.apply #qlx.action<pauli_rotation>(%1132, %1133, %cst_782) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_783 = arith.constant 1.5707963267948966 : f64
    %1135 = qlx.apply #qlx.action<pauli_rotation>(%1111#0, %cst_783) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1136 = qlx.apply #qlx.action<h>(%1128#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_784 = arith.constant 1.5707963267948966 : f64
    %1137:2 = qlx.apply #qlx.action<pauli_rotation>(%1135, %1136, %cst_784) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_785 = arith.constant 1.5707963267948966 : f64
    %1138 = qlx.apply #qlx.action<pauli_rotation>(%1137#1, %cst_785) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_786 = arith.constant 1.5707963267948966 : f64
    %1139 = qlx.apply #qlx.action<pauli_rotation>(%1137#0, %cst_786) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1140 = qlx.apply #qlx.action<h>(%1139) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_787 = arith.constant 1.5707963267948966 : f64
    %1141:2 = qlx.apply #qlx.action<pauli_rotation>(%1138, %1140, %cst_787) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_788 = arith.constant 1.5707963267948966 : f64
    %1142 = qlx.apply #qlx.action<pauli_rotation>(%1085#0, %cst_788) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1143 = qlx.apply #qlx.action<h>(%1142) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1144 = qlx.apply #qlx.action<h>(%1080#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_789 = arith.constant 1.5707963267948966 : f64
    %1145:2 = qlx.apply #qlx.action<pauli_rotation>(%1143, %1144, %cst_789) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_790 = arith.constant 1.5707963267948966 : f64
    %1146 = qlx.apply #qlx.action<pauli_rotation>(%1145#1, %cst_790) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1147 = qlx.apply #qlx.action<h>(%1146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_791 = arith.constant 1.5707963267948966 : f64
    %1148 = qlx.apply #qlx.action<pauli_rotation>(%1131#0, %cst_791) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1149 = qlx.apply #qlx.action<h>(%1148) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_792 = arith.constant 1.5707963267948966 : f64
    %1150 = qlx.apply #qlx.action<pauli_rotation>(%1149, %cst_792) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1151 = qlx.apply #qlx.action<h>(%1150) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_793 = arith.constant 1.5707963267948966 : f64
    %1152:2 = qlx.apply #qlx.action<pauli_rotation>(%1147, %1151, %cst_793) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_794 = arith.constant 1.5707963267948966 : f64
    %1153 = qlx.apply #qlx.action<pauli_rotation>(%1152#1, %cst_794) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1154 = qlx.apply #qlx.action<h>(%1153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_795 = arith.constant 1.5707963267948966 : f64
    %1155 = qlx.apply #qlx.action<pauli_rotation>(%1141#1, %cst_795) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1156 = qlx.apply #qlx.action<h>(%1155) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_796 = arith.constant 0.78539816339744828 : f64
    %1157:2 = qlx.apply #qlx.action<pauli_rotation>(%1154, %1156, %cst_796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_797 = arith.constant 1.5707963267948966 : f64
    %1158 = qlx.apply #qlx.action<pauli_rotation>(%1152#0, %cst_797) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1159 = qlx.apply #qlx.action<h>(%1157#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_798 = arith.constant 1.5707963267948966 : f64
    %1160:2 = qlx.apply #qlx.action<pauli_rotation>(%1158, %1159, %cst_798) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_799 = arith.constant 1.5707963267948966 : f64
    %1161 = qlx.apply #qlx.action<pauli_rotation>(%1145#0, %cst_799) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_800 = arith.constant 1.5707963267948966 : f64
    %1162 = qlx.apply #qlx.action<pauli_rotation>(%1160#0, %cst_800) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1163 = qlx.apply #qlx.action<h>(%1162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_801 = arith.constant 1.5707963267948966 : f64
    %1164:2 = qlx.apply #qlx.action<pauli_rotation>(%1161, %1163, %cst_801) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_802 = arith.constant 1.5707963267948966 : f64
    %1165 = qlx.apply #qlx.action<pauli_rotation>(%1141#0, %cst_802) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1166 = qlx.apply #qlx.action<h>(%1157#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_803 = arith.constant 1.5707963267948966 : f64
    %1167:2 = qlx.apply #qlx.action<pauli_rotation>(%1165, %1166, %cst_803) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_804 = arith.constant 1.5707963267948966 : f64
    %1168 = qlx.apply #qlx.action<pauli_rotation>(%1167#0, %cst_804) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1169 = qlx.apply #qlx.action<h>(%1168) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_805 = arith.constant 1.5707963267948966 : f64
    %1170 = qlx.apply #qlx.action<pauli_rotation>(%1169, %cst_805) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1171 = qlx.apply #qlx.action<h>(%1170) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_806 = arith.constant 1.5707963267948966 : f64
    %1172 = qlx.apply #qlx.action<pauli_rotation>(%1167#1, %cst_806) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_807 = arith.constant 1.5707963267948966 : f64
    %1173:2 = qlx.apply #qlx.action<pauli_rotation>(%1171, %1172, %cst_807) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_808 = arith.constant 1.5707963267948966 : f64
    %1174 = qlx.apply #qlx.action<pauli_rotation>(%1164#0, %cst_808) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1175 = qlx.apply #qlx.action<h>(%1174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_809 = arith.constant 1.5707963267948966 : f64
    %1176 = qlx.apply #qlx.action<pauli_rotation>(%1175, %cst_809) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1177 = qlx.apply #qlx.action<h>(%1176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_810 = arith.constant 1.5707963267948966 : f64
    %1178 = qlx.apply #qlx.action<pauli_rotation>(%1164#1, %cst_810) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_811 = arith.constant 1.5707963267948966 : f64
    %1179:2 = qlx.apply #qlx.action<pauli_rotation>(%1177, %1178, %cst_811) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_812 = arith.constant 1.5707963267948966 : f64
    %1180 = qlx.apply #qlx.action<pauli_rotation>(%1179#1, %cst_812) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1181 = qlx.apply #qlx.action<h>(%1180) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_813 = arith.constant 1.5707963267948966 : f64
    %1182 = qlx.apply #qlx.action<pauli_rotation>(%1160#1, %cst_813) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_814 = arith.constant 1.5707963267948966 : f64
    %1183:2 = qlx.apply #qlx.action<pauli_rotation>(%1181, %1182, %cst_814) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_815 = arith.constant 1.5707963267948966 : f64
    %1184 = qlx.apply #qlx.action<pauli_rotation>(%1183#1, %cst_815) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1185 = qlx.apply #qlx.action<h>(%1184) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_816 = arith.constant 1.5707963267948966 : f64
    %1186 = qlx.apply #qlx.action<pauli_rotation>(%1173#1, %cst_816) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1187 = qlx.apply #qlx.action<h>(%1186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_817 = arith.constant 0.78539816339744828 : f64
    %1188:2 = qlx.apply #qlx.action<pauli_rotation>(%1185, %1187, %cst_817) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_818 = arith.constant 1.5707963267948966 : f64
    %1189 = qlx.apply #qlx.action<pauli_rotation>(%1183#0, %cst_818) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1190 = qlx.apply #qlx.action<h>(%1188#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_819 = arith.constant 1.5707963267948966 : f64
    %1191:2 = qlx.apply #qlx.action<pauli_rotation>(%1189, %1190, %cst_819) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_820 = arith.constant 1.5707963267948966 : f64
    %1192 = qlx.apply #qlx.action<pauli_rotation>(%1179#0, %cst_820) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_821 = arith.constant 1.5707963267948966 : f64
    %1193 = qlx.apply #qlx.action<pauli_rotation>(%1191#0, %cst_821) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1194 = qlx.apply #qlx.action<h>(%1193) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_822 = arith.constant 1.5707963267948966 : f64
    %1195:2 = qlx.apply #qlx.action<pauli_rotation>(%1192, %1194, %cst_822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_823 = arith.constant 1.5707963267948966 : f64
    %1196 = qlx.apply #qlx.action<pauli_rotation>(%1173#0, %cst_823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1197 = qlx.apply #qlx.action<h>(%1188#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_824 = arith.constant 1.5707963267948966 : f64
    %1198:2 = qlx.apply #qlx.action<pauli_rotation>(%1196, %1197, %cst_824) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_825 = arith.constant 1.5707963267948966 : f64
    %1199 = qlx.apply #qlx.action<pauli_rotation>(%1191#1, %cst_825) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_826 = arith.constant 1.5707963267948966 : f64
    %1200 = qlx.apply #qlx.action<pauli_rotation>(%1198#1, %cst_826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_827 = arith.constant 1.5707963267948966 : f64
    %1201:2 = qlx.apply #qlx.action<pauli_rotation>(%1199, %1200, %cst_827) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_828 = arith.constant 1.5707963267948966 : f64
    %1202 = qlx.apply #qlx.action<pauli_rotation>(%1201#1, %cst_828) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1203 = qlx.apply #qlx.action<h>(%1202) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_829 = arith.constant 1.5707963267948966 : f64
    %1204 = qlx.apply #qlx.action<pauli_rotation>(%1198#0, %cst_829) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1205 = qlx.apply #qlx.action<h>(%1204) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_830 = arith.constant 1.5707963267948966 : f64
    %1206 = qlx.apply #qlx.action<pauli_rotation>(%1205, %cst_830) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1207 = qlx.apply #qlx.action<h>(%1206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_831 = arith.constant 5.000000e-01 : f64
    %1208:2 = qlx.apply #qlx.action<pauli_rotation>(%1203, %1207, %cst_831) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_832 = arith.constant 1.5707963267948966 : f64
    %1209 = qlx.apply #qlx.action<pauli_rotation>(%1201#0, %cst_832) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1210 = qlx.apply #qlx.action<h>(%1208#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_833 = arith.constant 1.5707963267948966 : f64
    %1211:2 = qlx.apply #qlx.action<pauli_rotation>(%1209, %1210, %cst_833) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_834 = arith.constant 1.5707963267948966 : f64
    %1212 = qlx.apply #qlx.action<pauli_rotation>(%1211#0, %cst_834) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1213 = qlx.apply #qlx.action<h>(%1212) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_835 = arith.constant 1.5707963267948966 : f64
    %1214 = qlx.apply #qlx.action<pauli_rotation>(%1213, %cst_835) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1215 = qlx.apply #qlx.action<h>(%1214) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_836 = arith.constant 1.5707963267948966 : f64
    %1216 = qlx.apply #qlx.action<pauli_rotation>(%1211#1, %cst_836) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_837 = arith.constant 1.5707963267948966 : f64
    %1217:2 = qlx.apply #qlx.action<pauli_rotation>(%1215, %1216, %cst_837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_838 = arith.constant 1.5707963267948966 : f64
    %1218 = qlx.apply #qlx.action<pauli_rotation>(%1217#1, %cst_838) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1219 = qlx.apply #qlx.action<h>(%1218) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1220 = qlx.apply #qlx.action<h>(%1208#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_839 = arith.constant 1.5707963267948966 : f64
    %1221 = qlx.apply #qlx.action<pauli_rotation>(%1220, %cst_839) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1222 = qlx.apply #qlx.action<h>(%1221) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_840 = arith.constant 5.000000e-01 : f64
    %1223:2 = qlx.apply #qlx.action<pauli_rotation>(%1219, %1222, %cst_840) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_841 = arith.constant 1.5707963267948966 : f64
    %1224 = qlx.apply #qlx.action<pauli_rotation>(%1217#0, %cst_841) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1225 = qlx.apply #qlx.action<h>(%1223#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_842 = arith.constant 1.5707963267948966 : f64
    %1226:2 = qlx.apply #qlx.action<pauli_rotation>(%1224, %1225, %cst_842) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_843 = arith.constant 1.5707963267948966 : f64
    %1227 = qlx.apply #qlx.action<pauli_rotation>(%1226#1, %cst_843) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1228 = qlx.apply #qlx.action<h>(%1227) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1229 = qlx.apply #qlx.action<h>(%1223#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_844 = arith.constant 1.5707963267948966 : f64
    %1230 = qlx.apply #qlx.action<pauli_rotation>(%1229, %cst_844) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1231 = qlx.apply #qlx.action<h>(%1230) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_845 = arith.constant 1.5707963267948966 : f64
    %1232:2 = qlx.apply #qlx.action<pauli_rotation>(%1228, %1231, %cst_845) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_846 = arith.constant 1.5707963267948966 : f64
    %1233 = qlx.apply #qlx.action<pauli_rotation>(%1134#0, %cst_846) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1234 = qlx.apply #qlx.action<h>(%1233) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_847 = arith.constant 1.5707963267948966 : f64
    %1235 = qlx.apply #qlx.action<pauli_rotation>(%1234, %cst_847) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1236 = qlx.apply #qlx.action<h>(%1235) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_848 = arith.constant 1.5707963267948966 : f64
    %1237 = qlx.apply #qlx.action<pauli_rotation>(%1134#1, %cst_848) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_849 = arith.constant 1.5707963267948966 : f64
    %1238:2 = qlx.apply #qlx.action<pauli_rotation>(%1236, %1237, %cst_849) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_850 = arith.constant 1.5707963267948966 : f64
    %1239 = qlx.apply #qlx.action<pauli_rotation>(%1226#0, %cst_850) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1240 = qlx.apply #qlx.action<h>(%1239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_851 = arith.constant 1.5707963267948966 : f64
    %1241 = qlx.apply #qlx.action<pauli_rotation>(%1240, %cst_851) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1242 = qlx.apply #qlx.action<h>(%1241) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_852 = arith.constant 1.5707963267948966 : f64
    %1243 = qlx.apply #qlx.action<pauli_rotation>(%1238#1, %cst_852) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_853 = arith.constant 1.5707963267948966 : f64
    %1244:2 = qlx.apply #qlx.action<pauli_rotation>(%1242, %1243, %cst_853) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_854 = arith.constant 1.5707963267948966 : f64
    %1245 = qlx.apply #qlx.action<pauli_rotation>(%1244#1, %cst_854) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1246 = qlx.apply #qlx.action<h>(%1245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_855 = arith.constant 1.5707963267948966 : f64
    %1247 = qlx.apply #qlx.action<pauli_rotation>(%1232#1, %cst_855) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1248 = qlx.apply #qlx.action<h>(%1247) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_856 = arith.constant 0.78539816339744828 : f64
    %1249:2 = qlx.apply #qlx.action<pauli_rotation>(%1246, %1248, %cst_856) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_857 = arith.constant 1.5707963267948966 : f64
    %1250 = qlx.apply #qlx.action<pauli_rotation>(%1244#0, %cst_857) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1251 = qlx.apply #qlx.action<h>(%1249#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_858 = arith.constant 1.5707963267948966 : f64
    %1252:2 = qlx.apply #qlx.action<pauli_rotation>(%1250, %1251, %cst_858) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_859 = arith.constant 1.5707963267948966 : f64
    %1253 = qlx.apply #qlx.action<pauli_rotation>(%1238#0, %cst_859) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_860 = arith.constant 1.5707963267948966 : f64
    %1254 = qlx.apply #qlx.action<pauli_rotation>(%1252#1, %cst_860) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_861 = arith.constant 1.5707963267948966 : f64
    %1255:2 = qlx.apply #qlx.action<pauli_rotation>(%1253, %1254, %cst_861) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_862 = arith.constant 1.5707963267948966 : f64
    %1256 = qlx.apply #qlx.action<pauli_rotation>(%1232#0, %cst_862) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1257 = qlx.apply #qlx.action<h>(%1249#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_863 = arith.constant 1.5707963267948966 : f64
    %1258:2 = qlx.apply #qlx.action<pauli_rotation>(%1256, %1257, %cst_863) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_864 = arith.constant 1.5707963267948966 : f64
    %1259 = qlx.apply #qlx.action<pauli_rotation>(%1258#0, %cst_864) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_865 = arith.constant 1.5707963267948966 : f64
    %1260 = qlx.apply #qlx.action<pauli_rotation>(%1258#1, %cst_865) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_866 = arith.constant 1.5707963267948966 : f64
    %1261:2 = qlx.apply #qlx.action<pauli_rotation>(%1259, %1260, %cst_866) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_867 = arith.constant 1.5707963267948966 : f64
    %1262 = qlx.apply #qlx.action<pauli_rotation>(%1255#0, %cst_867) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1263 = qlx.apply #qlx.action<h>(%1262) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_868 = arith.constant 1.5707963267948966 : f64
    %1264 = qlx.apply #qlx.action<pauli_rotation>(%1263, %cst_868) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1265 = qlx.apply #qlx.action<h>(%1264) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_869 = arith.constant 1.5707963267948966 : f64
    %1266 = qlx.apply #qlx.action<pauli_rotation>(%1255#1, %cst_869) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_870 = arith.constant 1.5707963267948966 : f64
    %1267:2 = qlx.apply #qlx.action<pauli_rotation>(%1265, %1266, %cst_870) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_871 = arith.constant 1.5707963267948966 : f64
    %1268 = qlx.apply #qlx.action<pauli_rotation>(%1252#0, %cst_871) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1269 = qlx.apply #qlx.action<h>(%1268) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_872 = arith.constant 1.5707963267948966 : f64
    %1270 = qlx.apply #qlx.action<pauli_rotation>(%1269, %cst_872) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1271 = qlx.apply #qlx.action<h>(%1270) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_873 = arith.constant 1.5707963267948966 : f64
    %1272 = qlx.apply #qlx.action<pauli_rotation>(%1267#1, %cst_873) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_874 = arith.constant 1.5707963267948966 : f64
    %1273:2 = qlx.apply #qlx.action<pauli_rotation>(%1271, %1272, %cst_874) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_875 = arith.constant 1.5707963267948966 : f64
    %1274 = qlx.apply #qlx.action<pauli_rotation>(%1273#1, %cst_875) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1275 = qlx.apply #qlx.action<h>(%1274) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_876 = arith.constant 1.5707963267948966 : f64
    %1276 = qlx.apply #qlx.action<pauli_rotation>(%1261#1, %cst_876) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1277 = qlx.apply #qlx.action<h>(%1276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_877 = arith.constant 0.78539816339744828 : f64
    %1278:2 = qlx.apply #qlx.action<pauli_rotation>(%1275, %1277, %cst_877) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_878 = arith.constant 1.5707963267948966 : f64
    %1279 = qlx.apply #qlx.action<pauli_rotation>(%1273#0, %cst_878) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1280 = qlx.apply #qlx.action<h>(%1278#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_879 = arith.constant 1.5707963267948966 : f64
    %1281:2 = qlx.apply #qlx.action<pauli_rotation>(%1279, %1280, %cst_879) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_880 = arith.constant 1.5707963267948966 : f64
    %1282 = qlx.apply #qlx.action<pauli_rotation>(%1267#0, %cst_880) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_881 = arith.constant 1.5707963267948966 : f64
    %1283 = qlx.apply #qlx.action<pauli_rotation>(%1281#1, %cst_881) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_882 = arith.constant 1.5707963267948966 : f64
    %1284:2 = qlx.apply #qlx.action<pauli_rotation>(%1282, %1283, %cst_882) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_883 = arith.constant 1.5707963267948966 : f64
    %1285 = qlx.apply #qlx.action<pauli_rotation>(%1261#0, %cst_883) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1286 = qlx.apply #qlx.action<h>(%1278#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_884 = arith.constant 1.5707963267948966 : f64
    %1287:2 = qlx.apply #qlx.action<pauli_rotation>(%1285, %1286, %cst_884) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_885 = arith.constant 1.5707963267948966 : f64
    %1288 = qlx.apply #qlx.action<pauli_rotation>(%1287#1, %cst_885) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_886 = arith.constant 1.5707963267948966 : f64
    %1289 = qlx.apply #qlx.action<pauli_rotation>(%1287#0, %cst_886) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1290 = qlx.apply #qlx.action<h>(%1289) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_887 = arith.constant 1.5707963267948966 : f64
    %1291:2 = qlx.apply #qlx.action<pauli_rotation>(%1288, %1290, %cst_887) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_888 = arith.constant 1.5707963267948966 : f64
    %1292 = qlx.apply #qlx.action<pauli_rotation>(%1195#0, %cst_888) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1293 = qlx.apply #qlx.action<h>(%1292) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_889 = arith.constant 1.5707963267948966 : f64
    %1294 = qlx.apply #qlx.action<pauli_rotation>(%1293, %cst_889) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1295 = qlx.apply #qlx.action<h>(%1294) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_890 = arith.constant 1.5707963267948966 : f64
    %1296 = qlx.apply #qlx.action<pauli_rotation>(%1195#1, %cst_890) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_891 = arith.constant 1.5707963267948966 : f64
    %1297:2 = qlx.apply #qlx.action<pauli_rotation>(%1295, %1296, %cst_891) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_892 = arith.constant 1.5707963267948966 : f64
    %1298 = qlx.apply #qlx.action<pauli_rotation>(%1297#1, %cst_892) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1299 = qlx.apply #qlx.action<h>(%1298) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_893 = arith.constant 1.5707963267948966 : f64
    %1300 = qlx.apply #qlx.action<pauli_rotation>(%1281#0, %cst_893) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1301 = qlx.apply #qlx.action<h>(%1300) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_894 = arith.constant 1.5707963267948966 : f64
    %1302 = qlx.apply #qlx.action<pauli_rotation>(%1301, %cst_894) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1303 = qlx.apply #qlx.action<h>(%1302) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_895 = arith.constant 1.5707963267948966 : f64
    %1304:2 = qlx.apply #qlx.action<pauli_rotation>(%1299, %1303, %cst_895) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_896 = arith.constant 1.5707963267948966 : f64
    %1305 = qlx.apply #qlx.action<pauli_rotation>(%1304#1, %cst_896) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1306 = qlx.apply #qlx.action<h>(%1305) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_897 = arith.constant 1.5707963267948966 : f64
    %1307 = qlx.apply #qlx.action<pauli_rotation>(%1291#1, %cst_897) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1308 = qlx.apply #qlx.action<h>(%1307) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_898 = arith.constant 0.78539816339744828 : f64
    %1309:2 = qlx.apply #qlx.action<pauli_rotation>(%1306, %1308, %cst_898) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_899 = arith.constant 1.5707963267948966 : f64
    %1310 = qlx.apply #qlx.action<pauli_rotation>(%1304#0, %cst_899) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1311 = qlx.apply #qlx.action<h>(%1309#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_900 = arith.constant 1.5707963267948966 : f64
    %1312:2 = qlx.apply #qlx.action<pauli_rotation>(%1310, %1311, %cst_900) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_901 = arith.constant 1.5707963267948966 : f64
    %1313 = qlx.apply #qlx.action<pauli_rotation>(%1297#0, %cst_901) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_902 = arith.constant 1.5707963267948966 : f64
    %1314 = qlx.apply #qlx.action<pauli_rotation>(%1312#0, %cst_902) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1315 = qlx.apply #qlx.action<h>(%1314) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_903 = arith.constant 1.5707963267948966 : f64
    %1316:2 = qlx.apply #qlx.action<pauli_rotation>(%1313, %1315, %cst_903) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_904 = arith.constant 1.5707963267948966 : f64
    %1317 = qlx.apply #qlx.action<pauli_rotation>(%1291#0, %cst_904) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1318 = qlx.apply #qlx.action<h>(%1309#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_905 = arith.constant 1.5707963267948966 : f64
    %1319:2 = qlx.apply #qlx.action<pauli_rotation>(%1317, %1318, %cst_905) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_906 = arith.constant 1.5707963267948966 : f64
    %1320 = qlx.apply #qlx.action<pauli_rotation>(%1319#0, %cst_906) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1321 = qlx.apply #qlx.action<h>(%1320) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_907 = arith.constant 1.5707963267948966 : f64
    %1322 = qlx.apply #qlx.action<pauli_rotation>(%1321, %cst_907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1323 = qlx.apply #qlx.action<h>(%1322) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_908 = arith.constant 1.5707963267948966 : f64
    %1324 = qlx.apply #qlx.action<pauli_rotation>(%1319#1, %cst_908) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_909 = arith.constant 1.5707963267948966 : f64
    %1325:2 = qlx.apply #qlx.action<pauli_rotation>(%1323, %1324, %cst_909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_910 = arith.constant 1.5707963267948966 : f64
    %1326 = qlx.apply #qlx.action<pauli_rotation>(%1316#0, %cst_910) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1327 = qlx.apply #qlx.action<h>(%1326) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_911 = arith.constant 1.5707963267948966 : f64
    %1328 = qlx.apply #qlx.action<pauli_rotation>(%1327, %cst_911) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1329 = qlx.apply #qlx.action<h>(%1328) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_912 = arith.constant 1.5707963267948966 : f64
    %1330 = qlx.apply #qlx.action<pauli_rotation>(%1316#1, %cst_912) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_913 = arith.constant 1.5707963267948966 : f64
    %1331:2 = qlx.apply #qlx.action<pauli_rotation>(%1329, %1330, %cst_913) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_914 = arith.constant 1.5707963267948966 : f64
    %1332 = qlx.apply #qlx.action<pauli_rotation>(%1331#1, %cst_914) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1333 = qlx.apply #qlx.action<h>(%1332) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_915 = arith.constant 1.5707963267948966 : f64
    %1334 = qlx.apply #qlx.action<pauli_rotation>(%1312#1, %cst_915) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_916 = arith.constant 1.5707963267948966 : f64
    %1335:2 = qlx.apply #qlx.action<pauli_rotation>(%1333, %1334, %cst_916) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_917 = arith.constant 1.5707963267948966 : f64
    %1336 = qlx.apply #qlx.action<pauli_rotation>(%1335#1, %cst_917) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1337 = qlx.apply #qlx.action<h>(%1336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_918 = arith.constant 1.5707963267948966 : f64
    %1338 = qlx.apply #qlx.action<pauli_rotation>(%1325#1, %cst_918) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1339 = qlx.apply #qlx.action<h>(%1338) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_919 = arith.constant 0.78539816339744828 : f64
    %1340:2 = qlx.apply #qlx.action<pauli_rotation>(%1337, %1339, %cst_919) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_920 = arith.constant 1.5707963267948966 : f64
    %1341 = qlx.apply #qlx.action<pauli_rotation>(%1335#0, %cst_920) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1342 = qlx.apply #qlx.action<h>(%1340#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_921 = arith.constant 1.5707963267948966 : f64
    %1343:2 = qlx.apply #qlx.action<pauli_rotation>(%1341, %1342, %cst_921) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_922 = arith.constant 1.5707963267948966 : f64
    %1344 = qlx.apply #qlx.action<pauli_rotation>(%1331#0, %cst_922) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_923 = arith.constant 1.5707963267948966 : f64
    %1345 = qlx.apply #qlx.action<pauli_rotation>(%1343#0, %cst_923) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1346 = qlx.apply #qlx.action<h>(%1345) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_924 = arith.constant 1.5707963267948966 : f64
    %1347:2 = qlx.apply #qlx.action<pauli_rotation>(%1344, %1346, %cst_924) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_925 = arith.constant 1.5707963267948966 : f64
    %1348 = qlx.apply #qlx.action<pauli_rotation>(%1325#0, %cst_925) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1349 = qlx.apply #qlx.action<h>(%1340#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_926 = arith.constant 1.5707963267948966 : f64
    %1350:2 = qlx.apply #qlx.action<pauli_rotation>(%1348, %1349, %cst_926) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_927 = arith.constant 1.5707963267948966 : f64
    %1351 = qlx.apply #qlx.action<pauli_rotation>(%1350#0, %cst_927) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1352 = qlx.apply #qlx.action<h>(%1351) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_928 = arith.constant 1.5707963267948966 : f64
    %1353 = qlx.apply #qlx.action<pauli_rotation>(%1352, %cst_928) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_929 = arith.constant 1.5707963267948966 : f64
    %1354 = qlx.apply #qlx.action<pauli_rotation>(%1284#1, %cst_929) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1355 = qlx.apply #qlx.action<h>(%1354) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_930 = arith.constant 1.5707963267948966 : f64
    %1356 = qlx.apply #qlx.action<pauli_rotation>(%1355, %cst_930) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_931 = arith.constant 1.5707963267948966 : f64
    %1357:2 = qlx.apply #qlx.action<pauli_rotation>(%1353, %1356, %cst_931) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_932 = arith.constant 1.5707963267948966 : f64
    %1358 = qlx.apply #qlx.action<pauli_rotation>(%1350#1, %cst_932) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1359 = qlx.apply #qlx.action<h>(%1358) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_933 = arith.constant 1.5707963267948966 : f64
    %1360 = qlx.apply #qlx.action<pauli_rotation>(%1343#1, %cst_933) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_934 = arith.constant 1.5707963267948966 : f64
    %1361:2 = qlx.apply #qlx.action<pauli_rotation>(%1359, %1360, %cst_934) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_935 = arith.constant 1.5707963267948966 : f64
    %1362 = qlx.apply #qlx.action<pauli_rotation>(%1347#1, %cst_935) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_936 = arith.constant 1.5707963267948966 : f64
    %1363 = qlx.apply #qlx.action<pauli_rotation>(%1361#1, %cst_936) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_937 = arith.constant 1.5707963267948966 : f64
    %1364:2 = qlx.apply #qlx.action<pauli_rotation>(%1362, %1363, %cst_937) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_938 = arith.constant 1.5707963267948966 : f64
    %1365 = qlx.apply #qlx.action<pauli_rotation>(%1364#1, %cst_938) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1366 = qlx.apply #qlx.action<h>(%1365) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_939 = arith.constant 1.5707963267948966 : f64
    %1367 = qlx.apply #qlx.action<pauli_rotation>(%1357#1, %cst_939) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1368 = qlx.apply #qlx.action<h>(%1367) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_940 = arith.constant 0.78539816339744828 : f64
    %1369:2 = qlx.apply #qlx.action<pauli_rotation>(%1366, %1368, %cst_940) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_941 = arith.constant 1.5707963267948966 : f64
    %1370 = qlx.apply #qlx.action<pauli_rotation>(%1364#0, %cst_941) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1371 = qlx.apply #qlx.action<h>(%1369#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_942 = arith.constant 1.5707963267948966 : f64
    %1372:2 = qlx.apply #qlx.action<pauli_rotation>(%1370, %1371, %cst_942) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_943 = arith.constant 1.5707963267948966 : f64
    %1373 = qlx.apply #qlx.action<pauli_rotation>(%1361#0, %cst_943) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_944 = arith.constant 1.5707963267948966 : f64
    %1374 = qlx.apply #qlx.action<pauli_rotation>(%1372#1, %cst_944) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_945 = arith.constant 1.5707963267948966 : f64
    %1375:2 = qlx.apply #qlx.action<pauli_rotation>(%1373, %1374, %cst_945) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_946 = arith.constant 1.5707963267948966 : f64
    %1376 = qlx.apply #qlx.action<pauli_rotation>(%1357#0, %cst_946) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1377 = qlx.apply #qlx.action<h>(%1369#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_947 = arith.constant 1.5707963267948966 : f64
    %1378:2 = qlx.apply #qlx.action<pauli_rotation>(%1376, %1377, %cst_947) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_948 = arith.constant 1.5707963267948966 : f64
    %1379 = qlx.apply #qlx.action<pauli_rotation>(%1378#0, %cst_948) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_949 = arith.constant 1.5707963267948966 : f64
    %1380:2 = qlx.apply #qlx.action<pauli_rotation>(%1378#1, %1379, %cst_949) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_950 = arith.constant 1.5707963267948966 : f64
    %1381 = qlx.apply #qlx.action<pauli_rotation>(%1375#0, %cst_950) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_951 = arith.constant 1.5707963267948966 : f64
    %1382 = qlx.apply #qlx.action<pauli_rotation>(%1375#1, %cst_951) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_952 = arith.constant 1.5707963267948966 : f64
    %1383:2 = qlx.apply #qlx.action<pauli_rotation>(%1381, %1382, %cst_952) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_953 = arith.constant 1.5707963267948966 : f64
    %1384 = qlx.apply #qlx.action<pauli_rotation>(%1372#0, %cst_953) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1385 = qlx.apply #qlx.action<h>(%1384) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_954 = arith.constant 1.5707963267948966 : f64
    %1386 = qlx.apply #qlx.action<pauli_rotation>(%1385, %cst_954) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1387 = qlx.apply #qlx.action<h>(%1386) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_955 = arith.constant 1.5707963267948966 : f64
    %1388 = qlx.apply #qlx.action<pauli_rotation>(%1383#1, %cst_955) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_956 = arith.constant 1.5707963267948966 : f64
    %1389:2 = qlx.apply #qlx.action<pauli_rotation>(%1387, %1388, %cst_956) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_957 = arith.constant 1.5707963267948966 : f64
    %1390 = qlx.apply #qlx.action<pauli_rotation>(%1389#1, %cst_957) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1391 = qlx.apply #qlx.action<h>(%1390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_958 = arith.constant 1.5707963267948966 : f64
    %1392 = qlx.apply #qlx.action<pauli_rotation>(%1380#0, %cst_958) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1393 = qlx.apply #qlx.action<h>(%1392) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_959 = arith.constant 0.78539816339744828 : f64
    %1394:2 = qlx.apply #qlx.action<pauli_rotation>(%1391, %1393, %cst_959) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_960 = arith.constant 1.5707963267948966 : f64
    %1395 = qlx.apply #qlx.action<pauli_rotation>(%1389#0, %cst_960) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1396 = qlx.apply #qlx.action<h>(%1394#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_961 = arith.constant 1.5707963267948966 : f64
    %1397:2 = qlx.apply #qlx.action<pauli_rotation>(%1395, %1396, %cst_961) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_962 = arith.constant 1.5707963267948966 : f64
    %1398 = qlx.apply #qlx.action<pauli_rotation>(%1383#0, %cst_962) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_963 = arith.constant 1.5707963267948966 : f64
    %1399 = qlx.apply #qlx.action<pauli_rotation>(%1397#1, %cst_963) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_964 = arith.constant 1.5707963267948966 : f64
    %1400:2 = qlx.apply #qlx.action<pauli_rotation>(%1398, %1399, %cst_964) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_965 = arith.constant 1.5707963267948966 : f64
    %1401 = qlx.apply #qlx.action<pauli_rotation>(%1380#1, %cst_965) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1402 = qlx.apply #qlx.action<h>(%1394#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_966 = arith.constant 1.5707963267948966 : f64
    %1403:2 = qlx.apply #qlx.action<pauli_rotation>(%1401, %1402, %cst_966) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_967 = arith.constant 1.5707963267948966 : f64
    %1404 = qlx.apply #qlx.action<pauli_rotation>(%1347#0, %cst_967) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1405 = qlx.apply #qlx.action<h>(%1404) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_968 = arith.constant 3.1415926535897931 : f64
    %1406 = qlx.apply #qlx.action<pauli_rotation>(%1405, %cst_968) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_969 = arith.constant 1.5707963267948966 : f64
    %1407 = qlx.apply #qlx.action<pauli_rotation>(%1397#0, %cst_969) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1408 = qlx.apply #qlx.action<h>(%1407) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_970 = arith.constant 1.5707963267948966 : f64
    %1409 = qlx.apply #qlx.action<pauli_rotation>(%1408, %cst_970) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1410 = qlx.apply #qlx.action<h>(%1409) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_971 = arith.constant 1.5707963267948966 : f64
    %1411:2 = qlx.apply #qlx.action<pauli_rotation>(%1406, %1410, %cst_971) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_972 = arith.constant 1.5707963267948966 : f64
    %1412 = qlx.apply #qlx.action<pauli_rotation>(%1400#0, %cst_972) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1413 = qlx.apply #qlx.action<h>(%1412) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_973 = arith.constant 1.5707963267948966 : f64
    %1414 = qlx.apply #qlx.action<pauli_rotation>(%1400#1, %cst_973) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_974 = arith.constant 1.5707963267948966 : f64
    %1415:2 = qlx.apply #qlx.action<pauli_rotation>(%1413, %1414, %cst_974) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_975 = arith.constant 1.5707963267948966 : f64
    %1416 = qlx.apply #qlx.action<pauli_rotation>(%1085#1, %cst_975) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1417 = qlx.apply #qlx.action<h>(%1416) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_976 = arith.constant 1.5707963267948966 : f64
    %1418 = qlx.apply #qlx.action<pauli_rotation>(%1415#1, %cst_976) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_977 = arith.constant 1.5707963267948966 : f64
    %1419:2 = qlx.apply #qlx.action<pauli_rotation>(%1417, %1418, %cst_977) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_978 = arith.constant 1.5707963267948966 : f64
    %1420 = qlx.apply #qlx.action<pauli_rotation>(%1419#1, %cst_978) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1421 = qlx.apply #qlx.action<h>(%1420) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_979 = arith.constant 1.5707963267948966 : f64
    %1422 = qlx.apply #qlx.action<pauli_rotation>(%1411#1, %cst_979) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1423 = qlx.apply #qlx.action<h>(%1422) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_980 = arith.constant 0.78539816339744828 : f64
    %1424:2 = qlx.apply #qlx.action<pauli_rotation>(%1421, %1423, %cst_980) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_981 = arith.constant 1.5707963267948966 : f64
    %1425 = qlx.apply #qlx.action<pauli_rotation>(%1419#0, %cst_981) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1426 = qlx.apply #qlx.action<h>(%1424#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_982 = arith.constant 1.5707963267948966 : f64
    %1427:2 = qlx.apply #qlx.action<pauli_rotation>(%1425, %1426, %cst_982) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_983 = arith.constant 1.5707963267948966 : f64
    %1428 = qlx.apply #qlx.action<pauli_rotation>(%1415#0, %cst_983) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_984 = arith.constant 1.5707963267948966 : f64
    %1429 = qlx.apply #qlx.action<pauli_rotation>(%1427#1, %cst_984) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_985 = arith.constant 1.5707963267948966 : f64
    %1430:2 = qlx.apply #qlx.action<pauli_rotation>(%1428, %1429, %cst_985) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_986 = arith.constant 1.5707963267948966 : f64
    %1431 = qlx.apply #qlx.action<pauli_rotation>(%1411#0, %cst_986) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1432 = qlx.apply #qlx.action<h>(%1424#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_987 = arith.constant 1.5707963267948966 : f64
    %1433:2 = qlx.apply #qlx.action<pauli_rotation>(%1431, %1432, %cst_987) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_988 = arith.constant 1.5707963267948966 : f64
    %1434 = qlx.apply #qlx.action<pauli_rotation>(%1433#0, %cst_988) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_989 = arith.constant 1.5707963267948966 : f64
    %1435 = qlx.apply #qlx.action<pauli_rotation>(%1433#1, %cst_989) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_990 = arith.constant 1.5707963267948966 : f64
    %1436:2 = qlx.apply #qlx.action<pauli_rotation>(%1434, %1435, %cst_990) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_991 = arith.constant 1.5707963267948966 : f64
    %1437 = qlx.apply #qlx.action<pauli_rotation>(%1430#0, %cst_991) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1438 = qlx.apply #qlx.action<h>(%1437) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_992 = arith.constant 1.5707963267948966 : f64
    %1439 = qlx.apply #qlx.action<pauli_rotation>(%1438, %cst_992) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1440 = qlx.apply #qlx.action<h>(%1439) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_993 = arith.constant 1.5707963267948966 : f64
    %1441 = qlx.apply #qlx.action<pauli_rotation>(%1430#1, %cst_993) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_994 = arith.constant 1.5707963267948966 : f64
    %1442:2 = qlx.apply #qlx.action<pauli_rotation>(%1440, %1441, %cst_994) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_995 = arith.constant 1.5707963267948966 : f64
    %1443 = qlx.apply #qlx.action<pauli_rotation>(%1427#0, %cst_995) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1444 = qlx.apply #qlx.action<h>(%1443) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_996 = arith.constant 1.5707963267948966 : f64
    %1445 = qlx.apply #qlx.action<pauli_rotation>(%1444, %cst_996) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1446 = qlx.apply #qlx.action<h>(%1445) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_997 = arith.constant 1.5707963267948966 : f64
    %1447 = qlx.apply #qlx.action<pauli_rotation>(%1442#1, %cst_997) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_998 = arith.constant 1.5707963267948966 : f64
    %1448:2 = qlx.apply #qlx.action<pauli_rotation>(%1446, %1447, %cst_998) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_999 = arith.constant 1.5707963267948966 : f64
    %1449 = qlx.apply #qlx.action<pauli_rotation>(%1448#1, %cst_999) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1450 = qlx.apply #qlx.action<h>(%1449) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1000 = arith.constant 1.5707963267948966 : f64
    %1451 = qlx.apply #qlx.action<pauli_rotation>(%1436#1, %cst_1000) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1452 = qlx.apply #qlx.action<h>(%1451) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1001 = arith.constant 0.78539816339744828 : f64
    %1453:2 = qlx.apply #qlx.action<pauli_rotation>(%1450, %1452, %cst_1001) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1002 = arith.constant 1.5707963267948966 : f64
    %1454 = qlx.apply #qlx.action<pauli_rotation>(%1448#0, %cst_1002) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1455 = qlx.apply #qlx.action<h>(%1453#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1003 = arith.constant 1.5707963267948966 : f64
    %1456:2 = qlx.apply #qlx.action<pauli_rotation>(%1454, %1455, %cst_1003) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1004 = arith.constant 1.5707963267948966 : f64
    %1457 = qlx.apply #qlx.action<pauli_rotation>(%1442#0, %cst_1004) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1005 = arith.constant 1.5707963267948966 : f64
    %1458 = qlx.apply #qlx.action<pauli_rotation>(%1456#1, %cst_1005) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1006 = arith.constant 1.5707963267948966 : f64
    %1459:2 = qlx.apply #qlx.action<pauli_rotation>(%1457, %1458, %cst_1006) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1007 = arith.constant 1.5707963267948966 : f64
    %1460 = qlx.apply #qlx.action<pauli_rotation>(%1436#0, %cst_1007) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1461 = qlx.apply #qlx.action<h>(%1453#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1008 = arith.constant 1.5707963267948966 : f64
    %1462:2 = qlx.apply #qlx.action<pauli_rotation>(%1460, %1461, %cst_1008) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1009 = arith.constant 1.5707963267948966 : f64
    %1463 = qlx.apply #qlx.action<pauli_rotation>(%1462#1, %cst_1009) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1010 = arith.constant 1.5707963267948966 : f64
    %1464 = qlx.apply #qlx.action<pauli_rotation>(%1459#1, %cst_1010) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1011 = arith.constant 1.5707963267948966 : f64
    %1465:2 = qlx.apply #qlx.action<pauli_rotation>(%1463, %1464, %cst_1011) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1012 = arith.constant 1.5707963267948966 : f64
    %1466 = qlx.apply #qlx.action<pauli_rotation>(%1465#1, %cst_1012) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1467 = qlx.apply #qlx.action<h>(%1466) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1013 = arith.constant 1.5707963267948966 : f64
    %1468 = qlx.apply #qlx.action<pauli_rotation>(%1459#0, %cst_1013) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1469 = qlx.apply #qlx.action<h>(%1468) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1014 = arith.constant 1.5707963267948966 : f64
    %1470 = qlx.apply #qlx.action<pauli_rotation>(%1469, %cst_1014) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1471 = qlx.apply #qlx.action<h>(%1470) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1015 = arith.constant 5.000000e-01 : f64
    %1472:2 = qlx.apply #qlx.action<pauli_rotation>(%1467, %1471, %cst_1015) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1016 = arith.constant 1.5707963267948966 : f64
    %1473 = qlx.apply #qlx.action<pauli_rotation>(%1465#0, %cst_1016) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1474 = qlx.apply #qlx.action<h>(%1472#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1017 = arith.constant 1.5707963267948966 : f64
    %1475:2 = qlx.apply #qlx.action<pauli_rotation>(%1473, %1474, %cst_1017) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1018 = arith.constant 1.5707963267948966 : f64
    %1476 = qlx.apply #qlx.action<pauli_rotation>(%1475#0, %cst_1018) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1477 = qlx.apply #qlx.action<h>(%1476) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1019 = arith.constant 1.5707963267948966 : f64
    %1478 = qlx.apply #qlx.action<pauli_rotation>(%1477, %cst_1019) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1479 = qlx.apply #qlx.action<h>(%1478) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1020 = arith.constant 1.5707963267948966 : f64
    %1480 = qlx.apply #qlx.action<pauli_rotation>(%1475#1, %cst_1020) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1021 = arith.constant 1.5707963267948966 : f64
    %1481:2 = qlx.apply #qlx.action<pauli_rotation>(%1479, %1480, %cst_1021) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1022 = arith.constant 1.5707963267948966 : f64
    %1482 = qlx.apply #qlx.action<pauli_rotation>(%1481#1, %cst_1022) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1483 = qlx.apply #qlx.action<h>(%1482) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1484 = qlx.apply #qlx.action<h>(%1472#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1023 = arith.constant 1.5707963267948966 : f64
    %1485 = qlx.apply #qlx.action<pauli_rotation>(%1484, %cst_1023) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1486 = qlx.apply #qlx.action<h>(%1485) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1024 = arith.constant 5.000000e-01 : f64
    %1487:2 = qlx.apply #qlx.action<pauli_rotation>(%1483, %1486, %cst_1024) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1025 = arith.constant 1.5707963267948966 : f64
    %1488 = qlx.apply #qlx.action<pauli_rotation>(%1481#0, %cst_1025) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1489 = qlx.apply #qlx.action<h>(%1487#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1026 = arith.constant 1.5707963267948966 : f64
    %1490:2 = qlx.apply #qlx.action<pauli_rotation>(%1488, %1489, %cst_1026) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1027 = arith.constant 1.5707963267948966 : f64
    %1491 = qlx.apply #qlx.action<pauli_rotation>(%1403#0, %cst_1027) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1028 = arith.constant 1.5707963267948966 : f64
    %1492:2 = qlx.apply #qlx.action<pauli_rotation>(%1403#1, %1491, %cst_1028) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1493 = qlx.apply #qlx.action<h>(%1487#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1029 = arith.constant 1.5707963267948966 : f64
    %1494 = qlx.apply #qlx.action<pauli_rotation>(%1493, %cst_1029) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1030 = arith.constant 1.5707963267948966 : f64
    %1495 = qlx.apply #qlx.action<pauli_rotation>(%1490#1, %cst_1030) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1031 = arith.constant 1.5707963267948966 : f64
    %1496:2 = qlx.apply #qlx.action<pauli_rotation>(%1494, %1495, %cst_1031) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1032 = arith.constant 1.5707963267948966 : f64
    %1497 = qlx.apply #qlx.action<pauli_rotation>(%1490#0, %cst_1032) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1498 = qlx.apply #qlx.action<h>(%1497) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1033 = arith.constant 1.5707963267948966 : f64
    %1499 = qlx.apply #qlx.action<pauli_rotation>(%1498, %cst_1033) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1500 = qlx.apply #qlx.action<h>(%1499) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1034 = arith.constant 1.5707963267948966 : f64
    %1501 = qlx.apply #qlx.action<pauli_rotation>(%1496#1, %cst_1034) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1035 = arith.constant 1.5707963267948966 : f64
    %1502:2 = qlx.apply #qlx.action<pauli_rotation>(%1500, %1501, %cst_1035) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1036 = arith.constant 1.5707963267948966 : f64
    %1503 = qlx.apply #qlx.action<pauli_rotation>(%1502#1, %cst_1036) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1504 = qlx.apply #qlx.action<h>(%1503) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1037 = arith.constant 1.5707963267948966 : f64
    %1505 = qlx.apply #qlx.action<pauli_rotation>(%1492#0, %cst_1037) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1506 = qlx.apply #qlx.action<h>(%1505) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1038 = arith.constant 0.78539816339744828 : f64
    %1507:2 = qlx.apply #qlx.action<pauli_rotation>(%1504, %1506, %cst_1038) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1039 = arith.constant 1.5707963267948966 : f64
    %1508 = qlx.apply #qlx.action<pauli_rotation>(%1502#0, %cst_1039) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1509 = qlx.apply #qlx.action<h>(%1507#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1040 = arith.constant 1.5707963267948966 : f64
    %1510:2 = qlx.apply #qlx.action<pauli_rotation>(%1508, %1509, %cst_1040) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1041 = arith.constant 1.5707963267948966 : f64
    %1511 = qlx.apply #qlx.action<pauli_rotation>(%1496#0, %cst_1041) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1042 = arith.constant 1.5707963267948966 : f64
    %1512 = qlx.apply #qlx.action<pauli_rotation>(%1510#1, %cst_1042) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1043 = arith.constant 1.5707963267948966 : f64
    %1513:2 = qlx.apply #qlx.action<pauli_rotation>(%1511, %1512, %cst_1043) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1044 = arith.constant 1.5707963267948966 : f64
    %1514 = qlx.apply #qlx.action<pauli_rotation>(%1492#1, %cst_1044) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1515 = qlx.apply #qlx.action<h>(%1507#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1045 = arith.constant 1.5707963267948966 : f64
    %1516:2 = qlx.apply #qlx.action<pauli_rotation>(%1514, %1515, %cst_1045) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1046 = arith.constant 1.5707963267948966 : f64
    %1517 = qlx.apply #qlx.action<pauli_rotation>(%1516#0, %cst_1046) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1047 = arith.constant 1.5707963267948966 : f64
    %1518:2 = qlx.apply #qlx.action<pauli_rotation>(%1516#1, %1517, %cst_1047) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1048 = arith.constant 1.5707963267948966 : f64
    %1519 = qlx.apply #qlx.action<pauli_rotation>(%1513#0, %cst_1048) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1049 = arith.constant 1.5707963267948966 : f64
    %1520 = qlx.apply #qlx.action<pauli_rotation>(%1513#1, %cst_1049) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1050 = arith.constant 1.5707963267948966 : f64
    %1521:2 = qlx.apply #qlx.action<pauli_rotation>(%1519, %1520, %cst_1050) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1051 = arith.constant 1.5707963267948966 : f64
    %1522 = qlx.apply #qlx.action<pauli_rotation>(%1510#0, %cst_1051) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1523 = qlx.apply #qlx.action<h>(%1522) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1052 = arith.constant 1.5707963267948966 : f64
    %1524 = qlx.apply #qlx.action<pauli_rotation>(%1523, %cst_1052) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1525 = qlx.apply #qlx.action<h>(%1524) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1053 = arith.constant 1.5707963267948966 : f64
    %1526 = qlx.apply #qlx.action<pauli_rotation>(%1521#1, %cst_1053) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1054 = arith.constant 1.5707963267948966 : f64
    %1527:2 = qlx.apply #qlx.action<pauli_rotation>(%1525, %1526, %cst_1054) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1055 = arith.constant 1.5707963267948966 : f64
    %1528 = qlx.apply #qlx.action<pauli_rotation>(%1527#1, %cst_1055) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1529 = qlx.apply #qlx.action<h>(%1528) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1056 = arith.constant 1.5707963267948966 : f64
    %1530 = qlx.apply #qlx.action<pauli_rotation>(%1518#0, %cst_1056) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1531 = qlx.apply #qlx.action<h>(%1530) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1057 = arith.constant 0.78539816339744828 : f64
    %1532:2 = qlx.apply #qlx.action<pauli_rotation>(%1529, %1531, %cst_1057) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1058 = arith.constant 1.5707963267948966 : f64
    %1533 = qlx.apply #qlx.action<pauli_rotation>(%1527#0, %cst_1058) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1534 = qlx.apply #qlx.action<h>(%1532#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1059 = arith.constant 1.5707963267948966 : f64
    %1535:2 = qlx.apply #qlx.action<pauli_rotation>(%1533, %1534, %cst_1059) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1060 = arith.constant 1.5707963267948966 : f64
    %1536 = qlx.apply #qlx.action<pauli_rotation>(%1521#0, %cst_1060) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1061 = arith.constant 1.5707963267948966 : f64
    %1537 = qlx.apply #qlx.action<pauli_rotation>(%1535#1, %cst_1061) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1062 = arith.constant 1.5707963267948966 : f64
    %1538:2 = qlx.apply #qlx.action<pauli_rotation>(%1536, %1537, %cst_1062) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1063 = arith.constant 1.5707963267948966 : f64
    %1539 = qlx.apply #qlx.action<pauli_rotation>(%1518#1, %cst_1063) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1540 = qlx.apply #qlx.action<h>(%1532#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1064 = arith.constant 1.5707963267948966 : f64
    %1541:2 = qlx.apply #qlx.action<pauli_rotation>(%1539, %1540, %cst_1064) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1065 = arith.constant 1.5707963267948966 : f64
    %1542 = qlx.apply #qlx.action<pauli_rotation>(%1462#0, %cst_1065) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1066 = arith.constant 1.5707963267948966 : f64
    %1543 = qlx.apply #qlx.action<pauli_rotation>(%1535#0, %cst_1066) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1544 = qlx.apply #qlx.action<h>(%1543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1067 = arith.constant 1.5707963267948966 : f64
    %1545 = qlx.apply #qlx.action<pauli_rotation>(%1544, %cst_1067) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1546 = qlx.apply #qlx.action<h>(%1545) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1068 = arith.constant 1.5707963267948966 : f64
    %1547:2 = qlx.apply #qlx.action<pauli_rotation>(%1542, %1546, %cst_1068) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1069 = arith.constant 1.5707963267948966 : f64
    %1548 = qlx.apply #qlx.action<pauli_rotation>(%1538#0, %cst_1069) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1549 = qlx.apply #qlx.action<h>(%1548) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1070 = arith.constant 1.5707963267948966 : f64
    %1550 = qlx.apply #qlx.action<pauli_rotation>(%1538#1, %cst_1070) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1071 = arith.constant 1.5707963267948966 : f64
    %1551:2 = qlx.apply #qlx.action<pauli_rotation>(%1549, %1550, %cst_1071) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1072 = arith.constant 1.5707963267948966 : f64
    %1552 = qlx.apply #qlx.action<pauli_rotation>(%1456#0, %cst_1072) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1553 = qlx.apply #qlx.action<h>(%1552) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1073 = arith.constant 1.5707963267948966 : f64
    %1554 = qlx.apply #qlx.action<pauli_rotation>(%1553, %cst_1073) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1555 = qlx.apply #qlx.action<h>(%1554) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1074 = arith.constant 1.5707963267948966 : f64
    %1556 = qlx.apply #qlx.action<pauli_rotation>(%1551#1, %cst_1074) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1075 = arith.constant 1.5707963267948966 : f64
    %1557:2 = qlx.apply #qlx.action<pauli_rotation>(%1555, %1556, %cst_1075) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1076 = arith.constant 1.5707963267948966 : f64
    %1558 = qlx.apply #qlx.action<pauli_rotation>(%1557#1, %cst_1076) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1559 = qlx.apply #qlx.action<h>(%1558) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1077 = arith.constant 1.5707963267948966 : f64
    %1560 = qlx.apply #qlx.action<pauli_rotation>(%1547#1, %cst_1077) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1561 = qlx.apply #qlx.action<h>(%1560) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1078 = arith.constant 0.78539816339744828 : f64
    %1562:2 = qlx.apply #qlx.action<pauli_rotation>(%1559, %1561, %cst_1078) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1079 = arith.constant 1.5707963267948966 : f64
    %1563 = qlx.apply #qlx.action<pauli_rotation>(%1557#0, %cst_1079) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1564 = qlx.apply #qlx.action<h>(%1562#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1080 = arith.constant 1.5707963267948966 : f64
    %1565:2 = qlx.apply #qlx.action<pauli_rotation>(%1563, %1564, %cst_1080) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1081 = arith.constant 1.5707963267948966 : f64
    %1566 = qlx.apply #qlx.action<pauli_rotation>(%1551#0, %cst_1081) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1082 = arith.constant 1.5707963267948966 : f64
    %1567 = qlx.apply #qlx.action<pauli_rotation>(%1565#1, %cst_1082) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1083 = arith.constant 1.5707963267948966 : f64
    %1568:2 = qlx.apply #qlx.action<pauli_rotation>(%1566, %1567, %cst_1083) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1084 = arith.constant 1.5707963267948966 : f64
    %1569 = qlx.apply #qlx.action<pauli_rotation>(%1547#0, %cst_1084) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1570 = qlx.apply #qlx.action<h>(%1562#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1085 = arith.constant 1.5707963267948966 : f64
    %1571:2 = qlx.apply #qlx.action<pauli_rotation>(%1569, %1570, %cst_1085) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1086 = arith.constant 1.5707963267948966 : f64
    %1572 = qlx.apply #qlx.action<pauli_rotation>(%1571#0, %cst_1086) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1087 = arith.constant 1.5707963267948966 : f64
    %1573 = qlx.apply #qlx.action<pauli_rotation>(%1571#1, %cst_1087) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1088 = arith.constant 1.5707963267948966 : f64
    %1574:2 = qlx.apply #qlx.action<pauli_rotation>(%1572, %1573, %cst_1088) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1089 = arith.constant 1.5707963267948966 : f64
    %1575 = qlx.apply #qlx.action<pauli_rotation>(%1568#0, %cst_1089) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1576 = qlx.apply #qlx.action<h>(%1575) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1090 = arith.constant 1.5707963267948966 : f64
    %1577 = qlx.apply #qlx.action<pauli_rotation>(%1576, %cst_1090) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1578 = qlx.apply #qlx.action<h>(%1577) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1091 = arith.constant 1.5707963267948966 : f64
    %1579 = qlx.apply #qlx.action<pauli_rotation>(%1568#1, %cst_1091) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1092 = arith.constant 1.5707963267948966 : f64
    %1580:2 = qlx.apply #qlx.action<pauli_rotation>(%1578, %1579, %cst_1092) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1093 = arith.constant 1.5707963267948966 : f64
    %1581 = qlx.apply #qlx.action<pauli_rotation>(%1565#0, %cst_1093) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1582 = qlx.apply #qlx.action<h>(%1581) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1094 = arith.constant 1.5707963267948966 : f64
    %1583 = qlx.apply #qlx.action<pauli_rotation>(%1582, %cst_1094) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1584 = qlx.apply #qlx.action<h>(%1583) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1095 = arith.constant 1.5707963267948966 : f64
    %1585 = qlx.apply #qlx.action<pauli_rotation>(%1580#1, %cst_1095) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1096 = arith.constant 1.5707963267948966 : f64
    %1586:2 = qlx.apply #qlx.action<pauli_rotation>(%1584, %1585, %cst_1096) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1097 = arith.constant 1.5707963267948966 : f64
    %1587 = qlx.apply #qlx.action<pauli_rotation>(%1586#1, %cst_1097) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1588 = qlx.apply #qlx.action<h>(%1587) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1098 = arith.constant 1.5707963267948966 : f64
    %1589 = qlx.apply #qlx.action<pauli_rotation>(%1574#1, %cst_1098) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1590 = qlx.apply #qlx.action<h>(%1589) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1099 = arith.constant 0.78539816339744828 : f64
    %1591:2 = qlx.apply #qlx.action<pauli_rotation>(%1588, %1590, %cst_1099) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1100 = arith.constant 1.5707963267948966 : f64
    %1592 = qlx.apply #qlx.action<pauli_rotation>(%1586#0, %cst_1100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1593 = qlx.apply #qlx.action<h>(%1591#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1101 = arith.constant 1.5707963267948966 : f64
    %1594:2 = qlx.apply #qlx.action<pauli_rotation>(%1592, %1593, %cst_1101) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1102 = arith.constant 1.5707963267948966 : f64
    %1595 = qlx.apply #qlx.action<pauli_rotation>(%1580#0, %cst_1102) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1103 = arith.constant 1.5707963267948966 : f64
    %1596 = qlx.apply #qlx.action<pauli_rotation>(%1594#1, %cst_1103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1104 = arith.constant 1.5707963267948966 : f64
    %1597:2 = qlx.apply #qlx.action<pauli_rotation>(%1595, %1596, %cst_1104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1105 = arith.constant 1.5707963267948966 : f64
    %1598 = qlx.apply #qlx.action<pauli_rotation>(%1574#0, %cst_1105) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1599 = qlx.apply #qlx.action<h>(%1591#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1106 = arith.constant 1.5707963267948966 : f64
    %1600:2 = qlx.apply #qlx.action<pauli_rotation>(%1598, %1599, %cst_1106) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1107 = arith.constant 1.5707963267948966 : f64
    %1601 = qlx.apply #qlx.action<pauli_rotation>(%1284#0, %cst_1107) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1602 = qlx.apply #qlx.action<h>(%1601) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1108 = arith.constant 3.1415926535897931 : f64
    %1603 = qlx.apply #qlx.action<pauli_rotation>(%1602, %cst_1108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1109 = arith.constant 1.5707963267948966 : f64
    %1604 = qlx.apply #qlx.action<pauli_rotation>(%1541#1, %cst_1109) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1110 = arith.constant 5.000000e-01 : f64
    %1605:2 = qlx.apply #qlx.action<pauli_rotation>(%1603, %1604, %cst_1110) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1111 = arith.constant 1.5707963267948966 : f64
    %1606 = qlx.apply #qlx.action<pauli_rotation>(%1541#0, %cst_1111) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1112 = arith.constant 1.5707963267948966 : f64
    %1607 = qlx.apply #qlx.action<pauli_rotation>(%1597#0, %cst_1112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1608 = qlx.apply #qlx.action<h>(%1607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1113 = arith.constant 1.5707963267948966 : f64
    %1609 = qlx.apply #qlx.action<pauli_rotation>(%1608, %cst_1113) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1114 = arith.constant 5.000000e-01 : f64
    %1610:2 = qlx.apply #qlx.action<pauli_rotation>(%1606, %1609, %cst_1114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1115 = arith.constant 1.5707963267948966 : f64
    %1611 = qlx.apply #qlx.action<pauli_rotation>(%1597#1, %cst_1115) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1612 = qlx.apply #qlx.action<h>(%1611) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1116 = arith.constant 1.5707963267948966 : f64
    %1613 = qlx.apply #qlx.action<pauli_rotation>(%1600#1, %cst_1116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1614 = qlx.apply #qlx.action<h>(%1613) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1117 = arith.constant 5.000000e-01 : f64
    %1615:2 = qlx.apply #qlx.action<pauli_rotation>(%1612, %1614, %cst_1117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1118 = arith.constant 1.5707963267948966 : f64
    %1616 = qlx.apply #qlx.action<pauli_rotation>(%1600#0, %cst_1118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1119 = arith.constant 1.5707963267948966 : f64
    %1617 = qlx.apply #qlx.action<pauli_rotation>(%1594#0, %cst_1119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1618 = qlx.apply #qlx.action<h>(%1617) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1120 = arith.constant 3.1415926535897931 : f64
    %1619 = qlx.apply #qlx.action<pauli_rotation>(%1618, %cst_1120) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1121 = arith.constant 5.000000e-01 : f64
    %1620:2 = qlx.apply #qlx.action<pauli_rotation>(%1616, %1619, %cst_1121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1621 = qlx.apply #qlx.action<h>(%1610#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1122 = arith.constant 1.5707963267948966 : f64
    %1622:2 = qlx.apply #qlx.action<pauli_rotation>(%1610#1, %1621, %cst_1122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1123 = arith.constant 1.5707963267948966 : f64
    %1623 = qlx.apply #qlx.action<pauli_rotation>(%1605#0, %cst_1123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1624 = qlx.apply #qlx.action<h>(%1623) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1625 = qlx.apply #qlx.action<h>(%1605#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1124 = arith.constant 1.5707963267948966 : f64
    %1626:2 = qlx.apply #qlx.action<pauli_rotation>(%1624, %1625, %cst_1124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1627 = qlx.apply #qlx.action<h>(%1615#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1125 = arith.constant 1.5707963267948966 : f64
    %1628 = qlx.apply #qlx.action<pauli_rotation>(%1626#1, %cst_1125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1126 = arith.constant 1.5707963267948966 : f64
    %1629:2 = qlx.apply #qlx.action<pauli_rotation>(%1627, %1628, %cst_1126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1127 = arith.constant 1.5707963267948966 : f64
    %1630 = qlx.apply #qlx.action<pauli_rotation>(%1629#1, %cst_1127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1631 = qlx.apply #qlx.action<h>(%1630) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1128 = arith.constant 1.5707963267948966 : f64
    %1632 = qlx.apply #qlx.action<pauli_rotation>(%1622#1, %cst_1128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1633 = qlx.apply #qlx.action<h>(%1632) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1129 = arith.constant 0.78539816339744828 : f64
    %1634:2 = qlx.apply #qlx.action<pauli_rotation>(%1631, %1633, %cst_1129) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1130 = arith.constant 1.5707963267948966 : f64
    %1635 = qlx.apply #qlx.action<pauli_rotation>(%1629#0, %cst_1130) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1636 = qlx.apply #qlx.action<h>(%1634#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1131 = arith.constant 1.5707963267948966 : f64
    %1637:2 = qlx.apply #qlx.action<pauli_rotation>(%1635, %1636, %cst_1131) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1132 = arith.constant 1.5707963267948966 : f64
    %1638 = qlx.apply #qlx.action<pauli_rotation>(%1626#0, %cst_1132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1133 = arith.constant 1.5707963267948966 : f64
    %1639 = qlx.apply #qlx.action<pauli_rotation>(%1637#1, %cst_1133) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1134 = arith.constant 1.5707963267948966 : f64
    %1640:2 = qlx.apply #qlx.action<pauli_rotation>(%1638, %1639, %cst_1134) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1135 = arith.constant 1.5707963267948966 : f64
    %1641 = qlx.apply #qlx.action<pauli_rotation>(%1622#0, %cst_1135) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1642 = qlx.apply #qlx.action<h>(%1634#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1136 = arith.constant 1.5707963267948966 : f64
    %1643:2 = qlx.apply #qlx.action<pauli_rotation>(%1641, %1642, %cst_1136) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1137 = arith.constant 1.5707963267948966 : f64
    %1644 = qlx.apply #qlx.action<pauli_rotation>(%1643#0, %cst_1137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1138 = arith.constant 1.5707963267948966 : f64
    %1645 = qlx.apply #qlx.action<pauli_rotation>(%1643#1, %cst_1138) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1139 = arith.constant 1.5707963267948966 : f64
    %1646:2 = qlx.apply #qlx.action<pauli_rotation>(%1644, %1645, %cst_1139) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1140 = arith.constant 1.5707963267948966 : f64
    %1647 = qlx.apply #qlx.action<pauli_rotation>(%1640#0, %cst_1140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1648 = qlx.apply #qlx.action<h>(%1647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1141 = arith.constant 1.5707963267948966 : f64
    %1649 = qlx.apply #qlx.action<pauli_rotation>(%1648, %cst_1141) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1650 = qlx.apply #qlx.action<h>(%1649) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1142 = arith.constant 1.5707963267948966 : f64
    %1651 = qlx.apply #qlx.action<pauli_rotation>(%1640#1, %cst_1142) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1143 = arith.constant 1.5707963267948966 : f64
    %1652:2 = qlx.apply #qlx.action<pauli_rotation>(%1650, %1651, %cst_1143) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1144 = arith.constant 1.5707963267948966 : f64
    %1653 = qlx.apply #qlx.action<pauli_rotation>(%1637#0, %cst_1144) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1654 = qlx.apply #qlx.action<h>(%1653) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1145 = arith.constant 1.5707963267948966 : f64
    %1655 = qlx.apply #qlx.action<pauli_rotation>(%1654, %cst_1145) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1656 = qlx.apply #qlx.action<h>(%1655) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1146 = arith.constant 1.5707963267948966 : f64
    %1657 = qlx.apply #qlx.action<pauli_rotation>(%1652#1, %cst_1146) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1147 = arith.constant 1.5707963267948966 : f64
    %1658:2 = qlx.apply #qlx.action<pauli_rotation>(%1656, %1657, %cst_1147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1148 = arith.constant 1.5707963267948966 : f64
    %1659 = qlx.apply #qlx.action<pauli_rotation>(%1658#1, %cst_1148) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1660 = qlx.apply #qlx.action<h>(%1659) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1149 = arith.constant 1.5707963267948966 : f64
    %1661 = qlx.apply #qlx.action<pauli_rotation>(%1646#1, %cst_1149) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1662 = qlx.apply #qlx.action<h>(%1661) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1150 = arith.constant 0.78539816339744828 : f64
    %1663:2 = qlx.apply #qlx.action<pauli_rotation>(%1660, %1662, %cst_1150) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1151 = arith.constant 1.5707963267948966 : f64
    %1664 = qlx.apply #qlx.action<pauli_rotation>(%1658#0, %cst_1151) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1665 = qlx.apply #qlx.action<h>(%1663#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1152 = arith.constant 1.5707963267948966 : f64
    %1666:2 = qlx.apply #qlx.action<pauli_rotation>(%1664, %1665, %cst_1152) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1153 = arith.constant 1.5707963267948966 : f64
    %1667 = qlx.apply #qlx.action<pauli_rotation>(%1652#0, %cst_1153) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1154 = arith.constant 1.5707963267948966 : f64
    %1668 = qlx.apply #qlx.action<pauli_rotation>(%1666#1, %cst_1154) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1155 = arith.constant 1.5707963267948966 : f64
    %1669:2 = qlx.apply #qlx.action<pauli_rotation>(%1667, %1668, %cst_1155) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1156 = arith.constant 1.5707963267948966 : f64
    %1670 = qlx.apply #qlx.action<pauli_rotation>(%1646#0, %cst_1156) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1671 = qlx.apply #qlx.action<h>(%1663#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1157 = arith.constant 1.5707963267948966 : f64
    %1672:2 = qlx.apply #qlx.action<pauli_rotation>(%1670, %1671, %cst_1157) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1158 = arith.constant 1.5707963267948966 : f64
    %1673 = qlx.apply #qlx.action<pauli_rotation>(%1672#1, %cst_1158) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1159 = arith.constant 1.5707963267948966 : f64
    %1674 = qlx.apply #qlx.action<pauli_rotation>(%1672#0, %cst_1159) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1675 = qlx.apply #qlx.action<h>(%1674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1160 = arith.constant 1.5707963267948966 : f64
    %1676:2 = qlx.apply #qlx.action<pauli_rotation>(%1673, %1675, %cst_1160) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1161 = arith.constant 1.5707963267948966 : f64
    %1677 = qlx.apply #qlx.action<pauli_rotation>(%1620#0, %cst_1161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1678 = qlx.apply #qlx.action<h>(%1677) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1679 = qlx.apply #qlx.action<h>(%1615#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1162 = arith.constant 1.5707963267948966 : f64
    %1680:2 = qlx.apply #qlx.action<pauli_rotation>(%1678, %1679, %cst_1162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1163 = arith.constant 1.5707963267948966 : f64
    %1681 = qlx.apply #qlx.action<pauli_rotation>(%1680#1, %cst_1163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1682 = qlx.apply #qlx.action<h>(%1681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1164 = arith.constant 1.5707963267948966 : f64
    %1683 = qlx.apply #qlx.action<pauli_rotation>(%1666#0, %cst_1164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1684 = qlx.apply #qlx.action<h>(%1683) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1165 = arith.constant 1.5707963267948966 : f64
    %1685 = qlx.apply #qlx.action<pauli_rotation>(%1684, %cst_1165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1686 = qlx.apply #qlx.action<h>(%1685) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1166 = arith.constant 1.5707963267948966 : f64
    %1687:2 = qlx.apply #qlx.action<pauli_rotation>(%1682, %1686, %cst_1166) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1167 = arith.constant 1.5707963267948966 : f64
    %1688 = qlx.apply #qlx.action<pauli_rotation>(%1687#1, %cst_1167) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1689 = qlx.apply #qlx.action<h>(%1688) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1168 = arith.constant 1.5707963267948966 : f64
    %1690 = qlx.apply #qlx.action<pauli_rotation>(%1676#1, %cst_1168) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1691 = qlx.apply #qlx.action<h>(%1690) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1169 = arith.constant 0.78539816339744828 : f64
    %1692:2 = qlx.apply #qlx.action<pauli_rotation>(%1689, %1691, %cst_1169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1170 = arith.constant 1.5707963267948966 : f64
    %1693 = qlx.apply #qlx.action<pauli_rotation>(%1687#0, %cst_1170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1694 = qlx.apply #qlx.action<h>(%1692#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1171 = arith.constant 1.5707963267948966 : f64
    %1695:2 = qlx.apply #qlx.action<pauli_rotation>(%1693, %1694, %cst_1171) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1172 = arith.constant 1.5707963267948966 : f64
    %1696 = qlx.apply #qlx.action<pauli_rotation>(%1680#0, %cst_1172) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1173 = arith.constant 1.5707963267948966 : f64
    %1697 = qlx.apply #qlx.action<pauli_rotation>(%1695#0, %cst_1173) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1698 = qlx.apply #qlx.action<h>(%1697) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1174 = arith.constant 1.5707963267948966 : f64
    %1699:2 = qlx.apply #qlx.action<pauli_rotation>(%1696, %1698, %cst_1174) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1175 = arith.constant 1.5707963267948966 : f64
    %1700 = qlx.apply #qlx.action<pauli_rotation>(%1676#0, %cst_1175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1701 = qlx.apply #qlx.action<h>(%1692#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1176 = arith.constant 1.5707963267948966 : f64
    %1702:2 = qlx.apply #qlx.action<pauli_rotation>(%1700, %1701, %cst_1176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1177 = arith.constant 1.5707963267948966 : f64
    %1703 = qlx.apply #qlx.action<pauli_rotation>(%1702#0, %cst_1177) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1704 = qlx.apply #qlx.action<h>(%1703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1178 = arith.constant 1.5707963267948966 : f64
    %1705 = qlx.apply #qlx.action<pauli_rotation>(%1704, %cst_1178) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1706 = qlx.apply #qlx.action<h>(%1705) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1179 = arith.constant 1.5707963267948966 : f64
    %1707 = qlx.apply #qlx.action<pauli_rotation>(%1702#1, %cst_1179) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1180 = arith.constant 1.5707963267948966 : f64
    %1708:2 = qlx.apply #qlx.action<pauli_rotation>(%1706, %1707, %cst_1180) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1181 = arith.constant 1.5707963267948966 : f64
    %1709 = qlx.apply #qlx.action<pauli_rotation>(%1699#0, %cst_1181) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1710 = qlx.apply #qlx.action<h>(%1709) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1182 = arith.constant 1.5707963267948966 : f64
    %1711 = qlx.apply #qlx.action<pauli_rotation>(%1710, %cst_1182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1712 = qlx.apply #qlx.action<h>(%1711) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1183 = arith.constant 1.5707963267948966 : f64
    %1713 = qlx.apply #qlx.action<pauli_rotation>(%1699#1, %cst_1183) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1184 = arith.constant 1.5707963267948966 : f64
    %1714:2 = qlx.apply #qlx.action<pauli_rotation>(%1712, %1713, %cst_1184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1185 = arith.constant 1.5707963267948966 : f64
    %1715 = qlx.apply #qlx.action<pauli_rotation>(%1714#1, %cst_1185) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1716 = qlx.apply #qlx.action<h>(%1715) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1186 = arith.constant 1.5707963267948966 : f64
    %1717 = qlx.apply #qlx.action<pauli_rotation>(%1695#1, %cst_1186) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1187 = arith.constant 1.5707963267948966 : f64
    %1718:2 = qlx.apply #qlx.action<pauli_rotation>(%1716, %1717, %cst_1187) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1188 = arith.constant 1.5707963267948966 : f64
    %1719 = qlx.apply #qlx.action<pauli_rotation>(%1718#1, %cst_1188) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1720 = qlx.apply #qlx.action<h>(%1719) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1189 = arith.constant 1.5707963267948966 : f64
    %1721 = qlx.apply #qlx.action<pauli_rotation>(%1708#1, %cst_1189) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1722 = qlx.apply #qlx.action<h>(%1721) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1190 = arith.constant 0.78539816339744828 : f64
    %1723:2 = qlx.apply #qlx.action<pauli_rotation>(%1720, %1722, %cst_1190) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1191 = arith.constant 1.5707963267948966 : f64
    %1724 = qlx.apply #qlx.action<pauli_rotation>(%1718#0, %cst_1191) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1725 = qlx.apply #qlx.action<h>(%1723#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1192 = arith.constant 1.5707963267948966 : f64
    %1726:2 = qlx.apply #qlx.action<pauli_rotation>(%1724, %1725, %cst_1192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1193 = arith.constant 1.5707963267948966 : f64
    %1727 = qlx.apply #qlx.action<pauli_rotation>(%1714#0, %cst_1193) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1194 = arith.constant 1.5707963267948966 : f64
    %1728 = qlx.apply #qlx.action<pauli_rotation>(%1726#0, %cst_1194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1729 = qlx.apply #qlx.action<h>(%1728) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1195 = arith.constant 1.5707963267948966 : f64
    %1730:2 = qlx.apply #qlx.action<pauli_rotation>(%1727, %1729, %cst_1195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1196 = arith.constant 1.5707963267948966 : f64
    %1731 = qlx.apply #qlx.action<pauli_rotation>(%1708#0, %cst_1196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1732 = qlx.apply #qlx.action<h>(%1723#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1197 = arith.constant 1.5707963267948966 : f64
    %1733:2 = qlx.apply #qlx.action<pauli_rotation>(%1731, %1732, %cst_1197) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1198 = arith.constant 1.5707963267948966 : f64
    %1734 = qlx.apply #qlx.action<pauli_rotation>(%1726#1, %cst_1198) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1199 = arith.constant 1.5707963267948966 : f64
    %1735 = qlx.apply #qlx.action<pauli_rotation>(%1733#1, %cst_1199) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1200 = arith.constant 1.5707963267948966 : f64
    %1736:2 = qlx.apply #qlx.action<pauli_rotation>(%1734, %1735, %cst_1200) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1201 = arith.constant 1.5707963267948966 : f64
    %1737 = qlx.apply #qlx.action<pauli_rotation>(%1736#1, %cst_1201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1738 = qlx.apply #qlx.action<h>(%1737) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1202 = arith.constant 1.5707963267948966 : f64
    %1739 = qlx.apply #qlx.action<pauli_rotation>(%1733#0, %cst_1202) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1740 = qlx.apply #qlx.action<h>(%1739) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1203 = arith.constant 1.5707963267948966 : f64
    %1741 = qlx.apply #qlx.action<pauli_rotation>(%1740, %cst_1203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1742 = qlx.apply #qlx.action<h>(%1741) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1204 = arith.constant 5.000000e-01 : f64
    %1743:2 = qlx.apply #qlx.action<pauli_rotation>(%1738, %1742, %cst_1204) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1205 = arith.constant 1.5707963267948966 : f64
    %1744 = qlx.apply #qlx.action<pauli_rotation>(%1736#0, %cst_1205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1745 = qlx.apply #qlx.action<h>(%1743#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1206 = arith.constant 1.5707963267948966 : f64
    %1746:2 = qlx.apply #qlx.action<pauli_rotation>(%1744, %1745, %cst_1206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1207 = arith.constant 1.5707963267948966 : f64
    %1747 = qlx.apply #qlx.action<pauli_rotation>(%1746#0, %cst_1207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1748 = qlx.apply #qlx.action<h>(%1747) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1208 = arith.constant 1.5707963267948966 : f64
    %1749 = qlx.apply #qlx.action<pauli_rotation>(%1748, %cst_1208) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1750 = qlx.apply #qlx.action<h>(%1749) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1209 = arith.constant 1.5707963267948966 : f64
    %1751 = qlx.apply #qlx.action<pauli_rotation>(%1746#1, %cst_1209) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1210 = arith.constant 1.5707963267948966 : f64
    %1752:2 = qlx.apply #qlx.action<pauli_rotation>(%1750, %1751, %cst_1210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1211 = arith.constant 1.5707963267948966 : f64
    %1753 = qlx.apply #qlx.action<pauli_rotation>(%1752#1, %cst_1211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1754 = qlx.apply #qlx.action<h>(%1753) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1755 = qlx.apply #qlx.action<h>(%1743#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1212 = arith.constant 1.5707963267948966 : f64
    %1756 = qlx.apply #qlx.action<pauli_rotation>(%1755, %cst_1212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1757 = qlx.apply #qlx.action<h>(%1756) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1213 = arith.constant 5.000000e-01 : f64
    %1758:2 = qlx.apply #qlx.action<pauli_rotation>(%1754, %1757, %cst_1213) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1214 = arith.constant 1.5707963267948966 : f64
    %1759 = qlx.apply #qlx.action<pauli_rotation>(%1752#0, %cst_1214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1760 = qlx.apply #qlx.action<h>(%1758#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1215 = arith.constant 1.5707963267948966 : f64
    %1761:2 = qlx.apply #qlx.action<pauli_rotation>(%1759, %1760, %cst_1215) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1216 = arith.constant 1.5707963267948966 : f64
    %1762 = qlx.apply #qlx.action<pauli_rotation>(%1761#1, %cst_1216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1763 = qlx.apply #qlx.action<h>(%1762) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1764 = qlx.apply #qlx.action<h>(%1758#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1217 = arith.constant 1.5707963267948966 : f64
    %1765 = qlx.apply #qlx.action<pauli_rotation>(%1764, %cst_1217) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1766 = qlx.apply #qlx.action<h>(%1765) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1218 = arith.constant 1.5707963267948966 : f64
    %1767:2 = qlx.apply #qlx.action<pauli_rotation>(%1763, %1766, %cst_1218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1219 = arith.constant 1.5707963267948966 : f64
    %1768 = qlx.apply #qlx.action<pauli_rotation>(%1669#0, %cst_1219) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1769 = qlx.apply #qlx.action<h>(%1768) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1220 = arith.constant 1.5707963267948966 : f64
    %1770 = qlx.apply #qlx.action<pauli_rotation>(%1769, %cst_1220) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1771 = qlx.apply #qlx.action<h>(%1770) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1221 = arith.constant 1.5707963267948966 : f64
    %1772 = qlx.apply #qlx.action<pauli_rotation>(%1669#1, %cst_1221) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1222 = arith.constant 1.5707963267948966 : f64
    %1773:2 = qlx.apply #qlx.action<pauli_rotation>(%1771, %1772, %cst_1222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1223 = arith.constant 1.5707963267948966 : f64
    %1774 = qlx.apply #qlx.action<pauli_rotation>(%1761#0, %cst_1223) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1775 = qlx.apply #qlx.action<h>(%1774) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1224 = arith.constant 1.5707963267948966 : f64
    %1776 = qlx.apply #qlx.action<pauli_rotation>(%1775, %cst_1224) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1777 = qlx.apply #qlx.action<h>(%1776) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1225 = arith.constant 1.5707963267948966 : f64
    %1778 = qlx.apply #qlx.action<pauli_rotation>(%1773#1, %cst_1225) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1226 = arith.constant 1.5707963267948966 : f64
    %1779:2 = qlx.apply #qlx.action<pauli_rotation>(%1777, %1778, %cst_1226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1227 = arith.constant 1.5707963267948966 : f64
    %1780 = qlx.apply #qlx.action<pauli_rotation>(%1779#1, %cst_1227) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1781 = qlx.apply #qlx.action<h>(%1780) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1228 = arith.constant 1.5707963267948966 : f64
    %1782 = qlx.apply #qlx.action<pauli_rotation>(%1767#1, %cst_1228) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1783 = qlx.apply #qlx.action<h>(%1782) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1229 = arith.constant 0.78539816339744828 : f64
    %1784:2 = qlx.apply #qlx.action<pauli_rotation>(%1781, %1783, %cst_1229) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1230 = arith.constant 1.5707963267948966 : f64
    %1785 = qlx.apply #qlx.action<pauli_rotation>(%1779#0, %cst_1230) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1786 = qlx.apply #qlx.action<h>(%1784#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1231 = arith.constant 1.5707963267948966 : f64
    %1787:2 = qlx.apply #qlx.action<pauli_rotation>(%1785, %1786, %cst_1231) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1232 = arith.constant 1.5707963267948966 : f64
    %1788 = qlx.apply #qlx.action<pauli_rotation>(%1773#0, %cst_1232) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1233 = arith.constant 1.5707963267948966 : f64
    %1789 = qlx.apply #qlx.action<pauli_rotation>(%1787#1, %cst_1233) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1234 = arith.constant 1.5707963267948966 : f64
    %1790:2 = qlx.apply #qlx.action<pauli_rotation>(%1788, %1789, %cst_1234) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1235 = arith.constant 1.5707963267948966 : f64
    %1791 = qlx.apply #qlx.action<pauli_rotation>(%1767#0, %cst_1235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1792 = qlx.apply #qlx.action<h>(%1784#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1236 = arith.constant 1.5707963267948966 : f64
    %1793:2 = qlx.apply #qlx.action<pauli_rotation>(%1791, %1792, %cst_1236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1237 = arith.constant 1.5707963267948966 : f64
    %1794 = qlx.apply #qlx.action<pauli_rotation>(%1793#0, %cst_1237) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1238 = arith.constant 1.5707963267948966 : f64
    %1795 = qlx.apply #qlx.action<pauli_rotation>(%1793#1, %cst_1238) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1239 = arith.constant 1.5707963267948966 : f64
    %1796:2 = qlx.apply #qlx.action<pauli_rotation>(%1794, %1795, %cst_1239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1240 = arith.constant 1.5707963267948966 : f64
    %1797 = qlx.apply #qlx.action<pauli_rotation>(%1790#0, %cst_1240) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1798 = qlx.apply #qlx.action<h>(%1797) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1241 = arith.constant 1.5707963267948966 : f64
    %1799 = qlx.apply #qlx.action<pauli_rotation>(%1798, %cst_1241) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1800 = qlx.apply #qlx.action<h>(%1799) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1242 = arith.constant 1.5707963267948966 : f64
    %1801 = qlx.apply #qlx.action<pauli_rotation>(%1790#1, %cst_1242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1243 = arith.constant 1.5707963267948966 : f64
    %1802:2 = qlx.apply #qlx.action<pauli_rotation>(%1800, %1801, %cst_1243) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1244 = arith.constant 1.5707963267948966 : f64
    %1803 = qlx.apply #qlx.action<pauli_rotation>(%1787#0, %cst_1244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1804 = qlx.apply #qlx.action<h>(%1803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1245 = arith.constant 1.5707963267948966 : f64
    %1805 = qlx.apply #qlx.action<pauli_rotation>(%1804, %cst_1245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1806 = qlx.apply #qlx.action<h>(%1805) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1246 = arith.constant 1.5707963267948966 : f64
    %1807 = qlx.apply #qlx.action<pauli_rotation>(%1802#1, %cst_1246) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1247 = arith.constant 1.5707963267948966 : f64
    %1808:2 = qlx.apply #qlx.action<pauli_rotation>(%1806, %1807, %cst_1247) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1248 = arith.constant 1.5707963267948966 : f64
    %1809 = qlx.apply #qlx.action<pauli_rotation>(%1808#1, %cst_1248) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1810 = qlx.apply #qlx.action<h>(%1809) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1249 = arith.constant 1.5707963267948966 : f64
    %1811 = qlx.apply #qlx.action<pauli_rotation>(%1796#1, %cst_1249) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1812 = qlx.apply #qlx.action<h>(%1811) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1250 = arith.constant 0.78539816339744828 : f64
    %1813:2 = qlx.apply #qlx.action<pauli_rotation>(%1810, %1812, %cst_1250) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1251 = arith.constant 1.5707963267948966 : f64
    %1814 = qlx.apply #qlx.action<pauli_rotation>(%1808#0, %cst_1251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1815 = qlx.apply #qlx.action<h>(%1813#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1252 = arith.constant 1.5707963267948966 : f64
    %1816:2 = qlx.apply #qlx.action<pauli_rotation>(%1814, %1815, %cst_1252) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1253 = arith.constant 1.5707963267948966 : f64
    %1817 = qlx.apply #qlx.action<pauli_rotation>(%1802#0, %cst_1253) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1254 = arith.constant 1.5707963267948966 : f64
    %1818 = qlx.apply #qlx.action<pauli_rotation>(%1816#1, %cst_1254) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1255 = arith.constant 1.5707963267948966 : f64
    %1819:2 = qlx.apply #qlx.action<pauli_rotation>(%1817, %1818, %cst_1255) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1256 = arith.constant 1.5707963267948966 : f64
    %1820 = qlx.apply #qlx.action<pauli_rotation>(%1796#0, %cst_1256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1821 = qlx.apply #qlx.action<h>(%1813#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1257 = arith.constant 1.5707963267948966 : f64
    %1822:2 = qlx.apply #qlx.action<pauli_rotation>(%1820, %1821, %cst_1257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1258 = arith.constant 1.5707963267948966 : f64
    %1823 = qlx.apply #qlx.action<pauli_rotation>(%1822#1, %cst_1258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1259 = arith.constant 1.5707963267948966 : f64
    %1824 = qlx.apply #qlx.action<pauli_rotation>(%1822#0, %cst_1259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1825 = qlx.apply #qlx.action<h>(%1824) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1260 = arith.constant 1.5707963267948966 : f64
    %1826:2 = qlx.apply #qlx.action<pauli_rotation>(%1823, %1825, %cst_1260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1261 = arith.constant 1.5707963267948966 : f64
    %1827 = qlx.apply #qlx.action<pauli_rotation>(%1730#0, %cst_1261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1828 = qlx.apply #qlx.action<h>(%1827) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1262 = arith.constant 1.5707963267948966 : f64
    %1829 = qlx.apply #qlx.action<pauli_rotation>(%1828, %cst_1262) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1830 = qlx.apply #qlx.action<h>(%1829) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1263 = arith.constant 1.5707963267948966 : f64
    %1831 = qlx.apply #qlx.action<pauli_rotation>(%1730#1, %cst_1263) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1264 = arith.constant 1.5707963267948966 : f64
    %1832:2 = qlx.apply #qlx.action<pauli_rotation>(%1830, %1831, %cst_1264) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1265 = arith.constant 1.5707963267948966 : f64
    %1833 = qlx.apply #qlx.action<pauli_rotation>(%1832#1, %cst_1265) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1834 = qlx.apply #qlx.action<h>(%1833) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1266 = arith.constant 1.5707963267948966 : f64
    %1835 = qlx.apply #qlx.action<pauli_rotation>(%1816#0, %cst_1266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1836 = qlx.apply #qlx.action<h>(%1835) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1267 = arith.constant 1.5707963267948966 : f64
    %1837 = qlx.apply #qlx.action<pauli_rotation>(%1836, %cst_1267) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1838 = qlx.apply #qlx.action<h>(%1837) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1268 = arith.constant 1.5707963267948966 : f64
    %1839:2 = qlx.apply #qlx.action<pauli_rotation>(%1834, %1838, %cst_1268) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1269 = arith.constant 1.5707963267948966 : f64
    %1840 = qlx.apply #qlx.action<pauli_rotation>(%1839#1, %cst_1269) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1841 = qlx.apply #qlx.action<h>(%1840) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1270 = arith.constant 1.5707963267948966 : f64
    %1842 = qlx.apply #qlx.action<pauli_rotation>(%1826#1, %cst_1270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1843 = qlx.apply #qlx.action<h>(%1842) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1271 = arith.constant 0.78539816339744828 : f64
    %1844:2 = qlx.apply #qlx.action<pauli_rotation>(%1841, %1843, %cst_1271) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1272 = arith.constant 1.5707963267948966 : f64
    %1845 = qlx.apply #qlx.action<pauli_rotation>(%1839#0, %cst_1272) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1846 = qlx.apply #qlx.action<h>(%1844#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1273 = arith.constant 1.5707963267948966 : f64
    %1847:2 = qlx.apply #qlx.action<pauli_rotation>(%1845, %1846, %cst_1273) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1274 = arith.constant 1.5707963267948966 : f64
    %1848 = qlx.apply #qlx.action<pauli_rotation>(%1832#0, %cst_1274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1275 = arith.constant 1.5707963267948966 : f64
    %1849 = qlx.apply #qlx.action<pauli_rotation>(%1847#0, %cst_1275) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1850 = qlx.apply #qlx.action<h>(%1849) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1276 = arith.constant 1.5707963267948966 : f64
    %1851:2 = qlx.apply #qlx.action<pauli_rotation>(%1848, %1850, %cst_1276) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1277 = arith.constant 1.5707963267948966 : f64
    %1852 = qlx.apply #qlx.action<pauli_rotation>(%1826#0, %cst_1277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1853 = qlx.apply #qlx.action<h>(%1844#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1278 = arith.constant 1.5707963267948966 : f64
    %1854:2 = qlx.apply #qlx.action<pauli_rotation>(%1852, %1853, %cst_1278) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1279 = arith.constant 1.5707963267948966 : f64
    %1855 = qlx.apply #qlx.action<pauli_rotation>(%1854#0, %cst_1279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1856 = qlx.apply #qlx.action<h>(%1855) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1280 = arith.constant 1.5707963267948966 : f64
    %1857 = qlx.apply #qlx.action<pauli_rotation>(%1856, %cst_1280) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1858 = qlx.apply #qlx.action<h>(%1857) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1281 = arith.constant 1.5707963267948966 : f64
    %1859 = qlx.apply #qlx.action<pauli_rotation>(%1854#1, %cst_1281) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1282 = arith.constant 1.5707963267948966 : f64
    %1860:2 = qlx.apply #qlx.action<pauli_rotation>(%1858, %1859, %cst_1282) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1283 = arith.constant 1.5707963267948966 : f64
    %1861 = qlx.apply #qlx.action<pauli_rotation>(%1851#0, %cst_1283) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1862 = qlx.apply #qlx.action<h>(%1861) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1284 = arith.constant 1.5707963267948966 : f64
    %1863 = qlx.apply #qlx.action<pauli_rotation>(%1862, %cst_1284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1864 = qlx.apply #qlx.action<h>(%1863) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1285 = arith.constant 1.5707963267948966 : f64
    %1865 = qlx.apply #qlx.action<pauli_rotation>(%1851#1, %cst_1285) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1286 = arith.constant 1.5707963267948966 : f64
    %1866:2 = qlx.apply #qlx.action<pauli_rotation>(%1864, %1865, %cst_1286) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1287 = arith.constant 1.5707963267948966 : f64
    %1867 = qlx.apply #qlx.action<pauli_rotation>(%1866#1, %cst_1287) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1868 = qlx.apply #qlx.action<h>(%1867) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1288 = arith.constant 1.5707963267948966 : f64
    %1869 = qlx.apply #qlx.action<pauli_rotation>(%1847#1, %cst_1288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1289 = arith.constant 1.5707963267948966 : f64
    %1870:2 = qlx.apply #qlx.action<pauli_rotation>(%1868, %1869, %cst_1289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1290 = arith.constant 1.5707963267948966 : f64
    %1871 = qlx.apply #qlx.action<pauli_rotation>(%1870#1, %cst_1290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1872 = qlx.apply #qlx.action<h>(%1871) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1291 = arith.constant 1.5707963267948966 : f64
    %1873 = qlx.apply #qlx.action<pauli_rotation>(%1860#1, %cst_1291) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1874 = qlx.apply #qlx.action<h>(%1873) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1292 = arith.constant 0.78539816339744828 : f64
    %1875:2 = qlx.apply #qlx.action<pauli_rotation>(%1872, %1874, %cst_1292) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1293 = arith.constant 1.5707963267948966 : f64
    %1876 = qlx.apply #qlx.action<pauli_rotation>(%1870#0, %cst_1293) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1877 = qlx.apply #qlx.action<h>(%1875#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1294 = arith.constant 1.5707963267948966 : f64
    %1878:2 = qlx.apply #qlx.action<pauli_rotation>(%1876, %1877, %cst_1294) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1295 = arith.constant 1.5707963267948966 : f64
    %1879 = qlx.apply #qlx.action<pauli_rotation>(%1866#0, %cst_1295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1296 = arith.constant 1.5707963267948966 : f64
    %1880 = qlx.apply #qlx.action<pauli_rotation>(%1878#0, %cst_1296) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1881 = qlx.apply #qlx.action<h>(%1880) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1297 = arith.constant 1.5707963267948966 : f64
    %1882:2 = qlx.apply #qlx.action<pauli_rotation>(%1879, %1881, %cst_1297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1298 = arith.constant 1.5707963267948966 : f64
    %1883 = qlx.apply #qlx.action<pauli_rotation>(%1860#0, %cst_1298) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1884 = qlx.apply #qlx.action<h>(%1875#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1299 = arith.constant 1.5707963267948966 : f64
    %1885:2 = qlx.apply #qlx.action<pauli_rotation>(%1883, %1884, %cst_1299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1300 = arith.constant 1.5707963267948966 : f64
    %1886 = qlx.apply #qlx.action<pauli_rotation>(%1885#0, %cst_1300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1887 = qlx.apply #qlx.action<h>(%1886) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1301 = arith.constant 1.5707963267948966 : f64
    %1888 = qlx.apply #qlx.action<pauli_rotation>(%1887, %cst_1301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1302 = arith.constant 1.5707963267948966 : f64
    %1889 = qlx.apply #qlx.action<pauli_rotation>(%1819#1, %cst_1302) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1890 = qlx.apply #qlx.action<h>(%1889) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1303 = arith.constant 1.5707963267948966 : f64
    %1891 = qlx.apply #qlx.action<pauli_rotation>(%1890, %cst_1303) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1304 = arith.constant 1.5707963267948966 : f64
    %1892:2 = qlx.apply #qlx.action<pauli_rotation>(%1888, %1891, %cst_1304) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1305 = arith.constant 1.5707963267948966 : f64
    %1893 = qlx.apply #qlx.action<pauli_rotation>(%1885#1, %cst_1305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1894 = qlx.apply #qlx.action<h>(%1893) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1306 = arith.constant 1.5707963267948966 : f64
    %1895 = qlx.apply #qlx.action<pauli_rotation>(%1878#1, %cst_1306) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1307 = arith.constant 1.5707963267948966 : f64
    %1896:2 = qlx.apply #qlx.action<pauli_rotation>(%1894, %1895, %cst_1307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1308 = arith.constant 1.5707963267948966 : f64
    %1897 = qlx.apply #qlx.action<pauli_rotation>(%1882#1, %cst_1308) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1309 = arith.constant 1.5707963267948966 : f64
    %1898 = qlx.apply #qlx.action<pauli_rotation>(%1896#1, %cst_1309) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1310 = arith.constant 1.5707963267948966 : f64
    %1899:2 = qlx.apply #qlx.action<pauli_rotation>(%1897, %1898, %cst_1310) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1311 = arith.constant 1.5707963267948966 : f64
    %1900 = qlx.apply #qlx.action<pauli_rotation>(%1899#1, %cst_1311) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1901 = qlx.apply #qlx.action<h>(%1900) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1312 = arith.constant 1.5707963267948966 : f64
    %1902 = qlx.apply #qlx.action<pauli_rotation>(%1892#1, %cst_1312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1903 = qlx.apply #qlx.action<h>(%1902) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1313 = arith.constant 0.78539816339744828 : f64
    %1904:2 = qlx.apply #qlx.action<pauli_rotation>(%1901, %1903, %cst_1313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1314 = arith.constant 1.5707963267948966 : f64
    %1905 = qlx.apply #qlx.action<pauli_rotation>(%1899#0, %cst_1314) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1906 = qlx.apply #qlx.action<h>(%1904#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1315 = arith.constant 1.5707963267948966 : f64
    %1907:2 = qlx.apply #qlx.action<pauli_rotation>(%1905, %1906, %cst_1315) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1316 = arith.constant 1.5707963267948966 : f64
    %1908 = qlx.apply #qlx.action<pauli_rotation>(%1896#0, %cst_1316) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1317 = arith.constant 1.5707963267948966 : f64
    %1909 = qlx.apply #qlx.action<pauli_rotation>(%1907#1, %cst_1317) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1318 = arith.constant 1.5707963267948966 : f64
    %1910:2 = qlx.apply #qlx.action<pauli_rotation>(%1908, %1909, %cst_1318) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1319 = arith.constant 1.5707963267948966 : f64
    %1911 = qlx.apply #qlx.action<pauli_rotation>(%1892#0, %cst_1319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1912 = qlx.apply #qlx.action<h>(%1904#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1320 = arith.constant 1.5707963267948966 : f64
    %1913:2 = qlx.apply #qlx.action<pauli_rotation>(%1911, %1912, %cst_1320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1321 = arith.constant 1.5707963267948966 : f64
    %1914 = qlx.apply #qlx.action<pauli_rotation>(%1913#0, %cst_1321) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1322 = arith.constant 1.5707963267948966 : f64
    %1915:2 = qlx.apply #qlx.action<pauli_rotation>(%1913#1, %1914, %cst_1322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1323 = arith.constant 1.5707963267948966 : f64
    %1916 = qlx.apply #qlx.action<pauli_rotation>(%1910#0, %cst_1323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1324 = arith.constant 1.5707963267948966 : f64
    %1917 = qlx.apply #qlx.action<pauli_rotation>(%1910#1, %cst_1324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1325 = arith.constant 1.5707963267948966 : f64
    %1918:2 = qlx.apply #qlx.action<pauli_rotation>(%1916, %1917, %cst_1325) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1326 = arith.constant 1.5707963267948966 : f64
    %1919 = qlx.apply #qlx.action<pauli_rotation>(%1907#0, %cst_1326) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1920 = qlx.apply #qlx.action<h>(%1919) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1327 = arith.constant 1.5707963267948966 : f64
    %1921 = qlx.apply #qlx.action<pauli_rotation>(%1920, %cst_1327) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1922 = qlx.apply #qlx.action<h>(%1921) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1328 = arith.constant 1.5707963267948966 : f64
    %1923 = qlx.apply #qlx.action<pauli_rotation>(%1918#1, %cst_1328) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1329 = arith.constant 1.5707963267948966 : f64
    %1924:2 = qlx.apply #qlx.action<pauli_rotation>(%1922, %1923, %cst_1329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1330 = arith.constant 1.5707963267948966 : f64
    %1925 = qlx.apply #qlx.action<pauli_rotation>(%1924#1, %cst_1330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1926 = qlx.apply #qlx.action<h>(%1925) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1331 = arith.constant 1.5707963267948966 : f64
    %1927 = qlx.apply #qlx.action<pauli_rotation>(%1915#0, %cst_1331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1928 = qlx.apply #qlx.action<h>(%1927) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1332 = arith.constant 0.78539816339744828 : f64
    %1929:2 = qlx.apply #qlx.action<pauli_rotation>(%1926, %1928, %cst_1332) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1333 = arith.constant 1.5707963267948966 : f64
    %1930 = qlx.apply #qlx.action<pauli_rotation>(%1924#0, %cst_1333) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1931 = qlx.apply #qlx.action<h>(%1929#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1334 = arith.constant 1.5707963267948966 : f64
    %1932:2 = qlx.apply #qlx.action<pauli_rotation>(%1930, %1931, %cst_1334) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1335 = arith.constant 1.5707963267948966 : f64
    %1933 = qlx.apply #qlx.action<pauli_rotation>(%1918#0, %cst_1335) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1336 = arith.constant 1.5707963267948966 : f64
    %1934 = qlx.apply #qlx.action<pauli_rotation>(%1932#1, %cst_1336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1337 = arith.constant 1.5707963267948966 : f64
    %1935:2 = qlx.apply #qlx.action<pauli_rotation>(%1933, %1934, %cst_1337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1338 = arith.constant 1.5707963267948966 : f64
    %1936 = qlx.apply #qlx.action<pauli_rotation>(%1915#1, %cst_1338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1937 = qlx.apply #qlx.action<h>(%1929#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1339 = arith.constant 1.5707963267948966 : f64
    %1938:2 = qlx.apply #qlx.action<pauli_rotation>(%1936, %1937, %cst_1339) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1340 = arith.constant 1.5707963267948966 : f64
    %1939 = qlx.apply #qlx.action<pauli_rotation>(%1882#0, %cst_1340) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1940 = qlx.apply #qlx.action<h>(%1939) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1341 = arith.constant 3.1415926535897931 : f64
    %1941 = qlx.apply #qlx.action<pauli_rotation>(%1940, %cst_1341) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1342 = arith.constant 1.5707963267948966 : f64
    %1942 = qlx.apply #qlx.action<pauli_rotation>(%1932#0, %cst_1342) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1943 = qlx.apply #qlx.action<h>(%1942) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1343 = arith.constant 1.5707963267948966 : f64
    %1944 = qlx.apply #qlx.action<pauli_rotation>(%1943, %cst_1343) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1945 = qlx.apply #qlx.action<h>(%1944) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1344 = arith.constant 1.5707963267948966 : f64
    %1946:2 = qlx.apply #qlx.action<pauli_rotation>(%1941, %1945, %cst_1344) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1345 = arith.constant 1.5707963267948966 : f64
    %1947 = qlx.apply #qlx.action<pauli_rotation>(%1935#0, %cst_1345) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1948 = qlx.apply #qlx.action<h>(%1947) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1346 = arith.constant 1.5707963267948966 : f64
    %1949 = qlx.apply #qlx.action<pauli_rotation>(%1935#1, %cst_1346) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1347 = arith.constant 1.5707963267948966 : f64
    %1950:2 = qlx.apply #qlx.action<pauli_rotation>(%1948, %1949, %cst_1347) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1348 = arith.constant 1.5707963267948966 : f64
    %1951 = qlx.apply #qlx.action<pauli_rotation>(%1620#1, %cst_1348) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1952 = qlx.apply #qlx.action<h>(%1951) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1349 = arith.constant 1.5707963267948966 : f64
    %1953 = qlx.apply #qlx.action<pauli_rotation>(%1950#1, %cst_1349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1350 = arith.constant 1.5707963267948966 : f64
    %1954:2 = qlx.apply #qlx.action<pauli_rotation>(%1952, %1953, %cst_1350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1351 = arith.constant 1.5707963267948966 : f64
    %1955 = qlx.apply #qlx.action<pauli_rotation>(%1954#1, %cst_1351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1956 = qlx.apply #qlx.action<h>(%1955) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1352 = arith.constant 1.5707963267948966 : f64
    %1957 = qlx.apply #qlx.action<pauli_rotation>(%1946#1, %cst_1352) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1958 = qlx.apply #qlx.action<h>(%1957) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1353 = arith.constant 0.78539816339744828 : f64
    %1959:2 = qlx.apply #qlx.action<pauli_rotation>(%1956, %1958, %cst_1353) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1354 = arith.constant 1.5707963267948966 : f64
    %1960 = qlx.apply #qlx.action<pauli_rotation>(%1954#0, %cst_1354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1961 = qlx.apply #qlx.action<h>(%1959#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1355 = arith.constant 1.5707963267948966 : f64
    %1962:2 = qlx.apply #qlx.action<pauli_rotation>(%1960, %1961, %cst_1355) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1356 = arith.constant 1.5707963267948966 : f64
    %1963 = qlx.apply #qlx.action<pauli_rotation>(%1950#0, %cst_1356) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1357 = arith.constant 1.5707963267948966 : f64
    %1964 = qlx.apply #qlx.action<pauli_rotation>(%1962#1, %cst_1357) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1358 = arith.constant 1.5707963267948966 : f64
    %1965:2 = qlx.apply #qlx.action<pauli_rotation>(%1963, %1964, %cst_1358) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1359 = arith.constant 1.5707963267948966 : f64
    %1966 = qlx.apply #qlx.action<pauli_rotation>(%1946#0, %cst_1359) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1967 = qlx.apply #qlx.action<h>(%1959#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1360 = arith.constant 1.5707963267948966 : f64
    %1968:2 = qlx.apply #qlx.action<pauli_rotation>(%1966, %1967, %cst_1360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1361 = arith.constant 1.5707963267948966 : f64
    %1969 = qlx.apply #qlx.action<pauli_rotation>(%1968#0, %cst_1361) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1362 = arith.constant 1.5707963267948966 : f64
    %1970 = qlx.apply #qlx.action<pauli_rotation>(%1968#1, %cst_1362) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1363 = arith.constant 1.5707963267948966 : f64
    %1971:2 = qlx.apply #qlx.action<pauli_rotation>(%1969, %1970, %cst_1363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1364 = arith.constant 1.5707963267948966 : f64
    %1972 = qlx.apply #qlx.action<pauli_rotation>(%1965#0, %cst_1364) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1973 = qlx.apply #qlx.action<h>(%1972) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1365 = arith.constant 1.5707963267948966 : f64
    %1974 = qlx.apply #qlx.action<pauli_rotation>(%1973, %cst_1365) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1975 = qlx.apply #qlx.action<h>(%1974) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1366 = arith.constant 1.5707963267948966 : f64
    %1976 = qlx.apply #qlx.action<pauli_rotation>(%1965#1, %cst_1366) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1367 = arith.constant 1.5707963267948966 : f64
    %1977:2 = qlx.apply #qlx.action<pauli_rotation>(%1975, %1976, %cst_1367) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1368 = arith.constant 1.5707963267948966 : f64
    %1978 = qlx.apply #qlx.action<pauli_rotation>(%1962#0, %cst_1368) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1979 = qlx.apply #qlx.action<h>(%1978) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1369 = arith.constant 1.5707963267948966 : f64
    %1980 = qlx.apply #qlx.action<pauli_rotation>(%1979, %cst_1369) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1981 = qlx.apply #qlx.action<h>(%1980) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1370 = arith.constant 1.5707963267948966 : f64
    %1982 = qlx.apply #qlx.action<pauli_rotation>(%1977#1, %cst_1370) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1371 = arith.constant 1.5707963267948966 : f64
    %1983:2 = qlx.apply #qlx.action<pauli_rotation>(%1981, %1982, %cst_1371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1372 = arith.constant 1.5707963267948966 : f64
    %1984 = qlx.apply #qlx.action<pauli_rotation>(%1983#1, %cst_1372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1985 = qlx.apply #qlx.action<h>(%1984) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1373 = arith.constant 1.5707963267948966 : f64
    %1986 = qlx.apply #qlx.action<pauli_rotation>(%1971#1, %cst_1373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1987 = qlx.apply #qlx.action<h>(%1986) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1374 = arith.constant 0.78539816339744828 : f64
    %1988:2 = qlx.apply #qlx.action<pauli_rotation>(%1985, %1987, %cst_1374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1375 = arith.constant 1.5707963267948966 : f64
    %1989 = qlx.apply #qlx.action<pauli_rotation>(%1983#0, %cst_1375) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1990 = qlx.apply #qlx.action<h>(%1988#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1376 = arith.constant 1.5707963267948966 : f64
    %1991:2 = qlx.apply #qlx.action<pauli_rotation>(%1989, %1990, %cst_1376) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1377 = arith.constant 1.5707963267948966 : f64
    %1992 = qlx.apply #qlx.action<pauli_rotation>(%1977#0, %cst_1377) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1378 = arith.constant 1.5707963267948966 : f64
    %1993 = qlx.apply #qlx.action<pauli_rotation>(%1991#1, %cst_1378) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1379 = arith.constant 1.5707963267948966 : f64
    %1994:2 = qlx.apply #qlx.action<pauli_rotation>(%1992, %1993, %cst_1379) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1380 = arith.constant 1.5707963267948966 : f64
    %1995 = qlx.apply #qlx.action<pauli_rotation>(%1971#0, %cst_1380) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1996 = qlx.apply #qlx.action<h>(%1988#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1381 = arith.constant 1.5707963267948966 : f64
    %1997:2 = qlx.apply #qlx.action<pauli_rotation>(%1995, %1996, %cst_1381) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1382 = arith.constant 1.5707963267948966 : f64
    %1998 = qlx.apply #qlx.action<pauli_rotation>(%1997#1, %cst_1382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1383 = arith.constant 1.5707963267948966 : f64
    %1999 = qlx.apply #qlx.action<pauli_rotation>(%1994#1, %cst_1383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1384 = arith.constant 1.5707963267948966 : f64
    %2000:2 = qlx.apply #qlx.action<pauli_rotation>(%1998, %1999, %cst_1384) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1385 = arith.constant 1.5707963267948966 : f64
    %2001 = qlx.apply #qlx.action<pauli_rotation>(%2000#1, %cst_1385) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2002 = qlx.apply #qlx.action<h>(%2001) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1386 = arith.constant 1.5707963267948966 : f64
    %2003 = qlx.apply #qlx.action<pauli_rotation>(%1994#0, %cst_1386) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2004 = qlx.apply #qlx.action<h>(%2003) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1387 = arith.constant 1.5707963267948966 : f64
    %2005 = qlx.apply #qlx.action<pauli_rotation>(%2004, %cst_1387) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2006 = qlx.apply #qlx.action<h>(%2005) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1388 = arith.constant 5.000000e-01 : f64
    %2007:2 = qlx.apply #qlx.action<pauli_rotation>(%2002, %2006, %cst_1388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1389 = arith.constant 1.5707963267948966 : f64
    %2008 = qlx.apply #qlx.action<pauli_rotation>(%2000#0, %cst_1389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2009 = qlx.apply #qlx.action<h>(%2007#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1390 = arith.constant 1.5707963267948966 : f64
    %2010:2 = qlx.apply #qlx.action<pauli_rotation>(%2008, %2009, %cst_1390) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1391 = arith.constant 1.5707963267948966 : f64
    %2011 = qlx.apply #qlx.action<pauli_rotation>(%2010#0, %cst_1391) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2012 = qlx.apply #qlx.action<h>(%2011) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1392 = arith.constant 1.5707963267948966 : f64
    %2013 = qlx.apply #qlx.action<pauli_rotation>(%2012, %cst_1392) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2014 = qlx.apply #qlx.action<h>(%2013) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1393 = arith.constant 1.5707963267948966 : f64
    %2015 = qlx.apply #qlx.action<pauli_rotation>(%2010#1, %cst_1393) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1394 = arith.constant 1.5707963267948966 : f64
    %2016:2 = qlx.apply #qlx.action<pauli_rotation>(%2014, %2015, %cst_1394) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1395 = arith.constant 1.5707963267948966 : f64
    %2017 = qlx.apply #qlx.action<pauli_rotation>(%2016#1, %cst_1395) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2018 = qlx.apply #qlx.action<h>(%2017) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2019 = qlx.apply #qlx.action<h>(%2007#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1396 = arith.constant 1.5707963267948966 : f64
    %2020 = qlx.apply #qlx.action<pauli_rotation>(%2019, %cst_1396) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2021 = qlx.apply #qlx.action<h>(%2020) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1397 = arith.constant 5.000000e-01 : f64
    %2022:2 = qlx.apply #qlx.action<pauli_rotation>(%2018, %2021, %cst_1397) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1398 = arith.constant 1.5707963267948966 : f64
    %2023 = qlx.apply #qlx.action<pauli_rotation>(%2016#0, %cst_1398) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2024 = qlx.apply #qlx.action<h>(%2022#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1399 = arith.constant 1.5707963267948966 : f64
    %2025:2 = qlx.apply #qlx.action<pauli_rotation>(%2023, %2024, %cst_1399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1400 = arith.constant 1.5707963267948966 : f64
    %2026 = qlx.apply #qlx.action<pauli_rotation>(%1938#0, %cst_1400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1401 = arith.constant 1.5707963267948966 : f64
    %2027:2 = qlx.apply #qlx.action<pauli_rotation>(%1938#1, %2026, %cst_1401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2028 = qlx.apply #qlx.action<h>(%2022#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1402 = arith.constant 1.5707963267948966 : f64
    %2029 = qlx.apply #qlx.action<pauli_rotation>(%2028, %cst_1402) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1403 = arith.constant 1.5707963267948966 : f64
    %2030 = qlx.apply #qlx.action<pauli_rotation>(%2025#1, %cst_1403) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1404 = arith.constant 1.5707963267948966 : f64
    %2031:2 = qlx.apply #qlx.action<pauli_rotation>(%2029, %2030, %cst_1404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1405 = arith.constant 1.5707963267948966 : f64
    %2032 = qlx.apply #qlx.action<pauli_rotation>(%2025#0, %cst_1405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2033 = qlx.apply #qlx.action<h>(%2032) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1406 = arith.constant 1.5707963267948966 : f64
    %2034 = qlx.apply #qlx.action<pauli_rotation>(%2033, %cst_1406) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2035 = qlx.apply #qlx.action<h>(%2034) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1407 = arith.constant 1.5707963267948966 : f64
    %2036 = qlx.apply #qlx.action<pauli_rotation>(%2031#1, %cst_1407) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1408 = arith.constant 1.5707963267948966 : f64
    %2037:2 = qlx.apply #qlx.action<pauli_rotation>(%2035, %2036, %cst_1408) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1409 = arith.constant 1.5707963267948966 : f64
    %2038 = qlx.apply #qlx.action<pauli_rotation>(%2037#1, %cst_1409) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2039 = qlx.apply #qlx.action<h>(%2038) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1410 = arith.constant 1.5707963267948966 : f64
    %2040 = qlx.apply #qlx.action<pauli_rotation>(%2027#0, %cst_1410) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2041 = qlx.apply #qlx.action<h>(%2040) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1411 = arith.constant 0.78539816339744828 : f64
    %2042:2 = qlx.apply #qlx.action<pauli_rotation>(%2039, %2041, %cst_1411) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1412 = arith.constant 1.5707963267948966 : f64
    %2043 = qlx.apply #qlx.action<pauli_rotation>(%2037#0, %cst_1412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2044 = qlx.apply #qlx.action<h>(%2042#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1413 = arith.constant 1.5707963267948966 : f64
    %2045:2 = qlx.apply #qlx.action<pauli_rotation>(%2043, %2044, %cst_1413) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1414 = arith.constant 1.5707963267948966 : f64
    %2046 = qlx.apply #qlx.action<pauli_rotation>(%2031#0, %cst_1414) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1415 = arith.constant 1.5707963267948966 : f64
    %2047 = qlx.apply #qlx.action<pauli_rotation>(%2045#1, %cst_1415) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1416 = arith.constant 1.5707963267948966 : f64
    %2048:2 = qlx.apply #qlx.action<pauli_rotation>(%2046, %2047, %cst_1416) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1417 = arith.constant 1.5707963267948966 : f64
    %2049 = qlx.apply #qlx.action<pauli_rotation>(%2027#1, %cst_1417) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2050 = qlx.apply #qlx.action<h>(%2042#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1418 = arith.constant 1.5707963267948966 : f64
    %2051:2 = qlx.apply #qlx.action<pauli_rotation>(%2049, %2050, %cst_1418) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1419 = arith.constant 1.5707963267948966 : f64
    %2052 = qlx.apply #qlx.action<pauli_rotation>(%2051#0, %cst_1419) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1420 = arith.constant 1.5707963267948966 : f64
    %2053:2 = qlx.apply #qlx.action<pauli_rotation>(%2051#1, %2052, %cst_1420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1421 = arith.constant 1.5707963267948966 : f64
    %2054 = qlx.apply #qlx.action<pauli_rotation>(%2048#0, %cst_1421) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1422 = arith.constant 1.5707963267948966 : f64
    %2055 = qlx.apply #qlx.action<pauli_rotation>(%2048#1, %cst_1422) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1423 = arith.constant 1.5707963267948966 : f64
    %2056:2 = qlx.apply #qlx.action<pauli_rotation>(%2054, %2055, %cst_1423) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1424 = arith.constant 1.5707963267948966 : f64
    %2057 = qlx.apply #qlx.action<pauli_rotation>(%2045#0, %cst_1424) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2058 = qlx.apply #qlx.action<h>(%2057) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1425 = arith.constant 1.5707963267948966 : f64
    %2059 = qlx.apply #qlx.action<pauli_rotation>(%2058, %cst_1425) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2060 = qlx.apply #qlx.action<h>(%2059) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1426 = arith.constant 1.5707963267948966 : f64
    %2061 = qlx.apply #qlx.action<pauli_rotation>(%2056#1, %cst_1426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1427 = arith.constant 1.5707963267948966 : f64
    %2062:2 = qlx.apply #qlx.action<pauli_rotation>(%2060, %2061, %cst_1427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1428 = arith.constant 1.5707963267948966 : f64
    %2063 = qlx.apply #qlx.action<pauli_rotation>(%2062#1, %cst_1428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2064 = qlx.apply #qlx.action<h>(%2063) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1429 = arith.constant 1.5707963267948966 : f64
    %2065 = qlx.apply #qlx.action<pauli_rotation>(%2053#0, %cst_1429) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2066 = qlx.apply #qlx.action<h>(%2065) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1430 = arith.constant 0.78539816339744828 : f64
    %2067:2 = qlx.apply #qlx.action<pauli_rotation>(%2064, %2066, %cst_1430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1431 = arith.constant 1.5707963267948966 : f64
    %2068 = qlx.apply #qlx.action<pauli_rotation>(%2062#0, %cst_1431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2069 = qlx.apply #qlx.action<h>(%2067#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1432 = arith.constant 1.5707963267948966 : f64
    %2070:2 = qlx.apply #qlx.action<pauli_rotation>(%2068, %2069, %cst_1432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1433 = arith.constant 1.5707963267948966 : f64
    %2071 = qlx.apply #qlx.action<pauli_rotation>(%2056#0, %cst_1433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1434 = arith.constant 1.5707963267948966 : f64
    %2072 = qlx.apply #qlx.action<pauli_rotation>(%2070#1, %cst_1434) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1435 = arith.constant 1.5707963267948966 : f64
    %2073:2 = qlx.apply #qlx.action<pauli_rotation>(%2071, %2072, %cst_1435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1436 = arith.constant 1.5707963267948966 : f64
    %2074 = qlx.apply #qlx.action<pauli_rotation>(%2053#1, %cst_1436) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2075 = qlx.apply #qlx.action<h>(%2067#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1437 = arith.constant 1.5707963267948966 : f64
    %2076:2 = qlx.apply #qlx.action<pauli_rotation>(%2074, %2075, %cst_1437) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1438 = arith.constant 1.5707963267948966 : f64
    %2077 = qlx.apply #qlx.action<pauli_rotation>(%1997#0, %cst_1438) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1439 = arith.constant 1.5707963267948966 : f64
    %2078 = qlx.apply #qlx.action<pauli_rotation>(%2070#0, %cst_1439) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2079 = qlx.apply #qlx.action<h>(%2078) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1440 = arith.constant 1.5707963267948966 : f64
    %2080 = qlx.apply #qlx.action<pauli_rotation>(%2079, %cst_1440) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2081 = qlx.apply #qlx.action<h>(%2080) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1441 = arith.constant 1.5707963267948966 : f64
    %2082:2 = qlx.apply #qlx.action<pauli_rotation>(%2077, %2081, %cst_1441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1442 = arith.constant 1.5707963267948966 : f64
    %2083 = qlx.apply #qlx.action<pauli_rotation>(%2073#0, %cst_1442) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2084 = qlx.apply #qlx.action<h>(%2083) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1443 = arith.constant 1.5707963267948966 : f64
    %2085 = qlx.apply #qlx.action<pauli_rotation>(%2073#1, %cst_1443) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1444 = arith.constant 1.5707963267948966 : f64
    %2086:2 = qlx.apply #qlx.action<pauli_rotation>(%2084, %2085, %cst_1444) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1445 = arith.constant 1.5707963267948966 : f64
    %2087 = qlx.apply #qlx.action<pauli_rotation>(%1991#0, %cst_1445) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2088 = qlx.apply #qlx.action<h>(%2087) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1446 = arith.constant 1.5707963267948966 : f64
    %2089 = qlx.apply #qlx.action<pauli_rotation>(%2088, %cst_1446) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2090 = qlx.apply #qlx.action<h>(%2089) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1447 = arith.constant 1.5707963267948966 : f64
    %2091 = qlx.apply #qlx.action<pauli_rotation>(%2086#1, %cst_1447) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1448 = arith.constant 1.5707963267948966 : f64
    %2092:2 = qlx.apply #qlx.action<pauli_rotation>(%2090, %2091, %cst_1448) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1449 = arith.constant 1.5707963267948966 : f64
    %2093 = qlx.apply #qlx.action<pauli_rotation>(%2092#1, %cst_1449) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2094 = qlx.apply #qlx.action<h>(%2093) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1450 = arith.constant 1.5707963267948966 : f64
    %2095 = qlx.apply #qlx.action<pauli_rotation>(%2082#1, %cst_1450) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2096 = qlx.apply #qlx.action<h>(%2095) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1451 = arith.constant 0.78539816339744828 : f64
    %2097:2 = qlx.apply #qlx.action<pauli_rotation>(%2094, %2096, %cst_1451) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1452 = arith.constant 1.5707963267948966 : f64
    %2098 = qlx.apply #qlx.action<pauli_rotation>(%2092#0, %cst_1452) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2099 = qlx.apply #qlx.action<h>(%2097#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1453 = arith.constant 1.5707963267948966 : f64
    %2100:2 = qlx.apply #qlx.action<pauli_rotation>(%2098, %2099, %cst_1453) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1454 = arith.constant 1.5707963267948966 : f64
    %2101 = qlx.apply #qlx.action<pauli_rotation>(%2086#0, %cst_1454) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1455 = arith.constant 1.5707963267948966 : f64
    %2102 = qlx.apply #qlx.action<pauli_rotation>(%2100#1, %cst_1455) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1456 = arith.constant 1.5707963267948966 : f64
    %2103:2 = qlx.apply #qlx.action<pauli_rotation>(%2101, %2102, %cst_1456) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1457 = arith.constant 1.5707963267948966 : f64
    %2104 = qlx.apply #qlx.action<pauli_rotation>(%2082#0, %cst_1457) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2105 = qlx.apply #qlx.action<h>(%2097#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1458 = arith.constant 1.5707963267948966 : f64
    %2106:2 = qlx.apply #qlx.action<pauli_rotation>(%2104, %2105, %cst_1458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1459 = arith.constant 1.5707963267948966 : f64
    %2107 = qlx.apply #qlx.action<pauli_rotation>(%2106#0, %cst_1459) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1460 = arith.constant 1.5707963267948966 : f64
    %2108 = qlx.apply #qlx.action<pauli_rotation>(%2106#1, %cst_1460) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1461 = arith.constant 1.5707963267948966 : f64
    %2109:2 = qlx.apply #qlx.action<pauli_rotation>(%2107, %2108, %cst_1461) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1462 = arith.constant 1.5707963267948966 : f64
    %2110 = qlx.apply #qlx.action<pauli_rotation>(%2103#0, %cst_1462) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2111 = qlx.apply #qlx.action<h>(%2110) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1463 = arith.constant 1.5707963267948966 : f64
    %2112 = qlx.apply #qlx.action<pauli_rotation>(%2111, %cst_1463) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2113 = qlx.apply #qlx.action<h>(%2112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1464 = arith.constant 1.5707963267948966 : f64
    %2114 = qlx.apply #qlx.action<pauli_rotation>(%2103#1, %cst_1464) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1465 = arith.constant 1.5707963267948966 : f64
    %2115:2 = qlx.apply #qlx.action<pauli_rotation>(%2113, %2114, %cst_1465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1466 = arith.constant 1.5707963267948966 : f64
    %2116 = qlx.apply #qlx.action<pauli_rotation>(%2100#0, %cst_1466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2117 = qlx.apply #qlx.action<h>(%2116) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1467 = arith.constant 1.5707963267948966 : f64
    %2118 = qlx.apply #qlx.action<pauli_rotation>(%2117, %cst_1467) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2119 = qlx.apply #qlx.action<h>(%2118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1468 = arith.constant 1.5707963267948966 : f64
    %2120 = qlx.apply #qlx.action<pauli_rotation>(%2115#1, %cst_1468) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1469 = arith.constant 1.5707963267948966 : f64
    %2121:2 = qlx.apply #qlx.action<pauli_rotation>(%2119, %2120, %cst_1469) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1470 = arith.constant 1.5707963267948966 : f64
    %2122 = qlx.apply #qlx.action<pauli_rotation>(%2121#1, %cst_1470) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2123 = qlx.apply #qlx.action<h>(%2122) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1471 = arith.constant 1.5707963267948966 : f64
    %2124 = qlx.apply #qlx.action<pauli_rotation>(%2109#1, %cst_1471) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2125 = qlx.apply #qlx.action<h>(%2124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1472 = arith.constant 0.78539816339744828 : f64
    %2126:2 = qlx.apply #qlx.action<pauli_rotation>(%2123, %2125, %cst_1472) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1473 = arith.constant 1.5707963267948966 : f64
    %2127 = qlx.apply #qlx.action<pauli_rotation>(%2121#0, %cst_1473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2128 = qlx.apply #qlx.action<h>(%2126#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1474 = arith.constant 1.5707963267948966 : f64
    %2129:2 = qlx.apply #qlx.action<pauli_rotation>(%2127, %2128, %cst_1474) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1475 = arith.constant 1.5707963267948966 : f64
    %2130 = qlx.apply #qlx.action<pauli_rotation>(%2115#0, %cst_1475) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1476 = arith.constant 1.5707963267948966 : f64
    %2131 = qlx.apply #qlx.action<pauli_rotation>(%2129#1, %cst_1476) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1477 = arith.constant 1.5707963267948966 : f64
    %2132:2 = qlx.apply #qlx.action<pauli_rotation>(%2130, %2131, %cst_1477) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1478 = arith.constant 1.5707963267948966 : f64
    %2133 = qlx.apply #qlx.action<pauli_rotation>(%2109#0, %cst_1478) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2134 = qlx.apply #qlx.action<h>(%2126#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1479 = arith.constant 1.5707963267948966 : f64
    %2135:2 = qlx.apply #qlx.action<pauli_rotation>(%2133, %2134, %cst_1479) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1480 = arith.constant 1.5707963267948966 : f64
    %2136 = qlx.apply #qlx.action<pauli_rotation>(%1819#0, %cst_1480) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2137 = qlx.apply #qlx.action<h>(%2136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1481 = arith.constant 3.1415926535897931 : f64
    %2138 = qlx.apply #qlx.action<pauli_rotation>(%2137, %cst_1481) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1482 = arith.constant 1.5707963267948966 : f64
    %2139 = qlx.apply #qlx.action<pauli_rotation>(%2076#1, %cst_1482) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1483 = arith.constant 2.500000e-01 : f64
    %2140:2 = qlx.apply #qlx.action<pauli_rotation>(%2138, %2139, %cst_1483) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1484 = arith.constant 1.5707963267948966 : f64
    %2141 = qlx.apply #qlx.action<pauli_rotation>(%2076#0, %cst_1484) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1485 = arith.constant 1.5707963267948966 : f64
    %2142 = qlx.apply #qlx.action<pauli_rotation>(%2132#0, %cst_1485) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2143 = qlx.apply #qlx.action<h>(%2142) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1486 = arith.constant 1.5707963267948966 : f64
    %2144 = qlx.apply #qlx.action<pauli_rotation>(%2143, %cst_1486) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1487 = arith.constant 2.500000e-01 : f64
    %2145:2 = qlx.apply #qlx.action<pauli_rotation>(%2141, %2144, %cst_1487) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1488 = arith.constant 1.5707963267948966 : f64
    %2146 = qlx.apply #qlx.action<pauli_rotation>(%2132#1, %cst_1488) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2147 = qlx.apply #qlx.action<h>(%2146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1489 = arith.constant 1.5707963267948966 : f64
    %2148 = qlx.apply #qlx.action<pauli_rotation>(%2135#1, %cst_1489) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2149 = qlx.apply #qlx.action<h>(%2148) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1490 = arith.constant 2.500000e-01 : f64
    %2150:2 = qlx.apply #qlx.action<pauli_rotation>(%2147, %2149, %cst_1490) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1491 = arith.constant 1.5707963267948966 : f64
    %2151 = qlx.apply #qlx.action<pauli_rotation>(%2135#0, %cst_1491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1492 = arith.constant 1.5707963267948966 : f64
    %2152 = qlx.apply #qlx.action<pauli_rotation>(%2129#0, %cst_1492) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2153 = qlx.apply #qlx.action<h>(%2152) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1493 = arith.constant 3.1415926535897931 : f64
    %2154 = qlx.apply #qlx.action<pauli_rotation>(%2153, %cst_1493) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1494 = arith.constant 2.500000e-01 : f64
    %2155:2 = qlx.apply #qlx.action<pauli_rotation>(%2151, %2154, %cst_1494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2156 = qlx.measure <Z> %2140#0 : !qlx.logical_qubit -> i1
    %2157 = qlx.measure <Z> %2140#1 : !qlx.logical_qubit -> i1
    %2158 = qlx.measure <Z> %2145#0 : !qlx.logical_qubit -> i1
    %2159 = qlx.measure <Z> %2145#1 : !qlx.logical_qubit -> i1
    %2160 = qlx.measure <Z> %2150#0 : !qlx.logical_qubit -> i1
    %2161 = qlx.measure <Z> %2150#1 : !qlx.logical_qubit -> i1
    %2162 = qlx.measure <Z> %2155#0 : !qlx.logical_qubit -> i1
    %2163 = qlx.measure <Z> %2155#1 : !qlx.logical_qubit -> i1
  }
}
