module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %9:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %10 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_0 = arith.constant 2.500000e-01 : f64
    %11:2 = qlx.apply #qlx.action<pauli_rotation>(%2, %10, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %12 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1 = arith.constant 2.500000e-01 : f64
    %13:2 = qlx.apply #qlx.action<pauli_rotation>(%12, %5, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %14 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2 = arith.constant 2.500000e-01 : f64
    %15:2 = qlx.apply #qlx.action<pauli_rotation>(%6, %14, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %16 = qlx.apply #qlx.action<h>(%11#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %17 = qlx.apply #qlx.action<h>(%13#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %18:2 = qlx.apply #qlx.action<pauli_rotation>(%16, %17, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %19 = qlx.apply #qlx.action<pauli_rotation>(%18#0, %cst_4) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %20 = qlx.apply #qlx.action<pauli_rotation>(%18#1, %cst_5) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %21:2 = qlx.apply #qlx.action<pauli_rotation>(%19, %20, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %22 = qlx.apply #qlx.action<h>(%11#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %23 = qlx.apply #qlx.action<h>(%21#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_7 = arith.constant 3.1415926535897931 : f64
    %24 = qlx.apply #qlx.action<pauli_rotation>(%23, %cst_7) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %25 = qlx.apply #qlx.action<h>(%24) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %26:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %25, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %27 = qlx.apply #qlx.action<pauli_rotation>(%26#0, %cst_9) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %28 = qlx.apply #qlx.action<pauli_rotation>(%26#1, %cst_10) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_11 = arith.constant 1.5707963267948966 : f64
    %29:2 = qlx.apply #qlx.action<pauli_rotation>(%27, %28, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %30 = qlx.apply #qlx.action<h>(%9#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %31 = qlx.apply #qlx.action<h>(%29#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_12 = arith.constant 3.1415926535897931 : f64
    %32 = qlx.apply #qlx.action<pauli_rotation>(%31, %cst_12) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %33 = qlx.apply #qlx.action<h>(%32) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %34:2 = qlx.apply #qlx.action<pauli_rotation>(%30, %33, %cst_13) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %35 = qlx.apply #qlx.action<pauli_rotation>(%34#0, %cst_14) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %36 = qlx.apply #qlx.action<pauli_rotation>(%34#1, %cst_15) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %37:2 = qlx.apply #qlx.action<pauli_rotation>(%35, %36, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_17 = arith.constant 0.78539816339744828 : f64
    %38 = qlx.apply #qlx.action<pauli_rotation>(%9#0, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %39 = qlx.apply #qlx.action<h>(%38) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %40 = qlx.apply #qlx.action<h>(%37#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_18 = arith.constant 2.3561944901923448 : f64
    %41 = qlx.apply #qlx.action<pauli_rotation>(%40, %cst_18) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %42 = qlx.apply #qlx.action<h>(%41) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_19 = arith.constant 0.78539816339744828 : f64
    %43:2 = qlx.apply #qlx.action<pauli_rotation>(%39, %42, %cst_19) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %44 = qlx.apply #qlx.action<pauli_rotation>(%43#0, %cst_20) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %45 = qlx.apply #qlx.action<pauli_rotation>(%43#1, %cst_21) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %46:2 = qlx.apply #qlx.action<pauli_rotation>(%44, %45, %cst_22) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %47 = qlx.apply #qlx.action<h>(%13#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %48 = qlx.apply #qlx.action<h>(%15#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %49:2 = qlx.apply #qlx.action<pauli_rotation>(%47, %48, %cst_23) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %50 = qlx.apply #qlx.action<pauli_rotation>(%49#0, %cst_24) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%49#1, %cst_25) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %52:2 = qlx.apply #qlx.action<pauli_rotation>(%50, %51, %cst_26) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %53 = qlx.apply #qlx.action<h>(%21#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 3.1415926535897931 : f64
    %54 = qlx.apply #qlx.action<pauli_rotation>(%53, %cst_27) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %55 = qlx.apply #qlx.action<h>(%54) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %56 = qlx.apply #qlx.action<h>(%52#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_28 = arith.constant 3.1415926535897931 : f64
    %57 = qlx.apply #qlx.action<pauli_rotation>(%56, %cst_28) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %58 = qlx.apply #qlx.action<h>(%57) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_29 = arith.constant 1.5707963267948966 : f64
    %59:2 = qlx.apply #qlx.action<pauli_rotation>(%55, %58, %cst_29) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %60 = qlx.apply #qlx.action<pauli_rotation>(%59#0, %cst_30) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_31 = arith.constant 1.5707963267948966 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%59#1, %cst_31) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %62:2 = qlx.apply #qlx.action<pauli_rotation>(%60, %61, %cst_32) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %63 = qlx.apply #qlx.action<h>(%29#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_33 = arith.constant 2.3561944901923448 : f64
    %64 = qlx.apply #qlx.action<pauli_rotation>(%63, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %65 = qlx.apply #qlx.action<h>(%64) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<h>(%62#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_34 = arith.constant 2.3561944901923448 : f64
    %67 = qlx.apply #qlx.action<pauli_rotation>(%66, %cst_34) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %68 = qlx.apply #qlx.action<h>(%67) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_35 = arith.constant 0.78539816339744828 : f64
    %69:2 = qlx.apply #qlx.action<pauli_rotation>(%65, %68, %cst_35) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %70 = qlx.apply #qlx.action<pauli_rotation>(%69#0, %cst_36) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %71 = qlx.apply #qlx.action<pauli_rotation>(%69#1, %cst_37) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_38 = arith.constant 0.78539816339744828 : f64
    %72:2 = qlx.apply #qlx.action<pauli_rotation>(%70, %71, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %73 = qlx.apply #qlx.action<h>(%37#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 3.1415926535897931 : f64
    %74 = qlx.apply #qlx.action<pauli_rotation>(%73, %cst_39) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %75 = qlx.apply #qlx.action<h>(%74) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %76 = qlx.apply #qlx.action<h>(%72#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_40 = arith.constant 2.3561944901923448 : f64
    %77 = qlx.apply #qlx.action<pauli_rotation>(%76, %cst_40) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %78 = qlx.apply #qlx.action<h>(%77) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %79:2 = qlx.apply #qlx.action<pauli_rotation>(%75, %78, %cst_41) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_42 = arith.constant 1.5707963267948966 : f64
    %80 = qlx.apply #qlx.action<pauli_rotation>(%79#0, %cst_42) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %81 = qlx.apply #qlx.action<pauli_rotation>(%79#1, %cst_43) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_44 = arith.constant 1.5707963267948966 : f64
    %82:2 = qlx.apply #qlx.action<pauli_rotation>(%80, %81, %cst_44) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %83 = qlx.apply #qlx.action<h>(%46#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 2.3561944901923448 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%83, %cst_45) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %85 = qlx.apply #qlx.action<h>(%84) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %86 = qlx.apply #qlx.action<h>(%82#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %87 = qlx.apply #qlx.action<pauli_rotation>(%86, %cst_46) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %88 = qlx.apply #qlx.action<h>(%87) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_47 = arith.constant 5.000000e-01 : f64
    %89:2 = qlx.apply #qlx.action<pauli_rotation>(%85, %88, %cst_47) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %90 = qlx.apply #qlx.action<pauli_rotation>(%89#0, %cst_48) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_49 = arith.constant 1.5707963267948966 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%89#1, %cst_49) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_50 = arith.constant 5.000000e-01 : f64
    %92:2 = qlx.apply #qlx.action<pauli_rotation>(%90, %91, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %93 = qlx.apply #qlx.action<h>(%46#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_51 = arith.constant 1.5707963267948966 : f64
    %94 = qlx.apply #qlx.action<pauli_rotation>(%93, %cst_51) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %95 = qlx.apply #qlx.action<h>(%94) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %96 = qlx.apply #qlx.action<h>(%92#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_52 = arith.constant 0.78539816339744828 : f64
    %97 = qlx.apply #qlx.action<pauli_rotation>(%96, %cst_52) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %98 = qlx.apply #qlx.action<h>(%97) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_53 = arith.constant 0.78539816339744828 : f64
    %99:2 = qlx.apply #qlx.action<pauli_rotation>(%95, %98, %cst_53) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_54 = arith.constant 1.5707963267948966 : f64
    %100 = qlx.apply #qlx.action<pauli_rotation>(%99#0, %cst_54) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %101 = qlx.apply #qlx.action<pauli_rotation>(%99#1, %cst_55) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_56 = arith.constant 0.78539816339744828 : f64
    %102:2 = qlx.apply #qlx.action<pauli_rotation>(%100, %101, %cst_56) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %103 = qlx.apply #qlx.action<h>(%82#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_57 = arith.constant 3.1415926535897931 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%103, %cst_57) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %105 = qlx.apply #qlx.action<h>(%104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %106 = qlx.apply #qlx.action<h>(%72#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_58 = arith.constant 2.3561944901923448 : f64
    %107 = qlx.apply #qlx.action<pauli_rotation>(%106, %cst_58) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %108 = qlx.apply #qlx.action<h>(%107) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%105, %108, %cst_59) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_60 = arith.constant 1.5707963267948966 : f64
    %110 = qlx.apply #qlx.action<pauli_rotation>(%109#0, %cst_60) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_61 = arith.constant 1.5707963267948966 : f64
    %111 = qlx.apply #qlx.action<pauli_rotation>(%109#1, %cst_61) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %112:2 = qlx.apply #qlx.action<pauli_rotation>(%110, %111, %cst_62) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %113 = qlx.apply #qlx.action<h>(%92#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_63 = arith.constant 2.3561944901923448 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %115 = qlx.apply #qlx.action<h>(%114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %116 = qlx.apply #qlx.action<h>(%112#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_64 = arith.constant 2.3561944901923448 : f64
    %117 = qlx.apply #qlx.action<pauli_rotation>(%116, %cst_64) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %118 = qlx.apply #qlx.action<h>(%117) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_65 = arith.constant 0.78539816339744828 : f64
    %119:2 = qlx.apply #qlx.action<pauli_rotation>(%115, %118, %cst_65) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 1.5707963267948966 : f64
    %120 = qlx.apply #qlx.action<pauli_rotation>(%119#0, %cst_66) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_67 = arith.constant 1.5707963267948966 : f64
    %121 = qlx.apply #qlx.action<pauli_rotation>(%119#1, %cst_67) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_68 = arith.constant 0.78539816339744828 : f64
    %122:2 = qlx.apply #qlx.action<pauli_rotation>(%120, %121, %cst_68) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %123 = qlx.apply #qlx.action<h>(%62#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_69 = arith.constant 3.1415926535897931 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%123, %cst_69) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %125 = qlx.apply #qlx.action<h>(%124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %126 = qlx.apply #qlx.action<h>(%52#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_70 = arith.constant 3.1415926535897931 : f64
    %127 = qlx.apply #qlx.action<pauli_rotation>(%126, %cst_70) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %128 = qlx.apply #qlx.action<h>(%127) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_71 = arith.constant 1.5707963267948966 : f64
    %129:2 = qlx.apply #qlx.action<pauli_rotation>(%125, %128, %cst_71) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %130 = qlx.apply #qlx.action<pauli_rotation>(%129#0, %cst_72) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_73 = arith.constant 1.5707963267948966 : f64
    %131 = qlx.apply #qlx.action<pauli_rotation>(%129#1, %cst_73) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_74 = arith.constant 1.5707963267948966 : f64
    %132:2 = qlx.apply #qlx.action<pauli_rotation>(%130, %131, %cst_74) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %133 = qlx.apply #qlx.action<h>(%112#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_75 = arith.constant 2.3561944901923448 : f64
    %134 = qlx.apply #qlx.action<pauli_rotation>(%133, %cst_75) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<h>(%134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %136 = qlx.apply #qlx.action<h>(%132#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_76 = arith.constant 2.3561944901923448 : f64
    %137 = qlx.apply #qlx.action<pauli_rotation>(%136, %cst_76) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %138 = qlx.apply #qlx.action<h>(%137) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_77 = arith.constant 0.78539816339744828 : f64
    %139:2 = qlx.apply #qlx.action<pauli_rotation>(%135, %138, %cst_77) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %140 = qlx.apply #qlx.action<pauli_rotation>(%139#0, %cst_78) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_79 = arith.constant 1.5707963267948966 : f64
    %141 = qlx.apply #qlx.action<pauli_rotation>(%139#1, %cst_79) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_80 = arith.constant 0.78539816339744828 : f64
    %142:2 = qlx.apply #qlx.action<pauli_rotation>(%140, %141, %cst_80) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %143 = qlx.apply #qlx.action<h>(%132#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_81 = arith.constant 2.3561944901923448 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_82 = arith.constant 0.78539816339744828 : f64
    %146 = qlx.apply #qlx.action<pauli_rotation>(%15#1, %cst_82) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %147 = qlx.apply #qlx.action<h>(%146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_83 = arith.constant 0.78539816339744828 : f64
    %148:2 = qlx.apply #qlx.action<pauli_rotation>(%145, %147, %cst_83) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %149 = qlx.apply #qlx.action<pauli_rotation>(%148#0, %cst_84) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_85 = arith.constant 1.5707963267948966 : f64
    %150 = qlx.apply #qlx.action<pauli_rotation>(%148#1, %cst_85) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_86 = arith.constant 0.78539816339744828 : f64
    %151:2 = qlx.apply #qlx.action<pauli_rotation>(%149, %150, %cst_86) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %152 = qlx.apply #qlx.action<h>(%142#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 2.3561944901923448 : f64
    %153 = qlx.apply #qlx.action<pauli_rotation>(%152, %cst_87) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %154 = qlx.apply #qlx.action<h>(%153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %155 = qlx.apply #qlx.action<h>(%151#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_88 = arith.constant 0.78539816339744828 : f64
    %156 = qlx.apply #qlx.action<pauli_rotation>(%155, %cst_88) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %157 = qlx.apply #qlx.action<h>(%156) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_89 = arith.constant 5.000000e-01 : f64
    %158:2 = qlx.apply #qlx.action<pauli_rotation>(%154, %157, %cst_89) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %159 = qlx.apply #qlx.action<pauli_rotation>(%158#0, %cst_90) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_91 = arith.constant 1.5707963267948966 : f64
    %160 = qlx.apply #qlx.action<pauli_rotation>(%158#1, %cst_91) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_92 = arith.constant 5.000000e-01 : f64
    %161:2 = qlx.apply #qlx.action<pauli_rotation>(%159, %160, %cst_92) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %162 = qlx.apply #qlx.action<h>(%142#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %163 = qlx.apply #qlx.action<pauli_rotation>(%162, %cst_93) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %164 = qlx.apply #qlx.action<h>(%163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %165 = qlx.apply #qlx.action<h>(%161#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_94 = arith.constant 0.78539816339744828 : f64
    %166 = qlx.apply #qlx.action<pauli_rotation>(%165, %cst_94) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %167 = qlx.apply #qlx.action<h>(%166) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_95 = arith.constant 0.78539816339744828 : f64
    %168:2 = qlx.apply #qlx.action<pauli_rotation>(%164, %167, %cst_95) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %169 = qlx.apply #qlx.action<pauli_rotation>(%168#0, %cst_96) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_97 = arith.constant 1.5707963267948966 : f64
    %170 = qlx.apply #qlx.action<pauli_rotation>(%168#1, %cst_97) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_98 = arith.constant 0.78539816339744828 : f64
    %171:2 = qlx.apply #qlx.action<pauli_rotation>(%169, %170, %cst_98) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %172 = qlx.apply #qlx.action<h>(%161#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_99 = arith.constant 2.3561944901923448 : f64
    %173 = qlx.apply #qlx.action<pauli_rotation>(%172, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %174 = qlx.apply #qlx.action<h>(%173) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %175 = qlx.apply #qlx.action<h>(%151#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %176 = qlx.apply #qlx.action<pauli_rotation>(%175, %cst_100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %177 = qlx.apply #qlx.action<h>(%176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_101 = arith.constant 0.78539816339744828 : f64
    %178:2 = qlx.apply #qlx.action<pauli_rotation>(%174, %177, %cst_101) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %179 = qlx.apply #qlx.action<pauli_rotation>(%178#0, %cst_102) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_103 = arith.constant 1.5707963267948966 : f64
    %180 = qlx.apply #qlx.action<pauli_rotation>(%178#1, %cst_103) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_104 = arith.constant 0.78539816339744828 : f64
    %181:2 = qlx.apply #qlx.action<pauli_rotation>(%179, %180, %cst_104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %182 = qlx.apply #qlx.action<h>(%122#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_105 = arith.constant 2.3561944901923448 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%182, %cst_105) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %184 = qlx.apply #qlx.action<h>(%183) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %185 = qlx.apply #qlx.action<h>(%171#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_106 = arith.constant 2.3561944901923448 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%185, %cst_106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %187 = qlx.apply #qlx.action<h>(%186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_107 = arith.constant 1.5707963267948966 : f64
    %188:2 = qlx.apply #qlx.action<pauli_rotation>(%184, %187, %cst_107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_108 = arith.constant 1.5707963267948966 : f64
    %189 = qlx.apply #qlx.action<pauli_rotation>(%188#0, %cst_108) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_109 = arith.constant 1.5707963267948966 : f64
    %190 = qlx.apply #qlx.action<pauli_rotation>(%188#1, %cst_109) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_110 = arith.constant 1.5707963267948966 : f64
    %191:2 = qlx.apply #qlx.action<pauli_rotation>(%189, %190, %cst_110) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %192 = qlx.apply #qlx.action<h>(%122#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_111 = arith.constant 2.3561944901923448 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%192, %cst_111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %194 = qlx.apply #qlx.action<h>(%193) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %195 = qlx.apply #qlx.action<h>(%191#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 3.1415926535897931 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%195, %cst_112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<h>(%196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_113 = arith.constant 1.5707963267948966 : f64
    %198:2 = qlx.apply #qlx.action<pauli_rotation>(%194, %197, %cst_113) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_114 = arith.constant 1.5707963267948966 : f64
    %199 = qlx.apply #qlx.action<pauli_rotation>(%198#0, %cst_114) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_115 = arith.constant 1.5707963267948966 : f64
    %200 = qlx.apply #qlx.action<pauli_rotation>(%198#1, %cst_115) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %201:2 = qlx.apply #qlx.action<pauli_rotation>(%199, %200, %cst_116) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %202 = qlx.apply #qlx.action<h>(%102#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_117 = arith.constant 2.3561944901923448 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%202, %cst_117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %204 = qlx.apply #qlx.action<h>(%203) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %205 = qlx.apply #qlx.action<h>(%201#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_118 = arith.constant 3.1415926535897931 : f64
    %206 = qlx.apply #qlx.action<pauli_rotation>(%205, %cst_118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %208:2 = qlx.apply #qlx.action<pauli_rotation>(%204, %207, %cst_119) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %209 = qlx.apply #qlx.action<pauli_rotation>(%208#0, %cst_120) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %210 = qlx.apply #qlx.action<pauli_rotation>(%208#1, %cst_121) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%209, %210, %cst_122) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %212 = qlx.apply #qlx.action<h>(%102#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 2.3561944901923448 : f64
    %213 = qlx.apply #qlx.action<pauli_rotation>(%212, %cst_123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %214 = qlx.apply #qlx.action<h>(%211#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_124 = arith.constant 3.1415926535897931 : f64
    %215 = qlx.apply #qlx.action<pauli_rotation>(%214, %cst_124) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 5.000000e-01 : f64
    %216:2 = qlx.apply #qlx.action<pauli_rotation>(%213, %215, %cst_125) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %217 = qlx.apply #qlx.action<h>(%201#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_126 = arith.constant 3.1415926535897931 : f64
    %218 = qlx.apply #qlx.action<pauli_rotation>(%217, %cst_126) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %219 = qlx.apply #qlx.action<h>(%218) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<h>(%191#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 3.1415926535897931 : f64
    %221 = qlx.apply #qlx.action<pauli_rotation>(%220, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %222 = qlx.apply #qlx.action<h>(%221) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_128 = arith.constant 1.5707963267948966 : f64
    %223:2 = qlx.apply #qlx.action<pauli_rotation>(%219, %222, %cst_128) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %224 = qlx.apply #qlx.action<pauli_rotation>(%223#0, %cst_129) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %225 = qlx.apply #qlx.action<pauli_rotation>(%223#1, %cst_130) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 1.5707963267948966 : f64
    %226:2 = qlx.apply #qlx.action<pauli_rotation>(%224, %225, %cst_131) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %227 = qlx.apply #qlx.action<h>(%226#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_132 = arith.constant 3.1415926535897931 : f64
    %228 = qlx.apply #qlx.action<pauli_rotation>(%227, %cst_132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %229 = qlx.apply #qlx.action<h>(%228) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %230 = qlx.apply #qlx.action<h>(%171#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_133 = arith.constant 2.3561944901923448 : f64
    %231 = qlx.apply #qlx.action<pauli_rotation>(%230, %cst_133) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %232 = qlx.apply #qlx.action<h>(%231) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_134 = arith.constant 1.5707963267948966 : f64
    %233:2 = qlx.apply #qlx.action<pauli_rotation>(%229, %232, %cst_134) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %234 = qlx.apply #qlx.action<pauli_rotation>(%233#0, %cst_135) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %235 = qlx.apply #qlx.action<pauli_rotation>(%233#1, %cst_136) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %236:2 = qlx.apply #qlx.action<pauli_rotation>(%234, %235, %cst_137) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %237 = qlx.apply #qlx.action<h>(%236#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_138 = arith.constant 3.1415926535897931 : f64
    %238 = qlx.apply #qlx.action<pauli_rotation>(%237, %cst_138) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %239 = qlx.apply #qlx.action<h>(%181#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_139 = arith.constant 2.3561944901923448 : f64
    %240 = qlx.apply #qlx.action<pauli_rotation>(%239, %cst_139) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_140 = arith.constant 5.000000e-01 : f64
    %241:2 = qlx.apply #qlx.action<pauli_rotation>(%238, %240, %cst_140) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %242 = qlx.apply #qlx.action<h>(%226#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 3.1415926535897931 : f64
    %243 = qlx.apply #qlx.action<pauli_rotation>(%242, %cst_141) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %244 = qlx.apply #qlx.action<h>(%243) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %245 = qlx.apply #qlx.action<h>(%236#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_142 = arith.constant 3.1415926535897931 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%245, %cst_142) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %247 = qlx.apply #qlx.action<h>(%246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %248:2 = qlx.apply #qlx.action<pauli_rotation>(%244, %247, %cst_143) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %249 = qlx.apply #qlx.action<pauli_rotation>(%248#0, %cst_144) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_145 = arith.constant 1.5707963267948966 : f64
    %250 = qlx.apply #qlx.action<pauli_rotation>(%248#1, %cst_145) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_146 = arith.constant 1.5707963267948966 : f64
    %251:2 = qlx.apply #qlx.action<pauli_rotation>(%249, %250, %cst_146) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %252 = qlx.apply #qlx.action<h>(%211#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_147 = arith.constant 3.1415926535897931 : f64
    %253 = qlx.apply #qlx.action<pauli_rotation>(%252, %cst_147) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %254 = qlx.apply #qlx.action<h>(%251#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_148 = arith.constant 3.1415926535897931 : f64
    %255 = qlx.apply #qlx.action<pauli_rotation>(%254, %cst_148) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_149 = arith.constant 5.000000e-01 : f64
    %256:2 = qlx.apply #qlx.action<pauli_rotation>(%253, %255, %cst_149) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %257 = qlx.apply #qlx.action<h>(%251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_150 = arith.constant 3.1415926535897931 : f64
    %258 = qlx.apply #qlx.action<pauli_rotation>(%257, %cst_150) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %259 = qlx.apply #qlx.action<h>(%258) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%241#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_151 = arith.constant 1.5707963267948966 : f64
    %261:2 = qlx.apply #qlx.action<pauli_rotation>(%259, %260, %cst_151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_152 = arith.constant 1.5707963267948966 : f64
    %262 = qlx.apply #qlx.action<pauli_rotation>(%261#0, %cst_152) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_153 = arith.constant 1.5707963267948966 : f64
    %263 = qlx.apply #qlx.action<pauli_rotation>(%261#1, %cst_153) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %264:2 = qlx.apply #qlx.action<pauli_rotation>(%262, %263, %cst_154) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %265 = qlx.apply #qlx.action<h>(%241#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %266 = qlx.apply #qlx.action<h>(%181#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_155 = arith.constant 2.3561944901923448 : f64
    %267 = qlx.apply #qlx.action<pauli_rotation>(%266, %cst_155) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %268 = qlx.apply #qlx.action<h>(%267) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_156 = arith.constant 1.5707963267948966 : f64
    %269:2 = qlx.apply #qlx.action<pauli_rotation>(%265, %268, %cst_156) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_157 = arith.constant 1.5707963267948966 : f64
    %270 = qlx.apply #qlx.action<pauli_rotation>(%269#0, %cst_157) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_158 = arith.constant 1.5707963267948966 : f64
    %271 = qlx.apply #qlx.action<pauli_rotation>(%269#1, %cst_158) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_159 = arith.constant 1.5707963267948966 : f64
    %272:2 = qlx.apply #qlx.action<pauli_rotation>(%270, %271, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %273 = qlx.apply #qlx.action<h>(%264#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_160 = arith.constant 3.1415926535897931 : f64
    %274 = qlx.apply #qlx.action<pauli_rotation>(%273, %cst_160) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %275 = qlx.apply #qlx.action<h>(%272#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_161 = arith.constant 3.1415926535897931 : f64
    %276 = qlx.apply #qlx.action<pauli_rotation>(%275, %cst_161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 5.000000e-01 : f64
    %277:2 = qlx.apply #qlx.action<pauli_rotation>(%274, %276, %cst_162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %278 = qlx.apply #qlx.action<h>(%216#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %279 = qlx.apply #qlx.action<h>(%256#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 1.5707963267948966 : f64
    %280:2 = qlx.apply #qlx.action<pauli_rotation>(%278, %279, %cst_163) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_164 = arith.constant 1.5707963267948966 : f64
    %281 = qlx.apply #qlx.action<pauli_rotation>(%280#0, %cst_164) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_165 = arith.constant 1.5707963267948966 : f64
    %282 = qlx.apply #qlx.action<pauli_rotation>(%280#1, %cst_165) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %283:2 = qlx.apply #qlx.action<pauli_rotation>(%281, %282, %cst_166) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_167 = arith.constant 0.78539816339744828 : f64
    %284 = qlx.apply #qlx.action<pauli_rotation>(%216#0, %cst_167) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %285 = qlx.apply #qlx.action<h>(%284) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %286 = qlx.apply #qlx.action<h>(%283#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_168 = arith.constant 2.3561944901923448 : f64
    %287 = qlx.apply #qlx.action<pauli_rotation>(%286, %cst_168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %288 = qlx.apply #qlx.action<h>(%287) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 0.78539816339744828 : f64
    %289:2 = qlx.apply #qlx.action<pauli_rotation>(%285, %288, %cst_169) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_170 = arith.constant 1.5707963267948966 : f64
    %290 = qlx.apply #qlx.action<pauli_rotation>(%289#0, %cst_170) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_171 = arith.constant 1.5707963267948966 : f64
    %291 = qlx.apply #qlx.action<pauli_rotation>(%289#1, %cst_171) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_172 = arith.constant 0.78539816339744828 : f64
    %292:2 = qlx.apply #qlx.action<pauli_rotation>(%290, %291, %cst_172) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %293 = qlx.apply #qlx.action<h>(%264#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_173 = arith.constant 2.3561944901923448 : f64
    %294 = qlx.apply #qlx.action<pauli_rotation>(%293, %cst_173) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %295 = qlx.apply #qlx.action<h>(%294) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_174 = arith.constant 0.78539816339744828 : f64
    %296 = qlx.apply #qlx.action<pauli_rotation>(%277#0, %cst_174) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %297 = qlx.apply #qlx.action<h>(%296) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 0.78539816339744828 : f64
    %298:2 = qlx.apply #qlx.action<pauli_rotation>(%295, %297, %cst_175) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_176 = arith.constant 1.5707963267948966 : f64
    %299 = qlx.apply #qlx.action<pauli_rotation>(%298#0, %cst_176) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_177 = arith.constant 1.5707963267948966 : f64
    %300 = qlx.apply #qlx.action<pauli_rotation>(%298#1, %cst_177) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_178 = arith.constant 0.78539816339744828 : f64
    %301:2 = qlx.apply #qlx.action<pauli_rotation>(%299, %300, %cst_178) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %302 = qlx.apply #qlx.action<h>(%292#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_179 = arith.constant 2.3561944901923448 : f64
    %303 = qlx.apply #qlx.action<pauli_rotation>(%302, %cst_179) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %304 = qlx.apply #qlx.action<h>(%303) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %305 = qlx.apply #qlx.action<h>(%283#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_180 = arith.constant 3.1415926535897931 : f64
    %306 = qlx.apply #qlx.action<pauli_rotation>(%305, %cst_180) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %307 = qlx.apply #qlx.action<h>(%306) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_181 = arith.constant 1.5707963267948966 : f64
    %308:2 = qlx.apply #qlx.action<pauli_rotation>(%304, %307, %cst_181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_182 = arith.constant 1.5707963267948966 : f64
    %309 = qlx.apply #qlx.action<pauli_rotation>(%308#0, %cst_182) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_183 = arith.constant 1.5707963267948966 : f64
    %310 = qlx.apply #qlx.action<pauli_rotation>(%308#1, %cst_183) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %311:2 = qlx.apply #qlx.action<pauli_rotation>(%309, %310, %cst_184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %312 = qlx.apply #qlx.action<h>(%311#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_185 = arith.constant 3.1415926535897931 : f64
    %313 = qlx.apply #qlx.action<pauli_rotation>(%312, %cst_185) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %314 = qlx.apply #qlx.action<h>(%313) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %315 = qlx.apply #qlx.action<h>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_186 = arith.constant 1.5707963267948966 : f64
    %316:2 = qlx.apply #qlx.action<pauli_rotation>(%314, %315, %cst_186) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_187 = arith.constant 1.5707963267948966 : f64
    %317 = qlx.apply #qlx.action<pauli_rotation>(%316#0, %cst_187) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_188 = arith.constant 1.5707963267948966 : f64
    %318 = qlx.apply #qlx.action<pauli_rotation>(%316#1, %cst_188) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_189 = arith.constant 1.5707963267948966 : f64
    %319:2 = qlx.apply #qlx.action<pauli_rotation>(%317, %318, %cst_189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %320 = qlx.apply #qlx.action<h>(%319#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %321 = qlx.apply #qlx.action<pauli_rotation>(%320, %cst_190) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %322 = qlx.apply #qlx.action<h>(%321) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %323 = qlx.apply #qlx.action<h>(%301#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_191 = arith.constant 0.78539816339744828 : f64
    %324 = qlx.apply #qlx.action<pauli_rotation>(%323, %cst_191) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %325 = qlx.apply #qlx.action<h>(%324) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_192 = arith.constant 5.000000e-01 : f64
    %326:2 = qlx.apply #qlx.action<pauli_rotation>(%322, %325, %cst_192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %327 = qlx.apply #qlx.action<pauli_rotation>(%326#0, %cst_193) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_194 = arith.constant 1.5707963267948966 : f64
    %328 = qlx.apply #qlx.action<pauli_rotation>(%326#1, %cst_194) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_195 = arith.constant 5.000000e-01 : f64
    %329:2 = qlx.apply #qlx.action<pauli_rotation>(%327, %328, %cst_195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %330 = qlx.apply #qlx.action<h>(%319#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_196 = arith.constant 3.1415926535897931 : f64
    %331 = qlx.apply #qlx.action<pauli_rotation>(%330, %cst_196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %332 = qlx.apply #qlx.action<h>(%331) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.5707963267948966 : f64
    %333:2 = qlx.apply #qlx.action<pauli_rotation>(%329#0, %332, %cst_197) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_198 = arith.constant 1.5707963267948966 : f64
    %334 = qlx.apply #qlx.action<pauli_rotation>(%333#1, %cst_198) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_199 = arith.constant 1.5707963267948966 : f64
    %335 = qlx.apply #qlx.action<pauli_rotation>(%333#0, %cst_199) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_200 = arith.constant 1.5707963267948966 : f64
    %336:2 = qlx.apply #qlx.action<pauli_rotation>(%334, %335, %cst_200) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %337 = qlx.apply #qlx.action<h>(%311#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 3.1415926535897931 : f64
    %338 = qlx.apply #qlx.action<pauli_rotation>(%337, %cst_201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %339 = qlx.apply #qlx.action<h>(%338) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %340 = qlx.apply #qlx.action<h>(%336#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_202 = arith.constant 3.1415926535897931 : f64
    %341 = qlx.apply #qlx.action<pauli_rotation>(%340, %cst_202) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %342 = qlx.apply #qlx.action<h>(%341) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %343:2 = qlx.apply #qlx.action<pauli_rotation>(%339, %342, %cst_203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_204 = arith.constant 1.5707963267948966 : f64
    %344 = qlx.apply #qlx.action<pauli_rotation>(%343#0, %cst_204) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_205 = arith.constant 1.5707963267948966 : f64
    %345 = qlx.apply #qlx.action<pauli_rotation>(%343#1, %cst_205) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_206 = arith.constant 1.5707963267948966 : f64
    %346:2 = qlx.apply #qlx.action<pauli_rotation>(%344, %345, %cst_206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %347 = qlx.apply #qlx.action<h>(%292#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %348 = qlx.apply #qlx.action<pauli_rotation>(%347, %cst_207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %349 = qlx.apply #qlx.action<h>(%348) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %350 = qlx.apply #qlx.action<h>(%346#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_208 = arith.constant 2.3561944901923448 : f64
    %351 = qlx.apply #qlx.action<pauli_rotation>(%350, %cst_208) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %352 = qlx.apply #qlx.action<h>(%351) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_209 = arith.constant 0.78539816339744828 : f64
    %353:2 = qlx.apply #qlx.action<pauli_rotation>(%349, %352, %cst_209) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %354 = qlx.apply #qlx.action<pauli_rotation>(%353#0, %cst_210) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_211 = arith.constant 1.5707963267948966 : f64
    %355 = qlx.apply #qlx.action<pauli_rotation>(%353#1, %cst_211) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_212 = arith.constant 0.78539816339744828 : f64
    %356:2 = qlx.apply #qlx.action<pauli_rotation>(%354, %355, %cst_212) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %357 = qlx.apply #qlx.action<h>(%329#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 2.3561944901923448 : f64
    %358 = qlx.apply #qlx.action<pauli_rotation>(%357, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %359 = qlx.apply #qlx.action<h>(%358) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %360 = qlx.apply #qlx.action<h>(%301#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %361 = qlx.apply #qlx.action<pauli_rotation>(%360, %cst_214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %362 = qlx.apply #qlx.action<h>(%361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_215 = arith.constant 0.78539816339744828 : f64
    %363:2 = qlx.apply #qlx.action<pauli_rotation>(%359, %362, %cst_215) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %364 = qlx.apply #qlx.action<pauli_rotation>(%363#0, %cst_216) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_217 = arith.constant 1.5707963267948966 : f64
    %365 = qlx.apply #qlx.action<pauli_rotation>(%363#1, %cst_217) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_218 = arith.constant 0.78539816339744828 : f64
    %366:2 = qlx.apply #qlx.action<pauli_rotation>(%364, %365, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %367 = qlx.apply #qlx.action<h>(%346#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_219 = arith.constant 2.3561944901923448 : f64
    %368 = qlx.apply #qlx.action<pauli_rotation>(%367, %cst_219) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %369 = qlx.apply #qlx.action<h>(%368) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %370 = qlx.apply #qlx.action<h>(%336#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_220 = arith.constant 2.3561944901923448 : f64
    %371 = qlx.apply #qlx.action<pauli_rotation>(%370, %cst_220) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %372 = qlx.apply #qlx.action<h>(%371) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_221 = arith.constant 0.78539816339744828 : f64
    %373:2 = qlx.apply #qlx.action<pauli_rotation>(%369, %372, %cst_221) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_222 = arith.constant 1.5707963267948966 : f64
    %374 = qlx.apply #qlx.action<pauli_rotation>(%373#0, %cst_222) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_223 = arith.constant 1.5707963267948966 : f64
    %375 = qlx.apply #qlx.action<pauli_rotation>(%373#1, %cst_223) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_224 = arith.constant 0.78539816339744828 : f64
    %376:2 = qlx.apply #qlx.action<pauli_rotation>(%374, %375, %cst_224) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_225 = arith.constant 2.3561944901923448 : f64
    %377 = qlx.apply #qlx.action<pauli_rotation>(%277#1, %cst_225) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %378 = qlx.apply #qlx.action<h>(%377) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %379 = qlx.apply #qlx.action<h>(%272#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_226 = arith.constant 0.78539816339744828 : f64
    %380 = qlx.apply #qlx.action<pauli_rotation>(%379, %cst_226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %381 = qlx.apply #qlx.action<h>(%380) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_227 = arith.constant 0.78539816339744828 : f64
    %382:2 = qlx.apply #qlx.action<pauli_rotation>(%378, %381, %cst_227) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_228 = arith.constant 1.5707963267948966 : f64
    %383 = qlx.apply #qlx.action<pauli_rotation>(%382#0, %cst_228) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_229 = arith.constant 1.5707963267948966 : f64
    %384 = qlx.apply #qlx.action<pauli_rotation>(%382#1, %cst_229) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_230 = arith.constant 0.78539816339744828 : f64
    %385:2 = qlx.apply #qlx.action<pauli_rotation>(%383, %384, %cst_230) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %386 = qlx.apply #qlx.action<h>(%366#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_231 = arith.constant 2.3561944901923448 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%386, %cst_231) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %388 = qlx.apply #qlx.action<h>(%387) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %389 = qlx.apply #qlx.action<h>(%385#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_232 = arith.constant 0.78539816339744828 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%389, %cst_232) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_233 = arith.constant 1.5707963267948966 : f64
    %392:2 = qlx.apply #qlx.action<pauli_rotation>(%388, %391, %cst_233) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_234 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %cst_234) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_235 = arith.constant 1.5707963267948966 : f64
    %394 = qlx.apply #qlx.action<pauli_rotation>(%392#1, %cst_235) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_236 = arith.constant 1.5707963267948966 : f64
    %395:2 = qlx.apply #qlx.action<pauli_rotation>(%393, %394, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %396 = qlx.apply #qlx.action<h>(%366#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_237 = arith.constant 2.3561944901923448 : f64
    %397 = qlx.apply #qlx.action<pauli_rotation>(%396, %cst_237) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %398 = qlx.apply #qlx.action<h>(%397) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %399 = qlx.apply #qlx.action<h>(%395#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_238 = arith.constant 3.1415926535897931 : f64
    %400 = qlx.apply #qlx.action<pauli_rotation>(%399, %cst_238) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %401 = qlx.apply #qlx.action<h>(%400) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %402:2 = qlx.apply #qlx.action<pauli_rotation>(%398, %401, %cst_239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_240 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%402#0, %cst_240) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_241 = arith.constant 1.5707963267948966 : f64
    %404 = qlx.apply #qlx.action<pauli_rotation>(%402#1, %cst_241) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_242 = arith.constant 1.5707963267948966 : f64
    %405:2 = qlx.apply #qlx.action<pauli_rotation>(%403, %404, %cst_242) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %406 = qlx.apply #qlx.action<h>(%376#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_243 = arith.constant 2.3561944901923448 : f64
    %407 = qlx.apply #qlx.action<pauli_rotation>(%406, %cst_243) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %408 = qlx.apply #qlx.action<h>(%407) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %409 = qlx.apply #qlx.action<h>(%405#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_244 = arith.constant 1.5707963267948966 : f64
    %410 = qlx.apply #qlx.action<pauli_rotation>(%409, %cst_244) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %411 = qlx.apply #qlx.action<h>(%410) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_245 = arith.constant 5.000000e-01 : f64
    %412:2 = qlx.apply #qlx.action<pauli_rotation>(%408, %411, %cst_245) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_246 = arith.constant 1.5707963267948966 : f64
    %413 = qlx.apply #qlx.action<pauli_rotation>(%412#0, %cst_246) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_247 = arith.constant 1.5707963267948966 : f64
    %414 = qlx.apply #qlx.action<pauli_rotation>(%412#1, %cst_247) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_248 = arith.constant 5.000000e-01 : f64
    %415:2 = qlx.apply #qlx.action<pauli_rotation>(%413, %414, %cst_248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %416 = qlx.apply #qlx.action<h>(%376#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_249 = arith.constant 1.5707963267948966 : f64
    %417 = qlx.apply #qlx.action<pauli_rotation>(%416, %cst_249) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %418 = qlx.apply #qlx.action<h>(%417) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %419 = qlx.apply #qlx.action<h>(%415#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_250 = arith.constant 0.78539816339744828 : f64
    %420 = qlx.apply #qlx.action<pauli_rotation>(%419, %cst_250) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %421 = qlx.apply #qlx.action<h>(%420) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_251 = arith.constant 0.78539816339744828 : f64
    %422:2 = qlx.apply #qlx.action<pauli_rotation>(%418, %421, %cst_251) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_252 = arith.constant 1.5707963267948966 : f64
    %423 = qlx.apply #qlx.action<pauli_rotation>(%422#0, %cst_252) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_253 = arith.constant 1.5707963267948966 : f64
    %424 = qlx.apply #qlx.action<pauli_rotation>(%422#1, %cst_253) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_254 = arith.constant 0.78539816339744828 : f64
    %425:2 = qlx.apply #qlx.action<pauli_rotation>(%423, %424, %cst_254) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %426 = qlx.apply #qlx.action<h>(%415#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_255 = arith.constant 3.1415926535897931 : f64
    %427 = qlx.apply #qlx.action<pauli_rotation>(%426, %cst_255) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %428 = qlx.apply #qlx.action<h>(%427) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %429 = qlx.apply #qlx.action<h>(%405#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_256 = arith.constant 3.1415926535897931 : f64
    %430 = qlx.apply #qlx.action<pauli_rotation>(%429, %cst_256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %431 = qlx.apply #qlx.action<h>(%430) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %432:2 = qlx.apply #qlx.action<pauli_rotation>(%428, %431, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_258 = arith.constant 1.5707963267948966 : f64
    %433 = qlx.apply #qlx.action<pauli_rotation>(%432#0, %cst_258) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_259 = arith.constant 1.5707963267948966 : f64
    %434 = qlx.apply #qlx.action<pauli_rotation>(%432#1, %cst_259) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %435:2 = qlx.apply #qlx.action<pauli_rotation>(%433, %434, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %436 = qlx.apply #qlx.action<h>(%435#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_261 = arith.constant 3.1415926535897931 : f64
    %437 = qlx.apply #qlx.action<pauli_rotation>(%436, %cst_261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %438 = qlx.apply #qlx.action<h>(%437) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %439 = qlx.apply #qlx.action<h>(%395#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_262 = arith.constant 3.1415926535897931 : f64
    %440 = qlx.apply #qlx.action<pauli_rotation>(%439, %cst_262) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %441 = qlx.apply #qlx.action<h>(%440) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %442:2 = qlx.apply #qlx.action<pauli_rotation>(%438, %441, %cst_263) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_264 = arith.constant 1.5707963267948966 : f64
    %443 = qlx.apply #qlx.action<pauli_rotation>(%442#0, %cst_264) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_265 = arith.constant 1.5707963267948966 : f64
    %444 = qlx.apply #qlx.action<pauli_rotation>(%442#1, %cst_265) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_266 = arith.constant 1.5707963267948966 : f64
    %445:2 = qlx.apply #qlx.action<pauli_rotation>(%443, %444, %cst_266) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %446 = qlx.apply #qlx.action<h>(%445#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_267 = arith.constant 2.3561944901923448 : f64
    %447 = qlx.apply #qlx.action<pauli_rotation>(%446, %cst_267) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %448 = qlx.apply #qlx.action<h>(%447) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %449 = qlx.apply #qlx.action<h>(%385#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %450 = qlx.apply #qlx.action<pauli_rotation>(%449, %cst_268) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %451 = qlx.apply #qlx.action<h>(%450) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_269 = arith.constant 0.78539816339744828 : f64
    %452:2 = qlx.apply #qlx.action<pauli_rotation>(%448, %451, %cst_269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_270 = arith.constant 1.5707963267948966 : f64
    %453 = qlx.apply #qlx.action<pauli_rotation>(%452#0, %cst_270) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_271 = arith.constant 1.5707963267948966 : f64
    %454 = qlx.apply #qlx.action<pauli_rotation>(%452#1, %cst_271) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_272 = arith.constant 0.78539816339744828 : f64
    %455:2 = qlx.apply #qlx.action<pauli_rotation>(%453, %454, %cst_272) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %456 = qlx.apply #qlx.action<h>(%356#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_273 = arith.constant 2.3561944901923448 : f64
    %457 = qlx.apply #qlx.action<pauli_rotation>(%456, %cst_273) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %458 = qlx.apply #qlx.action<h>(%457) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %459 = qlx.apply #qlx.action<h>(%425#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_274 = arith.constant 2.3561944901923448 : f64
    %460 = qlx.apply #qlx.action<pauli_rotation>(%459, %cst_274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %461 = qlx.apply #qlx.action<h>(%460) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.5707963267948966 : f64
    %462:2 = qlx.apply #qlx.action<pauli_rotation>(%458, %461, %cst_275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %463 = qlx.apply #qlx.action<pauli_rotation>(%462#0, %cst_276) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_277 = arith.constant 1.5707963267948966 : f64
    %464 = qlx.apply #qlx.action<pauli_rotation>(%462#1, %cst_277) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_278 = arith.constant 1.5707963267948966 : f64
    %465:2 = qlx.apply #qlx.action<pauli_rotation>(%463, %464, %cst_278) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %466 = qlx.apply #qlx.action<h>(%356#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_279 = arith.constant 2.3561944901923448 : f64
    %467 = qlx.apply #qlx.action<pauli_rotation>(%466, %cst_279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %468 = qlx.apply #qlx.action<h>(%465#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_280 = arith.constant 3.1415926535897931 : f64
    %469 = qlx.apply #qlx.action<pauli_rotation>(%468, %cst_280) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_281 = arith.constant 5.000000e-01 : f64
    %470:2 = qlx.apply #qlx.action<pauli_rotation>(%467, %469, %cst_281) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %471 = qlx.apply #qlx.action<h>(%445#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_282 = arith.constant 3.1415926535897931 : f64
    %472 = qlx.apply #qlx.action<pauli_rotation>(%471, %cst_282) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %473 = qlx.apply #qlx.action<h>(%472) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %474 = qlx.apply #qlx.action<h>(%455#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_283 = arith.constant 2.3561944901923448 : f64
    %475 = qlx.apply #qlx.action<pauli_rotation>(%474, %cst_283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %476 = qlx.apply #qlx.action<h>(%475) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_284 = arith.constant 1.5707963267948966 : f64
    %477:2 = qlx.apply #qlx.action<pauli_rotation>(%473, %476, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_285 = arith.constant 1.5707963267948966 : f64
    %478 = qlx.apply #qlx.action<pauli_rotation>(%477#0, %cst_285) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %479 = qlx.apply #qlx.action<pauli_rotation>(%477#1, %cst_286) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.5707963267948966 : f64
    %480:2 = qlx.apply #qlx.action<pauli_rotation>(%478, %479, %cst_287) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %481 = qlx.apply #qlx.action<h>(%435#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_288 = arith.constant 3.1415926535897931 : f64
    %482 = qlx.apply #qlx.action<pauli_rotation>(%481, %cst_288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %483 = qlx.apply #qlx.action<h>(%480#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 3.1415926535897931 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%483, %cst_289) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_290 = arith.constant 5.000000e-01 : f64
    %485:2 = qlx.apply #qlx.action<pauli_rotation>(%482, %484, %cst_290) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %486 = qlx.apply #qlx.action<h>(%465#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_291 = arith.constant 3.1415926535897931 : f64
    %487 = qlx.apply #qlx.action<pauli_rotation>(%486, %cst_291) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %488 = qlx.apply #qlx.action<h>(%425#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_292 = arith.constant 2.3561944901923448 : f64
    %489 = qlx.apply #qlx.action<pauli_rotation>(%488, %cst_292) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_293 = arith.constant 5.000000e-01 : f64
    %490:2 = qlx.apply #qlx.action<pauli_rotation>(%487, %489, %cst_293) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %491 = qlx.apply #qlx.action<h>(%480#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_294 = arith.constant 3.1415926535897931 : f64
    %492 = qlx.apply #qlx.action<pauli_rotation>(%491, %cst_294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %493 = qlx.apply #qlx.action<h>(%455#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 2.3561944901923448 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_296 = arith.constant 5.000000e-01 : f64
    %495:2 = qlx.apply #qlx.action<pauli_rotation>(%492, %494, %cst_296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %496 = qlx.apply #qlx.action<h>(%470#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %497 = qlx.apply #qlx.action<h>(%490#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_297 = arith.constant 1.5707963267948966 : f64
    %498:2 = qlx.apply #qlx.action<pauli_rotation>(%496, %497, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %499 = qlx.apply #qlx.action<pauli_rotation>(%498#0, %cst_298) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%498#1, %cst_299) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_300 = arith.constant 1.5707963267948966 : f64
    %501:2 = qlx.apply #qlx.action<pauli_rotation>(%499, %500, %cst_300) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_301 = arith.constant 0.78539816339744828 : f64
    %502 = qlx.apply #qlx.action<pauli_rotation>(%470#0, %cst_301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %503 = qlx.apply #qlx.action<h>(%502) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %504 = qlx.apply #qlx.action<h>(%501#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_302 = arith.constant 2.3561944901923448 : f64
    %505 = qlx.apply #qlx.action<pauli_rotation>(%504, %cst_302) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %506 = qlx.apply #qlx.action<h>(%505) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_303 = arith.constant 0.78539816339744828 : f64
    %507:2 = qlx.apply #qlx.action<pauli_rotation>(%503, %506, %cst_303) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %508 = qlx.apply #qlx.action<pauli_rotation>(%507#0, %cst_304) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %509 = qlx.apply #qlx.action<pauli_rotation>(%507#1, %cst_305) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_306 = arith.constant 0.78539816339744828 : f64
    %510:2 = qlx.apply #qlx.action<pauli_rotation>(%508, %509, %cst_306) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %511 = qlx.apply #qlx.action<h>(%485#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %512 = qlx.apply #qlx.action<h>(%495#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 1.5707963267948966 : f64
    %513:2 = qlx.apply #qlx.action<pauli_rotation>(%511, %512, %cst_307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %514 = qlx.apply #qlx.action<pauli_rotation>(%513#0, %cst_308) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_309 = arith.constant 1.5707963267948966 : f64
    %515 = qlx.apply #qlx.action<pauli_rotation>(%513#1, %cst_309) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %516:2 = qlx.apply #qlx.action<pauli_rotation>(%514, %515, %cst_310) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_311 = arith.constant 0.78539816339744828 : f64
    %517 = qlx.apply #qlx.action<pauli_rotation>(%485#0, %cst_311) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %518 = qlx.apply #qlx.action<h>(%517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %519 = qlx.apply #qlx.action<h>(%516#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_312 = arith.constant 2.3561944901923448 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%519, %cst_312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %521 = qlx.apply #qlx.action<h>(%520) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 0.78539816339744828 : f64
    %522:2 = qlx.apply #qlx.action<pauli_rotation>(%518, %521, %cst_313) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_314 = arith.constant 1.5707963267948966 : f64
    %523 = qlx.apply #qlx.action<pauli_rotation>(%522#0, %cst_314) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_315 = arith.constant 1.5707963267948966 : f64
    %524 = qlx.apply #qlx.action<pauli_rotation>(%522#1, %cst_315) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_316 = arith.constant 0.78539816339744828 : f64
    %525:2 = qlx.apply #qlx.action<pauli_rotation>(%523, %524, %cst_316) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %526 = qlx.apply #qlx.action<h>(%510#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_317 = arith.constant 2.3561944901923448 : f64
    %527 = qlx.apply #qlx.action<pauli_rotation>(%526, %cst_317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %528 = qlx.apply #qlx.action<h>(%527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %529 = qlx.apply #qlx.action<h>(%501#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_318 = arith.constant 3.1415926535897931 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%529, %cst_318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %531 = qlx.apply #qlx.action<h>(%530) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 1.5707963267948966 : f64
    %532:2 = qlx.apply #qlx.action<pauli_rotation>(%528, %531, %cst_319) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_320 = arith.constant 1.5707963267948966 : f64
    %533 = qlx.apply #qlx.action<pauli_rotation>(%532#0, %cst_320) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_321 = arith.constant 1.5707963267948966 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%532#1, %cst_321) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %535:2 = qlx.apply #qlx.action<pauli_rotation>(%533, %534, %cst_322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %536 = qlx.apply #qlx.action<h>(%535#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_323 = arith.constant 3.1415926535897931 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%536, %cst_323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %538 = qlx.apply #qlx.action<h>(%537) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %539 = qlx.apply #qlx.action<h>(%490#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_324 = arith.constant 1.5707963267948966 : f64
    %540:2 = qlx.apply #qlx.action<pauli_rotation>(%538, %539, %cst_324) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_325 = arith.constant 1.5707963267948966 : f64
    %541 = qlx.apply #qlx.action<pauli_rotation>(%540#0, %cst_325) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_326 = arith.constant 1.5707963267948966 : f64
    %542 = qlx.apply #qlx.action<pauli_rotation>(%540#1, %cst_326) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_327 = arith.constant 1.5707963267948966 : f64
    %543:2 = qlx.apply #qlx.action<pauli_rotation>(%541, %542, %cst_327) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %544 = qlx.apply #qlx.action<h>(%543#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %545 = qlx.apply #qlx.action<pauli_rotation>(%544, %cst_328) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %546 = qlx.apply #qlx.action<h>(%545) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %547 = qlx.apply #qlx.action<h>(%525#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_329 = arith.constant 0.78539816339744828 : f64
    %548 = qlx.apply #qlx.action<pauli_rotation>(%547, %cst_329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %549 = qlx.apply #qlx.action<h>(%548) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_330 = arith.constant 5.000000e-01 : f64
    %550:2 = qlx.apply #qlx.action<pauli_rotation>(%546, %549, %cst_330) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_331 = arith.constant 1.5707963267948966 : f64
    %551 = qlx.apply #qlx.action<pauli_rotation>(%550#0, %cst_331) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_332 = arith.constant 1.5707963267948966 : f64
    %552 = qlx.apply #qlx.action<pauli_rotation>(%550#1, %cst_332) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_333 = arith.constant 5.000000e-01 : f64
    %553:2 = qlx.apply #qlx.action<pauli_rotation>(%551, %552, %cst_333) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %554 = qlx.apply #qlx.action<h>(%543#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_334 = arith.constant 3.1415926535897931 : f64
    %555 = qlx.apply #qlx.action<pauli_rotation>(%554, %cst_334) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %556 = qlx.apply #qlx.action<h>(%555) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %557:2 = qlx.apply #qlx.action<pauli_rotation>(%553#0, %556, %cst_335) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_336 = arith.constant 1.5707963267948966 : f64
    %558 = qlx.apply #qlx.action<pauli_rotation>(%557#1, %cst_336) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_337 = arith.constant 1.5707963267948966 : f64
    %559 = qlx.apply #qlx.action<pauli_rotation>(%557#0, %cst_337) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %560:2 = qlx.apply #qlx.action<pauli_rotation>(%558, %559, %cst_338) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %561 = qlx.apply #qlx.action<h>(%535#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_339 = arith.constant 3.1415926535897931 : f64
    %562 = qlx.apply #qlx.action<pauli_rotation>(%561, %cst_339) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %563 = qlx.apply #qlx.action<h>(%562) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %564 = qlx.apply #qlx.action<h>(%560#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_340 = arith.constant 3.1415926535897931 : f64
    %565 = qlx.apply #qlx.action<pauli_rotation>(%564, %cst_340) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %566 = qlx.apply #qlx.action<h>(%565) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %567:2 = qlx.apply #qlx.action<pauli_rotation>(%563, %566, %cst_341) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_342 = arith.constant 1.5707963267948966 : f64
    %568 = qlx.apply #qlx.action<pauli_rotation>(%567#0, %cst_342) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_343 = arith.constant 1.5707963267948966 : f64
    %569 = qlx.apply #qlx.action<pauli_rotation>(%567#1, %cst_343) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_344 = arith.constant 1.5707963267948966 : f64
    %570:2 = qlx.apply #qlx.action<pauli_rotation>(%568, %569, %cst_344) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %571 = qlx.apply #qlx.action<h>(%510#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %572 = qlx.apply #qlx.action<pauli_rotation>(%571, %cst_345) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %573 = qlx.apply #qlx.action<h>(%572) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %574 = qlx.apply #qlx.action<h>(%570#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_346 = arith.constant 2.3561944901923448 : f64
    %575 = qlx.apply #qlx.action<pauli_rotation>(%574, %cst_346) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %576 = qlx.apply #qlx.action<h>(%575) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_347 = arith.constant 0.78539816339744828 : f64
    %577:2 = qlx.apply #qlx.action<pauli_rotation>(%573, %576, %cst_347) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %578 = qlx.apply #qlx.action<pauli_rotation>(%577#0, %cst_348) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_349 = arith.constant 1.5707963267948966 : f64
    %579 = qlx.apply #qlx.action<pauli_rotation>(%577#1, %cst_349) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_350 = arith.constant 0.78539816339744828 : f64
    %580:2 = qlx.apply #qlx.action<pauli_rotation>(%578, %579, %cst_350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %581 = qlx.apply #qlx.action<h>(%553#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_351 = arith.constant 2.3561944901923448 : f64
    %582 = qlx.apply #qlx.action<pauli_rotation>(%581, %cst_351) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %583 = qlx.apply #qlx.action<h>(%582) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %584 = qlx.apply #qlx.action<h>(%525#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %585 = qlx.apply #qlx.action<pauli_rotation>(%584, %cst_352) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %586 = qlx.apply #qlx.action<h>(%585) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_353 = arith.constant 0.78539816339744828 : f64
    %587:2 = qlx.apply #qlx.action<pauli_rotation>(%583, %586, %cst_353) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %588 = qlx.apply #qlx.action<pauli_rotation>(%587#0, %cst_354) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_355 = arith.constant 1.5707963267948966 : f64
    %589 = qlx.apply #qlx.action<pauli_rotation>(%587#1, %cst_355) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_356 = arith.constant 0.78539816339744828 : f64
    %590:2 = qlx.apply #qlx.action<pauli_rotation>(%588, %589, %cst_356) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %591 = qlx.apply #qlx.action<h>(%570#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_357 = arith.constant 2.3561944901923448 : f64
    %592 = qlx.apply #qlx.action<pauli_rotation>(%591, %cst_357) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %593 = qlx.apply #qlx.action<h>(%592) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %594 = qlx.apply #qlx.action<h>(%560#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_358 = arith.constant 2.3561944901923448 : f64
    %595 = qlx.apply #qlx.action<pauli_rotation>(%594, %cst_358) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %596 = qlx.apply #qlx.action<h>(%595) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_359 = arith.constant 0.78539816339744828 : f64
    %597:2 = qlx.apply #qlx.action<pauli_rotation>(%593, %596, %cst_359) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %598 = qlx.apply #qlx.action<pauli_rotation>(%597#0, %cst_360) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_361 = arith.constant 1.5707963267948966 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%597#1, %cst_361) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_362 = arith.constant 0.78539816339744828 : f64
    %600:2 = qlx.apply #qlx.action<pauli_rotation>(%598, %599, %cst_362) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %601 = qlx.apply #qlx.action<h>(%516#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_363 = arith.constant 2.3561944901923448 : f64
    %602 = qlx.apply #qlx.action<pauli_rotation>(%601, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %603 = qlx.apply #qlx.action<h>(%602) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_364 = arith.constant 0.78539816339744828 : f64
    %604 = qlx.apply #qlx.action<pauli_rotation>(%495#1, %cst_364) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %605 = qlx.apply #qlx.action<h>(%604) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_365 = arith.constant 0.78539816339744828 : f64
    %606:2 = qlx.apply #qlx.action<pauli_rotation>(%603, %605, %cst_365) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %607 = qlx.apply #qlx.action<pauli_rotation>(%606#0, %cst_366) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_367 = arith.constant 1.5707963267948966 : f64
    %608 = qlx.apply #qlx.action<pauli_rotation>(%606#1, %cst_367) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_368 = arith.constant 0.78539816339744828 : f64
    %609:2 = qlx.apply #qlx.action<pauli_rotation>(%607, %608, %cst_368) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %610 = qlx.apply #qlx.action<h>(%590#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_369 = arith.constant 2.3561944901923448 : f64
    %611 = qlx.apply #qlx.action<pauli_rotation>(%610, %cst_369) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %612 = qlx.apply #qlx.action<h>(%611) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %613 = qlx.apply #qlx.action<h>(%609#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_370 = arith.constant 2.3561944901923448 : f64
    %614 = qlx.apply #qlx.action<pauli_rotation>(%613, %cst_370) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %615 = qlx.apply #qlx.action<h>(%614) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %616:2 = qlx.apply #qlx.action<pauli_rotation>(%612, %615, %cst_371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_372 = arith.constant 1.5707963267948966 : f64
    %617 = qlx.apply #qlx.action<pauli_rotation>(%616#0, %cst_372) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_373 = arith.constant 1.5707963267948966 : f64
    %618 = qlx.apply #qlx.action<pauli_rotation>(%616#1, %cst_373) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_374 = arith.constant 1.5707963267948966 : f64
    %619:2 = qlx.apply #qlx.action<pauli_rotation>(%617, %618, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %620 = qlx.apply #qlx.action<h>(%590#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_375 = arith.constant 2.3561944901923448 : f64
    %621 = qlx.apply #qlx.action<pauli_rotation>(%620, %cst_375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %622 = qlx.apply #qlx.action<h>(%621) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %623 = qlx.apply #qlx.action<h>(%619#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_376 = arith.constant 3.1415926535897931 : f64
    %624 = qlx.apply #qlx.action<pauli_rotation>(%623, %cst_376) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %625 = qlx.apply #qlx.action<h>(%624) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %626:2 = qlx.apply #qlx.action<pauli_rotation>(%622, %625, %cst_377) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_378 = arith.constant 1.5707963267948966 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%626#0, %cst_378) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_379 = arith.constant 1.5707963267948966 : f64
    %628 = qlx.apply #qlx.action<pauli_rotation>(%626#1, %cst_379) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_380 = arith.constant 1.5707963267948966 : f64
    %629:2 = qlx.apply #qlx.action<pauli_rotation>(%627, %628, %cst_380) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %630 = qlx.apply #qlx.action<h>(%600#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_381 = arith.constant 2.3561944901923448 : f64
    %631 = qlx.apply #qlx.action<pauli_rotation>(%630, %cst_381) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %632 = qlx.apply #qlx.action<h>(%631) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %633 = qlx.apply #qlx.action<h>(%629#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_382 = arith.constant 1.5707963267948966 : f64
    %634 = qlx.apply #qlx.action<pauli_rotation>(%633, %cst_382) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %635 = qlx.apply #qlx.action<h>(%634) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_383 = arith.constant 5.000000e-01 : f64
    %636:2 = qlx.apply #qlx.action<pauli_rotation>(%632, %635, %cst_383) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_384 = arith.constant 1.5707963267948966 : f64
    %637 = qlx.apply #qlx.action<pauli_rotation>(%636#0, %cst_384) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_385 = arith.constant 1.5707963267948966 : f64
    %638 = qlx.apply #qlx.action<pauli_rotation>(%636#1, %cst_385) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_386 = arith.constant 5.000000e-01 : f64
    %639:2 = qlx.apply #qlx.action<pauli_rotation>(%637, %638, %cst_386) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %640 = qlx.apply #qlx.action<h>(%600#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_387 = arith.constant 1.5707963267948966 : f64
    %641 = qlx.apply #qlx.action<pauli_rotation>(%640, %cst_387) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %642 = qlx.apply #qlx.action<h>(%641) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %643 = qlx.apply #qlx.action<h>(%639#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_388 = arith.constant 0.78539816339744828 : f64
    %644 = qlx.apply #qlx.action<pauli_rotation>(%643, %cst_388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %645 = qlx.apply #qlx.action<h>(%644) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_389 = arith.constant 0.78539816339744828 : f64
    %646:2 = qlx.apply #qlx.action<pauli_rotation>(%642, %645, %cst_389) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_390 = arith.constant 1.5707963267948966 : f64
    %647 = qlx.apply #qlx.action<pauli_rotation>(%646#0, %cst_390) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %648 = qlx.apply #qlx.action<pauli_rotation>(%646#1, %cst_391) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_392 = arith.constant 0.78539816339744828 : f64
    %649:2 = qlx.apply #qlx.action<pauli_rotation>(%647, %648, %cst_392) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %650 = qlx.apply #qlx.action<h>(%639#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_393 = arith.constant 3.1415926535897931 : f64
    %651 = qlx.apply #qlx.action<pauli_rotation>(%650, %cst_393) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %652 = qlx.apply #qlx.action<h>(%651) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %653 = qlx.apply #qlx.action<h>(%629#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_394 = arith.constant 3.1415926535897931 : f64
    %654 = qlx.apply #qlx.action<pauli_rotation>(%653, %cst_394) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %655 = qlx.apply #qlx.action<h>(%654) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_395 = arith.constant 1.5707963267948966 : f64
    %656:2 = qlx.apply #qlx.action<pauli_rotation>(%652, %655, %cst_395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_396 = arith.constant 1.5707963267948966 : f64
    %657 = qlx.apply #qlx.action<pauli_rotation>(%656#0, %cst_396) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %658 = qlx.apply #qlx.action<pauli_rotation>(%656#1, %cst_397) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %659:2 = qlx.apply #qlx.action<pauli_rotation>(%657, %658, %cst_398) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %660 = qlx.apply #qlx.action<h>(%659#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_399 = arith.constant 3.1415926535897931 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%660, %cst_399) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %662 = qlx.apply #qlx.action<h>(%661) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %663 = qlx.apply #qlx.action<h>(%619#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_400 = arith.constant 3.1415926535897931 : f64
    %664 = qlx.apply #qlx.action<pauli_rotation>(%663, %cst_400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.5707963267948966 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%662, %665, %cst_401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%666#0, %cst_402) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_403 = arith.constant 1.5707963267948966 : f64
    %668 = qlx.apply #qlx.action<pauli_rotation>(%666#1, %cst_403) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_404 = arith.constant 1.5707963267948966 : f64
    %669:2 = qlx.apply #qlx.action<pauli_rotation>(%667, %668, %cst_404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %670 = qlx.apply #qlx.action<h>(%669#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_405 = arith.constant 2.3561944901923448 : f64
    %671 = qlx.apply #qlx.action<pauli_rotation>(%670, %cst_405) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %672 = qlx.apply #qlx.action<h>(%671) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %673 = qlx.apply #qlx.action<h>(%609#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_406 = arith.constant 1.5707963267948966 : f64
    %674 = qlx.apply #qlx.action<pauli_rotation>(%673, %cst_406) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %675 = qlx.apply #qlx.action<h>(%674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_407 = arith.constant 0.78539816339744828 : f64
    %676:2 = qlx.apply #qlx.action<pauli_rotation>(%672, %675, %cst_407) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676#0, %cst_408) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_409 = arith.constant 1.5707963267948966 : f64
    %678 = qlx.apply #qlx.action<pauli_rotation>(%676#1, %cst_409) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_410 = arith.constant 0.78539816339744828 : f64
    %679:2 = qlx.apply #qlx.action<pauli_rotation>(%677, %678, %cst_410) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %680 = qlx.apply #qlx.action<h>(%580#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 2.3561944901923448 : f64
    %681 = qlx.apply #qlx.action<pauli_rotation>(%680, %cst_411) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %682 = qlx.apply #qlx.action<h>(%681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %683 = qlx.apply #qlx.action<h>(%649#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_412 = arith.constant 2.3561944901923448 : f64
    %684 = qlx.apply #qlx.action<pauli_rotation>(%683, %cst_412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %685 = qlx.apply #qlx.action<h>(%684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %686:2 = qlx.apply #qlx.action<pauli_rotation>(%682, %685, %cst_413) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686#0, %cst_414) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_415 = arith.constant 1.5707963267948966 : f64
    %688 = qlx.apply #qlx.action<pauli_rotation>(%686#1, %cst_415) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_416 = arith.constant 1.5707963267948966 : f64
    %689:2 = qlx.apply #qlx.action<pauli_rotation>(%687, %688, %cst_416) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %690 = qlx.apply #qlx.action<h>(%580#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_417 = arith.constant 2.3561944901923448 : f64
    %691 = qlx.apply #qlx.action<pauli_rotation>(%690, %cst_417) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %692 = qlx.apply #qlx.action<h>(%689#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_418 = arith.constant 3.1415926535897931 : f64
    %693 = qlx.apply #qlx.action<pauli_rotation>(%692, %cst_418) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_419 = arith.constant 5.000000e-01 : f64
    %694:2 = qlx.apply #qlx.action<pauli_rotation>(%691, %693, %cst_419) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %695 = qlx.apply #qlx.action<h>(%669#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_420 = arith.constant 3.1415926535897931 : f64
    %696 = qlx.apply #qlx.action<pauli_rotation>(%695, %cst_420) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %697 = qlx.apply #qlx.action<h>(%696) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %698 = qlx.apply #qlx.action<h>(%679#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_421 = arith.constant 2.3561944901923448 : f64
    %699 = qlx.apply #qlx.action<pauli_rotation>(%698, %cst_421) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %700 = qlx.apply #qlx.action<h>(%699) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 1.5707963267948966 : f64
    %701:2 = qlx.apply #qlx.action<pauli_rotation>(%697, %700, %cst_422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_423 = arith.constant 1.5707963267948966 : f64
    %702 = qlx.apply #qlx.action<pauli_rotation>(%701#0, %cst_423) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %703 = qlx.apply #qlx.action<pauli_rotation>(%701#1, %cst_424) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %704:2 = qlx.apply #qlx.action<pauli_rotation>(%702, %703, %cst_425) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %705 = qlx.apply #qlx.action<h>(%659#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_426 = arith.constant 3.1415926535897931 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705, %cst_426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %707 = qlx.apply #qlx.action<h>(%704#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 3.1415926535897931 : f64
    %708 = qlx.apply #qlx.action<pauli_rotation>(%707, %cst_427) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_428 = arith.constant 5.000000e-01 : f64
    %709:2 = qlx.apply #qlx.action<pauli_rotation>(%706, %708, %cst_428) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %710 = qlx.apply #qlx.action<h>(%689#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_429 = arith.constant 3.1415926535897931 : f64
    %711 = qlx.apply #qlx.action<pauli_rotation>(%710, %cst_429) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%649#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_430 = arith.constant 2.3561944901923448 : f64
    %713 = qlx.apply #qlx.action<pauli_rotation>(%712, %cst_430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_431 = arith.constant 5.000000e-01 : f64
    %714:2 = qlx.apply #qlx.action<pauli_rotation>(%711, %713, %cst_431) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %715 = qlx.apply #qlx.action<h>(%704#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_432 = arith.constant 3.1415926535897931 : f64
    %716 = qlx.apply #qlx.action<pauli_rotation>(%715, %cst_432) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %717 = qlx.apply #qlx.action<h>(%679#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_433 = arith.constant 2.3561944901923448 : f64
    %718 = qlx.apply #qlx.action<pauli_rotation>(%717, %cst_433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_434 = arith.constant 5.000000e-01 : f64
    %719:2 = qlx.apply #qlx.action<pauli_rotation>(%716, %718, %cst_434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %720 = qlx.apply #qlx.action<h>(%694#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %721 = qlx.apply #qlx.action<h>(%714#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_435 = arith.constant 1.5707963267948966 : f64
    %722:2 = qlx.apply #qlx.action<pauli_rotation>(%720, %721, %cst_435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_436 = arith.constant 1.5707963267948966 : f64
    %723 = qlx.apply #qlx.action<pauli_rotation>(%722#0, %cst_436) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %724 = qlx.apply #qlx.action<pauli_rotation>(%722#1, %cst_437) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_438 = arith.constant 1.5707963267948966 : f64
    %725:2 = qlx.apply #qlx.action<pauli_rotation>(%723, %724, %cst_438) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_439 = arith.constant 0.78539816339744828 : f64
    %726 = qlx.apply #qlx.action<pauli_rotation>(%694#0, %cst_439) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %727 = qlx.apply #qlx.action<h>(%726) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %728 = qlx.apply #qlx.action<h>(%725#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_440 = arith.constant 2.3561944901923448 : f64
    %729 = qlx.apply #qlx.action<pauli_rotation>(%728, %cst_440) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %730 = qlx.apply #qlx.action<h>(%729) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 0.78539816339744828 : f64
    %731:2 = qlx.apply #qlx.action<pauli_rotation>(%727, %730, %cst_441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %732 = qlx.apply #qlx.action<pauli_rotation>(%731#0, %cst_442) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %733 = qlx.apply #qlx.action<pauli_rotation>(%731#1, %cst_443) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_444 = arith.constant 0.78539816339744828 : f64
    %734:2 = qlx.apply #qlx.action<pauli_rotation>(%732, %733, %cst_444) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %735 = qlx.apply #qlx.action<h>(%709#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %736 = qlx.apply #qlx.action<h>(%719#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_445 = arith.constant 1.5707963267948966 : f64
    %737:2 = qlx.apply #qlx.action<pauli_rotation>(%735, %736, %cst_445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_446 = arith.constant 1.5707963267948966 : f64
    %738 = qlx.apply #qlx.action<pauli_rotation>(%737#0, %cst_446) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_447 = arith.constant 1.5707963267948966 : f64
    %739 = qlx.apply #qlx.action<pauli_rotation>(%737#1, %cst_447) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_448 = arith.constant 1.5707963267948966 : f64
    %740:2 = qlx.apply #qlx.action<pauli_rotation>(%738, %739, %cst_448) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_449 = arith.constant 0.78539816339744828 : f64
    %741 = qlx.apply #qlx.action<pauli_rotation>(%709#0, %cst_449) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%741) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %743 = qlx.apply #qlx.action<h>(%740#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_450 = arith.constant 2.3561944901923448 : f64
    %744 = qlx.apply #qlx.action<pauli_rotation>(%743, %cst_450) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %745 = qlx.apply #qlx.action<h>(%744) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_451 = arith.constant 0.78539816339744828 : f64
    %746:2 = qlx.apply #qlx.action<pauli_rotation>(%742, %745, %cst_451) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_452 = arith.constant 1.5707963267948966 : f64
    %747 = qlx.apply #qlx.action<pauli_rotation>(%746#0, %cst_452) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_453 = arith.constant 1.5707963267948966 : f64
    %748 = qlx.apply #qlx.action<pauli_rotation>(%746#1, %cst_453) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_454 = arith.constant 0.78539816339744828 : f64
    %749:2 = qlx.apply #qlx.action<pauli_rotation>(%747, %748, %cst_454) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %750 = qlx.apply #qlx.action<h>(%734#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_455 = arith.constant 2.3561944901923448 : f64
    %751 = qlx.apply #qlx.action<pauli_rotation>(%750, %cst_455) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %752 = qlx.apply #qlx.action<h>(%751) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %753 = qlx.apply #qlx.action<h>(%725#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_456 = arith.constant 3.1415926535897931 : f64
    %754 = qlx.apply #qlx.action<pauli_rotation>(%753, %cst_456) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %755 = qlx.apply #qlx.action<h>(%754) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 1.5707963267948966 : f64
    %756:2 = qlx.apply #qlx.action<pauli_rotation>(%752, %755, %cst_457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_458 = arith.constant 1.5707963267948966 : f64
    %757 = qlx.apply #qlx.action<pauli_rotation>(%756#0, %cst_458) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_459 = arith.constant 1.5707963267948966 : f64
    %758 = qlx.apply #qlx.action<pauli_rotation>(%756#1, %cst_459) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %759:2 = qlx.apply #qlx.action<pauli_rotation>(%757, %758, %cst_460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %760 = qlx.apply #qlx.action<h>(%759#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_461 = arith.constant 3.1415926535897931 : f64
    %761 = qlx.apply #qlx.action<pauli_rotation>(%760, %cst_461) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %762 = qlx.apply #qlx.action<h>(%761) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %763 = qlx.apply #qlx.action<h>(%714#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_462 = arith.constant 1.5707963267948966 : f64
    %764:2 = qlx.apply #qlx.action<pauli_rotation>(%762, %763, %cst_462) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_463 = arith.constant 1.5707963267948966 : f64
    %765 = qlx.apply #qlx.action<pauli_rotation>(%764#0, %cst_463) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_464 = arith.constant 1.5707963267948966 : f64
    %766 = qlx.apply #qlx.action<pauli_rotation>(%764#1, %cst_464) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_465 = arith.constant 1.5707963267948966 : f64
    %767:2 = qlx.apply #qlx.action<pauli_rotation>(%765, %766, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %768 = qlx.apply #qlx.action<h>(%767#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_466 = arith.constant 1.5707963267948966 : f64
    %769 = qlx.apply #qlx.action<pauli_rotation>(%768, %cst_466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %770 = qlx.apply #qlx.action<h>(%769) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %771 = qlx.apply #qlx.action<h>(%749#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_467 = arith.constant 0.78539816339744828 : f64
    %772 = qlx.apply #qlx.action<pauli_rotation>(%771, %cst_467) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %773 = qlx.apply #qlx.action<h>(%772) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_468 = arith.constant 5.000000e-01 : f64
    %774:2 = qlx.apply #qlx.action<pauli_rotation>(%770, %773, %cst_468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_469 = arith.constant 1.5707963267948966 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%774#0, %cst_469) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_470 = arith.constant 1.5707963267948966 : f64
    %776 = qlx.apply #qlx.action<pauli_rotation>(%774#1, %cst_470) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_471 = arith.constant 5.000000e-01 : f64
    %777:2 = qlx.apply #qlx.action<pauli_rotation>(%775, %776, %cst_471) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %778 = qlx.apply #qlx.action<h>(%767#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 3.1415926535897931 : f64
    %779 = qlx.apply #qlx.action<pauli_rotation>(%778, %cst_472) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %780 = qlx.apply #qlx.action<h>(%779) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_473 = arith.constant 1.5707963267948966 : f64
    %781:2 = qlx.apply #qlx.action<pauli_rotation>(%777#0, %780, %cst_473) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_474 = arith.constant 1.5707963267948966 : f64
    %782 = qlx.apply #qlx.action<pauli_rotation>(%781#1, %cst_474) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_475 = arith.constant 1.5707963267948966 : f64
    %783 = qlx.apply #qlx.action<pauli_rotation>(%781#0, %cst_475) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %784:2 = qlx.apply #qlx.action<pauli_rotation>(%782, %783, %cst_476) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %785 = qlx.apply #qlx.action<h>(%759#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_477 = arith.constant 3.1415926535897931 : f64
    %786 = qlx.apply #qlx.action<pauli_rotation>(%785, %cst_477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %787 = qlx.apply #qlx.action<h>(%786) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %788 = qlx.apply #qlx.action<h>(%784#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_478 = arith.constant 3.1415926535897931 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%788, %cst_478) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %790 = qlx.apply #qlx.action<h>(%789) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_479 = arith.constant 1.5707963267948966 : f64
    %791:2 = qlx.apply #qlx.action<pauli_rotation>(%787, %790, %cst_479) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_480 = arith.constant 1.5707963267948966 : f64
    %792 = qlx.apply #qlx.action<pauli_rotation>(%791#0, %cst_480) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_481 = arith.constant 1.5707963267948966 : f64
    %793 = qlx.apply #qlx.action<pauli_rotation>(%791#1, %cst_481) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_482 = arith.constant 1.5707963267948966 : f64
    %794:2 = qlx.apply #qlx.action<pauli_rotation>(%792, %793, %cst_482) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %795 = qlx.apply #qlx.action<h>(%734#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_483 = arith.constant 1.5707963267948966 : f64
    %796 = qlx.apply #qlx.action<pauli_rotation>(%795, %cst_483) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %797 = qlx.apply #qlx.action<h>(%796) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %798 = qlx.apply #qlx.action<h>(%794#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_484 = arith.constant 2.3561944901923448 : f64
    %799 = qlx.apply #qlx.action<pauli_rotation>(%798, %cst_484) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %800 = qlx.apply #qlx.action<h>(%799) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_485 = arith.constant 0.78539816339744828 : f64
    %801:2 = qlx.apply #qlx.action<pauli_rotation>(%797, %800, %cst_485) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %802 = qlx.apply #qlx.action<pauli_rotation>(%801#0, %cst_486) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_487 = arith.constant 1.5707963267948966 : f64
    %803 = qlx.apply #qlx.action<pauli_rotation>(%801#1, %cst_487) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_488 = arith.constant 0.78539816339744828 : f64
    %804:2 = qlx.apply #qlx.action<pauli_rotation>(%802, %803, %cst_488) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %805 = qlx.apply #qlx.action<h>(%777#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_489 = arith.constant 2.3561944901923448 : f64
    %806 = qlx.apply #qlx.action<pauli_rotation>(%805, %cst_489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %807 = qlx.apply #qlx.action<h>(%806) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %808 = qlx.apply #qlx.action<h>(%749#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_490 = arith.constant 1.5707963267948966 : f64
    %809 = qlx.apply #qlx.action<pauli_rotation>(%808, %cst_490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %810 = qlx.apply #qlx.action<h>(%809) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_491 = arith.constant 0.78539816339744828 : f64
    %811:2 = qlx.apply #qlx.action<pauli_rotation>(%807, %810, %cst_491) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_492 = arith.constant 1.5707963267948966 : f64
    %812 = qlx.apply #qlx.action<pauli_rotation>(%811#0, %cst_492) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_493 = arith.constant 1.5707963267948966 : f64
    %813 = qlx.apply #qlx.action<pauli_rotation>(%811#1, %cst_493) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_494 = arith.constant 0.78539816339744828 : f64
    %814:2 = qlx.apply #qlx.action<pauli_rotation>(%812, %813, %cst_494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %815 = qlx.apply #qlx.action<h>(%794#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_495 = arith.constant 2.3561944901923448 : f64
    %816 = qlx.apply #qlx.action<pauli_rotation>(%815, %cst_495) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %817 = qlx.apply #qlx.action<h>(%816) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %818 = qlx.apply #qlx.action<h>(%784#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_496 = arith.constant 2.3561944901923448 : f64
    %819 = qlx.apply #qlx.action<pauli_rotation>(%818, %cst_496) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %820 = qlx.apply #qlx.action<h>(%819) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_497 = arith.constant 0.78539816339744828 : f64
    %821:2 = qlx.apply #qlx.action<pauli_rotation>(%817, %820, %cst_497) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %822 = qlx.apply #qlx.action<pauli_rotation>(%821#0, %cst_498) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_499 = arith.constant 1.5707963267948966 : f64
    %823 = qlx.apply #qlx.action<pauli_rotation>(%821#1, %cst_499) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_500 = arith.constant 0.78539816339744828 : f64
    %824:2 = qlx.apply #qlx.action<pauli_rotation>(%822, %823, %cst_500) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %825 = qlx.apply #qlx.action<h>(%740#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_501 = arith.constant 2.3561944901923448 : f64
    %826 = qlx.apply #qlx.action<pauli_rotation>(%825, %cst_501) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %827 = qlx.apply #qlx.action<h>(%826) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_502 = arith.constant 0.78539816339744828 : f64
    %828 = qlx.apply #qlx.action<pauli_rotation>(%719#1, %cst_502) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %829 = qlx.apply #qlx.action<h>(%828) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_503 = arith.constant 0.78539816339744828 : f64
    %830:2 = qlx.apply #qlx.action<pauli_rotation>(%827, %829, %cst_503) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_504 = arith.constant 1.5707963267948966 : f64
    %831 = qlx.apply #qlx.action<pauli_rotation>(%830#0, %cst_504) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_505 = arith.constant 1.5707963267948966 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%830#1, %cst_505) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_506 = arith.constant 0.78539816339744828 : f64
    %833:2 = qlx.apply #qlx.action<pauli_rotation>(%831, %832, %cst_506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %834 = qlx.apply #qlx.action<h>(%814#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_507 = arith.constant 2.3561944901923448 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%834, %cst_507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %836 = qlx.apply #qlx.action<h>(%835) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %837 = qlx.apply #qlx.action<h>(%833#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_508 = arith.constant 2.3561944901923448 : f64
    %838 = qlx.apply #qlx.action<pauli_rotation>(%837, %cst_508) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %839 = qlx.apply #qlx.action<h>(%838) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_509 = arith.constant 1.5707963267948966 : f64
    %840:2 = qlx.apply #qlx.action<pauli_rotation>(%836, %839, %cst_509) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %841 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %cst_510) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_511 = arith.constant 1.5707963267948966 : f64
    %842 = qlx.apply #qlx.action<pauli_rotation>(%840#1, %cst_511) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_512 = arith.constant 1.5707963267948966 : f64
    %843:2 = qlx.apply #qlx.action<pauli_rotation>(%841, %842, %cst_512) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %844 = qlx.apply #qlx.action<h>(%814#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_513 = arith.constant 2.3561944901923448 : f64
    %845 = qlx.apply #qlx.action<pauli_rotation>(%844, %cst_513) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %846 = qlx.apply #qlx.action<h>(%845) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %847 = qlx.apply #qlx.action<h>(%843#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_514 = arith.constant 3.1415926535897931 : f64
    %848 = qlx.apply #qlx.action<pauli_rotation>(%847, %cst_514) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %849 = qlx.apply #qlx.action<h>(%848) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_515 = arith.constant 1.5707963267948966 : f64
    %850:2 = qlx.apply #qlx.action<pauli_rotation>(%846, %849, %cst_515) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %851 = qlx.apply #qlx.action<pauli_rotation>(%850#0, %cst_516) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_517 = arith.constant 1.5707963267948966 : f64
    %852 = qlx.apply #qlx.action<pauli_rotation>(%850#1, %cst_517) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_518 = arith.constant 1.5707963267948966 : f64
    %853:2 = qlx.apply #qlx.action<pauli_rotation>(%851, %852, %cst_518) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %854 = qlx.apply #qlx.action<h>(%824#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_519 = arith.constant 2.3561944901923448 : f64
    %855 = qlx.apply #qlx.action<pauli_rotation>(%854, %cst_519) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %856 = qlx.apply #qlx.action<h>(%855) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %857 = qlx.apply #qlx.action<h>(%853#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_520 = arith.constant 1.5707963267948966 : f64
    %858 = qlx.apply #qlx.action<pauli_rotation>(%857, %cst_520) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %859 = qlx.apply #qlx.action<h>(%858) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_521 = arith.constant 5.000000e-01 : f64
    %860:2 = qlx.apply #qlx.action<pauli_rotation>(%856, %859, %cst_521) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_522 = arith.constant 1.5707963267948966 : f64
    %861 = qlx.apply #qlx.action<pauli_rotation>(%860#0, %cst_522) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_523 = arith.constant 1.5707963267948966 : f64
    %862 = qlx.apply #qlx.action<pauli_rotation>(%860#1, %cst_523) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_524 = arith.constant 5.000000e-01 : f64
    %863:2 = qlx.apply #qlx.action<pauli_rotation>(%861, %862, %cst_524) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %864 = qlx.apply #qlx.action<h>(%824#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_525 = arith.constant 1.5707963267948966 : f64
    %865 = qlx.apply #qlx.action<pauli_rotation>(%864, %cst_525) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %866 = qlx.apply #qlx.action<h>(%865) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %867 = qlx.apply #qlx.action<h>(%863#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_526 = arith.constant 0.78539816339744828 : f64
    %868 = qlx.apply #qlx.action<pauli_rotation>(%867, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %869 = qlx.apply #qlx.action<h>(%868) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_527 = arith.constant 0.78539816339744828 : f64
    %870:2 = qlx.apply #qlx.action<pauli_rotation>(%866, %869, %cst_527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_528 = arith.constant 1.5707963267948966 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%870#0, %cst_528) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %872 = qlx.apply #qlx.action<pauli_rotation>(%870#1, %cst_529) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_530 = arith.constant 0.78539816339744828 : f64
    %873:2 = qlx.apply #qlx.action<pauli_rotation>(%871, %872, %cst_530) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %874 = qlx.apply #qlx.action<h>(%863#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_531 = arith.constant 3.1415926535897931 : f64
    %875 = qlx.apply #qlx.action<pauli_rotation>(%874, %cst_531) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %876 = qlx.apply #qlx.action<h>(%875) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %877 = qlx.apply #qlx.action<h>(%853#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_532 = arith.constant 3.1415926535897931 : f64
    %878 = qlx.apply #qlx.action<pauli_rotation>(%877, %cst_532) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %879 = qlx.apply #qlx.action<h>(%878) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %880:2 = qlx.apply #qlx.action<pauli_rotation>(%876, %879, %cst_533) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_534 = arith.constant 1.5707963267948966 : f64
    %881 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %cst_534) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %882 = qlx.apply #qlx.action<pauli_rotation>(%880#1, %cst_535) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_536 = arith.constant 1.5707963267948966 : f64
    %883:2 = qlx.apply #qlx.action<pauli_rotation>(%881, %882, %cst_536) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %884 = qlx.apply #qlx.action<h>(%843#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_537 = arith.constant 3.1415926535897931 : f64
    %885 = qlx.apply #qlx.action<pauli_rotation>(%884, %cst_537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %886 = qlx.apply #qlx.action<h>(%885) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %887 = qlx.apply #qlx.action<h>(%833#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_538 = arith.constant 2.3561944901923448 : f64
    %888 = qlx.apply #qlx.action<pauli_rotation>(%887, %cst_538) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %889 = qlx.apply #qlx.action<h>(%888) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_539 = arith.constant 1.5707963267948966 : f64
    %890:2 = qlx.apply #qlx.action<pauli_rotation>(%886, %889, %cst_539) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_540 = arith.constant 1.5707963267948966 : f64
    %891 = qlx.apply #qlx.action<pauli_rotation>(%890#0, %cst_540) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_541 = arith.constant 1.5707963267948966 : f64
    %892 = qlx.apply #qlx.action<pauli_rotation>(%890#1, %cst_541) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_542 = arith.constant 1.5707963267948966 : f64
    %893:2 = qlx.apply #qlx.action<pauli_rotation>(%891, %892, %cst_542) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %894 = qlx.apply #qlx.action<h>(%883#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_543 = arith.constant 2.3561944901923448 : f64
    %895 = qlx.apply #qlx.action<pauli_rotation>(%894, %cst_543) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %896 = qlx.apply #qlx.action<h>(%895) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %897 = qlx.apply #qlx.action<h>(%893#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_544 = arith.constant 2.3561944901923448 : f64
    %898 = qlx.apply #qlx.action<pauli_rotation>(%897, %cst_544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %899 = qlx.apply #qlx.action<h>(%898) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_545 = arith.constant 0.78539816339744828 : f64
    %900:2 = qlx.apply #qlx.action<pauli_rotation>(%896, %899, %cst_545) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_546 = arith.constant 1.5707963267948966 : f64
    %901 = qlx.apply #qlx.action<pauli_rotation>(%900#0, %cst_546) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_547 = arith.constant 1.5707963267948966 : f64
    %902 = qlx.apply #qlx.action<pauli_rotation>(%900#1, %cst_547) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_548 = arith.constant 0.78539816339744828 : f64
    %903:2 = qlx.apply #qlx.action<pauli_rotation>(%901, %902, %cst_548) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %904 = qlx.apply #qlx.action<h>(%804#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_549 = arith.constant 2.3561944901923448 : f64
    %905 = qlx.apply #qlx.action<pauli_rotation>(%904, %cst_549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %906 = qlx.apply #qlx.action<h>(%905) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %907 = qlx.apply #qlx.action<h>(%873#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_550 = arith.constant 2.3561944901923448 : f64
    %908 = qlx.apply #qlx.action<pauli_rotation>(%907, %cst_550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%908) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_551 = arith.constant 1.5707963267948966 : f64
    %910:2 = qlx.apply #qlx.action<pauli_rotation>(%906, %909, %cst_551) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_552 = arith.constant 1.5707963267948966 : f64
    %911 = qlx.apply #qlx.action<pauli_rotation>(%910#0, %cst_552) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_553 = arith.constant 1.5707963267948966 : f64
    %912 = qlx.apply #qlx.action<pauli_rotation>(%910#1, %cst_553) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_554 = arith.constant 1.5707963267948966 : f64
    %913:2 = qlx.apply #qlx.action<pauli_rotation>(%911, %912, %cst_554) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %914 = qlx.apply #qlx.action<h>(%804#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_555 = arith.constant 2.3561944901923448 : f64
    %915 = qlx.apply #qlx.action<pauli_rotation>(%914, %cst_555) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %916 = qlx.apply #qlx.action<h>(%913#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_556 = arith.constant 3.1415926535897931 : f64
    %917 = qlx.apply #qlx.action<pauli_rotation>(%916, %cst_556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_557 = arith.constant 2.500000e-01 : f64
    %918:2 = qlx.apply #qlx.action<pauli_rotation>(%915, %917, %cst_557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %919 = qlx.apply #qlx.action<h>(%883#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_558 = arith.constant 3.1415926535897931 : f64
    %920 = qlx.apply #qlx.action<pauli_rotation>(%919, %cst_558) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %921 = qlx.apply #qlx.action<h>(%903#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_559 = arith.constant 2.3561944901923448 : f64
    %922 = qlx.apply #qlx.action<pauli_rotation>(%921, %cst_559) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_560 = arith.constant 2.500000e-01 : f64
    %923:2 = qlx.apply #qlx.action<pauli_rotation>(%920, %922, %cst_560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %924 = qlx.apply #qlx.action<h>(%913#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_561 = arith.constant 3.1415926535897931 : f64
    %925 = qlx.apply #qlx.action<pauli_rotation>(%924, %cst_561) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %926 = qlx.apply #qlx.action<h>(%873#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_562 = arith.constant 2.3561944901923448 : f64
    %927 = qlx.apply #qlx.action<pauli_rotation>(%926, %cst_562) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_563 = arith.constant 2.500000e-01 : f64
    %928:2 = qlx.apply #qlx.action<pauli_rotation>(%925, %927, %cst_563) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %929 = qlx.apply #qlx.action<h>(%903#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_564 = arith.constant 2.3561944901923448 : f64
    %930 = qlx.apply #qlx.action<pauli_rotation>(%929, %cst_564) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %931 = qlx.apply #qlx.action<h>(%893#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_565 = arith.constant 3.1415926535897931 : f64
    %932 = qlx.apply #qlx.action<pauli_rotation>(%931, %cst_565) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_566 = arith.constant 2.500000e-01 : f64
    %933:2 = qlx.apply #qlx.action<pauli_rotation>(%930, %932, %cst_566) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %934 = qlx.measure <Z> %918#0 : !qlx.logical_qubit -> i1
    %935 = qlx.measure <Z> %918#1 : !qlx.logical_qubit -> i1
    %936 = qlx.measure <Z> %928#0 : !qlx.logical_qubit -> i1
    %937 = qlx.measure <Z> %928#1 : !qlx.logical_qubit -> i1
    %938 = qlx.measure <Z> %923#0 : !qlx.logical_qubit -> i1
    %939 = qlx.measure <Z> %923#1 : !qlx.logical_qubit -> i1
    %940 = qlx.measure <Z> %933#0 : !qlx.logical_qubit -> i1
    %941 = qlx.measure <Z> %933#1 : !qlx.logical_qubit -> i1
  }
}
