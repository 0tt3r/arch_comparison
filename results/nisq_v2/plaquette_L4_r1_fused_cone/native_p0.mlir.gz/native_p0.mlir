module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 8 : i64} : !qlx.logical_qubit
    %9 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 9 : i64} : !qlx.logical_qubit
    %10 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 10 : i64} : !qlx.logical_qubit
    %11 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 11 : i64} : !qlx.logical_qubit
    %12 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 12 : i64} : !qlx.logical_qubit
    %13 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 13 : i64} : !qlx.logical_qubit
    %14 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 14 : i64} : !qlx.logical_qubit
    %15 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 15 : i64} : !qlx.logical_qubit
    %16 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 16 : i64} : !qlx.logical_qubit
    %17 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 17 : i64} : !qlx.logical_qubit
    %18 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 18 : i64} : !qlx.logical_qubit
    %19 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 19 : i64} : !qlx.logical_qubit
    %20 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 20 : i64} : !qlx.logical_qubit
    %21 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 21 : i64} : !qlx.logical_qubit
    %22 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 22 : i64} : !qlx.logical_qubit
    %23 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 23 : i64} : !qlx.logical_qubit
    %24 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 24 : i64} : !qlx.logical_qubit
    %25 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 25 : i64} : !qlx.logical_qubit
    %26 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 26 : i64} : !qlx.logical_qubit
    %27 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 27 : i64} : !qlx.logical_qubit
    %28 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 28 : i64} : !qlx.logical_qubit
    %29 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 29 : i64} : !qlx.logical_qubit
    %30 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 30 : i64} : !qlx.logical_qubit
    %31 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 31 : i64} : !qlx.logical_qubit
    %32 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 1.000000e+00 : f64
    %33:2 = qlx.apply #qlx.action<pauli_rotation>(%32, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %34 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_0 = arith.constant 1.000000e+00 : f64
    %35:2 = qlx.apply #qlx.action<pauli_rotation>(%2, %34, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %36 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1 = arith.constant 1.000000e+00 : f64
    %37:2 = qlx.apply #qlx.action<pauli_rotation>(%36, %5, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %38 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2 = arith.constant 1.000000e+00 : f64
    %39:2 = qlx.apply #qlx.action<pauli_rotation>(%6, %38, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %40 = qlx.apply #qlx.action<x>(%8) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_3 = arith.constant 1.000000e+00 : f64
    %41:2 = qlx.apply #qlx.action<pauli_rotation>(%40, %9, %cst_3) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %42 = qlx.apply #qlx.action<x>(%11) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_4 = arith.constant 1.000000e+00 : f64
    %43:2 = qlx.apply #qlx.action<pauli_rotation>(%10, %42, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %44 = qlx.apply #qlx.action<x>(%12) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 1.000000e+00 : f64
    %45:2 = qlx.apply #qlx.action<pauli_rotation>(%44, %13, %cst_5) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %46 = qlx.apply #qlx.action<x>(%15) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_6 = arith.constant 1.000000e+00 : f64
    %47:2 = qlx.apply #qlx.action<pauli_rotation>(%14, %46, %cst_6) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %48 = qlx.apply #qlx.action<x>(%16) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_7 = arith.constant 1.000000e+00 : f64
    %49:2 = qlx.apply #qlx.action<pauli_rotation>(%48, %17, %cst_7) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %50 = qlx.apply #qlx.action<x>(%19) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_8 = arith.constant 1.000000e+00 : f64
    %51:2 = qlx.apply #qlx.action<pauli_rotation>(%18, %50, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %52 = qlx.apply #qlx.action<x>(%20) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_9 = arith.constant 1.000000e+00 : f64
    %53:2 = qlx.apply #qlx.action<pauli_rotation>(%52, %21, %cst_9) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %54 = qlx.apply #qlx.action<x>(%23) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 1.000000e+00 : f64
    %55:2 = qlx.apply #qlx.action<pauli_rotation>(%22, %54, %cst_10) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %56 = qlx.apply #qlx.action<x>(%24) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 1.000000e+00 : f64
    %57:2 = qlx.apply #qlx.action<pauli_rotation>(%56, %25, %cst_11) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %58 = qlx.apply #qlx.action<x>(%27) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_12 = arith.constant 1.000000e+00 : f64
    %59:2 = qlx.apply #qlx.action<pauli_rotation>(%26, %58, %cst_12) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %60 = qlx.apply #qlx.action<x>(%28) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_13 = arith.constant 1.000000e+00 : f64
    %61:2 = qlx.apply #qlx.action<pauli_rotation>(%60, %29, %cst_13) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %62 = qlx.apply #qlx.action<x>(%31) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_14 = arith.constant 1.000000e+00 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%30, %62, %cst_14) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<h>(%43#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %65 = qlx.apply #qlx.action<h>(%45#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %66:2 = qlx.apply #qlx.action<pauli_rotation>(%64, %65, %cst_15) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %67 = qlx.apply #qlx.action<pauli_rotation>(%66#0, %cst_16) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%66#1, %cst_17) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %69:2 = qlx.apply #qlx.action<pauli_rotation>(%67, %68, %cst_18) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %70 = qlx.apply #qlx.action<h>(%43#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %71 = qlx.apply #qlx.action<h>(%69#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_19 = arith.constant 3.1415926535897931 : f64
    %72 = qlx.apply #qlx.action<pauli_rotation>(%71, %cst_19) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %73 = qlx.apply #qlx.action<h>(%72) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %74:2 = qlx.apply #qlx.action<pauli_rotation>(%70, %73, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %75 = qlx.apply #qlx.action<pauli_rotation>(%74#0, %cst_21) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %76 = qlx.apply #qlx.action<pauli_rotation>(%74#1, %cst_22) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %77:2 = qlx.apply #qlx.action<pauli_rotation>(%75, %76, %cst_23) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %78 = qlx.apply #qlx.action<h>(%41#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %79 = qlx.apply #qlx.action<h>(%77#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_24 = arith.constant 3.1415926535897931 : f64
    %80 = qlx.apply #qlx.action<pauli_rotation>(%79, %cst_24) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %81 = qlx.apply #qlx.action<h>(%80) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %82:2 = qlx.apply #qlx.action<pauli_rotation>(%78, %81, %cst_25) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %83 = qlx.apply #qlx.action<pauli_rotation>(%82#0, %cst_26) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%82#1, %cst_27) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %85:2 = qlx.apply #qlx.action<pauli_rotation>(%83, %84, %cst_28) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %86 = qlx.apply #qlx.action<h>(%41#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %87 = qlx.apply #qlx.action<h>(%85#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_29 = arith.constant 3.1415926535897931 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%87, %cst_29) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %89 = qlx.apply #qlx.action<h>(%88) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %90:2 = qlx.apply #qlx.action<pauli_rotation>(%86, %89, %cst_30) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_31 = arith.constant 1.5707963267948966 : f64
    %91 = qlx.apply #qlx.action<pauli_rotation>(%90#0, %cst_31) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %92 = qlx.apply #qlx.action<pauli_rotation>(%90#1, %cst_32) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %93:2 = qlx.apply #qlx.action<pauli_rotation>(%91, %92, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %94 = qlx.apply #qlx.action<h>(%39#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %95 = qlx.apply #qlx.action<h>(%93#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_34 = arith.constant 3.1415926535897931 : f64
    %96 = qlx.apply #qlx.action<pauli_rotation>(%95, %cst_34) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %97 = qlx.apply #qlx.action<h>(%96) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %98:2 = qlx.apply #qlx.action<pauli_rotation>(%94, %97, %cst_35) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %99 = qlx.apply #qlx.action<pauli_rotation>(%98#0, %cst_36) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %100 = qlx.apply #qlx.action<pauli_rotation>(%98#1, %cst_37) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %101:2 = qlx.apply #qlx.action<pauli_rotation>(%99, %100, %cst_38) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %102 = qlx.apply #qlx.action<h>(%39#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %103 = qlx.apply #qlx.action<h>(%101#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 3.1415926535897931 : f64
    %104 = qlx.apply #qlx.action<pauli_rotation>(%103, %cst_39) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %105 = qlx.apply #qlx.action<h>(%104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%102, %105, %cst_40) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %107 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %cst_41) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_42 = arith.constant 1.5707963267948966 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%106#1, %cst_42) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%107, %108, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %110 = qlx.apply #qlx.action<h>(%37#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %111 = qlx.apply #qlx.action<h>(%109#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_44 = arith.constant 3.1415926535897931 : f64
    %112 = qlx.apply #qlx.action<pauli_rotation>(%111, %cst_44) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %113 = qlx.apply #qlx.action<h>(%112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 1.5707963267948966 : f64
    %114:2 = qlx.apply #qlx.action<pauli_rotation>(%110, %113, %cst_45) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %115 = qlx.apply #qlx.action<pauli_rotation>(%114#0, %cst_46) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_47 = arith.constant 1.5707963267948966 : f64
    %116 = qlx.apply #qlx.action<pauli_rotation>(%114#1, %cst_47) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %117:2 = qlx.apply #qlx.action<pauli_rotation>(%115, %116, %cst_48) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %118 = qlx.apply #qlx.action<h>(%37#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %119 = qlx.apply #qlx.action<h>(%117#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_49 = arith.constant 3.1415926535897931 : f64
    %120 = qlx.apply #qlx.action<pauli_rotation>(%119, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %121 = qlx.apply #qlx.action<h>(%120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_50 = arith.constant 1.5707963267948966 : f64
    %122:2 = qlx.apply #qlx.action<pauli_rotation>(%118, %121, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 1.5707963267948966 : f64
    %123 = qlx.apply #qlx.action<pauli_rotation>(%122#0, %cst_51) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%122#1, %cst_52) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %125:2 = qlx.apply #qlx.action<pauli_rotation>(%123, %124, %cst_53) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %126 = qlx.apply #qlx.action<h>(%35#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %127 = qlx.apply #qlx.action<h>(%125#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_54 = arith.constant 3.1415926535897931 : f64
    %128 = qlx.apply #qlx.action<pauli_rotation>(%127, %cst_54) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %129 = qlx.apply #qlx.action<h>(%128) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %130:2 = qlx.apply #qlx.action<pauli_rotation>(%126, %129, %cst_55) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_56 = arith.constant 1.5707963267948966 : f64
    %131 = qlx.apply #qlx.action<pauli_rotation>(%130#0, %cst_56) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_57 = arith.constant 1.5707963267948966 : f64
    %132 = qlx.apply #qlx.action<pauli_rotation>(%130#1, %cst_57) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %133:2 = qlx.apply #qlx.action<pauli_rotation>(%131, %132, %cst_58) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %134 = qlx.apply #qlx.action<h>(%35#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %135 = qlx.apply #qlx.action<h>(%133#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_59 = arith.constant 3.1415926535897931 : f64
    %136 = qlx.apply #qlx.action<pauli_rotation>(%135, %cst_59) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %137 = qlx.apply #qlx.action<h>(%136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_60 = arith.constant 1.5707963267948966 : f64
    %138:2 = qlx.apply #qlx.action<pauli_rotation>(%134, %137, %cst_60) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_61 = arith.constant 1.5707963267948966 : f64
    %139 = qlx.apply #qlx.action<pauli_rotation>(%138#0, %cst_61) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %140 = qlx.apply #qlx.action<pauli_rotation>(%138#1, %cst_62) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_63 = arith.constant 1.5707963267948966 : f64
    %141:2 = qlx.apply #qlx.action<pauli_rotation>(%139, %140, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %142 = qlx.apply #qlx.action<h>(%33#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %143 = qlx.apply #qlx.action<h>(%141#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_64 = arith.constant 3.1415926535897931 : f64
    %144 = qlx.apply #qlx.action<pauli_rotation>(%143, %cst_64) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %145 = qlx.apply #qlx.action<h>(%144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %146:2 = qlx.apply #qlx.action<pauli_rotation>(%142, %145, %cst_65) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 1.5707963267948966 : f64
    %147 = qlx.apply #qlx.action<pauli_rotation>(%146#0, %cst_66) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_67 = arith.constant 1.5707963267948966 : f64
    %148 = qlx.apply #qlx.action<pauli_rotation>(%146#1, %cst_67) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_68 = arith.constant 1.5707963267948966 : f64
    %149:2 = qlx.apply #qlx.action<pauli_rotation>(%147, %148, %cst_68) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_69 = arith.constant 0.78539816339744828 : f64
    %150 = qlx.apply #qlx.action<pauli_rotation>(%33#0, %cst_69) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %151 = qlx.apply #qlx.action<h>(%150) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %152 = qlx.apply #qlx.action<h>(%149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_70 = arith.constant 2.3561944901923448 : f64
    %153 = qlx.apply #qlx.action<pauli_rotation>(%152, %cst_70) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %154 = qlx.apply #qlx.action<h>(%153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_71 = arith.constant 0.78539816339744828 : f64
    %155:2 = qlx.apply #qlx.action<pauli_rotation>(%151, %154, %cst_71) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %156 = qlx.apply #qlx.action<pauli_rotation>(%155#0, %cst_72) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_73 = arith.constant 1.5707963267948966 : f64
    %157 = qlx.apply #qlx.action<pauli_rotation>(%155#1, %cst_73) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_74 = arith.constant 0.78539816339744828 : f64
    %158:2 = qlx.apply #qlx.action<pauli_rotation>(%156, %157, %cst_74) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %159 = qlx.apply #qlx.action<h>(%45#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %160 = qlx.apply #qlx.action<h>(%47#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %161:2 = qlx.apply #qlx.action<pauli_rotation>(%159, %160, %cst_75) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %162 = qlx.apply #qlx.action<pauli_rotation>(%161#0, %cst_76) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_77 = arith.constant 1.5707963267948966 : f64
    %163 = qlx.apply #qlx.action<pauli_rotation>(%161#1, %cst_77) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %164:2 = qlx.apply #qlx.action<pauli_rotation>(%162, %163, %cst_78) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %165 = qlx.apply #qlx.action<h>(%69#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 3.1415926535897931 : f64
    %166 = qlx.apply #qlx.action<pauli_rotation>(%165, %cst_79) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %167 = qlx.apply #qlx.action<h>(%166) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %168 = qlx.apply #qlx.action<h>(%164#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_80 = arith.constant 3.1415926535897931 : f64
    %169 = qlx.apply #qlx.action<pauli_rotation>(%168, %cst_80) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %170 = qlx.apply #qlx.action<h>(%169) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %171:2 = qlx.apply #qlx.action<pauli_rotation>(%167, %170, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.5707963267948966 : f64
    %172 = qlx.apply #qlx.action<pauli_rotation>(%171#0, %cst_82) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %173 = qlx.apply #qlx.action<pauli_rotation>(%171#1, %cst_83) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %174:2 = qlx.apply #qlx.action<pauli_rotation>(%172, %173, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %175 = qlx.apply #qlx.action<h>(%77#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 3.1415926535897931 : f64
    %176 = qlx.apply #qlx.action<pauli_rotation>(%175, %cst_85) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %177 = qlx.apply #qlx.action<h>(%176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %178 = qlx.apply #qlx.action<h>(%174#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_86 = arith.constant 3.1415926535897931 : f64
    %179 = qlx.apply #qlx.action<pauli_rotation>(%178, %cst_86) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %180 = qlx.apply #qlx.action<h>(%179) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %181:2 = qlx.apply #qlx.action<pauli_rotation>(%177, %180, %cst_87) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.5707963267948966 : f64
    %182 = qlx.apply #qlx.action<pauli_rotation>(%181#0, %cst_88) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%181#1, %cst_89) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %184:2 = qlx.apply #qlx.action<pauli_rotation>(%182, %183, %cst_90) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %185 = qlx.apply #qlx.action<h>(%85#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_91 = arith.constant 3.1415926535897931 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%185, %cst_91) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %187 = qlx.apply #qlx.action<h>(%186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %188 = qlx.apply #qlx.action<h>(%184#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_92 = arith.constant 3.1415926535897931 : f64
    %189 = qlx.apply #qlx.action<pauli_rotation>(%188, %cst_92) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %190 = qlx.apply #qlx.action<h>(%189) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %191:2 = qlx.apply #qlx.action<pauli_rotation>(%187, %190, %cst_93) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 1.5707963267948966 : f64
    %192 = qlx.apply #qlx.action<pauli_rotation>(%191#0, %cst_94) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%191#1, %cst_95) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %194:2 = qlx.apply #qlx.action<pauli_rotation>(%192, %193, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %195 = qlx.apply #qlx.action<h>(%93#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_97 = arith.constant 3.1415926535897931 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%195, %cst_97) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %197 = qlx.apply #qlx.action<h>(%196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %198 = qlx.apply #qlx.action<h>(%194#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_98 = arith.constant 3.1415926535897931 : f64
    %199 = qlx.apply #qlx.action<pauli_rotation>(%198, %cst_98) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %200 = qlx.apply #qlx.action<h>(%199) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %201:2 = qlx.apply #qlx.action<pauli_rotation>(%197, %200, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %202 = qlx.apply #qlx.action<pauli_rotation>(%201#0, %cst_100) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_101 = arith.constant 1.5707963267948966 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%201#1, %cst_101) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %204:2 = qlx.apply #qlx.action<pauli_rotation>(%202, %203, %cst_102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %205 = qlx.apply #qlx.action<h>(%101#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_103 = arith.constant 3.1415926535897931 : f64
    %206 = qlx.apply #qlx.action<pauli_rotation>(%205, %cst_103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %208 = qlx.apply #qlx.action<h>(%204#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_104 = arith.constant 3.1415926535897931 : f64
    %209 = qlx.apply #qlx.action<pauli_rotation>(%208, %cst_104) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %210 = qlx.apply #qlx.action<h>(%209) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_105 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%207, %210, %cst_105) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_106 = arith.constant 1.5707963267948966 : f64
    %212 = qlx.apply #qlx.action<pauli_rotation>(%211#0, %cst_106) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_107 = arith.constant 1.5707963267948966 : f64
    %213 = qlx.apply #qlx.action<pauli_rotation>(%211#1, %cst_107) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_108 = arith.constant 1.5707963267948966 : f64
    %214:2 = qlx.apply #qlx.action<pauli_rotation>(%212, %213, %cst_108) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %215 = qlx.apply #qlx.action<h>(%109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_109 = arith.constant 3.1415926535897931 : f64
    %216 = qlx.apply #qlx.action<pauli_rotation>(%215, %cst_109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %217 = qlx.apply #qlx.action<h>(%216) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %218 = qlx.apply #qlx.action<h>(%214#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_110 = arith.constant 3.1415926535897931 : f64
    %219 = qlx.apply #qlx.action<pauli_rotation>(%218, %cst_110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %220 = qlx.apply #qlx.action<h>(%219) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_111 = arith.constant 1.5707963267948966 : f64
    %221:2 = qlx.apply #qlx.action<pauli_rotation>(%217, %220, %cst_111) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_112 = arith.constant 1.5707963267948966 : f64
    %222 = qlx.apply #qlx.action<pauli_rotation>(%221#0, %cst_112) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_113 = arith.constant 1.5707963267948966 : f64
    %223 = qlx.apply #qlx.action<pauli_rotation>(%221#1, %cst_113) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 1.5707963267948966 : f64
    %224:2 = qlx.apply #qlx.action<pauli_rotation>(%222, %223, %cst_114) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %225 = qlx.apply #qlx.action<h>(%117#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_115 = arith.constant 3.1415926535897931 : f64
    %226 = qlx.apply #qlx.action<pauli_rotation>(%225, %cst_115) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %227 = qlx.apply #qlx.action<h>(%226) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %228 = qlx.apply #qlx.action<h>(%224#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_116 = arith.constant 3.1415926535897931 : f64
    %229 = qlx.apply #qlx.action<pauli_rotation>(%228, %cst_116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %230 = qlx.apply #qlx.action<h>(%229) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %231:2 = qlx.apply #qlx.action<pauli_rotation>(%227, %230, %cst_117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231#0, %cst_118) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %233 = qlx.apply #qlx.action<pauli_rotation>(%231#1, %cst_119) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %234:2 = qlx.apply #qlx.action<pauli_rotation>(%232, %233, %cst_120) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %235 = qlx.apply #qlx.action<h>(%125#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_121 = arith.constant 3.1415926535897931 : f64
    %236 = qlx.apply #qlx.action<pauli_rotation>(%235, %cst_121) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %237 = qlx.apply #qlx.action<h>(%236) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<h>(%234#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_122 = arith.constant 3.1415926535897931 : f64
    %239 = qlx.apply #qlx.action<pauli_rotation>(%238, %cst_122) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %240 = qlx.apply #qlx.action<h>(%239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %241:2 = qlx.apply #qlx.action<pauli_rotation>(%237, %240, %cst_123) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%241#0, %cst_124) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 1.5707963267948966 : f64
    %243 = qlx.apply #qlx.action<pauli_rotation>(%241#1, %cst_125) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_126 = arith.constant 1.5707963267948966 : f64
    %244:2 = qlx.apply #qlx.action<pauli_rotation>(%242, %243, %cst_126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %245 = qlx.apply #qlx.action<h>(%133#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_127 = arith.constant 3.1415926535897931 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%245, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %247 = qlx.apply #qlx.action<h>(%246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %248 = qlx.apply #qlx.action<h>(%244#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_128 = arith.constant 3.1415926535897931 : f64
    %249 = qlx.apply #qlx.action<pauli_rotation>(%248, %cst_128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %250 = qlx.apply #qlx.action<h>(%249) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %251:2 = qlx.apply #qlx.action<pauli_rotation>(%247, %250, %cst_129) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %252 = qlx.apply #qlx.action<pauli_rotation>(%251#0, %cst_130) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 1.5707963267948966 : f64
    %253 = qlx.apply #qlx.action<pauli_rotation>(%251#1, %cst_131) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %254:2 = qlx.apply #qlx.action<pauli_rotation>(%252, %253, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %255 = qlx.apply #qlx.action<h>(%141#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_133 = arith.constant 2.3561944901923448 : f64
    %256 = qlx.apply #qlx.action<pauli_rotation>(%255, %cst_133) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %257 = qlx.apply #qlx.action<h>(%256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %258 = qlx.apply #qlx.action<h>(%254#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_134 = arith.constant 2.3561944901923448 : f64
    %259 = qlx.apply #qlx.action<pauli_rotation>(%258, %cst_134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %260 = qlx.apply #qlx.action<h>(%259) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_135 = arith.constant 0.78539816339744828 : f64
    %261:2 = qlx.apply #qlx.action<pauli_rotation>(%257, %260, %cst_135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %262 = qlx.apply #qlx.action<pauli_rotation>(%261#0, %cst_136) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %263 = qlx.apply #qlx.action<pauli_rotation>(%261#1, %cst_137) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_138 = arith.constant 0.78539816339744828 : f64
    %264:2 = qlx.apply #qlx.action<pauli_rotation>(%262, %263, %cst_138) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %265 = qlx.apply #qlx.action<h>(%149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_139 = arith.constant 3.1415926535897931 : f64
    %266 = qlx.apply #qlx.action<pauli_rotation>(%265, %cst_139) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %267 = qlx.apply #qlx.action<h>(%266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %268 = qlx.apply #qlx.action<h>(%264#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_140 = arith.constant 2.3561944901923448 : f64
    %269 = qlx.apply #qlx.action<pauli_rotation>(%268, %cst_140) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %270 = qlx.apply #qlx.action<h>(%269) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %271:2 = qlx.apply #qlx.action<pauli_rotation>(%267, %270, %cst_141) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 1.5707963267948966 : f64
    %272 = qlx.apply #qlx.action<pauli_rotation>(%271#0, %cst_142) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %273 = qlx.apply #qlx.action<pauli_rotation>(%271#1, %cst_143) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %274:2 = qlx.apply #qlx.action<pauli_rotation>(%272, %273, %cst_144) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %275 = qlx.apply #qlx.action<h>(%158#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_145 = arith.constant 2.3561944901923448 : f64
    %276 = qlx.apply #qlx.action<pauli_rotation>(%275, %cst_145) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %277 = qlx.apply #qlx.action<h>(%276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %278 = qlx.apply #qlx.action<h>(%274#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_146 = arith.constant 1.5707963267948966 : f64
    %279 = qlx.apply #qlx.action<pauli_rotation>(%278, %cst_146) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %280 = qlx.apply #qlx.action<h>(%279) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_147 = arith.constant 1.000000e+00 : f64
    %281:2 = qlx.apply #qlx.action<pauli_rotation>(%277, %280, %cst_147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %282 = qlx.apply #qlx.action<pauli_rotation>(%281#0, %cst_148) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_149 = arith.constant 1.5707963267948966 : f64
    %283 = qlx.apply #qlx.action<pauli_rotation>(%281#1, %cst_149) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_150 = arith.constant 1.000000e+00 : f64
    %284:2 = qlx.apply #qlx.action<pauli_rotation>(%282, %283, %cst_150) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %285 = qlx.apply #qlx.action<h>(%158#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_151 = arith.constant 1.5707963267948966 : f64
    %286 = qlx.apply #qlx.action<pauli_rotation>(%285, %cst_151) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %287 = qlx.apply #qlx.action<h>(%286) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %288 = qlx.apply #qlx.action<h>(%284#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_152 = arith.constant 0.78539816339744828 : f64
    %289 = qlx.apply #qlx.action<pauli_rotation>(%288, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %290 = qlx.apply #qlx.action<h>(%289) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_153 = arith.constant 0.78539816339744828 : f64
    %291:2 = qlx.apply #qlx.action<pauli_rotation>(%287, %290, %cst_153) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %292 = qlx.apply #qlx.action<pauli_rotation>(%291#0, %cst_154) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %293 = qlx.apply #qlx.action<pauli_rotation>(%291#1, %cst_155) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_156 = arith.constant 0.78539816339744828 : f64
    %294:2 = qlx.apply #qlx.action<pauli_rotation>(%292, %293, %cst_156) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %295 = qlx.apply #qlx.action<h>(%174#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_157 = arith.constant 3.1415926535897931 : f64
    %296 = qlx.apply #qlx.action<pauli_rotation>(%295, %cst_157) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %297 = qlx.apply #qlx.action<h>(%296) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %298 = qlx.apply #qlx.action<h>(%164#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_158 = arith.constant 3.1415926535897931 : f64
    %299 = qlx.apply #qlx.action<pauli_rotation>(%298, %cst_158) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %300 = qlx.apply #qlx.action<h>(%299) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_159 = arith.constant 1.5707963267948966 : f64
    %301:2 = qlx.apply #qlx.action<pauli_rotation>(%297, %300, %cst_159) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %302 = qlx.apply #qlx.action<pauli_rotation>(%301#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.5707963267948966 : f64
    %303 = qlx.apply #qlx.action<pauli_rotation>(%301#1, %cst_161) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 1.5707963267948966 : f64
    %304:2 = qlx.apply #qlx.action<pauli_rotation>(%302, %303, %cst_162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %305 = qlx.apply #qlx.action<h>(%184#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 3.1415926535897931 : f64
    %306 = qlx.apply #qlx.action<pauli_rotation>(%305, %cst_163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %307 = qlx.apply #qlx.action<h>(%306) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %308 = qlx.apply #qlx.action<h>(%304#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_164 = arith.constant 3.1415926535897931 : f64
    %309 = qlx.apply #qlx.action<pauli_rotation>(%308, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %310 = qlx.apply #qlx.action<h>(%309) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 1.5707963267948966 : f64
    %311:2 = qlx.apply #qlx.action<pauli_rotation>(%307, %310, %cst_165) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %312 = qlx.apply #qlx.action<pauli_rotation>(%311#0, %cst_166) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %313 = qlx.apply #qlx.action<pauli_rotation>(%311#1, %cst_167) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_168 = arith.constant 1.5707963267948966 : f64
    %314:2 = qlx.apply #qlx.action<pauli_rotation>(%312, %313, %cst_168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %315 = qlx.apply #qlx.action<h>(%194#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 3.1415926535897931 : f64
    %316 = qlx.apply #qlx.action<pauli_rotation>(%315, %cst_169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %317 = qlx.apply #qlx.action<h>(%316) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %318 = qlx.apply #qlx.action<h>(%314#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_170 = arith.constant 3.1415926535897931 : f64
    %319 = qlx.apply #qlx.action<pauli_rotation>(%318, %cst_170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %320 = qlx.apply #qlx.action<h>(%319) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_171 = arith.constant 1.5707963267948966 : f64
    %321:2 = qlx.apply #qlx.action<pauli_rotation>(%317, %320, %cst_171) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %322 = qlx.apply #qlx.action<pauli_rotation>(%321#0, %cst_172) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_173 = arith.constant 1.5707963267948966 : f64
    %323 = qlx.apply #qlx.action<pauli_rotation>(%321#1, %cst_173) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_174 = arith.constant 1.5707963267948966 : f64
    %324:2 = qlx.apply #qlx.action<pauli_rotation>(%322, %323, %cst_174) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %325 = qlx.apply #qlx.action<h>(%204#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 3.1415926535897931 : f64
    %326 = qlx.apply #qlx.action<pauli_rotation>(%325, %cst_175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %327 = qlx.apply #qlx.action<h>(%326) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %328 = qlx.apply #qlx.action<h>(%324#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_176 = arith.constant 3.1415926535897931 : f64
    %329 = qlx.apply #qlx.action<pauli_rotation>(%328, %cst_176) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %330 = qlx.apply #qlx.action<h>(%329) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_177 = arith.constant 1.5707963267948966 : f64
    %331:2 = qlx.apply #qlx.action<pauli_rotation>(%327, %330, %cst_177) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %332 = qlx.apply #qlx.action<pauli_rotation>(%331#0, %cst_178) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_179 = arith.constant 1.5707963267948966 : f64
    %333 = qlx.apply #qlx.action<pauli_rotation>(%331#1, %cst_179) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_180 = arith.constant 1.5707963267948966 : f64
    %334:2 = qlx.apply #qlx.action<pauli_rotation>(%332, %333, %cst_180) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %335 = qlx.apply #qlx.action<h>(%214#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_181 = arith.constant 3.1415926535897931 : f64
    %336 = qlx.apply #qlx.action<pauli_rotation>(%335, %cst_181) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %337 = qlx.apply #qlx.action<h>(%336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %338 = qlx.apply #qlx.action<h>(%334#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_182 = arith.constant 3.1415926535897931 : f64
    %339 = qlx.apply #qlx.action<pauli_rotation>(%338, %cst_182) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %340 = qlx.apply #qlx.action<h>(%339) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_183 = arith.constant 1.5707963267948966 : f64
    %341:2 = qlx.apply #qlx.action<pauli_rotation>(%337, %340, %cst_183) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %342 = qlx.apply #qlx.action<pauli_rotation>(%341#0, %cst_184) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.5707963267948966 : f64
    %343 = qlx.apply #qlx.action<pauli_rotation>(%341#1, %cst_185) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_186 = arith.constant 1.5707963267948966 : f64
    %344:2 = qlx.apply #qlx.action<pauli_rotation>(%342, %343, %cst_186) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %345 = qlx.apply #qlx.action<h>(%224#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_187 = arith.constant 3.1415926535897931 : f64
    %346 = qlx.apply #qlx.action<pauli_rotation>(%345, %cst_187) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %347 = qlx.apply #qlx.action<h>(%346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %348 = qlx.apply #qlx.action<h>(%344#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_188 = arith.constant 3.1415926535897931 : f64
    %349 = qlx.apply #qlx.action<pauli_rotation>(%348, %cst_188) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %350 = qlx.apply #qlx.action<h>(%349) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_189 = arith.constant 1.5707963267948966 : f64
    %351:2 = qlx.apply #qlx.action<pauli_rotation>(%347, %350, %cst_189) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %352 = qlx.apply #qlx.action<pauli_rotation>(%351#0, %cst_190) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_191 = arith.constant 1.5707963267948966 : f64
    %353 = qlx.apply #qlx.action<pauli_rotation>(%351#1, %cst_191) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_192 = arith.constant 1.5707963267948966 : f64
    %354:2 = qlx.apply #qlx.action<pauli_rotation>(%352, %353, %cst_192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %355 = qlx.apply #qlx.action<h>(%234#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_193 = arith.constant 3.1415926535897931 : f64
    %356 = qlx.apply #qlx.action<pauli_rotation>(%355, %cst_193) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %357 = qlx.apply #qlx.action<h>(%356) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %358 = qlx.apply #qlx.action<h>(%354#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_194 = arith.constant 3.1415926535897931 : f64
    %359 = qlx.apply #qlx.action<pauli_rotation>(%358, %cst_194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %360 = qlx.apply #qlx.action<h>(%359) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_195 = arith.constant 1.5707963267948966 : f64
    %361:2 = qlx.apply #qlx.action<pauli_rotation>(%357, %360, %cst_195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %362 = qlx.apply #qlx.action<pauli_rotation>(%361#0, %cst_196) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.5707963267948966 : f64
    %363 = qlx.apply #qlx.action<pauli_rotation>(%361#1, %cst_197) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_198 = arith.constant 1.5707963267948966 : f64
    %364:2 = qlx.apply #qlx.action<pauli_rotation>(%362, %363, %cst_198) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %365 = qlx.apply #qlx.action<h>(%244#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_199 = arith.constant 3.1415926535897931 : f64
    %366 = qlx.apply #qlx.action<pauli_rotation>(%365, %cst_199) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %367 = qlx.apply #qlx.action<h>(%366) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %368 = qlx.apply #qlx.action<h>(%364#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_200 = arith.constant 3.1415926535897931 : f64
    %369 = qlx.apply #qlx.action<pauli_rotation>(%368, %cst_200) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %370 = qlx.apply #qlx.action<h>(%369) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 1.5707963267948966 : f64
    %371:2 = qlx.apply #qlx.action<pauli_rotation>(%367, %370, %cst_201) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_202 = arith.constant 1.5707963267948966 : f64
    %372 = qlx.apply #qlx.action<pauli_rotation>(%371#0, %cst_202) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %373 = qlx.apply #qlx.action<pauli_rotation>(%371#1, %cst_203) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_204 = arith.constant 1.5707963267948966 : f64
    %374:2 = qlx.apply #qlx.action<pauli_rotation>(%372, %373, %cst_204) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %375 = qlx.apply #qlx.action<h>(%254#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_205 = arith.constant 3.1415926535897931 : f64
    %376 = qlx.apply #qlx.action<pauli_rotation>(%375, %cst_205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %377 = qlx.apply #qlx.action<h>(%376) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %378 = qlx.apply #qlx.action<h>(%374#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_206 = arith.constant 3.1415926535897931 : f64
    %379 = qlx.apply #qlx.action<pauli_rotation>(%378, %cst_206) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %380 = qlx.apply #qlx.action<h>(%379) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %381:2 = qlx.apply #qlx.action<pauli_rotation>(%377, %380, %cst_207) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %382 = qlx.apply #qlx.action<pauli_rotation>(%381#0, %cst_208) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %383 = qlx.apply #qlx.action<pauli_rotation>(%381#1, %cst_209) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %384:2 = qlx.apply #qlx.action<pauli_rotation>(%382, %383, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %385 = qlx.apply #qlx.action<h>(%264#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_211 = arith.constant 2.3561944901923448 : f64
    %386 = qlx.apply #qlx.action<pauli_rotation>(%385, %cst_211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %387 = qlx.apply #qlx.action<h>(%386) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %388 = qlx.apply #qlx.action<h>(%384#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 3.1415926535897931 : f64
    %389 = qlx.apply #qlx.action<pauli_rotation>(%388, %cst_212) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %390 = qlx.apply #qlx.action<h>(%389) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 1.5707963267948966 : f64
    %391:2 = qlx.apply #qlx.action<pauli_rotation>(%387, %390, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %392 = qlx.apply #qlx.action<pauli_rotation>(%391#0, %cst_214) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%391#1, %cst_215) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_216 = arith.constant 1.5707963267948966 : f64
    %394:2 = qlx.apply #qlx.action<pauli_rotation>(%392, %393, %cst_216) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %395 = qlx.apply #qlx.action<h>(%274#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_217 = arith.constant 2.3561944901923448 : f64
    %396 = qlx.apply #qlx.action<pauli_rotation>(%395, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %397 = qlx.apply #qlx.action<h>(%396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %398 = qlx.apply #qlx.action<h>(%394#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_218 = arith.constant 2.3561944901923448 : f64
    %399 = qlx.apply #qlx.action<pauli_rotation>(%398, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %400 = qlx.apply #qlx.action<h>(%399) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_219 = arith.constant 0.78539816339744828 : f64
    %401:2 = qlx.apply #qlx.action<pauli_rotation>(%397, %400, %cst_219) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %402 = qlx.apply #qlx.action<pauli_rotation>(%401#0, %cst_220) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_221 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%401#1, %cst_221) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_222 = arith.constant 0.78539816339744828 : f64
    %404:2 = qlx.apply #qlx.action<pauli_rotation>(%402, %403, %cst_222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %405 = qlx.apply #qlx.action<h>(%304#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_223 = arith.constant 3.1415926535897931 : f64
    %406 = qlx.apply #qlx.action<pauli_rotation>(%405, %cst_223) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %407 = qlx.apply #qlx.action<h>(%406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %408 = qlx.apply #qlx.action<h>(%47#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_224 = arith.constant 1.5707963267948966 : f64
    %409:2 = qlx.apply #qlx.action<pauli_rotation>(%407, %408, %cst_224) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_225 = arith.constant 1.5707963267948966 : f64
    %410 = qlx.apply #qlx.action<pauli_rotation>(%409#0, %cst_225) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %411 = qlx.apply #qlx.action<pauli_rotation>(%409#1, %cst_226) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_227 = arith.constant 1.5707963267948966 : f64
    %412:2 = qlx.apply #qlx.action<pauli_rotation>(%410, %411, %cst_227) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %413 = qlx.apply #qlx.action<h>(%314#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_228 = arith.constant 3.1415926535897931 : f64
    %414 = qlx.apply #qlx.action<pauli_rotation>(%413, %cst_228) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %415 = qlx.apply #qlx.action<h>(%414) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %416 = qlx.apply #qlx.action<h>(%412#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_229 = arith.constant 3.1415926535897931 : f64
    %417 = qlx.apply #qlx.action<pauli_rotation>(%416, %cst_229) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %418 = qlx.apply #qlx.action<h>(%417) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_230 = arith.constant 1.5707963267948966 : f64
    %419:2 = qlx.apply #qlx.action<pauli_rotation>(%415, %418, %cst_230) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %420 = qlx.apply #qlx.action<pauli_rotation>(%419#0, %cst_231) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_232 = arith.constant 1.5707963267948966 : f64
    %421 = qlx.apply #qlx.action<pauli_rotation>(%419#1, %cst_232) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_233 = arith.constant 1.5707963267948966 : f64
    %422:2 = qlx.apply #qlx.action<pauli_rotation>(%420, %421, %cst_233) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %423 = qlx.apply #qlx.action<h>(%324#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_234 = arith.constant 3.1415926535897931 : f64
    %424 = qlx.apply #qlx.action<pauli_rotation>(%423, %cst_234) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %425 = qlx.apply #qlx.action<h>(%424) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %426 = qlx.apply #qlx.action<h>(%422#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_235 = arith.constant 3.1415926535897931 : f64
    %427 = qlx.apply #qlx.action<pauli_rotation>(%426, %cst_235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %428 = qlx.apply #qlx.action<h>(%427) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 1.5707963267948966 : f64
    %429:2 = qlx.apply #qlx.action<pauli_rotation>(%425, %428, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_237 = arith.constant 1.5707963267948966 : f64
    %430 = qlx.apply #qlx.action<pauli_rotation>(%429#0, %cst_237) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_238 = arith.constant 1.5707963267948966 : f64
    %431 = qlx.apply #qlx.action<pauli_rotation>(%429#1, %cst_238) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_239 = arith.constant 1.5707963267948966 : f64
    %432:2 = qlx.apply #qlx.action<pauli_rotation>(%430, %431, %cst_239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %433 = qlx.apply #qlx.action<h>(%334#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_240 = arith.constant 3.1415926535897931 : f64
    %434 = qlx.apply #qlx.action<pauli_rotation>(%433, %cst_240) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %435 = qlx.apply #qlx.action<h>(%434) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %436 = qlx.apply #qlx.action<h>(%432#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 3.1415926535897931 : f64
    %437 = qlx.apply #qlx.action<pauli_rotation>(%436, %cst_241) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %438 = qlx.apply #qlx.action<h>(%437) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_242 = arith.constant 1.5707963267948966 : f64
    %439:2 = qlx.apply #qlx.action<pauli_rotation>(%435, %438, %cst_242) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_243 = arith.constant 1.5707963267948966 : f64
    %440 = qlx.apply #qlx.action<pauli_rotation>(%439#0, %cst_243) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_244 = arith.constant 1.5707963267948966 : f64
    %441 = qlx.apply #qlx.action<pauli_rotation>(%439#1, %cst_244) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_245 = arith.constant 1.5707963267948966 : f64
    %442:2 = qlx.apply #qlx.action<pauli_rotation>(%440, %441, %cst_245) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %443 = qlx.apply #qlx.action<h>(%344#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_246 = arith.constant 3.1415926535897931 : f64
    %444 = qlx.apply #qlx.action<pauli_rotation>(%443, %cst_246) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %445 = qlx.apply #qlx.action<h>(%444) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %446 = qlx.apply #qlx.action<h>(%442#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_247 = arith.constant 3.1415926535897931 : f64
    %447 = qlx.apply #qlx.action<pauli_rotation>(%446, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %448 = qlx.apply #qlx.action<h>(%447) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_248 = arith.constant 1.5707963267948966 : f64
    %449:2 = qlx.apply #qlx.action<pauli_rotation>(%445, %448, %cst_248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_249 = arith.constant 1.5707963267948966 : f64
    %450 = qlx.apply #qlx.action<pauli_rotation>(%449#0, %cst_249) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_250 = arith.constant 1.5707963267948966 : f64
    %451 = qlx.apply #qlx.action<pauli_rotation>(%449#1, %cst_250) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_251 = arith.constant 1.5707963267948966 : f64
    %452:2 = qlx.apply #qlx.action<pauli_rotation>(%450, %451, %cst_251) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %453 = qlx.apply #qlx.action<h>(%354#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_252 = arith.constant 3.1415926535897931 : f64
    %454 = qlx.apply #qlx.action<pauli_rotation>(%453, %cst_252) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %455 = qlx.apply #qlx.action<h>(%454) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %456 = qlx.apply #qlx.action<h>(%452#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_253 = arith.constant 3.1415926535897931 : f64
    %457 = qlx.apply #qlx.action<pauli_rotation>(%456, %cst_253) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %458 = qlx.apply #qlx.action<h>(%457) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_254 = arith.constant 1.5707963267948966 : f64
    %459:2 = qlx.apply #qlx.action<pauli_rotation>(%455, %458, %cst_254) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_255 = arith.constant 1.5707963267948966 : f64
    %460 = qlx.apply #qlx.action<pauli_rotation>(%459#0, %cst_255) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %461 = qlx.apply #qlx.action<pauli_rotation>(%459#1, %cst_256) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %462:2 = qlx.apply #qlx.action<pauli_rotation>(%460, %461, %cst_257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %463 = qlx.apply #qlx.action<h>(%364#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_258 = arith.constant 3.1415926535897931 : f64
    %464 = qlx.apply #qlx.action<pauli_rotation>(%463, %cst_258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %465 = qlx.apply #qlx.action<h>(%464) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %466 = qlx.apply #qlx.action<h>(%462#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_259 = arith.constant 3.1415926535897931 : f64
    %467 = qlx.apply #qlx.action<pauli_rotation>(%466, %cst_259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %468 = qlx.apply #qlx.action<h>(%467) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %469:2 = qlx.apply #qlx.action<pauli_rotation>(%465, %468, %cst_260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_261 = arith.constant 1.5707963267948966 : f64
    %470 = qlx.apply #qlx.action<pauli_rotation>(%469#0, %cst_261) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %471 = qlx.apply #qlx.action<pauli_rotation>(%469#1, %cst_262) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %472:2 = qlx.apply #qlx.action<pauli_rotation>(%470, %471, %cst_263) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %473 = qlx.apply #qlx.action<h>(%374#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_264 = arith.constant 3.1415926535897931 : f64
    %474 = qlx.apply #qlx.action<pauli_rotation>(%473, %cst_264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %475 = qlx.apply #qlx.action<h>(%474) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %476 = qlx.apply #qlx.action<h>(%472#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_265 = arith.constant 3.1415926535897931 : f64
    %477 = qlx.apply #qlx.action<pauli_rotation>(%476, %cst_265) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %478 = qlx.apply #qlx.action<h>(%477) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_266 = arith.constant 1.5707963267948966 : f64
    %479:2 = qlx.apply #qlx.action<pauli_rotation>(%475, %478, %cst_266) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %480 = qlx.apply #qlx.action<pauli_rotation>(%479#0, %cst_267) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %481 = qlx.apply #qlx.action<pauli_rotation>(%479#1, %cst_268) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_269 = arith.constant 1.5707963267948966 : f64
    %482:2 = qlx.apply #qlx.action<pauli_rotation>(%480, %481, %cst_269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %483 = qlx.apply #qlx.action<h>(%384#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_270 = arith.constant 2.3561944901923448 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%483, %cst_270) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %485 = qlx.apply #qlx.action<h>(%484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %486 = qlx.apply #qlx.action<h>(%482#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_271 = arith.constant 2.3561944901923448 : f64
    %487 = qlx.apply #qlx.action<pauli_rotation>(%486, %cst_271) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %488 = qlx.apply #qlx.action<h>(%487) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_272 = arith.constant 0.78539816339744828 : f64
    %489:2 = qlx.apply #qlx.action<pauli_rotation>(%485, %488, %cst_272) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%489#0, %cst_273) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %491 = qlx.apply #qlx.action<pauli_rotation>(%489#1, %cst_274) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_275 = arith.constant 0.78539816339744828 : f64
    %492:2 = qlx.apply #qlx.action<pauli_rotation>(%490, %491, %cst_275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %493 = qlx.apply #qlx.action<h>(%394#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_276 = arith.constant 3.1415926535897931 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493, %cst_276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %495 = qlx.apply #qlx.action<h>(%494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %496 = qlx.apply #qlx.action<h>(%492#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 2.3561944901923448 : f64
    %497 = qlx.apply #qlx.action<pauli_rotation>(%496, %cst_277) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %498 = qlx.apply #qlx.action<h>(%497) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 1.5707963267948966 : f64
    %499:2 = qlx.apply #qlx.action<pauli_rotation>(%495, %498, %cst_278) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%499#0, %cst_279) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %501 = qlx.apply #qlx.action<pauli_rotation>(%499#1, %cst_280) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_281 = arith.constant 1.5707963267948966 : f64
    %502:2 = qlx.apply #qlx.action<pauli_rotation>(%500, %501, %cst_281) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %503 = qlx.apply #qlx.action<h>(%404#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_282 = arith.constant 2.3561944901923448 : f64
    %504 = qlx.apply #qlx.action<pauli_rotation>(%503, %cst_282) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %505 = qlx.apply #qlx.action<h>(%504) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %506 = qlx.apply #qlx.action<h>(%502#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_283 = arith.constant 1.5707963267948966 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%506, %cst_283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %508 = qlx.apply #qlx.action<h>(%507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_284 = arith.constant 1.000000e+00 : f64
    %509:2 = qlx.apply #qlx.action<pauli_rotation>(%505, %508, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_285 = arith.constant 1.5707963267948966 : f64
    %510 = qlx.apply #qlx.action<pauli_rotation>(%509#0, %cst_285) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %511 = qlx.apply #qlx.action<pauli_rotation>(%509#1, %cst_286) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.000000e+00 : f64
    %512:2 = qlx.apply #qlx.action<pauli_rotation>(%510, %511, %cst_287) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %513 = qlx.apply #qlx.action<h>(%404#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_288 = arith.constant 1.5707963267948966 : f64
    %514 = qlx.apply #qlx.action<pauli_rotation>(%513, %cst_288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %515 = qlx.apply #qlx.action<h>(%514) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %516 = qlx.apply #qlx.action<h>(%512#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 0.78539816339744828 : f64
    %517 = qlx.apply #qlx.action<pauli_rotation>(%516, %cst_289) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %518 = qlx.apply #qlx.action<h>(%517) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_290 = arith.constant 0.78539816339744828 : f64
    %519:2 = qlx.apply #qlx.action<pauli_rotation>(%515, %518, %cst_290) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_291 = arith.constant 1.5707963267948966 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%519#0, %cst_291) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_292 = arith.constant 1.5707963267948966 : f64
    %521 = qlx.apply #qlx.action<pauli_rotation>(%519#1, %cst_292) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_293 = arith.constant 0.78539816339744828 : f64
    %522:2 = qlx.apply #qlx.action<pauli_rotation>(%520, %521, %cst_293) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %523 = qlx.apply #qlx.action<h>(%452#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_294 = arith.constant 3.1415926535897931 : f64
    %524 = qlx.apply #qlx.action<pauli_rotation>(%523, %cst_294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %525 = qlx.apply #qlx.action<h>(%524) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %526 = qlx.apply #qlx.action<h>(%442#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 3.1415926535897931 : f64
    %527 = qlx.apply #qlx.action<pauli_rotation>(%526, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %528 = qlx.apply #qlx.action<h>(%527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_296 = arith.constant 1.5707963267948966 : f64
    %529:2 = qlx.apply #qlx.action<pauli_rotation>(%525, %528, %cst_296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_297 = arith.constant 1.5707963267948966 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%529#0, %cst_297) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %531 = qlx.apply #qlx.action<pauli_rotation>(%529#1, %cst_298) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %532:2 = qlx.apply #qlx.action<pauli_rotation>(%530, %531, %cst_299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %533 = qlx.apply #qlx.action<h>(%462#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_300 = arith.constant 3.1415926535897931 : f64
    %534 = qlx.apply #qlx.action<pauli_rotation>(%533, %cst_300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %535 = qlx.apply #qlx.action<h>(%534) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %536 = qlx.apply #qlx.action<h>(%532#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_301 = arith.constant 3.1415926535897931 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%536, %cst_301) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %538 = qlx.apply #qlx.action<h>(%537) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_302 = arith.constant 1.5707963267948966 : f64
    %539:2 = qlx.apply #qlx.action<pauli_rotation>(%535, %538, %cst_302) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_303 = arith.constant 1.5707963267948966 : f64
    %540 = qlx.apply #qlx.action<pauli_rotation>(%539#0, %cst_303) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_304 = arith.constant 1.5707963267948966 : f64
    %541 = qlx.apply #qlx.action<pauli_rotation>(%539#1, %cst_304) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %542:2 = qlx.apply #qlx.action<pauli_rotation>(%540, %541, %cst_305) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %543 = qlx.apply #qlx.action<h>(%472#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_306 = arith.constant 3.1415926535897931 : f64
    %544 = qlx.apply #qlx.action<pauli_rotation>(%543, %cst_306) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %545 = qlx.apply #qlx.action<h>(%544) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %546 = qlx.apply #qlx.action<h>(%542#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 3.1415926535897931 : f64
    %547 = qlx.apply #qlx.action<pauli_rotation>(%546, %cst_307) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %548 = qlx.apply #qlx.action<h>(%547) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %549:2 = qlx.apply #qlx.action<pauli_rotation>(%545, %548, %cst_308) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_309 = arith.constant 1.5707963267948966 : f64
    %550 = qlx.apply #qlx.action<pauli_rotation>(%549#0, %cst_309) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %551 = qlx.apply #qlx.action<pauli_rotation>(%549#1, %cst_310) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_311 = arith.constant 1.5707963267948966 : f64
    %552:2 = qlx.apply #qlx.action<pauli_rotation>(%550, %551, %cst_311) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %553 = qlx.apply #qlx.action<h>(%482#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_312 = arith.constant 2.3561944901923448 : f64
    %554 = qlx.apply #qlx.action<pauli_rotation>(%553, %cst_312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %555 = qlx.apply #qlx.action<h>(%554) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %556 = qlx.apply #qlx.action<h>(%552#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 2.3561944901923448 : f64
    %557 = qlx.apply #qlx.action<pauli_rotation>(%556, %cst_313) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %558 = qlx.apply #qlx.action<h>(%557) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_314 = arith.constant 0.78539816339744828 : f64
    %559:2 = qlx.apply #qlx.action<pauli_rotation>(%555, %558, %cst_314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_315 = arith.constant 1.5707963267948966 : f64
    %560 = qlx.apply #qlx.action<pauli_rotation>(%559#0, %cst_315) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %561 = qlx.apply #qlx.action<pauli_rotation>(%559#1, %cst_316) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_317 = arith.constant 0.78539816339744828 : f64
    %562:2 = qlx.apply #qlx.action<pauli_rotation>(%560, %561, %cst_317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %563 = qlx.apply #qlx.action<h>(%432#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_318 = arith.constant 3.1415926535897931 : f64
    %564 = qlx.apply #qlx.action<pauli_rotation>(%563, %cst_318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %565 = qlx.apply #qlx.action<h>(%564) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %566 = qlx.apply #qlx.action<h>(%422#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 3.1415926535897931 : f64
    %567 = qlx.apply #qlx.action<pauli_rotation>(%566, %cst_319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %568 = qlx.apply #qlx.action<h>(%567) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_320 = arith.constant 1.5707963267948966 : f64
    %569:2 = qlx.apply #qlx.action<pauli_rotation>(%565, %568, %cst_320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_321 = arith.constant 1.5707963267948966 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%569#0, %cst_321) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %571 = qlx.apply #qlx.action<pauli_rotation>(%569#1, %cst_322) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %572:2 = qlx.apply #qlx.action<pauli_rotation>(%570, %571, %cst_323) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %573 = qlx.apply #qlx.action<h>(%532#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_324 = arith.constant 3.1415926535897931 : f64
    %574 = qlx.apply #qlx.action<pauli_rotation>(%573, %cst_324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %575 = qlx.apply #qlx.action<h>(%574) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %576 = qlx.apply #qlx.action<h>(%572#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_325 = arith.constant 3.1415926535897931 : f64
    %577 = qlx.apply #qlx.action<pauli_rotation>(%576, %cst_325) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %578 = qlx.apply #qlx.action<h>(%577) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_326 = arith.constant 1.5707963267948966 : f64
    %579:2 = qlx.apply #qlx.action<pauli_rotation>(%575, %578, %cst_326) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_327 = arith.constant 1.5707963267948966 : f64
    %580 = qlx.apply #qlx.action<pauli_rotation>(%579#0, %cst_327) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %581 = qlx.apply #qlx.action<pauli_rotation>(%579#1, %cst_328) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_329 = arith.constant 1.5707963267948966 : f64
    %582:2 = qlx.apply #qlx.action<pauli_rotation>(%580, %581, %cst_329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %583 = qlx.apply #qlx.action<h>(%542#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_330 = arith.constant 2.3561944901923448 : f64
    %584 = qlx.apply #qlx.action<pauli_rotation>(%583, %cst_330) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %585 = qlx.apply #qlx.action<h>(%584) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %586 = qlx.apply #qlx.action<h>(%582#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_331 = arith.constant 2.3561944901923448 : f64
    %587 = qlx.apply #qlx.action<pauli_rotation>(%586, %cst_331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %588 = qlx.apply #qlx.action<h>(%587) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_332 = arith.constant 0.78539816339744828 : f64
    %589:2 = qlx.apply #qlx.action<pauli_rotation>(%585, %588, %cst_332) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_333 = arith.constant 1.5707963267948966 : f64
    %590 = qlx.apply #qlx.action<pauli_rotation>(%589#0, %cst_333) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %591 = qlx.apply #qlx.action<pauli_rotation>(%589#1, %cst_334) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_335 = arith.constant 0.78539816339744828 : f64
    %592:2 = qlx.apply #qlx.action<pauli_rotation>(%590, %591, %cst_335) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %593 = qlx.apply #qlx.action<h>(%552#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_336 = arith.constant 3.1415926535897931 : f64
    %594 = qlx.apply #qlx.action<pauli_rotation>(%593, %cst_336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %595 = qlx.apply #qlx.action<h>(%594) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %596 = qlx.apply #qlx.action<h>(%592#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_337 = arith.constant 2.3561944901923448 : f64
    %597 = qlx.apply #qlx.action<pauli_rotation>(%596, %cst_337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %598 = qlx.apply #qlx.action<h>(%597) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %599:2 = qlx.apply #qlx.action<pauli_rotation>(%595, %598, %cst_338) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_339 = arith.constant 1.5707963267948966 : f64
    %600 = qlx.apply #qlx.action<pauli_rotation>(%599#0, %cst_339) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %601 = qlx.apply #qlx.action<pauli_rotation>(%599#1, %cst_340) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %602:2 = qlx.apply #qlx.action<pauli_rotation>(%600, %601, %cst_341) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %603 = qlx.apply #qlx.action<h>(%562#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_342 = arith.constant 2.3561944901923448 : f64
    %604 = qlx.apply #qlx.action<pauli_rotation>(%603, %cst_342) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %605 = qlx.apply #qlx.action<h>(%604) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %606 = qlx.apply #qlx.action<h>(%602#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_343 = arith.constant 1.5707963267948966 : f64
    %607 = qlx.apply #qlx.action<pauli_rotation>(%606, %cst_343) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %608 = qlx.apply #qlx.action<h>(%607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_344 = arith.constant 1.000000e+00 : f64
    %609:2 = qlx.apply #qlx.action<pauli_rotation>(%605, %608, %cst_344) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %610 = qlx.apply #qlx.action<pauli_rotation>(%609#0, %cst_345) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_346 = arith.constant 1.5707963267948966 : f64
    %611 = qlx.apply #qlx.action<pauli_rotation>(%609#1, %cst_346) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_347 = arith.constant 1.000000e+00 : f64
    %612:2 = qlx.apply #qlx.action<pauli_rotation>(%610, %611, %cst_347) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %613 = qlx.apply #qlx.action<h>(%562#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %614 = qlx.apply #qlx.action<pauli_rotation>(%613, %cst_348) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %615 = qlx.apply #qlx.action<h>(%614) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %616 = qlx.apply #qlx.action<h>(%612#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_349 = arith.constant 0.78539816339744828 : f64
    %617 = qlx.apply #qlx.action<pauli_rotation>(%616, %cst_349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %618 = qlx.apply #qlx.action<h>(%617) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_350 = arith.constant 0.78539816339744828 : f64
    %619:2 = qlx.apply #qlx.action<pauli_rotation>(%615, %618, %cst_350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_351 = arith.constant 1.5707963267948966 : f64
    %620 = qlx.apply #qlx.action<pauli_rotation>(%619#0, %cst_351) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %621 = qlx.apply #qlx.action<pauli_rotation>(%619#1, %cst_352) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_353 = arith.constant 0.78539816339744828 : f64
    %622:2 = qlx.apply #qlx.action<pauli_rotation>(%620, %621, %cst_353) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %623 = qlx.apply #qlx.action<h>(%602#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_354 = arith.constant 3.1415926535897931 : f64
    %624 = qlx.apply #qlx.action<pauli_rotation>(%623, %cst_354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %625 = qlx.apply #qlx.action<h>(%624) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %626 = qlx.apply #qlx.action<h>(%592#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_355 = arith.constant 2.3561944901923448 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%626, %cst_355) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %628 = qlx.apply #qlx.action<h>(%627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_356 = arith.constant 1.5707963267948966 : f64
    %629:2 = qlx.apply #qlx.action<pauli_rotation>(%625, %628, %cst_356) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_357 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%629#0, %cst_357) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %631 = qlx.apply #qlx.action<pauli_rotation>(%629#1, %cst_358) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %632:2 = qlx.apply #qlx.action<pauli_rotation>(%630, %631, %cst_359) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %633 = qlx.apply #qlx.action<h>(%612#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_360 = arith.constant 2.3561944901923448 : f64
    %634 = qlx.apply #qlx.action<pauli_rotation>(%633, %cst_360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %635 = qlx.apply #qlx.action<h>(%634) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %636 = qlx.apply #qlx.action<h>(%632#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_361 = arith.constant 2.3561944901923448 : f64
    %637 = qlx.apply #qlx.action<pauli_rotation>(%636, %cst_361) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %638 = qlx.apply #qlx.action<h>(%637) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_362 = arith.constant 0.78539816339744828 : f64
    %639:2 = qlx.apply #qlx.action<pauli_rotation>(%635, %638, %cst_362) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %640 = qlx.apply #qlx.action<pauli_rotation>(%639#0, %cst_363) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_364 = arith.constant 1.5707963267948966 : f64
    %641 = qlx.apply #qlx.action<pauli_rotation>(%639#1, %cst_364) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_365 = arith.constant 0.78539816339744828 : f64
    %642:2 = qlx.apply #qlx.action<pauli_rotation>(%640, %641, %cst_365) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %643 = qlx.apply #qlx.action<h>(%582#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_366 = arith.constant 3.1415926535897931 : f64
    %644 = qlx.apply #qlx.action<pauli_rotation>(%643, %cst_366) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %645 = qlx.apply #qlx.action<h>(%644) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %646 = qlx.apply #qlx.action<h>(%572#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_367 = arith.constant 3.1415926535897931 : f64
    %647 = qlx.apply #qlx.action<pauli_rotation>(%646, %cst_367) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %648 = qlx.apply #qlx.action<h>(%647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_368 = arith.constant 1.5707963267948966 : f64
    %649:2 = qlx.apply #qlx.action<pauli_rotation>(%645, %648, %cst_368) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_369 = arith.constant 1.5707963267948966 : f64
    %650 = qlx.apply #qlx.action<pauli_rotation>(%649#0, %cst_369) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %651 = qlx.apply #qlx.action<pauli_rotation>(%649#1, %cst_370) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %652:2 = qlx.apply #qlx.action<pauli_rotation>(%650, %651, %cst_371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %653 = qlx.apply #qlx.action<h>(%632#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_372 = arith.constant 2.3561944901923448 : f64
    %654 = qlx.apply #qlx.action<pauli_rotation>(%653, %cst_372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %655 = qlx.apply #qlx.action<h>(%654) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %656 = qlx.apply #qlx.action<h>(%652#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_373 = arith.constant 2.3561944901923448 : f64
    %657 = qlx.apply #qlx.action<pauli_rotation>(%656, %cst_373) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %658 = qlx.apply #qlx.action<h>(%657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_374 = arith.constant 0.78539816339744828 : f64
    %659:2 = qlx.apply #qlx.action<pauli_rotation>(%655, %658, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_375 = arith.constant 1.5707963267948966 : f64
    %660 = qlx.apply #qlx.action<pauli_rotation>(%659#0, %cst_375) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%659#1, %cst_376) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_377 = arith.constant 0.78539816339744828 : f64
    %662:2 = qlx.apply #qlx.action<pauli_rotation>(%660, %661, %cst_377) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %663 = qlx.apply #qlx.action<h>(%652#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_378 = arith.constant 2.3561944901923448 : f64
    %664 = qlx.apply #qlx.action<pauli_rotation>(%663, %cst_378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %666 = qlx.apply #qlx.action<h>(%412#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_379 = arith.constant 2.3561944901923448 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%666, %cst_379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %668 = qlx.apply #qlx.action<h>(%667) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_380 = arith.constant 0.78539816339744828 : f64
    %669:2 = qlx.apply #qlx.action<pauli_rotation>(%665, %668, %cst_380) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_381 = arith.constant 1.5707963267948966 : f64
    %670 = qlx.apply #qlx.action<pauli_rotation>(%669#0, %cst_381) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_382 = arith.constant 1.5707963267948966 : f64
    %671 = qlx.apply #qlx.action<pauli_rotation>(%669#1, %cst_382) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_383 = arith.constant 0.78539816339744828 : f64
    %672:2 = qlx.apply #qlx.action<pauli_rotation>(%670, %671, %cst_383) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %673 = qlx.apply #qlx.action<h>(%662#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_384 = arith.constant 2.3561944901923448 : f64
    %674 = qlx.apply #qlx.action<pauli_rotation>(%673, %cst_384) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %675 = qlx.apply #qlx.action<h>(%674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %676 = qlx.apply #qlx.action<h>(%672#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_385 = arith.constant 0.78539816339744828 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676, %cst_385) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %678 = qlx.apply #qlx.action<h>(%677) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_386 = arith.constant 1.000000e+00 : f64
    %679:2 = qlx.apply #qlx.action<pauli_rotation>(%675, %678, %cst_386) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_387 = arith.constant 1.5707963267948966 : f64
    %680 = qlx.apply #qlx.action<pauli_rotation>(%679#0, %cst_387) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_388 = arith.constant 1.5707963267948966 : f64
    %681 = qlx.apply #qlx.action<pauli_rotation>(%679#1, %cst_388) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_389 = arith.constant 1.000000e+00 : f64
    %682:2 = qlx.apply #qlx.action<pauli_rotation>(%680, %681, %cst_389) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %683 = qlx.apply #qlx.action<h>(%662#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_390 = arith.constant 1.5707963267948966 : f64
    %684 = qlx.apply #qlx.action<pauli_rotation>(%683, %cst_390) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %685 = qlx.apply #qlx.action<h>(%684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %686 = qlx.apply #qlx.action<h>(%682#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_391 = arith.constant 0.78539816339744828 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686, %cst_391) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %688 = qlx.apply #qlx.action<h>(%687) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_392 = arith.constant 0.78539816339744828 : f64
    %689:2 = qlx.apply #qlx.action<pauli_rotation>(%685, %688, %cst_392) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_393 = arith.constant 1.5707963267948966 : f64
    %690 = qlx.apply #qlx.action<pauli_rotation>(%689#0, %cst_393) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_394 = arith.constant 1.5707963267948966 : f64
    %691 = qlx.apply #qlx.action<pauli_rotation>(%689#1, %cst_394) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_395 = arith.constant 0.78539816339744828 : f64
    %692:2 = qlx.apply #qlx.action<pauli_rotation>(%690, %691, %cst_395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %693 = qlx.apply #qlx.action<h>(%682#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_396 = arith.constant 2.3561944901923448 : f64
    %694 = qlx.apply #qlx.action<pauli_rotation>(%693, %cst_396) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %695 = qlx.apply #qlx.action<h>(%694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %696 = qlx.apply #qlx.action<h>(%672#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %697 = qlx.apply #qlx.action<pauli_rotation>(%696, %cst_397) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %698 = qlx.apply #qlx.action<h>(%697) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_398 = arith.constant 0.78539816339744828 : f64
    %699:2 = qlx.apply #qlx.action<pauli_rotation>(%695, %698, %cst_398) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_399 = arith.constant 1.5707963267948966 : f64
    %700 = qlx.apply #qlx.action<pauli_rotation>(%699#0, %cst_399) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_400 = arith.constant 1.5707963267948966 : f64
    %701 = qlx.apply #qlx.action<pauli_rotation>(%699#1, %cst_400) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_401 = arith.constant 0.78539816339744828 : f64
    %702:2 = qlx.apply #qlx.action<pauli_rotation>(%700, %701, %cst_401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %703 = qlx.apply #qlx.action<h>(%59#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %704 = qlx.apply #qlx.action<h>(%61#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %705:2 = qlx.apply #qlx.action<pauli_rotation>(%703, %704, %cst_402) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_403 = arith.constant 1.5707963267948966 : f64
    %706 = qlx.apply #qlx.action<pauli_rotation>(%705#0, %cst_403) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_404 = arith.constant 1.5707963267948966 : f64
    %707 = qlx.apply #qlx.action<pauli_rotation>(%705#1, %cst_404) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_405 = arith.constant 1.5707963267948966 : f64
    %708:2 = qlx.apply #qlx.action<pauli_rotation>(%706, %707, %cst_405) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %709 = qlx.apply #qlx.action<h>(%59#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %710 = qlx.apply #qlx.action<h>(%708#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_406 = arith.constant 3.1415926535897931 : f64
    %711 = qlx.apply #qlx.action<pauli_rotation>(%710, %cst_406) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%711) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %713:2 = qlx.apply #qlx.action<pauli_rotation>(%709, %712, %cst_407) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %714 = qlx.apply #qlx.action<pauli_rotation>(%713#0, %cst_408) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_409 = arith.constant 1.5707963267948966 : f64
    %715 = qlx.apply #qlx.action<pauli_rotation>(%713#1, %cst_409) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_410 = arith.constant 1.5707963267948966 : f64
    %716:2 = qlx.apply #qlx.action<pauli_rotation>(%714, %715, %cst_410) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %717 = qlx.apply #qlx.action<h>(%57#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %718 = qlx.apply #qlx.action<h>(%716#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_411 = arith.constant 3.1415926535897931 : f64
    %719 = qlx.apply #qlx.action<pauli_rotation>(%718, %cst_411) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %720 = qlx.apply #qlx.action<h>(%719) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_412 = arith.constant 1.5707963267948966 : f64
    %721:2 = qlx.apply #qlx.action<pauli_rotation>(%717, %720, %cst_412) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %722 = qlx.apply #qlx.action<pauli_rotation>(%721#0, %cst_413) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %723 = qlx.apply #qlx.action<pauli_rotation>(%721#1, %cst_414) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_415 = arith.constant 1.5707963267948966 : f64
    %724:2 = qlx.apply #qlx.action<pauli_rotation>(%722, %723, %cst_415) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %725 = qlx.apply #qlx.action<h>(%57#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %726 = qlx.apply #qlx.action<h>(%724#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_416 = arith.constant 3.1415926535897931 : f64
    %727 = qlx.apply #qlx.action<pauli_rotation>(%726, %cst_416) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %728 = qlx.apply #qlx.action<h>(%727) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %729:2 = qlx.apply #qlx.action<pauli_rotation>(%725, %728, %cst_417) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %730 = qlx.apply #qlx.action<pauli_rotation>(%729#0, %cst_418) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.5707963267948966 : f64
    %731 = qlx.apply #qlx.action<pauli_rotation>(%729#1, %cst_419) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %732:2 = qlx.apply #qlx.action<pauli_rotation>(%730, %731, %cst_420) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %733 = qlx.apply #qlx.action<h>(%55#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %734 = qlx.apply #qlx.action<h>(%732#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_421 = arith.constant 3.1415926535897931 : f64
    %735 = qlx.apply #qlx.action<pauli_rotation>(%734, %cst_421) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %736 = qlx.apply #qlx.action<h>(%735) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_422 = arith.constant 1.5707963267948966 : f64
    %737:2 = qlx.apply #qlx.action<pauli_rotation>(%733, %736, %cst_422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_423 = arith.constant 1.5707963267948966 : f64
    %738 = qlx.apply #qlx.action<pauli_rotation>(%737#0, %cst_423) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %739 = qlx.apply #qlx.action<pauli_rotation>(%737#1, %cst_424) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %740:2 = qlx.apply #qlx.action<pauli_rotation>(%738, %739, %cst_425) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %741 = qlx.apply #qlx.action<h>(%55#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %742 = qlx.apply #qlx.action<h>(%740#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_426 = arith.constant 3.1415926535897931 : f64
    %743 = qlx.apply #qlx.action<pauli_rotation>(%742, %cst_426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %744 = qlx.apply #qlx.action<h>(%743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 1.5707963267948966 : f64
    %745:2 = qlx.apply #qlx.action<pauli_rotation>(%741, %744, %cst_427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_428 = arith.constant 1.5707963267948966 : f64
    %746 = qlx.apply #qlx.action<pauli_rotation>(%745#0, %cst_428) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_429 = arith.constant 1.5707963267948966 : f64
    %747 = qlx.apply #qlx.action<pauli_rotation>(%745#1, %cst_429) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_430 = arith.constant 1.5707963267948966 : f64
    %748:2 = qlx.apply #qlx.action<pauli_rotation>(%746, %747, %cst_430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %749 = qlx.apply #qlx.action<h>(%53#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %750 = qlx.apply #qlx.action<h>(%748#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_431 = arith.constant 3.1415926535897931 : f64
    %751 = qlx.apply #qlx.action<pauli_rotation>(%750, %cst_431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %752 = qlx.apply #qlx.action<h>(%751) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_432 = arith.constant 1.5707963267948966 : f64
    %753:2 = qlx.apply #qlx.action<pauli_rotation>(%749, %752, %cst_432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_433 = arith.constant 1.5707963267948966 : f64
    %754 = qlx.apply #qlx.action<pauli_rotation>(%753#0, %cst_433) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_434 = arith.constant 1.5707963267948966 : f64
    %755 = qlx.apply #qlx.action<pauli_rotation>(%753#1, %cst_434) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_435 = arith.constant 1.5707963267948966 : f64
    %756:2 = qlx.apply #qlx.action<pauli_rotation>(%754, %755, %cst_435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %757 = qlx.apply #qlx.action<h>(%53#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %758 = qlx.apply #qlx.action<h>(%756#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_436 = arith.constant 3.1415926535897931 : f64
    %759 = qlx.apply #qlx.action<pauli_rotation>(%758, %cst_436) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %760 = qlx.apply #qlx.action<h>(%759) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %761:2 = qlx.apply #qlx.action<pauli_rotation>(%757, %760, %cst_437) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_438 = arith.constant 1.5707963267948966 : f64
    %762 = qlx.apply #qlx.action<pauli_rotation>(%761#0, %cst_438) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_439 = arith.constant 1.5707963267948966 : f64
    %763 = qlx.apply #qlx.action<pauli_rotation>(%761#1, %cst_439) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_440 = arith.constant 1.5707963267948966 : f64
    %764:2 = qlx.apply #qlx.action<pauli_rotation>(%762, %763, %cst_440) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %765 = qlx.apply #qlx.action<h>(%51#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %766 = qlx.apply #qlx.action<h>(%764#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 3.1415926535897931 : f64
    %767 = qlx.apply #qlx.action<pauli_rotation>(%766, %cst_441) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %768 = qlx.apply #qlx.action<h>(%767) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %769:2 = qlx.apply #qlx.action<pauli_rotation>(%765, %768, %cst_442) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %770 = qlx.apply #qlx.action<pauli_rotation>(%769#0, %cst_443) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_444 = arith.constant 1.5707963267948966 : f64
    %771 = qlx.apply #qlx.action<pauli_rotation>(%769#1, %cst_444) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_445 = arith.constant 1.5707963267948966 : f64
    %772:2 = qlx.apply #qlx.action<pauli_rotation>(%770, %771, %cst_445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %773 = qlx.apply #qlx.action<h>(%51#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %774 = qlx.apply #qlx.action<h>(%772#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_446 = arith.constant 3.1415926535897931 : f64
    %775 = qlx.apply #qlx.action<pauli_rotation>(%774, %cst_446) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %776 = qlx.apply #qlx.action<h>(%775) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_447 = arith.constant 1.5707963267948966 : f64
    %777:2 = qlx.apply #qlx.action<pauli_rotation>(%773, %776, %cst_447) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_448 = arith.constant 1.5707963267948966 : f64
    %778 = qlx.apply #qlx.action<pauli_rotation>(%777#0, %cst_448) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %779 = qlx.apply #qlx.action<pauli_rotation>(%777#1, %cst_449) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_450 = arith.constant 1.5707963267948966 : f64
    %780:2 = qlx.apply #qlx.action<pauli_rotation>(%778, %779, %cst_450) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %781 = qlx.apply #qlx.action<h>(%49#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %782 = qlx.apply #qlx.action<h>(%780#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_451 = arith.constant 3.1415926535897931 : f64
    %783 = qlx.apply #qlx.action<pauli_rotation>(%782, %cst_451) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %784 = qlx.apply #qlx.action<h>(%783) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_452 = arith.constant 1.5707963267948966 : f64
    %785:2 = qlx.apply #qlx.action<pauli_rotation>(%781, %784, %cst_452) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_453 = arith.constant 1.5707963267948966 : f64
    %786 = qlx.apply #qlx.action<pauli_rotation>(%785#0, %cst_453) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %787 = qlx.apply #qlx.action<pauli_rotation>(%785#1, %cst_454) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %788:2 = qlx.apply #qlx.action<pauli_rotation>(%786, %787, %cst_455) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_456 = arith.constant 0.78539816339744828 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%49#0, %cst_456) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %790 = qlx.apply #qlx.action<h>(%789) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %791 = qlx.apply #qlx.action<h>(%788#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 2.3561944901923448 : f64
    %792 = qlx.apply #qlx.action<pauli_rotation>(%791, %cst_457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %793 = qlx.apply #qlx.action<h>(%792) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_458 = arith.constant 0.78539816339744828 : f64
    %794:2 = qlx.apply #qlx.action<pauli_rotation>(%790, %793, %cst_458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_459 = arith.constant 1.5707963267948966 : f64
    %795 = qlx.apply #qlx.action<pauli_rotation>(%794#0, %cst_459) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %796 = qlx.apply #qlx.action<pauli_rotation>(%794#1, %cst_460) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_461 = arith.constant 0.78539816339744828 : f64
    %797:2 = qlx.apply #qlx.action<pauli_rotation>(%795, %796, %cst_461) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %798 = qlx.apply #qlx.action<h>(%61#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %799 = qlx.apply #qlx.action<h>(%63#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_462 = arith.constant 1.5707963267948966 : f64
    %800:2 = qlx.apply #qlx.action<pauli_rotation>(%798, %799, %cst_462) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_463 = arith.constant 1.5707963267948966 : f64
    %801 = qlx.apply #qlx.action<pauli_rotation>(%800#0, %cst_463) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_464 = arith.constant 1.5707963267948966 : f64
    %802 = qlx.apply #qlx.action<pauli_rotation>(%800#1, %cst_464) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_465 = arith.constant 1.5707963267948966 : f64
    %803:2 = qlx.apply #qlx.action<pauli_rotation>(%801, %802, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %804 = qlx.apply #qlx.action<h>(%708#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_466 = arith.constant 3.1415926535897931 : f64
    %805 = qlx.apply #qlx.action<pauli_rotation>(%804, %cst_466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %806 = qlx.apply #qlx.action<h>(%805) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %807 = qlx.apply #qlx.action<h>(%803#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_467 = arith.constant 3.1415926535897931 : f64
    %808 = qlx.apply #qlx.action<pauli_rotation>(%807, %cst_467) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %809 = qlx.apply #qlx.action<h>(%808) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_468 = arith.constant 1.5707963267948966 : f64
    %810:2 = qlx.apply #qlx.action<pauli_rotation>(%806, %809, %cst_468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_469 = arith.constant 1.5707963267948966 : f64
    %811 = qlx.apply #qlx.action<pauli_rotation>(%810#0, %cst_469) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_470 = arith.constant 1.5707963267948966 : f64
    %812 = qlx.apply #qlx.action<pauli_rotation>(%810#1, %cst_470) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_471 = arith.constant 1.5707963267948966 : f64
    %813:2 = qlx.apply #qlx.action<pauli_rotation>(%811, %812, %cst_471) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %814 = qlx.apply #qlx.action<h>(%716#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 3.1415926535897931 : f64
    %815 = qlx.apply #qlx.action<pauli_rotation>(%814, %cst_472) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %816 = qlx.apply #qlx.action<h>(%815) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %817 = qlx.apply #qlx.action<h>(%813#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_473 = arith.constant 3.1415926535897931 : f64
    %818 = qlx.apply #qlx.action<pauli_rotation>(%817, %cst_473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %819 = qlx.apply #qlx.action<h>(%818) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_474 = arith.constant 1.5707963267948966 : f64
    %820:2 = qlx.apply #qlx.action<pauli_rotation>(%816, %819, %cst_474) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_475 = arith.constant 1.5707963267948966 : f64
    %821 = qlx.apply #qlx.action<pauli_rotation>(%820#0, %cst_475) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %822 = qlx.apply #qlx.action<pauli_rotation>(%820#1, %cst_476) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_477 = arith.constant 1.5707963267948966 : f64
    %823:2 = qlx.apply #qlx.action<pauli_rotation>(%821, %822, %cst_477) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %824 = qlx.apply #qlx.action<h>(%724#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_478 = arith.constant 3.1415926535897931 : f64
    %825 = qlx.apply #qlx.action<pauli_rotation>(%824, %cst_478) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %826 = qlx.apply #qlx.action<h>(%825) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %827 = qlx.apply #qlx.action<h>(%823#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_479 = arith.constant 3.1415926535897931 : f64
    %828 = qlx.apply #qlx.action<pauli_rotation>(%827, %cst_479) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %829 = qlx.apply #qlx.action<h>(%828) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_480 = arith.constant 1.5707963267948966 : f64
    %830:2 = qlx.apply #qlx.action<pauli_rotation>(%826, %829, %cst_480) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_481 = arith.constant 1.5707963267948966 : f64
    %831 = qlx.apply #qlx.action<pauli_rotation>(%830#0, %cst_481) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_482 = arith.constant 1.5707963267948966 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%830#1, %cst_482) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_483 = arith.constant 1.5707963267948966 : f64
    %833:2 = qlx.apply #qlx.action<pauli_rotation>(%831, %832, %cst_483) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %834 = qlx.apply #qlx.action<h>(%732#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_484 = arith.constant 3.1415926535897931 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%834, %cst_484) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %836 = qlx.apply #qlx.action<h>(%835) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %837 = qlx.apply #qlx.action<h>(%833#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_485 = arith.constant 3.1415926535897931 : f64
    %838 = qlx.apply #qlx.action<pauli_rotation>(%837, %cst_485) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %839 = qlx.apply #qlx.action<h>(%838) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %840:2 = qlx.apply #qlx.action<pauli_rotation>(%836, %839, %cst_486) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_487 = arith.constant 1.5707963267948966 : f64
    %841 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %cst_487) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_488 = arith.constant 1.5707963267948966 : f64
    %842 = qlx.apply #qlx.action<pauli_rotation>(%840#1, %cst_488) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_489 = arith.constant 1.5707963267948966 : f64
    %843:2 = qlx.apply #qlx.action<pauli_rotation>(%841, %842, %cst_489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %844 = qlx.apply #qlx.action<h>(%740#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_490 = arith.constant 3.1415926535897931 : f64
    %845 = qlx.apply #qlx.action<pauli_rotation>(%844, %cst_490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %846 = qlx.apply #qlx.action<h>(%845) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %847 = qlx.apply #qlx.action<h>(%843#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_491 = arith.constant 3.1415926535897931 : f64
    %848 = qlx.apply #qlx.action<pauli_rotation>(%847, %cst_491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %849 = qlx.apply #qlx.action<h>(%848) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_492 = arith.constant 1.5707963267948966 : f64
    %850:2 = qlx.apply #qlx.action<pauli_rotation>(%846, %849, %cst_492) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_493 = arith.constant 1.5707963267948966 : f64
    %851 = qlx.apply #qlx.action<pauli_rotation>(%850#0, %cst_493) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_494 = arith.constant 1.5707963267948966 : f64
    %852 = qlx.apply #qlx.action<pauli_rotation>(%850#1, %cst_494) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_495 = arith.constant 1.5707963267948966 : f64
    %853:2 = qlx.apply #qlx.action<pauli_rotation>(%851, %852, %cst_495) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %854 = qlx.apply #qlx.action<h>(%748#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_496 = arith.constant 3.1415926535897931 : f64
    %855 = qlx.apply #qlx.action<pauli_rotation>(%854, %cst_496) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %856 = qlx.apply #qlx.action<h>(%855) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %857 = qlx.apply #qlx.action<h>(%853#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_497 = arith.constant 3.1415926535897931 : f64
    %858 = qlx.apply #qlx.action<pauli_rotation>(%857, %cst_497) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %859 = qlx.apply #qlx.action<h>(%858) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %860:2 = qlx.apply #qlx.action<pauli_rotation>(%856, %859, %cst_498) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_499 = arith.constant 1.5707963267948966 : f64
    %861 = qlx.apply #qlx.action<pauli_rotation>(%860#0, %cst_499) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_500 = arith.constant 1.5707963267948966 : f64
    %862 = qlx.apply #qlx.action<pauli_rotation>(%860#1, %cst_500) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_501 = arith.constant 1.5707963267948966 : f64
    %863:2 = qlx.apply #qlx.action<pauli_rotation>(%861, %862, %cst_501) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %864 = qlx.apply #qlx.action<h>(%756#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_502 = arith.constant 3.1415926535897931 : f64
    %865 = qlx.apply #qlx.action<pauli_rotation>(%864, %cst_502) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %866 = qlx.apply #qlx.action<h>(%865) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %867 = qlx.apply #qlx.action<h>(%863#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_503 = arith.constant 3.1415926535897931 : f64
    %868 = qlx.apply #qlx.action<pauli_rotation>(%867, %cst_503) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %869 = qlx.apply #qlx.action<h>(%868) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_504 = arith.constant 1.5707963267948966 : f64
    %870:2 = qlx.apply #qlx.action<pauli_rotation>(%866, %869, %cst_504) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_505 = arith.constant 1.5707963267948966 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%870#0, %cst_505) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_506 = arith.constant 1.5707963267948966 : f64
    %872 = qlx.apply #qlx.action<pauli_rotation>(%870#1, %cst_506) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_507 = arith.constant 1.5707963267948966 : f64
    %873:2 = qlx.apply #qlx.action<pauli_rotation>(%871, %872, %cst_507) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %874 = qlx.apply #qlx.action<h>(%764#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_508 = arith.constant 3.1415926535897931 : f64
    %875 = qlx.apply #qlx.action<pauli_rotation>(%874, %cst_508) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %876 = qlx.apply #qlx.action<h>(%875) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %877 = qlx.apply #qlx.action<h>(%873#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_509 = arith.constant 3.1415926535897931 : f64
    %878 = qlx.apply #qlx.action<pauli_rotation>(%877, %cst_509) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %879 = qlx.apply #qlx.action<h>(%878) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %880:2 = qlx.apply #qlx.action<pauli_rotation>(%876, %879, %cst_510) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_511 = arith.constant 1.5707963267948966 : f64
    %881 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %cst_511) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_512 = arith.constant 1.5707963267948966 : f64
    %882 = qlx.apply #qlx.action<pauli_rotation>(%880#1, %cst_512) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_513 = arith.constant 1.5707963267948966 : f64
    %883:2 = qlx.apply #qlx.action<pauli_rotation>(%881, %882, %cst_513) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %884 = qlx.apply #qlx.action<h>(%772#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_514 = arith.constant 3.1415926535897931 : f64
    %885 = qlx.apply #qlx.action<pauli_rotation>(%884, %cst_514) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %886 = qlx.apply #qlx.action<h>(%885) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %887 = qlx.apply #qlx.action<h>(%883#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_515 = arith.constant 3.1415926535897931 : f64
    %888 = qlx.apply #qlx.action<pauli_rotation>(%887, %cst_515) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %889 = qlx.apply #qlx.action<h>(%888) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %890:2 = qlx.apply #qlx.action<pauli_rotation>(%886, %889, %cst_516) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_517 = arith.constant 1.5707963267948966 : f64
    %891 = qlx.apply #qlx.action<pauli_rotation>(%890#0, %cst_517) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_518 = arith.constant 1.5707963267948966 : f64
    %892 = qlx.apply #qlx.action<pauli_rotation>(%890#1, %cst_518) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_519 = arith.constant 1.5707963267948966 : f64
    %893:2 = qlx.apply #qlx.action<pauli_rotation>(%891, %892, %cst_519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %894 = qlx.apply #qlx.action<h>(%780#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_520 = arith.constant 2.3561944901923448 : f64
    %895 = qlx.apply #qlx.action<pauli_rotation>(%894, %cst_520) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %896 = qlx.apply #qlx.action<h>(%895) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %897 = qlx.apply #qlx.action<h>(%893#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_521 = arith.constant 2.3561944901923448 : f64
    %898 = qlx.apply #qlx.action<pauli_rotation>(%897, %cst_521) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %899 = qlx.apply #qlx.action<h>(%898) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_522 = arith.constant 0.78539816339744828 : f64
    %900:2 = qlx.apply #qlx.action<pauli_rotation>(%896, %899, %cst_522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_523 = arith.constant 1.5707963267948966 : f64
    %901 = qlx.apply #qlx.action<pauli_rotation>(%900#0, %cst_523) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_524 = arith.constant 1.5707963267948966 : f64
    %902 = qlx.apply #qlx.action<pauli_rotation>(%900#1, %cst_524) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_525 = arith.constant 0.78539816339744828 : f64
    %903:2 = qlx.apply #qlx.action<pauli_rotation>(%901, %902, %cst_525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %904 = qlx.apply #qlx.action<h>(%788#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_526 = arith.constant 3.1415926535897931 : f64
    %905 = qlx.apply #qlx.action<pauli_rotation>(%904, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %906 = qlx.apply #qlx.action<h>(%905) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %907 = qlx.apply #qlx.action<h>(%903#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_527 = arith.constant 2.3561944901923448 : f64
    %908 = qlx.apply #qlx.action<pauli_rotation>(%907, %cst_527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%908) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_528 = arith.constant 1.5707963267948966 : f64
    %910:2 = qlx.apply #qlx.action<pauli_rotation>(%906, %909, %cst_528) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %911 = qlx.apply #qlx.action<pauli_rotation>(%910#0, %cst_529) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_530 = arith.constant 1.5707963267948966 : f64
    %912 = qlx.apply #qlx.action<pauli_rotation>(%910#1, %cst_530) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_531 = arith.constant 1.5707963267948966 : f64
    %913:2 = qlx.apply #qlx.action<pauli_rotation>(%911, %912, %cst_531) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %914 = qlx.apply #qlx.action<h>(%797#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_532 = arith.constant 2.3561944901923448 : f64
    %915 = qlx.apply #qlx.action<pauli_rotation>(%914, %cst_532) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %916 = qlx.apply #qlx.action<h>(%915) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %917 = qlx.apply #qlx.action<h>(%913#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %918 = qlx.apply #qlx.action<pauli_rotation>(%917, %cst_533) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %919 = qlx.apply #qlx.action<h>(%918) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_534 = arith.constant 1.000000e+00 : f64
    %920:2 = qlx.apply #qlx.action<pauli_rotation>(%916, %919, %cst_534) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %921 = qlx.apply #qlx.action<pauli_rotation>(%920#0, %cst_535) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_536 = arith.constant 1.5707963267948966 : f64
    %922 = qlx.apply #qlx.action<pauli_rotation>(%920#1, %cst_536) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_537 = arith.constant 1.000000e+00 : f64
    %923:2 = qlx.apply #qlx.action<pauli_rotation>(%921, %922, %cst_537) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %924 = qlx.apply #qlx.action<h>(%797#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_538 = arith.constant 1.5707963267948966 : f64
    %925 = qlx.apply #qlx.action<pauli_rotation>(%924, %cst_538) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %926 = qlx.apply #qlx.action<h>(%925) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %927 = qlx.apply #qlx.action<h>(%923#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_539 = arith.constant 0.78539816339744828 : f64
    %928 = qlx.apply #qlx.action<pauli_rotation>(%927, %cst_539) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %929 = qlx.apply #qlx.action<h>(%928) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_540 = arith.constant 0.78539816339744828 : f64
    %930:2 = qlx.apply #qlx.action<pauli_rotation>(%926, %929, %cst_540) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_541 = arith.constant 1.5707963267948966 : f64
    %931 = qlx.apply #qlx.action<pauli_rotation>(%930#0, %cst_541) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_542 = arith.constant 1.5707963267948966 : f64
    %932 = qlx.apply #qlx.action<pauli_rotation>(%930#1, %cst_542) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_543 = arith.constant 0.78539816339744828 : f64
    %933:2 = qlx.apply #qlx.action<pauli_rotation>(%931, %932, %cst_543) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %934 = qlx.apply #qlx.action<h>(%913#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_544 = arith.constant 3.1415926535897931 : f64
    %935 = qlx.apply #qlx.action<pauli_rotation>(%934, %cst_544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %936 = qlx.apply #qlx.action<h>(%935) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %937 = qlx.apply #qlx.action<h>(%903#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_545 = arith.constant 2.3561944901923448 : f64
    %938 = qlx.apply #qlx.action<pauli_rotation>(%937, %cst_545) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %939 = qlx.apply #qlx.action<h>(%938) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_546 = arith.constant 1.5707963267948966 : f64
    %940:2 = qlx.apply #qlx.action<pauli_rotation>(%936, %939, %cst_546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_547 = arith.constant 1.5707963267948966 : f64
    %941 = qlx.apply #qlx.action<pauli_rotation>(%940#0, %cst_547) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_548 = arith.constant 1.5707963267948966 : f64
    %942 = qlx.apply #qlx.action<pauli_rotation>(%940#1, %cst_548) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_549 = arith.constant 1.5707963267948966 : f64
    %943:2 = qlx.apply #qlx.action<pauli_rotation>(%941, %942, %cst_549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %944 = qlx.apply #qlx.action<h>(%923#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_550 = arith.constant 2.3561944901923448 : f64
    %945 = qlx.apply #qlx.action<pauli_rotation>(%944, %cst_550) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %946 = qlx.apply #qlx.action<h>(%945) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %947 = qlx.apply #qlx.action<h>(%943#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_551 = arith.constant 2.3561944901923448 : f64
    %948 = qlx.apply #qlx.action<pauli_rotation>(%947, %cst_551) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %949 = qlx.apply #qlx.action<h>(%948) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_552 = arith.constant 0.78539816339744828 : f64
    %950:2 = qlx.apply #qlx.action<pauli_rotation>(%946, %949, %cst_552) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_553 = arith.constant 1.5707963267948966 : f64
    %951 = qlx.apply #qlx.action<pauli_rotation>(%950#0, %cst_553) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_554 = arith.constant 1.5707963267948966 : f64
    %952 = qlx.apply #qlx.action<pauli_rotation>(%950#1, %cst_554) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_555 = arith.constant 0.78539816339744828 : f64
    %953:2 = qlx.apply #qlx.action<pauli_rotation>(%951, %952, %cst_555) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %954 = qlx.apply #qlx.action<h>(%813#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_556 = arith.constant 3.1415926535897931 : f64
    %955 = qlx.apply #qlx.action<pauli_rotation>(%954, %cst_556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %956 = qlx.apply #qlx.action<h>(%955) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %957 = qlx.apply #qlx.action<h>(%803#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_557 = arith.constant 3.1415926535897931 : f64
    %958 = qlx.apply #qlx.action<pauli_rotation>(%957, %cst_557) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %959 = qlx.apply #qlx.action<h>(%958) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_558 = arith.constant 1.5707963267948966 : f64
    %960:2 = qlx.apply #qlx.action<pauli_rotation>(%956, %959, %cst_558) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_559 = arith.constant 1.5707963267948966 : f64
    %961 = qlx.apply #qlx.action<pauli_rotation>(%960#0, %cst_559) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_560 = arith.constant 1.5707963267948966 : f64
    %962 = qlx.apply #qlx.action<pauli_rotation>(%960#1, %cst_560) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_561 = arith.constant 1.5707963267948966 : f64
    %963:2 = qlx.apply #qlx.action<pauli_rotation>(%961, %962, %cst_561) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %964 = qlx.apply #qlx.action<h>(%823#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_562 = arith.constant 3.1415926535897931 : f64
    %965 = qlx.apply #qlx.action<pauli_rotation>(%964, %cst_562) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %966 = qlx.apply #qlx.action<h>(%965) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %967 = qlx.apply #qlx.action<h>(%963#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_563 = arith.constant 3.1415926535897931 : f64
    %968 = qlx.apply #qlx.action<pauli_rotation>(%967, %cst_563) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %969 = qlx.apply #qlx.action<h>(%968) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_564 = arith.constant 1.5707963267948966 : f64
    %970:2 = qlx.apply #qlx.action<pauli_rotation>(%966, %969, %cst_564) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_565 = arith.constant 1.5707963267948966 : f64
    %971 = qlx.apply #qlx.action<pauli_rotation>(%970#0, %cst_565) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_566 = arith.constant 1.5707963267948966 : f64
    %972 = qlx.apply #qlx.action<pauli_rotation>(%970#1, %cst_566) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_567 = arith.constant 1.5707963267948966 : f64
    %973:2 = qlx.apply #qlx.action<pauli_rotation>(%971, %972, %cst_567) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %974 = qlx.apply #qlx.action<h>(%833#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_568 = arith.constant 3.1415926535897931 : f64
    %975 = qlx.apply #qlx.action<pauli_rotation>(%974, %cst_568) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %976 = qlx.apply #qlx.action<h>(%975) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %977 = qlx.apply #qlx.action<h>(%973#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_569 = arith.constant 3.1415926535897931 : f64
    %978 = qlx.apply #qlx.action<pauli_rotation>(%977, %cst_569) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %979 = qlx.apply #qlx.action<h>(%978) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_570 = arith.constant 1.5707963267948966 : f64
    %980:2 = qlx.apply #qlx.action<pauli_rotation>(%976, %979, %cst_570) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_571 = arith.constant 1.5707963267948966 : f64
    %981 = qlx.apply #qlx.action<pauli_rotation>(%980#0, %cst_571) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_572 = arith.constant 1.5707963267948966 : f64
    %982 = qlx.apply #qlx.action<pauli_rotation>(%980#1, %cst_572) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_573 = arith.constant 1.5707963267948966 : f64
    %983:2 = qlx.apply #qlx.action<pauli_rotation>(%981, %982, %cst_573) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %984 = qlx.apply #qlx.action<h>(%843#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_574 = arith.constant 3.1415926535897931 : f64
    %985 = qlx.apply #qlx.action<pauli_rotation>(%984, %cst_574) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %986 = qlx.apply #qlx.action<h>(%985) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %987 = qlx.apply #qlx.action<h>(%983#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_575 = arith.constant 3.1415926535897931 : f64
    %988 = qlx.apply #qlx.action<pauli_rotation>(%987, %cst_575) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %989 = qlx.apply #qlx.action<h>(%988) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_576 = arith.constant 1.5707963267948966 : f64
    %990:2 = qlx.apply #qlx.action<pauli_rotation>(%986, %989, %cst_576) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_577 = arith.constant 1.5707963267948966 : f64
    %991 = qlx.apply #qlx.action<pauli_rotation>(%990#0, %cst_577) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_578 = arith.constant 1.5707963267948966 : f64
    %992 = qlx.apply #qlx.action<pauli_rotation>(%990#1, %cst_578) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_579 = arith.constant 1.5707963267948966 : f64
    %993:2 = qlx.apply #qlx.action<pauli_rotation>(%991, %992, %cst_579) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %994 = qlx.apply #qlx.action<h>(%853#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_580 = arith.constant 3.1415926535897931 : f64
    %995 = qlx.apply #qlx.action<pauli_rotation>(%994, %cst_580) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %996 = qlx.apply #qlx.action<h>(%995) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %997 = qlx.apply #qlx.action<h>(%993#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_581 = arith.constant 3.1415926535897931 : f64
    %998 = qlx.apply #qlx.action<pauli_rotation>(%997, %cst_581) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %999 = qlx.apply #qlx.action<h>(%998) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_582 = arith.constant 1.5707963267948966 : f64
    %1000:2 = qlx.apply #qlx.action<pauli_rotation>(%996, %999, %cst_582) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_583 = arith.constant 1.5707963267948966 : f64
    %1001 = qlx.apply #qlx.action<pauli_rotation>(%1000#0, %cst_583) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_584 = arith.constant 1.5707963267948966 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1000#1, %cst_584) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_585 = arith.constant 1.5707963267948966 : f64
    %1003:2 = qlx.apply #qlx.action<pauli_rotation>(%1001, %1002, %cst_585) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1004 = qlx.apply #qlx.action<h>(%863#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_586 = arith.constant 3.1415926535897931 : f64
    %1005 = qlx.apply #qlx.action<pauli_rotation>(%1004, %cst_586) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1006 = qlx.apply #qlx.action<h>(%1005) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1007 = qlx.apply #qlx.action<h>(%1003#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_587 = arith.constant 3.1415926535897931 : f64
    %1008 = qlx.apply #qlx.action<pauli_rotation>(%1007, %cst_587) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1009 = qlx.apply #qlx.action<h>(%1008) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_588 = arith.constant 1.5707963267948966 : f64
    %1010:2 = qlx.apply #qlx.action<pauli_rotation>(%1006, %1009, %cst_588) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_589 = arith.constant 1.5707963267948966 : f64
    %1011 = qlx.apply #qlx.action<pauli_rotation>(%1010#0, %cst_589) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_590 = arith.constant 1.5707963267948966 : f64
    %1012 = qlx.apply #qlx.action<pauli_rotation>(%1010#1, %cst_590) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_591 = arith.constant 1.5707963267948966 : f64
    %1013:2 = qlx.apply #qlx.action<pauli_rotation>(%1011, %1012, %cst_591) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1014 = qlx.apply #qlx.action<h>(%873#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_592 = arith.constant 3.1415926535897931 : f64
    %1015 = qlx.apply #qlx.action<pauli_rotation>(%1014, %cst_592) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1016 = qlx.apply #qlx.action<h>(%1015) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1017 = qlx.apply #qlx.action<h>(%1013#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_593 = arith.constant 3.1415926535897931 : f64
    %1018 = qlx.apply #qlx.action<pauli_rotation>(%1017, %cst_593) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1019 = qlx.apply #qlx.action<h>(%1018) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_594 = arith.constant 1.5707963267948966 : f64
    %1020:2 = qlx.apply #qlx.action<pauli_rotation>(%1016, %1019, %cst_594) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_595 = arith.constant 1.5707963267948966 : f64
    %1021 = qlx.apply #qlx.action<pauli_rotation>(%1020#0, %cst_595) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_596 = arith.constant 1.5707963267948966 : f64
    %1022 = qlx.apply #qlx.action<pauli_rotation>(%1020#1, %cst_596) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_597 = arith.constant 1.5707963267948966 : f64
    %1023:2 = qlx.apply #qlx.action<pauli_rotation>(%1021, %1022, %cst_597) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1024 = qlx.apply #qlx.action<h>(%883#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_598 = arith.constant 3.1415926535897931 : f64
    %1025 = qlx.apply #qlx.action<pauli_rotation>(%1024, %cst_598) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1026 = qlx.apply #qlx.action<h>(%1025) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1027 = qlx.apply #qlx.action<h>(%1023#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_599 = arith.constant 3.1415926535897931 : f64
    %1028 = qlx.apply #qlx.action<pauli_rotation>(%1027, %cst_599) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1029 = qlx.apply #qlx.action<h>(%1028) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_600 = arith.constant 1.5707963267948966 : f64
    %1030:2 = qlx.apply #qlx.action<pauli_rotation>(%1026, %1029, %cst_600) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_601 = arith.constant 1.5707963267948966 : f64
    %1031 = qlx.apply #qlx.action<pauli_rotation>(%1030#0, %cst_601) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_602 = arith.constant 1.5707963267948966 : f64
    %1032 = qlx.apply #qlx.action<pauli_rotation>(%1030#1, %cst_602) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_603 = arith.constant 1.5707963267948966 : f64
    %1033:2 = qlx.apply #qlx.action<pauli_rotation>(%1031, %1032, %cst_603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1034 = qlx.apply #qlx.action<h>(%893#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_604 = arith.constant 3.1415926535897931 : f64
    %1035 = qlx.apply #qlx.action<pauli_rotation>(%1034, %cst_604) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1036 = qlx.apply #qlx.action<h>(%1035) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1037 = qlx.apply #qlx.action<h>(%1033#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_605 = arith.constant 3.1415926535897931 : f64
    %1038 = qlx.apply #qlx.action<pauli_rotation>(%1037, %cst_605) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1039 = qlx.apply #qlx.action<h>(%1038) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_606 = arith.constant 1.5707963267948966 : f64
    %1040:2 = qlx.apply #qlx.action<pauli_rotation>(%1036, %1039, %cst_606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_607 = arith.constant 1.5707963267948966 : f64
    %1041 = qlx.apply #qlx.action<pauli_rotation>(%1040#0, %cst_607) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_608 = arith.constant 1.5707963267948966 : f64
    %1042 = qlx.apply #qlx.action<pauli_rotation>(%1040#1, %cst_608) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_609 = arith.constant 1.5707963267948966 : f64
    %1043:2 = qlx.apply #qlx.action<pauli_rotation>(%1041, %1042, %cst_609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1044 = qlx.apply #qlx.action<h>(%943#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_610 = arith.constant 2.3561944901923448 : f64
    %1045 = qlx.apply #qlx.action<pauli_rotation>(%1044, %cst_610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1046 = qlx.apply #qlx.action<h>(%1045) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1047 = qlx.apply #qlx.action<h>(%1043#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_611 = arith.constant 2.3561944901923448 : f64
    %1048 = qlx.apply #qlx.action<pauli_rotation>(%1047, %cst_611) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1049 = qlx.apply #qlx.action<h>(%1048) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_612 = arith.constant 0.78539816339744828 : f64
    %1050:2 = qlx.apply #qlx.action<pauli_rotation>(%1046, %1049, %cst_612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_613 = arith.constant 1.5707963267948966 : f64
    %1051 = qlx.apply #qlx.action<pauli_rotation>(%1050#0, %cst_613) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_614 = arith.constant 1.5707963267948966 : f64
    %1052 = qlx.apply #qlx.action<pauli_rotation>(%1050#1, %cst_614) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_615 = arith.constant 0.78539816339744828 : f64
    %1053:2 = qlx.apply #qlx.action<pauli_rotation>(%1051, %1052, %cst_615) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1054 = qlx.apply #qlx.action<h>(%963#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_616 = arith.constant 3.1415926535897931 : f64
    %1055 = qlx.apply #qlx.action<pauli_rotation>(%1054, %cst_616) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1056 = qlx.apply #qlx.action<h>(%1055) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1057 = qlx.apply #qlx.action<h>(%63#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_617 = arith.constant 1.5707963267948966 : f64
    %1058:2 = qlx.apply #qlx.action<pauli_rotation>(%1056, %1057, %cst_617) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_618 = arith.constant 1.5707963267948966 : f64
    %1059 = qlx.apply #qlx.action<pauli_rotation>(%1058#0, %cst_618) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_619 = arith.constant 1.5707963267948966 : f64
    %1060 = qlx.apply #qlx.action<pauli_rotation>(%1058#1, %cst_619) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_620 = arith.constant 1.5707963267948966 : f64
    %1061:2 = qlx.apply #qlx.action<pauli_rotation>(%1059, %1060, %cst_620) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1062 = qlx.apply #qlx.action<h>(%973#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_621 = arith.constant 3.1415926535897931 : f64
    %1063 = qlx.apply #qlx.action<pauli_rotation>(%1062, %cst_621) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1064 = qlx.apply #qlx.action<h>(%1063) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1065 = qlx.apply #qlx.action<h>(%1061#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_622 = arith.constant 3.1415926535897931 : f64
    %1066 = qlx.apply #qlx.action<pauli_rotation>(%1065, %cst_622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1067 = qlx.apply #qlx.action<h>(%1066) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_623 = arith.constant 1.5707963267948966 : f64
    %1068:2 = qlx.apply #qlx.action<pauli_rotation>(%1064, %1067, %cst_623) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_624 = arith.constant 1.5707963267948966 : f64
    %1069 = qlx.apply #qlx.action<pauli_rotation>(%1068#0, %cst_624) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_625 = arith.constant 1.5707963267948966 : f64
    %1070 = qlx.apply #qlx.action<pauli_rotation>(%1068#1, %cst_625) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_626 = arith.constant 1.5707963267948966 : f64
    %1071:2 = qlx.apply #qlx.action<pauli_rotation>(%1069, %1070, %cst_626) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1072 = qlx.apply #qlx.action<h>(%983#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_627 = arith.constant 3.1415926535897931 : f64
    %1073 = qlx.apply #qlx.action<pauli_rotation>(%1072, %cst_627) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1074 = qlx.apply #qlx.action<h>(%1073) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1075 = qlx.apply #qlx.action<h>(%1071#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_628 = arith.constant 3.1415926535897931 : f64
    %1076 = qlx.apply #qlx.action<pauli_rotation>(%1075, %cst_628) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1077 = qlx.apply #qlx.action<h>(%1076) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_629 = arith.constant 1.5707963267948966 : f64
    %1078:2 = qlx.apply #qlx.action<pauli_rotation>(%1074, %1077, %cst_629) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_630 = arith.constant 1.5707963267948966 : f64
    %1079 = qlx.apply #qlx.action<pauli_rotation>(%1078#0, %cst_630) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_631 = arith.constant 1.5707963267948966 : f64
    %1080 = qlx.apply #qlx.action<pauli_rotation>(%1078#1, %cst_631) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_632 = arith.constant 1.5707963267948966 : f64
    %1081:2 = qlx.apply #qlx.action<pauli_rotation>(%1079, %1080, %cst_632) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1082 = qlx.apply #qlx.action<h>(%993#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_633 = arith.constant 3.1415926535897931 : f64
    %1083 = qlx.apply #qlx.action<pauli_rotation>(%1082, %cst_633) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1084 = qlx.apply #qlx.action<h>(%1083) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1085 = qlx.apply #qlx.action<h>(%1081#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_634 = arith.constant 3.1415926535897931 : f64
    %1086 = qlx.apply #qlx.action<pauli_rotation>(%1085, %cst_634) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1087 = qlx.apply #qlx.action<h>(%1086) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_635 = arith.constant 1.5707963267948966 : f64
    %1088:2 = qlx.apply #qlx.action<pauli_rotation>(%1084, %1087, %cst_635) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_636 = arith.constant 1.5707963267948966 : f64
    %1089 = qlx.apply #qlx.action<pauli_rotation>(%1088#0, %cst_636) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_637 = arith.constant 1.5707963267948966 : f64
    %1090 = qlx.apply #qlx.action<pauli_rotation>(%1088#1, %cst_637) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_638 = arith.constant 1.5707963267948966 : f64
    %1091:2 = qlx.apply #qlx.action<pauli_rotation>(%1089, %1090, %cst_638) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1092 = qlx.apply #qlx.action<h>(%1003#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_639 = arith.constant 3.1415926535897931 : f64
    %1093 = qlx.apply #qlx.action<pauli_rotation>(%1092, %cst_639) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1094 = qlx.apply #qlx.action<h>(%1093) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1095 = qlx.apply #qlx.action<h>(%1091#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_640 = arith.constant 3.1415926535897931 : f64
    %1096 = qlx.apply #qlx.action<pauli_rotation>(%1095, %cst_640) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1097 = qlx.apply #qlx.action<h>(%1096) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_641 = arith.constant 1.5707963267948966 : f64
    %1098:2 = qlx.apply #qlx.action<pauli_rotation>(%1094, %1097, %cst_641) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_642 = arith.constant 1.5707963267948966 : f64
    %1099 = qlx.apply #qlx.action<pauli_rotation>(%1098#0, %cst_642) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_643 = arith.constant 1.5707963267948966 : f64
    %1100 = qlx.apply #qlx.action<pauli_rotation>(%1098#1, %cst_643) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_644 = arith.constant 1.5707963267948966 : f64
    %1101:2 = qlx.apply #qlx.action<pauli_rotation>(%1099, %1100, %cst_644) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1102 = qlx.apply #qlx.action<h>(%1013#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_645 = arith.constant 3.1415926535897931 : f64
    %1103 = qlx.apply #qlx.action<pauli_rotation>(%1102, %cst_645) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1104 = qlx.apply #qlx.action<h>(%1103) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1105 = qlx.apply #qlx.action<h>(%1101#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_646 = arith.constant 3.1415926535897931 : f64
    %1106 = qlx.apply #qlx.action<pauli_rotation>(%1105, %cst_646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1107 = qlx.apply #qlx.action<h>(%1106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_647 = arith.constant 1.5707963267948966 : f64
    %1108:2 = qlx.apply #qlx.action<pauli_rotation>(%1104, %1107, %cst_647) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_648 = arith.constant 1.5707963267948966 : f64
    %1109 = qlx.apply #qlx.action<pauli_rotation>(%1108#0, %cst_648) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_649 = arith.constant 1.5707963267948966 : f64
    %1110 = qlx.apply #qlx.action<pauli_rotation>(%1108#1, %cst_649) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_650 = arith.constant 1.5707963267948966 : f64
    %1111:2 = qlx.apply #qlx.action<pauli_rotation>(%1109, %1110, %cst_650) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1112 = qlx.apply #qlx.action<h>(%1023#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_651 = arith.constant 3.1415926535897931 : f64
    %1113 = qlx.apply #qlx.action<pauli_rotation>(%1112, %cst_651) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1114 = qlx.apply #qlx.action<h>(%1113) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1115 = qlx.apply #qlx.action<h>(%1111#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_652 = arith.constant 3.1415926535897931 : f64
    %1116 = qlx.apply #qlx.action<pauli_rotation>(%1115, %cst_652) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1117 = qlx.apply #qlx.action<h>(%1116) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_653 = arith.constant 1.5707963267948966 : f64
    %1118:2 = qlx.apply #qlx.action<pauli_rotation>(%1114, %1117, %cst_653) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_654 = arith.constant 1.5707963267948966 : f64
    %1119 = qlx.apply #qlx.action<pauli_rotation>(%1118#0, %cst_654) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_655 = arith.constant 1.5707963267948966 : f64
    %1120 = qlx.apply #qlx.action<pauli_rotation>(%1118#1, %cst_655) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_656 = arith.constant 1.5707963267948966 : f64
    %1121:2 = qlx.apply #qlx.action<pauli_rotation>(%1119, %1120, %cst_656) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1122 = qlx.apply #qlx.action<h>(%1033#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_657 = arith.constant 3.1415926535897931 : f64
    %1123 = qlx.apply #qlx.action<pauli_rotation>(%1122, %cst_657) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1124 = qlx.apply #qlx.action<h>(%1123) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1125 = qlx.apply #qlx.action<h>(%1121#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_658 = arith.constant 3.1415926535897931 : f64
    %1126 = qlx.apply #qlx.action<pauli_rotation>(%1125, %cst_658) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1127 = qlx.apply #qlx.action<h>(%1126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_659 = arith.constant 1.5707963267948966 : f64
    %1128:2 = qlx.apply #qlx.action<pauli_rotation>(%1124, %1127, %cst_659) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_660 = arith.constant 1.5707963267948966 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1128#0, %cst_660) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_661 = arith.constant 1.5707963267948966 : f64
    %1130 = qlx.apply #qlx.action<pauli_rotation>(%1128#1, %cst_661) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_662 = arith.constant 1.5707963267948966 : f64
    %1131:2 = qlx.apply #qlx.action<pauli_rotation>(%1129, %1130, %cst_662) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1132 = qlx.apply #qlx.action<h>(%1043#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_663 = arith.constant 2.3561944901923448 : f64
    %1133 = qlx.apply #qlx.action<pauli_rotation>(%1132, %cst_663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1134 = qlx.apply #qlx.action<h>(%1133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1135 = qlx.apply #qlx.action<h>(%1131#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_664 = arith.constant 2.3561944901923448 : f64
    %1136 = qlx.apply #qlx.action<pauli_rotation>(%1135, %cst_664) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1137 = qlx.apply #qlx.action<h>(%1136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_665 = arith.constant 0.78539816339744828 : f64
    %1138:2 = qlx.apply #qlx.action<pauli_rotation>(%1134, %1137, %cst_665) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_666 = arith.constant 1.5707963267948966 : f64
    %1139 = qlx.apply #qlx.action<pauli_rotation>(%1138#0, %cst_666) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_667 = arith.constant 1.5707963267948966 : f64
    %1140 = qlx.apply #qlx.action<pauli_rotation>(%1138#1, %cst_667) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_668 = arith.constant 0.78539816339744828 : f64
    %1141:2 = qlx.apply #qlx.action<pauli_rotation>(%1139, %1140, %cst_668) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1142 = qlx.apply #qlx.action<h>(%1053#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_669 = arith.constant 2.3561944901923448 : f64
    %1143 = qlx.apply #qlx.action<pauli_rotation>(%1142, %cst_669) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1144 = qlx.apply #qlx.action<h>(%1143) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1145 = qlx.apply #qlx.action<h>(%1141#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_670 = arith.constant 0.78539816339744828 : f64
    %1146 = qlx.apply #qlx.action<pauli_rotation>(%1145, %cst_670) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1147 = qlx.apply #qlx.action<h>(%1146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_671 = arith.constant 1.000000e+00 : f64
    %1148:2 = qlx.apply #qlx.action<pauli_rotation>(%1144, %1147, %cst_671) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_672 = arith.constant 1.5707963267948966 : f64
    %1149 = qlx.apply #qlx.action<pauli_rotation>(%1148#0, %cst_672) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_673 = arith.constant 1.5707963267948966 : f64
    %1150 = qlx.apply #qlx.action<pauli_rotation>(%1148#1, %cst_673) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_674 = arith.constant 1.000000e+00 : f64
    %1151:2 = qlx.apply #qlx.action<pauli_rotation>(%1149, %1150, %cst_674) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1152 = qlx.apply #qlx.action<h>(%1053#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_675 = arith.constant 1.5707963267948966 : f64
    %1153 = qlx.apply #qlx.action<pauli_rotation>(%1152, %cst_675) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1154 = qlx.apply #qlx.action<h>(%1153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1155 = qlx.apply #qlx.action<h>(%1151#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_676 = arith.constant 0.78539816339744828 : f64
    %1156 = qlx.apply #qlx.action<pauli_rotation>(%1155, %cst_676) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1157 = qlx.apply #qlx.action<h>(%1156) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_677 = arith.constant 0.78539816339744828 : f64
    %1158:2 = qlx.apply #qlx.action<pauli_rotation>(%1154, %1157, %cst_677) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_678 = arith.constant 1.5707963267948966 : f64
    %1159 = qlx.apply #qlx.action<pauli_rotation>(%1158#0, %cst_678) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_679 = arith.constant 1.5707963267948966 : f64
    %1160 = qlx.apply #qlx.action<pauli_rotation>(%1158#1, %cst_679) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_680 = arith.constant 0.78539816339744828 : f64
    %1161:2 = qlx.apply #qlx.action<pauli_rotation>(%1159, %1160, %cst_680) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1162 = qlx.apply #qlx.action<h>(%1151#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_681 = arith.constant 2.3561944901923448 : f64
    %1163 = qlx.apply #qlx.action<pauli_rotation>(%1162, %cst_681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1164 = qlx.apply #qlx.action<h>(%1163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1165 = qlx.apply #qlx.action<h>(%1141#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_682 = arith.constant 1.5707963267948966 : f64
    %1166 = qlx.apply #qlx.action<pauli_rotation>(%1165, %cst_682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1167 = qlx.apply #qlx.action<h>(%1166) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_683 = arith.constant 0.78539816339744828 : f64
    %1168:2 = qlx.apply #qlx.action<pauli_rotation>(%1164, %1167, %cst_683) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_684 = arith.constant 1.5707963267948966 : f64
    %1169 = qlx.apply #qlx.action<pauli_rotation>(%1168#0, %cst_684) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_685 = arith.constant 1.5707963267948966 : f64
    %1170 = qlx.apply #qlx.action<pauli_rotation>(%1168#1, %cst_685) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_686 = arith.constant 0.78539816339744828 : f64
    %1171:2 = qlx.apply #qlx.action<pauli_rotation>(%1169, %1170, %cst_686) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1172 = qlx.apply #qlx.action<h>(%1101#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_687 = arith.constant 3.1415926535897931 : f64
    %1173 = qlx.apply #qlx.action<pauli_rotation>(%1172, %cst_687) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1174 = qlx.apply #qlx.action<h>(%1173) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1175 = qlx.apply #qlx.action<h>(%1091#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_688 = arith.constant 3.1415926535897931 : f64
    %1176 = qlx.apply #qlx.action<pauli_rotation>(%1175, %cst_688) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1177 = qlx.apply #qlx.action<h>(%1176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_689 = arith.constant 1.5707963267948966 : f64
    %1178:2 = qlx.apply #qlx.action<pauli_rotation>(%1174, %1177, %cst_689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_690 = arith.constant 1.5707963267948966 : f64
    %1179 = qlx.apply #qlx.action<pauli_rotation>(%1178#0, %cst_690) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_691 = arith.constant 1.5707963267948966 : f64
    %1180 = qlx.apply #qlx.action<pauli_rotation>(%1178#1, %cst_691) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_692 = arith.constant 1.5707963267948966 : f64
    %1181:2 = qlx.apply #qlx.action<pauli_rotation>(%1179, %1180, %cst_692) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1182 = qlx.apply #qlx.action<h>(%1111#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_693 = arith.constant 3.1415926535897931 : f64
    %1183 = qlx.apply #qlx.action<pauli_rotation>(%1182, %cst_693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1184 = qlx.apply #qlx.action<h>(%1183) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1185 = qlx.apply #qlx.action<h>(%1181#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_694 = arith.constant 3.1415926535897931 : f64
    %1186 = qlx.apply #qlx.action<pauli_rotation>(%1185, %cst_694) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1187 = qlx.apply #qlx.action<h>(%1186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_695 = arith.constant 1.5707963267948966 : f64
    %1188:2 = qlx.apply #qlx.action<pauli_rotation>(%1184, %1187, %cst_695) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_696 = arith.constant 1.5707963267948966 : f64
    %1189 = qlx.apply #qlx.action<pauli_rotation>(%1188#0, %cst_696) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_697 = arith.constant 1.5707963267948966 : f64
    %1190 = qlx.apply #qlx.action<pauli_rotation>(%1188#1, %cst_697) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_698 = arith.constant 1.5707963267948966 : f64
    %1191:2 = qlx.apply #qlx.action<pauli_rotation>(%1189, %1190, %cst_698) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1192 = qlx.apply #qlx.action<h>(%1121#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_699 = arith.constant 3.1415926535897931 : f64
    %1193 = qlx.apply #qlx.action<pauli_rotation>(%1192, %cst_699) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1194 = qlx.apply #qlx.action<h>(%1193) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1195 = qlx.apply #qlx.action<h>(%1191#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_700 = arith.constant 3.1415926535897931 : f64
    %1196 = qlx.apply #qlx.action<pauli_rotation>(%1195, %cst_700) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1197 = qlx.apply #qlx.action<h>(%1196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_701 = arith.constant 1.5707963267948966 : f64
    %1198:2 = qlx.apply #qlx.action<pauli_rotation>(%1194, %1197, %cst_701) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_702 = arith.constant 1.5707963267948966 : f64
    %1199 = qlx.apply #qlx.action<pauli_rotation>(%1198#0, %cst_702) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_703 = arith.constant 1.5707963267948966 : f64
    %1200 = qlx.apply #qlx.action<pauli_rotation>(%1198#1, %cst_703) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_704 = arith.constant 1.5707963267948966 : f64
    %1201:2 = qlx.apply #qlx.action<pauli_rotation>(%1199, %1200, %cst_704) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1202 = qlx.apply #qlx.action<h>(%1131#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_705 = arith.constant 2.3561944901923448 : f64
    %1203 = qlx.apply #qlx.action<pauli_rotation>(%1202, %cst_705) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1204 = qlx.apply #qlx.action<h>(%1203) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1205 = qlx.apply #qlx.action<h>(%1201#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_706 = arith.constant 2.3561944901923448 : f64
    %1206 = qlx.apply #qlx.action<pauli_rotation>(%1205, %cst_706) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1207 = qlx.apply #qlx.action<h>(%1206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_707 = arith.constant 0.78539816339744828 : f64
    %1208:2 = qlx.apply #qlx.action<pauli_rotation>(%1204, %1207, %cst_707) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_708 = arith.constant 1.5707963267948966 : f64
    %1209 = qlx.apply #qlx.action<pauli_rotation>(%1208#0, %cst_708) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_709 = arith.constant 1.5707963267948966 : f64
    %1210 = qlx.apply #qlx.action<pauli_rotation>(%1208#1, %cst_709) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_710 = arith.constant 0.78539816339744828 : f64
    %1211:2 = qlx.apply #qlx.action<pauli_rotation>(%1209, %1210, %cst_710) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1212 = qlx.apply #qlx.action<h>(%1081#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_711 = arith.constant 3.1415926535897931 : f64
    %1213 = qlx.apply #qlx.action<pauli_rotation>(%1212, %cst_711) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1214 = qlx.apply #qlx.action<h>(%1213) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1215 = qlx.apply #qlx.action<h>(%1071#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_712 = arith.constant 3.1415926535897931 : f64
    %1216 = qlx.apply #qlx.action<pauli_rotation>(%1215, %cst_712) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1217 = qlx.apply #qlx.action<h>(%1216) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_713 = arith.constant 1.5707963267948966 : f64
    %1218:2 = qlx.apply #qlx.action<pauli_rotation>(%1214, %1217, %cst_713) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_714 = arith.constant 1.5707963267948966 : f64
    %1219 = qlx.apply #qlx.action<pauli_rotation>(%1218#0, %cst_714) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_715 = arith.constant 1.5707963267948966 : f64
    %1220 = qlx.apply #qlx.action<pauli_rotation>(%1218#1, %cst_715) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_716 = arith.constant 1.5707963267948966 : f64
    %1221:2 = qlx.apply #qlx.action<pauli_rotation>(%1219, %1220, %cst_716) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1222 = qlx.apply #qlx.action<h>(%1181#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_717 = arith.constant 3.1415926535897931 : f64
    %1223 = qlx.apply #qlx.action<pauli_rotation>(%1222, %cst_717) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1224 = qlx.apply #qlx.action<h>(%1223) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1225 = qlx.apply #qlx.action<h>(%1221#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_718 = arith.constant 3.1415926535897931 : f64
    %1226 = qlx.apply #qlx.action<pauli_rotation>(%1225, %cst_718) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1227 = qlx.apply #qlx.action<h>(%1226) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_719 = arith.constant 1.5707963267948966 : f64
    %1228:2 = qlx.apply #qlx.action<pauli_rotation>(%1224, %1227, %cst_719) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_720 = arith.constant 1.5707963267948966 : f64
    %1229 = qlx.apply #qlx.action<pauli_rotation>(%1228#0, %cst_720) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_721 = arith.constant 1.5707963267948966 : f64
    %1230 = qlx.apply #qlx.action<pauli_rotation>(%1228#1, %cst_721) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_722 = arith.constant 1.5707963267948966 : f64
    %1231:2 = qlx.apply #qlx.action<pauli_rotation>(%1229, %1230, %cst_722) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1232 = qlx.apply #qlx.action<h>(%1191#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_723 = arith.constant 2.3561944901923448 : f64
    %1233 = qlx.apply #qlx.action<pauli_rotation>(%1232, %cst_723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1234 = qlx.apply #qlx.action<h>(%1233) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1235 = qlx.apply #qlx.action<h>(%1231#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_724 = arith.constant 2.3561944901923448 : f64
    %1236 = qlx.apply #qlx.action<pauli_rotation>(%1235, %cst_724) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1237 = qlx.apply #qlx.action<h>(%1236) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_725 = arith.constant 0.78539816339744828 : f64
    %1238:2 = qlx.apply #qlx.action<pauli_rotation>(%1234, %1237, %cst_725) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_726 = arith.constant 1.5707963267948966 : f64
    %1239 = qlx.apply #qlx.action<pauli_rotation>(%1238#0, %cst_726) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_727 = arith.constant 1.5707963267948966 : f64
    %1240 = qlx.apply #qlx.action<pauli_rotation>(%1238#1, %cst_727) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_728 = arith.constant 0.78539816339744828 : f64
    %1241:2 = qlx.apply #qlx.action<pauli_rotation>(%1239, %1240, %cst_728) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1242 = qlx.apply #qlx.action<h>(%1201#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_729 = arith.constant 3.1415926535897931 : f64
    %1243 = qlx.apply #qlx.action<pauli_rotation>(%1242, %cst_729) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1244 = qlx.apply #qlx.action<h>(%1243) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1245 = qlx.apply #qlx.action<h>(%1241#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_730 = arith.constant 2.3561944901923448 : f64
    %1246 = qlx.apply #qlx.action<pauli_rotation>(%1245, %cst_730) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1247 = qlx.apply #qlx.action<h>(%1246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_731 = arith.constant 1.5707963267948966 : f64
    %1248:2 = qlx.apply #qlx.action<pauli_rotation>(%1244, %1247, %cst_731) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_732 = arith.constant 1.5707963267948966 : f64
    %1249 = qlx.apply #qlx.action<pauli_rotation>(%1248#0, %cst_732) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_733 = arith.constant 1.5707963267948966 : f64
    %1250 = qlx.apply #qlx.action<pauli_rotation>(%1248#1, %cst_733) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_734 = arith.constant 1.5707963267948966 : f64
    %1251:2 = qlx.apply #qlx.action<pauli_rotation>(%1249, %1250, %cst_734) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1252 = qlx.apply #qlx.action<h>(%1211#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_735 = arith.constant 2.3561944901923448 : f64
    %1253 = qlx.apply #qlx.action<pauli_rotation>(%1252, %cst_735) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1254 = qlx.apply #qlx.action<h>(%1253) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1255 = qlx.apply #qlx.action<h>(%1251#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_736 = arith.constant 1.5707963267948966 : f64
    %1256 = qlx.apply #qlx.action<pauli_rotation>(%1255, %cst_736) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1257 = qlx.apply #qlx.action<h>(%1256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_737 = arith.constant 1.000000e+00 : f64
    %1258:2 = qlx.apply #qlx.action<pauli_rotation>(%1254, %1257, %cst_737) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_738 = arith.constant 1.5707963267948966 : f64
    %1259 = qlx.apply #qlx.action<pauli_rotation>(%1258#0, %cst_738) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_739 = arith.constant 1.5707963267948966 : f64
    %1260 = qlx.apply #qlx.action<pauli_rotation>(%1258#1, %cst_739) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_740 = arith.constant 1.000000e+00 : f64
    %1261:2 = qlx.apply #qlx.action<pauli_rotation>(%1259, %1260, %cst_740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1262 = qlx.apply #qlx.action<h>(%1211#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_741 = arith.constant 1.5707963267948966 : f64
    %1263 = qlx.apply #qlx.action<pauli_rotation>(%1262, %cst_741) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1264 = qlx.apply #qlx.action<h>(%1263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1265 = qlx.apply #qlx.action<h>(%1261#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_742 = arith.constant 0.78539816339744828 : f64
    %1266 = qlx.apply #qlx.action<pauli_rotation>(%1265, %cst_742) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1267 = qlx.apply #qlx.action<h>(%1266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_743 = arith.constant 0.78539816339744828 : f64
    %1268:2 = qlx.apply #qlx.action<pauli_rotation>(%1264, %1267, %cst_743) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_744 = arith.constant 1.5707963267948966 : f64
    %1269 = qlx.apply #qlx.action<pauli_rotation>(%1268#0, %cst_744) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_745 = arith.constant 1.5707963267948966 : f64
    %1270 = qlx.apply #qlx.action<pauli_rotation>(%1268#1, %cst_745) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_746 = arith.constant 0.78539816339744828 : f64
    %1271:2 = qlx.apply #qlx.action<pauli_rotation>(%1269, %1270, %cst_746) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1272 = qlx.apply #qlx.action<h>(%1251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_747 = arith.constant 3.1415926535897931 : f64
    %1273 = qlx.apply #qlx.action<pauli_rotation>(%1272, %cst_747) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1274 = qlx.apply #qlx.action<h>(%1273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1275 = qlx.apply #qlx.action<h>(%1241#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_748 = arith.constant 2.3561944901923448 : f64
    %1276 = qlx.apply #qlx.action<pauli_rotation>(%1275, %cst_748) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1277 = qlx.apply #qlx.action<h>(%1276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_749 = arith.constant 1.5707963267948966 : f64
    %1278:2 = qlx.apply #qlx.action<pauli_rotation>(%1274, %1277, %cst_749) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_750 = arith.constant 1.5707963267948966 : f64
    %1279 = qlx.apply #qlx.action<pauli_rotation>(%1278#0, %cst_750) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_751 = arith.constant 1.5707963267948966 : f64
    %1280 = qlx.apply #qlx.action<pauli_rotation>(%1278#1, %cst_751) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_752 = arith.constant 1.5707963267948966 : f64
    %1281:2 = qlx.apply #qlx.action<pauli_rotation>(%1279, %1280, %cst_752) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1282 = qlx.apply #qlx.action<h>(%1261#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_753 = arith.constant 2.3561944901923448 : f64
    %1283 = qlx.apply #qlx.action<pauli_rotation>(%1282, %cst_753) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1284 = qlx.apply #qlx.action<h>(%1283) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1285 = qlx.apply #qlx.action<h>(%1281#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_754 = arith.constant 2.3561944901923448 : f64
    %1286 = qlx.apply #qlx.action<pauli_rotation>(%1285, %cst_754) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1287 = qlx.apply #qlx.action<h>(%1286) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_755 = arith.constant 0.78539816339744828 : f64
    %1288:2 = qlx.apply #qlx.action<pauli_rotation>(%1284, %1287, %cst_755) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_756 = arith.constant 1.5707963267948966 : f64
    %1289 = qlx.apply #qlx.action<pauli_rotation>(%1288#0, %cst_756) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_757 = arith.constant 1.5707963267948966 : f64
    %1290 = qlx.apply #qlx.action<pauli_rotation>(%1288#1, %cst_757) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_758 = arith.constant 0.78539816339744828 : f64
    %1291:2 = qlx.apply #qlx.action<pauli_rotation>(%1289, %1290, %cst_758) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1292 = qlx.apply #qlx.action<h>(%1231#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_759 = arith.constant 3.1415926535897931 : f64
    %1293 = qlx.apply #qlx.action<pauli_rotation>(%1292, %cst_759) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1294 = qlx.apply #qlx.action<h>(%1293) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1295 = qlx.apply #qlx.action<h>(%1221#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_760 = arith.constant 3.1415926535897931 : f64
    %1296 = qlx.apply #qlx.action<pauli_rotation>(%1295, %cst_760) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1297 = qlx.apply #qlx.action<h>(%1296) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_761 = arith.constant 1.5707963267948966 : f64
    %1298:2 = qlx.apply #qlx.action<pauli_rotation>(%1294, %1297, %cst_761) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_762 = arith.constant 1.5707963267948966 : f64
    %1299 = qlx.apply #qlx.action<pauli_rotation>(%1298#0, %cst_762) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_763 = arith.constant 1.5707963267948966 : f64
    %1300 = qlx.apply #qlx.action<pauli_rotation>(%1298#1, %cst_763) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_764 = arith.constant 1.5707963267948966 : f64
    %1301:2 = qlx.apply #qlx.action<pauli_rotation>(%1299, %1300, %cst_764) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1302 = qlx.apply #qlx.action<h>(%1281#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_765 = arith.constant 2.3561944901923448 : f64
    %1303 = qlx.apply #qlx.action<pauli_rotation>(%1302, %cst_765) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1304 = qlx.apply #qlx.action<h>(%1303) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1305 = qlx.apply #qlx.action<h>(%1301#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_766 = arith.constant 2.3561944901923448 : f64
    %1306 = qlx.apply #qlx.action<pauli_rotation>(%1305, %cst_766) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1307 = qlx.apply #qlx.action<h>(%1306) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_767 = arith.constant 0.78539816339744828 : f64
    %1308:2 = qlx.apply #qlx.action<pauli_rotation>(%1304, %1307, %cst_767) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_768 = arith.constant 1.5707963267948966 : f64
    %1309 = qlx.apply #qlx.action<pauli_rotation>(%1308#0, %cst_768) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_769 = arith.constant 1.5707963267948966 : f64
    %1310 = qlx.apply #qlx.action<pauli_rotation>(%1308#1, %cst_769) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_770 = arith.constant 0.78539816339744828 : f64
    %1311:2 = qlx.apply #qlx.action<pauli_rotation>(%1309, %1310, %cst_770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1312 = qlx.apply #qlx.action<h>(%1301#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_771 = arith.constant 2.3561944901923448 : f64
    %1313 = qlx.apply #qlx.action<pauli_rotation>(%1312, %cst_771) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1314 = qlx.apply #qlx.action<h>(%1313) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1315 = qlx.apply #qlx.action<h>(%1061#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_772 = arith.constant 2.3561944901923448 : f64
    %1316 = qlx.apply #qlx.action<pauli_rotation>(%1315, %cst_772) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1317 = qlx.apply #qlx.action<h>(%1316) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_773 = arith.constant 0.78539816339744828 : f64
    %1318:2 = qlx.apply #qlx.action<pauli_rotation>(%1314, %1317, %cst_773) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_774 = arith.constant 1.5707963267948966 : f64
    %1319 = qlx.apply #qlx.action<pauli_rotation>(%1318#0, %cst_774) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_775 = arith.constant 1.5707963267948966 : f64
    %1320 = qlx.apply #qlx.action<pauli_rotation>(%1318#1, %cst_775) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_776 = arith.constant 0.78539816339744828 : f64
    %1321:2 = qlx.apply #qlx.action<pauli_rotation>(%1319, %1320, %cst_776) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1322 = qlx.apply #qlx.action<h>(%1311#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_777 = arith.constant 2.3561944901923448 : f64
    %1323 = qlx.apply #qlx.action<pauli_rotation>(%1322, %cst_777) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1324 = qlx.apply #qlx.action<h>(%1323) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1325 = qlx.apply #qlx.action<h>(%1321#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_778 = arith.constant 0.78539816339744828 : f64
    %1326 = qlx.apply #qlx.action<pauli_rotation>(%1325, %cst_778) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1327 = qlx.apply #qlx.action<h>(%1326) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_779 = arith.constant 1.000000e+00 : f64
    %1328:2 = qlx.apply #qlx.action<pauli_rotation>(%1324, %1327, %cst_779) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_780 = arith.constant 1.5707963267948966 : f64
    %1329 = qlx.apply #qlx.action<pauli_rotation>(%1328#0, %cst_780) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_781 = arith.constant 1.5707963267948966 : f64
    %1330 = qlx.apply #qlx.action<pauli_rotation>(%1328#1, %cst_781) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_782 = arith.constant 1.000000e+00 : f64
    %1331:2 = qlx.apply #qlx.action<pauli_rotation>(%1329, %1330, %cst_782) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1332 = qlx.apply #qlx.action<h>(%1311#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_783 = arith.constant 1.5707963267948966 : f64
    %1333 = qlx.apply #qlx.action<pauli_rotation>(%1332, %cst_783) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1334 = qlx.apply #qlx.action<h>(%1333) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1335 = qlx.apply #qlx.action<h>(%1331#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_784 = arith.constant 0.78539816339744828 : f64
    %1336 = qlx.apply #qlx.action<pauli_rotation>(%1335, %cst_784) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1337 = qlx.apply #qlx.action<h>(%1336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_785 = arith.constant 0.78539816339744828 : f64
    %1338:2 = qlx.apply #qlx.action<pauli_rotation>(%1334, %1337, %cst_785) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_786 = arith.constant 1.5707963267948966 : f64
    %1339 = qlx.apply #qlx.action<pauli_rotation>(%1338#0, %cst_786) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_787 = arith.constant 1.5707963267948966 : f64
    %1340 = qlx.apply #qlx.action<pauli_rotation>(%1338#1, %cst_787) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_788 = arith.constant 0.78539816339744828 : f64
    %1341:2 = qlx.apply #qlx.action<pauli_rotation>(%1339, %1340, %cst_788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1342 = qlx.apply #qlx.action<h>(%1331#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_789 = arith.constant 2.3561944901923448 : f64
    %1343 = qlx.apply #qlx.action<pauli_rotation>(%1342, %cst_789) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1344 = qlx.apply #qlx.action<h>(%1343) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1345 = qlx.apply #qlx.action<h>(%1321#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_790 = arith.constant 1.5707963267948966 : f64
    %1346 = qlx.apply #qlx.action<pauli_rotation>(%1345, %cst_790) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1347 = qlx.apply #qlx.action<h>(%1346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_791 = arith.constant 0.78539816339744828 : f64
    %1348:2 = qlx.apply #qlx.action<pauli_rotation>(%1344, %1347, %cst_791) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_792 = arith.constant 1.5707963267948966 : f64
    %1349 = qlx.apply #qlx.action<pauli_rotation>(%1348#0, %cst_792) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_793 = arith.constant 1.5707963267948966 : f64
    %1350 = qlx.apply #qlx.action<pauli_rotation>(%1348#1, %cst_793) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_794 = arith.constant 0.78539816339744828 : f64
    %1351:2 = qlx.apply #qlx.action<pauli_rotation>(%1349, %1350, %cst_794) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1352 = qlx.apply #qlx.action<h>(%1171#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_795 = arith.constant 2.3561944901923448 : f64
    %1353 = qlx.apply #qlx.action<pauli_rotation>(%1352, %cst_795) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1354 = qlx.apply #qlx.action<h>(%1353) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1355 = qlx.apply #qlx.action<h>(%1271#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_796 = arith.constant 2.3561944901923448 : f64
    %1356 = qlx.apply #qlx.action<pauli_rotation>(%1355, %cst_796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1357 = qlx.apply #qlx.action<h>(%1356) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_797 = arith.constant 1.5707963267948966 : f64
    %1358:2 = qlx.apply #qlx.action<pauli_rotation>(%1354, %1357, %cst_797) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_798 = arith.constant 1.5707963267948966 : f64
    %1359 = qlx.apply #qlx.action<pauli_rotation>(%1358#0, %cst_798) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_799 = arith.constant 1.5707963267948966 : f64
    %1360 = qlx.apply #qlx.action<pauli_rotation>(%1358#1, %cst_799) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_800 = arith.constant 1.5707963267948966 : f64
    %1361:2 = qlx.apply #qlx.action<pauli_rotation>(%1359, %1360, %cst_800) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1362 = qlx.apply #qlx.action<h>(%1171#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_801 = arith.constant 2.3561944901923448 : f64
    %1363 = qlx.apply #qlx.action<pauli_rotation>(%1362, %cst_801) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1364 = qlx.apply #qlx.action<h>(%1363) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1365 = qlx.apply #qlx.action<h>(%1361#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_802 = arith.constant 3.1415926535897931 : f64
    %1366 = qlx.apply #qlx.action<pauli_rotation>(%1365, %cst_802) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1367 = qlx.apply #qlx.action<h>(%1366) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_803 = arith.constant 1.5707963267948966 : f64
    %1368:2 = qlx.apply #qlx.action<pauli_rotation>(%1364, %1367, %cst_803) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_804 = arith.constant 1.5707963267948966 : f64
    %1369 = qlx.apply #qlx.action<pauli_rotation>(%1368#0, %cst_804) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_805 = arith.constant 1.5707963267948966 : f64
    %1370 = qlx.apply #qlx.action<pauli_rotation>(%1368#1, %cst_805) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_806 = arith.constant 1.5707963267948966 : f64
    %1371:2 = qlx.apply #qlx.action<pauli_rotation>(%1369, %1370, %cst_806) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1372 = qlx.apply #qlx.action<h>(%1161#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_807 = arith.constant 2.3561944901923448 : f64
    %1373 = qlx.apply #qlx.action<pauli_rotation>(%1372, %cst_807) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1374 = qlx.apply #qlx.action<h>(%1373) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1375 = qlx.apply #qlx.action<h>(%1371#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_808 = arith.constant 3.1415926535897931 : f64
    %1376 = qlx.apply #qlx.action<pauli_rotation>(%1375, %cst_808) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1377 = qlx.apply #qlx.action<h>(%1376) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_809 = arith.constant 1.5707963267948966 : f64
    %1378:2 = qlx.apply #qlx.action<pauli_rotation>(%1374, %1377, %cst_809) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_810 = arith.constant 1.5707963267948966 : f64
    %1379 = qlx.apply #qlx.action<pauli_rotation>(%1378#0, %cst_810) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_811 = arith.constant 1.5707963267948966 : f64
    %1380 = qlx.apply #qlx.action<pauli_rotation>(%1378#1, %cst_811) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_812 = arith.constant 1.5707963267948966 : f64
    %1381:2 = qlx.apply #qlx.action<pauli_rotation>(%1379, %1380, %cst_812) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1382 = qlx.apply #qlx.action<h>(%1161#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_813 = arith.constant 2.3561944901923448 : f64
    %1383 = qlx.apply #qlx.action<pauli_rotation>(%1382, %cst_813) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1384 = qlx.apply #qlx.action<h>(%1383) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1385 = qlx.apply #qlx.action<h>(%1381#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_814 = arith.constant 3.1415926535897931 : f64
    %1386 = qlx.apply #qlx.action<pauli_rotation>(%1385, %cst_814) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1387 = qlx.apply #qlx.action<h>(%1386) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_815 = arith.constant 1.5707963267948966 : f64
    %1388:2 = qlx.apply #qlx.action<pauli_rotation>(%1384, %1387, %cst_815) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_816 = arith.constant 1.5707963267948966 : f64
    %1389 = qlx.apply #qlx.action<pauli_rotation>(%1388#0, %cst_816) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_817 = arith.constant 1.5707963267948966 : f64
    %1390 = qlx.apply #qlx.action<pauli_rotation>(%1388#1, %cst_817) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_818 = arith.constant 1.5707963267948966 : f64
    %1391:2 = qlx.apply #qlx.action<pauli_rotation>(%1389, %1390, %cst_818) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1392 = qlx.apply #qlx.action<h>(%953#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_819 = arith.constant 2.3561944901923448 : f64
    %1393 = qlx.apply #qlx.action<pauli_rotation>(%1392, %cst_819) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1394 = qlx.apply #qlx.action<h>(%1393) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1395 = qlx.apply #qlx.action<h>(%1391#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_820 = arith.constant 3.1415926535897931 : f64
    %1396 = qlx.apply #qlx.action<pauli_rotation>(%1395, %cst_820) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1397 = qlx.apply #qlx.action<h>(%1396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_821 = arith.constant 1.5707963267948966 : f64
    %1398:2 = qlx.apply #qlx.action<pauli_rotation>(%1394, %1397, %cst_821) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_822 = arith.constant 1.5707963267948966 : f64
    %1399 = qlx.apply #qlx.action<pauli_rotation>(%1398#0, %cst_822) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_823 = arith.constant 1.5707963267948966 : f64
    %1400 = qlx.apply #qlx.action<pauli_rotation>(%1398#1, %cst_823) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_824 = arith.constant 1.5707963267948966 : f64
    %1401:2 = qlx.apply #qlx.action<pauli_rotation>(%1399, %1400, %cst_824) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1402 = qlx.apply #qlx.action<h>(%953#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_825 = arith.constant 2.3561944901923448 : f64
    %1403 = qlx.apply #qlx.action<pauli_rotation>(%1402, %cst_825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1404 = qlx.apply #qlx.action<h>(%1403) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1405 = qlx.apply #qlx.action<h>(%1401#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_826 = arith.constant 3.1415926535897931 : f64
    %1406 = qlx.apply #qlx.action<pauli_rotation>(%1405, %cst_826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1407 = qlx.apply #qlx.action<h>(%1406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_827 = arith.constant 1.5707963267948966 : f64
    %1408:2 = qlx.apply #qlx.action<pauli_rotation>(%1404, %1407, %cst_827) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_828 = arith.constant 1.5707963267948966 : f64
    %1409 = qlx.apply #qlx.action<pauli_rotation>(%1408#0, %cst_828) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_829 = arith.constant 1.5707963267948966 : f64
    %1410 = qlx.apply #qlx.action<pauli_rotation>(%1408#1, %cst_829) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_830 = arith.constant 1.5707963267948966 : f64
    %1411:2 = qlx.apply #qlx.action<pauli_rotation>(%1409, %1410, %cst_830) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1412 = qlx.apply #qlx.action<h>(%933#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_831 = arith.constant 2.3561944901923448 : f64
    %1413 = qlx.apply #qlx.action<pauli_rotation>(%1412, %cst_831) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1414 = qlx.apply #qlx.action<h>(%1413) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1415 = qlx.apply #qlx.action<h>(%1411#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_832 = arith.constant 3.1415926535897931 : f64
    %1416 = qlx.apply #qlx.action<pauli_rotation>(%1415, %cst_832) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1417 = qlx.apply #qlx.action<h>(%1416) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_833 = arith.constant 1.5707963267948966 : f64
    %1418:2 = qlx.apply #qlx.action<pauli_rotation>(%1414, %1417, %cst_833) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_834 = arith.constant 1.5707963267948966 : f64
    %1419 = qlx.apply #qlx.action<pauli_rotation>(%1418#0, %cst_834) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_835 = arith.constant 1.5707963267948966 : f64
    %1420 = qlx.apply #qlx.action<pauli_rotation>(%1418#1, %cst_835) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_836 = arith.constant 1.5707963267948966 : f64
    %1421:2 = qlx.apply #qlx.action<pauli_rotation>(%1419, %1420, %cst_836) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1422 = qlx.apply #qlx.action<h>(%933#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_837 = arith.constant 2.3561944901923448 : f64
    %1423 = qlx.apply #qlx.action<pauli_rotation>(%1422, %cst_837) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1424 = qlx.apply #qlx.action<h>(%1423) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1425 = qlx.apply #qlx.action<h>(%1421#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_838 = arith.constant 3.1415926535897931 : f64
    %1426 = qlx.apply #qlx.action<pauli_rotation>(%1425, %cst_838) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1427 = qlx.apply #qlx.action<h>(%1426) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_839 = arith.constant 1.5707963267948966 : f64
    %1428:2 = qlx.apply #qlx.action<pauli_rotation>(%1424, %1427, %cst_839) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_840 = arith.constant 1.5707963267948966 : f64
    %1429 = qlx.apply #qlx.action<pauli_rotation>(%1428#0, %cst_840) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_841 = arith.constant 1.5707963267948966 : f64
    %1430 = qlx.apply #qlx.action<pauli_rotation>(%1428#1, %cst_841) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_842 = arith.constant 1.5707963267948966 : f64
    %1431:2 = qlx.apply #qlx.action<pauli_rotation>(%1429, %1430, %cst_842) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1432 = qlx.apply #qlx.action<h>(%702#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_843 = arith.constant 2.3561944901923448 : f64
    %1433 = qlx.apply #qlx.action<pauli_rotation>(%1432, %cst_843) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1434 = qlx.apply #qlx.action<h>(%1433) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1435 = qlx.apply #qlx.action<h>(%1431#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_844 = arith.constant 3.1415926535897931 : f64
    %1436 = qlx.apply #qlx.action<pauli_rotation>(%1435, %cst_844) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1437 = qlx.apply #qlx.action<h>(%1436) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_845 = arith.constant 1.5707963267948966 : f64
    %1438:2 = qlx.apply #qlx.action<pauli_rotation>(%1434, %1437, %cst_845) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_846 = arith.constant 1.5707963267948966 : f64
    %1439 = qlx.apply #qlx.action<pauli_rotation>(%1438#0, %cst_846) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_847 = arith.constant 1.5707963267948966 : f64
    %1440 = qlx.apply #qlx.action<pauli_rotation>(%1438#1, %cst_847) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_848 = arith.constant 1.5707963267948966 : f64
    %1441:2 = qlx.apply #qlx.action<pauli_rotation>(%1439, %1440, %cst_848) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1442 = qlx.apply #qlx.action<h>(%702#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_849 = arith.constant 2.3561944901923448 : f64
    %1443 = qlx.apply #qlx.action<pauli_rotation>(%1442, %cst_849) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1444 = qlx.apply #qlx.action<h>(%1443) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1445 = qlx.apply #qlx.action<h>(%1441#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_850 = arith.constant 3.1415926535897931 : f64
    %1446 = qlx.apply #qlx.action<pauli_rotation>(%1445, %cst_850) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1447 = qlx.apply #qlx.action<h>(%1446) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_851 = arith.constant 1.5707963267948966 : f64
    %1448:2 = qlx.apply #qlx.action<pauli_rotation>(%1444, %1447, %cst_851) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_852 = arith.constant 1.5707963267948966 : f64
    %1449 = qlx.apply #qlx.action<pauli_rotation>(%1448#0, %cst_852) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_853 = arith.constant 1.5707963267948966 : f64
    %1450 = qlx.apply #qlx.action<pauli_rotation>(%1448#1, %cst_853) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_854 = arith.constant 1.5707963267948966 : f64
    %1451:2 = qlx.apply #qlx.action<pauli_rotation>(%1449, %1450, %cst_854) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1452 = qlx.apply #qlx.action<h>(%692#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_855 = arith.constant 2.3561944901923448 : f64
    %1453 = qlx.apply #qlx.action<pauli_rotation>(%1452, %cst_855) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1454 = qlx.apply #qlx.action<h>(%1453) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1455 = qlx.apply #qlx.action<h>(%1451#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_856 = arith.constant 3.1415926535897931 : f64
    %1456 = qlx.apply #qlx.action<pauli_rotation>(%1455, %cst_856) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1457 = qlx.apply #qlx.action<h>(%1456) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_857 = arith.constant 1.5707963267948966 : f64
    %1458:2 = qlx.apply #qlx.action<pauli_rotation>(%1454, %1457, %cst_857) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_858 = arith.constant 1.5707963267948966 : f64
    %1459 = qlx.apply #qlx.action<pauli_rotation>(%1458#0, %cst_858) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_859 = arith.constant 1.5707963267948966 : f64
    %1460 = qlx.apply #qlx.action<pauli_rotation>(%1458#1, %cst_859) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_860 = arith.constant 1.5707963267948966 : f64
    %1461:2 = qlx.apply #qlx.action<pauli_rotation>(%1459, %1460, %cst_860) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1462 = qlx.apply #qlx.action<h>(%692#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_861 = arith.constant 2.3561944901923448 : f64
    %1463 = qlx.apply #qlx.action<pauli_rotation>(%1462, %cst_861) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1464 = qlx.apply #qlx.action<h>(%1463) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1465 = qlx.apply #qlx.action<h>(%1461#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_862 = arith.constant 3.1415926535897931 : f64
    %1466 = qlx.apply #qlx.action<pauli_rotation>(%1465, %cst_862) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1467 = qlx.apply #qlx.action<h>(%1466) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_863 = arith.constant 1.5707963267948966 : f64
    %1468:2 = qlx.apply #qlx.action<pauli_rotation>(%1464, %1467, %cst_863) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_864 = arith.constant 1.5707963267948966 : f64
    %1469 = qlx.apply #qlx.action<pauli_rotation>(%1468#0, %cst_864) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_865 = arith.constant 1.5707963267948966 : f64
    %1470 = qlx.apply #qlx.action<pauli_rotation>(%1468#1, %cst_865) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_866 = arith.constant 1.5707963267948966 : f64
    %1471:2 = qlx.apply #qlx.action<pauli_rotation>(%1469, %1470, %cst_866) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1472 = qlx.apply #qlx.action<h>(%642#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_867 = arith.constant 2.3561944901923448 : f64
    %1473 = qlx.apply #qlx.action<pauli_rotation>(%1472, %cst_867) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1474 = qlx.apply #qlx.action<h>(%1473) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1475 = qlx.apply #qlx.action<h>(%1471#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_868 = arith.constant 3.1415926535897931 : f64
    %1476 = qlx.apply #qlx.action<pauli_rotation>(%1475, %cst_868) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1477 = qlx.apply #qlx.action<h>(%1476) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_869 = arith.constant 1.5707963267948966 : f64
    %1478:2 = qlx.apply #qlx.action<pauli_rotation>(%1474, %1477, %cst_869) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_870 = arith.constant 1.5707963267948966 : f64
    %1479 = qlx.apply #qlx.action<pauli_rotation>(%1478#0, %cst_870) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_871 = arith.constant 1.5707963267948966 : f64
    %1480 = qlx.apply #qlx.action<pauli_rotation>(%1478#1, %cst_871) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_872 = arith.constant 1.5707963267948966 : f64
    %1481:2 = qlx.apply #qlx.action<pauli_rotation>(%1479, %1480, %cst_872) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1482 = qlx.apply #qlx.action<h>(%642#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_873 = arith.constant 2.3561944901923448 : f64
    %1483 = qlx.apply #qlx.action<pauli_rotation>(%1482, %cst_873) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1484 = qlx.apply #qlx.action<h>(%1483) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1485 = qlx.apply #qlx.action<h>(%1481#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_874 = arith.constant 3.1415926535897931 : f64
    %1486 = qlx.apply #qlx.action<pauli_rotation>(%1485, %cst_874) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1487 = qlx.apply #qlx.action<h>(%1486) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_875 = arith.constant 1.5707963267948966 : f64
    %1488:2 = qlx.apply #qlx.action<pauli_rotation>(%1484, %1487, %cst_875) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_876 = arith.constant 1.5707963267948966 : f64
    %1489 = qlx.apply #qlx.action<pauli_rotation>(%1488#0, %cst_876) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_877 = arith.constant 1.5707963267948966 : f64
    %1490 = qlx.apply #qlx.action<pauli_rotation>(%1488#1, %cst_877) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_878 = arith.constant 1.5707963267948966 : f64
    %1491:2 = qlx.apply #qlx.action<pauli_rotation>(%1489, %1490, %cst_878) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1492 = qlx.apply #qlx.action<h>(%622#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_879 = arith.constant 2.3561944901923448 : f64
    %1493 = qlx.apply #qlx.action<pauli_rotation>(%1492, %cst_879) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1494 = qlx.apply #qlx.action<h>(%1493) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1495 = qlx.apply #qlx.action<h>(%1491#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_880 = arith.constant 3.1415926535897931 : f64
    %1496 = qlx.apply #qlx.action<pauli_rotation>(%1495, %cst_880) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1497 = qlx.apply #qlx.action<h>(%1496) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_881 = arith.constant 1.5707963267948966 : f64
    %1498:2 = qlx.apply #qlx.action<pauli_rotation>(%1494, %1497, %cst_881) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_882 = arith.constant 1.5707963267948966 : f64
    %1499 = qlx.apply #qlx.action<pauli_rotation>(%1498#0, %cst_882) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_883 = arith.constant 1.5707963267948966 : f64
    %1500 = qlx.apply #qlx.action<pauli_rotation>(%1498#1, %cst_883) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_884 = arith.constant 1.5707963267948966 : f64
    %1501:2 = qlx.apply #qlx.action<pauli_rotation>(%1499, %1500, %cst_884) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1502 = qlx.apply #qlx.action<h>(%622#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_885 = arith.constant 2.3561944901923448 : f64
    %1503 = qlx.apply #qlx.action<pauli_rotation>(%1502, %cst_885) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1504 = qlx.apply #qlx.action<h>(%1503) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1505 = qlx.apply #qlx.action<h>(%1501#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_886 = arith.constant 3.1415926535897931 : f64
    %1506 = qlx.apply #qlx.action<pauli_rotation>(%1505, %cst_886) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1507 = qlx.apply #qlx.action<h>(%1506) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_887 = arith.constant 1.5707963267948966 : f64
    %1508:2 = qlx.apply #qlx.action<pauli_rotation>(%1504, %1507, %cst_887) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_888 = arith.constant 1.5707963267948966 : f64
    %1509 = qlx.apply #qlx.action<pauli_rotation>(%1508#0, %cst_888) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_889 = arith.constant 1.5707963267948966 : f64
    %1510 = qlx.apply #qlx.action<pauli_rotation>(%1508#1, %cst_889) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_890 = arith.constant 1.5707963267948966 : f64
    %1511:2 = qlx.apply #qlx.action<pauli_rotation>(%1509, %1510, %cst_890) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1512 = qlx.apply #qlx.action<h>(%492#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_891 = arith.constant 2.3561944901923448 : f64
    %1513 = qlx.apply #qlx.action<pauli_rotation>(%1512, %cst_891) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1514 = qlx.apply #qlx.action<h>(%1513) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1515 = qlx.apply #qlx.action<h>(%1511#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_892 = arith.constant 3.1415926535897931 : f64
    %1516 = qlx.apply #qlx.action<pauli_rotation>(%1515, %cst_892) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1517 = qlx.apply #qlx.action<h>(%1516) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_893 = arith.constant 1.5707963267948966 : f64
    %1518:2 = qlx.apply #qlx.action<pauli_rotation>(%1514, %1517, %cst_893) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_894 = arith.constant 1.5707963267948966 : f64
    %1519 = qlx.apply #qlx.action<pauli_rotation>(%1518#0, %cst_894) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_895 = arith.constant 1.5707963267948966 : f64
    %1520 = qlx.apply #qlx.action<pauli_rotation>(%1518#1, %cst_895) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_896 = arith.constant 1.5707963267948966 : f64
    %1521:2 = qlx.apply #qlx.action<pauli_rotation>(%1519, %1520, %cst_896) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1522 = qlx.apply #qlx.action<h>(%502#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_897 = arith.constant 3.1415926535897931 : f64
    %1523 = qlx.apply #qlx.action<pauli_rotation>(%1522, %cst_897) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1524 = qlx.apply #qlx.action<h>(%1523) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1525 = qlx.apply #qlx.action<h>(%1521#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_898 = arith.constant 3.1415926535897931 : f64
    %1526 = qlx.apply #qlx.action<pauli_rotation>(%1525, %cst_898) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1527 = qlx.apply #qlx.action<h>(%1526) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_899 = arith.constant 1.5707963267948966 : f64
    %1528:2 = qlx.apply #qlx.action<pauli_rotation>(%1524, %1527, %cst_899) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_900 = arith.constant 1.5707963267948966 : f64
    %1529 = qlx.apply #qlx.action<pauli_rotation>(%1528#0, %cst_900) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_901 = arith.constant 1.5707963267948966 : f64
    %1530 = qlx.apply #qlx.action<pauli_rotation>(%1528#1, %cst_901) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_902 = arith.constant 1.5707963267948966 : f64
    %1531:2 = qlx.apply #qlx.action<pauli_rotation>(%1529, %1530, %cst_902) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1532 = qlx.apply #qlx.action<h>(%512#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_903 = arith.constant 3.1415926535897931 : f64
    %1533 = qlx.apply #qlx.action<pauli_rotation>(%1532, %cst_903) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1534 = qlx.apply #qlx.action<h>(%1533) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1535 = qlx.apply #qlx.action<h>(%1531#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_904 = arith.constant 3.1415926535897931 : f64
    %1536 = qlx.apply #qlx.action<pauli_rotation>(%1535, %cst_904) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1537 = qlx.apply #qlx.action<h>(%1536) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_905 = arith.constant 1.5707963267948966 : f64
    %1538:2 = qlx.apply #qlx.action<pauli_rotation>(%1534, %1537, %cst_905) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_906 = arith.constant 1.5707963267948966 : f64
    %1539 = qlx.apply #qlx.action<pauli_rotation>(%1538#0, %cst_906) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_907 = arith.constant 1.5707963267948966 : f64
    %1540 = qlx.apply #qlx.action<pauli_rotation>(%1538#1, %cst_907) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_908 = arith.constant 1.5707963267948966 : f64
    %1541:2 = qlx.apply #qlx.action<pauli_rotation>(%1539, %1540, %cst_908) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1542 = qlx.apply #qlx.action<h>(%522#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_909 = arith.constant 2.3561944901923448 : f64
    %1543 = qlx.apply #qlx.action<pauli_rotation>(%1542, %cst_909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1544 = qlx.apply #qlx.action<h>(%1543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1545 = qlx.apply #qlx.action<h>(%1541#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_910 = arith.constant 3.1415926535897931 : f64
    %1546 = qlx.apply #qlx.action<pauli_rotation>(%1545, %cst_910) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1547 = qlx.apply #qlx.action<h>(%1546) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_911 = arith.constant 1.5707963267948966 : f64
    %1548:2 = qlx.apply #qlx.action<pauli_rotation>(%1544, %1547, %cst_911) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_912 = arith.constant 1.5707963267948966 : f64
    %1549 = qlx.apply #qlx.action<pauli_rotation>(%1548#0, %cst_912) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_913 = arith.constant 1.5707963267948966 : f64
    %1550 = qlx.apply #qlx.action<pauli_rotation>(%1548#1, %cst_913) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_914 = arith.constant 1.5707963267948966 : f64
    %1551:2 = qlx.apply #qlx.action<pauli_rotation>(%1549, %1550, %cst_914) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1552 = qlx.apply #qlx.action<h>(%522#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_915 = arith.constant 2.3561944901923448 : f64
    %1553 = qlx.apply #qlx.action<pauli_rotation>(%1552, %cst_915) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1554 = qlx.apply #qlx.action<h>(%1553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1555 = qlx.apply #qlx.action<h>(%1551#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_916 = arith.constant 3.1415926535897931 : f64
    %1556 = qlx.apply #qlx.action<pauli_rotation>(%1555, %cst_916) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1557 = qlx.apply #qlx.action<h>(%1556) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_917 = arith.constant 1.5707963267948966 : f64
    %1558:2 = qlx.apply #qlx.action<pauli_rotation>(%1554, %1557, %cst_917) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_918 = arith.constant 1.5707963267948966 : f64
    %1559 = qlx.apply #qlx.action<pauli_rotation>(%1558#0, %cst_918) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_919 = arith.constant 1.5707963267948966 : f64
    %1560 = qlx.apply #qlx.action<pauli_rotation>(%1558#1, %cst_919) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_920 = arith.constant 1.5707963267948966 : f64
    %1561:2 = qlx.apply #qlx.action<pauli_rotation>(%1559, %1560, %cst_920) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1562 = qlx.apply #qlx.action<h>(%284#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_921 = arith.constant 3.1415926535897931 : f64
    %1563 = qlx.apply #qlx.action<pauli_rotation>(%1562, %cst_921) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1564 = qlx.apply #qlx.action<h>(%1563) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1565 = qlx.apply #qlx.action<h>(%1561#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_922 = arith.constant 3.1415926535897931 : f64
    %1566 = qlx.apply #qlx.action<pauli_rotation>(%1565, %cst_922) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1567 = qlx.apply #qlx.action<h>(%1566) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_923 = arith.constant 1.5707963267948966 : f64
    %1568:2 = qlx.apply #qlx.action<pauli_rotation>(%1564, %1567, %cst_923) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_924 = arith.constant 1.5707963267948966 : f64
    %1569 = qlx.apply #qlx.action<pauli_rotation>(%1568#0, %cst_924) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_925 = arith.constant 1.5707963267948966 : f64
    %1570 = qlx.apply #qlx.action<pauli_rotation>(%1568#1, %cst_925) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_926 = arith.constant 1.5707963267948966 : f64
    %1571:2 = qlx.apply #qlx.action<pauli_rotation>(%1569, %1570, %cst_926) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1572 = qlx.apply #qlx.action<h>(%294#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_927 = arith.constant 3.1415926535897931 : f64
    %1573 = qlx.apply #qlx.action<pauli_rotation>(%1572, %cst_927) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1574 = qlx.apply #qlx.action<h>(%1573) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1575 = qlx.apply #qlx.action<h>(%1571#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_928 = arith.constant 2.3561944901923448 : f64
    %1576 = qlx.apply #qlx.action<pauli_rotation>(%1575, %cst_928) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1577 = qlx.apply #qlx.action<h>(%1576) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_929 = arith.constant 0.78539816339744828 : f64
    %1578:2 = qlx.apply #qlx.action<pauli_rotation>(%1574, %1577, %cst_929) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_930 = arith.constant 1.5707963267948966 : f64
    %1579 = qlx.apply #qlx.action<pauli_rotation>(%1578#0, %cst_930) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_931 = arith.constant 1.5707963267948966 : f64
    %1580 = qlx.apply #qlx.action<pauli_rotation>(%1578#1, %cst_931) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_932 = arith.constant 0.78539816339744828 : f64
    %1581:2 = qlx.apply #qlx.action<pauli_rotation>(%1579, %1580, %cst_932) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1582 = qlx.apply #qlx.action<h>(%1421#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_933 = arith.constant 3.1415926535897931 : f64
    %1583 = qlx.apply #qlx.action<pauli_rotation>(%1582, %cst_933) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1584 = qlx.apply #qlx.action<h>(%1583) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1585 = qlx.apply #qlx.action<h>(%1411#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_934 = arith.constant 3.1415926535897931 : f64
    %1586 = qlx.apply #qlx.action<pauli_rotation>(%1585, %cst_934) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1587 = qlx.apply #qlx.action<h>(%1586) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_935 = arith.constant 1.5707963267948966 : f64
    %1588:2 = qlx.apply #qlx.action<pauli_rotation>(%1584, %1587, %cst_935) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_936 = arith.constant 1.5707963267948966 : f64
    %1589 = qlx.apply #qlx.action<pauli_rotation>(%1588#0, %cst_936) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_937 = arith.constant 1.5707963267948966 : f64
    %1590 = qlx.apply #qlx.action<pauli_rotation>(%1588#1, %cst_937) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_938 = arith.constant 1.5707963267948966 : f64
    %1591:2 = qlx.apply #qlx.action<pauli_rotation>(%1589, %1590, %cst_938) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1592 = qlx.apply #qlx.action<h>(%1431#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_939 = arith.constant 3.1415926535897931 : f64
    %1593 = qlx.apply #qlx.action<pauli_rotation>(%1592, %cst_939) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1594 = qlx.apply #qlx.action<h>(%1593) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1595 = qlx.apply #qlx.action<h>(%1591#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_940 = arith.constant 3.1415926535897931 : f64
    %1596 = qlx.apply #qlx.action<pauli_rotation>(%1595, %cst_940) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1597 = qlx.apply #qlx.action<h>(%1596) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_941 = arith.constant 1.5707963267948966 : f64
    %1598:2 = qlx.apply #qlx.action<pauli_rotation>(%1594, %1597, %cst_941) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_942 = arith.constant 1.5707963267948966 : f64
    %1599 = qlx.apply #qlx.action<pauli_rotation>(%1598#0, %cst_942) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_943 = arith.constant 1.5707963267948966 : f64
    %1600 = qlx.apply #qlx.action<pauli_rotation>(%1598#1, %cst_943) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_944 = arith.constant 1.5707963267948966 : f64
    %1601:2 = qlx.apply #qlx.action<pauli_rotation>(%1599, %1600, %cst_944) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1602 = qlx.apply #qlx.action<h>(%1441#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_945 = arith.constant 3.1415926535897931 : f64
    %1603 = qlx.apply #qlx.action<pauli_rotation>(%1602, %cst_945) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1604 = qlx.apply #qlx.action<h>(%1603) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1605 = qlx.apply #qlx.action<h>(%1601#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_946 = arith.constant 3.1415926535897931 : f64
    %1606 = qlx.apply #qlx.action<pauli_rotation>(%1605, %cst_946) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1607 = qlx.apply #qlx.action<h>(%1606) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_947 = arith.constant 1.5707963267948966 : f64
    %1608:2 = qlx.apply #qlx.action<pauli_rotation>(%1604, %1607, %cst_947) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_948 = arith.constant 1.5707963267948966 : f64
    %1609 = qlx.apply #qlx.action<pauli_rotation>(%1608#0, %cst_948) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_949 = arith.constant 1.5707963267948966 : f64
    %1610 = qlx.apply #qlx.action<pauli_rotation>(%1608#1, %cst_949) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_950 = arith.constant 1.5707963267948966 : f64
    %1611:2 = qlx.apply #qlx.action<pauli_rotation>(%1609, %1610, %cst_950) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1612 = qlx.apply #qlx.action<h>(%1451#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_951 = arith.constant 3.1415926535897931 : f64
    %1613 = qlx.apply #qlx.action<pauli_rotation>(%1612, %cst_951) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1614 = qlx.apply #qlx.action<h>(%1613) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1615 = qlx.apply #qlx.action<h>(%1611#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_952 = arith.constant 3.1415926535897931 : f64
    %1616 = qlx.apply #qlx.action<pauli_rotation>(%1615, %cst_952) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1617 = qlx.apply #qlx.action<h>(%1616) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_953 = arith.constant 1.5707963267948966 : f64
    %1618:2 = qlx.apply #qlx.action<pauli_rotation>(%1614, %1617, %cst_953) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_954 = arith.constant 1.5707963267948966 : f64
    %1619 = qlx.apply #qlx.action<pauli_rotation>(%1618#0, %cst_954) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_955 = arith.constant 1.5707963267948966 : f64
    %1620 = qlx.apply #qlx.action<pauli_rotation>(%1618#1, %cst_955) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_956 = arith.constant 1.5707963267948966 : f64
    %1621:2 = qlx.apply #qlx.action<pauli_rotation>(%1619, %1620, %cst_956) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1622 = qlx.apply #qlx.action<h>(%1461#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_957 = arith.constant 3.1415926535897931 : f64
    %1623 = qlx.apply #qlx.action<pauli_rotation>(%1622, %cst_957) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1624 = qlx.apply #qlx.action<h>(%1623) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1625 = qlx.apply #qlx.action<h>(%1621#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_958 = arith.constant 3.1415926535897931 : f64
    %1626 = qlx.apply #qlx.action<pauli_rotation>(%1625, %cst_958) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1627 = qlx.apply #qlx.action<h>(%1626) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_959 = arith.constant 1.5707963267948966 : f64
    %1628:2 = qlx.apply #qlx.action<pauli_rotation>(%1624, %1627, %cst_959) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_960 = arith.constant 1.5707963267948966 : f64
    %1629 = qlx.apply #qlx.action<pauli_rotation>(%1628#0, %cst_960) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_961 = arith.constant 1.5707963267948966 : f64
    %1630 = qlx.apply #qlx.action<pauli_rotation>(%1628#1, %cst_961) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_962 = arith.constant 1.5707963267948966 : f64
    %1631:2 = qlx.apply #qlx.action<pauli_rotation>(%1629, %1630, %cst_962) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1632 = qlx.apply #qlx.action<h>(%1471#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_963 = arith.constant 3.1415926535897931 : f64
    %1633 = qlx.apply #qlx.action<pauli_rotation>(%1632, %cst_963) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1634 = qlx.apply #qlx.action<h>(%1633) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1635 = qlx.apply #qlx.action<h>(%1631#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_964 = arith.constant 3.1415926535897931 : f64
    %1636 = qlx.apply #qlx.action<pauli_rotation>(%1635, %cst_964) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1637 = qlx.apply #qlx.action<h>(%1636) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_965 = arith.constant 1.5707963267948966 : f64
    %1638:2 = qlx.apply #qlx.action<pauli_rotation>(%1634, %1637, %cst_965) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_966 = arith.constant 1.5707963267948966 : f64
    %1639 = qlx.apply #qlx.action<pauli_rotation>(%1638#0, %cst_966) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_967 = arith.constant 1.5707963267948966 : f64
    %1640 = qlx.apply #qlx.action<pauli_rotation>(%1638#1, %cst_967) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_968 = arith.constant 1.5707963267948966 : f64
    %1641:2 = qlx.apply #qlx.action<pauli_rotation>(%1639, %1640, %cst_968) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1642 = qlx.apply #qlx.action<h>(%1481#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_969 = arith.constant 2.3561944901923448 : f64
    %1643 = qlx.apply #qlx.action<pauli_rotation>(%1642, %cst_969) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1644 = qlx.apply #qlx.action<h>(%1643) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1645 = qlx.apply #qlx.action<h>(%1641#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_970 = arith.constant 2.3561944901923448 : f64
    %1646 = qlx.apply #qlx.action<pauli_rotation>(%1645, %cst_970) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1647 = qlx.apply #qlx.action<h>(%1646) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_971 = arith.constant 0.78539816339744828 : f64
    %1648:2 = qlx.apply #qlx.action<pauli_rotation>(%1644, %1647, %cst_971) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_972 = arith.constant 1.5707963267948966 : f64
    %1649 = qlx.apply #qlx.action<pauli_rotation>(%1648#0, %cst_972) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_973 = arith.constant 1.5707963267948966 : f64
    %1650 = qlx.apply #qlx.action<pauli_rotation>(%1648#1, %cst_973) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_974 = arith.constant 0.78539816339744828 : f64
    %1651:2 = qlx.apply #qlx.action<pauli_rotation>(%1649, %1650, %cst_974) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1652 = qlx.apply #qlx.action<h>(%1491#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_975 = arith.constant 3.1415926535897931 : f64
    %1653 = qlx.apply #qlx.action<pauli_rotation>(%1652, %cst_975) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1654 = qlx.apply #qlx.action<h>(%1653) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1655 = qlx.apply #qlx.action<h>(%1651#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_976 = arith.constant 2.3561944901923448 : f64
    %1656 = qlx.apply #qlx.action<pauli_rotation>(%1655, %cst_976) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1657 = qlx.apply #qlx.action<h>(%1656) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_977 = arith.constant 1.5707963267948966 : f64
    %1658:2 = qlx.apply #qlx.action<pauli_rotation>(%1654, %1657, %cst_977) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_978 = arith.constant 1.5707963267948966 : f64
    %1659 = qlx.apply #qlx.action<pauli_rotation>(%1658#0, %cst_978) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_979 = arith.constant 1.5707963267948966 : f64
    %1660 = qlx.apply #qlx.action<pauli_rotation>(%1658#1, %cst_979) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_980 = arith.constant 1.5707963267948966 : f64
    %1661:2 = qlx.apply #qlx.action<pauli_rotation>(%1659, %1660, %cst_980) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1662 = qlx.apply #qlx.action<h>(%1501#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_981 = arith.constant 3.1415926535897931 : f64
    %1663 = qlx.apply #qlx.action<pauli_rotation>(%1662, %cst_981) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1664 = qlx.apply #qlx.action<h>(%1663) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1665 = qlx.apply #qlx.action<h>(%1661#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_982 = arith.constant 3.1415926535897931 : f64
    %1666 = qlx.apply #qlx.action<pauli_rotation>(%1665, %cst_982) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1667 = qlx.apply #qlx.action<h>(%1666) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_983 = arith.constant 1.5707963267948966 : f64
    %1668:2 = qlx.apply #qlx.action<pauli_rotation>(%1664, %1667, %cst_983) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_984 = arith.constant 1.5707963267948966 : f64
    %1669 = qlx.apply #qlx.action<pauli_rotation>(%1668#0, %cst_984) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_985 = arith.constant 1.5707963267948966 : f64
    %1670 = qlx.apply #qlx.action<pauli_rotation>(%1668#1, %cst_985) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_986 = arith.constant 1.5707963267948966 : f64
    %1671:2 = qlx.apply #qlx.action<pauli_rotation>(%1669, %1670, %cst_986) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1672 = qlx.apply #qlx.action<h>(%1511#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_987 = arith.constant 3.1415926535897931 : f64
    %1673 = qlx.apply #qlx.action<pauli_rotation>(%1672, %cst_987) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1674 = qlx.apply #qlx.action<h>(%1673) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1675 = qlx.apply #qlx.action<h>(%1671#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_988 = arith.constant 3.1415926535897931 : f64
    %1676 = qlx.apply #qlx.action<pauli_rotation>(%1675, %cst_988) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1677 = qlx.apply #qlx.action<h>(%1676) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_989 = arith.constant 1.5707963267948966 : f64
    %1678:2 = qlx.apply #qlx.action<pauli_rotation>(%1674, %1677, %cst_989) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_990 = arith.constant 1.5707963267948966 : f64
    %1679 = qlx.apply #qlx.action<pauli_rotation>(%1678#0, %cst_990) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_991 = arith.constant 1.5707963267948966 : f64
    %1680 = qlx.apply #qlx.action<pauli_rotation>(%1678#1, %cst_991) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_992 = arith.constant 1.5707963267948966 : f64
    %1681:2 = qlx.apply #qlx.action<pauli_rotation>(%1679, %1680, %cst_992) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1682 = qlx.apply #qlx.action<h>(%1521#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_993 = arith.constant 3.1415926535897931 : f64
    %1683 = qlx.apply #qlx.action<pauli_rotation>(%1682, %cst_993) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1684 = qlx.apply #qlx.action<h>(%1683) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1685 = qlx.apply #qlx.action<h>(%1681#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_994 = arith.constant 3.1415926535897931 : f64
    %1686 = qlx.apply #qlx.action<pauli_rotation>(%1685, %cst_994) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1687 = qlx.apply #qlx.action<h>(%1686) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_995 = arith.constant 1.5707963267948966 : f64
    %1688:2 = qlx.apply #qlx.action<pauli_rotation>(%1684, %1687, %cst_995) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_996 = arith.constant 1.5707963267948966 : f64
    %1689 = qlx.apply #qlx.action<pauli_rotation>(%1688#0, %cst_996) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_997 = arith.constant 1.5707963267948966 : f64
    %1690 = qlx.apply #qlx.action<pauli_rotation>(%1688#1, %cst_997) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_998 = arith.constant 1.5707963267948966 : f64
    %1691:2 = qlx.apply #qlx.action<pauli_rotation>(%1689, %1690, %cst_998) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1692 = qlx.apply #qlx.action<h>(%1531#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_999 = arith.constant 3.1415926535897931 : f64
    %1693 = qlx.apply #qlx.action<pauli_rotation>(%1692, %cst_999) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1694 = qlx.apply #qlx.action<h>(%1693) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1695 = qlx.apply #qlx.action<h>(%1691#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1000 = arith.constant 3.1415926535897931 : f64
    %1696 = qlx.apply #qlx.action<pauli_rotation>(%1695, %cst_1000) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1697 = qlx.apply #qlx.action<h>(%1696) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1001 = arith.constant 1.5707963267948966 : f64
    %1698:2 = qlx.apply #qlx.action<pauli_rotation>(%1694, %1697, %cst_1001) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1002 = arith.constant 1.5707963267948966 : f64
    %1699 = qlx.apply #qlx.action<pauli_rotation>(%1698#0, %cst_1002) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1003 = arith.constant 1.5707963267948966 : f64
    %1700 = qlx.apply #qlx.action<pauli_rotation>(%1698#1, %cst_1003) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1004 = arith.constant 1.5707963267948966 : f64
    %1701:2 = qlx.apply #qlx.action<pauli_rotation>(%1699, %1700, %cst_1004) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1702 = qlx.apply #qlx.action<h>(%1541#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1005 = arith.constant 3.1415926535897931 : f64
    %1703 = qlx.apply #qlx.action<pauli_rotation>(%1702, %cst_1005) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1704 = qlx.apply #qlx.action<h>(%1703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1705 = qlx.apply #qlx.action<h>(%1701#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1006 = arith.constant 3.1415926535897931 : f64
    %1706 = qlx.apply #qlx.action<pauli_rotation>(%1705, %cst_1006) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1707 = qlx.apply #qlx.action<h>(%1706) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1007 = arith.constant 1.5707963267948966 : f64
    %1708:2 = qlx.apply #qlx.action<pauli_rotation>(%1704, %1707, %cst_1007) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1008 = arith.constant 1.5707963267948966 : f64
    %1709 = qlx.apply #qlx.action<pauli_rotation>(%1708#0, %cst_1008) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1009 = arith.constant 1.5707963267948966 : f64
    %1710 = qlx.apply #qlx.action<pauli_rotation>(%1708#1, %cst_1009) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1010 = arith.constant 1.5707963267948966 : f64
    %1711:2 = qlx.apply #qlx.action<pauli_rotation>(%1709, %1710, %cst_1010) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1712 = qlx.apply #qlx.action<h>(%1551#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1011 = arith.constant 3.1415926535897931 : f64
    %1713 = qlx.apply #qlx.action<pauli_rotation>(%1712, %cst_1011) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1714 = qlx.apply #qlx.action<h>(%1713) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1715 = qlx.apply #qlx.action<h>(%1711#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1012 = arith.constant 3.1415926535897931 : f64
    %1716 = qlx.apply #qlx.action<pauli_rotation>(%1715, %cst_1012) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1717 = qlx.apply #qlx.action<h>(%1716) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1013 = arith.constant 1.5707963267948966 : f64
    %1718:2 = qlx.apply #qlx.action<pauli_rotation>(%1714, %1717, %cst_1013) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1014 = arith.constant 1.5707963267948966 : f64
    %1719 = qlx.apply #qlx.action<pauli_rotation>(%1718#0, %cst_1014) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1015 = arith.constant 1.5707963267948966 : f64
    %1720 = qlx.apply #qlx.action<pauli_rotation>(%1718#1, %cst_1015) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1016 = arith.constant 1.5707963267948966 : f64
    %1721:2 = qlx.apply #qlx.action<pauli_rotation>(%1719, %1720, %cst_1016) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1722 = qlx.apply #qlx.action<h>(%1561#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1017 = arith.constant 3.1415926535897931 : f64
    %1723 = qlx.apply #qlx.action<pauli_rotation>(%1722, %cst_1017) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1724 = qlx.apply #qlx.action<h>(%1723) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1725 = qlx.apply #qlx.action<h>(%1721#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1018 = arith.constant 3.1415926535897931 : f64
    %1726 = qlx.apply #qlx.action<pauli_rotation>(%1725, %cst_1018) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1727 = qlx.apply #qlx.action<h>(%1726) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1019 = arith.constant 1.5707963267948966 : f64
    %1728:2 = qlx.apply #qlx.action<pauli_rotation>(%1724, %1727, %cst_1019) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1020 = arith.constant 1.5707963267948966 : f64
    %1729 = qlx.apply #qlx.action<pauli_rotation>(%1728#0, %cst_1020) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1021 = arith.constant 1.5707963267948966 : f64
    %1730 = qlx.apply #qlx.action<pauli_rotation>(%1728#1, %cst_1021) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1022 = arith.constant 1.5707963267948966 : f64
    %1731:2 = qlx.apply #qlx.action<pauli_rotation>(%1729, %1730, %cst_1022) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1732 = qlx.apply #qlx.action<h>(%1571#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1023 = arith.constant 3.1415926535897931 : f64
    %1733 = qlx.apply #qlx.action<pauli_rotation>(%1732, %cst_1023) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1734 = qlx.apply #qlx.action<h>(%1733) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1735 = qlx.apply #qlx.action<h>(%1731#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1024 = arith.constant 3.1415926535897931 : f64
    %1736 = qlx.apply #qlx.action<pauli_rotation>(%1735, %cst_1024) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1737 = qlx.apply #qlx.action<h>(%1736) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1025 = arith.constant 1.5707963267948966 : f64
    %1738:2 = qlx.apply #qlx.action<pauli_rotation>(%1734, %1737, %cst_1025) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1026 = arith.constant 1.5707963267948966 : f64
    %1739 = qlx.apply #qlx.action<pauli_rotation>(%1738#0, %cst_1026) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1027 = arith.constant 1.5707963267948966 : f64
    %1740 = qlx.apply #qlx.action<pauli_rotation>(%1738#1, %cst_1027) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1028 = arith.constant 1.5707963267948966 : f64
    %1741:2 = qlx.apply #qlx.action<pauli_rotation>(%1739, %1740, %cst_1028) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1742 = qlx.apply #qlx.action<h>(%1581#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1029 = arith.constant 2.3561944901923448 : f64
    %1743 = qlx.apply #qlx.action<pauli_rotation>(%1742, %cst_1029) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1744 = qlx.apply #qlx.action<h>(%1743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1745 = qlx.apply #qlx.action<h>(%1741#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1030 = arith.constant 3.1415926535897931 : f64
    %1746 = qlx.apply #qlx.action<pauli_rotation>(%1745, %cst_1030) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1747 = qlx.apply #qlx.action<h>(%1746) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1031 = arith.constant 1.1415926535897931 : f64
    %1748:2 = qlx.apply #qlx.action<pauli_rotation>(%1744, %1747, %cst_1031) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1032 = arith.constant 1.5707963267948966 : f64
    %1749 = qlx.apply #qlx.action<pauli_rotation>(%1748#0, %cst_1032) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1033 = arith.constant 1.5707963267948966 : f64
    %1750 = qlx.apply #qlx.action<pauli_rotation>(%1748#1, %cst_1033) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1034 = arith.constant 1.1415926535897931 : f64
    %1751:2 = qlx.apply #qlx.action<pauli_rotation>(%1749, %1750, %cst_1034) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1752 = qlx.apply #qlx.action<h>(%1581#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1035 = arith.constant 1.5707963267948966 : f64
    %1753 = qlx.apply #qlx.action<pauli_rotation>(%1752, %cst_1035) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1754 = qlx.apply #qlx.action<h>(%1753) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1755 = qlx.apply #qlx.action<h>(%1751#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1036 = arith.constant 2.3561944901923448 : f64
    %1756 = qlx.apply #qlx.action<pauli_rotation>(%1755, %cst_1036) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1757 = qlx.apply #qlx.action<h>(%1756) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1037 = arith.constant 0.78539816339744828 : f64
    %1758:2 = qlx.apply #qlx.action<pauli_rotation>(%1754, %1757, %cst_1037) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1038 = arith.constant 1.5707963267948966 : f64
    %1759 = qlx.apply #qlx.action<pauli_rotation>(%1758#0, %cst_1038) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1039 = arith.constant 1.5707963267948966 : f64
    %1760 = qlx.apply #qlx.action<pauli_rotation>(%1758#1, %cst_1039) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1040 = arith.constant 0.78539816339744828 : f64
    %1761:2 = qlx.apply #qlx.action<pauli_rotation>(%1759, %1760, %cst_1040) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1762 = qlx.apply #qlx.action<h>(%1291#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1041 = arith.constant 2.3561944901923448 : f64
    %1763 = qlx.apply #qlx.action<pauli_rotation>(%1762, %cst_1041) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1764 = qlx.apply #qlx.action<h>(%1763) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1765 = qlx.apply #qlx.action<h>(%1341#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1042 = arith.constant 2.3561944901923448 : f64
    %1766 = qlx.apply #qlx.action<pauli_rotation>(%1765, %cst_1042) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1767 = qlx.apply #qlx.action<h>(%1766) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1043 = arith.constant 1.5707963267948966 : f64
    %1768:2 = qlx.apply #qlx.action<pauli_rotation>(%1764, %1767, %cst_1043) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1044 = arith.constant 1.5707963267948966 : f64
    %1769 = qlx.apply #qlx.action<pauli_rotation>(%1768#0, %cst_1044) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1045 = arith.constant 1.5707963267948966 : f64
    %1770 = qlx.apply #qlx.action<pauli_rotation>(%1768#1, %cst_1045) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1046 = arith.constant 1.5707963267948966 : f64
    %1771:2 = qlx.apply #qlx.action<pauli_rotation>(%1769, %1770, %cst_1046) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1772 = qlx.apply #qlx.action<h>(%1291#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1047 = arith.constant 2.3561944901923448 : f64
    %1773 = qlx.apply #qlx.action<pauli_rotation>(%1772, %cst_1047) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1774 = qlx.apply #qlx.action<h>(%1773) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1775 = qlx.apply #qlx.action<h>(%1771#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1048 = arith.constant 3.1415926535897931 : f64
    %1776 = qlx.apply #qlx.action<pauli_rotation>(%1775, %cst_1048) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1777 = qlx.apply #qlx.action<h>(%1776) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1049 = arith.constant 1.5707963267948966 : f64
    %1778:2 = qlx.apply #qlx.action<pauli_rotation>(%1774, %1777, %cst_1049) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1050 = arith.constant 1.5707963267948966 : f64
    %1779 = qlx.apply #qlx.action<pauli_rotation>(%1778#0, %cst_1050) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1051 = arith.constant 1.5707963267948966 : f64
    %1780 = qlx.apply #qlx.action<pauli_rotation>(%1778#1, %cst_1051) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1052 = arith.constant 1.5707963267948966 : f64
    %1781:2 = qlx.apply #qlx.action<pauli_rotation>(%1779, %1780, %cst_1052) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1782 = qlx.apply #qlx.action<h>(%1271#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1053 = arith.constant 2.3561944901923448 : f64
    %1783 = qlx.apply #qlx.action<pauli_rotation>(%1782, %cst_1053) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1784 = qlx.apply #qlx.action<h>(%1783) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1785 = qlx.apply #qlx.action<h>(%1781#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1054 = arith.constant 3.1415926535897931 : f64
    %1786 = qlx.apply #qlx.action<pauli_rotation>(%1785, %cst_1054) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1787 = qlx.apply #qlx.action<h>(%1786) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1055 = arith.constant 1.5707963267948966 : f64
    %1788:2 = qlx.apply #qlx.action<pauli_rotation>(%1784, %1787, %cst_1055) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1056 = arith.constant 1.5707963267948966 : f64
    %1789 = qlx.apply #qlx.action<pauli_rotation>(%1788#0, %cst_1056) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1057 = arith.constant 1.5707963267948966 : f64
    %1790 = qlx.apply #qlx.action<pauli_rotation>(%1788#1, %cst_1057) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1058 = arith.constant 1.5707963267948966 : f64
    %1791:2 = qlx.apply #qlx.action<pauli_rotation>(%1789, %1790, %cst_1058) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1792 = qlx.apply #qlx.action<h>(%1361#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1059 = arith.constant 3.1415926535897931 : f64
    %1793 = qlx.apply #qlx.action<pauli_rotation>(%1792, %cst_1059) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1794 = qlx.apply #qlx.action<h>(%1793) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1795 = qlx.apply #qlx.action<h>(%1791#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1060 = arith.constant 3.1415926535897931 : f64
    %1796 = qlx.apply #qlx.action<pauli_rotation>(%1795, %cst_1060) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1797 = qlx.apply #qlx.action<h>(%1796) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1061 = arith.constant 1.5707963267948966 : f64
    %1798:2 = qlx.apply #qlx.action<pauli_rotation>(%1794, %1797, %cst_1061) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1062 = arith.constant 1.5707963267948966 : f64
    %1799 = qlx.apply #qlx.action<pauli_rotation>(%1798#0, %cst_1062) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1063 = arith.constant 1.5707963267948966 : f64
    %1800 = qlx.apply #qlx.action<pauli_rotation>(%1798#1, %cst_1063) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1064 = arith.constant 1.5707963267948966 : f64
    %1801:2 = qlx.apply #qlx.action<pauli_rotation>(%1799, %1800, %cst_1064) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1802 = qlx.apply #qlx.action<h>(%1371#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1065 = arith.constant 3.1415926535897931 : f64
    %1803 = qlx.apply #qlx.action<pauli_rotation>(%1802, %cst_1065) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1804 = qlx.apply #qlx.action<h>(%1803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1805 = qlx.apply #qlx.action<h>(%1801#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1066 = arith.constant 3.1415926535897931 : f64
    %1806 = qlx.apply #qlx.action<pauli_rotation>(%1805, %cst_1066) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1807 = qlx.apply #qlx.action<h>(%1806) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1067 = arith.constant 1.5707963267948966 : f64
    %1808:2 = qlx.apply #qlx.action<pauli_rotation>(%1804, %1807, %cst_1067) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1068 = arith.constant 1.5707963267948966 : f64
    %1809 = qlx.apply #qlx.action<pauli_rotation>(%1808#0, %cst_1068) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1069 = arith.constant 1.5707963267948966 : f64
    %1810 = qlx.apply #qlx.action<pauli_rotation>(%1808#1, %cst_1069) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1070 = arith.constant 1.5707963267948966 : f64
    %1811:2 = qlx.apply #qlx.action<pauli_rotation>(%1809, %1810, %cst_1070) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1812 = qlx.apply #qlx.action<h>(%1381#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1071 = arith.constant 3.1415926535897931 : f64
    %1813 = qlx.apply #qlx.action<pauli_rotation>(%1812, %cst_1071) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1814 = qlx.apply #qlx.action<h>(%1813) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1815 = qlx.apply #qlx.action<h>(%1811#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1072 = arith.constant 3.1415926535897931 : f64
    %1816 = qlx.apply #qlx.action<pauli_rotation>(%1815, %cst_1072) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1817 = qlx.apply #qlx.action<h>(%1816) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1073 = arith.constant 1.5707963267948966 : f64
    %1818:2 = qlx.apply #qlx.action<pauli_rotation>(%1814, %1817, %cst_1073) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1074 = arith.constant 1.5707963267948966 : f64
    %1819 = qlx.apply #qlx.action<pauli_rotation>(%1818#0, %cst_1074) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1075 = arith.constant 1.5707963267948966 : f64
    %1820 = qlx.apply #qlx.action<pauli_rotation>(%1818#1, %cst_1075) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1076 = arith.constant 1.5707963267948966 : f64
    %1821:2 = qlx.apply #qlx.action<pauli_rotation>(%1819, %1820, %cst_1076) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1822 = qlx.apply #qlx.action<h>(%1391#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1077 = arith.constant 3.1415926535897931 : f64
    %1823 = qlx.apply #qlx.action<pauli_rotation>(%1822, %cst_1077) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1824 = qlx.apply #qlx.action<h>(%1823) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1825 = qlx.apply #qlx.action<h>(%1821#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1078 = arith.constant 3.1415926535897931 : f64
    %1826 = qlx.apply #qlx.action<pauli_rotation>(%1825, %cst_1078) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1827 = qlx.apply #qlx.action<h>(%1826) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1079 = arith.constant 1.5707963267948966 : f64
    %1828:2 = qlx.apply #qlx.action<pauli_rotation>(%1824, %1827, %cst_1079) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1080 = arith.constant 1.5707963267948966 : f64
    %1829 = qlx.apply #qlx.action<pauli_rotation>(%1828#0, %cst_1080) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1081 = arith.constant 1.5707963267948966 : f64
    %1830 = qlx.apply #qlx.action<pauli_rotation>(%1828#1, %cst_1081) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1082 = arith.constant 1.5707963267948966 : f64
    %1831:2 = qlx.apply #qlx.action<pauli_rotation>(%1829, %1830, %cst_1082) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1832 = qlx.apply #qlx.action<h>(%1401#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1083 = arith.constant 3.1415926535897931 : f64
    %1833 = qlx.apply #qlx.action<pauli_rotation>(%1832, %cst_1083) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1834 = qlx.apply #qlx.action<h>(%1833) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1835 = qlx.apply #qlx.action<h>(%1831#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1084 = arith.constant 3.1415926535897931 : f64
    %1836 = qlx.apply #qlx.action<pauli_rotation>(%1835, %cst_1084) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1837 = qlx.apply #qlx.action<h>(%1836) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1085 = arith.constant 1.5707963267948966 : f64
    %1838:2 = qlx.apply #qlx.action<pauli_rotation>(%1834, %1837, %cst_1085) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1086 = arith.constant 1.5707963267948966 : f64
    %1839 = qlx.apply #qlx.action<pauli_rotation>(%1838#0, %cst_1086) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1087 = arith.constant 1.5707963267948966 : f64
    %1840 = qlx.apply #qlx.action<pauli_rotation>(%1838#1, %cst_1087) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1088 = arith.constant 1.5707963267948966 : f64
    %1841:2 = qlx.apply #qlx.action<pauli_rotation>(%1839, %1840, %cst_1088) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1842 = qlx.apply #qlx.action<h>(%1591#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1089 = arith.constant 3.1415926535897931 : f64
    %1843 = qlx.apply #qlx.action<pauli_rotation>(%1842, %cst_1089) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1844 = qlx.apply #qlx.action<h>(%1843) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1845 = qlx.apply #qlx.action<h>(%1841#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1090 = arith.constant 3.1415926535897931 : f64
    %1846 = qlx.apply #qlx.action<pauli_rotation>(%1845, %cst_1090) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1847 = qlx.apply #qlx.action<h>(%1846) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1091 = arith.constant 1.5707963267948966 : f64
    %1848:2 = qlx.apply #qlx.action<pauli_rotation>(%1844, %1847, %cst_1091) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1092 = arith.constant 1.5707963267948966 : f64
    %1849 = qlx.apply #qlx.action<pauli_rotation>(%1848#0, %cst_1092) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1093 = arith.constant 1.5707963267948966 : f64
    %1850 = qlx.apply #qlx.action<pauli_rotation>(%1848#1, %cst_1093) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1094 = arith.constant 1.5707963267948966 : f64
    %1851:2 = qlx.apply #qlx.action<pauli_rotation>(%1849, %1850, %cst_1094) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1852 = qlx.apply #qlx.action<h>(%1601#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1095 = arith.constant 3.1415926535897931 : f64
    %1853 = qlx.apply #qlx.action<pauli_rotation>(%1852, %cst_1095) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1854 = qlx.apply #qlx.action<h>(%1853) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1855 = qlx.apply #qlx.action<h>(%1851#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1096 = arith.constant 3.1415926535897931 : f64
    %1856 = qlx.apply #qlx.action<pauli_rotation>(%1855, %cst_1096) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1857 = qlx.apply #qlx.action<h>(%1856) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1097 = arith.constant 1.5707963267948966 : f64
    %1858:2 = qlx.apply #qlx.action<pauli_rotation>(%1854, %1857, %cst_1097) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1098 = arith.constant 1.5707963267948966 : f64
    %1859 = qlx.apply #qlx.action<pauli_rotation>(%1858#0, %cst_1098) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1099 = arith.constant 1.5707963267948966 : f64
    %1860 = qlx.apply #qlx.action<pauli_rotation>(%1858#1, %cst_1099) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1100 = arith.constant 1.5707963267948966 : f64
    %1861:2 = qlx.apply #qlx.action<pauli_rotation>(%1859, %1860, %cst_1100) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1862 = qlx.apply #qlx.action<h>(%1611#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1101 = arith.constant 3.1415926535897931 : f64
    %1863 = qlx.apply #qlx.action<pauli_rotation>(%1862, %cst_1101) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1864 = qlx.apply #qlx.action<h>(%1863) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1865 = qlx.apply #qlx.action<h>(%1861#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1102 = arith.constant 3.1415926535897931 : f64
    %1866 = qlx.apply #qlx.action<pauli_rotation>(%1865, %cst_1102) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1867 = qlx.apply #qlx.action<h>(%1866) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1103 = arith.constant 1.5707963267948966 : f64
    %1868:2 = qlx.apply #qlx.action<pauli_rotation>(%1864, %1867, %cst_1103) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1104 = arith.constant 1.5707963267948966 : f64
    %1869 = qlx.apply #qlx.action<pauli_rotation>(%1868#0, %cst_1104) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1105 = arith.constant 1.5707963267948966 : f64
    %1870 = qlx.apply #qlx.action<pauli_rotation>(%1868#1, %cst_1105) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1106 = arith.constant 1.5707963267948966 : f64
    %1871:2 = qlx.apply #qlx.action<pauli_rotation>(%1869, %1870, %cst_1106) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1872 = qlx.apply #qlx.action<h>(%1621#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1107 = arith.constant 3.1415926535897931 : f64
    %1873 = qlx.apply #qlx.action<pauli_rotation>(%1872, %cst_1107) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1874 = qlx.apply #qlx.action<h>(%1873) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1875 = qlx.apply #qlx.action<h>(%1871#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1108 = arith.constant 3.1415926535897931 : f64
    %1876 = qlx.apply #qlx.action<pauli_rotation>(%1875, %cst_1108) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1877 = qlx.apply #qlx.action<h>(%1876) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1109 = arith.constant 1.5707963267948966 : f64
    %1878:2 = qlx.apply #qlx.action<pauli_rotation>(%1874, %1877, %cst_1109) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1110 = arith.constant 1.5707963267948966 : f64
    %1879 = qlx.apply #qlx.action<pauli_rotation>(%1878#0, %cst_1110) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1111 = arith.constant 1.5707963267948966 : f64
    %1880 = qlx.apply #qlx.action<pauli_rotation>(%1878#1, %cst_1111) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1112 = arith.constant 1.5707963267948966 : f64
    %1881:2 = qlx.apply #qlx.action<pauli_rotation>(%1879, %1880, %cst_1112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1882 = qlx.apply #qlx.action<h>(%1631#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1113 = arith.constant 3.1415926535897931 : f64
    %1883 = qlx.apply #qlx.action<pauli_rotation>(%1882, %cst_1113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1884 = qlx.apply #qlx.action<h>(%1883) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1885 = qlx.apply #qlx.action<h>(%1881#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1114 = arith.constant 3.1415926535897931 : f64
    %1886 = qlx.apply #qlx.action<pauli_rotation>(%1885, %cst_1114) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1887 = qlx.apply #qlx.action<h>(%1886) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1115 = arith.constant 1.5707963267948966 : f64
    %1888:2 = qlx.apply #qlx.action<pauli_rotation>(%1884, %1887, %cst_1115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1116 = arith.constant 1.5707963267948966 : f64
    %1889 = qlx.apply #qlx.action<pauli_rotation>(%1888#0, %cst_1116) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1117 = arith.constant 1.5707963267948966 : f64
    %1890 = qlx.apply #qlx.action<pauli_rotation>(%1888#1, %cst_1117) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1118 = arith.constant 1.5707963267948966 : f64
    %1891:2 = qlx.apply #qlx.action<pauli_rotation>(%1889, %1890, %cst_1118) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1892 = qlx.apply #qlx.action<h>(%1641#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1119 = arith.constant 3.1415926535897931 : f64
    %1893 = qlx.apply #qlx.action<pauli_rotation>(%1892, %cst_1119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1894 = qlx.apply #qlx.action<h>(%1893) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1895 = qlx.apply #qlx.action<h>(%1891#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1120 = arith.constant 3.1415926535897931 : f64
    %1896 = qlx.apply #qlx.action<pauli_rotation>(%1895, %cst_1120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1897 = qlx.apply #qlx.action<h>(%1896) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1121 = arith.constant 1.5707963267948966 : f64
    %1898:2 = qlx.apply #qlx.action<pauli_rotation>(%1894, %1897, %cst_1121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1122 = arith.constant 1.5707963267948966 : f64
    %1899 = qlx.apply #qlx.action<pauli_rotation>(%1898#0, %cst_1122) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1123 = arith.constant 1.5707963267948966 : f64
    %1900 = qlx.apply #qlx.action<pauli_rotation>(%1898#1, %cst_1123) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1124 = arith.constant 1.5707963267948966 : f64
    %1901:2 = qlx.apply #qlx.action<pauli_rotation>(%1899, %1900, %cst_1124) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1902 = qlx.apply #qlx.action<h>(%1651#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1125 = arith.constant 2.3561944901923448 : f64
    %1903 = qlx.apply #qlx.action<pauli_rotation>(%1902, %cst_1125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1904 = qlx.apply #qlx.action<h>(%1903) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1905 = qlx.apply #qlx.action<h>(%1901#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1126 = arith.constant 3.1415926535897931 : f64
    %1906 = qlx.apply #qlx.action<pauli_rotation>(%1905, %cst_1126) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1907 = qlx.apply #qlx.action<h>(%1906) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1127 = arith.constant 1.5707963267948966 : f64
    %1908:2 = qlx.apply #qlx.action<pauli_rotation>(%1904, %1907, %cst_1127) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1128 = arith.constant 1.5707963267948966 : f64
    %1909 = qlx.apply #qlx.action<pauli_rotation>(%1908#0, %cst_1128) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1129 = arith.constant 1.5707963267948966 : f64
    %1910 = qlx.apply #qlx.action<pauli_rotation>(%1908#1, %cst_1129) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1130 = arith.constant 1.5707963267948966 : f64
    %1911:2 = qlx.apply #qlx.action<pauli_rotation>(%1909, %1910, %cst_1130) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1912 = qlx.apply #qlx.action<h>(%1661#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1131 = arith.constant 3.1415926535897931 : f64
    %1913 = qlx.apply #qlx.action<pauli_rotation>(%1912, %cst_1131) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1914 = qlx.apply #qlx.action<h>(%1913) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1915 = qlx.apply #qlx.action<h>(%1911#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1132 = arith.constant 3.1415926535897931 : f64
    %1916 = qlx.apply #qlx.action<pauli_rotation>(%1915, %cst_1132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1917 = qlx.apply #qlx.action<h>(%1916) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1133 = arith.constant 1.5707963267948966 : f64
    %1918:2 = qlx.apply #qlx.action<pauli_rotation>(%1914, %1917, %cst_1133) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1134 = arith.constant 1.5707963267948966 : f64
    %1919 = qlx.apply #qlx.action<pauli_rotation>(%1918#0, %cst_1134) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1135 = arith.constant 1.5707963267948966 : f64
    %1920 = qlx.apply #qlx.action<pauli_rotation>(%1918#1, %cst_1135) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1136 = arith.constant 1.5707963267948966 : f64
    %1921:2 = qlx.apply #qlx.action<pauli_rotation>(%1919, %1920, %cst_1136) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1922 = qlx.apply #qlx.action<h>(%1671#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1137 = arith.constant 3.1415926535897931 : f64
    %1923 = qlx.apply #qlx.action<pauli_rotation>(%1922, %cst_1137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1924 = qlx.apply #qlx.action<h>(%1923) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1925 = qlx.apply #qlx.action<h>(%1921#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1138 = arith.constant 3.1415926535897931 : f64
    %1926 = qlx.apply #qlx.action<pauli_rotation>(%1925, %cst_1138) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1927 = qlx.apply #qlx.action<h>(%1926) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1139 = arith.constant 1.5707963267948966 : f64
    %1928:2 = qlx.apply #qlx.action<pauli_rotation>(%1924, %1927, %cst_1139) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1140 = arith.constant 1.5707963267948966 : f64
    %1929 = qlx.apply #qlx.action<pauli_rotation>(%1928#0, %cst_1140) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1141 = arith.constant 1.5707963267948966 : f64
    %1930 = qlx.apply #qlx.action<pauli_rotation>(%1928#1, %cst_1141) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1142 = arith.constant 1.5707963267948966 : f64
    %1931:2 = qlx.apply #qlx.action<pauli_rotation>(%1929, %1930, %cst_1142) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1932 = qlx.apply #qlx.action<h>(%1681#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1143 = arith.constant 3.1415926535897931 : f64
    %1933 = qlx.apply #qlx.action<pauli_rotation>(%1932, %cst_1143) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1934 = qlx.apply #qlx.action<h>(%1933) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1935 = qlx.apply #qlx.action<h>(%1931#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1144 = arith.constant 3.1415926535897931 : f64
    %1936 = qlx.apply #qlx.action<pauli_rotation>(%1935, %cst_1144) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1937 = qlx.apply #qlx.action<h>(%1936) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1145 = arith.constant 1.5707963267948966 : f64
    %1938:2 = qlx.apply #qlx.action<pauli_rotation>(%1934, %1937, %cst_1145) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1146 = arith.constant 1.5707963267948966 : f64
    %1939 = qlx.apply #qlx.action<pauli_rotation>(%1938#0, %cst_1146) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1147 = arith.constant 1.5707963267948966 : f64
    %1940 = qlx.apply #qlx.action<pauli_rotation>(%1938#1, %cst_1147) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1148 = arith.constant 1.5707963267948966 : f64
    %1941:2 = qlx.apply #qlx.action<pauli_rotation>(%1939, %1940, %cst_1148) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1942 = qlx.apply #qlx.action<h>(%1691#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1149 = arith.constant 3.1415926535897931 : f64
    %1943 = qlx.apply #qlx.action<pauli_rotation>(%1942, %cst_1149) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1944 = qlx.apply #qlx.action<h>(%1943) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1945 = qlx.apply #qlx.action<h>(%1941#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1150 = arith.constant 3.1415926535897931 : f64
    %1946 = qlx.apply #qlx.action<pauli_rotation>(%1945, %cst_1150) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1947 = qlx.apply #qlx.action<h>(%1946) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1151 = arith.constant 1.5707963267948966 : f64
    %1948:2 = qlx.apply #qlx.action<pauli_rotation>(%1944, %1947, %cst_1151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1152 = arith.constant 1.5707963267948966 : f64
    %1949 = qlx.apply #qlx.action<pauli_rotation>(%1948#0, %cst_1152) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1153 = arith.constant 1.5707963267948966 : f64
    %1950 = qlx.apply #qlx.action<pauli_rotation>(%1948#1, %cst_1153) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1154 = arith.constant 1.5707963267948966 : f64
    %1951:2 = qlx.apply #qlx.action<pauli_rotation>(%1949, %1950, %cst_1154) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1952 = qlx.apply #qlx.action<h>(%1701#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1155 = arith.constant 3.1415926535897931 : f64
    %1953 = qlx.apply #qlx.action<pauli_rotation>(%1952, %cst_1155) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1954 = qlx.apply #qlx.action<h>(%1953) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1955 = qlx.apply #qlx.action<h>(%1951#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1156 = arith.constant 3.1415926535897931 : f64
    %1956 = qlx.apply #qlx.action<pauli_rotation>(%1955, %cst_1156) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1957 = qlx.apply #qlx.action<h>(%1956) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1157 = arith.constant 1.5707963267948966 : f64
    %1958:2 = qlx.apply #qlx.action<pauli_rotation>(%1954, %1957, %cst_1157) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1158 = arith.constant 1.5707963267948966 : f64
    %1959 = qlx.apply #qlx.action<pauli_rotation>(%1958#0, %cst_1158) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1159 = arith.constant 1.5707963267948966 : f64
    %1960 = qlx.apply #qlx.action<pauli_rotation>(%1958#1, %cst_1159) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1160 = arith.constant 1.5707963267948966 : f64
    %1961:2 = qlx.apply #qlx.action<pauli_rotation>(%1959, %1960, %cst_1160) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1962 = qlx.apply #qlx.action<h>(%1711#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1161 = arith.constant 3.1415926535897931 : f64
    %1963 = qlx.apply #qlx.action<pauli_rotation>(%1962, %cst_1161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1964 = qlx.apply #qlx.action<h>(%1963) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1965 = qlx.apply #qlx.action<h>(%1961#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1162 = arith.constant 3.1415926535897931 : f64
    %1966 = qlx.apply #qlx.action<pauli_rotation>(%1965, %cst_1162) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1967 = qlx.apply #qlx.action<h>(%1966) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1163 = arith.constant 1.5707963267948966 : f64
    %1968:2 = qlx.apply #qlx.action<pauli_rotation>(%1964, %1967, %cst_1163) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1164 = arith.constant 1.5707963267948966 : f64
    %1969 = qlx.apply #qlx.action<pauli_rotation>(%1968#0, %cst_1164) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1165 = arith.constant 1.5707963267948966 : f64
    %1970 = qlx.apply #qlx.action<pauli_rotation>(%1968#1, %cst_1165) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1166 = arith.constant 1.5707963267948966 : f64
    %1971:2 = qlx.apply #qlx.action<pauli_rotation>(%1969, %1970, %cst_1166) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1972 = qlx.apply #qlx.action<h>(%1721#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1167 = arith.constant 2.3561944901923448 : f64
    %1973 = qlx.apply #qlx.action<pauli_rotation>(%1972, %cst_1167) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1974 = qlx.apply #qlx.action<h>(%1973) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1975 = qlx.apply #qlx.action<h>(%1971#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1168 = arith.constant 2.3561944901923448 : f64
    %1976 = qlx.apply #qlx.action<pauli_rotation>(%1975, %cst_1168) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1977 = qlx.apply #qlx.action<h>(%1976) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1169 = arith.constant 0.78539816339744828 : f64
    %1978:2 = qlx.apply #qlx.action<pauli_rotation>(%1974, %1977, %cst_1169) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1170 = arith.constant 1.5707963267948966 : f64
    %1979 = qlx.apply #qlx.action<pauli_rotation>(%1978#0, %cst_1170) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1171 = arith.constant 1.5707963267948966 : f64
    %1980 = qlx.apply #qlx.action<pauli_rotation>(%1978#1, %cst_1171) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1172 = arith.constant 0.78539816339744828 : f64
    %1981:2 = qlx.apply #qlx.action<pauli_rotation>(%1979, %1980, %cst_1172) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1982 = qlx.apply #qlx.action<h>(%1821#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1173 = arith.constant 3.1415926535897931 : f64
    %1983 = qlx.apply #qlx.action<pauli_rotation>(%1982, %cst_1173) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1984 = qlx.apply #qlx.action<h>(%1983) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1985 = qlx.apply #qlx.action<h>(%1811#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1174 = arith.constant 3.1415926535897931 : f64
    %1986 = qlx.apply #qlx.action<pauli_rotation>(%1985, %cst_1174) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1987 = qlx.apply #qlx.action<h>(%1986) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1175 = arith.constant 1.5707963267948966 : f64
    %1988:2 = qlx.apply #qlx.action<pauli_rotation>(%1984, %1987, %cst_1175) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1176 = arith.constant 1.5707963267948966 : f64
    %1989 = qlx.apply #qlx.action<pauli_rotation>(%1988#0, %cst_1176) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1177 = arith.constant 1.5707963267948966 : f64
    %1990 = qlx.apply #qlx.action<pauli_rotation>(%1988#1, %cst_1177) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1178 = arith.constant 1.5707963267948966 : f64
    %1991:2 = qlx.apply #qlx.action<pauli_rotation>(%1989, %1990, %cst_1178) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1992 = qlx.apply #qlx.action<h>(%1831#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1179 = arith.constant 3.1415926535897931 : f64
    %1993 = qlx.apply #qlx.action<pauli_rotation>(%1992, %cst_1179) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1994 = qlx.apply #qlx.action<h>(%1993) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1995 = qlx.apply #qlx.action<h>(%1991#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1180 = arith.constant 3.1415926535897931 : f64
    %1996 = qlx.apply #qlx.action<pauli_rotation>(%1995, %cst_1180) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1997 = qlx.apply #qlx.action<h>(%1996) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1181 = arith.constant 1.5707963267948966 : f64
    %1998:2 = qlx.apply #qlx.action<pauli_rotation>(%1994, %1997, %cst_1181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1182 = arith.constant 1.5707963267948966 : f64
    %1999 = qlx.apply #qlx.action<pauli_rotation>(%1998#0, %cst_1182) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1183 = arith.constant 1.5707963267948966 : f64
    %2000 = qlx.apply #qlx.action<pauli_rotation>(%1998#1, %cst_1183) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1184 = arith.constant 1.5707963267948966 : f64
    %2001:2 = qlx.apply #qlx.action<pauli_rotation>(%1999, %2000, %cst_1184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2002 = qlx.apply #qlx.action<h>(%1841#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1185 = arith.constant 3.1415926535897931 : f64
    %2003 = qlx.apply #qlx.action<pauli_rotation>(%2002, %cst_1185) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2004 = qlx.apply #qlx.action<h>(%2003) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2005 = qlx.apply #qlx.action<h>(%2001#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1186 = arith.constant 3.1415926535897931 : f64
    %2006 = qlx.apply #qlx.action<pauli_rotation>(%2005, %cst_1186) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2007 = qlx.apply #qlx.action<h>(%2006) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1187 = arith.constant 1.5707963267948966 : f64
    %2008:2 = qlx.apply #qlx.action<pauli_rotation>(%2004, %2007, %cst_1187) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1188 = arith.constant 1.5707963267948966 : f64
    %2009 = qlx.apply #qlx.action<pauli_rotation>(%2008#0, %cst_1188) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1189 = arith.constant 1.5707963267948966 : f64
    %2010 = qlx.apply #qlx.action<pauli_rotation>(%2008#1, %cst_1189) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1190 = arith.constant 1.5707963267948966 : f64
    %2011:2 = qlx.apply #qlx.action<pauli_rotation>(%2009, %2010, %cst_1190) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2012 = qlx.apply #qlx.action<h>(%1851#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1191 = arith.constant 3.1415926535897931 : f64
    %2013 = qlx.apply #qlx.action<pauli_rotation>(%2012, %cst_1191) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2014 = qlx.apply #qlx.action<h>(%2013) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2015 = qlx.apply #qlx.action<h>(%2011#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1192 = arith.constant 3.1415926535897931 : f64
    %2016 = qlx.apply #qlx.action<pauli_rotation>(%2015, %cst_1192) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2017 = qlx.apply #qlx.action<h>(%2016) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1193 = arith.constant 1.5707963267948966 : f64
    %2018:2 = qlx.apply #qlx.action<pauli_rotation>(%2014, %2017, %cst_1193) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1194 = arith.constant 1.5707963267948966 : f64
    %2019 = qlx.apply #qlx.action<pauli_rotation>(%2018#0, %cst_1194) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1195 = arith.constant 1.5707963267948966 : f64
    %2020 = qlx.apply #qlx.action<pauli_rotation>(%2018#1, %cst_1195) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1196 = arith.constant 1.5707963267948966 : f64
    %2021:2 = qlx.apply #qlx.action<pauli_rotation>(%2019, %2020, %cst_1196) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2022 = qlx.apply #qlx.action<h>(%1861#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1197 = arith.constant 3.1415926535897931 : f64
    %2023 = qlx.apply #qlx.action<pauli_rotation>(%2022, %cst_1197) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2024 = qlx.apply #qlx.action<h>(%2023) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2025 = qlx.apply #qlx.action<h>(%2021#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1198 = arith.constant 3.1415926535897931 : f64
    %2026 = qlx.apply #qlx.action<pauli_rotation>(%2025, %cst_1198) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2027 = qlx.apply #qlx.action<h>(%2026) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1199 = arith.constant 1.5707963267948966 : f64
    %2028:2 = qlx.apply #qlx.action<pauli_rotation>(%2024, %2027, %cst_1199) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1200 = arith.constant 1.5707963267948966 : f64
    %2029 = qlx.apply #qlx.action<pauli_rotation>(%2028#0, %cst_1200) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1201 = arith.constant 1.5707963267948966 : f64
    %2030 = qlx.apply #qlx.action<pauli_rotation>(%2028#1, %cst_1201) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1202 = arith.constant 1.5707963267948966 : f64
    %2031:2 = qlx.apply #qlx.action<pauli_rotation>(%2029, %2030, %cst_1202) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2032 = qlx.apply #qlx.action<h>(%1871#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1203 = arith.constant 2.3561944901923448 : f64
    %2033 = qlx.apply #qlx.action<pauli_rotation>(%2032, %cst_1203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2034 = qlx.apply #qlx.action<h>(%2033) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2035 = qlx.apply #qlx.action<h>(%2031#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1204 = arith.constant 2.3561944901923448 : f64
    %2036 = qlx.apply #qlx.action<pauli_rotation>(%2035, %cst_1204) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2037 = qlx.apply #qlx.action<h>(%2036) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1205 = arith.constant 0.78539816339744828 : f64
    %2038:2 = qlx.apply #qlx.action<pauli_rotation>(%2034, %2037, %cst_1205) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1206 = arith.constant 1.5707963267948966 : f64
    %2039 = qlx.apply #qlx.action<pauli_rotation>(%2038#0, %cst_1206) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1207 = arith.constant 1.5707963267948966 : f64
    %2040 = qlx.apply #qlx.action<pauli_rotation>(%2038#1, %cst_1207) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1208 = arith.constant 0.78539816339744828 : f64
    %2041:2 = qlx.apply #qlx.action<pauli_rotation>(%2039, %2040, %cst_1208) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2042 = qlx.apply #qlx.action<h>(%1881#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1209 = arith.constant 3.1415926535897931 : f64
    %2043 = qlx.apply #qlx.action<pauli_rotation>(%2042, %cst_1209) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2044 = qlx.apply #qlx.action<h>(%2043) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2045 = qlx.apply #qlx.action<h>(%2041#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1210 = arith.constant 2.3561944901923448 : f64
    %2046 = qlx.apply #qlx.action<pauli_rotation>(%2045, %cst_1210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2047 = qlx.apply #qlx.action<h>(%2046) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1211 = arith.constant 1.5707963267948966 : f64
    %2048:2 = qlx.apply #qlx.action<pauli_rotation>(%2044, %2047, %cst_1211) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1212 = arith.constant 1.5707963267948966 : f64
    %2049 = qlx.apply #qlx.action<pauli_rotation>(%2048#0, %cst_1212) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1213 = arith.constant 1.5707963267948966 : f64
    %2050 = qlx.apply #qlx.action<pauli_rotation>(%2048#1, %cst_1213) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1214 = arith.constant 1.5707963267948966 : f64
    %2051:2 = qlx.apply #qlx.action<pauli_rotation>(%2049, %2050, %cst_1214) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2052 = qlx.apply #qlx.action<h>(%1891#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1215 = arith.constant 3.1415926535897931 : f64
    %2053 = qlx.apply #qlx.action<pauli_rotation>(%2052, %cst_1215) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2054 = qlx.apply #qlx.action<h>(%2053) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2055 = qlx.apply #qlx.action<h>(%2051#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1216 = arith.constant 3.1415926535897931 : f64
    %2056 = qlx.apply #qlx.action<pauli_rotation>(%2055, %cst_1216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2057 = qlx.apply #qlx.action<h>(%2056) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1217 = arith.constant 1.5707963267948966 : f64
    %2058:2 = qlx.apply #qlx.action<pauli_rotation>(%2054, %2057, %cst_1217) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1218 = arith.constant 1.5707963267948966 : f64
    %2059 = qlx.apply #qlx.action<pauli_rotation>(%2058#0, %cst_1218) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1219 = arith.constant 1.5707963267948966 : f64
    %2060 = qlx.apply #qlx.action<pauli_rotation>(%2058#1, %cst_1219) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1220 = arith.constant 1.5707963267948966 : f64
    %2061:2 = qlx.apply #qlx.action<pauli_rotation>(%2059, %2060, %cst_1220) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2062 = qlx.apply #qlx.action<h>(%1901#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1221 = arith.constant 3.1415926535897931 : f64
    %2063 = qlx.apply #qlx.action<pauli_rotation>(%2062, %cst_1221) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2064 = qlx.apply #qlx.action<h>(%2063) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2065 = qlx.apply #qlx.action<h>(%2061#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1222 = arith.constant 3.1415926535897931 : f64
    %2066 = qlx.apply #qlx.action<pauli_rotation>(%2065, %cst_1222) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2067 = qlx.apply #qlx.action<h>(%2066) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1223 = arith.constant 1.5707963267948966 : f64
    %2068:2 = qlx.apply #qlx.action<pauli_rotation>(%2064, %2067, %cst_1223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1224 = arith.constant 1.5707963267948966 : f64
    %2069 = qlx.apply #qlx.action<pauli_rotation>(%2068#0, %cst_1224) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1225 = arith.constant 1.5707963267948966 : f64
    %2070 = qlx.apply #qlx.action<pauli_rotation>(%2068#1, %cst_1225) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1226 = arith.constant 1.5707963267948966 : f64
    %2071:2 = qlx.apply #qlx.action<pauli_rotation>(%2069, %2070, %cst_1226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2072 = qlx.apply #qlx.action<h>(%1911#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1227 = arith.constant 3.1415926535897931 : f64
    %2073 = qlx.apply #qlx.action<pauli_rotation>(%2072, %cst_1227) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2074 = qlx.apply #qlx.action<h>(%2073) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2075 = qlx.apply #qlx.action<h>(%2071#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1228 = arith.constant 3.1415926535897931 : f64
    %2076 = qlx.apply #qlx.action<pauli_rotation>(%2075, %cst_1228) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2077 = qlx.apply #qlx.action<h>(%2076) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1229 = arith.constant 1.5707963267948966 : f64
    %2078:2 = qlx.apply #qlx.action<pauli_rotation>(%2074, %2077, %cst_1229) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1230 = arith.constant 1.5707963267948966 : f64
    %2079 = qlx.apply #qlx.action<pauli_rotation>(%2078#0, %cst_1230) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1231 = arith.constant 1.5707963267948966 : f64
    %2080 = qlx.apply #qlx.action<pauli_rotation>(%2078#1, %cst_1231) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1232 = arith.constant 1.5707963267948966 : f64
    %2081:2 = qlx.apply #qlx.action<pauli_rotation>(%2079, %2080, %cst_1232) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2082 = qlx.apply #qlx.action<h>(%1921#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1233 = arith.constant 3.1415926535897931 : f64
    %2083 = qlx.apply #qlx.action<pauli_rotation>(%2082, %cst_1233) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2084 = qlx.apply #qlx.action<h>(%2083) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2085 = qlx.apply #qlx.action<h>(%2081#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1234 = arith.constant 3.1415926535897931 : f64
    %2086 = qlx.apply #qlx.action<pauli_rotation>(%2085, %cst_1234) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2087 = qlx.apply #qlx.action<h>(%2086) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1235 = arith.constant 1.5707963267948966 : f64
    %2088:2 = qlx.apply #qlx.action<pauli_rotation>(%2084, %2087, %cst_1235) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1236 = arith.constant 1.5707963267948966 : f64
    %2089 = qlx.apply #qlx.action<pauli_rotation>(%2088#0, %cst_1236) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1237 = arith.constant 1.5707963267948966 : f64
    %2090 = qlx.apply #qlx.action<pauli_rotation>(%2088#1, %cst_1237) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1238 = arith.constant 1.5707963267948966 : f64
    %2091:2 = qlx.apply #qlx.action<pauli_rotation>(%2089, %2090, %cst_1238) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2092 = qlx.apply #qlx.action<h>(%1931#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1239 = arith.constant 3.1415926535897931 : f64
    %2093 = qlx.apply #qlx.action<pauli_rotation>(%2092, %cst_1239) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2094 = qlx.apply #qlx.action<h>(%2093) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2095 = qlx.apply #qlx.action<h>(%2091#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1240 = arith.constant 3.1415926535897931 : f64
    %2096 = qlx.apply #qlx.action<pauli_rotation>(%2095, %cst_1240) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2097 = qlx.apply #qlx.action<h>(%2096) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1241 = arith.constant 1.5707963267948966 : f64
    %2098:2 = qlx.apply #qlx.action<pauli_rotation>(%2094, %2097, %cst_1241) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1242 = arith.constant 1.5707963267948966 : f64
    %2099 = qlx.apply #qlx.action<pauli_rotation>(%2098#0, %cst_1242) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1243 = arith.constant 1.5707963267948966 : f64
    %2100 = qlx.apply #qlx.action<pauli_rotation>(%2098#1, %cst_1243) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1244 = arith.constant 1.5707963267948966 : f64
    %2101:2 = qlx.apply #qlx.action<pauli_rotation>(%2099, %2100, %cst_1244) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2102 = qlx.apply #qlx.action<h>(%1941#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1245 = arith.constant 3.1415926535897931 : f64
    %2103 = qlx.apply #qlx.action<pauli_rotation>(%2102, %cst_1245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2104 = qlx.apply #qlx.action<h>(%2103) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2105 = qlx.apply #qlx.action<h>(%2101#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1246 = arith.constant 3.1415926535897931 : f64
    %2106 = qlx.apply #qlx.action<pauli_rotation>(%2105, %cst_1246) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2107 = qlx.apply #qlx.action<h>(%2106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1247 = arith.constant 1.5707963267948966 : f64
    %2108:2 = qlx.apply #qlx.action<pauli_rotation>(%2104, %2107, %cst_1247) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1248 = arith.constant 1.5707963267948966 : f64
    %2109 = qlx.apply #qlx.action<pauli_rotation>(%2108#0, %cst_1248) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1249 = arith.constant 1.5707963267948966 : f64
    %2110 = qlx.apply #qlx.action<pauli_rotation>(%2108#1, %cst_1249) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1250 = arith.constant 1.5707963267948966 : f64
    %2111:2 = qlx.apply #qlx.action<pauli_rotation>(%2109, %2110, %cst_1250) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2112 = qlx.apply #qlx.action<h>(%1951#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1251 = arith.constant 3.1415926535897931 : f64
    %2113 = qlx.apply #qlx.action<pauli_rotation>(%2112, %cst_1251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2114 = qlx.apply #qlx.action<h>(%2113) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2115 = qlx.apply #qlx.action<h>(%2111#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1252 = arith.constant 3.1415926535897931 : f64
    %2116 = qlx.apply #qlx.action<pauli_rotation>(%2115, %cst_1252) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2117 = qlx.apply #qlx.action<h>(%2116) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1253 = arith.constant 1.5707963267948966 : f64
    %2118:2 = qlx.apply #qlx.action<pauli_rotation>(%2114, %2117, %cst_1253) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1254 = arith.constant 1.5707963267948966 : f64
    %2119 = qlx.apply #qlx.action<pauli_rotation>(%2118#0, %cst_1254) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1255 = arith.constant 1.5707963267948966 : f64
    %2120 = qlx.apply #qlx.action<pauli_rotation>(%2118#1, %cst_1255) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1256 = arith.constant 1.5707963267948966 : f64
    %2121:2 = qlx.apply #qlx.action<pauli_rotation>(%2119, %2120, %cst_1256) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2122 = qlx.apply #qlx.action<h>(%1961#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1257 = arith.constant 3.1415926535897931 : f64
    %2123 = qlx.apply #qlx.action<pauli_rotation>(%2122, %cst_1257) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2124 = qlx.apply #qlx.action<h>(%2123) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2125 = qlx.apply #qlx.action<h>(%2121#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1258 = arith.constant 3.1415926535897931 : f64
    %2126 = qlx.apply #qlx.action<pauli_rotation>(%2125, %cst_1258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2127 = qlx.apply #qlx.action<h>(%2126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1259 = arith.constant 1.5707963267948966 : f64
    %2128:2 = qlx.apply #qlx.action<pauli_rotation>(%2124, %2127, %cst_1259) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1260 = arith.constant 1.5707963267948966 : f64
    %2129 = qlx.apply #qlx.action<pauli_rotation>(%2128#0, %cst_1260) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1261 = arith.constant 1.5707963267948966 : f64
    %2130 = qlx.apply #qlx.action<pauli_rotation>(%2128#1, %cst_1261) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1262 = arith.constant 1.5707963267948966 : f64
    %2131:2 = qlx.apply #qlx.action<pauli_rotation>(%2129, %2130, %cst_1262) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2132 = qlx.apply #qlx.action<h>(%1971#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1263 = arith.constant 3.1415926535897931 : f64
    %2133 = qlx.apply #qlx.action<pauli_rotation>(%2132, %cst_1263) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2134 = qlx.apply #qlx.action<h>(%2133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2135 = qlx.apply #qlx.action<h>(%2131#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1264 = arith.constant 3.1415926535897931 : f64
    %2136 = qlx.apply #qlx.action<pauli_rotation>(%2135, %cst_1264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2137 = qlx.apply #qlx.action<h>(%2136) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1265 = arith.constant 1.5707963267948966 : f64
    %2138:2 = qlx.apply #qlx.action<pauli_rotation>(%2134, %2137, %cst_1265) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1266 = arith.constant 1.5707963267948966 : f64
    %2139 = qlx.apply #qlx.action<pauli_rotation>(%2138#0, %cst_1266) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1267 = arith.constant 1.5707963267948966 : f64
    %2140 = qlx.apply #qlx.action<pauli_rotation>(%2138#1, %cst_1267) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1268 = arith.constant 1.5707963267948966 : f64
    %2141:2 = qlx.apply #qlx.action<pauli_rotation>(%2139, %2140, %cst_1268) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2142 = qlx.apply #qlx.action<h>(%1981#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1269 = arith.constant 2.3561944901923448 : f64
    %2143 = qlx.apply #qlx.action<pauli_rotation>(%2142, %cst_1269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2144 = qlx.apply #qlx.action<h>(%2143) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2145 = qlx.apply #qlx.action<h>(%2141#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1270 = arith.constant 3.1415926535897931 : f64
    %2146 = qlx.apply #qlx.action<pauli_rotation>(%2145, %cst_1270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2147 = qlx.apply #qlx.action<h>(%2146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1271 = arith.constant 1.1415926535897931 : f64
    %2148:2 = qlx.apply #qlx.action<pauli_rotation>(%2144, %2147, %cst_1271) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1272 = arith.constant 1.5707963267948966 : f64
    %2149 = qlx.apply #qlx.action<pauli_rotation>(%2148#0, %cst_1272) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1273 = arith.constant 1.5707963267948966 : f64
    %2150 = qlx.apply #qlx.action<pauli_rotation>(%2148#1, %cst_1273) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1274 = arith.constant 1.1415926535897931 : f64
    %2151:2 = qlx.apply #qlx.action<pauli_rotation>(%2149, %2150, %cst_1274) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2152 = qlx.apply #qlx.action<h>(%1981#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1275 = arith.constant 1.5707963267948966 : f64
    %2153 = qlx.apply #qlx.action<pauli_rotation>(%2152, %cst_1275) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2154 = qlx.apply #qlx.action<h>(%2153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2155 = qlx.apply #qlx.action<h>(%2151#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1276 = arith.constant 2.3561944901923448 : f64
    %2156 = qlx.apply #qlx.action<pauli_rotation>(%2155, %cst_1276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2157 = qlx.apply #qlx.action<h>(%2156) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1277 = arith.constant 0.78539816339744828 : f64
    %2158:2 = qlx.apply #qlx.action<pauli_rotation>(%2154, %2157, %cst_1277) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1278 = arith.constant 1.5707963267948966 : f64
    %2159 = qlx.apply #qlx.action<pauli_rotation>(%2158#0, %cst_1278) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1279 = arith.constant 1.5707963267948966 : f64
    %2160 = qlx.apply #qlx.action<pauli_rotation>(%2158#1, %cst_1279) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1280 = arith.constant 0.78539816339744828 : f64
    %2161:2 = qlx.apply #qlx.action<pauli_rotation>(%2159, %2160, %cst_1280) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2162 = qlx.apply #qlx.action<h>(%1791#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1281 = arith.constant 3.1415926535897931 : f64
    %2163 = qlx.apply #qlx.action<pauli_rotation>(%2162, %cst_1281) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2164 = qlx.apply #qlx.action<h>(%2163) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2165 = qlx.apply #qlx.action<h>(%1781#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1282 = arith.constant 3.1415926535897931 : f64
    %2166 = qlx.apply #qlx.action<pauli_rotation>(%2165, %cst_1282) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2167 = qlx.apply #qlx.action<h>(%2166) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1283 = arith.constant 1.5707963267948966 : f64
    %2168:2 = qlx.apply #qlx.action<pauli_rotation>(%2164, %2167, %cst_1283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1284 = arith.constant 1.5707963267948966 : f64
    %2169 = qlx.apply #qlx.action<pauli_rotation>(%2168#0, %cst_1284) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1285 = arith.constant 1.5707963267948966 : f64
    %2170 = qlx.apply #qlx.action<pauli_rotation>(%2168#1, %cst_1285) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1286 = arith.constant 1.5707963267948966 : f64
    %2171:2 = qlx.apply #qlx.action<pauli_rotation>(%2169, %2170, %cst_1286) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2172 = qlx.apply #qlx.action<h>(%1801#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1287 = arith.constant 3.1415926535897931 : f64
    %2173 = qlx.apply #qlx.action<pauli_rotation>(%2172, %cst_1287) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2174 = qlx.apply #qlx.action<h>(%2173) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2175 = qlx.apply #qlx.action<h>(%2171#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1288 = arith.constant 3.1415926535897931 : f64
    %2176 = qlx.apply #qlx.action<pauli_rotation>(%2175, %cst_1288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2177 = qlx.apply #qlx.action<h>(%2176) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1289 = arith.constant 1.5707963267948966 : f64
    %2178:2 = qlx.apply #qlx.action<pauli_rotation>(%2174, %2177, %cst_1289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1290 = arith.constant 1.5707963267948966 : f64
    %2179 = qlx.apply #qlx.action<pauli_rotation>(%2178#0, %cst_1290) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1291 = arith.constant 1.5707963267948966 : f64
    %2180 = qlx.apply #qlx.action<pauli_rotation>(%2178#1, %cst_1291) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1292 = arith.constant 1.5707963267948966 : f64
    %2181:2 = qlx.apply #qlx.action<pauli_rotation>(%2179, %2180, %cst_1292) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2182 = qlx.apply #qlx.action<h>(%1991#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1293 = arith.constant 3.1415926535897931 : f64
    %2183 = qlx.apply #qlx.action<pauli_rotation>(%2182, %cst_1293) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2184 = qlx.apply #qlx.action<h>(%2183) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2185 = qlx.apply #qlx.action<h>(%2181#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1294 = arith.constant 3.1415926535897931 : f64
    %2186 = qlx.apply #qlx.action<pauli_rotation>(%2185, %cst_1294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2187 = qlx.apply #qlx.action<h>(%2186) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1295 = arith.constant 1.5707963267948966 : f64
    %2188:2 = qlx.apply #qlx.action<pauli_rotation>(%2184, %2187, %cst_1295) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1296 = arith.constant 1.5707963267948966 : f64
    %2189 = qlx.apply #qlx.action<pauli_rotation>(%2188#0, %cst_1296) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1297 = arith.constant 1.5707963267948966 : f64
    %2190 = qlx.apply #qlx.action<pauli_rotation>(%2188#1, %cst_1297) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1298 = arith.constant 1.5707963267948966 : f64
    %2191:2 = qlx.apply #qlx.action<pauli_rotation>(%2189, %2190, %cst_1298) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2192 = qlx.apply #qlx.action<h>(%2001#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1299 = arith.constant 3.1415926535897931 : f64
    %2193 = qlx.apply #qlx.action<pauli_rotation>(%2192, %cst_1299) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2194 = qlx.apply #qlx.action<h>(%2193) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2195 = qlx.apply #qlx.action<h>(%2191#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1300 = arith.constant 3.1415926535897931 : f64
    %2196 = qlx.apply #qlx.action<pauli_rotation>(%2195, %cst_1300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2197 = qlx.apply #qlx.action<h>(%2196) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1301 = arith.constant 1.5707963267948966 : f64
    %2198:2 = qlx.apply #qlx.action<pauli_rotation>(%2194, %2197, %cst_1301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1302 = arith.constant 1.5707963267948966 : f64
    %2199 = qlx.apply #qlx.action<pauli_rotation>(%2198#0, %cst_1302) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1303 = arith.constant 1.5707963267948966 : f64
    %2200 = qlx.apply #qlx.action<pauli_rotation>(%2198#1, %cst_1303) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1304 = arith.constant 1.5707963267948966 : f64
    %2201:2 = qlx.apply #qlx.action<pauli_rotation>(%2199, %2200, %cst_1304) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2202 = qlx.apply #qlx.action<h>(%2011#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1305 = arith.constant 3.1415926535897931 : f64
    %2203 = qlx.apply #qlx.action<pauli_rotation>(%2202, %cst_1305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2204 = qlx.apply #qlx.action<h>(%2203) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2205 = qlx.apply #qlx.action<h>(%2201#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1306 = arith.constant 3.1415926535897931 : f64
    %2206 = qlx.apply #qlx.action<pauli_rotation>(%2205, %cst_1306) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2207 = qlx.apply #qlx.action<h>(%2206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1307 = arith.constant 1.5707963267948966 : f64
    %2208:2 = qlx.apply #qlx.action<pauli_rotation>(%2204, %2207, %cst_1307) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1308 = arith.constant 1.5707963267948966 : f64
    %2209 = qlx.apply #qlx.action<pauli_rotation>(%2208#0, %cst_1308) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1309 = arith.constant 1.5707963267948966 : f64
    %2210 = qlx.apply #qlx.action<pauli_rotation>(%2208#1, %cst_1309) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1310 = arith.constant 1.5707963267948966 : f64
    %2211:2 = qlx.apply #qlx.action<pauli_rotation>(%2209, %2210, %cst_1310) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2212 = qlx.apply #qlx.action<h>(%2021#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1311 = arith.constant 3.1415926535897931 : f64
    %2213 = qlx.apply #qlx.action<pauli_rotation>(%2212, %cst_1311) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2214 = qlx.apply #qlx.action<h>(%2213) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2215 = qlx.apply #qlx.action<h>(%2211#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1312 = arith.constant 3.1415926535897931 : f64
    %2216 = qlx.apply #qlx.action<pauli_rotation>(%2215, %cst_1312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2217 = qlx.apply #qlx.action<h>(%2216) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1313 = arith.constant 1.5707963267948966 : f64
    %2218:2 = qlx.apply #qlx.action<pauli_rotation>(%2214, %2217, %cst_1313) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1314 = arith.constant 1.5707963267948966 : f64
    %2219 = qlx.apply #qlx.action<pauli_rotation>(%2218#0, %cst_1314) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1315 = arith.constant 1.5707963267948966 : f64
    %2220 = qlx.apply #qlx.action<pauli_rotation>(%2218#1, %cst_1315) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1316 = arith.constant 1.5707963267948966 : f64
    %2221:2 = qlx.apply #qlx.action<pauli_rotation>(%2219, %2220, %cst_1316) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2222 = qlx.apply #qlx.action<h>(%2031#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1317 = arith.constant 3.1415926535897931 : f64
    %2223 = qlx.apply #qlx.action<pauli_rotation>(%2222, %cst_1317) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2224 = qlx.apply #qlx.action<h>(%2223) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2225 = qlx.apply #qlx.action<h>(%2221#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1318 = arith.constant 3.1415926535897931 : f64
    %2226 = qlx.apply #qlx.action<pauli_rotation>(%2225, %cst_1318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2227 = qlx.apply #qlx.action<h>(%2226) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1319 = arith.constant 1.5707963267948966 : f64
    %2228:2 = qlx.apply #qlx.action<pauli_rotation>(%2224, %2227, %cst_1319) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1320 = arith.constant 1.5707963267948966 : f64
    %2229 = qlx.apply #qlx.action<pauli_rotation>(%2228#0, %cst_1320) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1321 = arith.constant 1.5707963267948966 : f64
    %2230 = qlx.apply #qlx.action<pauli_rotation>(%2228#1, %cst_1321) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1322 = arith.constant 1.5707963267948966 : f64
    %2231:2 = qlx.apply #qlx.action<pauli_rotation>(%2229, %2230, %cst_1322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2232 = qlx.apply #qlx.action<h>(%2041#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1323 = arith.constant 2.3561944901923448 : f64
    %2233 = qlx.apply #qlx.action<pauli_rotation>(%2232, %cst_1323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2234 = qlx.apply #qlx.action<h>(%2233) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2235 = qlx.apply #qlx.action<h>(%2231#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1324 = arith.constant 3.1415926535897931 : f64
    %2236 = qlx.apply #qlx.action<pauli_rotation>(%2235, %cst_1324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2237 = qlx.apply #qlx.action<h>(%2236) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1325 = arith.constant 1.5707963267948966 : f64
    %2238:2 = qlx.apply #qlx.action<pauli_rotation>(%2234, %2237, %cst_1325) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1326 = arith.constant 1.5707963267948966 : f64
    %2239 = qlx.apply #qlx.action<pauli_rotation>(%2238#0, %cst_1326) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1327 = arith.constant 1.5707963267948966 : f64
    %2240 = qlx.apply #qlx.action<pauli_rotation>(%2238#1, %cst_1327) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1328 = arith.constant 1.5707963267948966 : f64
    %2241:2 = qlx.apply #qlx.action<pauli_rotation>(%2239, %2240, %cst_1328) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2242 = qlx.apply #qlx.action<h>(%2051#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1329 = arith.constant 3.1415926535897931 : f64
    %2243 = qlx.apply #qlx.action<pauli_rotation>(%2242, %cst_1329) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2244 = qlx.apply #qlx.action<h>(%2243) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2245 = qlx.apply #qlx.action<h>(%2241#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1330 = arith.constant 3.1415926535897931 : f64
    %2246 = qlx.apply #qlx.action<pauli_rotation>(%2245, %cst_1330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2247 = qlx.apply #qlx.action<h>(%2246) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1331 = arith.constant 1.5707963267948966 : f64
    %2248:2 = qlx.apply #qlx.action<pauli_rotation>(%2244, %2247, %cst_1331) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1332 = arith.constant 1.5707963267948966 : f64
    %2249 = qlx.apply #qlx.action<pauli_rotation>(%2248#0, %cst_1332) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1333 = arith.constant 1.5707963267948966 : f64
    %2250 = qlx.apply #qlx.action<pauli_rotation>(%2248#1, %cst_1333) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1334 = arith.constant 1.5707963267948966 : f64
    %2251:2 = qlx.apply #qlx.action<pauli_rotation>(%2249, %2250, %cst_1334) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2252 = qlx.apply #qlx.action<h>(%2061#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1335 = arith.constant 3.1415926535897931 : f64
    %2253 = qlx.apply #qlx.action<pauli_rotation>(%2252, %cst_1335) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2254 = qlx.apply #qlx.action<h>(%2253) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2255 = qlx.apply #qlx.action<h>(%2251#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1336 = arith.constant 3.1415926535897931 : f64
    %2256 = qlx.apply #qlx.action<pauli_rotation>(%2255, %cst_1336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2257 = qlx.apply #qlx.action<h>(%2256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1337 = arith.constant 1.5707963267948966 : f64
    %2258:2 = qlx.apply #qlx.action<pauli_rotation>(%2254, %2257, %cst_1337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1338 = arith.constant 1.5707963267948966 : f64
    %2259 = qlx.apply #qlx.action<pauli_rotation>(%2258#0, %cst_1338) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1339 = arith.constant 1.5707963267948966 : f64
    %2260 = qlx.apply #qlx.action<pauli_rotation>(%2258#1, %cst_1339) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1340 = arith.constant 1.5707963267948966 : f64
    %2261:2 = qlx.apply #qlx.action<pauli_rotation>(%2259, %2260, %cst_1340) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2262 = qlx.apply #qlx.action<h>(%2071#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1341 = arith.constant 3.1415926535897931 : f64
    %2263 = qlx.apply #qlx.action<pauli_rotation>(%2262, %cst_1341) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2264 = qlx.apply #qlx.action<h>(%2263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2265 = qlx.apply #qlx.action<h>(%2261#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1342 = arith.constant 3.1415926535897931 : f64
    %2266 = qlx.apply #qlx.action<pauli_rotation>(%2265, %cst_1342) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2267 = qlx.apply #qlx.action<h>(%2266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1343 = arith.constant 1.5707963267948966 : f64
    %2268:2 = qlx.apply #qlx.action<pauli_rotation>(%2264, %2267, %cst_1343) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1344 = arith.constant 1.5707963267948966 : f64
    %2269 = qlx.apply #qlx.action<pauli_rotation>(%2268#0, %cst_1344) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1345 = arith.constant 1.5707963267948966 : f64
    %2270 = qlx.apply #qlx.action<pauli_rotation>(%2268#1, %cst_1345) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1346 = arith.constant 1.5707963267948966 : f64
    %2271:2 = qlx.apply #qlx.action<pauli_rotation>(%2269, %2270, %cst_1346) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2272 = qlx.apply #qlx.action<h>(%2081#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1347 = arith.constant 3.1415926535897931 : f64
    %2273 = qlx.apply #qlx.action<pauli_rotation>(%2272, %cst_1347) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2274 = qlx.apply #qlx.action<h>(%2273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2275 = qlx.apply #qlx.action<h>(%2271#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1348 = arith.constant 3.1415926535897931 : f64
    %2276 = qlx.apply #qlx.action<pauli_rotation>(%2275, %cst_1348) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2277 = qlx.apply #qlx.action<h>(%2276) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1349 = arith.constant 1.5707963267948966 : f64
    %2278:2 = qlx.apply #qlx.action<pauli_rotation>(%2274, %2277, %cst_1349) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1350 = arith.constant 1.5707963267948966 : f64
    %2279 = qlx.apply #qlx.action<pauli_rotation>(%2278#0, %cst_1350) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1351 = arith.constant 1.5707963267948966 : f64
    %2280 = qlx.apply #qlx.action<pauli_rotation>(%2278#1, %cst_1351) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1352 = arith.constant 1.5707963267948966 : f64
    %2281:2 = qlx.apply #qlx.action<pauli_rotation>(%2279, %2280, %cst_1352) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2282 = qlx.apply #qlx.action<h>(%2091#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1353 = arith.constant 3.1415926535897931 : f64
    %2283 = qlx.apply #qlx.action<pauli_rotation>(%2282, %cst_1353) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2284 = qlx.apply #qlx.action<h>(%2283) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2285 = qlx.apply #qlx.action<h>(%2281#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1354 = arith.constant 3.1415926535897931 : f64
    %2286 = qlx.apply #qlx.action<pauli_rotation>(%2285, %cst_1354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2287 = qlx.apply #qlx.action<h>(%2286) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1355 = arith.constant 1.5707963267948966 : f64
    %2288:2 = qlx.apply #qlx.action<pauli_rotation>(%2284, %2287, %cst_1355) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1356 = arith.constant 1.5707963267948966 : f64
    %2289 = qlx.apply #qlx.action<pauli_rotation>(%2288#0, %cst_1356) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1357 = arith.constant 1.5707963267948966 : f64
    %2290 = qlx.apply #qlx.action<pauli_rotation>(%2288#1, %cst_1357) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1358 = arith.constant 1.5707963267948966 : f64
    %2291:2 = qlx.apply #qlx.action<pauli_rotation>(%2289, %2290, %cst_1358) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2292 = qlx.apply #qlx.action<h>(%2101#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1359 = arith.constant 1.5707963267948966 : f64
    %2293 = qlx.apply #qlx.action<pauli_rotation>(%2292, %cst_1359) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2294 = qlx.apply #qlx.action<h>(%2293) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2295 = qlx.apply #qlx.action<h>(%2291#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1360 = arith.constant 1.5707963267948966 : f64
    %2296 = qlx.apply #qlx.action<pauli_rotation>(%2295, %cst_1360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2297 = qlx.apply #qlx.action<h>(%2296) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1361 = arith.constant 1.000000e+00 : f64
    %2298:2 = qlx.apply #qlx.action<pauli_rotation>(%2294, %2297, %cst_1361) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1362 = arith.constant 1.5707963267948966 : f64
    %2299 = qlx.apply #qlx.action<pauli_rotation>(%2298#0, %cst_1362) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1363 = arith.constant 1.5707963267948966 : f64
    %2300 = qlx.apply #qlx.action<pauli_rotation>(%2298#1, %cst_1363) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1364 = arith.constant 1.000000e+00 : f64
    %2301:2 = qlx.apply #qlx.action<pauli_rotation>(%2299, %2300, %cst_1364) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2302 = qlx.apply #qlx.action<h>(%1341#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1365 = arith.constant 2.3561944901923448 : f64
    %2303 = qlx.apply #qlx.action<pauli_rotation>(%2302, %cst_1365) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2304 = qlx.apply #qlx.action<h>(%2303) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2305 = qlx.apply #qlx.action<h>(%1351#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1366 = arith.constant 2.3561944901923448 : f64
    %2306 = qlx.apply #qlx.action<pauli_rotation>(%2305, %cst_1366) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2307 = qlx.apply #qlx.action<h>(%2306) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1367 = arith.constant 1.5707963267948966 : f64
    %2308:2 = qlx.apply #qlx.action<pauli_rotation>(%2304, %2307, %cst_1367) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1368 = arith.constant 1.5707963267948966 : f64
    %2309 = qlx.apply #qlx.action<pauli_rotation>(%2308#0, %cst_1368) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1369 = arith.constant 1.5707963267948966 : f64
    %2310 = qlx.apply #qlx.action<pauli_rotation>(%2308#1, %cst_1369) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1370 = arith.constant 1.5707963267948966 : f64
    %2311:2 = qlx.apply #qlx.action<pauli_rotation>(%2309, %2310, %cst_1370) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2312 = qlx.apply #qlx.action<h>(%1771#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1371 = arith.constant 3.1415926535897931 : f64
    %2313 = qlx.apply #qlx.action<pauli_rotation>(%2312, %cst_1371) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2314 = qlx.apply #qlx.action<h>(%2313) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2315 = qlx.apply #qlx.action<h>(%2311#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1372 = arith.constant 3.1415926535897931 : f64
    %2316 = qlx.apply #qlx.action<pauli_rotation>(%2315, %cst_1372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2317 = qlx.apply #qlx.action<h>(%2316) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1373 = arith.constant 1.5707963267948966 : f64
    %2318:2 = qlx.apply #qlx.action<pauli_rotation>(%2314, %2317, %cst_1373) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1374 = arith.constant 1.5707963267948966 : f64
    %2319 = qlx.apply #qlx.action<pauli_rotation>(%2318#0, %cst_1374) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1375 = arith.constant 1.5707963267948966 : f64
    %2320 = qlx.apply #qlx.action<pauli_rotation>(%2318#1, %cst_1375) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1376 = arith.constant 1.5707963267948966 : f64
    %2321:2 = qlx.apply #qlx.action<pauli_rotation>(%2319, %2320, %cst_1376) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2322 = qlx.apply #qlx.action<h>(%2171#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1377 = arith.constant 3.1415926535897931 : f64
    %2323 = qlx.apply #qlx.action<pauli_rotation>(%2322, %cst_1377) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2324 = qlx.apply #qlx.action<h>(%2323) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2325 = qlx.apply #qlx.action<h>(%2321#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1378 = arith.constant 3.1415926535897931 : f64
    %2326 = qlx.apply #qlx.action<pauli_rotation>(%2325, %cst_1378) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2327 = qlx.apply #qlx.action<h>(%2326) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1379 = arith.constant 1.5707963267948966 : f64
    %2328:2 = qlx.apply #qlx.action<pauli_rotation>(%2324, %2327, %cst_1379) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1380 = arith.constant 1.5707963267948966 : f64
    %2329 = qlx.apply #qlx.action<pauli_rotation>(%2328#0, %cst_1380) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1381 = arith.constant 1.5707963267948966 : f64
    %2330 = qlx.apply #qlx.action<pauli_rotation>(%2328#1, %cst_1381) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1382 = arith.constant 1.5707963267948966 : f64
    %2331:2 = qlx.apply #qlx.action<pauli_rotation>(%2329, %2330, %cst_1382) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2332 = qlx.apply #qlx.action<h>(%2181#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1383 = arith.constant 3.1415926535897931 : f64
    %2333 = qlx.apply #qlx.action<pauli_rotation>(%2332, %cst_1383) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2334 = qlx.apply #qlx.action<h>(%2333) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2335 = qlx.apply #qlx.action<h>(%2331#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1384 = arith.constant 3.1415926535897931 : f64
    %2336 = qlx.apply #qlx.action<pauli_rotation>(%2335, %cst_1384) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2337 = qlx.apply #qlx.action<h>(%2336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1385 = arith.constant 1.5707963267948966 : f64
    %2338:2 = qlx.apply #qlx.action<pauli_rotation>(%2334, %2337, %cst_1385) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1386 = arith.constant 1.5707963267948966 : f64
    %2339 = qlx.apply #qlx.action<pauli_rotation>(%2338#0, %cst_1386) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1387 = arith.constant 1.5707963267948966 : f64
    %2340 = qlx.apply #qlx.action<pauli_rotation>(%2338#1, %cst_1387) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1388 = arith.constant 1.5707963267948966 : f64
    %2341:2 = qlx.apply #qlx.action<pauli_rotation>(%2339, %2340, %cst_1388) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2342 = qlx.apply #qlx.action<h>(%2191#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1389 = arith.constant 3.1415926535897931 : f64
    %2343 = qlx.apply #qlx.action<pauli_rotation>(%2342, %cst_1389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2344 = qlx.apply #qlx.action<h>(%2343) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2345 = qlx.apply #qlx.action<h>(%2341#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1390 = arith.constant 3.1415926535897931 : f64
    %2346 = qlx.apply #qlx.action<pauli_rotation>(%2345, %cst_1390) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2347 = qlx.apply #qlx.action<h>(%2346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1391 = arith.constant 1.5707963267948966 : f64
    %2348:2 = qlx.apply #qlx.action<pauli_rotation>(%2344, %2347, %cst_1391) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1392 = arith.constant 1.5707963267948966 : f64
    %2349 = qlx.apply #qlx.action<pauli_rotation>(%2348#0, %cst_1392) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1393 = arith.constant 1.5707963267948966 : f64
    %2350 = qlx.apply #qlx.action<pauli_rotation>(%2348#1, %cst_1393) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1394 = arith.constant 1.5707963267948966 : f64
    %2351:2 = qlx.apply #qlx.action<pauli_rotation>(%2349, %2350, %cst_1394) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2352 = qlx.apply #qlx.action<h>(%2201#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1395 = arith.constant 3.1415926535897931 : f64
    %2353 = qlx.apply #qlx.action<pauli_rotation>(%2352, %cst_1395) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2354 = qlx.apply #qlx.action<h>(%2353) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2355 = qlx.apply #qlx.action<h>(%2351#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1396 = arith.constant 3.1415926535897931 : f64
    %2356 = qlx.apply #qlx.action<pauli_rotation>(%2355, %cst_1396) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2357 = qlx.apply #qlx.action<h>(%2356) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1397 = arith.constant 1.5707963267948966 : f64
    %2358:2 = qlx.apply #qlx.action<pauli_rotation>(%2354, %2357, %cst_1397) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1398 = arith.constant 1.5707963267948966 : f64
    %2359 = qlx.apply #qlx.action<pauli_rotation>(%2358#0, %cst_1398) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1399 = arith.constant 1.5707963267948966 : f64
    %2360 = qlx.apply #qlx.action<pauli_rotation>(%2358#1, %cst_1399) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1400 = arith.constant 1.5707963267948966 : f64
    %2361:2 = qlx.apply #qlx.action<pauli_rotation>(%2359, %2360, %cst_1400) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2362 = qlx.apply #qlx.action<h>(%2211#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1401 = arith.constant 3.1415926535897931 : f64
    %2363 = qlx.apply #qlx.action<pauli_rotation>(%2362, %cst_1401) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2364 = qlx.apply #qlx.action<h>(%2363) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2365 = qlx.apply #qlx.action<h>(%2361#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1402 = arith.constant 3.1415926535897931 : f64
    %2366 = qlx.apply #qlx.action<pauli_rotation>(%2365, %cst_1402) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2367 = qlx.apply #qlx.action<h>(%2366) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1403 = arith.constant 1.5707963267948966 : f64
    %2368:2 = qlx.apply #qlx.action<pauli_rotation>(%2364, %2367, %cst_1403) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1404 = arith.constant 1.5707963267948966 : f64
    %2369 = qlx.apply #qlx.action<pauli_rotation>(%2368#0, %cst_1404) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1405 = arith.constant 1.5707963267948966 : f64
    %2370 = qlx.apply #qlx.action<pauli_rotation>(%2368#1, %cst_1405) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1406 = arith.constant 1.5707963267948966 : f64
    %2371:2 = qlx.apply #qlx.action<pauli_rotation>(%2369, %2370, %cst_1406) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2372 = qlx.apply #qlx.action<h>(%2221#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1407 = arith.constant 3.1415926535897931 : f64
    %2373 = qlx.apply #qlx.action<pauli_rotation>(%2372, %cst_1407) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2374 = qlx.apply #qlx.action<h>(%2373) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2375 = qlx.apply #qlx.action<h>(%2371#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1408 = arith.constant 3.1415926535897931 : f64
    %2376 = qlx.apply #qlx.action<pauli_rotation>(%2375, %cst_1408) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2377 = qlx.apply #qlx.action<h>(%2376) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1409 = arith.constant 1.5707963267948966 : f64
    %2378:2 = qlx.apply #qlx.action<pauli_rotation>(%2374, %2377, %cst_1409) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1410 = arith.constant 1.5707963267948966 : f64
    %2379 = qlx.apply #qlx.action<pauli_rotation>(%2378#0, %cst_1410) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1411 = arith.constant 1.5707963267948966 : f64
    %2380 = qlx.apply #qlx.action<pauli_rotation>(%2378#1, %cst_1411) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1412 = arith.constant 1.5707963267948966 : f64
    %2381:2 = qlx.apply #qlx.action<pauli_rotation>(%2379, %2380, %cst_1412) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2382 = qlx.apply #qlx.action<h>(%2231#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1413 = arith.constant 3.1415926535897931 : f64
    %2383 = qlx.apply #qlx.action<pauli_rotation>(%2382, %cst_1413) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2384 = qlx.apply #qlx.action<h>(%2383) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2385 = qlx.apply #qlx.action<h>(%2381#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1414 = arith.constant 3.1415926535897931 : f64
    %2386 = qlx.apply #qlx.action<pauli_rotation>(%2385, %cst_1414) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2387 = qlx.apply #qlx.action<h>(%2386) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1415 = arith.constant 1.5707963267948966 : f64
    %2388:2 = qlx.apply #qlx.action<pauli_rotation>(%2384, %2387, %cst_1415) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1416 = arith.constant 1.5707963267948966 : f64
    %2389 = qlx.apply #qlx.action<pauli_rotation>(%2388#0, %cst_1416) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1417 = arith.constant 1.5707963267948966 : f64
    %2390 = qlx.apply #qlx.action<pauli_rotation>(%2388#1, %cst_1417) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1418 = arith.constant 1.5707963267948966 : f64
    %2391:2 = qlx.apply #qlx.action<pauli_rotation>(%2389, %2390, %cst_1418) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2392 = qlx.apply #qlx.action<h>(%2241#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1419 = arith.constant 3.1415926535897931 : f64
    %2393 = qlx.apply #qlx.action<pauli_rotation>(%2392, %cst_1419) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2394 = qlx.apply #qlx.action<h>(%2393) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2395 = qlx.apply #qlx.action<h>(%2391#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1420 = arith.constant 3.1415926535897931 : f64
    %2396 = qlx.apply #qlx.action<pauli_rotation>(%2395, %cst_1420) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2397 = qlx.apply #qlx.action<h>(%2396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1421 = arith.constant 1.5707963267948966 : f64
    %2398:2 = qlx.apply #qlx.action<pauli_rotation>(%2394, %2397, %cst_1421) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1422 = arith.constant 1.5707963267948966 : f64
    %2399 = qlx.apply #qlx.action<pauli_rotation>(%2398#0, %cst_1422) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1423 = arith.constant 1.5707963267948966 : f64
    %2400 = qlx.apply #qlx.action<pauli_rotation>(%2398#1, %cst_1423) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1424 = arith.constant 1.5707963267948966 : f64
    %2401:2 = qlx.apply #qlx.action<pauli_rotation>(%2399, %2400, %cst_1424) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2402 = qlx.apply #qlx.action<h>(%2251#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1425 = arith.constant 3.1415926535897931 : f64
    %2403 = qlx.apply #qlx.action<pauli_rotation>(%2402, %cst_1425) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2404 = qlx.apply #qlx.action<h>(%2403) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2405 = qlx.apply #qlx.action<h>(%2401#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1426 = arith.constant 3.1415926535897931 : f64
    %2406 = qlx.apply #qlx.action<pauli_rotation>(%2405, %cst_1426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2407 = qlx.apply #qlx.action<h>(%2406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1427 = arith.constant 1.5707963267948966 : f64
    %2408:2 = qlx.apply #qlx.action<pauli_rotation>(%2404, %2407, %cst_1427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1428 = arith.constant 1.5707963267948966 : f64
    %2409 = qlx.apply #qlx.action<pauli_rotation>(%2408#0, %cst_1428) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1429 = arith.constant 1.5707963267948966 : f64
    %2410 = qlx.apply #qlx.action<pauli_rotation>(%2408#1, %cst_1429) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1430 = arith.constant 1.5707963267948966 : f64
    %2411:2 = qlx.apply #qlx.action<pauli_rotation>(%2409, %2410, %cst_1430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2412 = qlx.apply #qlx.action<h>(%2261#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1431 = arith.constant 1.5707963267948966 : f64
    %2413 = qlx.apply #qlx.action<pauli_rotation>(%2412, %cst_1431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2414 = qlx.apply #qlx.action<h>(%2413) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2415 = qlx.apply #qlx.action<h>(%2411#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1432 = arith.constant 1.5707963267948966 : f64
    %2416 = qlx.apply #qlx.action<pauli_rotation>(%2415, %cst_1432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2417 = qlx.apply #qlx.action<h>(%2416) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1433 = arith.constant 1.000000e+00 : f64
    %2418:2 = qlx.apply #qlx.action<pauli_rotation>(%2414, %2417, %cst_1433) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1434 = arith.constant 1.5707963267948966 : f64
    %2419 = qlx.apply #qlx.action<pauli_rotation>(%2418#0, %cst_1434) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1435 = arith.constant 1.5707963267948966 : f64
    %2420 = qlx.apply #qlx.action<pauli_rotation>(%2418#1, %cst_1435) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1436 = arith.constant 1.000000e+00 : f64
    %2421:2 = qlx.apply #qlx.action<pauli_rotation>(%2419, %2420, %cst_1436) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2422 = qlx.apply #qlx.action<h>(%2331#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1437 = arith.constant 3.1415926535897931 : f64
    %2423 = qlx.apply #qlx.action<pauli_rotation>(%2422, %cst_1437) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2424 = qlx.apply #qlx.action<h>(%2423) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2425 = qlx.apply #qlx.action<h>(%2321#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1438 = arith.constant 3.1415926535897931 : f64
    %2426 = qlx.apply #qlx.action<pauli_rotation>(%2425, %cst_1438) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2427 = qlx.apply #qlx.action<h>(%2426) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1439 = arith.constant 1.5707963267948966 : f64
    %2428:2 = qlx.apply #qlx.action<pauli_rotation>(%2424, %2427, %cst_1439) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1440 = arith.constant 1.5707963267948966 : f64
    %2429 = qlx.apply #qlx.action<pauli_rotation>(%2428#0, %cst_1440) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1441 = arith.constant 1.5707963267948966 : f64
    %2430 = qlx.apply #qlx.action<pauli_rotation>(%2428#1, %cst_1441) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1442 = arith.constant 1.5707963267948966 : f64
    %2431:2 = qlx.apply #qlx.action<pauli_rotation>(%2429, %2430, %cst_1442) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2432 = qlx.apply #qlx.action<h>(%2341#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1443 = arith.constant 3.1415926535897931 : f64
    %2433 = qlx.apply #qlx.action<pauli_rotation>(%2432, %cst_1443) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2434 = qlx.apply #qlx.action<h>(%2433) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2435 = qlx.apply #qlx.action<h>(%2431#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1444 = arith.constant 3.1415926535897931 : f64
    %2436 = qlx.apply #qlx.action<pauli_rotation>(%2435, %cst_1444) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2437 = qlx.apply #qlx.action<h>(%2436) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1445 = arith.constant 1.5707963267948966 : f64
    %2438:2 = qlx.apply #qlx.action<pauli_rotation>(%2434, %2437, %cst_1445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1446 = arith.constant 1.5707963267948966 : f64
    %2439 = qlx.apply #qlx.action<pauli_rotation>(%2438#0, %cst_1446) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1447 = arith.constant 1.5707963267948966 : f64
    %2440 = qlx.apply #qlx.action<pauli_rotation>(%2438#1, %cst_1447) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1448 = arith.constant 1.5707963267948966 : f64
    %2441:2 = qlx.apply #qlx.action<pauli_rotation>(%2439, %2440, %cst_1448) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2442 = qlx.apply #qlx.action<h>(%2351#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1449 = arith.constant 3.1415926535897931 : f64
    %2443 = qlx.apply #qlx.action<pauli_rotation>(%2442, %cst_1449) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2444 = qlx.apply #qlx.action<h>(%2443) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2445 = qlx.apply #qlx.action<h>(%2441#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1450 = arith.constant 3.1415926535897931 : f64
    %2446 = qlx.apply #qlx.action<pauli_rotation>(%2445, %cst_1450) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2447 = qlx.apply #qlx.action<h>(%2446) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1451 = arith.constant 1.5707963267948966 : f64
    %2448:2 = qlx.apply #qlx.action<pauli_rotation>(%2444, %2447, %cst_1451) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1452 = arith.constant 1.5707963267948966 : f64
    %2449 = qlx.apply #qlx.action<pauli_rotation>(%2448#0, %cst_1452) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1453 = arith.constant 1.5707963267948966 : f64
    %2450 = qlx.apply #qlx.action<pauli_rotation>(%2448#1, %cst_1453) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1454 = arith.constant 1.5707963267948966 : f64
    %2451:2 = qlx.apply #qlx.action<pauli_rotation>(%2449, %2450, %cst_1454) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2452 = qlx.apply #qlx.action<h>(%2361#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1455 = arith.constant 3.1415926535897931 : f64
    %2453 = qlx.apply #qlx.action<pauli_rotation>(%2452, %cst_1455) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2454 = qlx.apply #qlx.action<h>(%2453) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2455 = qlx.apply #qlx.action<h>(%2451#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1456 = arith.constant 3.1415926535897931 : f64
    %2456 = qlx.apply #qlx.action<pauli_rotation>(%2455, %cst_1456) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2457 = qlx.apply #qlx.action<h>(%2456) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1457 = arith.constant 1.5707963267948966 : f64
    %2458:2 = qlx.apply #qlx.action<pauli_rotation>(%2454, %2457, %cst_1457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1458 = arith.constant 1.5707963267948966 : f64
    %2459 = qlx.apply #qlx.action<pauli_rotation>(%2458#0, %cst_1458) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1459 = arith.constant 1.5707963267948966 : f64
    %2460 = qlx.apply #qlx.action<pauli_rotation>(%2458#1, %cst_1459) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1460 = arith.constant 1.5707963267948966 : f64
    %2461:2 = qlx.apply #qlx.action<pauli_rotation>(%2459, %2460, %cst_1460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2462 = qlx.apply #qlx.action<h>(%2371#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1461 = arith.constant 3.1415926535897931 : f64
    %2463 = qlx.apply #qlx.action<pauli_rotation>(%2462, %cst_1461) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2464 = qlx.apply #qlx.action<h>(%2463) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2465 = qlx.apply #qlx.action<h>(%2461#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1462 = arith.constant 3.1415926535897931 : f64
    %2466 = qlx.apply #qlx.action<pauli_rotation>(%2465, %cst_1462) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2467 = qlx.apply #qlx.action<h>(%2466) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1463 = arith.constant 1.5707963267948966 : f64
    %2468:2 = qlx.apply #qlx.action<pauli_rotation>(%2464, %2467, %cst_1463) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1464 = arith.constant 1.5707963267948966 : f64
    %2469 = qlx.apply #qlx.action<pauli_rotation>(%2468#0, %cst_1464) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1465 = arith.constant 1.5707963267948966 : f64
    %2470 = qlx.apply #qlx.action<pauli_rotation>(%2468#1, %cst_1465) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1466 = arith.constant 1.5707963267948966 : f64
    %2471:2 = qlx.apply #qlx.action<pauli_rotation>(%2469, %2470, %cst_1466) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2472 = qlx.apply #qlx.action<h>(%2381#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1467 = arith.constant 1.5707963267948966 : f64
    %2473 = qlx.apply #qlx.action<pauli_rotation>(%2472, %cst_1467) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2474 = qlx.apply #qlx.action<h>(%2473) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2475 = qlx.apply #qlx.action<h>(%2471#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1468 = arith.constant 1.5707963267948966 : f64
    %2476 = qlx.apply #qlx.action<pauli_rotation>(%2475, %cst_1468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2477 = qlx.apply #qlx.action<h>(%2476) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1469 = arith.constant 1.000000e+00 : f64
    %2478:2 = qlx.apply #qlx.action<pauli_rotation>(%2474, %2477, %cst_1469) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1470 = arith.constant 1.5707963267948966 : f64
    %2479 = qlx.apply #qlx.action<pauli_rotation>(%2478#0, %cst_1470) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1471 = arith.constant 1.5707963267948966 : f64
    %2480 = qlx.apply #qlx.action<pauli_rotation>(%2478#1, %cst_1471) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1472 = arith.constant 1.000000e+00 : f64
    %2481:2 = qlx.apply #qlx.action<pauli_rotation>(%2479, %2480, %cst_1472) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2482 = qlx.apply #qlx.action<h>(%2311#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1473 = arith.constant 3.1415926535897931 : f64
    %2483 = qlx.apply #qlx.action<pauli_rotation>(%2482, %cst_1473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2484 = qlx.apply #qlx.action<h>(%2483) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2485 = qlx.apply #qlx.action<h>(%1351#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1474 = arith.constant 2.3561944901923448 : f64
    %2486 = qlx.apply #qlx.action<pauli_rotation>(%2485, %cst_1474) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2487 = qlx.apply #qlx.action<h>(%2486) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1475 = arith.constant 1.5707963267948966 : f64
    %2488:2 = qlx.apply #qlx.action<pauli_rotation>(%2484, %2487, %cst_1475) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1476 = arith.constant 1.5707963267948966 : f64
    %2489 = qlx.apply #qlx.action<pauli_rotation>(%2488#0, %cst_1476) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1477 = arith.constant 1.5707963267948966 : f64
    %2490 = qlx.apply #qlx.action<pauli_rotation>(%2488#1, %cst_1477) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1478 = arith.constant 1.5707963267948966 : f64
    %2491:2 = qlx.apply #qlx.action<pauli_rotation>(%2489, %2490, %cst_1478) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2492 = qlx.apply #qlx.action<h>(%2431#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1479 = arith.constant 3.1415926535897931 : f64
    %2493 = qlx.apply #qlx.action<pauli_rotation>(%2492, %cst_1479) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2494 = qlx.apply #qlx.action<h>(%2493) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2495 = qlx.apply #qlx.action<h>(%2491#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1480 = arith.constant 3.1415926535897931 : f64
    %2496 = qlx.apply #qlx.action<pauli_rotation>(%2495, %cst_1480) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2497 = qlx.apply #qlx.action<h>(%2496) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1481 = arith.constant 1.5707963267948966 : f64
    %2498:2 = qlx.apply #qlx.action<pauli_rotation>(%2494, %2497, %cst_1481) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1482 = arith.constant 1.5707963267948966 : f64
    %2499 = qlx.apply #qlx.action<pauli_rotation>(%2498#0, %cst_1482) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1483 = arith.constant 1.5707963267948966 : f64
    %2500 = qlx.apply #qlx.action<pauli_rotation>(%2498#1, %cst_1483) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1484 = arith.constant 1.5707963267948966 : f64
    %2501:2 = qlx.apply #qlx.action<pauli_rotation>(%2499, %2500, %cst_1484) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2502 = qlx.apply #qlx.action<h>(%2441#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1485 = arith.constant 3.1415926535897931 : f64
    %2503 = qlx.apply #qlx.action<pauli_rotation>(%2502, %cst_1485) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2504 = qlx.apply #qlx.action<h>(%2503) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2505 = qlx.apply #qlx.action<h>(%2501#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1486 = arith.constant 3.1415926535897931 : f64
    %2506 = qlx.apply #qlx.action<pauli_rotation>(%2505, %cst_1486) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2507 = qlx.apply #qlx.action<h>(%2506) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1487 = arith.constant 1.5707963267948966 : f64
    %2508:2 = qlx.apply #qlx.action<pauli_rotation>(%2504, %2507, %cst_1487) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1488 = arith.constant 1.5707963267948966 : f64
    %2509 = qlx.apply #qlx.action<pauli_rotation>(%2508#0, %cst_1488) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1489 = arith.constant 1.5707963267948966 : f64
    %2510 = qlx.apply #qlx.action<pauli_rotation>(%2508#1, %cst_1489) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1490 = arith.constant 1.5707963267948966 : f64
    %2511:2 = qlx.apply #qlx.action<pauli_rotation>(%2509, %2510, %cst_1490) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2512 = qlx.apply #qlx.action<h>(%2451#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1491 = arith.constant 1.5707963267948966 : f64
    %2513 = qlx.apply #qlx.action<pauli_rotation>(%2512, %cst_1491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2514 = qlx.apply #qlx.action<h>(%2513) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2515 = qlx.apply #qlx.action<h>(%2511#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1492 = arith.constant 1.5707963267948966 : f64
    %2516 = qlx.apply #qlx.action<pauli_rotation>(%2515, %cst_1492) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2517 = qlx.apply #qlx.action<h>(%2516) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1493 = arith.constant 1.000000e+00 : f64
    %2518:2 = qlx.apply #qlx.action<pauli_rotation>(%2514, %2517, %cst_1493) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1494 = arith.constant 1.5707963267948966 : f64
    %2519 = qlx.apply #qlx.action<pauli_rotation>(%2518#0, %cst_1494) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1495 = arith.constant 1.5707963267948966 : f64
    %2520 = qlx.apply #qlx.action<pauli_rotation>(%2518#1, %cst_1495) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1496 = arith.constant 1.000000e+00 : f64
    %2521:2 = qlx.apply #qlx.action<pauli_rotation>(%2519, %2520, %cst_1496) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2522 = qlx.apply #qlx.action<h>(%2511#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1497 = arith.constant 3.1415926535897931 : f64
    %2523 = qlx.apply #qlx.action<pauli_rotation>(%2522, %cst_1497) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2524 = qlx.apply #qlx.action<h>(%2523) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2525 = qlx.apply #qlx.action<h>(%2501#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1498 = arith.constant 3.1415926535897931 : f64
    %2526 = qlx.apply #qlx.action<pauli_rotation>(%2525, %cst_1498) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2527 = qlx.apply #qlx.action<h>(%2526) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1499 = arith.constant 1.5707963267948966 : f64
    %2528:2 = qlx.apply #qlx.action<pauli_rotation>(%2524, %2527, %cst_1499) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1500 = arith.constant 1.5707963267948966 : f64
    %2529 = qlx.apply #qlx.action<pauli_rotation>(%2528#0, %cst_1500) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1501 = arith.constant 1.5707963267948966 : f64
    %2530 = qlx.apply #qlx.action<pauli_rotation>(%2528#1, %cst_1501) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1502 = arith.constant 1.5707963267948966 : f64
    %2531:2 = qlx.apply #qlx.action<pauli_rotation>(%2529, %2530, %cst_1502) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2532 = qlx.apply #qlx.action<h>(%2521#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1503 = arith.constant 3.1415926535897931 : f64
    %2533 = qlx.apply #qlx.action<pauli_rotation>(%2532, %cst_1503) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2534 = qlx.apply #qlx.action<h>(%2533) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2535 = qlx.apply #qlx.action<h>(%2531#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1504 = arith.constant 3.1415926535897931 : f64
    %2536 = qlx.apply #qlx.action<pauli_rotation>(%2535, %cst_1504) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2537 = qlx.apply #qlx.action<h>(%2536) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1505 = arith.constant 1.5707963267948966 : f64
    %2538:2 = qlx.apply #qlx.action<pauli_rotation>(%2534, %2537, %cst_1505) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1506 = arith.constant 1.5707963267948966 : f64
    %2539 = qlx.apply #qlx.action<pauli_rotation>(%2538#0, %cst_1506) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1507 = arith.constant 1.5707963267948966 : f64
    %2540 = qlx.apply #qlx.action<pauli_rotation>(%2538#1, %cst_1507) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1508 = arith.constant 1.5707963267948966 : f64
    %2541:2 = qlx.apply #qlx.action<pauli_rotation>(%2539, %2540, %cst_1508) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2542 = qlx.apply #qlx.action<h>(%2541#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1509 = arith.constant 3.1415926535897931 : f64
    %2543 = qlx.apply #qlx.action<pauli_rotation>(%2542, %cst_1509) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2544 = qlx.apply #qlx.action<h>(%2543) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1510 = arith.constant 1.5707963267948966 : f64
    %2545:2 = qlx.apply #qlx.action<pauli_rotation>(%2521#0, %2544, %cst_1510) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1511 = arith.constant 1.5707963267948966 : f64
    %2546 = qlx.apply #qlx.action<pauli_rotation>(%2545#0, %cst_1511) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1512 = arith.constant 1.5707963267948966 : f64
    %2547 = qlx.apply #qlx.action<pauli_rotation>(%2545#1, %cst_1512) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1513 = arith.constant 1.5707963267948966 : f64
    %2548:2 = qlx.apply #qlx.action<pauli_rotation>(%2546, %2547, %cst_1513) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2549 = qlx.apply #qlx.action<h>(%2461#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1514 = arith.constant 3.1415926535897931 : f64
    %2550 = qlx.apply #qlx.action<pauli_rotation>(%2549, %cst_1514) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2551 = qlx.apply #qlx.action<h>(%2550) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2552 = qlx.apply #qlx.action<h>(%2548#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1515 = arith.constant 3.1415926535897931 : f64
    %2553 = qlx.apply #qlx.action<pauli_rotation>(%2552, %cst_1515) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2554 = qlx.apply #qlx.action<h>(%2553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1516 = arith.constant 1.5707963267948966 : f64
    %2555:2 = qlx.apply #qlx.action<pauli_rotation>(%2551, %2554, %cst_1516) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1517 = arith.constant 1.5707963267948966 : f64
    %2556 = qlx.apply #qlx.action<pauli_rotation>(%2555#0, %cst_1517) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1518 = arith.constant 1.5707963267948966 : f64
    %2557 = qlx.apply #qlx.action<pauli_rotation>(%2555#1, %cst_1518) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1519 = arith.constant 1.5707963267948966 : f64
    %2558:2 = qlx.apply #qlx.action<pauli_rotation>(%2556, %2557, %cst_1519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2559 = qlx.apply #qlx.action<h>(%2471#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1520 = arith.constant 3.1415926535897931 : f64
    %2560 = qlx.apply #qlx.action<pauli_rotation>(%2559, %cst_1520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2561 = qlx.apply #qlx.action<h>(%2560) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2562 = qlx.apply #qlx.action<h>(%2558#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1521 = arith.constant 3.1415926535897931 : f64
    %2563 = qlx.apply #qlx.action<pauli_rotation>(%2562, %cst_1521) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2564 = qlx.apply #qlx.action<h>(%2563) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1522 = arith.constant 1.5707963267948966 : f64
    %2565:2 = qlx.apply #qlx.action<pauli_rotation>(%2561, %2564, %cst_1522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1523 = arith.constant 1.5707963267948966 : f64
    %2566 = qlx.apply #qlx.action<pauli_rotation>(%2565#0, %cst_1523) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1524 = arith.constant 1.5707963267948966 : f64
    %2567 = qlx.apply #qlx.action<pauli_rotation>(%2565#1, %cst_1524) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1525 = arith.constant 1.5707963267948966 : f64
    %2568:2 = qlx.apply #qlx.action<pauli_rotation>(%2566, %2567, %cst_1525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2569 = qlx.apply #qlx.action<h>(%2481#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1526 = arith.constant 3.1415926535897931 : f64
    %2570 = qlx.apply #qlx.action<pauli_rotation>(%2569, %cst_1526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2571 = qlx.apply #qlx.action<h>(%2570) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2572 = qlx.apply #qlx.action<h>(%2568#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1527 = arith.constant 3.1415926535897931 : f64
    %2573 = qlx.apply #qlx.action<pauli_rotation>(%2572, %cst_1527) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2574 = qlx.apply #qlx.action<h>(%2573) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1528 = arith.constant 1.5707963267948966 : f64
    %2575:2 = qlx.apply #qlx.action<pauli_rotation>(%2571, %2574, %cst_1528) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1529 = arith.constant 1.5707963267948966 : f64
    %2576 = qlx.apply #qlx.action<pauli_rotation>(%2575#0, %cst_1529) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1530 = arith.constant 1.5707963267948966 : f64
    %2577 = qlx.apply #qlx.action<pauli_rotation>(%2575#1, %cst_1530) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1531 = arith.constant 1.5707963267948966 : f64
    %2578:2 = qlx.apply #qlx.action<pauli_rotation>(%2576, %2577, %cst_1531) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2579 = qlx.apply #qlx.action<h>(%2578#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1532 = arith.constant 3.1415926535897931 : f64
    %2580 = qlx.apply #qlx.action<pauli_rotation>(%2579, %cst_1532) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2581 = qlx.apply #qlx.action<h>(%2580) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1533 = arith.constant 1.5707963267948966 : f64
    %2582:2 = qlx.apply #qlx.action<pauli_rotation>(%2481#0, %2581, %cst_1533) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1534 = arith.constant 1.5707963267948966 : f64
    %2583 = qlx.apply #qlx.action<pauli_rotation>(%2582#0, %cst_1534) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1535 = arith.constant 1.5707963267948966 : f64
    %2584 = qlx.apply #qlx.action<pauli_rotation>(%2582#1, %cst_1535) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1536 = arith.constant 1.5707963267948966 : f64
    %2585:2 = qlx.apply #qlx.action<pauli_rotation>(%2583, %2584, %cst_1536) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2586 = qlx.apply #qlx.action<h>(%2391#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1537 = arith.constant 3.1415926535897931 : f64
    %2587 = qlx.apply #qlx.action<pauli_rotation>(%2586, %cst_1537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2588 = qlx.apply #qlx.action<h>(%2587) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2589 = qlx.apply #qlx.action<h>(%2585#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1538 = arith.constant 3.1415926535897931 : f64
    %2590 = qlx.apply #qlx.action<pauli_rotation>(%2589, %cst_1538) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2591 = qlx.apply #qlx.action<h>(%2590) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1539 = arith.constant 1.5707963267948966 : f64
    %2592:2 = qlx.apply #qlx.action<pauli_rotation>(%2588, %2591, %cst_1539) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1540 = arith.constant 1.5707963267948966 : f64
    %2593 = qlx.apply #qlx.action<pauli_rotation>(%2592#0, %cst_1540) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1541 = arith.constant 1.5707963267948966 : f64
    %2594 = qlx.apply #qlx.action<pauli_rotation>(%2592#1, %cst_1541) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1542 = arith.constant 1.5707963267948966 : f64
    %2595:2 = qlx.apply #qlx.action<pauli_rotation>(%2593, %2594, %cst_1542) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2596 = qlx.apply #qlx.action<h>(%2401#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1543 = arith.constant 3.1415926535897931 : f64
    %2597 = qlx.apply #qlx.action<pauli_rotation>(%2596, %cst_1543) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2598 = qlx.apply #qlx.action<h>(%2597) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2599 = qlx.apply #qlx.action<h>(%2595#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1544 = arith.constant 3.1415926535897931 : f64
    %2600 = qlx.apply #qlx.action<pauli_rotation>(%2599, %cst_1544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2601 = qlx.apply #qlx.action<h>(%2600) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1545 = arith.constant 1.5707963267948966 : f64
    %2602:2 = qlx.apply #qlx.action<pauli_rotation>(%2598, %2601, %cst_1545) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1546 = arith.constant 1.5707963267948966 : f64
    %2603 = qlx.apply #qlx.action<pauli_rotation>(%2602#0, %cst_1546) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1547 = arith.constant 1.5707963267948966 : f64
    %2604 = qlx.apply #qlx.action<pauli_rotation>(%2602#1, %cst_1547) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1548 = arith.constant 1.5707963267948966 : f64
    %2605:2 = qlx.apply #qlx.action<pauli_rotation>(%2603, %2604, %cst_1548) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2606 = qlx.apply #qlx.action<h>(%2411#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1549 = arith.constant 3.1415926535897931 : f64
    %2607 = qlx.apply #qlx.action<pauli_rotation>(%2606, %cst_1549) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2608 = qlx.apply #qlx.action<h>(%2607) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2609 = qlx.apply #qlx.action<h>(%2605#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1550 = arith.constant 3.1415926535897931 : f64
    %2610 = qlx.apply #qlx.action<pauli_rotation>(%2609, %cst_1550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2611 = qlx.apply #qlx.action<h>(%2610) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1551 = arith.constant 1.5707963267948966 : f64
    %2612:2 = qlx.apply #qlx.action<pauli_rotation>(%2608, %2611, %cst_1551) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1552 = arith.constant 1.5707963267948966 : f64
    %2613 = qlx.apply #qlx.action<pauli_rotation>(%2612#0, %cst_1552) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1553 = arith.constant 1.5707963267948966 : f64
    %2614 = qlx.apply #qlx.action<pauli_rotation>(%2612#1, %cst_1553) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1554 = arith.constant 1.5707963267948966 : f64
    %2615:2 = qlx.apply #qlx.action<pauli_rotation>(%2613, %2614, %cst_1554) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2616 = qlx.apply #qlx.action<h>(%2421#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1555 = arith.constant 3.1415926535897931 : f64
    %2617 = qlx.apply #qlx.action<pauli_rotation>(%2616, %cst_1555) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2618 = qlx.apply #qlx.action<h>(%2617) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2619 = qlx.apply #qlx.action<h>(%2615#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1556 = arith.constant 3.1415926535897931 : f64
    %2620 = qlx.apply #qlx.action<pauli_rotation>(%2619, %cst_1556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2621 = qlx.apply #qlx.action<h>(%2620) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1557 = arith.constant 1.5707963267948966 : f64
    %2622:2 = qlx.apply #qlx.action<pauli_rotation>(%2618, %2621, %cst_1557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1558 = arith.constant 1.5707963267948966 : f64
    %2623 = qlx.apply #qlx.action<pauli_rotation>(%2622#0, %cst_1558) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1559 = arith.constant 1.5707963267948966 : f64
    %2624 = qlx.apply #qlx.action<pauli_rotation>(%2622#1, %cst_1559) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1560 = arith.constant 1.5707963267948966 : f64
    %2625:2 = qlx.apply #qlx.action<pauli_rotation>(%2623, %2624, %cst_1560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2626 = qlx.apply #qlx.action<h>(%2625#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1561 = arith.constant 3.1415926535897931 : f64
    %2627 = qlx.apply #qlx.action<pauli_rotation>(%2626, %cst_1561) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2628 = qlx.apply #qlx.action<h>(%2627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1562 = arith.constant 1.5707963267948966 : f64
    %2629:2 = qlx.apply #qlx.action<pauli_rotation>(%2421#0, %2628, %cst_1562) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1563 = arith.constant 1.5707963267948966 : f64
    %2630 = qlx.apply #qlx.action<pauli_rotation>(%2629#0, %cst_1563) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1564 = arith.constant 1.5707963267948966 : f64
    %2631 = qlx.apply #qlx.action<pauli_rotation>(%2629#1, %cst_1564) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1565 = arith.constant 1.5707963267948966 : f64
    %2632:2 = qlx.apply #qlx.action<pauli_rotation>(%2630, %2631, %cst_1565) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2633 = qlx.apply #qlx.action<h>(%2271#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1566 = arith.constant 3.1415926535897931 : f64
    %2634 = qlx.apply #qlx.action<pauli_rotation>(%2633, %cst_1566) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2635 = qlx.apply #qlx.action<h>(%2634) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2636 = qlx.apply #qlx.action<h>(%2632#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1567 = arith.constant 3.1415926535897931 : f64
    %2637 = qlx.apply #qlx.action<pauli_rotation>(%2636, %cst_1567) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2638 = qlx.apply #qlx.action<h>(%2637) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1568 = arith.constant 1.5707963267948966 : f64
    %2639:2 = qlx.apply #qlx.action<pauli_rotation>(%2635, %2638, %cst_1568) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1569 = arith.constant 1.5707963267948966 : f64
    %2640 = qlx.apply #qlx.action<pauli_rotation>(%2639#0, %cst_1569) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1570 = arith.constant 1.5707963267948966 : f64
    %2641 = qlx.apply #qlx.action<pauli_rotation>(%2639#1, %cst_1570) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1571 = arith.constant 1.5707963267948966 : f64
    %2642:2 = qlx.apply #qlx.action<pauli_rotation>(%2640, %2641, %cst_1571) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2643 = qlx.apply #qlx.action<h>(%2281#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1572 = arith.constant 3.1415926535897931 : f64
    %2644 = qlx.apply #qlx.action<pauli_rotation>(%2643, %cst_1572) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2645 = qlx.apply #qlx.action<h>(%2644) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2646 = qlx.apply #qlx.action<h>(%2642#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1573 = arith.constant 3.1415926535897931 : f64
    %2647 = qlx.apply #qlx.action<pauli_rotation>(%2646, %cst_1573) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2648 = qlx.apply #qlx.action<h>(%2647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1574 = arith.constant 1.5707963267948966 : f64
    %2649:2 = qlx.apply #qlx.action<pauli_rotation>(%2645, %2648, %cst_1574) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1575 = arith.constant 1.5707963267948966 : f64
    %2650 = qlx.apply #qlx.action<pauli_rotation>(%2649#0, %cst_1575) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1576 = arith.constant 1.5707963267948966 : f64
    %2651 = qlx.apply #qlx.action<pauli_rotation>(%2649#1, %cst_1576) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1577 = arith.constant 1.5707963267948966 : f64
    %2652:2 = qlx.apply #qlx.action<pauli_rotation>(%2650, %2651, %cst_1577) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2653 = qlx.apply #qlx.action<h>(%2291#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1578 = arith.constant 3.1415926535897931 : f64
    %2654 = qlx.apply #qlx.action<pauli_rotation>(%2653, %cst_1578) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2655 = qlx.apply #qlx.action<h>(%2654) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2656 = qlx.apply #qlx.action<h>(%2652#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1579 = arith.constant 3.1415926535897931 : f64
    %2657 = qlx.apply #qlx.action<pauli_rotation>(%2656, %cst_1579) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2658 = qlx.apply #qlx.action<h>(%2657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1580 = arith.constant 1.5707963267948966 : f64
    %2659:2 = qlx.apply #qlx.action<pauli_rotation>(%2655, %2658, %cst_1580) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1581 = arith.constant 1.5707963267948966 : f64
    %2660 = qlx.apply #qlx.action<pauli_rotation>(%2659#0, %cst_1581) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1582 = arith.constant 1.5707963267948966 : f64
    %2661 = qlx.apply #qlx.action<pauli_rotation>(%2659#1, %cst_1582) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1583 = arith.constant 1.5707963267948966 : f64
    %2662:2 = qlx.apply #qlx.action<pauli_rotation>(%2660, %2661, %cst_1583) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2663 = qlx.apply #qlx.action<h>(%2301#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1584 = arith.constant 3.1415926535897931 : f64
    %2664 = qlx.apply #qlx.action<pauli_rotation>(%2663, %cst_1584) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2665 = qlx.apply #qlx.action<h>(%2664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2666 = qlx.apply #qlx.action<h>(%2662#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1585 = arith.constant 3.1415926535897931 : f64
    %2667 = qlx.apply #qlx.action<pauli_rotation>(%2666, %cst_1585) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2668 = qlx.apply #qlx.action<h>(%2667) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1586 = arith.constant 1.5707963267948966 : f64
    %2669:2 = qlx.apply #qlx.action<pauli_rotation>(%2665, %2668, %cst_1586) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1587 = arith.constant 1.5707963267948966 : f64
    %2670 = qlx.apply #qlx.action<pauli_rotation>(%2669#0, %cst_1587) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1588 = arith.constant 1.5707963267948966 : f64
    %2671 = qlx.apply #qlx.action<pauli_rotation>(%2669#1, %cst_1588) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1589 = arith.constant 1.5707963267948966 : f64
    %2672:2 = qlx.apply #qlx.action<pauli_rotation>(%2670, %2671, %cst_1589) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2673 = qlx.apply #qlx.action<h>(%2672#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1590 = arith.constant 3.1415926535897931 : f64
    %2674 = qlx.apply #qlx.action<pauli_rotation>(%2673, %cst_1590) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2675 = qlx.apply #qlx.action<h>(%2674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1591 = arith.constant 1.5707963267948966 : f64
    %2676:2 = qlx.apply #qlx.action<pauli_rotation>(%2301#0, %2675, %cst_1591) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1592 = arith.constant 1.5707963267948966 : f64
    %2677 = qlx.apply #qlx.action<pauli_rotation>(%2676#0, %cst_1592) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1593 = arith.constant 1.5707963267948966 : f64
    %2678 = qlx.apply #qlx.action<pauli_rotation>(%2676#1, %cst_1593) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1594 = arith.constant 1.5707963267948966 : f64
    %2679:2 = qlx.apply #qlx.action<pauli_rotation>(%2677, %2678, %cst_1594) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2680 = qlx.apply #qlx.action<h>(%2111#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1595 = arith.constant 3.1415926535897931 : f64
    %2681 = qlx.apply #qlx.action<pauli_rotation>(%2680, %cst_1595) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2682 = qlx.apply #qlx.action<h>(%2681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2683 = qlx.apply #qlx.action<h>(%2679#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1596 = arith.constant 3.1415926535897931 : f64
    %2684 = qlx.apply #qlx.action<pauli_rotation>(%2683, %cst_1596) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2685 = qlx.apply #qlx.action<h>(%2684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1597 = arith.constant 1.5707963267948966 : f64
    %2686:2 = qlx.apply #qlx.action<pauli_rotation>(%2682, %2685, %cst_1597) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1598 = arith.constant 1.5707963267948966 : f64
    %2687 = qlx.apply #qlx.action<pauli_rotation>(%2686#0, %cst_1598) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1599 = arith.constant 1.5707963267948966 : f64
    %2688 = qlx.apply #qlx.action<pauli_rotation>(%2686#1, %cst_1599) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1600 = arith.constant 1.5707963267948966 : f64
    %2689:2 = qlx.apply #qlx.action<pauli_rotation>(%2687, %2688, %cst_1600) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2690 = qlx.apply #qlx.action<h>(%2121#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1601 = arith.constant 3.1415926535897931 : f64
    %2691 = qlx.apply #qlx.action<pauli_rotation>(%2690, %cst_1601) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2692 = qlx.apply #qlx.action<h>(%2691) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2693 = qlx.apply #qlx.action<h>(%2689#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1602 = arith.constant 3.1415926535897931 : f64
    %2694 = qlx.apply #qlx.action<pauli_rotation>(%2693, %cst_1602) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2695 = qlx.apply #qlx.action<h>(%2694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1603 = arith.constant 1.5707963267948966 : f64
    %2696:2 = qlx.apply #qlx.action<pauli_rotation>(%2692, %2695, %cst_1603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1604 = arith.constant 1.5707963267948966 : f64
    %2697 = qlx.apply #qlx.action<pauli_rotation>(%2696#0, %cst_1604) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1605 = arith.constant 1.5707963267948966 : f64
    %2698 = qlx.apply #qlx.action<pauli_rotation>(%2696#1, %cst_1605) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1606 = arith.constant 1.5707963267948966 : f64
    %2699:2 = qlx.apply #qlx.action<pauli_rotation>(%2697, %2698, %cst_1606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2700 = qlx.apply #qlx.action<h>(%2131#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1607 = arith.constant 3.1415926535897931 : f64
    %2701 = qlx.apply #qlx.action<pauli_rotation>(%2700, %cst_1607) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2702 = qlx.apply #qlx.action<h>(%2701) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2703 = qlx.apply #qlx.action<h>(%2699#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1608 = arith.constant 3.1415926535897931 : f64
    %2704 = qlx.apply #qlx.action<pauli_rotation>(%2703, %cst_1608) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2705 = qlx.apply #qlx.action<h>(%2704) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1609 = arith.constant 1.5707963267948966 : f64
    %2706:2 = qlx.apply #qlx.action<pauli_rotation>(%2702, %2705, %cst_1609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1610 = arith.constant 1.5707963267948966 : f64
    %2707 = qlx.apply #qlx.action<pauli_rotation>(%2706#0, %cst_1610) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1611 = arith.constant 1.5707963267948966 : f64
    %2708 = qlx.apply #qlx.action<pauli_rotation>(%2706#1, %cst_1611) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1612 = arith.constant 1.5707963267948966 : f64
    %2709:2 = qlx.apply #qlx.action<pauli_rotation>(%2707, %2708, %cst_1612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2710 = qlx.apply #qlx.action<h>(%2141#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1613 = arith.constant 3.1415926535897931 : f64
    %2711 = qlx.apply #qlx.action<pauli_rotation>(%2710, %cst_1613) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2712 = qlx.apply #qlx.action<h>(%2711) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2713 = qlx.apply #qlx.action<h>(%2709#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1614 = arith.constant 3.1415926535897931 : f64
    %2714 = qlx.apply #qlx.action<pauli_rotation>(%2713, %cst_1614) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2715 = qlx.apply #qlx.action<h>(%2714) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1615 = arith.constant 1.5707963267948966 : f64
    %2716:2 = qlx.apply #qlx.action<pauli_rotation>(%2712, %2715, %cst_1615) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1616 = arith.constant 1.5707963267948966 : f64
    %2717 = qlx.apply #qlx.action<pauli_rotation>(%2716#0, %cst_1616) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1617 = arith.constant 1.5707963267948966 : f64
    %2718 = qlx.apply #qlx.action<pauli_rotation>(%2716#1, %cst_1617) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1618 = arith.constant 1.5707963267948966 : f64
    %2719:2 = qlx.apply #qlx.action<pauli_rotation>(%2717, %2718, %cst_1618) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2720 = qlx.apply #qlx.action<h>(%2151#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1619 = arith.constant 1.5707963267948966 : f64
    %2721 = qlx.apply #qlx.action<pauli_rotation>(%2720, %cst_1619) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2722 = qlx.apply #qlx.action<h>(%2721) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2723 = qlx.apply #qlx.action<h>(%2719#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1620 = arith.constant 3.1415926535897931 : f64
    %2724 = qlx.apply #qlx.action<pauli_rotation>(%2723, %cst_1620) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2725 = qlx.apply #qlx.action<h>(%2724) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1621 = arith.constant 1.5707963267948966 : f64
    %2726:2 = qlx.apply #qlx.action<pauli_rotation>(%2722, %2725, %cst_1621) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1622 = arith.constant 1.5707963267948966 : f64
    %2727 = qlx.apply #qlx.action<pauli_rotation>(%2726#0, %cst_1622) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1623 = arith.constant 1.5707963267948966 : f64
    %2728 = qlx.apply #qlx.action<pauli_rotation>(%2726#1, %cst_1623) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1624 = arith.constant 1.5707963267948966 : f64
    %2729:2 = qlx.apply #qlx.action<pauli_rotation>(%2727, %2728, %cst_1624) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2730 = qlx.apply #qlx.action<h>(%2161#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1625 = arith.constant 2.3561944901923448 : f64
    %2731 = qlx.apply #qlx.action<pauli_rotation>(%2730, %cst_1625) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2732 = qlx.apply #qlx.action<h>(%2731) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2733 = qlx.apply #qlx.action<h>(%2729#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1626 = arith.constant 3.1415926535897931 : f64
    %2734 = qlx.apply #qlx.action<pauli_rotation>(%2733, %cst_1626) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2735 = qlx.apply #qlx.action<h>(%2734) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1627 = arith.constant 1.5707963267948966 : f64
    %2736:2 = qlx.apply #qlx.action<pauli_rotation>(%2732, %2735, %cst_1627) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1628 = arith.constant 1.5707963267948966 : f64
    %2737 = qlx.apply #qlx.action<pauli_rotation>(%2736#0, %cst_1628) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1629 = arith.constant 1.5707963267948966 : f64
    %2738 = qlx.apply #qlx.action<pauli_rotation>(%2736#1, %cst_1629) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1630 = arith.constant 1.5707963267948966 : f64
    %2739:2 = qlx.apply #qlx.action<pauli_rotation>(%2737, %2738, %cst_1630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2740 = qlx.apply #qlx.action<h>(%2161#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1631 = arith.constant 2.3561944901923448 : f64
    %2741 = qlx.apply #qlx.action<pauli_rotation>(%2740, %cst_1631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2742 = qlx.apply #qlx.action<h>(%2741) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2743 = qlx.apply #qlx.action<h>(%2739#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1632 = arith.constant 3.1415926535897931 : f64
    %2744 = qlx.apply #qlx.action<pauli_rotation>(%2743, %cst_1632) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2745 = qlx.apply #qlx.action<h>(%2744) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1633 = arith.constant 1.5707963267948966 : f64
    %2746:2 = qlx.apply #qlx.action<pauli_rotation>(%2742, %2745, %cst_1633) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1634 = arith.constant 1.5707963267948966 : f64
    %2747 = qlx.apply #qlx.action<pauli_rotation>(%2746#0, %cst_1634) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1635 = arith.constant 1.5707963267948966 : f64
    %2748 = qlx.apply #qlx.action<pauli_rotation>(%2746#1, %cst_1635) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1636 = arith.constant 1.5707963267948966 : f64
    %2749:2 = qlx.apply #qlx.action<pauli_rotation>(%2747, %2748, %cst_1636) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2750 = qlx.apply #qlx.action<h>(%1731#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1637 = arith.constant 3.1415926535897931 : f64
    %2751 = qlx.apply #qlx.action<pauli_rotation>(%2750, %cst_1637) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2752 = qlx.apply #qlx.action<h>(%2751) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2753 = qlx.apply #qlx.action<h>(%2749#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1638 = arith.constant 3.1415926535897931 : f64
    %2754 = qlx.apply #qlx.action<pauli_rotation>(%2753, %cst_1638) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2755 = qlx.apply #qlx.action<h>(%2754) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1639 = arith.constant 1.5707963267948966 : f64
    %2756:2 = qlx.apply #qlx.action<pauli_rotation>(%2752, %2755, %cst_1639) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1640 = arith.constant 1.5707963267948966 : f64
    %2757 = qlx.apply #qlx.action<pauli_rotation>(%2756#0, %cst_1640) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1641 = arith.constant 1.5707963267948966 : f64
    %2758 = qlx.apply #qlx.action<pauli_rotation>(%2756#1, %cst_1641) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1642 = arith.constant 1.5707963267948966 : f64
    %2759:2 = qlx.apply #qlx.action<pauli_rotation>(%2757, %2758, %cst_1642) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2760 = qlx.apply #qlx.action<h>(%1741#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1643 = arith.constant 3.1415926535897931 : f64
    %2761 = qlx.apply #qlx.action<pauli_rotation>(%2760, %cst_1643) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2762 = qlx.apply #qlx.action<h>(%2761) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2763 = qlx.apply #qlx.action<h>(%2759#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1644 = arith.constant 3.1415926535897931 : f64
    %2764 = qlx.apply #qlx.action<pauli_rotation>(%2763, %cst_1644) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2765 = qlx.apply #qlx.action<h>(%2764) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1645 = arith.constant 1.5707963267948966 : f64
    %2766:2 = qlx.apply #qlx.action<pauli_rotation>(%2762, %2765, %cst_1645) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1646 = arith.constant 1.5707963267948966 : f64
    %2767 = qlx.apply #qlx.action<pauli_rotation>(%2766#0, %cst_1646) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1647 = arith.constant 1.5707963267948966 : f64
    %2768 = qlx.apply #qlx.action<pauli_rotation>(%2766#1, %cst_1647) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1648 = arith.constant 1.5707963267948966 : f64
    %2769:2 = qlx.apply #qlx.action<pauli_rotation>(%2767, %2768, %cst_1648) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2770 = qlx.apply #qlx.action<h>(%1751#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1649 = arith.constant 1.5707963267948966 : f64
    %2771 = qlx.apply #qlx.action<pauli_rotation>(%2770, %cst_1649) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2772 = qlx.apply #qlx.action<h>(%2771) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2773 = qlx.apply #qlx.action<h>(%2769#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1650 = arith.constant 3.1415926535897931 : f64
    %2774 = qlx.apply #qlx.action<pauli_rotation>(%2773, %cst_1650) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2775 = qlx.apply #qlx.action<h>(%2774) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1651 = arith.constant 1.5707963267948966 : f64
    %2776:2 = qlx.apply #qlx.action<pauli_rotation>(%2772, %2775, %cst_1651) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1652 = arith.constant 1.5707963267948966 : f64
    %2777 = qlx.apply #qlx.action<pauli_rotation>(%2776#0, %cst_1652) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1653 = arith.constant 1.5707963267948966 : f64
    %2778 = qlx.apply #qlx.action<pauli_rotation>(%2776#1, %cst_1653) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1654 = arith.constant 1.5707963267948966 : f64
    %2779:2 = qlx.apply #qlx.action<pauli_rotation>(%2777, %2778, %cst_1654) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2780 = qlx.apply #qlx.action<h>(%1761#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1655 = arith.constant 3.1415926535897931 : f64
    %2781 = qlx.apply #qlx.action<pauli_rotation>(%2780, %cst_1655) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2782 = qlx.apply #qlx.action<h>(%2781) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2783 = qlx.apply #qlx.action<h>(%2779#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1656 = arith.constant 2.3561944901923448 : f64
    %2784 = qlx.apply #qlx.action<pauli_rotation>(%2783, %cst_1656) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2785 = qlx.apply #qlx.action<h>(%2784) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1657 = arith.constant 0.78539816339744828 : f64
    %2786:2 = qlx.apply #qlx.action<pauli_rotation>(%2782, %2785, %cst_1657) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1658 = arith.constant 1.5707963267948966 : f64
    %2787 = qlx.apply #qlx.action<pauli_rotation>(%2786#0, %cst_1658) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1659 = arith.constant 1.5707963267948966 : f64
    %2788 = qlx.apply #qlx.action<pauli_rotation>(%2786#1, %cst_1659) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1660 = arith.constant 0.78539816339744828 : f64
    %2789:2 = qlx.apply #qlx.action<pauli_rotation>(%2787, %2788, %cst_1660) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2790 = qlx.apply #qlx.action<h>(%2585#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1661 = arith.constant 3.1415926535897931 : f64
    %2791 = qlx.apply #qlx.action<pauli_rotation>(%2790, %cst_1661) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2792 = qlx.apply #qlx.action<h>(%2791) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2793 = qlx.apply #qlx.action<h>(%2578#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1662 = arith.constant 3.1415926535897931 : f64
    %2794 = qlx.apply #qlx.action<pauli_rotation>(%2793, %cst_1662) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2795 = qlx.apply #qlx.action<h>(%2794) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1663 = arith.constant 1.5707963267948966 : f64
    %2796:2 = qlx.apply #qlx.action<pauli_rotation>(%2792, %2795, %cst_1663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1664 = arith.constant 1.5707963267948966 : f64
    %2797 = qlx.apply #qlx.action<pauli_rotation>(%2796#0, %cst_1664) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1665 = arith.constant 1.5707963267948966 : f64
    %2798 = qlx.apply #qlx.action<pauli_rotation>(%2796#1, %cst_1665) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1666 = arith.constant 1.5707963267948966 : f64
    %2799:2 = qlx.apply #qlx.action<pauli_rotation>(%2797, %2798, %cst_1666) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2800 = qlx.apply #qlx.action<h>(%2595#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1667 = arith.constant 3.1415926535897931 : f64
    %2801 = qlx.apply #qlx.action<pauli_rotation>(%2800, %cst_1667) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2802 = qlx.apply #qlx.action<h>(%2801) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2803 = qlx.apply #qlx.action<h>(%2799#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1668 = arith.constant 3.1415926535897931 : f64
    %2804 = qlx.apply #qlx.action<pauli_rotation>(%2803, %cst_1668) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2805 = qlx.apply #qlx.action<h>(%2804) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1669 = arith.constant 1.5707963267948966 : f64
    %2806:2 = qlx.apply #qlx.action<pauli_rotation>(%2802, %2805, %cst_1669) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1670 = arith.constant 1.5707963267948966 : f64
    %2807 = qlx.apply #qlx.action<pauli_rotation>(%2806#0, %cst_1670) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1671 = arith.constant 1.5707963267948966 : f64
    %2808 = qlx.apply #qlx.action<pauli_rotation>(%2806#1, %cst_1671) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1672 = arith.constant 1.5707963267948966 : f64
    %2809:2 = qlx.apply #qlx.action<pauli_rotation>(%2807, %2808, %cst_1672) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2810 = qlx.apply #qlx.action<h>(%2605#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1673 = arith.constant 3.1415926535897931 : f64
    %2811 = qlx.apply #qlx.action<pauli_rotation>(%2810, %cst_1673) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2812 = qlx.apply #qlx.action<h>(%2811) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2813 = qlx.apply #qlx.action<h>(%2809#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1674 = arith.constant 3.1415926535897931 : f64
    %2814 = qlx.apply #qlx.action<pauli_rotation>(%2813, %cst_1674) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2815 = qlx.apply #qlx.action<h>(%2814) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1675 = arith.constant 1.5707963267948966 : f64
    %2816:2 = qlx.apply #qlx.action<pauli_rotation>(%2812, %2815, %cst_1675) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1676 = arith.constant 1.5707963267948966 : f64
    %2817 = qlx.apply #qlx.action<pauli_rotation>(%2816#0, %cst_1676) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1677 = arith.constant 1.5707963267948966 : f64
    %2818 = qlx.apply #qlx.action<pauli_rotation>(%2816#1, %cst_1677) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1678 = arith.constant 1.5707963267948966 : f64
    %2819:2 = qlx.apply #qlx.action<pauli_rotation>(%2817, %2818, %cst_1678) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2820 = qlx.apply #qlx.action<h>(%2615#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1679 = arith.constant 3.1415926535897931 : f64
    %2821 = qlx.apply #qlx.action<pauli_rotation>(%2820, %cst_1679) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2822 = qlx.apply #qlx.action<h>(%2821) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2823 = qlx.apply #qlx.action<h>(%2819#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1680 = arith.constant 3.1415926535897931 : f64
    %2824 = qlx.apply #qlx.action<pauli_rotation>(%2823, %cst_1680) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2825 = qlx.apply #qlx.action<h>(%2824) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1681 = arith.constant 1.5707963267948966 : f64
    %2826:2 = qlx.apply #qlx.action<pauli_rotation>(%2822, %2825, %cst_1681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1682 = arith.constant 1.5707963267948966 : f64
    %2827 = qlx.apply #qlx.action<pauli_rotation>(%2826#0, %cst_1682) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1683 = arith.constant 1.5707963267948966 : f64
    %2828 = qlx.apply #qlx.action<pauli_rotation>(%2826#1, %cst_1683) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1684 = arith.constant 1.5707963267948966 : f64
    %2829:2 = qlx.apply #qlx.action<pauli_rotation>(%2827, %2828, %cst_1684) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2830 = qlx.apply #qlx.action<h>(%2625#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1685 = arith.constant 3.1415926535897931 : f64
    %2831 = qlx.apply #qlx.action<pauli_rotation>(%2830, %cst_1685) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2832 = qlx.apply #qlx.action<h>(%2831) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2833 = qlx.apply #qlx.action<h>(%2829#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1686 = arith.constant 3.1415926535897931 : f64
    %2834 = qlx.apply #qlx.action<pauli_rotation>(%2833, %cst_1686) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2835 = qlx.apply #qlx.action<h>(%2834) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1687 = arith.constant 1.5707963267948966 : f64
    %2836:2 = qlx.apply #qlx.action<pauli_rotation>(%2832, %2835, %cst_1687) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1688 = arith.constant 1.5707963267948966 : f64
    %2837 = qlx.apply #qlx.action<pauli_rotation>(%2836#0, %cst_1688) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1689 = arith.constant 1.5707963267948966 : f64
    %2838 = qlx.apply #qlx.action<pauli_rotation>(%2836#1, %cst_1689) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1690 = arith.constant 1.5707963267948966 : f64
    %2839:2 = qlx.apply #qlx.action<pauli_rotation>(%2837, %2838, %cst_1690) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2840 = qlx.apply #qlx.action<h>(%2632#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1691 = arith.constant 3.1415926535897931 : f64
    %2841 = qlx.apply #qlx.action<pauli_rotation>(%2840, %cst_1691) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2842 = qlx.apply #qlx.action<h>(%2841) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2843 = qlx.apply #qlx.action<h>(%2839#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1692 = arith.constant 3.1415926535897931 : f64
    %2844 = qlx.apply #qlx.action<pauli_rotation>(%2843, %cst_1692) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2845 = qlx.apply #qlx.action<h>(%2844) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1693 = arith.constant 1.5707963267948966 : f64
    %2846:2 = qlx.apply #qlx.action<pauli_rotation>(%2842, %2845, %cst_1693) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1694 = arith.constant 1.5707963267948966 : f64
    %2847 = qlx.apply #qlx.action<pauli_rotation>(%2846#0, %cst_1694) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1695 = arith.constant 1.5707963267948966 : f64
    %2848 = qlx.apply #qlx.action<pauli_rotation>(%2846#1, %cst_1695) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1696 = arith.constant 1.5707963267948966 : f64
    %2849:2 = qlx.apply #qlx.action<pauli_rotation>(%2847, %2848, %cst_1696) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2850 = qlx.apply #qlx.action<h>(%2642#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1697 = arith.constant 3.1415926535897931 : f64
    %2851 = qlx.apply #qlx.action<pauli_rotation>(%2850, %cst_1697) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2852 = qlx.apply #qlx.action<h>(%2851) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2853 = qlx.apply #qlx.action<h>(%2849#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1698 = arith.constant 3.1415926535897931 : f64
    %2854 = qlx.apply #qlx.action<pauli_rotation>(%2853, %cst_1698) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2855 = qlx.apply #qlx.action<h>(%2854) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1699 = arith.constant 1.5707963267948966 : f64
    %2856:2 = qlx.apply #qlx.action<pauli_rotation>(%2852, %2855, %cst_1699) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1700 = arith.constant 1.5707963267948966 : f64
    %2857 = qlx.apply #qlx.action<pauli_rotation>(%2856#0, %cst_1700) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1701 = arith.constant 1.5707963267948966 : f64
    %2858 = qlx.apply #qlx.action<pauli_rotation>(%2856#1, %cst_1701) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1702 = arith.constant 1.5707963267948966 : f64
    %2859:2 = qlx.apply #qlx.action<pauli_rotation>(%2857, %2858, %cst_1702) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2860 = qlx.apply #qlx.action<h>(%2652#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1703 = arith.constant 3.1415926535897931 : f64
    %2861 = qlx.apply #qlx.action<pauli_rotation>(%2860, %cst_1703) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2862 = qlx.apply #qlx.action<h>(%2861) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2863 = qlx.apply #qlx.action<h>(%2859#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1704 = arith.constant 3.1415926535897931 : f64
    %2864 = qlx.apply #qlx.action<pauli_rotation>(%2863, %cst_1704) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2865 = qlx.apply #qlx.action<h>(%2864) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1705 = arith.constant 1.5707963267948966 : f64
    %2866:2 = qlx.apply #qlx.action<pauli_rotation>(%2862, %2865, %cst_1705) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1706 = arith.constant 1.5707963267948966 : f64
    %2867 = qlx.apply #qlx.action<pauli_rotation>(%2866#0, %cst_1706) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1707 = arith.constant 1.5707963267948966 : f64
    %2868 = qlx.apply #qlx.action<pauli_rotation>(%2866#1, %cst_1707) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1708 = arith.constant 1.5707963267948966 : f64
    %2869:2 = qlx.apply #qlx.action<pauli_rotation>(%2867, %2868, %cst_1708) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2870 = qlx.apply #qlx.action<h>(%2662#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1709 = arith.constant 3.1415926535897931 : f64
    %2871 = qlx.apply #qlx.action<pauli_rotation>(%2870, %cst_1709) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2872 = qlx.apply #qlx.action<h>(%2871) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2873 = qlx.apply #qlx.action<h>(%2869#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1710 = arith.constant 3.1415926535897931 : f64
    %2874 = qlx.apply #qlx.action<pauli_rotation>(%2873, %cst_1710) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2875 = qlx.apply #qlx.action<h>(%2874) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1711 = arith.constant 1.5707963267948966 : f64
    %2876:2 = qlx.apply #qlx.action<pauli_rotation>(%2872, %2875, %cst_1711) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1712 = arith.constant 1.5707963267948966 : f64
    %2877 = qlx.apply #qlx.action<pauli_rotation>(%2876#0, %cst_1712) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1713 = arith.constant 1.5707963267948966 : f64
    %2878 = qlx.apply #qlx.action<pauli_rotation>(%2876#1, %cst_1713) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1714 = arith.constant 1.5707963267948966 : f64
    %2879:2 = qlx.apply #qlx.action<pauli_rotation>(%2877, %2878, %cst_1714) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2880 = qlx.apply #qlx.action<h>(%2672#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1715 = arith.constant 2.3561944901923448 : f64
    %2881 = qlx.apply #qlx.action<pauli_rotation>(%2880, %cst_1715) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2882 = qlx.apply #qlx.action<h>(%2881) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2883 = qlx.apply #qlx.action<h>(%2879#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1716 = arith.constant 2.3561944901923448 : f64
    %2884 = qlx.apply #qlx.action<pauli_rotation>(%2883, %cst_1716) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2885 = qlx.apply #qlx.action<h>(%2884) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1717 = arith.constant 0.78539816339744828 : f64
    %2886:2 = qlx.apply #qlx.action<pauli_rotation>(%2882, %2885, %cst_1717) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1718 = arith.constant 1.5707963267948966 : f64
    %2887 = qlx.apply #qlx.action<pauli_rotation>(%2886#0, %cst_1718) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1719 = arith.constant 1.5707963267948966 : f64
    %2888 = qlx.apply #qlx.action<pauli_rotation>(%2886#1, %cst_1719) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1720 = arith.constant 0.78539816339744828 : f64
    %2889:2 = qlx.apply #qlx.action<pauli_rotation>(%2887, %2888, %cst_1720) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2890 = qlx.apply #qlx.action<h>(%2679#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1721 = arith.constant 3.1415926535897931 : f64
    %2891 = qlx.apply #qlx.action<pauli_rotation>(%2890, %cst_1721) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2892 = qlx.apply #qlx.action<h>(%2891) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2893 = qlx.apply #qlx.action<h>(%2889#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1722 = arith.constant 2.3561944901923448 : f64
    %2894 = qlx.apply #qlx.action<pauli_rotation>(%2893, %cst_1722) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2895 = qlx.apply #qlx.action<h>(%2894) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1723 = arith.constant 1.5707963267948966 : f64
    %2896:2 = qlx.apply #qlx.action<pauli_rotation>(%2892, %2895, %cst_1723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1724 = arith.constant 1.5707963267948966 : f64
    %2897 = qlx.apply #qlx.action<pauli_rotation>(%2896#0, %cst_1724) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1725 = arith.constant 1.5707963267948966 : f64
    %2898 = qlx.apply #qlx.action<pauli_rotation>(%2896#1, %cst_1725) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1726 = arith.constant 1.5707963267948966 : f64
    %2899:2 = qlx.apply #qlx.action<pauli_rotation>(%2897, %2898, %cst_1726) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2900 = qlx.apply #qlx.action<h>(%2689#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1727 = arith.constant 3.1415926535897931 : f64
    %2901 = qlx.apply #qlx.action<pauli_rotation>(%2900, %cst_1727) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2902 = qlx.apply #qlx.action<h>(%2901) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2903 = qlx.apply #qlx.action<h>(%2899#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1728 = arith.constant 3.1415926535897931 : f64
    %2904 = qlx.apply #qlx.action<pauli_rotation>(%2903, %cst_1728) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2905 = qlx.apply #qlx.action<h>(%2904) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1729 = arith.constant 1.5707963267948966 : f64
    %2906:2 = qlx.apply #qlx.action<pauli_rotation>(%2902, %2905, %cst_1729) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1730 = arith.constant 1.5707963267948966 : f64
    %2907 = qlx.apply #qlx.action<pauli_rotation>(%2906#0, %cst_1730) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1731 = arith.constant 1.5707963267948966 : f64
    %2908 = qlx.apply #qlx.action<pauli_rotation>(%2906#1, %cst_1731) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1732 = arith.constant 1.5707963267948966 : f64
    %2909:2 = qlx.apply #qlx.action<pauli_rotation>(%2907, %2908, %cst_1732) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2910 = qlx.apply #qlx.action<h>(%2699#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1733 = arith.constant 3.1415926535897931 : f64
    %2911 = qlx.apply #qlx.action<pauli_rotation>(%2910, %cst_1733) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2912 = qlx.apply #qlx.action<h>(%2911) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2913 = qlx.apply #qlx.action<h>(%2909#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1734 = arith.constant 3.1415926535897931 : f64
    %2914 = qlx.apply #qlx.action<pauli_rotation>(%2913, %cst_1734) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2915 = qlx.apply #qlx.action<h>(%2914) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1735 = arith.constant 1.5707963267948966 : f64
    %2916:2 = qlx.apply #qlx.action<pauli_rotation>(%2912, %2915, %cst_1735) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1736 = arith.constant 1.5707963267948966 : f64
    %2917 = qlx.apply #qlx.action<pauli_rotation>(%2916#0, %cst_1736) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1737 = arith.constant 1.5707963267948966 : f64
    %2918 = qlx.apply #qlx.action<pauli_rotation>(%2916#1, %cst_1737) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1738 = arith.constant 1.5707963267948966 : f64
    %2919:2 = qlx.apply #qlx.action<pauli_rotation>(%2917, %2918, %cst_1738) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2920 = qlx.apply #qlx.action<h>(%2709#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1739 = arith.constant 3.1415926535897931 : f64
    %2921 = qlx.apply #qlx.action<pauli_rotation>(%2920, %cst_1739) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2922 = qlx.apply #qlx.action<h>(%2921) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2923 = qlx.apply #qlx.action<h>(%2919#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1740 = arith.constant 3.1415926535897931 : f64
    %2924 = qlx.apply #qlx.action<pauli_rotation>(%2923, %cst_1740) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2925 = qlx.apply #qlx.action<h>(%2924) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1741 = arith.constant 1.5707963267948966 : f64
    %2926:2 = qlx.apply #qlx.action<pauli_rotation>(%2922, %2925, %cst_1741) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1742 = arith.constant 1.5707963267948966 : f64
    %2927 = qlx.apply #qlx.action<pauli_rotation>(%2926#0, %cst_1742) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1743 = arith.constant 1.5707963267948966 : f64
    %2928 = qlx.apply #qlx.action<pauli_rotation>(%2926#1, %cst_1743) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1744 = arith.constant 1.5707963267948966 : f64
    %2929:2 = qlx.apply #qlx.action<pauli_rotation>(%2927, %2928, %cst_1744) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2930 = qlx.apply #qlx.action<h>(%2719#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1745 = arith.constant 3.1415926535897931 : f64
    %2931 = qlx.apply #qlx.action<pauli_rotation>(%2930, %cst_1745) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2932 = qlx.apply #qlx.action<h>(%2931) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2933 = qlx.apply #qlx.action<h>(%2929#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1746 = arith.constant 3.1415926535897931 : f64
    %2934 = qlx.apply #qlx.action<pauli_rotation>(%2933, %cst_1746) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2935 = qlx.apply #qlx.action<h>(%2934) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1747 = arith.constant 1.5707963267948966 : f64
    %2936:2 = qlx.apply #qlx.action<pauli_rotation>(%2932, %2935, %cst_1747) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1748 = arith.constant 1.5707963267948966 : f64
    %2937 = qlx.apply #qlx.action<pauli_rotation>(%2936#0, %cst_1748) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1749 = arith.constant 1.5707963267948966 : f64
    %2938 = qlx.apply #qlx.action<pauli_rotation>(%2936#1, %cst_1749) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1750 = arith.constant 1.5707963267948966 : f64
    %2939:2 = qlx.apply #qlx.action<pauli_rotation>(%2937, %2938, %cst_1750) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2940 = qlx.apply #qlx.action<h>(%2729#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1751 = arith.constant 3.1415926535897931 : f64
    %2941 = qlx.apply #qlx.action<pauli_rotation>(%2940, %cst_1751) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2942 = qlx.apply #qlx.action<h>(%2941) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2943 = qlx.apply #qlx.action<h>(%2939#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1752 = arith.constant 3.1415926535897931 : f64
    %2944 = qlx.apply #qlx.action<pauli_rotation>(%2943, %cst_1752) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2945 = qlx.apply #qlx.action<h>(%2944) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1753 = arith.constant 1.5707963267948966 : f64
    %2946:2 = qlx.apply #qlx.action<pauli_rotation>(%2942, %2945, %cst_1753) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1754 = arith.constant 1.5707963267948966 : f64
    %2947 = qlx.apply #qlx.action<pauli_rotation>(%2946#0, %cst_1754) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1755 = arith.constant 1.5707963267948966 : f64
    %2948 = qlx.apply #qlx.action<pauli_rotation>(%2946#1, %cst_1755) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1756 = arith.constant 1.5707963267948966 : f64
    %2949:2 = qlx.apply #qlx.action<pauli_rotation>(%2947, %2948, %cst_1756) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2950 = qlx.apply #qlx.action<h>(%2739#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1757 = arith.constant 3.1415926535897931 : f64
    %2951 = qlx.apply #qlx.action<pauli_rotation>(%2950, %cst_1757) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2952 = qlx.apply #qlx.action<h>(%2951) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2953 = qlx.apply #qlx.action<h>(%2949#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1758 = arith.constant 3.1415926535897931 : f64
    %2954 = qlx.apply #qlx.action<pauli_rotation>(%2953, %cst_1758) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2955 = qlx.apply #qlx.action<h>(%2954) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1759 = arith.constant 1.5707963267948966 : f64
    %2956:2 = qlx.apply #qlx.action<pauli_rotation>(%2952, %2955, %cst_1759) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1760 = arith.constant 1.5707963267948966 : f64
    %2957 = qlx.apply #qlx.action<pauli_rotation>(%2956#0, %cst_1760) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1761 = arith.constant 1.5707963267948966 : f64
    %2958 = qlx.apply #qlx.action<pauli_rotation>(%2956#1, %cst_1761) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1762 = arith.constant 1.5707963267948966 : f64
    %2959:2 = qlx.apply #qlx.action<pauli_rotation>(%2957, %2958, %cst_1762) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2960 = qlx.apply #qlx.action<h>(%2749#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1763 = arith.constant 3.1415926535897931 : f64
    %2961 = qlx.apply #qlx.action<pauli_rotation>(%2960, %cst_1763) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2962 = qlx.apply #qlx.action<h>(%2961) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2963 = qlx.apply #qlx.action<h>(%2959#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1764 = arith.constant 3.1415926535897931 : f64
    %2964 = qlx.apply #qlx.action<pauli_rotation>(%2963, %cst_1764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2965 = qlx.apply #qlx.action<h>(%2964) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1765 = arith.constant 1.5707963267948966 : f64
    %2966:2 = qlx.apply #qlx.action<pauli_rotation>(%2962, %2965, %cst_1765) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1766 = arith.constant 1.5707963267948966 : f64
    %2967 = qlx.apply #qlx.action<pauli_rotation>(%2966#0, %cst_1766) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1767 = arith.constant 1.5707963267948966 : f64
    %2968 = qlx.apply #qlx.action<pauli_rotation>(%2966#1, %cst_1767) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1768 = arith.constant 1.5707963267948966 : f64
    %2969:2 = qlx.apply #qlx.action<pauli_rotation>(%2967, %2968, %cst_1768) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2970 = qlx.apply #qlx.action<h>(%2759#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1769 = arith.constant 3.1415926535897931 : f64
    %2971 = qlx.apply #qlx.action<pauli_rotation>(%2970, %cst_1769) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2972 = qlx.apply #qlx.action<h>(%2971) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2973 = qlx.apply #qlx.action<h>(%2969#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1770 = arith.constant 3.1415926535897931 : f64
    %2974 = qlx.apply #qlx.action<pauli_rotation>(%2973, %cst_1770) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2975 = qlx.apply #qlx.action<h>(%2974) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1771 = arith.constant 1.5707963267948966 : f64
    %2976:2 = qlx.apply #qlx.action<pauli_rotation>(%2972, %2975, %cst_1771) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1772 = arith.constant 1.5707963267948966 : f64
    %2977 = qlx.apply #qlx.action<pauli_rotation>(%2976#0, %cst_1772) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1773 = arith.constant 1.5707963267948966 : f64
    %2978 = qlx.apply #qlx.action<pauli_rotation>(%2976#1, %cst_1773) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1774 = arith.constant 1.5707963267948966 : f64
    %2979:2 = qlx.apply #qlx.action<pauli_rotation>(%2977, %2978, %cst_1774) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2980 = qlx.apply #qlx.action<h>(%2769#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1775 = arith.constant 3.1415926535897931 : f64
    %2981 = qlx.apply #qlx.action<pauli_rotation>(%2980, %cst_1775) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2982 = qlx.apply #qlx.action<h>(%2981) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2983 = qlx.apply #qlx.action<h>(%2979#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1776 = arith.constant 3.1415926535897931 : f64
    %2984 = qlx.apply #qlx.action<pauli_rotation>(%2983, %cst_1776) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2985 = qlx.apply #qlx.action<h>(%2984) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1777 = arith.constant 1.5707963267948966 : f64
    %2986:2 = qlx.apply #qlx.action<pauli_rotation>(%2982, %2985, %cst_1777) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1778 = arith.constant 1.5707963267948966 : f64
    %2987 = qlx.apply #qlx.action<pauli_rotation>(%2986#0, %cst_1778) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1779 = arith.constant 1.5707963267948966 : f64
    %2988 = qlx.apply #qlx.action<pauli_rotation>(%2986#1, %cst_1779) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1780 = arith.constant 1.5707963267948966 : f64
    %2989:2 = qlx.apply #qlx.action<pauli_rotation>(%2987, %2988, %cst_1780) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2990 = qlx.apply #qlx.action<h>(%2779#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1781 = arith.constant 3.1415926535897931 : f64
    %2991 = qlx.apply #qlx.action<pauli_rotation>(%2990, %cst_1781) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2992 = qlx.apply #qlx.action<h>(%2991) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2993 = qlx.apply #qlx.action<h>(%2989#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1782 = arith.constant 3.1415926535897931 : f64
    %2994 = qlx.apply #qlx.action<pauli_rotation>(%2993, %cst_1782) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2995 = qlx.apply #qlx.action<h>(%2994) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1783 = arith.constant 1.5707963267948966 : f64
    %2996:2 = qlx.apply #qlx.action<pauli_rotation>(%2992, %2995, %cst_1783) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1784 = arith.constant 1.5707963267948966 : f64
    %2997 = qlx.apply #qlx.action<pauli_rotation>(%2996#0, %cst_1784) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1785 = arith.constant 1.5707963267948966 : f64
    %2998 = qlx.apply #qlx.action<pauli_rotation>(%2996#1, %cst_1785) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1786 = arith.constant 1.5707963267948966 : f64
    %2999:2 = qlx.apply #qlx.action<pauli_rotation>(%2997, %2998, %cst_1786) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3000 = qlx.apply #qlx.action<h>(%2789#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1787 = arith.constant 2.3561944901923448 : f64
    %3001 = qlx.apply #qlx.action<pauli_rotation>(%3000, %cst_1787) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3002 = qlx.apply #qlx.action<h>(%3001) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3003 = qlx.apply #qlx.action<h>(%2999#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1788 = arith.constant 1.5707963267948966 : f64
    %3004 = qlx.apply #qlx.action<pauli_rotation>(%3003, %cst_1788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3005 = qlx.apply #qlx.action<h>(%3004) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1789 = arith.constant 1.000000e+00 : f64
    %3006:2 = qlx.apply #qlx.action<pauli_rotation>(%3002, %3005, %cst_1789) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1790 = arith.constant 1.5707963267948966 : f64
    %3007 = qlx.apply #qlx.action<pauli_rotation>(%3006#0, %cst_1790) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1791 = arith.constant 1.5707963267948966 : f64
    %3008 = qlx.apply #qlx.action<pauli_rotation>(%3006#1, %cst_1791) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1792 = arith.constant 1.000000e+00 : f64
    %3009:2 = qlx.apply #qlx.action<pauli_rotation>(%3007, %3008, %cst_1792) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3010 = qlx.apply #qlx.action<h>(%2789#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1793 = arith.constant 1.5707963267948966 : f64
    %3011 = qlx.apply #qlx.action<pauli_rotation>(%3010, %cst_1793) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3012 = qlx.apply #qlx.action<h>(%3011) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3013 = qlx.apply #qlx.action<h>(%3009#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1794 = arith.constant 0.78539816339744828 : f64
    %3014 = qlx.apply #qlx.action<pauli_rotation>(%3013, %cst_1794) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3015 = qlx.apply #qlx.action<h>(%3014) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1795 = arith.constant 0.78539816339744828 : f64
    %3016:2 = qlx.apply #qlx.action<pauli_rotation>(%3012, %3015, %cst_1795) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1796 = arith.constant 1.5707963267948966 : f64
    %3017 = qlx.apply #qlx.action<pauli_rotation>(%3016#0, %cst_1796) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1797 = arith.constant 1.5707963267948966 : f64
    %3018 = qlx.apply #qlx.action<pauli_rotation>(%3016#1, %cst_1797) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1798 = arith.constant 0.78539816339744828 : f64
    %3019:2 = qlx.apply #qlx.action<pauli_rotation>(%3017, %3018, %cst_1798) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3020 = qlx.apply #qlx.action<h>(%2531#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1799 = arith.constant 3.1415926535897931 : f64
    %3021 = qlx.apply #qlx.action<pauli_rotation>(%3020, %cst_1799) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3022 = qlx.apply #qlx.action<h>(%3021) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3023 = qlx.apply #qlx.action<h>(%2491#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1800 = arith.constant 3.1415926535897931 : f64
    %3024 = qlx.apply #qlx.action<pauli_rotation>(%3023, %cst_1800) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3025 = qlx.apply #qlx.action<h>(%3024) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1801 = arith.constant 1.5707963267948966 : f64
    %3026:2 = qlx.apply #qlx.action<pauli_rotation>(%3022, %3025, %cst_1801) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1802 = arith.constant 1.5707963267948966 : f64
    %3027 = qlx.apply #qlx.action<pauli_rotation>(%3026#0, %cst_1802) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1803 = arith.constant 1.5707963267948966 : f64
    %3028 = qlx.apply #qlx.action<pauli_rotation>(%3026#1, %cst_1803) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1804 = arith.constant 1.5707963267948966 : f64
    %3029:2 = qlx.apply #qlx.action<pauli_rotation>(%3027, %3028, %cst_1804) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3030 = qlx.apply #qlx.action<h>(%2541#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1805 = arith.constant 3.1415926535897931 : f64
    %3031 = qlx.apply #qlx.action<pauli_rotation>(%3030, %cst_1805) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3032 = qlx.apply #qlx.action<h>(%3031) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3033 = qlx.apply #qlx.action<h>(%3029#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1806 = arith.constant 3.1415926535897931 : f64
    %3034 = qlx.apply #qlx.action<pauli_rotation>(%3033, %cst_1806) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3035 = qlx.apply #qlx.action<h>(%3034) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1807 = arith.constant 1.5707963267948966 : f64
    %3036:2 = qlx.apply #qlx.action<pauli_rotation>(%3032, %3035, %cst_1807) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1808 = arith.constant 1.5707963267948966 : f64
    %3037 = qlx.apply #qlx.action<pauli_rotation>(%3036#0, %cst_1808) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1809 = arith.constant 1.5707963267948966 : f64
    %3038 = qlx.apply #qlx.action<pauli_rotation>(%3036#1, %cst_1809) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1810 = arith.constant 1.5707963267948966 : f64
    %3039:2 = qlx.apply #qlx.action<pauli_rotation>(%3037, %3038, %cst_1810) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3040 = qlx.apply #qlx.action<h>(%2548#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1811 = arith.constant 3.1415926535897931 : f64
    %3041 = qlx.apply #qlx.action<pauli_rotation>(%3040, %cst_1811) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3042 = qlx.apply #qlx.action<h>(%3041) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3043 = qlx.apply #qlx.action<h>(%3039#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1812 = arith.constant 3.1415926535897931 : f64
    %3044 = qlx.apply #qlx.action<pauli_rotation>(%3043, %cst_1812) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3045 = qlx.apply #qlx.action<h>(%3044) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1813 = arith.constant 1.5707963267948966 : f64
    %3046:2 = qlx.apply #qlx.action<pauli_rotation>(%3042, %3045, %cst_1813) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1814 = arith.constant 1.5707963267948966 : f64
    %3047 = qlx.apply #qlx.action<pauli_rotation>(%3046#0, %cst_1814) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1815 = arith.constant 1.5707963267948966 : f64
    %3048 = qlx.apply #qlx.action<pauli_rotation>(%3046#1, %cst_1815) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1816 = arith.constant 1.5707963267948966 : f64
    %3049:2 = qlx.apply #qlx.action<pauli_rotation>(%3047, %3048, %cst_1816) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3050 = qlx.apply #qlx.action<h>(%2558#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1817 = arith.constant 3.1415926535897931 : f64
    %3051 = qlx.apply #qlx.action<pauli_rotation>(%3050, %cst_1817) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3052 = qlx.apply #qlx.action<h>(%3051) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3053 = qlx.apply #qlx.action<h>(%3049#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1818 = arith.constant 3.1415926535897931 : f64
    %3054 = qlx.apply #qlx.action<pauli_rotation>(%3053, %cst_1818) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3055 = qlx.apply #qlx.action<h>(%3054) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1819 = arith.constant 1.5707963267948966 : f64
    %3056:2 = qlx.apply #qlx.action<pauli_rotation>(%3052, %3055, %cst_1819) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1820 = arith.constant 1.5707963267948966 : f64
    %3057 = qlx.apply #qlx.action<pauli_rotation>(%3056#0, %cst_1820) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1821 = arith.constant 1.5707963267948966 : f64
    %3058 = qlx.apply #qlx.action<pauli_rotation>(%3056#1, %cst_1821) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1822 = arith.constant 1.5707963267948966 : f64
    %3059:2 = qlx.apply #qlx.action<pauli_rotation>(%3057, %3058, %cst_1822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3060 = qlx.apply #qlx.action<h>(%2568#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1823 = arith.constant 3.1415926535897931 : f64
    %3061 = qlx.apply #qlx.action<pauli_rotation>(%3060, %cst_1823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3062 = qlx.apply #qlx.action<h>(%3061) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3063 = qlx.apply #qlx.action<h>(%3059#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1824 = arith.constant 3.1415926535897931 : f64
    %3064 = qlx.apply #qlx.action<pauli_rotation>(%3063, %cst_1824) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3065 = qlx.apply #qlx.action<h>(%3064) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1825 = arith.constant 1.5707963267948966 : f64
    %3066:2 = qlx.apply #qlx.action<pauli_rotation>(%3062, %3065, %cst_1825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1826 = arith.constant 1.5707963267948966 : f64
    %3067 = qlx.apply #qlx.action<pauli_rotation>(%3066#0, %cst_1826) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1827 = arith.constant 1.5707963267948966 : f64
    %3068 = qlx.apply #qlx.action<pauli_rotation>(%3066#1, %cst_1827) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1828 = arith.constant 1.5707963267948966 : f64
    %3069:2 = qlx.apply #qlx.action<pauli_rotation>(%3067, %3068, %cst_1828) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3070 = qlx.apply #qlx.action<h>(%2799#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1829 = arith.constant 3.1415926535897931 : f64
    %3071 = qlx.apply #qlx.action<pauli_rotation>(%3070, %cst_1829) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3072 = qlx.apply #qlx.action<h>(%3071) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3073 = qlx.apply #qlx.action<h>(%3069#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1830 = arith.constant 3.1415926535897931 : f64
    %3074 = qlx.apply #qlx.action<pauli_rotation>(%3073, %cst_1830) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3075 = qlx.apply #qlx.action<h>(%3074) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1831 = arith.constant 1.5707963267948966 : f64
    %3076:2 = qlx.apply #qlx.action<pauli_rotation>(%3072, %3075, %cst_1831) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1832 = arith.constant 1.5707963267948966 : f64
    %3077 = qlx.apply #qlx.action<pauli_rotation>(%3076#0, %cst_1832) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1833 = arith.constant 1.5707963267948966 : f64
    %3078 = qlx.apply #qlx.action<pauli_rotation>(%3076#1, %cst_1833) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1834 = arith.constant 1.5707963267948966 : f64
    %3079:2 = qlx.apply #qlx.action<pauli_rotation>(%3077, %3078, %cst_1834) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3080 = qlx.apply #qlx.action<h>(%2809#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1835 = arith.constant 3.1415926535897931 : f64
    %3081 = qlx.apply #qlx.action<pauli_rotation>(%3080, %cst_1835) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3082 = qlx.apply #qlx.action<h>(%3081) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3083 = qlx.apply #qlx.action<h>(%3079#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1836 = arith.constant 3.1415926535897931 : f64
    %3084 = qlx.apply #qlx.action<pauli_rotation>(%3083, %cst_1836) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3085 = qlx.apply #qlx.action<h>(%3084) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1837 = arith.constant 1.5707963267948966 : f64
    %3086:2 = qlx.apply #qlx.action<pauli_rotation>(%3082, %3085, %cst_1837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1838 = arith.constant 1.5707963267948966 : f64
    %3087 = qlx.apply #qlx.action<pauli_rotation>(%3086#0, %cst_1838) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1839 = arith.constant 1.5707963267948966 : f64
    %3088 = qlx.apply #qlx.action<pauli_rotation>(%3086#1, %cst_1839) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1840 = arith.constant 1.5707963267948966 : f64
    %3089:2 = qlx.apply #qlx.action<pauli_rotation>(%3087, %3088, %cst_1840) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3090 = qlx.apply #qlx.action<h>(%2819#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1841 = arith.constant 3.1415926535897931 : f64
    %3091 = qlx.apply #qlx.action<pauli_rotation>(%3090, %cst_1841) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3092 = qlx.apply #qlx.action<h>(%3091) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3093 = qlx.apply #qlx.action<h>(%3089#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1842 = arith.constant 3.1415926535897931 : f64
    %3094 = qlx.apply #qlx.action<pauli_rotation>(%3093, %cst_1842) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3095 = qlx.apply #qlx.action<h>(%3094) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1843 = arith.constant 1.5707963267948966 : f64
    %3096:2 = qlx.apply #qlx.action<pauli_rotation>(%3092, %3095, %cst_1843) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1844 = arith.constant 1.5707963267948966 : f64
    %3097 = qlx.apply #qlx.action<pauli_rotation>(%3096#0, %cst_1844) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1845 = arith.constant 1.5707963267948966 : f64
    %3098 = qlx.apply #qlx.action<pauli_rotation>(%3096#1, %cst_1845) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1846 = arith.constant 1.5707963267948966 : f64
    %3099:2 = qlx.apply #qlx.action<pauli_rotation>(%3097, %3098, %cst_1846) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3100 = qlx.apply #qlx.action<h>(%2829#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1847 = arith.constant 3.1415926535897931 : f64
    %3101 = qlx.apply #qlx.action<pauli_rotation>(%3100, %cst_1847) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3102 = qlx.apply #qlx.action<h>(%3101) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3103 = qlx.apply #qlx.action<h>(%3099#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1848 = arith.constant 3.1415926535897931 : f64
    %3104 = qlx.apply #qlx.action<pauli_rotation>(%3103, %cst_1848) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3105 = qlx.apply #qlx.action<h>(%3104) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1849 = arith.constant 1.5707963267948966 : f64
    %3106:2 = qlx.apply #qlx.action<pauli_rotation>(%3102, %3105, %cst_1849) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1850 = arith.constant 1.5707963267948966 : f64
    %3107 = qlx.apply #qlx.action<pauli_rotation>(%3106#0, %cst_1850) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1851 = arith.constant 1.5707963267948966 : f64
    %3108 = qlx.apply #qlx.action<pauli_rotation>(%3106#1, %cst_1851) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1852 = arith.constant 1.5707963267948966 : f64
    %3109:2 = qlx.apply #qlx.action<pauli_rotation>(%3107, %3108, %cst_1852) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3110 = qlx.apply #qlx.action<h>(%2839#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1853 = arith.constant 3.1415926535897931 : f64
    %3111 = qlx.apply #qlx.action<pauli_rotation>(%3110, %cst_1853) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3112 = qlx.apply #qlx.action<h>(%3111) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3113 = qlx.apply #qlx.action<h>(%3109#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1854 = arith.constant 3.1415926535897931 : f64
    %3114 = qlx.apply #qlx.action<pauli_rotation>(%3113, %cst_1854) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3115 = qlx.apply #qlx.action<h>(%3114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1855 = arith.constant 1.5707963267948966 : f64
    %3116:2 = qlx.apply #qlx.action<pauli_rotation>(%3112, %3115, %cst_1855) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1856 = arith.constant 1.5707963267948966 : f64
    %3117 = qlx.apply #qlx.action<pauli_rotation>(%3116#0, %cst_1856) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1857 = arith.constant 1.5707963267948966 : f64
    %3118 = qlx.apply #qlx.action<pauli_rotation>(%3116#1, %cst_1857) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1858 = arith.constant 1.5707963267948966 : f64
    %3119:2 = qlx.apply #qlx.action<pauli_rotation>(%3117, %3118, %cst_1858) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3120 = qlx.apply #qlx.action<h>(%2849#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1859 = arith.constant 3.1415926535897931 : f64
    %3121 = qlx.apply #qlx.action<pauli_rotation>(%3120, %cst_1859) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3122 = qlx.apply #qlx.action<h>(%3121) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3123 = qlx.apply #qlx.action<h>(%3119#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1860 = arith.constant 3.1415926535897931 : f64
    %3124 = qlx.apply #qlx.action<pauli_rotation>(%3123, %cst_1860) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3125 = qlx.apply #qlx.action<h>(%3124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1861 = arith.constant 1.5707963267948966 : f64
    %3126:2 = qlx.apply #qlx.action<pauli_rotation>(%3122, %3125, %cst_1861) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1862 = arith.constant 1.5707963267948966 : f64
    %3127 = qlx.apply #qlx.action<pauli_rotation>(%3126#0, %cst_1862) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1863 = arith.constant 1.5707963267948966 : f64
    %3128 = qlx.apply #qlx.action<pauli_rotation>(%3126#1, %cst_1863) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1864 = arith.constant 1.5707963267948966 : f64
    %3129:2 = qlx.apply #qlx.action<pauli_rotation>(%3127, %3128, %cst_1864) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3130 = qlx.apply #qlx.action<h>(%2859#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1865 = arith.constant 3.1415926535897931 : f64
    %3131 = qlx.apply #qlx.action<pauli_rotation>(%3130, %cst_1865) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3132 = qlx.apply #qlx.action<h>(%3131) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3133 = qlx.apply #qlx.action<h>(%3129#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1866 = arith.constant 3.1415926535897931 : f64
    %3134 = qlx.apply #qlx.action<pauli_rotation>(%3133, %cst_1866) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3135 = qlx.apply #qlx.action<h>(%3134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1867 = arith.constant 1.5707963267948966 : f64
    %3136:2 = qlx.apply #qlx.action<pauli_rotation>(%3132, %3135, %cst_1867) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1868 = arith.constant 1.5707963267948966 : f64
    %3137 = qlx.apply #qlx.action<pauli_rotation>(%3136#0, %cst_1868) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1869 = arith.constant 1.5707963267948966 : f64
    %3138 = qlx.apply #qlx.action<pauli_rotation>(%3136#1, %cst_1869) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1870 = arith.constant 1.5707963267948966 : f64
    %3139:2 = qlx.apply #qlx.action<pauli_rotation>(%3137, %3138, %cst_1870) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3140 = qlx.apply #qlx.action<h>(%2869#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1871 = arith.constant 3.1415926535897931 : f64
    %3141 = qlx.apply #qlx.action<pauli_rotation>(%3140, %cst_1871) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3142 = qlx.apply #qlx.action<h>(%3141) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3143 = qlx.apply #qlx.action<h>(%3139#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1872 = arith.constant 3.1415926535897931 : f64
    %3144 = qlx.apply #qlx.action<pauli_rotation>(%3143, %cst_1872) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3145 = qlx.apply #qlx.action<h>(%3144) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1873 = arith.constant 1.5707963267948966 : f64
    %3146:2 = qlx.apply #qlx.action<pauli_rotation>(%3142, %3145, %cst_1873) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1874 = arith.constant 1.5707963267948966 : f64
    %3147 = qlx.apply #qlx.action<pauli_rotation>(%3146#0, %cst_1874) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1875 = arith.constant 1.5707963267948966 : f64
    %3148 = qlx.apply #qlx.action<pauli_rotation>(%3146#1, %cst_1875) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1876 = arith.constant 1.5707963267948966 : f64
    %3149:2 = qlx.apply #qlx.action<pauli_rotation>(%3147, %3148, %cst_1876) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3150 = qlx.apply #qlx.action<h>(%2879#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1877 = arith.constant 3.1415926535897931 : f64
    %3151 = qlx.apply #qlx.action<pauli_rotation>(%3150, %cst_1877) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3152 = qlx.apply #qlx.action<h>(%3151) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3153 = qlx.apply #qlx.action<h>(%3149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1878 = arith.constant 3.1415926535897931 : f64
    %3154 = qlx.apply #qlx.action<pauli_rotation>(%3153, %cst_1878) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3155 = qlx.apply #qlx.action<h>(%3154) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1879 = arith.constant 1.5707963267948966 : f64
    %3156:2 = qlx.apply #qlx.action<pauli_rotation>(%3152, %3155, %cst_1879) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1880 = arith.constant 1.5707963267948966 : f64
    %3157 = qlx.apply #qlx.action<pauli_rotation>(%3156#0, %cst_1880) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1881 = arith.constant 1.5707963267948966 : f64
    %3158 = qlx.apply #qlx.action<pauli_rotation>(%3156#1, %cst_1881) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1882 = arith.constant 1.5707963267948966 : f64
    %3159:2 = qlx.apply #qlx.action<pauli_rotation>(%3157, %3158, %cst_1882) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3160 = qlx.apply #qlx.action<h>(%2889#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1883 = arith.constant 2.3561944901923448 : f64
    %3161 = qlx.apply #qlx.action<pauli_rotation>(%3160, %cst_1883) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3162 = qlx.apply #qlx.action<h>(%3161) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3163 = qlx.apply #qlx.action<h>(%3159#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1884 = arith.constant 3.1415926535897931 : f64
    %3164 = qlx.apply #qlx.action<pauli_rotation>(%3163, %cst_1884) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3165 = qlx.apply #qlx.action<h>(%3164) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1885 = arith.constant 1.5707963267948966 : f64
    %3166:2 = qlx.apply #qlx.action<pauli_rotation>(%3162, %3165, %cst_1885) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1886 = arith.constant 1.5707963267948966 : f64
    %3167 = qlx.apply #qlx.action<pauli_rotation>(%3166#0, %cst_1886) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1887 = arith.constant 1.5707963267948966 : f64
    %3168 = qlx.apply #qlx.action<pauli_rotation>(%3166#1, %cst_1887) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1888 = arith.constant 1.5707963267948966 : f64
    %3169:2 = qlx.apply #qlx.action<pauli_rotation>(%3167, %3168, %cst_1888) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3170 = qlx.apply #qlx.action<h>(%2899#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1889 = arith.constant 3.1415926535897931 : f64
    %3171 = qlx.apply #qlx.action<pauli_rotation>(%3170, %cst_1889) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3172 = qlx.apply #qlx.action<h>(%3171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3173 = qlx.apply #qlx.action<h>(%3169#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1890 = arith.constant 3.1415926535897931 : f64
    %3174 = qlx.apply #qlx.action<pauli_rotation>(%3173, %cst_1890) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3175 = qlx.apply #qlx.action<h>(%3174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1891 = arith.constant 1.5707963267948966 : f64
    %3176:2 = qlx.apply #qlx.action<pauli_rotation>(%3172, %3175, %cst_1891) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1892 = arith.constant 1.5707963267948966 : f64
    %3177 = qlx.apply #qlx.action<pauli_rotation>(%3176#0, %cst_1892) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1893 = arith.constant 1.5707963267948966 : f64
    %3178 = qlx.apply #qlx.action<pauli_rotation>(%3176#1, %cst_1893) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1894 = arith.constant 1.5707963267948966 : f64
    %3179:2 = qlx.apply #qlx.action<pauli_rotation>(%3177, %3178, %cst_1894) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3180 = qlx.apply #qlx.action<h>(%2909#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1895 = arith.constant 3.1415926535897931 : f64
    %3181 = qlx.apply #qlx.action<pauli_rotation>(%3180, %cst_1895) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3182 = qlx.apply #qlx.action<h>(%3181) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3183 = qlx.apply #qlx.action<h>(%3179#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1896 = arith.constant 3.1415926535897931 : f64
    %3184 = qlx.apply #qlx.action<pauli_rotation>(%3183, %cst_1896) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3185 = qlx.apply #qlx.action<h>(%3184) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1897 = arith.constant 1.5707963267948966 : f64
    %3186:2 = qlx.apply #qlx.action<pauli_rotation>(%3182, %3185, %cst_1897) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1898 = arith.constant 1.5707963267948966 : f64
    %3187 = qlx.apply #qlx.action<pauli_rotation>(%3186#0, %cst_1898) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1899 = arith.constant 1.5707963267948966 : f64
    %3188 = qlx.apply #qlx.action<pauli_rotation>(%3186#1, %cst_1899) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1900 = arith.constant 1.5707963267948966 : f64
    %3189:2 = qlx.apply #qlx.action<pauli_rotation>(%3187, %3188, %cst_1900) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3190 = qlx.apply #qlx.action<h>(%2919#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1901 = arith.constant 3.1415926535897931 : f64
    %3191 = qlx.apply #qlx.action<pauli_rotation>(%3190, %cst_1901) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3192 = qlx.apply #qlx.action<h>(%3191) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3193 = qlx.apply #qlx.action<h>(%3189#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1902 = arith.constant 3.1415926535897931 : f64
    %3194 = qlx.apply #qlx.action<pauli_rotation>(%3193, %cst_1902) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3195 = qlx.apply #qlx.action<h>(%3194) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1903 = arith.constant 1.5707963267948966 : f64
    %3196:2 = qlx.apply #qlx.action<pauli_rotation>(%3192, %3195, %cst_1903) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1904 = arith.constant 1.5707963267948966 : f64
    %3197 = qlx.apply #qlx.action<pauli_rotation>(%3196#0, %cst_1904) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1905 = arith.constant 1.5707963267948966 : f64
    %3198 = qlx.apply #qlx.action<pauli_rotation>(%3196#1, %cst_1905) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1906 = arith.constant 1.5707963267948966 : f64
    %3199:2 = qlx.apply #qlx.action<pauli_rotation>(%3197, %3198, %cst_1906) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3200 = qlx.apply #qlx.action<h>(%2929#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1907 = arith.constant 3.1415926535897931 : f64
    %3201 = qlx.apply #qlx.action<pauli_rotation>(%3200, %cst_1907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3202 = qlx.apply #qlx.action<h>(%3201) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3203 = qlx.apply #qlx.action<h>(%3199#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1908 = arith.constant 3.1415926535897931 : f64
    %3204 = qlx.apply #qlx.action<pauli_rotation>(%3203, %cst_1908) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3205 = qlx.apply #qlx.action<h>(%3204) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1909 = arith.constant 1.5707963267948966 : f64
    %3206:2 = qlx.apply #qlx.action<pauli_rotation>(%3202, %3205, %cst_1909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1910 = arith.constant 1.5707963267948966 : f64
    %3207 = qlx.apply #qlx.action<pauli_rotation>(%3206#0, %cst_1910) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1911 = arith.constant 1.5707963267948966 : f64
    %3208 = qlx.apply #qlx.action<pauli_rotation>(%3206#1, %cst_1911) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1912 = arith.constant 1.5707963267948966 : f64
    %3209:2 = qlx.apply #qlx.action<pauli_rotation>(%3207, %3208, %cst_1912) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3210 = qlx.apply #qlx.action<h>(%2939#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1913 = arith.constant 3.1415926535897931 : f64
    %3211 = qlx.apply #qlx.action<pauli_rotation>(%3210, %cst_1913) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3212 = qlx.apply #qlx.action<h>(%3211) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3213 = qlx.apply #qlx.action<h>(%3209#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1914 = arith.constant 3.1415926535897931 : f64
    %3214 = qlx.apply #qlx.action<pauli_rotation>(%3213, %cst_1914) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3215 = qlx.apply #qlx.action<h>(%3214) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1915 = arith.constant 1.5707963267948966 : f64
    %3216:2 = qlx.apply #qlx.action<pauli_rotation>(%3212, %3215, %cst_1915) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1916 = arith.constant 1.5707963267948966 : f64
    %3217 = qlx.apply #qlx.action<pauli_rotation>(%3216#0, %cst_1916) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1917 = arith.constant 1.5707963267948966 : f64
    %3218 = qlx.apply #qlx.action<pauli_rotation>(%3216#1, %cst_1917) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1918 = arith.constant 1.5707963267948966 : f64
    %3219:2 = qlx.apply #qlx.action<pauli_rotation>(%3217, %3218, %cst_1918) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3220 = qlx.apply #qlx.action<h>(%2949#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1919 = arith.constant 3.1415926535897931 : f64
    %3221 = qlx.apply #qlx.action<pauli_rotation>(%3220, %cst_1919) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3222 = qlx.apply #qlx.action<h>(%3221) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3223 = qlx.apply #qlx.action<h>(%3219#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1920 = arith.constant 3.1415926535897931 : f64
    %3224 = qlx.apply #qlx.action<pauli_rotation>(%3223, %cst_1920) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3225 = qlx.apply #qlx.action<h>(%3224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1921 = arith.constant 1.5707963267948966 : f64
    %3226:2 = qlx.apply #qlx.action<pauli_rotation>(%3222, %3225, %cst_1921) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1922 = arith.constant 1.5707963267948966 : f64
    %3227 = qlx.apply #qlx.action<pauli_rotation>(%3226#0, %cst_1922) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1923 = arith.constant 1.5707963267948966 : f64
    %3228 = qlx.apply #qlx.action<pauli_rotation>(%3226#1, %cst_1923) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1924 = arith.constant 1.5707963267948966 : f64
    %3229:2 = qlx.apply #qlx.action<pauli_rotation>(%3227, %3228, %cst_1924) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3230 = qlx.apply #qlx.action<h>(%2959#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1925 = arith.constant 2.3561944901923448 : f64
    %3231 = qlx.apply #qlx.action<pauli_rotation>(%3230, %cst_1925) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3232 = qlx.apply #qlx.action<h>(%3231) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3233 = qlx.apply #qlx.action<h>(%3229#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1926 = arith.constant 2.3561944901923448 : f64
    %3234 = qlx.apply #qlx.action<pauli_rotation>(%3233, %cst_1926) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3235 = qlx.apply #qlx.action<h>(%3234) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1927 = arith.constant 0.78539816339744828 : f64
    %3236:2 = qlx.apply #qlx.action<pauli_rotation>(%3232, %3235, %cst_1927) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1928 = arith.constant 1.5707963267948966 : f64
    %3237 = qlx.apply #qlx.action<pauli_rotation>(%3236#0, %cst_1928) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1929 = arith.constant 1.5707963267948966 : f64
    %3238 = qlx.apply #qlx.action<pauli_rotation>(%3236#1, %cst_1929) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1930 = arith.constant 0.78539816339744828 : f64
    %3239:2 = qlx.apply #qlx.action<pauli_rotation>(%3237, %3238, %cst_1930) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3240 = qlx.apply #qlx.action<h>(%3049#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1931 = arith.constant 3.1415926535897931 : f64
    %3241 = qlx.apply #qlx.action<pauli_rotation>(%3240, %cst_1931) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3242 = qlx.apply #qlx.action<h>(%3241) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3243 = qlx.apply #qlx.action<h>(%3039#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1932 = arith.constant 3.1415926535897931 : f64
    %3244 = qlx.apply #qlx.action<pauli_rotation>(%3243, %cst_1932) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3245 = qlx.apply #qlx.action<h>(%3244) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1933 = arith.constant 1.5707963267948966 : f64
    %3246:2 = qlx.apply #qlx.action<pauli_rotation>(%3242, %3245, %cst_1933) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1934 = arith.constant 1.5707963267948966 : f64
    %3247 = qlx.apply #qlx.action<pauli_rotation>(%3246#0, %cst_1934) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1935 = arith.constant 1.5707963267948966 : f64
    %3248 = qlx.apply #qlx.action<pauli_rotation>(%3246#1, %cst_1935) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1936 = arith.constant 1.5707963267948966 : f64
    %3249:2 = qlx.apply #qlx.action<pauli_rotation>(%3247, %3248, %cst_1936) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3250 = qlx.apply #qlx.action<h>(%3059#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1937 = arith.constant 3.1415926535897931 : f64
    %3251 = qlx.apply #qlx.action<pauli_rotation>(%3250, %cst_1937) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3252 = qlx.apply #qlx.action<h>(%3251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3253 = qlx.apply #qlx.action<h>(%3249#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1938 = arith.constant 3.1415926535897931 : f64
    %3254 = qlx.apply #qlx.action<pauli_rotation>(%3253, %cst_1938) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3255 = qlx.apply #qlx.action<h>(%3254) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1939 = arith.constant 1.5707963267948966 : f64
    %3256:2 = qlx.apply #qlx.action<pauli_rotation>(%3252, %3255, %cst_1939) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1940 = arith.constant 1.5707963267948966 : f64
    %3257 = qlx.apply #qlx.action<pauli_rotation>(%3256#0, %cst_1940) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1941 = arith.constant 1.5707963267948966 : f64
    %3258 = qlx.apply #qlx.action<pauli_rotation>(%3256#1, %cst_1941) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1942 = arith.constant 1.5707963267948966 : f64
    %3259:2 = qlx.apply #qlx.action<pauli_rotation>(%3257, %3258, %cst_1942) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3260 = qlx.apply #qlx.action<h>(%3069#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1943 = arith.constant 3.1415926535897931 : f64
    %3261 = qlx.apply #qlx.action<pauli_rotation>(%3260, %cst_1943) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3262 = qlx.apply #qlx.action<h>(%3261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3263 = qlx.apply #qlx.action<h>(%3259#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1944 = arith.constant 3.1415926535897931 : f64
    %3264 = qlx.apply #qlx.action<pauli_rotation>(%3263, %cst_1944) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3265 = qlx.apply #qlx.action<h>(%3264) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1945 = arith.constant 1.5707963267948966 : f64
    %3266:2 = qlx.apply #qlx.action<pauli_rotation>(%3262, %3265, %cst_1945) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1946 = arith.constant 1.5707963267948966 : f64
    %3267 = qlx.apply #qlx.action<pauli_rotation>(%3266#0, %cst_1946) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1947 = arith.constant 1.5707963267948966 : f64
    %3268 = qlx.apply #qlx.action<pauli_rotation>(%3266#1, %cst_1947) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1948 = arith.constant 1.5707963267948966 : f64
    %3269:2 = qlx.apply #qlx.action<pauli_rotation>(%3267, %3268, %cst_1948) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3270 = qlx.apply #qlx.action<h>(%3079#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1949 = arith.constant 3.1415926535897931 : f64
    %3271 = qlx.apply #qlx.action<pauli_rotation>(%3270, %cst_1949) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3272 = qlx.apply #qlx.action<h>(%3271) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3273 = qlx.apply #qlx.action<h>(%3269#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1950 = arith.constant 3.1415926535897931 : f64
    %3274 = qlx.apply #qlx.action<pauli_rotation>(%3273, %cst_1950) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3275 = qlx.apply #qlx.action<h>(%3274) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1951 = arith.constant 1.5707963267948966 : f64
    %3276:2 = qlx.apply #qlx.action<pauli_rotation>(%3272, %3275, %cst_1951) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1952 = arith.constant 1.5707963267948966 : f64
    %3277 = qlx.apply #qlx.action<pauli_rotation>(%3276#0, %cst_1952) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1953 = arith.constant 1.5707963267948966 : f64
    %3278 = qlx.apply #qlx.action<pauli_rotation>(%3276#1, %cst_1953) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1954 = arith.constant 1.5707963267948966 : f64
    %3279:2 = qlx.apply #qlx.action<pauli_rotation>(%3277, %3278, %cst_1954) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3280 = qlx.apply #qlx.action<h>(%3089#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1955 = arith.constant 3.1415926535897931 : f64
    %3281 = qlx.apply #qlx.action<pauli_rotation>(%3280, %cst_1955) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3282 = qlx.apply #qlx.action<h>(%3281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3283 = qlx.apply #qlx.action<h>(%3279#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1956 = arith.constant 3.1415926535897931 : f64
    %3284 = qlx.apply #qlx.action<pauli_rotation>(%3283, %cst_1956) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3285 = qlx.apply #qlx.action<h>(%3284) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1957 = arith.constant 1.5707963267948966 : f64
    %3286:2 = qlx.apply #qlx.action<pauli_rotation>(%3282, %3285, %cst_1957) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1958 = arith.constant 1.5707963267948966 : f64
    %3287 = qlx.apply #qlx.action<pauli_rotation>(%3286#0, %cst_1958) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1959 = arith.constant 1.5707963267948966 : f64
    %3288 = qlx.apply #qlx.action<pauli_rotation>(%3286#1, %cst_1959) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1960 = arith.constant 1.5707963267948966 : f64
    %3289:2 = qlx.apply #qlx.action<pauli_rotation>(%3287, %3288, %cst_1960) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3290 = qlx.apply #qlx.action<h>(%3099#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1961 = arith.constant 3.1415926535897931 : f64
    %3291 = qlx.apply #qlx.action<pauli_rotation>(%3290, %cst_1961) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3292 = qlx.apply #qlx.action<h>(%3291) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3293 = qlx.apply #qlx.action<h>(%3289#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1962 = arith.constant 3.1415926535897931 : f64
    %3294 = qlx.apply #qlx.action<pauli_rotation>(%3293, %cst_1962) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3295 = qlx.apply #qlx.action<h>(%3294) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1963 = arith.constant 1.5707963267948966 : f64
    %3296:2 = qlx.apply #qlx.action<pauli_rotation>(%3292, %3295, %cst_1963) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1964 = arith.constant 1.5707963267948966 : f64
    %3297 = qlx.apply #qlx.action<pauli_rotation>(%3296#0, %cst_1964) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1965 = arith.constant 1.5707963267948966 : f64
    %3298 = qlx.apply #qlx.action<pauli_rotation>(%3296#1, %cst_1965) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1966 = arith.constant 1.5707963267948966 : f64
    %3299:2 = qlx.apply #qlx.action<pauli_rotation>(%3297, %3298, %cst_1966) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3300 = qlx.apply #qlx.action<h>(%3109#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1967 = arith.constant 3.1415926535897931 : f64
    %3301 = qlx.apply #qlx.action<pauli_rotation>(%3300, %cst_1967) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3302 = qlx.apply #qlx.action<h>(%3301) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3303 = qlx.apply #qlx.action<h>(%3299#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1968 = arith.constant 3.1415926535897931 : f64
    %3304 = qlx.apply #qlx.action<pauli_rotation>(%3303, %cst_1968) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3305 = qlx.apply #qlx.action<h>(%3304) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1969 = arith.constant 1.5707963267948966 : f64
    %3306:2 = qlx.apply #qlx.action<pauli_rotation>(%3302, %3305, %cst_1969) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1970 = arith.constant 1.5707963267948966 : f64
    %3307 = qlx.apply #qlx.action<pauli_rotation>(%3306#0, %cst_1970) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1971 = arith.constant 1.5707963267948966 : f64
    %3308 = qlx.apply #qlx.action<pauli_rotation>(%3306#1, %cst_1971) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1972 = arith.constant 1.5707963267948966 : f64
    %3309:2 = qlx.apply #qlx.action<pauli_rotation>(%3307, %3308, %cst_1972) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3310 = qlx.apply #qlx.action<h>(%3119#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1973 = arith.constant 2.3561944901923448 : f64
    %3311 = qlx.apply #qlx.action<pauli_rotation>(%3310, %cst_1973) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3312 = qlx.apply #qlx.action<h>(%3311) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3313 = qlx.apply #qlx.action<h>(%3309#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1974 = arith.constant 2.3561944901923448 : f64
    %3314 = qlx.apply #qlx.action<pauli_rotation>(%3313, %cst_1974) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3315 = qlx.apply #qlx.action<h>(%3314) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1975 = arith.constant 0.78539816339744828 : f64
    %3316:2 = qlx.apply #qlx.action<pauli_rotation>(%3312, %3315, %cst_1975) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1976 = arith.constant 1.5707963267948966 : f64
    %3317 = qlx.apply #qlx.action<pauli_rotation>(%3316#0, %cst_1976) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1977 = arith.constant 1.5707963267948966 : f64
    %3318 = qlx.apply #qlx.action<pauli_rotation>(%3316#1, %cst_1977) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1978 = arith.constant 0.78539816339744828 : f64
    %3319:2 = qlx.apply #qlx.action<pauli_rotation>(%3317, %3318, %cst_1978) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3320 = qlx.apply #qlx.action<h>(%3129#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1979 = arith.constant 3.1415926535897931 : f64
    %3321 = qlx.apply #qlx.action<pauli_rotation>(%3320, %cst_1979) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3322 = qlx.apply #qlx.action<h>(%3321) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3323 = qlx.apply #qlx.action<h>(%3319#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1980 = arith.constant 2.3561944901923448 : f64
    %3324 = qlx.apply #qlx.action<pauli_rotation>(%3323, %cst_1980) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3325 = qlx.apply #qlx.action<h>(%3324) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1981 = arith.constant 1.5707963267948966 : f64
    %3326:2 = qlx.apply #qlx.action<pauli_rotation>(%3322, %3325, %cst_1981) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1982 = arith.constant 1.5707963267948966 : f64
    %3327 = qlx.apply #qlx.action<pauli_rotation>(%3326#0, %cst_1982) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1983 = arith.constant 1.5707963267948966 : f64
    %3328 = qlx.apply #qlx.action<pauli_rotation>(%3326#1, %cst_1983) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1984 = arith.constant 1.5707963267948966 : f64
    %3329:2 = qlx.apply #qlx.action<pauli_rotation>(%3327, %3328, %cst_1984) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3330 = qlx.apply #qlx.action<h>(%3139#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1985 = arith.constant 3.1415926535897931 : f64
    %3331 = qlx.apply #qlx.action<pauli_rotation>(%3330, %cst_1985) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3332 = qlx.apply #qlx.action<h>(%3331) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3333 = qlx.apply #qlx.action<h>(%3329#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1986 = arith.constant 3.1415926535897931 : f64
    %3334 = qlx.apply #qlx.action<pauli_rotation>(%3333, %cst_1986) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3335 = qlx.apply #qlx.action<h>(%3334) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1987 = arith.constant 1.5707963267948966 : f64
    %3336:2 = qlx.apply #qlx.action<pauli_rotation>(%3332, %3335, %cst_1987) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1988 = arith.constant 1.5707963267948966 : f64
    %3337 = qlx.apply #qlx.action<pauli_rotation>(%3336#0, %cst_1988) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1989 = arith.constant 1.5707963267948966 : f64
    %3338 = qlx.apply #qlx.action<pauli_rotation>(%3336#1, %cst_1989) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1990 = arith.constant 1.5707963267948966 : f64
    %3339:2 = qlx.apply #qlx.action<pauli_rotation>(%3337, %3338, %cst_1990) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3340 = qlx.apply #qlx.action<h>(%3149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1991 = arith.constant 3.1415926535897931 : f64
    %3341 = qlx.apply #qlx.action<pauli_rotation>(%3340, %cst_1991) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3342 = qlx.apply #qlx.action<h>(%3341) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3343 = qlx.apply #qlx.action<h>(%3339#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1992 = arith.constant 3.1415926535897931 : f64
    %3344 = qlx.apply #qlx.action<pauli_rotation>(%3343, %cst_1992) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3345 = qlx.apply #qlx.action<h>(%3344) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1993 = arith.constant 1.5707963267948966 : f64
    %3346:2 = qlx.apply #qlx.action<pauli_rotation>(%3342, %3345, %cst_1993) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1994 = arith.constant 1.5707963267948966 : f64
    %3347 = qlx.apply #qlx.action<pauli_rotation>(%3346#0, %cst_1994) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1995 = arith.constant 1.5707963267948966 : f64
    %3348 = qlx.apply #qlx.action<pauli_rotation>(%3346#1, %cst_1995) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1996 = arith.constant 1.5707963267948966 : f64
    %3349:2 = qlx.apply #qlx.action<pauli_rotation>(%3347, %3348, %cst_1996) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3350 = qlx.apply #qlx.action<h>(%3159#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1997 = arith.constant 3.1415926535897931 : f64
    %3351 = qlx.apply #qlx.action<pauli_rotation>(%3350, %cst_1997) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3352 = qlx.apply #qlx.action<h>(%3351) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3353 = qlx.apply #qlx.action<h>(%3349#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1998 = arith.constant 3.1415926535897931 : f64
    %3354 = qlx.apply #qlx.action<pauli_rotation>(%3353, %cst_1998) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3355 = qlx.apply #qlx.action<h>(%3354) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1999 = arith.constant 1.5707963267948966 : f64
    %3356:2 = qlx.apply #qlx.action<pauli_rotation>(%3352, %3355, %cst_1999) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2000 = arith.constant 1.5707963267948966 : f64
    %3357 = qlx.apply #qlx.action<pauli_rotation>(%3356#0, %cst_2000) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2001 = arith.constant 1.5707963267948966 : f64
    %3358 = qlx.apply #qlx.action<pauli_rotation>(%3356#1, %cst_2001) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2002 = arith.constant 1.5707963267948966 : f64
    %3359:2 = qlx.apply #qlx.action<pauli_rotation>(%3357, %3358, %cst_2002) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3360 = qlx.apply #qlx.action<h>(%3169#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2003 = arith.constant 3.1415926535897931 : f64
    %3361 = qlx.apply #qlx.action<pauli_rotation>(%3360, %cst_2003) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3362 = qlx.apply #qlx.action<h>(%3361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3363 = qlx.apply #qlx.action<h>(%3359#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2004 = arith.constant 3.1415926535897931 : f64
    %3364 = qlx.apply #qlx.action<pauli_rotation>(%3363, %cst_2004) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3365 = qlx.apply #qlx.action<h>(%3364) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2005 = arith.constant 1.5707963267948966 : f64
    %3366:2 = qlx.apply #qlx.action<pauli_rotation>(%3362, %3365, %cst_2005) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2006 = arith.constant 1.5707963267948966 : f64
    %3367 = qlx.apply #qlx.action<pauli_rotation>(%3366#0, %cst_2006) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2007 = arith.constant 1.5707963267948966 : f64
    %3368 = qlx.apply #qlx.action<pauli_rotation>(%3366#1, %cst_2007) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2008 = arith.constant 1.5707963267948966 : f64
    %3369:2 = qlx.apply #qlx.action<pauli_rotation>(%3367, %3368, %cst_2008) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3370 = qlx.apply #qlx.action<h>(%3179#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2009 = arith.constant 3.1415926535897931 : f64
    %3371 = qlx.apply #qlx.action<pauli_rotation>(%3370, %cst_2009) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3372 = qlx.apply #qlx.action<h>(%3371) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3373 = qlx.apply #qlx.action<h>(%3369#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2010 = arith.constant 3.1415926535897931 : f64
    %3374 = qlx.apply #qlx.action<pauli_rotation>(%3373, %cst_2010) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3375 = qlx.apply #qlx.action<h>(%3374) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2011 = arith.constant 1.5707963267948966 : f64
    %3376:2 = qlx.apply #qlx.action<pauli_rotation>(%3372, %3375, %cst_2011) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2012 = arith.constant 1.5707963267948966 : f64
    %3377 = qlx.apply #qlx.action<pauli_rotation>(%3376#0, %cst_2012) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2013 = arith.constant 1.5707963267948966 : f64
    %3378 = qlx.apply #qlx.action<pauli_rotation>(%3376#1, %cst_2013) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2014 = arith.constant 1.5707963267948966 : f64
    %3379:2 = qlx.apply #qlx.action<pauli_rotation>(%3377, %3378, %cst_2014) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3380 = qlx.apply #qlx.action<h>(%3189#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2015 = arith.constant 3.1415926535897931 : f64
    %3381 = qlx.apply #qlx.action<pauli_rotation>(%3380, %cst_2015) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3382 = qlx.apply #qlx.action<h>(%3381) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3383 = qlx.apply #qlx.action<h>(%3379#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2016 = arith.constant 3.1415926535897931 : f64
    %3384 = qlx.apply #qlx.action<pauli_rotation>(%3383, %cst_2016) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3385 = qlx.apply #qlx.action<h>(%3384) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2017 = arith.constant 1.5707963267948966 : f64
    %3386:2 = qlx.apply #qlx.action<pauli_rotation>(%3382, %3385, %cst_2017) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2018 = arith.constant 1.5707963267948966 : f64
    %3387 = qlx.apply #qlx.action<pauli_rotation>(%3386#0, %cst_2018) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2019 = arith.constant 1.5707963267948966 : f64
    %3388 = qlx.apply #qlx.action<pauli_rotation>(%3386#1, %cst_2019) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2020 = arith.constant 1.5707963267948966 : f64
    %3389:2 = qlx.apply #qlx.action<pauli_rotation>(%3387, %3388, %cst_2020) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3390 = qlx.apply #qlx.action<h>(%3199#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2021 = arith.constant 3.1415926535897931 : f64
    %3391 = qlx.apply #qlx.action<pauli_rotation>(%3390, %cst_2021) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3392 = qlx.apply #qlx.action<h>(%3391) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3393 = qlx.apply #qlx.action<h>(%3389#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2022 = arith.constant 3.1415926535897931 : f64
    %3394 = qlx.apply #qlx.action<pauli_rotation>(%3393, %cst_2022) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3395 = qlx.apply #qlx.action<h>(%3394) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2023 = arith.constant 1.5707963267948966 : f64
    %3396:2 = qlx.apply #qlx.action<pauli_rotation>(%3392, %3395, %cst_2023) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2024 = arith.constant 1.5707963267948966 : f64
    %3397 = qlx.apply #qlx.action<pauli_rotation>(%3396#0, %cst_2024) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2025 = arith.constant 1.5707963267948966 : f64
    %3398 = qlx.apply #qlx.action<pauli_rotation>(%3396#1, %cst_2025) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2026 = arith.constant 1.5707963267948966 : f64
    %3399:2 = qlx.apply #qlx.action<pauli_rotation>(%3397, %3398, %cst_2026) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3400 = qlx.apply #qlx.action<h>(%3209#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2027 = arith.constant 3.1415926535897931 : f64
    %3401 = qlx.apply #qlx.action<pauli_rotation>(%3400, %cst_2027) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3402 = qlx.apply #qlx.action<h>(%3401) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3403 = qlx.apply #qlx.action<h>(%3399#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2028 = arith.constant 3.1415926535897931 : f64
    %3404 = qlx.apply #qlx.action<pauli_rotation>(%3403, %cst_2028) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3405 = qlx.apply #qlx.action<h>(%3404) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2029 = arith.constant 1.5707963267948966 : f64
    %3406:2 = qlx.apply #qlx.action<pauli_rotation>(%3402, %3405, %cst_2029) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2030 = arith.constant 1.5707963267948966 : f64
    %3407 = qlx.apply #qlx.action<pauli_rotation>(%3406#0, %cst_2030) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2031 = arith.constant 1.5707963267948966 : f64
    %3408 = qlx.apply #qlx.action<pauli_rotation>(%3406#1, %cst_2031) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2032 = arith.constant 1.5707963267948966 : f64
    %3409:2 = qlx.apply #qlx.action<pauli_rotation>(%3407, %3408, %cst_2032) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3410 = qlx.apply #qlx.action<h>(%3219#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2033 = arith.constant 3.1415926535897931 : f64
    %3411 = qlx.apply #qlx.action<pauli_rotation>(%3410, %cst_2033) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3412 = qlx.apply #qlx.action<h>(%3411) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3413 = qlx.apply #qlx.action<h>(%3409#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2034 = arith.constant 3.1415926535897931 : f64
    %3414 = qlx.apply #qlx.action<pauli_rotation>(%3413, %cst_2034) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3415 = qlx.apply #qlx.action<h>(%3414) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2035 = arith.constant 1.5707963267948966 : f64
    %3416:2 = qlx.apply #qlx.action<pauli_rotation>(%3412, %3415, %cst_2035) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2036 = arith.constant 1.5707963267948966 : f64
    %3417 = qlx.apply #qlx.action<pauli_rotation>(%3416#0, %cst_2036) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2037 = arith.constant 1.5707963267948966 : f64
    %3418 = qlx.apply #qlx.action<pauli_rotation>(%3416#1, %cst_2037) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2038 = arith.constant 1.5707963267948966 : f64
    %3419:2 = qlx.apply #qlx.action<pauli_rotation>(%3417, %3418, %cst_2038) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3420 = qlx.apply #qlx.action<h>(%3229#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2039 = arith.constant 3.1415926535897931 : f64
    %3421 = qlx.apply #qlx.action<pauli_rotation>(%3420, %cst_2039) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3422 = qlx.apply #qlx.action<h>(%3421) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3423 = qlx.apply #qlx.action<h>(%3419#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2040 = arith.constant 3.1415926535897931 : f64
    %3424 = qlx.apply #qlx.action<pauli_rotation>(%3423, %cst_2040) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3425 = qlx.apply #qlx.action<h>(%3424) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2041 = arith.constant 1.5707963267948966 : f64
    %3426:2 = qlx.apply #qlx.action<pauli_rotation>(%3422, %3425, %cst_2041) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2042 = arith.constant 1.5707963267948966 : f64
    %3427 = qlx.apply #qlx.action<pauli_rotation>(%3426#0, %cst_2042) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2043 = arith.constant 1.5707963267948966 : f64
    %3428 = qlx.apply #qlx.action<pauli_rotation>(%3426#1, %cst_2043) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2044 = arith.constant 1.5707963267948966 : f64
    %3429:2 = qlx.apply #qlx.action<pauli_rotation>(%3427, %3428, %cst_2044) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3430 = qlx.apply #qlx.action<h>(%3239#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2045 = arith.constant 2.3561944901923448 : f64
    %3431 = qlx.apply #qlx.action<pauli_rotation>(%3430, %cst_2045) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3432 = qlx.apply #qlx.action<h>(%3431) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3433 = qlx.apply #qlx.action<h>(%3429#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2046 = arith.constant 1.5707963267948966 : f64
    %3434 = qlx.apply #qlx.action<pauli_rotation>(%3433, %cst_2046) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3435 = qlx.apply #qlx.action<h>(%3434) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2047 = arith.constant 1.000000e+00 : f64
    %3436:2 = qlx.apply #qlx.action<pauli_rotation>(%3432, %3435, %cst_2047) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2048 = arith.constant 1.5707963267948966 : f64
    %3437 = qlx.apply #qlx.action<pauli_rotation>(%3436#0, %cst_2048) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2049 = arith.constant 1.5707963267948966 : f64
    %3438 = qlx.apply #qlx.action<pauli_rotation>(%3436#1, %cst_2049) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2050 = arith.constant 1.000000e+00 : f64
    %3439:2 = qlx.apply #qlx.action<pauli_rotation>(%3437, %3438, %cst_2050) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3440 = qlx.apply #qlx.action<h>(%3239#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2051 = arith.constant 1.5707963267948966 : f64
    %3441 = qlx.apply #qlx.action<pauli_rotation>(%3440, %cst_2051) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3442 = qlx.apply #qlx.action<h>(%3441) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3443 = qlx.apply #qlx.action<h>(%3439#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2052 = arith.constant 0.78539816339744828 : f64
    %3444 = qlx.apply #qlx.action<pauli_rotation>(%3443, %cst_2052) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3445 = qlx.apply #qlx.action<h>(%3444) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2053 = arith.constant 0.78539816339744828 : f64
    %3446:2 = qlx.apply #qlx.action<pauli_rotation>(%3442, %3445, %cst_2053) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2054 = arith.constant 1.5707963267948966 : f64
    %3447 = qlx.apply #qlx.action<pauli_rotation>(%3446#0, %cst_2054) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2055 = arith.constant 1.5707963267948966 : f64
    %3448 = qlx.apply #qlx.action<pauli_rotation>(%3446#1, %cst_2055) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2056 = arith.constant 0.78539816339744828 : f64
    %3449:2 = qlx.apply #qlx.action<pauli_rotation>(%3447, %3448, %cst_2056) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3450 = qlx.apply #qlx.action<h>(%2969#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2057 = arith.constant 3.1415926535897931 : f64
    %3451 = qlx.apply #qlx.action<pauli_rotation>(%3450, %cst_2057) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3452 = qlx.apply #qlx.action<h>(%3451) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3453 = qlx.apply #qlx.action<h>(%3449#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2058 = arith.constant 2.3561944901923448 : f64
    %3454 = qlx.apply #qlx.action<pauli_rotation>(%3453, %cst_2058) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3455 = qlx.apply #qlx.action<h>(%3454) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2059 = arith.constant 1.5707963267948966 : f64
    %3456:2 = qlx.apply #qlx.action<pauli_rotation>(%3452, %3455, %cst_2059) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2060 = arith.constant 1.5707963267948966 : f64
    %3457 = qlx.apply #qlx.action<pauli_rotation>(%3456#0, %cst_2060) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2061 = arith.constant 1.5707963267948966 : f64
    %3458 = qlx.apply #qlx.action<pauli_rotation>(%3456#1, %cst_2061) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2062 = arith.constant 1.5707963267948966 : f64
    %3459:2 = qlx.apply #qlx.action<pauli_rotation>(%3457, %3458, %cst_2062) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3460 = qlx.apply #qlx.action<h>(%2979#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2063 = arith.constant 3.1415926535897931 : f64
    %3461 = qlx.apply #qlx.action<pauli_rotation>(%3460, %cst_2063) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3462 = qlx.apply #qlx.action<h>(%3461) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3463 = qlx.apply #qlx.action<h>(%3459#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2064 = arith.constant 3.1415926535897931 : f64
    %3464 = qlx.apply #qlx.action<pauli_rotation>(%3463, %cst_2064) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3465 = qlx.apply #qlx.action<h>(%3464) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2065 = arith.constant 1.5707963267948966 : f64
    %3466:2 = qlx.apply #qlx.action<pauli_rotation>(%3462, %3465, %cst_2065) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2066 = arith.constant 1.5707963267948966 : f64
    %3467 = qlx.apply #qlx.action<pauli_rotation>(%3466#0, %cst_2066) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2067 = arith.constant 1.5707963267948966 : f64
    %3468 = qlx.apply #qlx.action<pauli_rotation>(%3466#1, %cst_2067) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2068 = arith.constant 1.5707963267948966 : f64
    %3469:2 = qlx.apply #qlx.action<pauli_rotation>(%3467, %3468, %cst_2068) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3470 = qlx.apply #qlx.action<h>(%2989#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2069 = arith.constant 3.1415926535897931 : f64
    %3471 = qlx.apply #qlx.action<pauli_rotation>(%3470, %cst_2069) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3472 = qlx.apply #qlx.action<h>(%3471) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3473 = qlx.apply #qlx.action<h>(%3469#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2070 = arith.constant 3.1415926535897931 : f64
    %3474 = qlx.apply #qlx.action<pauli_rotation>(%3473, %cst_2070) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3475 = qlx.apply #qlx.action<h>(%3474) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2071 = arith.constant 1.5707963267948966 : f64
    %3476:2 = qlx.apply #qlx.action<pauli_rotation>(%3472, %3475, %cst_2071) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2072 = arith.constant 1.5707963267948966 : f64
    %3477 = qlx.apply #qlx.action<pauli_rotation>(%3476#0, %cst_2072) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2073 = arith.constant 1.5707963267948966 : f64
    %3478 = qlx.apply #qlx.action<pauli_rotation>(%3476#1, %cst_2073) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2074 = arith.constant 1.5707963267948966 : f64
    %3479:2 = qlx.apply #qlx.action<pauli_rotation>(%3477, %3478, %cst_2074) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3480 = qlx.apply #qlx.action<h>(%2999#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2075 = arith.constant 3.1415926535897931 : f64
    %3481 = qlx.apply #qlx.action<pauli_rotation>(%3480, %cst_2075) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3482 = qlx.apply #qlx.action<h>(%3481) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3483 = qlx.apply #qlx.action<h>(%3479#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2076 = arith.constant 3.1415926535897931 : f64
    %3484 = qlx.apply #qlx.action<pauli_rotation>(%3483, %cst_2076) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3485 = qlx.apply #qlx.action<h>(%3484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2077 = arith.constant 1.5707963267948966 : f64
    %3486:2 = qlx.apply #qlx.action<pauli_rotation>(%3482, %3485, %cst_2077) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2078 = arith.constant 1.5707963267948966 : f64
    %3487 = qlx.apply #qlx.action<pauli_rotation>(%3486#0, %cst_2078) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2079 = arith.constant 1.5707963267948966 : f64
    %3488 = qlx.apply #qlx.action<pauli_rotation>(%3486#1, %cst_2079) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2080 = arith.constant 1.5707963267948966 : f64
    %3489:2 = qlx.apply #qlx.action<pauli_rotation>(%3487, %3488, %cst_2080) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3490 = qlx.apply #qlx.action<h>(%3009#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2081 = arith.constant 3.1415926535897931 : f64
    %3491 = qlx.apply #qlx.action<pauli_rotation>(%3490, %cst_2081) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3492 = qlx.apply #qlx.action<h>(%3491) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3493 = qlx.apply #qlx.action<h>(%3489#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2082 = arith.constant 3.1415926535897931 : f64
    %3494 = qlx.apply #qlx.action<pauli_rotation>(%3493, %cst_2082) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3495 = qlx.apply #qlx.action<h>(%3494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2083 = arith.constant 1.5707963267948966 : f64
    %3496:2 = qlx.apply #qlx.action<pauli_rotation>(%3492, %3495, %cst_2083) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2084 = arith.constant 1.5707963267948966 : f64
    %3497 = qlx.apply #qlx.action<pauli_rotation>(%3496#0, %cst_2084) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2085 = arith.constant 1.5707963267948966 : f64
    %3498 = qlx.apply #qlx.action<pauli_rotation>(%3496#1, %cst_2085) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2086 = arith.constant 1.5707963267948966 : f64
    %3499:2 = qlx.apply #qlx.action<pauli_rotation>(%3497, %3498, %cst_2086) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3500 = qlx.apply #qlx.action<h>(%3019#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2087 = arith.constant 2.3561944901923448 : f64
    %3501 = qlx.apply #qlx.action<pauli_rotation>(%3500, %cst_2087) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3502 = qlx.apply #qlx.action<h>(%3501) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %3503 = qlx.apply #qlx.action<h>(%3499#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2088 = arith.constant 3.1415926535897931 : f64
    %3504 = qlx.apply #qlx.action<pauli_rotation>(%3503, %cst_2088) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3505 = qlx.apply #qlx.action<h>(%3504) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2089 = arith.constant 1.5707963267948966 : f64
    %3506:2 = qlx.apply #qlx.action<pauli_rotation>(%3502, %3505, %cst_2089) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2090 = arith.constant 1.5707963267948966 : f64
    %3507 = qlx.apply #qlx.action<pauli_rotation>(%3506#0, %cst_2090) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2091 = arith.constant 1.5707963267948966 : f64
    %3508 = qlx.apply #qlx.action<pauli_rotation>(%3506#1, %cst_2091) {parameters = {sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2092 = arith.constant 1.5707963267948966 : f64
    %3509:2 = qlx.apply #qlx.action<pauli_rotation>(%3507, %3508, %cst_2092) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3510 = qlx.apply #qlx.action<h>(%3019#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2093 = arith.constant 2.3561944901923448 : f64
    %3511 = qlx.apply #qlx.action<pauli_rotation>(%3510, %cst_2093) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3512 = qlx.apply #qlx.action<h>(%3509#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2094 = arith.constant 3.1415926535897931 : f64
    %3513 = qlx.apply #qlx.action<pauli_rotation>(%3512, %cst_2094) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2095 = arith.constant 1.000000e+00 : f64
    %3514:2 = qlx.apply #qlx.action<pauli_rotation>(%3511, %3513, %cst_2095) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %3515 = qlx.apply #qlx.action<h>(%294#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2096 = arith.constant 2.3561944901923448 : f64
    %3516 = qlx.apply #qlx.action<pauli_rotation>(%3515, %cst_2096) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3517 = qlx.apply #qlx.action<h>(%1761#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2097 = arith.constant 2.3561944901923448 : f64
    %3518 = qlx.apply #qlx.action<pauli_rotation>(%3517, %cst_2097) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3519 = qlx.apply #qlx.action<h>(%3509#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2098 = arith.constant 3.1415926535897931 : f64
    %3520 = qlx.apply #qlx.action<pauli_rotation>(%3519, %cst_2098) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3521 = qlx.apply #qlx.action<h>(%3499#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2099 = arith.constant 3.1415926535897931 : f64
    %3522 = qlx.apply #qlx.action<pauli_rotation>(%3521, %cst_2099) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3523 = qlx.apply #qlx.action<h>(%3489#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2100 = arith.constant 3.1415926535897931 : f64
    %3524 = qlx.apply #qlx.action<pauli_rotation>(%3523, %cst_2100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3525 = qlx.apply #qlx.action<h>(%3479#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2101 = arith.constant 3.1415926535897931 : f64
    %3526 = qlx.apply #qlx.action<pauli_rotation>(%3525, %cst_2101) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3527 = qlx.apply #qlx.action<h>(%3469#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2102 = arith.constant 3.1415926535897931 : f64
    %3528 = qlx.apply #qlx.action<pauli_rotation>(%3527, %cst_2102) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3529 = qlx.apply #qlx.action<h>(%3459#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2103 = arith.constant 3.1415926535897931 : f64
    %3530 = qlx.apply #qlx.action<pauli_rotation>(%3529, %cst_2103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3531 = qlx.apply #qlx.action<h>(%3449#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2104 = arith.constant 2.3561944901923448 : f64
    %3532 = qlx.apply #qlx.action<pauli_rotation>(%3531, %cst_2104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3533 = qlx.apply #qlx.action<h>(%3439#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2105 = arith.constant 3.1415926535897931 : f64
    %3534 = qlx.apply #qlx.action<pauli_rotation>(%3533, %cst_2105) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3535 = qlx.apply #qlx.action<h>(%3429#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2106 = arith.constant 3.1415926535897931 : f64
    %3536 = qlx.apply #qlx.action<pauli_rotation>(%3535, %cst_2106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3537 = qlx.apply #qlx.action<h>(%3419#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2107 = arith.constant 3.1415926535897931 : f64
    %3538 = qlx.apply #qlx.action<pauli_rotation>(%3537, %cst_2107) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3539 = qlx.apply #qlx.action<h>(%3409#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2108 = arith.constant 3.1415926535897931 : f64
    %3540 = qlx.apply #qlx.action<pauli_rotation>(%3539, %cst_2108) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3541 = qlx.apply #qlx.action<h>(%3399#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2109 = arith.constant 3.1415926535897931 : f64
    %3542 = qlx.apply #qlx.action<pauli_rotation>(%3541, %cst_2109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3543 = qlx.apply #qlx.action<h>(%3389#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2110 = arith.constant 3.1415926535897931 : f64
    %3544 = qlx.apply #qlx.action<pauli_rotation>(%3543, %cst_2110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3545 = qlx.apply #qlx.action<h>(%3379#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2111 = arith.constant 3.1415926535897931 : f64
    %3546 = qlx.apply #qlx.action<pauli_rotation>(%3545, %cst_2111) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3547 = qlx.apply #qlx.action<h>(%3369#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2112 = arith.constant 3.1415926535897931 : f64
    %3548 = qlx.apply #qlx.action<pauli_rotation>(%3547, %cst_2112) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3549 = qlx.apply #qlx.action<h>(%3359#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2113 = arith.constant 3.1415926535897931 : f64
    %3550 = qlx.apply #qlx.action<pauli_rotation>(%3549, %cst_2113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3551 = qlx.apply #qlx.action<h>(%3349#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2114 = arith.constant 3.1415926535897931 : f64
    %3552 = qlx.apply #qlx.action<pauli_rotation>(%3551, %cst_2114) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3553 = qlx.apply #qlx.action<h>(%3339#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2115 = arith.constant 3.1415926535897931 : f64
    %3554 = qlx.apply #qlx.action<pauli_rotation>(%3553, %cst_2115) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3555 = qlx.apply #qlx.action<h>(%3329#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2116 = arith.constant 3.1415926535897931 : f64
    %3556 = qlx.apply #qlx.action<pauli_rotation>(%3555, %cst_2116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3557 = qlx.apply #qlx.action<h>(%3319#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2117 = arith.constant 2.3561944901923448 : f64
    %3558 = qlx.apply #qlx.action<pauli_rotation>(%3557, %cst_2117) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3559 = qlx.apply #qlx.action<h>(%3309#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2118 = arith.constant 3.1415926535897931 : f64
    %3560 = qlx.apply #qlx.action<pauli_rotation>(%3559, %cst_2118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3561 = qlx.apply #qlx.action<h>(%3299#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2119 = arith.constant 3.1415926535897931 : f64
    %3562 = qlx.apply #qlx.action<pauli_rotation>(%3561, %cst_2119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3563 = qlx.apply #qlx.action<h>(%3289#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2120 = arith.constant 3.1415926535897931 : f64
    %3564 = qlx.apply #qlx.action<pauli_rotation>(%3563, %cst_2120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3565 = qlx.apply #qlx.action<h>(%3279#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2121 = arith.constant 3.1415926535897931 : f64
    %3566 = qlx.apply #qlx.action<pauli_rotation>(%3565, %cst_2121) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3567 = qlx.apply #qlx.action<h>(%3269#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2122 = arith.constant 3.1415926535897931 : f64
    %3568 = qlx.apply #qlx.action<pauli_rotation>(%3567, %cst_2122) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3569 = qlx.apply #qlx.action<h>(%3259#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2123 = arith.constant 3.1415926535897931 : f64
    %3570 = qlx.apply #qlx.action<pauli_rotation>(%3569, %cst_2123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3571 = qlx.apply #qlx.action<h>(%3249#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2124 = arith.constant 3.1415926535897931 : f64
    %3572 = qlx.apply #qlx.action<pauli_rotation>(%3571, %cst_2124) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3573 = qlx.apply #qlx.action<h>(%3029#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2125 = arith.constant 3.1415926535897931 : f64
    %3574 = qlx.apply #qlx.action<pauli_rotation>(%3573, %cst_2125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %3575 = qlx.measure <Z> %3516 : !qlx.logical_qubit -> i1
    %3576 = qlx.measure <Z> %3518 : !qlx.logical_qubit -> i1
    %3577 = qlx.measure <Z> %3514#0 : !qlx.logical_qubit -> i1
    %3578 = qlx.measure <Z> %3514#1 : !qlx.logical_qubit -> i1
    %3579 = qlx.measure <Z> %3520 : !qlx.logical_qubit -> i1
    %3580 = qlx.measure <Z> %3522 : !qlx.logical_qubit -> i1
    %3581 = qlx.measure <Z> %3524 : !qlx.logical_qubit -> i1
    %3582 = qlx.measure <Z> %3526 : !qlx.logical_qubit -> i1
    %3583 = qlx.measure <Z> %3528 : !qlx.logical_qubit -> i1
    %3584 = qlx.measure <Z> %3530 : !qlx.logical_qubit -> i1
    %3585 = qlx.measure <Z> %3532 : !qlx.logical_qubit -> i1
    %3586 = qlx.measure <Z> %3534 : !qlx.logical_qubit -> i1
    %3587 = qlx.measure <Z> %3536 : !qlx.logical_qubit -> i1
    %3588 = qlx.measure <Z> %3538 : !qlx.logical_qubit -> i1
    %3589 = qlx.measure <Z> %3540 : !qlx.logical_qubit -> i1
    %3590 = qlx.measure <Z> %3542 : !qlx.logical_qubit -> i1
    %3591 = qlx.measure <Z> %3544 : !qlx.logical_qubit -> i1
    %3592 = qlx.measure <Z> %3546 : !qlx.logical_qubit -> i1
    %3593 = qlx.measure <Z> %3548 : !qlx.logical_qubit -> i1
    %3594 = qlx.measure <Z> %3550 : !qlx.logical_qubit -> i1
    %3595 = qlx.measure <Z> %3552 : !qlx.logical_qubit -> i1
    %3596 = qlx.measure <Z> %3554 : !qlx.logical_qubit -> i1
    %3597 = qlx.measure <Z> %3556 : !qlx.logical_qubit -> i1
    %3598 = qlx.measure <Z> %3558 : !qlx.logical_qubit -> i1
    %3599 = qlx.measure <Z> %3560 : !qlx.logical_qubit -> i1
    %3600 = qlx.measure <Z> %3562 : !qlx.logical_qubit -> i1
    %3601 = qlx.measure <Z> %3564 : !qlx.logical_qubit -> i1
    %3602 = qlx.measure <Z> %3566 : !qlx.logical_qubit -> i1
    %3603 = qlx.measure <Z> %3568 : !qlx.logical_qubit -> i1
    %3604 = qlx.measure <Z> %3570 : !qlx.logical_qubit -> i1
    %3605 = qlx.measure <Z> %3572 : !qlx.logical_qubit -> i1
    %3606 = qlx.measure <Z> %3574 : !qlx.logical_qubit -> i1
  }
}
