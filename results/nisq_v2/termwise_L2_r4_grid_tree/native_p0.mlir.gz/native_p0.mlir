module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %9:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %10 = qlx.apply #qlx.action<h>(%2) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %11 = qlx.apply #qlx.action<h>(%9#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %12:2 = qlx.apply #qlx.action<pauli_rotation>(%10, %11, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %13 = qlx.apply #qlx.action<pauli_rotation>(%12#1, %cst_1) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %14 = qlx.apply #qlx.action<h>(%13) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %15 = qlx.apply #qlx.action<h>(%9#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_2 = arith.constant 1.250000e-01 : f64
    %16:2 = qlx.apply #qlx.action<pauli_rotation>(%14, %15, %cst_2) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_3 = arith.constant 1.5707963267948966 : f64
    %17 = qlx.apply #qlx.action<pauli_rotation>(%12#0, %cst_3) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %18 = qlx.apply #qlx.action<h>(%16#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_4 = arith.constant 1.5707963267948966 : f64
    %19:2 = qlx.apply #qlx.action<pauli_rotation>(%17, %18, %cst_4) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_5 = arith.constant 1.5707963267948966 : f64
    %20 = qlx.apply #qlx.action<pauli_rotation>(%19#0, %cst_5) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %21 = qlx.apply #qlx.action<h>(%20) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %22 = qlx.apply #qlx.action<pauli_rotation>(%21, %cst_6) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %23 = qlx.apply #qlx.action<h>(%22) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_7 = arith.constant 1.5707963267948966 : f64
    %24 = qlx.apply #qlx.action<pauli_rotation>(%19#1, %cst_7) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_8 = arith.constant 1.5707963267948966 : f64
    %25:2 = qlx.apply #qlx.action<pauli_rotation>(%23, %24, %cst_8) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_9 = arith.constant 1.5707963267948966 : f64
    %26 = qlx.apply #qlx.action<pauli_rotation>(%25#1, %cst_9) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %27 = qlx.apply #qlx.action<h>(%26) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %28 = qlx.apply #qlx.action<h>(%16#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_10 = arith.constant 1.5707963267948966 : f64
    %29 = qlx.apply #qlx.action<pauli_rotation>(%28, %cst_10) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %30 = qlx.apply #qlx.action<h>(%29) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 1.250000e-01 : f64
    %31:2 = qlx.apply #qlx.action<pauli_rotation>(%27, %30, %cst_11) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 1.5707963267948966 : f64
    %32 = qlx.apply #qlx.action<pauli_rotation>(%25#0, %cst_12) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %33 = qlx.apply #qlx.action<h>(%31#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %34:2 = qlx.apply #qlx.action<pauli_rotation>(%32, %33, %cst_13) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %35 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %36 = qlx.apply #qlx.action<h>(%35) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_14 = arith.constant 1.5707963267948966 : f64
    %37 = qlx.apply #qlx.action<pauli_rotation>(%34#0, %cst_14) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %38 = qlx.apply #qlx.action<h>(%37) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %39 = qlx.apply #qlx.action<pauli_rotation>(%38, %cst_15) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %40 = qlx.apply #qlx.action<h>(%39) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %41:2 = qlx.apply #qlx.action<pauli_rotation>(%36, %40, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %42 = qlx.apply #qlx.action<pauli_rotation>(%41#1, %cst_17) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %43 = qlx.apply #qlx.action<h>(%42) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_18 = arith.constant 1.5707963267948966 : f64
    %44 = qlx.apply #qlx.action<pauli_rotation>(%34#1, %cst_18) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 1.250000e-01 : f64
    %45:2 = qlx.apply #qlx.action<pauli_rotation>(%43, %44, %cst_19) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_20 = arith.constant 1.5707963267948966 : f64
    %46 = qlx.apply #qlx.action<pauli_rotation>(%41#0, %cst_20) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %47 = qlx.apply #qlx.action<h>(%45#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_21 = arith.constant 1.5707963267948966 : f64
    %48:2 = qlx.apply #qlx.action<pauli_rotation>(%46, %47, %cst_21) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %49 = qlx.apply #qlx.action<pauli_rotation>(%48#0, %cst_22) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %50 = qlx.apply #qlx.action<h>(%49) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 1.5707963267948966 : f64
    %51 = qlx.apply #qlx.action<pauli_rotation>(%50, %cst_23) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %52 = qlx.apply #qlx.action<h>(%51) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_24 = arith.constant 1.5707963267948966 : f64
    %53 = qlx.apply #qlx.action<pauli_rotation>(%48#1, %cst_24) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_25 = arith.constant 1.5707963267948966 : f64
    %54:2 = qlx.apply #qlx.action<pauli_rotation>(%52, %53, %cst_25) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_26 = arith.constant 1.5707963267948966 : f64
    %55 = qlx.apply #qlx.action<pauli_rotation>(%54#1, %cst_26) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %56 = qlx.apply #qlx.action<h>(%55) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %57 = qlx.apply #qlx.action<h>(%45#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%57, %cst_27) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %59 = qlx.apply #qlx.action<h>(%58) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_28 = arith.constant 1.250000e-01 : f64
    %60:2 = qlx.apply #qlx.action<pauli_rotation>(%56, %59, %cst_28) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_29 = arith.constant 1.5707963267948966 : f64
    %61 = qlx.apply #qlx.action<pauli_rotation>(%54#0, %cst_29) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %62 = qlx.apply #qlx.action<h>(%60#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_30 = arith.constant 1.5707963267948966 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%61, %62, %cst_30) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<h>(%31#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_31 = arith.constant 1.5707963267948966 : f64
    %65 = qlx.apply #qlx.action<pauli_rotation>(%64, %cst_31) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %66 = qlx.apply #qlx.action<h>(%65) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %67 = qlx.apply #qlx.action<h>(%60#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %68 = qlx.apply #qlx.action<pauli_rotation>(%67, %cst_32) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %69 = qlx.apply #qlx.action<h>(%68) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_33 = arith.constant 1.5707963267948966 : f64
    %70:2 = qlx.apply #qlx.action<pauli_rotation>(%66, %69, %cst_33) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 1.5707963267948966 : f64
    %71 = qlx.apply #qlx.action<pauli_rotation>(%63#1, %cst_34) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %72 = qlx.apply #qlx.action<h>(%71) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_35 = arith.constant 1.5707963267948966 : f64
    %73 = qlx.apply #qlx.action<pauli_rotation>(%70#1, %cst_35) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_36 = arith.constant 1.5707963267948966 : f64
    %74:2 = qlx.apply #qlx.action<pauli_rotation>(%72, %73, %cst_36) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %75 = qlx.apply #qlx.action<h>(%6) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %76 = qlx.apply #qlx.action<h>(%5) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_37 = arith.constant 1.5707963267948966 : f64
    %77:2 = qlx.apply #qlx.action<pauli_rotation>(%76, %75, %cst_37) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_38 = arith.constant 1.5707963267948966 : f64
    %78 = qlx.apply #qlx.action<pauli_rotation>(%63#0, %cst_38) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %79 = qlx.apply #qlx.action<h>(%78) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 1.5707963267948966 : f64
    %80 = qlx.apply #qlx.action<pauli_rotation>(%79, %cst_39) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %81 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %82 = qlx.apply #qlx.action<h>(%81) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_40 = arith.constant 1.5707963267948966 : f64
    %83:2 = qlx.apply #qlx.action<pauli_rotation>(%82, %80, %cst_40) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_41 = arith.constant 1.5707963267948966 : f64
    %84 = qlx.apply #qlx.action<pauli_rotation>(%77#0, %cst_41) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %85 = qlx.apply #qlx.action<h>(%84) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_42 = arith.constant 1.5707963267948966 : f64
    %86 = qlx.apply #qlx.action<pauli_rotation>(%83#0, %cst_42) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %87:2 = qlx.apply #qlx.action<pauli_rotation>(%85, %86, %cst_43) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_44 = arith.constant 1.5707963267948966 : f64
    %88 = qlx.apply #qlx.action<pauli_rotation>(%87#1, %cst_44) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %89 = qlx.apply #qlx.action<h>(%88) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 1.5707963267948966 : f64
    %90 = qlx.apply #qlx.action<pauli_rotation>(%74#1, %cst_45) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %91 = qlx.apply #qlx.action<h>(%90) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_46 = arith.constant 1.250000e-01 : f64
    %92:2 = qlx.apply #qlx.action<pauli_rotation>(%89, %91, %cst_46) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_47 = arith.constant 1.5707963267948966 : f64
    %93 = qlx.apply #qlx.action<pauli_rotation>(%87#0, %cst_47) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %94 = qlx.apply #qlx.action<h>(%92#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %95:2 = qlx.apply #qlx.action<pauli_rotation>(%93, %94, %cst_48) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_49 = arith.constant 1.5707963267948966 : f64
    %96 = qlx.apply #qlx.action<pauli_rotation>(%83#1, %cst_49) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_50 = arith.constant 1.5707963267948966 : f64
    %97 = qlx.apply #qlx.action<pauli_rotation>(%95#1, %cst_50) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_51 = arith.constant 1.5707963267948966 : f64
    %98:2 = qlx.apply #qlx.action<pauli_rotation>(%96, %97, %cst_51) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_52 = arith.constant 1.5707963267948966 : f64
    %99 = qlx.apply #qlx.action<pauli_rotation>(%77#1, %cst_52) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_53 = arith.constant 1.5707963267948966 : f64
    %100 = qlx.apply #qlx.action<pauli_rotation>(%95#0, %cst_53) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %101 = qlx.apply #qlx.action<h>(%100) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_54 = arith.constant 1.5707963267948966 : f64
    %102:2 = qlx.apply #qlx.action<pauli_rotation>(%99, %101, %cst_54) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_55 = arith.constant 1.5707963267948966 : f64
    %103 = qlx.apply #qlx.action<pauli_rotation>(%74#0, %cst_55) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %104 = qlx.apply #qlx.action<h>(%92#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_56 = arith.constant 1.5707963267948966 : f64
    %105:2 = qlx.apply #qlx.action<pauli_rotation>(%103, %104, %cst_56) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_57 = arith.constant 1.5707963267948966 : f64
    %106 = qlx.apply #qlx.action<pauli_rotation>(%70#0, %cst_57) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %107 = qlx.apply #qlx.action<pauli_rotation>(%105#1, %cst_58) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_59 = arith.constant 1.5707963267948966 : f64
    %108:2 = qlx.apply #qlx.action<pauli_rotation>(%106, %107, %cst_59) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_60 = arith.constant 1.5707963267948966 : f64
    %109 = qlx.apply #qlx.action<pauli_rotation>(%108#0, %cst_60) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %110 = qlx.apply #qlx.action<h>(%109) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_61 = arith.constant 1.5707963267948966 : f64
    %111 = qlx.apply #qlx.action<pauli_rotation>(%110, %cst_61) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %112 = qlx.apply #qlx.action<h>(%111) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_62 = arith.constant 1.5707963267948966 : f64
    %113 = qlx.apply #qlx.action<pauli_rotation>(%108#1, %cst_62) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_63 = arith.constant 1.5707963267948966 : f64
    %114:2 = qlx.apply #qlx.action<pauli_rotation>(%112, %113, %cst_63) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 1.5707963267948966 : f64
    %115 = qlx.apply #qlx.action<pauli_rotation>(%105#0, %cst_64) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 1.5707963267948966 : f64
    %116 = qlx.apply #qlx.action<pauli_rotation>(%114#1, %cst_65) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_66 = arith.constant 1.5707963267948966 : f64
    %117:2 = qlx.apply #qlx.action<pauli_rotation>(%115, %116, %cst_66) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_67 = arith.constant 1.5707963267948966 : f64
    %118 = qlx.apply #qlx.action<pauli_rotation>(%102#0, %cst_67) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %119 = qlx.apply #qlx.action<h>(%118) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_68 = arith.constant 1.5707963267948966 : f64
    %120 = qlx.apply #qlx.action<pauli_rotation>(%119, %cst_68) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %121 = qlx.apply #qlx.action<h>(%120) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_69 = arith.constant 1.5707963267948966 : f64
    %122 = qlx.apply #qlx.action<pauli_rotation>(%102#1, %cst_69) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_70 = arith.constant 1.5707963267948966 : f64
    %123:2 = qlx.apply #qlx.action<pauli_rotation>(%121, %122, %cst_70) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_71 = arith.constant 1.5707963267948966 : f64
    %124 = qlx.apply #qlx.action<pauli_rotation>(%98#0, %cst_71) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_72 = arith.constant 1.5707963267948966 : f64
    %125 = qlx.apply #qlx.action<pauli_rotation>(%98#1, %cst_72) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_73 = arith.constant 1.5707963267948966 : f64
    %126:2 = qlx.apply #qlx.action<pauli_rotation>(%124, %125, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 1.5707963267948966 : f64
    %127 = qlx.apply #qlx.action<pauli_rotation>(%123#1, %cst_74) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %128 = qlx.apply #qlx.action<h>(%127) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_75 = arith.constant 1.5707963267948966 : f64
    %129 = qlx.apply #qlx.action<pauli_rotation>(%126#1, %cst_75) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_76 = arith.constant 1.5707963267948966 : f64
    %130:2 = qlx.apply #qlx.action<pauli_rotation>(%128, %129, %cst_76) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_77 = arith.constant 1.5707963267948966 : f64
    %131 = qlx.apply #qlx.action<pauli_rotation>(%130#1, %cst_77) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %132 = qlx.apply #qlx.action<h>(%131) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_78 = arith.constant 1.5707963267948966 : f64
    %133 = qlx.apply #qlx.action<pauli_rotation>(%117#1, %cst_78) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %134 = qlx.apply #qlx.action<h>(%133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 1.250000e-01 : f64
    %135:2 = qlx.apply #qlx.action<pauli_rotation>(%132, %134, %cst_79) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_80 = arith.constant 1.5707963267948966 : f64
    %136 = qlx.apply #qlx.action<pauli_rotation>(%130#0, %cst_80) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %137 = qlx.apply #qlx.action<h>(%135#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_81 = arith.constant 1.5707963267948966 : f64
    %138:2 = qlx.apply #qlx.action<pauli_rotation>(%136, %137, %cst_81) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.5707963267948966 : f64
    %139 = qlx.apply #qlx.action<pauli_rotation>(%126#0, %cst_82) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_83 = arith.constant 1.5707963267948966 : f64
    %140 = qlx.apply #qlx.action<pauli_rotation>(%138#1, %cst_83) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_84 = arith.constant 1.5707963267948966 : f64
    %141:2 = qlx.apply #qlx.action<pauli_rotation>(%139, %140, %cst_84) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_85 = arith.constant 1.5707963267948966 : f64
    %142 = qlx.apply #qlx.action<pauli_rotation>(%123#0, %cst_85) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_86 = arith.constant 1.5707963267948966 : f64
    %143 = qlx.apply #qlx.action<pauli_rotation>(%138#0, %cst_86) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %144 = qlx.apply #qlx.action<h>(%143) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 1.5707963267948966 : f64
    %145:2 = qlx.apply #qlx.action<pauli_rotation>(%142, %144, %cst_87) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.5707963267948966 : f64
    %146 = qlx.apply #qlx.action<pauli_rotation>(%117#0, %cst_88) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %147 = qlx.apply #qlx.action<h>(%135#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_89 = arith.constant 1.5707963267948966 : f64
    %148:2 = qlx.apply #qlx.action<pauli_rotation>(%146, %147, %cst_89) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_90 = arith.constant 1.5707963267948966 : f64
    %149 = qlx.apply #qlx.action<pauli_rotation>(%114#0, %cst_90) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_91 = arith.constant 1.5707963267948966 : f64
    %150 = qlx.apply #qlx.action<pauli_rotation>(%148#1, %cst_91) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_92 = arith.constant 1.5707963267948966 : f64
    %151:2 = qlx.apply #qlx.action<pauli_rotation>(%149, %150, %cst_92) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_93 = arith.constant 1.5707963267948966 : f64
    %152 = qlx.apply #qlx.action<pauli_rotation>(%148#0, %cst_93) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_94 = arith.constant 1.5707963267948966 : f64
    %153 = qlx.apply #qlx.action<pauli_rotation>(%151#1, %cst_94) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %154 = qlx.apply #qlx.action<h>(%153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_95 = arith.constant 1.5707963267948966 : f64
    %155:2 = qlx.apply #qlx.action<pauli_rotation>(%152, %154, %cst_95) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_96 = arith.constant 1.5707963267948966 : f64
    %156 = qlx.apply #qlx.action<pauli_rotation>(%145#0, %cst_96) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %157 = qlx.apply #qlx.action<h>(%156) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_97 = arith.constant 1.5707963267948966 : f64
    %158 = qlx.apply #qlx.action<pauli_rotation>(%157, %cst_97) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_98 = arith.constant 1.5707963267948966 : f64
    %159 = qlx.apply #qlx.action<pauli_rotation>(%145#1, %cst_98) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_99 = arith.constant 1.5707963267948966 : f64
    %160:2 = qlx.apply #qlx.action<pauli_rotation>(%158, %159, %cst_99) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.5707963267948966 : f64
    %161 = qlx.apply #qlx.action<pauli_rotation>(%141#0, %cst_100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_101 = arith.constant 1.5707963267948966 : f64
    %162 = qlx.apply #qlx.action<pauli_rotation>(%141#1, %cst_101) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_102 = arith.constant 1.5707963267948966 : f64
    %163:2 = qlx.apply #qlx.action<pauli_rotation>(%161, %162, %cst_102) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_103 = arith.constant 1.5707963267948966 : f64
    %164 = qlx.apply #qlx.action<pauli_rotation>(%160#1, %cst_103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %165 = qlx.apply #qlx.action<h>(%164) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_104 = arith.constant 1.5707963267948966 : f64
    %166 = qlx.apply #qlx.action<pauli_rotation>(%163#1, %cst_104) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_105 = arith.constant 1.5707963267948966 : f64
    %167:2 = qlx.apply #qlx.action<pauli_rotation>(%165, %166, %cst_105) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %168 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %169 = qlx.apply #qlx.action<h>(%168) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_106 = arith.constant 1.5707963267948966 : f64
    %170 = qlx.apply #qlx.action<pauli_rotation>(%167#1, %cst_106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_107 = arith.constant 1.5707963267948966 : f64
    %171:2 = qlx.apply #qlx.action<pauli_rotation>(%169, %170, %cst_107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_108 = arith.constant 1.5707963267948966 : f64
    %172 = qlx.apply #qlx.action<pauli_rotation>(%171#1, %cst_108) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %173 = qlx.apply #qlx.action<h>(%172) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_109 = arith.constant 1.5707963267948966 : f64
    %174 = qlx.apply #qlx.action<pauli_rotation>(%155#1, %cst_109) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %175 = qlx.apply #qlx.action<h>(%174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_110 = arith.constant 1.250000e-01 : f64
    %176:2 = qlx.apply #qlx.action<pauli_rotation>(%173, %175, %cst_110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_111 = arith.constant 1.5707963267948966 : f64
    %177 = qlx.apply #qlx.action<pauli_rotation>(%171#0, %cst_111) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %178 = qlx.apply #qlx.action<h>(%176#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_112 = arith.constant 1.5707963267948966 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%177, %178, %cst_112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_113 = arith.constant 1.5707963267948966 : f64
    %180 = qlx.apply #qlx.action<pauli_rotation>(%167#0, %cst_113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 1.5707963267948966 : f64
    %181 = qlx.apply #qlx.action<pauli_rotation>(%179#1, %cst_114) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_115 = arith.constant 1.5707963267948966 : f64
    %182:2 = qlx.apply #qlx.action<pauli_rotation>(%180, %181, %cst_115) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 1.5707963267948966 : f64
    %183 = qlx.apply #qlx.action<pauli_rotation>(%163#0, %cst_116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_117 = arith.constant 1.5707963267948966 : f64
    %184 = qlx.apply #qlx.action<pauli_rotation>(%182#1, %cst_117) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_118 = arith.constant 1.5707963267948966 : f64
    %185:2 = qlx.apply #qlx.action<pauli_rotation>(%183, %184, %cst_118) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_119 = arith.constant 1.5707963267948966 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%160#0, %cst_119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_120 = arith.constant 1.5707963267948966 : f64
    %187 = qlx.apply #qlx.action<pauli_rotation>(%182#0, %cst_120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %188 = qlx.apply #qlx.action<h>(%187) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_121 = arith.constant 1.5707963267948966 : f64
    %189:2 = qlx.apply #qlx.action<pauli_rotation>(%186, %188, %cst_121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_122 = arith.constant 1.5707963267948966 : f64
    %190 = qlx.apply #qlx.action<pauli_rotation>(%155#0, %cst_122) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %191 = qlx.apply #qlx.action<h>(%176#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_123 = arith.constant 1.5707963267948966 : f64
    %192:2 = qlx.apply #qlx.action<pauli_rotation>(%190, %191, %cst_123) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 1.5707963267948966 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%192#0, %cst_124) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 3.1415926535897931 : f64
    %194 = qlx.apply #qlx.action<pauli_rotation>(%192#1, %cst_125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_126 = arith.constant 1.5707963267948966 : f64
    %195:2 = qlx.apply #qlx.action<pauli_rotation>(%193, %194, %cst_126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_127 = arith.constant 1.5707963267948966 : f64
    %196 = qlx.apply #qlx.action<pauli_rotation>(%189#0, %cst_127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_128 = arith.constant 1.5707963267948966 : f64
    %197 = qlx.apply #qlx.action<pauli_rotation>(%189#1, %cst_128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_129 = arith.constant 1.5707963267948966 : f64
    %198:2 = qlx.apply #qlx.action<pauli_rotation>(%196, %197, %cst_129) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 1.5707963267948966 : f64
    %199 = qlx.apply #qlx.action<pauli_rotation>(%185#0, %cst_130) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 1.5707963267948966 : f64
    %200 = qlx.apply #qlx.action<pauli_rotation>(%185#1, %cst_131) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_132 = arith.constant 1.5707963267948966 : f64
    %201:2 = qlx.apply #qlx.action<pauli_rotation>(%199, %200, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_133 = arith.constant 1.5707963267948966 : f64
    %202 = qlx.apply #qlx.action<pauli_rotation>(%198#1, %cst_133) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %203 = qlx.apply #qlx.action<h>(%202) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_134 = arith.constant 1.5707963267948966 : f64
    %204 = qlx.apply #qlx.action<pauli_rotation>(%201#1, %cst_134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_135 = arith.constant 1.5707963267948966 : f64
    %205:2 = qlx.apply #qlx.action<pauli_rotation>(%203, %204, %cst_135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 1.5707963267948966 : f64
    %206 = qlx.apply #qlx.action<pauli_rotation>(%179#0, %cst_136) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %207 = qlx.apply #qlx.action<h>(%206) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_137 = arith.constant 1.5707963267948966 : f64
    %208 = qlx.apply #qlx.action<pauli_rotation>(%207, %cst_137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %209 = qlx.apply #qlx.action<h>(%208) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_138 = arith.constant 1.5707963267948966 : f64
    %210 = qlx.apply #qlx.action<pauli_rotation>(%205#1, %cst_138) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_139 = arith.constant 1.5707963267948966 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%209, %210, %cst_139) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_140 = arith.constant 1.5707963267948966 : f64
    %212 = qlx.apply #qlx.action<pauli_rotation>(%211#1, %cst_140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %213 = qlx.apply #qlx.action<h>(%212) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_141 = arith.constant 1.5707963267948966 : f64
    %214 = qlx.apply #qlx.action<pauli_rotation>(%195#1, %cst_141) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %215 = qlx.apply #qlx.action<h>(%214) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_142 = arith.constant 1.250000e-01 : f64
    %216:2 = qlx.apply #qlx.action<pauli_rotation>(%213, %215, %cst_142) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_143 = arith.constant 1.5707963267948966 : f64
    %217 = qlx.apply #qlx.action<pauli_rotation>(%211#0, %cst_143) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %218 = qlx.apply #qlx.action<h>(%216#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_144 = arith.constant 1.5707963267948966 : f64
    %219:2 = qlx.apply #qlx.action<pauli_rotation>(%217, %218, %cst_144) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_145 = arith.constant 1.5707963267948966 : f64
    %220 = qlx.apply #qlx.action<pauli_rotation>(%205#0, %cst_145) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_146 = arith.constant 1.5707963267948966 : f64
    %221 = qlx.apply #qlx.action<pauli_rotation>(%219#1, %cst_146) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_147 = arith.constant 1.5707963267948966 : f64
    %222:2 = qlx.apply #qlx.action<pauli_rotation>(%220, %221, %cst_147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_148 = arith.constant 1.5707963267948966 : f64
    %223 = qlx.apply #qlx.action<pauli_rotation>(%201#0, %cst_148) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_149 = arith.constant 1.5707963267948966 : f64
    %224 = qlx.apply #qlx.action<pauli_rotation>(%222#1, %cst_149) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_150 = arith.constant 1.5707963267948966 : f64
    %225:2 = qlx.apply #qlx.action<pauli_rotation>(%223, %224, %cst_150) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_151 = arith.constant 1.5707963267948966 : f64
    %226 = qlx.apply #qlx.action<pauli_rotation>(%198#0, %cst_151) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_152 = arith.constant 1.5707963267948966 : f64
    %227 = qlx.apply #qlx.action<pauli_rotation>(%222#0, %cst_152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %228 = qlx.apply #qlx.action<h>(%227) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_153 = arith.constant 1.5707963267948966 : f64
    %229:2 = qlx.apply #qlx.action<pauli_rotation>(%226, %228, %cst_153) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_154 = arith.constant 1.5707963267948966 : f64
    %230 = qlx.apply #qlx.action<pauli_rotation>(%195#0, %cst_154) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %231 = qlx.apply #qlx.action<h>(%216#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_155 = arith.constant 1.5707963267948966 : f64
    %232:2 = qlx.apply #qlx.action<pauli_rotation>(%230, %231, %cst_155) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_156 = arith.constant 1.5707963267948966 : f64
    %233 = qlx.apply #qlx.action<pauli_rotation>(%225#1, %cst_156) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_157 = arith.constant 1.5707963267948966 : f64
    %234 = qlx.apply #qlx.action<pauli_rotation>(%225#0, %cst_157) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %235 = qlx.apply #qlx.action<h>(%234) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_158 = arith.constant 1.5707963267948966 : f64
    %236:2 = qlx.apply #qlx.action<pauli_rotation>(%233, %235, %cst_158) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_159 = arith.constant 1.5707963267948966 : f64
    %237 = qlx.apply #qlx.action<pauli_rotation>(%236#1, %cst_159) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %238 = qlx.apply #qlx.action<h>(%237) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_160 = arith.constant 1.5707963267948966 : f64
    %239 = qlx.apply #qlx.action<pauli_rotation>(%232#0, %cst_160) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %240 = qlx.apply #qlx.action<h>(%239) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_161 = arith.constant 1.250000e-01 : f64
    %241:2 = qlx.apply #qlx.action<pauli_rotation>(%238, %240, %cst_161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_162 = arith.constant 1.5707963267948966 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%236#0, %cst_162) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %243 = qlx.apply #qlx.action<h>(%241#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_163 = arith.constant 1.5707963267948966 : f64
    %244:2 = qlx.apply #qlx.action<pauli_rotation>(%242, %243, %cst_163) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_164 = arith.constant 1.5707963267948966 : f64
    %245 = qlx.apply #qlx.action<pauli_rotation>(%244#0, %cst_164) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %246 = qlx.apply #qlx.action<h>(%245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_165 = arith.constant 1.5707963267948966 : f64
    %247 = qlx.apply #qlx.action<pauli_rotation>(%246, %cst_165) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %248 = qlx.apply #qlx.action<h>(%247) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_166 = arith.constant 1.5707963267948966 : f64
    %249 = qlx.apply #qlx.action<pauli_rotation>(%244#1, %cst_166) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_167 = arith.constant 1.5707963267948966 : f64
    %250:2 = qlx.apply #qlx.action<pauli_rotation>(%248, %249, %cst_167) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_168 = arith.constant 1.5707963267948966 : f64
    %251 = qlx.apply #qlx.action<pauli_rotation>(%250#1, %cst_168) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %252 = qlx.apply #qlx.action<h>(%251) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %253 = qlx.apply #qlx.action<h>(%241#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_169 = arith.constant 1.5707963267948966 : f64
    %254 = qlx.apply #qlx.action<pauli_rotation>(%253, %cst_169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %255 = qlx.apply #qlx.action<h>(%254) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_170 = arith.constant 1.250000e-01 : f64
    %256:2 = qlx.apply #qlx.action<pauli_rotation>(%252, %255, %cst_170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_171 = arith.constant 1.5707963267948966 : f64
    %257 = qlx.apply #qlx.action<pauli_rotation>(%250#0, %cst_171) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %258 = qlx.apply #qlx.action<h>(%256#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_172 = arith.constant 1.5707963267948966 : f64
    %259:2 = qlx.apply #qlx.action<pauli_rotation>(%257, %258, %cst_172) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_173 = arith.constant 1.5707963267948966 : f64
    %260 = qlx.apply #qlx.action<pauli_rotation>(%229#1, %cst_173) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_174 = arith.constant 1.5707963267948966 : f64
    %261 = qlx.apply #qlx.action<pauli_rotation>(%259#0, %cst_174) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %262 = qlx.apply #qlx.action<h>(%261) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_175 = arith.constant 1.5707963267948966 : f64
    %263 = qlx.apply #qlx.action<pauli_rotation>(%262, %cst_175) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %264 = qlx.apply #qlx.action<h>(%263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_176 = arith.constant 1.5707963267948966 : f64
    %265:2 = qlx.apply #qlx.action<pauli_rotation>(%260, %264, %cst_176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_177 = arith.constant 1.5707963267948966 : f64
    %266 = qlx.apply #qlx.action<pauli_rotation>(%265#1, %cst_177) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %267 = qlx.apply #qlx.action<h>(%266) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_178 = arith.constant 1.5707963267948966 : f64
    %268 = qlx.apply #qlx.action<pauli_rotation>(%259#1, %cst_178) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_179 = arith.constant 1.250000e-01 : f64
    %269:2 = qlx.apply #qlx.action<pauli_rotation>(%267, %268, %cst_179) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_180 = arith.constant 1.5707963267948966 : f64
    %270 = qlx.apply #qlx.action<pauli_rotation>(%265#0, %cst_180) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %271 = qlx.apply #qlx.action<h>(%269#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_181 = arith.constant 1.5707963267948966 : f64
    %272:2 = qlx.apply #qlx.action<pauli_rotation>(%270, %271, %cst_181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_182 = arith.constant 1.5707963267948966 : f64
    %273 = qlx.apply #qlx.action<pauli_rotation>(%272#0, %cst_182) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %274 = qlx.apply #qlx.action<h>(%273) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_183 = arith.constant 1.5707963267948966 : f64
    %275 = qlx.apply #qlx.action<pauli_rotation>(%274, %cst_183) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %276 = qlx.apply #qlx.action<h>(%275) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_184 = arith.constant 1.5707963267948966 : f64
    %277 = qlx.apply #qlx.action<pauli_rotation>(%272#1, %cst_184) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 1.5707963267948966 : f64
    %278:2 = qlx.apply #qlx.action<pauli_rotation>(%276, %277, %cst_185) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_186 = arith.constant 1.5707963267948966 : f64
    %279 = qlx.apply #qlx.action<pauli_rotation>(%278#1, %cst_186) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %280 = qlx.apply #qlx.action<h>(%279) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %281 = qlx.apply #qlx.action<h>(%269#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_187 = arith.constant 1.5707963267948966 : f64
    %282 = qlx.apply #qlx.action<pauli_rotation>(%281, %cst_187) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %283 = qlx.apply #qlx.action<h>(%282) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_188 = arith.constant 1.250000e-01 : f64
    %284:2 = qlx.apply #qlx.action<pauli_rotation>(%280, %283, %cst_188) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_189 = arith.constant 1.5707963267948966 : f64
    %285 = qlx.apply #qlx.action<pauli_rotation>(%278#0, %cst_189) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %286 = qlx.apply #qlx.action<h>(%284#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_190 = arith.constant 1.5707963267948966 : f64
    %287:2 = qlx.apply #qlx.action<pauli_rotation>(%285, %286, %cst_190) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_191 = arith.constant 1.5707963267948966 : f64
    %288 = qlx.apply #qlx.action<pauli_rotation>(%229#0, %cst_191) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %289 = qlx.apply #qlx.action<h>(%288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_192 = arith.constant 1.5707963267948966 : f64
    %290 = qlx.apply #qlx.action<pauli_rotation>(%287#0, %cst_192) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %291 = qlx.apply #qlx.action<h>(%290) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_193 = arith.constant 1.5707963267948966 : f64
    %292 = qlx.apply #qlx.action<pauli_rotation>(%291, %cst_193) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %293 = qlx.apply #qlx.action<h>(%292) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_194 = arith.constant 1.5707963267948966 : f64
    %294:2 = qlx.apply #qlx.action<pauli_rotation>(%289, %293, %cst_194) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_195 = arith.constant 1.5707963267948966 : f64
    %295 = qlx.apply #qlx.action<pauli_rotation>(%294#1, %cst_195) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %296 = qlx.apply #qlx.action<h>(%295) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_196 = arith.constant 1.5707963267948966 : f64
    %297 = qlx.apply #qlx.action<pauli_rotation>(%287#1, %cst_196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_197 = arith.constant 1.250000e-01 : f64
    %298:2 = qlx.apply #qlx.action<pauli_rotation>(%296, %297, %cst_197) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_198 = arith.constant 1.5707963267948966 : f64
    %299 = qlx.apply #qlx.action<pauli_rotation>(%294#0, %cst_198) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %300 = qlx.apply #qlx.action<h>(%298#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_199 = arith.constant 1.5707963267948966 : f64
    %301:2 = qlx.apply #qlx.action<pauli_rotation>(%299, %300, %cst_199) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_200 = arith.constant 1.5707963267948966 : f64
    %302 = qlx.apply #qlx.action<pauli_rotation>(%301#0, %cst_200) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %303 = qlx.apply #qlx.action<h>(%302) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_201 = arith.constant 1.5707963267948966 : f64
    %304 = qlx.apply #qlx.action<pauli_rotation>(%303, %cst_201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %305 = qlx.apply #qlx.action<h>(%304) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_202 = arith.constant 1.5707963267948966 : f64
    %306 = qlx.apply #qlx.action<pauli_rotation>(%301#1, %cst_202) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_203 = arith.constant 1.5707963267948966 : f64
    %307:2 = qlx.apply #qlx.action<pauli_rotation>(%305, %306, %cst_203) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_204 = arith.constant 1.5707963267948966 : f64
    %308 = qlx.apply #qlx.action<pauli_rotation>(%307#1, %cst_204) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %309 = qlx.apply #qlx.action<h>(%308) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %310 = qlx.apply #qlx.action<h>(%298#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_205 = arith.constant 1.5707963267948966 : f64
    %311 = qlx.apply #qlx.action<pauli_rotation>(%310, %cst_205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %312 = qlx.apply #qlx.action<h>(%311) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_206 = arith.constant 1.250000e-01 : f64
    %313:2 = qlx.apply #qlx.action<pauli_rotation>(%309, %312, %cst_206) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_207 = arith.constant 1.5707963267948966 : f64
    %314 = qlx.apply #qlx.action<pauli_rotation>(%307#0, %cst_207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %315 = qlx.apply #qlx.action<h>(%313#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_208 = arith.constant 1.5707963267948966 : f64
    %316:2 = qlx.apply #qlx.action<pauli_rotation>(%314, %315, %cst_208) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_209 = arith.constant 1.5707963267948966 : f64
    %317 = qlx.apply #qlx.action<pauli_rotation>(%219#0, %cst_209) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %318 = qlx.apply #qlx.action<h>(%317) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_210 = arith.constant 1.5707963267948966 : f64
    %319 = qlx.apply #qlx.action<pauli_rotation>(%318, %cst_210) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %320 = qlx.apply #qlx.action<h>(%319) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_211 = arith.constant 1.5707963267948966 : f64
    %321 = qlx.apply #qlx.action<pauli_rotation>(%316#0, %cst_211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %322 = qlx.apply #qlx.action<h>(%321) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_212 = arith.constant 1.5707963267948966 : f64
    %323 = qlx.apply #qlx.action<pauli_rotation>(%322, %cst_212) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %324 = qlx.apply #qlx.action<h>(%323) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_213 = arith.constant 1.5707963267948966 : f64
    %325:2 = qlx.apply #qlx.action<pauli_rotation>(%320, %324, %cst_213) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 1.5707963267948966 : f64
    %326 = qlx.apply #qlx.action<pauli_rotation>(%325#1, %cst_214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %327 = qlx.apply #qlx.action<h>(%326) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_215 = arith.constant 1.5707963267948966 : f64
    %328 = qlx.apply #qlx.action<pauli_rotation>(%316#1, %cst_215) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_216 = arith.constant 1.250000e-01 : f64
    %329:2 = qlx.apply #qlx.action<pauli_rotation>(%327, %328, %cst_216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_217 = arith.constant 1.5707963267948966 : f64
    %330 = qlx.apply #qlx.action<pauli_rotation>(%325#0, %cst_217) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %331 = qlx.apply #qlx.action<h>(%329#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_218 = arith.constant 1.5707963267948966 : f64
    %332:2 = qlx.apply #qlx.action<pauli_rotation>(%330, %331, %cst_218) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_219 = arith.constant 1.5707963267948966 : f64
    %333 = qlx.apply #qlx.action<pauli_rotation>(%332#0, %cst_219) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %334 = qlx.apply #qlx.action<h>(%333) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_220 = arith.constant 1.5707963267948966 : f64
    %335 = qlx.apply #qlx.action<pauli_rotation>(%334, %cst_220) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %336 = qlx.apply #qlx.action<h>(%335) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_221 = arith.constant 1.5707963267948966 : f64
    %337 = qlx.apply #qlx.action<pauli_rotation>(%332#1, %cst_221) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_222 = arith.constant 1.5707963267948966 : f64
    %338:2 = qlx.apply #qlx.action<pauli_rotation>(%336, %337, %cst_222) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_223 = arith.constant 1.5707963267948966 : f64
    %339 = qlx.apply #qlx.action<pauli_rotation>(%338#1, %cst_223) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %340 = qlx.apply #qlx.action<h>(%339) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %341 = qlx.apply #qlx.action<h>(%329#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_224 = arith.constant 1.5707963267948966 : f64
    %342 = qlx.apply #qlx.action<pauli_rotation>(%341, %cst_224) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %343 = qlx.apply #qlx.action<h>(%342) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_225 = arith.constant 1.250000e-01 : f64
    %344:2 = qlx.apply #qlx.action<pauli_rotation>(%340, %343, %cst_225) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_226 = arith.constant 1.5707963267948966 : f64
    %345 = qlx.apply #qlx.action<pauli_rotation>(%338#0, %cst_226) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %346 = qlx.apply #qlx.action<h>(%344#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_227 = arith.constant 1.5707963267948966 : f64
    %347:2 = qlx.apply #qlx.action<pauli_rotation>(%345, %346, %cst_227) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %348 = qlx.apply #qlx.action<h>(%256#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_228 = arith.constant 1.5707963267948966 : f64
    %349 = qlx.apply #qlx.action<pauli_rotation>(%348, %cst_228) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %350 = qlx.apply #qlx.action<h>(%284#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_229 = arith.constant 1.5707963267948966 : f64
    %351 = qlx.apply #qlx.action<pauli_rotation>(%350, %cst_229) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_230 = arith.constant 2.500000e-01 : f64
    %352:2 = qlx.apply #qlx.action<pauli_rotation>(%349, %351, %cst_230) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %353 = qlx.apply #qlx.action<h>(%313#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_231 = arith.constant 1.5707963267948966 : f64
    %354 = qlx.apply #qlx.action<pauli_rotation>(%353, %cst_231) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %355 = qlx.apply #qlx.action<h>(%344#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_232 = arith.constant 1.5707963267948966 : f64
    %356 = qlx.apply #qlx.action<pauli_rotation>(%355, %cst_232) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_233 = arith.constant 2.500000e-01 : f64
    %357:2 = qlx.apply #qlx.action<pauli_rotation>(%354, %356, %cst_233) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_234 = arith.constant 1.5707963267948966 : f64
    %358 = qlx.apply #qlx.action<pauli_rotation>(%347#1, %cst_234) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %359 = qlx.apply #qlx.action<h>(%358) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_235 = arith.constant 1.5707963267948966 : f64
    %360 = qlx.apply #qlx.action<pauli_rotation>(%347#0, %cst_235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %361 = qlx.apply #qlx.action<h>(%360) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_236 = arith.constant 1.5707963267948966 : f64
    %362 = qlx.apply #qlx.action<pauli_rotation>(%361, %cst_236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_237 = arith.constant 5.000000e-01 : f64
    %363:2 = qlx.apply #qlx.action<pauli_rotation>(%359, %362, %cst_237) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_238 = arith.constant 2.500000e-01 : f64
    %364:2 = qlx.apply #qlx.action<pauli_rotation>(%357#0, %357#1, %cst_238) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_239 = arith.constant 2.500000e-01 : f64
    %365:2 = qlx.apply #qlx.action<pauli_rotation>(%352#0, %352#1, %cst_239) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_240 = arith.constant 1.5707963267948966 : f64
    %366 = qlx.apply #qlx.action<pauli_rotation>(%363#1, %cst_240) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %367 = qlx.apply #qlx.action<h>(%366) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %368 = qlx.apply #qlx.action<h>(%363#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_241 = arith.constant 1.5707963267948966 : f64
    %369:2 = qlx.apply #qlx.action<pauli_rotation>(%367, %368, %cst_241) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_242 = arith.constant 1.5707963267948966 : f64
    %370 = qlx.apply #qlx.action<pauli_rotation>(%369#1, %cst_242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %371 = qlx.apply #qlx.action<h>(%370) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_243 = arith.constant 1.5707963267948966 : f64
    %372 = qlx.apply #qlx.action<pauli_rotation>(%364#1, %cst_243) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %373 = qlx.apply #qlx.action<h>(%372) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_244 = arith.constant 1.250000e-01 : f64
    %374:2 = qlx.apply #qlx.action<pauli_rotation>(%371, %373, %cst_244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_245 = arith.constant 1.5707963267948966 : f64
    %375 = qlx.apply #qlx.action<pauli_rotation>(%369#0, %cst_245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %376 = qlx.apply #qlx.action<h>(%374#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_246 = arith.constant 1.5707963267948966 : f64
    %377:2 = qlx.apply #qlx.action<pauli_rotation>(%375, %376, %cst_246) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_247 = arith.constant 1.5707963267948966 : f64
    %378 = qlx.apply #qlx.action<pauli_rotation>(%377#0, %cst_247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %379 = qlx.apply #qlx.action<h>(%378) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_248 = arith.constant 1.5707963267948966 : f64
    %380 = qlx.apply #qlx.action<pauli_rotation>(%379, %cst_248) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %381 = qlx.apply #qlx.action<h>(%380) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_249 = arith.constant 1.5707963267948966 : f64
    %382 = qlx.apply #qlx.action<pauli_rotation>(%377#1, %cst_249) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_250 = arith.constant 1.5707963267948966 : f64
    %383:2 = qlx.apply #qlx.action<pauli_rotation>(%381, %382, %cst_250) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_251 = arith.constant 1.5707963267948966 : f64
    %384 = qlx.apply #qlx.action<pauli_rotation>(%383#1, %cst_251) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %385 = qlx.apply #qlx.action<h>(%384) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %386 = qlx.apply #qlx.action<h>(%374#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_252 = arith.constant 1.5707963267948966 : f64
    %387 = qlx.apply #qlx.action<pauli_rotation>(%386, %cst_252) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %388 = qlx.apply #qlx.action<h>(%387) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_253 = arith.constant 1.250000e-01 : f64
    %389:2 = qlx.apply #qlx.action<pauli_rotation>(%385, %388, %cst_253) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_254 = arith.constant 1.5707963267948966 : f64
    %390 = qlx.apply #qlx.action<pauli_rotation>(%383#0, %cst_254) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %391 = qlx.apply #qlx.action<h>(%389#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_255 = arith.constant 1.5707963267948966 : f64
    %392:2 = qlx.apply #qlx.action<pauli_rotation>(%390, %391, %cst_255) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_256 = arith.constant 1.5707963267948966 : f64
    %393 = qlx.apply #qlx.action<pauli_rotation>(%392#1, %cst_256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %394 = qlx.apply #qlx.action<h>(%393) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_257 = arith.constant 1.5707963267948966 : f64
    %395 = qlx.apply #qlx.action<pauli_rotation>(%394, %cst_257) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %396 = qlx.apply #qlx.action<h>(%395) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_258 = arith.constant 1.5707963267948966 : f64
    %397:2 = qlx.apply #qlx.action<pauli_rotation>(%389#1, %396, %cst_258) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_259 = arith.constant 1.5707963267948966 : f64
    %398 = qlx.apply #qlx.action<pauli_rotation>(%397#0, %cst_259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %399 = qlx.apply #qlx.action<h>(%398) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_260 = arith.constant 1.5707963267948966 : f64
    %400 = qlx.apply #qlx.action<pauli_rotation>(%364#0, %cst_260) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %401 = qlx.apply #qlx.action<h>(%400) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_261 = arith.constant 1.250000e-01 : f64
    %402:2 = qlx.apply #qlx.action<pauli_rotation>(%399, %401, %cst_261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_262 = arith.constant 1.5707963267948966 : f64
    %403 = qlx.apply #qlx.action<pauli_rotation>(%397#1, %cst_262) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %404 = qlx.apply #qlx.action<h>(%402#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_263 = arith.constant 1.5707963267948966 : f64
    %405:2 = qlx.apply #qlx.action<pauli_rotation>(%403, %404, %cst_263) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_264 = arith.constant 1.5707963267948966 : f64
    %406 = qlx.apply #qlx.action<pauli_rotation>(%405#0, %cst_264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %407 = qlx.apply #qlx.action<h>(%406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_265 = arith.constant 1.5707963267948966 : f64
    %408 = qlx.apply #qlx.action<pauli_rotation>(%407, %cst_265) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %409 = qlx.apply #qlx.action<h>(%408) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_266 = arith.constant 1.5707963267948966 : f64
    %410 = qlx.apply #qlx.action<pauli_rotation>(%405#1, %cst_266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_267 = arith.constant 1.5707963267948966 : f64
    %411:2 = qlx.apply #qlx.action<pauli_rotation>(%409, %410, %cst_267) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_268 = arith.constant 1.5707963267948966 : f64
    %412 = qlx.apply #qlx.action<pauli_rotation>(%411#1, %cst_268) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %413 = qlx.apply #qlx.action<h>(%412) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %414 = qlx.apply #qlx.action<h>(%402#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_269 = arith.constant 1.5707963267948966 : f64
    %415 = qlx.apply #qlx.action<pauli_rotation>(%414, %cst_269) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %416 = qlx.apply #qlx.action<h>(%415) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_270 = arith.constant 1.250000e-01 : f64
    %417:2 = qlx.apply #qlx.action<pauli_rotation>(%413, %416, %cst_270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_271 = arith.constant 1.5707963267948966 : f64
    %418 = qlx.apply #qlx.action<pauli_rotation>(%411#0, %cst_271) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %419 = qlx.apply #qlx.action<h>(%417#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_272 = arith.constant 1.5707963267948966 : f64
    %420:2 = qlx.apply #qlx.action<pauli_rotation>(%418, %419, %cst_272) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_273 = arith.constant 1.5707963267948966 : f64
    %421 = qlx.apply #qlx.action<pauli_rotation>(%420#1, %cst_273) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %422 = qlx.apply #qlx.action<h>(%421) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_274 = arith.constant 1.5707963267948966 : f64
    %423 = qlx.apply #qlx.action<pauli_rotation>(%422, %cst_274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %424 = qlx.apply #qlx.action<h>(%423) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_275 = arith.constant 1.5707963267948966 : f64
    %425:2 = qlx.apply #qlx.action<pauli_rotation>(%417#1, %424, %cst_275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_276 = arith.constant 1.5707963267948966 : f64
    %426 = qlx.apply #qlx.action<pauli_rotation>(%425#0, %cst_276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %427 = qlx.apply #qlx.action<h>(%426) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_277 = arith.constant 1.5707963267948966 : f64
    %428 = qlx.apply #qlx.action<pauli_rotation>(%365#1, %cst_277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %429 = qlx.apply #qlx.action<h>(%428) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_278 = arith.constant 1.250000e-01 : f64
    %430:2 = qlx.apply #qlx.action<pauli_rotation>(%427, %429, %cst_278) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_279 = arith.constant 1.5707963267948966 : f64
    %431 = qlx.apply #qlx.action<pauli_rotation>(%425#1, %cst_279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %432 = qlx.apply #qlx.action<h>(%430#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_280 = arith.constant 1.5707963267948966 : f64
    %433:2 = qlx.apply #qlx.action<pauli_rotation>(%431, %432, %cst_280) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_281 = arith.constant 1.5707963267948966 : f64
    %434 = qlx.apply #qlx.action<pauli_rotation>(%433#0, %cst_281) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %435 = qlx.apply #qlx.action<h>(%434) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_282 = arith.constant 1.5707963267948966 : f64
    %436 = qlx.apply #qlx.action<pauli_rotation>(%435, %cst_282) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %437 = qlx.apply #qlx.action<h>(%436) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_283 = arith.constant 1.5707963267948966 : f64
    %438 = qlx.apply #qlx.action<pauli_rotation>(%433#1, %cst_283) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_284 = arith.constant 1.5707963267948966 : f64
    %439:2 = qlx.apply #qlx.action<pauli_rotation>(%437, %438, %cst_284) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_285 = arith.constant 1.5707963267948966 : f64
    %440 = qlx.apply #qlx.action<pauli_rotation>(%439#1, %cst_285) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %441 = qlx.apply #qlx.action<h>(%440) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %442 = qlx.apply #qlx.action<h>(%430#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_286 = arith.constant 1.5707963267948966 : f64
    %443 = qlx.apply #qlx.action<pauli_rotation>(%442, %cst_286) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %444 = qlx.apply #qlx.action<h>(%443) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_287 = arith.constant 1.250000e-01 : f64
    %445:2 = qlx.apply #qlx.action<pauli_rotation>(%441, %444, %cst_287) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_288 = arith.constant 1.5707963267948966 : f64
    %446 = qlx.apply #qlx.action<pauli_rotation>(%439#0, %cst_288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %447 = qlx.apply #qlx.action<h>(%445#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_289 = arith.constant 1.5707963267948966 : f64
    %448:2 = qlx.apply #qlx.action<pauli_rotation>(%446, %447, %cst_289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_290 = arith.constant 1.5707963267948966 : f64
    %449 = qlx.apply #qlx.action<pauli_rotation>(%448#1, %cst_290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %450 = qlx.apply #qlx.action<h>(%449) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_291 = arith.constant 1.5707963267948966 : f64
    %451 = qlx.apply #qlx.action<pauli_rotation>(%450, %cst_291) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %452 = qlx.apply #qlx.action<h>(%451) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_292 = arith.constant 1.5707963267948966 : f64
    %453:2 = qlx.apply #qlx.action<pauli_rotation>(%445#1, %452, %cst_292) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_293 = arith.constant 1.5707963267948966 : f64
    %454 = qlx.apply #qlx.action<pauli_rotation>(%453#0, %cst_293) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %455 = qlx.apply #qlx.action<h>(%454) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_294 = arith.constant 1.5707963267948966 : f64
    %456 = qlx.apply #qlx.action<pauli_rotation>(%365#0, %cst_294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %457 = qlx.apply #qlx.action<h>(%456) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_295 = arith.constant 1.250000e-01 : f64
    %458:2 = qlx.apply #qlx.action<pauli_rotation>(%455, %457, %cst_295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_296 = arith.constant 1.5707963267948966 : f64
    %459 = qlx.apply #qlx.action<pauli_rotation>(%453#1, %cst_296) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %460 = qlx.apply #qlx.action<h>(%458#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_297 = arith.constant 1.5707963267948966 : f64
    %461:2 = qlx.apply #qlx.action<pauli_rotation>(%459, %460, %cst_297) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 1.5707963267948966 : f64
    %462 = qlx.apply #qlx.action<pauli_rotation>(%461#0, %cst_298) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %463 = qlx.apply #qlx.action<h>(%462) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_299 = arith.constant 1.5707963267948966 : f64
    %464 = qlx.apply #qlx.action<pauli_rotation>(%463, %cst_299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %465 = qlx.apply #qlx.action<h>(%464) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_300 = arith.constant 1.5707963267948966 : f64
    %466 = qlx.apply #qlx.action<pauli_rotation>(%461#1, %cst_300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_301 = arith.constant 1.5707963267948966 : f64
    %467:2 = qlx.apply #qlx.action<pauli_rotation>(%465, %466, %cst_301) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_302 = arith.constant 1.5707963267948966 : f64
    %468 = qlx.apply #qlx.action<pauli_rotation>(%467#1, %cst_302) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %469 = qlx.apply #qlx.action<h>(%468) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %470 = qlx.apply #qlx.action<h>(%458#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_303 = arith.constant 1.5707963267948966 : f64
    %471 = qlx.apply #qlx.action<pauli_rotation>(%470, %cst_303) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %472 = qlx.apply #qlx.action<h>(%471) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_304 = arith.constant 1.250000e-01 : f64
    %473:2 = qlx.apply #qlx.action<pauli_rotation>(%469, %472, %cst_304) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_305 = arith.constant 1.5707963267948966 : f64
    %474 = qlx.apply #qlx.action<pauli_rotation>(%467#0, %cst_305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %475 = qlx.apply #qlx.action<h>(%473#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_306 = arith.constant 1.5707963267948966 : f64
    %476:2 = qlx.apply #qlx.action<pauli_rotation>(%474, %475, %cst_306) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %477 = qlx.apply #qlx.action<h>(%473#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_307 = arith.constant 1.5707963267948966 : f64
    %478 = qlx.apply #qlx.action<pauli_rotation>(%232#1, %cst_307) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_308 = arith.constant 1.5707963267948966 : f64
    %479:2 = qlx.apply #qlx.action<pauli_rotation>(%477, %478, %cst_308) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_309 = arith.constant 1.5707963267948966 : f64
    %480 = qlx.apply #qlx.action<pauli_rotation>(%420#0, %cst_309) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %481 = qlx.apply #qlx.action<h>(%480) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_310 = arith.constant 1.5707963267948966 : f64
    %482 = qlx.apply #qlx.action<pauli_rotation>(%448#0, %cst_310) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_311 = arith.constant 1.5707963267948966 : f64
    %483:2 = qlx.apply #qlx.action<pauli_rotation>(%481, %482, %cst_311) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_312 = arith.constant 1.5707963267948966 : f64
    %484 = qlx.apply #qlx.action<pauli_rotation>(%476#1, %cst_312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %485 = qlx.apply #qlx.action<h>(%484) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_313 = arith.constant 1.5707963267948966 : f64
    %486 = qlx.apply #qlx.action<pauli_rotation>(%476#0, %cst_313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_314 = arith.constant 1.5707963267948966 : f64
    %487:2 = qlx.apply #qlx.action<pauli_rotation>(%485, %486, %cst_314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_315 = arith.constant 1.5707963267948966 : f64
    %488 = qlx.apply #qlx.action<pauli_rotation>(%483#1, %cst_315) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %489 = qlx.apply #qlx.action<h>(%488) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_316 = arith.constant 1.5707963267948966 : f64
    %490 = qlx.apply #qlx.action<pauli_rotation>(%487#1, %cst_316) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_317 = arith.constant 1.5707963267948966 : f64
    %491:2 = qlx.apply #qlx.action<pauli_rotation>(%489, %490, %cst_317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_318 = arith.constant 1.5707963267948966 : f64
    %492 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %cst_318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %493 = qlx.apply #qlx.action<h>(%492) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_319 = arith.constant 1.5707963267948966 : f64
    %494 = qlx.apply #qlx.action<pauli_rotation>(%493, %cst_319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %495 = qlx.apply #qlx.action<h>(%494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_320 = arith.constant 1.5707963267948966 : f64
    %496 = qlx.apply #qlx.action<pauli_rotation>(%491#1, %cst_320) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_321 = arith.constant 1.5707963267948966 : f64
    %497:2 = qlx.apply #qlx.action<pauli_rotation>(%495, %496, %cst_321) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_322 = arith.constant 1.5707963267948966 : f64
    %498 = qlx.apply #qlx.action<pauli_rotation>(%497#1, %cst_322) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %499 = qlx.apply #qlx.action<h>(%498) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_323 = arith.constant 1.5707963267948966 : f64
    %500 = qlx.apply #qlx.action<pauli_rotation>(%479#1, %cst_323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %501 = qlx.apply #qlx.action<h>(%500) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_324 = arith.constant 1.250000e-01 : f64
    %502:2 = qlx.apply #qlx.action<pauli_rotation>(%499, %501, %cst_324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_325 = arith.constant 1.5707963267948966 : f64
    %503 = qlx.apply #qlx.action<pauli_rotation>(%497#0, %cst_325) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %504 = qlx.apply #qlx.action<h>(%502#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_326 = arith.constant 1.5707963267948966 : f64
    %505:2 = qlx.apply #qlx.action<pauli_rotation>(%503, %504, %cst_326) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_327 = arith.constant 1.5707963267948966 : f64
    %506 = qlx.apply #qlx.action<pauli_rotation>(%491#0, %cst_327) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_328 = arith.constant 1.5707963267948966 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%505#1, %cst_328) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_329 = arith.constant 1.5707963267948966 : f64
    %508:2 = qlx.apply #qlx.action<pauli_rotation>(%506, %507, %cst_329) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_330 = arith.constant 1.5707963267948966 : f64
    %509 = qlx.apply #qlx.action<pauli_rotation>(%487#0, %cst_330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_331 = arith.constant 1.5707963267948966 : f64
    %510 = qlx.apply #qlx.action<pauli_rotation>(%508#1, %cst_331) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_332 = arith.constant 1.5707963267948966 : f64
    %511:2 = qlx.apply #qlx.action<pauli_rotation>(%509, %510, %cst_332) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_333 = arith.constant 1.5707963267948966 : f64
    %512 = qlx.apply #qlx.action<pauli_rotation>(%483#0, %cst_333) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_334 = arith.constant 1.5707963267948966 : f64
    %513 = qlx.apply #qlx.action<pauli_rotation>(%508#0, %cst_334) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %514 = qlx.apply #qlx.action<h>(%513) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_335 = arith.constant 1.5707963267948966 : f64
    %515:2 = qlx.apply #qlx.action<pauli_rotation>(%512, %514, %cst_335) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_336 = arith.constant 1.5707963267948966 : f64
    %516 = qlx.apply #qlx.action<pauli_rotation>(%479#0, %cst_336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %517 = qlx.apply #qlx.action<h>(%502#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_337 = arith.constant 1.5707963267948966 : f64
    %518:2 = qlx.apply #qlx.action<pauli_rotation>(%516, %517, %cst_337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_338 = arith.constant 1.5707963267948966 : f64
    %519 = qlx.apply #qlx.action<pauli_rotation>(%518#0, %cst_338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_339 = arith.constant 1.5707963267948966 : f64
    %520:2 = qlx.apply #qlx.action<pauli_rotation>(%518#1, %519, %cst_339) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_340 = arith.constant 1.5707963267948966 : f64
    %521 = qlx.apply #qlx.action<pauli_rotation>(%515#0, %cst_340) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_341 = arith.constant 1.5707963267948966 : f64
    %522 = qlx.apply #qlx.action<pauli_rotation>(%515#1, %cst_341) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_342 = arith.constant 1.5707963267948966 : f64
    %523:2 = qlx.apply #qlx.action<pauli_rotation>(%521, %522, %cst_342) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_343 = arith.constant 1.5707963267948966 : f64
    %524 = qlx.apply #qlx.action<pauli_rotation>(%511#0, %cst_343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_344 = arith.constant 1.5707963267948966 : f64
    %525 = qlx.apply #qlx.action<pauli_rotation>(%511#1, %cst_344) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_345 = arith.constant 1.5707963267948966 : f64
    %526:2 = qlx.apply #qlx.action<pauli_rotation>(%524, %525, %cst_345) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_346 = arith.constant 1.5707963267948966 : f64
    %527 = qlx.apply #qlx.action<pauli_rotation>(%523#1, %cst_346) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %528 = qlx.apply #qlx.action<h>(%527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_347 = arith.constant 1.5707963267948966 : f64
    %529 = qlx.apply #qlx.action<pauli_rotation>(%526#1, %cst_347) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_348 = arith.constant 1.5707963267948966 : f64
    %530:2 = qlx.apply #qlx.action<pauli_rotation>(%528, %529, %cst_348) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_349 = arith.constant 1.5707963267948966 : f64
    %531 = qlx.apply #qlx.action<pauli_rotation>(%505#0, %cst_349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %532 = qlx.apply #qlx.action<h>(%531) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_350 = arith.constant 1.5707963267948966 : f64
    %533 = qlx.apply #qlx.action<pauli_rotation>(%532, %cst_350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %534 = qlx.apply #qlx.action<h>(%533) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_351 = arith.constant 1.5707963267948966 : f64
    %535 = qlx.apply #qlx.action<pauli_rotation>(%530#1, %cst_351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_352 = arith.constant 1.5707963267948966 : f64
    %536:2 = qlx.apply #qlx.action<pauli_rotation>(%534, %535, %cst_352) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_353 = arith.constant 1.5707963267948966 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%536#1, %cst_353) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %538 = qlx.apply #qlx.action<h>(%537) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_354 = arith.constant 1.5707963267948966 : f64
    %539 = qlx.apply #qlx.action<pauli_rotation>(%520#0, %cst_354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %540 = qlx.apply #qlx.action<h>(%539) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_355 = arith.constant 1.250000e-01 : f64
    %541:2 = qlx.apply #qlx.action<pauli_rotation>(%538, %540, %cst_355) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_356 = arith.constant 1.5707963267948966 : f64
    %542 = qlx.apply #qlx.action<pauli_rotation>(%536#0, %cst_356) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %543 = qlx.apply #qlx.action<h>(%541#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_357 = arith.constant 1.5707963267948966 : f64
    %544:2 = qlx.apply #qlx.action<pauli_rotation>(%542, %543, %cst_357) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_358 = arith.constant 1.5707963267948966 : f64
    %545 = qlx.apply #qlx.action<pauli_rotation>(%530#0, %cst_358) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_359 = arith.constant 1.5707963267948966 : f64
    %546 = qlx.apply #qlx.action<pauli_rotation>(%544#1, %cst_359) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_360 = arith.constant 1.5707963267948966 : f64
    %547:2 = qlx.apply #qlx.action<pauli_rotation>(%545, %546, %cst_360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_361 = arith.constant 1.5707963267948966 : f64
    %548 = qlx.apply #qlx.action<pauli_rotation>(%526#0, %cst_361) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_362 = arith.constant 1.5707963267948966 : f64
    %549 = qlx.apply #qlx.action<pauli_rotation>(%547#1, %cst_362) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_363 = arith.constant 1.5707963267948966 : f64
    %550:2 = qlx.apply #qlx.action<pauli_rotation>(%548, %549, %cst_363) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_364 = arith.constant 1.5707963267948966 : f64
    %551 = qlx.apply #qlx.action<pauli_rotation>(%523#0, %cst_364) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_365 = arith.constant 1.5707963267948966 : f64
    %552 = qlx.apply #qlx.action<pauli_rotation>(%547#0, %cst_365) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %553 = qlx.apply #qlx.action<h>(%552) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_366 = arith.constant 1.5707963267948966 : f64
    %554:2 = qlx.apply #qlx.action<pauli_rotation>(%551, %553, %cst_366) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_367 = arith.constant 1.5707963267948966 : f64
    %555 = qlx.apply #qlx.action<pauli_rotation>(%520#1, %cst_367) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %556 = qlx.apply #qlx.action<h>(%541#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_368 = arith.constant 1.5707963267948966 : f64
    %557:2 = qlx.apply #qlx.action<pauli_rotation>(%555, %556, %cst_368) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_369 = arith.constant 1.5707963267948966 : f64
    %558 = qlx.apply #qlx.action<pauli_rotation>(%151#0, %cst_369) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_370 = arith.constant 1.5707963267948966 : f64
    %559 = qlx.apply #qlx.action<pauli_rotation>(%557#1, %cst_370) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %560 = qlx.apply #qlx.action<h>(%559) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_371 = arith.constant 1.5707963267948966 : f64
    %561:2 = qlx.apply #qlx.action<pauli_rotation>(%558, %560, %cst_371) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_372 = arith.constant 1.5707963267948966 : f64
    %562 = qlx.apply #qlx.action<pauli_rotation>(%557#0, %cst_372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_373 = arith.constant 1.5707963267948966 : f64
    %563 = qlx.apply #qlx.action<pauli_rotation>(%561#1, %cst_373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_374 = arith.constant 1.5707963267948966 : f64
    %564:2 = qlx.apply #qlx.action<pauli_rotation>(%562, %563, %cst_374) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_375 = arith.constant 3.1415926535897931 : f64
    %565 = qlx.apply #qlx.action<pauli_rotation>(%554#0, %cst_375) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %566 = qlx.apply #qlx.action<h>(%565) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_376 = arith.constant 1.5707963267948966 : f64
    %567 = qlx.apply #qlx.action<pauli_rotation>(%554#1, %cst_376) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_377 = arith.constant 1.5707963267948966 : f64
    %568:2 = qlx.apply #qlx.action<pauli_rotation>(%566, %567, %cst_377) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_378 = arith.constant 1.5707963267948966 : f64
    %569 = qlx.apply #qlx.action<pauli_rotation>(%550#0, %cst_378) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_379 = arith.constant 1.5707963267948966 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%550#1, %cst_379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_380 = arith.constant 1.5707963267948966 : f64
    %571:2 = qlx.apply #qlx.action<pauli_rotation>(%569, %570, %cst_380) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_381 = arith.constant 1.5707963267948966 : f64
    %572 = qlx.apply #qlx.action<pauli_rotation>(%568#1, %cst_381) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %573 = qlx.apply #qlx.action<h>(%572) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_382 = arith.constant 1.5707963267948966 : f64
    %574 = qlx.apply #qlx.action<pauli_rotation>(%571#1, %cst_382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_383 = arith.constant 1.5707963267948966 : f64
    %575:2 = qlx.apply #qlx.action<pauli_rotation>(%573, %574, %cst_383) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_384 = arith.constant 1.5707963267948966 : f64
    %576 = qlx.apply #qlx.action<pauli_rotation>(%575#1, %cst_384) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %577 = qlx.apply #qlx.action<h>(%576) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_385 = arith.constant 1.5707963267948966 : f64
    %578 = qlx.apply #qlx.action<pauli_rotation>(%564#1, %cst_385) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %579 = qlx.apply #qlx.action<h>(%578) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_386 = arith.constant 1.250000e-01 : f64
    %580:2 = qlx.apply #qlx.action<pauli_rotation>(%577, %579, %cst_386) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_387 = arith.constant 1.5707963267948966 : f64
    %581 = qlx.apply #qlx.action<pauli_rotation>(%575#0, %cst_387) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %582 = qlx.apply #qlx.action<h>(%580#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_388 = arith.constant 1.5707963267948966 : f64
    %583:2 = qlx.apply #qlx.action<pauli_rotation>(%581, %582, %cst_388) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_389 = arith.constant 1.5707963267948966 : f64
    %584 = qlx.apply #qlx.action<pauli_rotation>(%571#0, %cst_389) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_390 = arith.constant 1.5707963267948966 : f64
    %585 = qlx.apply #qlx.action<pauli_rotation>(%583#1, %cst_390) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_391 = arith.constant 1.5707963267948966 : f64
    %586:2 = qlx.apply #qlx.action<pauli_rotation>(%584, %585, %cst_391) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_392 = arith.constant 1.5707963267948966 : f64
    %587 = qlx.apply #qlx.action<pauli_rotation>(%568#0, %cst_392) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_393 = arith.constant 1.5707963267948966 : f64
    %588 = qlx.apply #qlx.action<pauli_rotation>(%583#0, %cst_393) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %589 = qlx.apply #qlx.action<h>(%588) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_394 = arith.constant 1.5707963267948966 : f64
    %590:2 = qlx.apply #qlx.action<pauli_rotation>(%587, %589, %cst_394) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_395 = arith.constant 1.5707963267948966 : f64
    %591 = qlx.apply #qlx.action<pauli_rotation>(%564#0, %cst_395) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %592 = qlx.apply #qlx.action<h>(%580#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_396 = arith.constant 1.5707963267948966 : f64
    %593:2 = qlx.apply #qlx.action<pauli_rotation>(%591, %592, %cst_396) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_397 = arith.constant 1.5707963267948966 : f64
    %594 = qlx.apply #qlx.action<pauli_rotation>(%561#0, %cst_397) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_398 = arith.constant 1.5707963267948966 : f64
    %595 = qlx.apply #qlx.action<pauli_rotation>(%593#1, %cst_398) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_399 = arith.constant 1.5707963267948966 : f64
    %596:2 = qlx.apply #qlx.action<pauli_rotation>(%594, %595, %cst_399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_400 = arith.constant 1.5707963267948966 : f64
    %597 = qlx.apply #qlx.action<pauli_rotation>(%596#0, %cst_400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %598 = qlx.apply #qlx.action<h>(%597) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_401 = arith.constant 1.5707963267948966 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%598, %cst_401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %600 = qlx.apply #qlx.action<h>(%599) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_402 = arith.constant 1.5707963267948966 : f64
    %601 = qlx.apply #qlx.action<pauli_rotation>(%596#1, %cst_402) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_403 = arith.constant 1.5707963267948966 : f64
    %602:2 = qlx.apply #qlx.action<pauli_rotation>(%600, %601, %cst_403) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_404 = arith.constant 1.5707963267948966 : f64
    %603 = qlx.apply #qlx.action<pauli_rotation>(%593#0, %cst_404) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_405 = arith.constant 1.5707963267948966 : f64
    %604 = qlx.apply #qlx.action<pauli_rotation>(%602#1, %cst_405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_406 = arith.constant 1.5707963267948966 : f64
    %605:2 = qlx.apply #qlx.action<pauli_rotation>(%603, %604, %cst_406) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_407 = arith.constant 1.5707963267948966 : f64
    %606 = qlx.apply #qlx.action<pauli_rotation>(%590#0, %cst_407) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %607 = qlx.apply #qlx.action<h>(%606) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_408 = arith.constant 1.5707963267948966 : f64
    %608 = qlx.apply #qlx.action<pauli_rotation>(%607, %cst_408) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %609 = qlx.apply #qlx.action<h>(%608) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_409 = arith.constant 1.5707963267948966 : f64
    %610 = qlx.apply #qlx.action<pauli_rotation>(%590#1, %cst_409) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_410 = arith.constant 1.5707963267948966 : f64
    %611:2 = qlx.apply #qlx.action<pauli_rotation>(%609, %610, %cst_410) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_411 = arith.constant 1.5707963267948966 : f64
    %612 = qlx.apply #qlx.action<pauli_rotation>(%586#0, %cst_411) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_412 = arith.constant 1.5707963267948966 : f64
    %613 = qlx.apply #qlx.action<pauli_rotation>(%586#1, %cst_412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_413 = arith.constant 1.5707963267948966 : f64
    %614:2 = qlx.apply #qlx.action<pauli_rotation>(%612, %613, %cst_413) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_414 = arith.constant 1.5707963267948966 : f64
    %615 = qlx.apply #qlx.action<pauli_rotation>(%611#1, %cst_414) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %616 = qlx.apply #qlx.action<h>(%615) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_415 = arith.constant 1.5707963267948966 : f64
    %617 = qlx.apply #qlx.action<pauli_rotation>(%614#1, %cst_415) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_416 = arith.constant 1.5707963267948966 : f64
    %618:2 = qlx.apply #qlx.action<pauli_rotation>(%616, %617, %cst_416) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_417 = arith.constant 1.5707963267948966 : f64
    %619 = qlx.apply #qlx.action<pauli_rotation>(%618#1, %cst_417) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %620 = qlx.apply #qlx.action<h>(%619) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_418 = arith.constant 1.5707963267948966 : f64
    %621 = qlx.apply #qlx.action<pauli_rotation>(%605#1, %cst_418) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %622 = qlx.apply #qlx.action<h>(%621) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_419 = arith.constant 1.250000e-01 : f64
    %623:2 = qlx.apply #qlx.action<pauli_rotation>(%620, %622, %cst_419) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_420 = arith.constant 1.5707963267948966 : f64
    %624 = qlx.apply #qlx.action<pauli_rotation>(%618#0, %cst_420) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %625 = qlx.apply #qlx.action<h>(%623#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_421 = arith.constant 1.5707963267948966 : f64
    %626:2 = qlx.apply #qlx.action<pauli_rotation>(%624, %625, %cst_421) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_422 = arith.constant 1.5707963267948966 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%614#0, %cst_422) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_423 = arith.constant 1.5707963267948966 : f64
    %628 = qlx.apply #qlx.action<pauli_rotation>(%626#1, %cst_423) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_424 = arith.constant 1.5707963267948966 : f64
    %629:2 = qlx.apply #qlx.action<pauli_rotation>(%627, %628, %cst_424) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_425 = arith.constant 1.5707963267948966 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%611#0, %cst_425) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_426 = arith.constant 1.5707963267948966 : f64
    %631 = qlx.apply #qlx.action<pauli_rotation>(%626#0, %cst_426) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %632 = qlx.apply #qlx.action<h>(%631) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_427 = arith.constant 1.5707963267948966 : f64
    %633:2 = qlx.apply #qlx.action<pauli_rotation>(%630, %632, %cst_427) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_428 = arith.constant 1.5707963267948966 : f64
    %634 = qlx.apply #qlx.action<pauli_rotation>(%605#0, %cst_428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %635 = qlx.apply #qlx.action<h>(%623#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_429 = arith.constant 1.5707963267948966 : f64
    %636:2 = qlx.apply #qlx.action<pauli_rotation>(%634, %635, %cst_429) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_430 = arith.constant 1.5707963267948966 : f64
    %637 = qlx.apply #qlx.action<pauli_rotation>(%602#0, %cst_430) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_431 = arith.constant 1.5707963267948966 : f64
    %638 = qlx.apply #qlx.action<pauli_rotation>(%636#1, %cst_431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_432 = arith.constant 1.5707963267948966 : f64
    %639:2 = qlx.apply #qlx.action<pauli_rotation>(%637, %638, %cst_432) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_433 = arith.constant 3.1415926535897931 : f64
    %640 = qlx.apply #qlx.action<pauli_rotation>(%629#0, %cst_433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %641 = qlx.apply #qlx.action<h>(%640) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_434 = arith.constant 1.5707963267948966 : f64
    %642 = qlx.apply #qlx.action<pauli_rotation>(%636#0, %cst_434) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %643 = qlx.apply #qlx.action<h>(%642) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_435 = arith.constant 1.5707963267948966 : f64
    %644:2 = qlx.apply #qlx.action<pauli_rotation>(%641, %643, %cst_435) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_436 = arith.constant 1.5707963267948966 : f64
    %645 = qlx.apply #qlx.action<pauli_rotation>(%644#1, %cst_436) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %646 = qlx.apply #qlx.action<h>(%645) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_437 = arith.constant 1.5707963267948966 : f64
    %647 = qlx.apply #qlx.action<pauli_rotation>(%639#1, %cst_437) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %648 = qlx.apply #qlx.action<h>(%647) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_438 = arith.constant 1.5707963267948966 : f64
    %649 = qlx.apply #qlx.action<pauli_rotation>(%648, %cst_438) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %650 = qlx.apply #qlx.action<h>(%649) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_439 = arith.constant 1.250000e-01 : f64
    %651:2 = qlx.apply #qlx.action<pauli_rotation>(%646, %650, %cst_439) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_440 = arith.constant 1.5707963267948966 : f64
    %652 = qlx.apply #qlx.action<pauli_rotation>(%644#0, %cst_440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %653 = qlx.apply #qlx.action<h>(%651#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_441 = arith.constant 1.5707963267948966 : f64
    %654:2 = qlx.apply #qlx.action<pauli_rotation>(%652, %653, %cst_441) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 1.5707963267948966 : f64
    %655 = qlx.apply #qlx.action<pauli_rotation>(%654#0, %cst_442) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %656 = qlx.apply #qlx.action<h>(%655) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_443 = arith.constant 1.5707963267948966 : f64
    %657 = qlx.apply #qlx.action<pauli_rotation>(%656, %cst_443) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %658 = qlx.apply #qlx.action<h>(%657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_444 = arith.constant 1.5707963267948966 : f64
    %659 = qlx.apply #qlx.action<pauli_rotation>(%654#1, %cst_444) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_445 = arith.constant 1.5707963267948966 : f64
    %660:2 = qlx.apply #qlx.action<pauli_rotation>(%658, %659, %cst_445) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_446 = arith.constant 1.5707963267948966 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%660#1, %cst_446) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %662 = qlx.apply #qlx.action<h>(%661) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %663 = qlx.apply #qlx.action<h>(%651#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_447 = arith.constant 1.5707963267948966 : f64
    %664 = qlx.apply #qlx.action<pauli_rotation>(%663, %cst_447) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %665 = qlx.apply #qlx.action<h>(%664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_448 = arith.constant 1.250000e-01 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%662, %665, %cst_448) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_449 = arith.constant 1.5707963267948966 : f64
    %667 = qlx.apply #qlx.action<pauli_rotation>(%660#0, %cst_449) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %668 = qlx.apply #qlx.action<h>(%666#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_450 = arith.constant 1.5707963267948966 : f64
    %669:2 = qlx.apply #qlx.action<pauli_rotation>(%667, %668, %cst_450) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_451 = arith.constant 1.5707963267948966 : f64
    %670 = qlx.apply #qlx.action<pauli_rotation>(%669#1, %cst_451) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %671 = qlx.apply #qlx.action<h>(%670) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_452 = arith.constant 1.5707963267948966 : f64
    %672 = qlx.apply #qlx.action<pauli_rotation>(%671, %cst_452) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %673 = qlx.apply #qlx.action<h>(%672) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_453 = arith.constant 1.5707963267948966 : f64
    %674:2 = qlx.apply #qlx.action<pauli_rotation>(%666#1, %673, %cst_453) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_454 = arith.constant 1.5707963267948966 : f64
    %675 = qlx.apply #qlx.action<pauli_rotation>(%674#0, %cst_454) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %676 = qlx.apply #qlx.action<h>(%675) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_455 = arith.constant 1.5707963267948966 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%639#0, %cst_455) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %678 = qlx.apply #qlx.action<h>(%677) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_456 = arith.constant 1.5707963267948966 : f64
    %679 = qlx.apply #qlx.action<pauli_rotation>(%678, %cst_456) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %680 = qlx.apply #qlx.action<h>(%679) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_457 = arith.constant 1.250000e-01 : f64
    %681:2 = qlx.apply #qlx.action<pauli_rotation>(%676, %680, %cst_457) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_458 = arith.constant 1.5707963267948966 : f64
    %682 = qlx.apply #qlx.action<pauli_rotation>(%674#1, %cst_458) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %683 = qlx.apply #qlx.action<h>(%681#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_459 = arith.constant 1.5707963267948966 : f64
    %684:2 = qlx.apply #qlx.action<pauli_rotation>(%682, %683, %cst_459) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_460 = arith.constant 1.5707963267948966 : f64
    %685 = qlx.apply #qlx.action<pauli_rotation>(%684#0, %cst_460) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %686 = qlx.apply #qlx.action<h>(%685) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_461 = arith.constant 1.5707963267948966 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686, %cst_461) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %688 = qlx.apply #qlx.action<h>(%687) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_462 = arith.constant 1.5707963267948966 : f64
    %689 = qlx.apply #qlx.action<pauli_rotation>(%684#1, %cst_462) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_463 = arith.constant 1.5707963267948966 : f64
    %690:2 = qlx.apply #qlx.action<pauli_rotation>(%688, %689, %cst_463) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_464 = arith.constant 1.5707963267948966 : f64
    %691 = qlx.apply #qlx.action<pauli_rotation>(%690#1, %cst_464) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %692 = qlx.apply #qlx.action<h>(%691) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %693 = qlx.apply #qlx.action<h>(%681#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_465 = arith.constant 1.5707963267948966 : f64
    %694 = qlx.apply #qlx.action<pauli_rotation>(%693, %cst_465) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %695 = qlx.apply #qlx.action<h>(%694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_466 = arith.constant 1.250000e-01 : f64
    %696:2 = qlx.apply #qlx.action<pauli_rotation>(%692, %695, %cst_466) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_467 = arith.constant 1.5707963267948966 : f64
    %697 = qlx.apply #qlx.action<pauli_rotation>(%690#0, %cst_467) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %698 = qlx.apply #qlx.action<h>(%696#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_468 = arith.constant 1.5707963267948966 : f64
    %699:2 = qlx.apply #qlx.action<pauli_rotation>(%697, %698, %cst_468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %700 = qlx.apply #qlx.action<h>(%696#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_469 = arith.constant 1.5707963267948966 : f64
    %701 = qlx.apply #qlx.action<pauli_rotation>(%699#1, %cst_469) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %702 = qlx.apply #qlx.action<h>(%701) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_470 = arith.constant 5.000000e-01 : f64
    %703:2 = qlx.apply #qlx.action<pauli_rotation>(%700, %702, %cst_470) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_471 = arith.constant 1.5707963267948966 : f64
    %704 = qlx.apply #qlx.action<pauli_rotation>(%699#0, %cst_471) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %705 = qlx.apply #qlx.action<h>(%703#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_472 = arith.constant 1.5707963267948966 : f64
    %706:2 = qlx.apply #qlx.action<pauli_rotation>(%704, %705, %cst_472) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_473 = arith.constant 1.5707963267948966 : f64
    %707 = qlx.apply #qlx.action<pauli_rotation>(%706#1, %cst_473) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %708 = qlx.apply #qlx.action<h>(%707) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %709 = qlx.apply #qlx.action<h>(%703#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_474 = arith.constant 1.250000e-01 : f64
    %710:2 = qlx.apply #qlx.action<pauli_rotation>(%708, %709, %cst_474) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_475 = arith.constant 1.5707963267948966 : f64
    %711 = qlx.apply #qlx.action<pauli_rotation>(%706#0, %cst_475) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %712 = qlx.apply #qlx.action<h>(%710#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_476 = arith.constant 1.5707963267948966 : f64
    %713:2 = qlx.apply #qlx.action<pauli_rotation>(%711, %712, %cst_476) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_477 = arith.constant 1.5707963267948966 : f64
    %714 = qlx.apply #qlx.action<pauli_rotation>(%713#0, %cst_477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %715 = qlx.apply #qlx.action<h>(%714) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_478 = arith.constant 1.5707963267948966 : f64
    %716 = qlx.apply #qlx.action<pauli_rotation>(%715, %cst_478) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %717 = qlx.apply #qlx.action<h>(%716) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_479 = arith.constant 1.5707963267948966 : f64
    %718 = qlx.apply #qlx.action<pauli_rotation>(%713#1, %cst_479) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_480 = arith.constant 1.5707963267948966 : f64
    %719:2 = qlx.apply #qlx.action<pauli_rotation>(%717, %718, %cst_480) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_481 = arith.constant 1.5707963267948966 : f64
    %720 = qlx.apply #qlx.action<pauli_rotation>(%719#1, %cst_481) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %721 = qlx.apply #qlx.action<h>(%720) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %722 = qlx.apply #qlx.action<h>(%710#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_482 = arith.constant 1.5707963267948966 : f64
    %723 = qlx.apply #qlx.action<pauli_rotation>(%722, %cst_482) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %724 = qlx.apply #qlx.action<h>(%723) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_483 = arith.constant 1.250000e-01 : f64
    %725:2 = qlx.apply #qlx.action<pauli_rotation>(%721, %724, %cst_483) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_484 = arith.constant 1.5707963267948966 : f64
    %726 = qlx.apply #qlx.action<pauli_rotation>(%719#0, %cst_484) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %727 = qlx.apply #qlx.action<h>(%725#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_485 = arith.constant 1.5707963267948966 : f64
    %728:2 = qlx.apply #qlx.action<pauli_rotation>(%726, %727, %cst_485) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_486 = arith.constant 1.5707963267948966 : f64
    %729 = qlx.apply #qlx.action<pauli_rotation>(%669#0, %cst_486) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_487 = arith.constant 1.5707963267948966 : f64
    %730 = qlx.apply #qlx.action<pauli_rotation>(%728#0, %cst_487) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %731 = qlx.apply #qlx.action<h>(%730) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_488 = arith.constant 1.5707963267948966 : f64
    %732 = qlx.apply #qlx.action<pauli_rotation>(%731, %cst_488) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %733 = qlx.apply #qlx.action<h>(%732) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_489 = arith.constant 1.5707963267948966 : f64
    %734:2 = qlx.apply #qlx.action<pauli_rotation>(%729, %733, %cst_489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_490 = arith.constant 1.5707963267948966 : f64
    %735 = qlx.apply #qlx.action<pauli_rotation>(%734#1, %cst_490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %736 = qlx.apply #qlx.action<h>(%735) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_491 = arith.constant 1.5707963267948966 : f64
    %737 = qlx.apply #qlx.action<pauli_rotation>(%728#1, %cst_491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_492 = arith.constant 1.250000e-01 : f64
    %738:2 = qlx.apply #qlx.action<pauli_rotation>(%736, %737, %cst_492) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_493 = arith.constant 1.5707963267948966 : f64
    %739 = qlx.apply #qlx.action<pauli_rotation>(%734#0, %cst_493) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %740 = qlx.apply #qlx.action<h>(%738#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_494 = arith.constant 1.5707963267948966 : f64
    %741:2 = qlx.apply #qlx.action<pauli_rotation>(%739, %740, %cst_494) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_495 = arith.constant 1.5707963267948966 : f64
    %742 = qlx.apply #qlx.action<pauli_rotation>(%741#0, %cst_495) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %743 = qlx.apply #qlx.action<h>(%742) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_496 = arith.constant 1.5707963267948966 : f64
    %744 = qlx.apply #qlx.action<pauli_rotation>(%743, %cst_496) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %745 = qlx.apply #qlx.action<h>(%744) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_497 = arith.constant 1.5707963267948966 : f64
    %746 = qlx.apply #qlx.action<pauli_rotation>(%741#1, %cst_497) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_498 = arith.constant 1.5707963267948966 : f64
    %747:2 = qlx.apply #qlx.action<pauli_rotation>(%745, %746, %cst_498) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_499 = arith.constant 1.5707963267948966 : f64
    %748 = qlx.apply #qlx.action<pauli_rotation>(%747#1, %cst_499) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %749 = qlx.apply #qlx.action<h>(%748) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %750 = qlx.apply #qlx.action<h>(%738#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_500 = arith.constant 1.5707963267948966 : f64
    %751 = qlx.apply #qlx.action<pauli_rotation>(%750, %cst_500) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %752 = qlx.apply #qlx.action<h>(%751) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_501 = arith.constant 1.250000e-01 : f64
    %753:2 = qlx.apply #qlx.action<pauli_rotation>(%749, %752, %cst_501) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_502 = arith.constant 1.5707963267948966 : f64
    %754 = qlx.apply #qlx.action<pauli_rotation>(%747#0, %cst_502) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %755 = qlx.apply #qlx.action<h>(%753#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_503 = arith.constant 1.5707963267948966 : f64
    %756:2 = qlx.apply #qlx.action<pauli_rotation>(%754, %755, %cst_503) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %757 = qlx.apply #qlx.action<h>(%725#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_504 = arith.constant 1.5707963267948966 : f64
    %758 = qlx.apply #qlx.action<pauli_rotation>(%757, %cst_504) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %759 = qlx.apply #qlx.action<h>(%758) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %760 = qlx.apply #qlx.action<h>(%753#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_505 = arith.constant 1.5707963267948966 : f64
    %761 = qlx.apply #qlx.action<pauli_rotation>(%760, %cst_505) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %762 = qlx.apply #qlx.action<h>(%761) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_506 = arith.constant 1.5707963267948966 : f64
    %763:2 = qlx.apply #qlx.action<pauli_rotation>(%759, %762, %cst_506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_507 = arith.constant 1.5707963267948966 : f64
    %764 = qlx.apply #qlx.action<pauli_rotation>(%756#1, %cst_507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %765 = qlx.apply #qlx.action<h>(%764) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_508 = arith.constant 1.5707963267948966 : f64
    %766 = qlx.apply #qlx.action<pauli_rotation>(%763#1, %cst_508) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_509 = arith.constant 1.5707963267948966 : f64
    %767:2 = qlx.apply #qlx.action<pauli_rotation>(%765, %766, %cst_509) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_510 = arith.constant 1.5707963267948966 : f64
    %768 = qlx.apply #qlx.action<pauli_rotation>(%633#0, %cst_510) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_511 = arith.constant 1.5707963267948966 : f64
    %769 = qlx.apply #qlx.action<pauli_rotation>(%633#1, %cst_511) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_512 = arith.constant 1.5707963267948966 : f64
    %770:2 = qlx.apply #qlx.action<pauli_rotation>(%768, %769, %cst_512) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_513 = arith.constant 1.5707963267948966 : f64
    %771 = qlx.apply #qlx.action<pauli_rotation>(%756#0, %cst_513) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %772 = qlx.apply #qlx.action<h>(%771) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_514 = arith.constant 1.5707963267948966 : f64
    %773 = qlx.apply #qlx.action<pauli_rotation>(%772, %cst_514) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_515 = arith.constant 1.5707963267948966 : f64
    %774 = qlx.apply #qlx.action<pauli_rotation>(%629#1, %cst_515) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_516 = arith.constant 1.5707963267948966 : f64
    %775:2 = qlx.apply #qlx.action<pauli_rotation>(%773, %774, %cst_516) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_517 = arith.constant 1.5707963267948966 : f64
    %776 = qlx.apply #qlx.action<pauli_rotation>(%770#1, %cst_517) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %777 = qlx.apply #qlx.action<h>(%776) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_518 = arith.constant 1.5707963267948966 : f64
    %778 = qlx.apply #qlx.action<pauli_rotation>(%775#1, %cst_518) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_519 = arith.constant 1.5707963267948966 : f64
    %779:2 = qlx.apply #qlx.action<pauli_rotation>(%777, %778, %cst_519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_520 = arith.constant 1.5707963267948966 : f64
    %780 = qlx.apply #qlx.action<pauli_rotation>(%779#1, %cst_520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %781 = qlx.apply #qlx.action<h>(%780) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_521 = arith.constant 1.5707963267948966 : f64
    %782 = qlx.apply #qlx.action<pauli_rotation>(%767#1, %cst_521) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %783 = qlx.apply #qlx.action<h>(%782) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_522 = arith.constant 1.250000e-01 : f64
    %784:2 = qlx.apply #qlx.action<pauli_rotation>(%781, %783, %cst_522) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_523 = arith.constant 1.5707963267948966 : f64
    %785 = qlx.apply #qlx.action<pauli_rotation>(%779#0, %cst_523) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %786 = qlx.apply #qlx.action<h>(%784#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_524 = arith.constant 1.5707963267948966 : f64
    %787:2 = qlx.apply #qlx.action<pauli_rotation>(%785, %786, %cst_524) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_525 = arith.constant 1.5707963267948966 : f64
    %788 = qlx.apply #qlx.action<pauli_rotation>(%775#0, %cst_525) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_526 = arith.constant 1.5707963267948966 : f64
    %789 = qlx.apply #qlx.action<pauli_rotation>(%787#1, %cst_526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_527 = arith.constant 1.5707963267948966 : f64
    %790:2 = qlx.apply #qlx.action<pauli_rotation>(%788, %789, %cst_527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_528 = arith.constant 1.5707963267948966 : f64
    %791 = qlx.apply #qlx.action<pauli_rotation>(%770#0, %cst_528) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_529 = arith.constant 1.5707963267948966 : f64
    %792 = qlx.apply #qlx.action<pauli_rotation>(%787#0, %cst_529) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %793 = qlx.apply #qlx.action<h>(%792) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_530 = arith.constant 1.5707963267948966 : f64
    %794:2 = qlx.apply #qlx.action<pauli_rotation>(%791, %793, %cst_530) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_531 = arith.constant 1.5707963267948966 : f64
    %795 = qlx.apply #qlx.action<pauli_rotation>(%767#0, %cst_531) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %796 = qlx.apply #qlx.action<h>(%784#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_532 = arith.constant 1.5707963267948966 : f64
    %797:2 = qlx.apply #qlx.action<pauli_rotation>(%795, %796, %cst_532) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_533 = arith.constant 1.5707963267948966 : f64
    %798 = qlx.apply #qlx.action<pauli_rotation>(%763#0, %cst_533) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_534 = arith.constant 1.5707963267948966 : f64
    %799 = qlx.apply #qlx.action<pauli_rotation>(%797#1, %cst_534) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_535 = arith.constant 1.5707963267948966 : f64
    %800:2 = qlx.apply #qlx.action<pauli_rotation>(%798, %799, %cst_535) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_536 = arith.constant 1.5707963267948966 : f64
    %801 = qlx.apply #qlx.action<pauli_rotation>(%800#0, %cst_536) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %802 = qlx.apply #qlx.action<h>(%801) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_537 = arith.constant 1.5707963267948966 : f64
    %803 = qlx.apply #qlx.action<pauli_rotation>(%802, %cst_537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %804 = qlx.apply #qlx.action<h>(%803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_538 = arith.constant 1.5707963267948966 : f64
    %805 = qlx.apply #qlx.action<pauli_rotation>(%800#1, %cst_538) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_539 = arith.constant 1.5707963267948966 : f64
    %806:2 = qlx.apply #qlx.action<pauli_rotation>(%804, %805, %cst_539) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_540 = arith.constant 1.5707963267948966 : f64
    %807 = qlx.apply #qlx.action<pauli_rotation>(%797#0, %cst_540) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_541 = arith.constant 1.5707963267948966 : f64
    %808 = qlx.apply #qlx.action<pauli_rotation>(%806#1, %cst_541) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_542 = arith.constant 1.5707963267948966 : f64
    %809:2 = qlx.apply #qlx.action<pauli_rotation>(%807, %808, %cst_542) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_543 = arith.constant 1.5707963267948966 : f64
    %810 = qlx.apply #qlx.action<pauli_rotation>(%794#0, %cst_543) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %811 = qlx.apply #qlx.action<h>(%810) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_544 = arith.constant 1.5707963267948966 : f64
    %812 = qlx.apply #qlx.action<pauli_rotation>(%811, %cst_544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %813 = qlx.apply #qlx.action<h>(%812) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_545 = arith.constant 1.5707963267948966 : f64
    %814 = qlx.apply #qlx.action<pauli_rotation>(%794#1, %cst_545) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_546 = arith.constant 1.5707963267948966 : f64
    %815:2 = qlx.apply #qlx.action<pauli_rotation>(%813, %814, %cst_546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_547 = arith.constant 1.5707963267948966 : f64
    %816 = qlx.apply #qlx.action<pauli_rotation>(%790#0, %cst_547) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_548 = arith.constant 1.5707963267948966 : f64
    %817 = qlx.apply #qlx.action<pauli_rotation>(%790#1, %cst_548) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_549 = arith.constant 1.5707963267948966 : f64
    %818:2 = qlx.apply #qlx.action<pauli_rotation>(%816, %817, %cst_549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_550 = arith.constant 1.5707963267948966 : f64
    %819 = qlx.apply #qlx.action<pauli_rotation>(%815#1, %cst_550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %820 = qlx.apply #qlx.action<h>(%819) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_551 = arith.constant 1.5707963267948966 : f64
    %821 = qlx.apply #qlx.action<pauli_rotation>(%818#1, %cst_551) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_552 = arith.constant 1.5707963267948966 : f64
    %822:2 = qlx.apply #qlx.action<pauli_rotation>(%820, %821, %cst_552) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_553 = arith.constant 1.5707963267948966 : f64
    %823 = qlx.apply #qlx.action<pauli_rotation>(%822#1, %cst_553) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %824 = qlx.apply #qlx.action<h>(%823) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_554 = arith.constant 1.5707963267948966 : f64
    %825 = qlx.apply #qlx.action<pauli_rotation>(%809#1, %cst_554) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %826 = qlx.apply #qlx.action<h>(%825) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_555 = arith.constant 1.250000e-01 : f64
    %827:2 = qlx.apply #qlx.action<pauli_rotation>(%824, %826, %cst_555) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_556 = arith.constant 1.5707963267948966 : f64
    %828 = qlx.apply #qlx.action<pauli_rotation>(%822#0, %cst_556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %829 = qlx.apply #qlx.action<h>(%827#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_557 = arith.constant 1.5707963267948966 : f64
    %830:2 = qlx.apply #qlx.action<pauli_rotation>(%828, %829, %cst_557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_558 = arith.constant 1.5707963267948966 : f64
    %831 = qlx.apply #qlx.action<pauli_rotation>(%818#0, %cst_558) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_559 = arith.constant 1.5707963267948966 : f64
    %832 = qlx.apply #qlx.action<pauli_rotation>(%830#1, %cst_559) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_560 = arith.constant 1.5707963267948966 : f64
    %833:2 = qlx.apply #qlx.action<pauli_rotation>(%831, %832, %cst_560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_561 = arith.constant 1.5707963267948966 : f64
    %834 = qlx.apply #qlx.action<pauli_rotation>(%815#0, %cst_561) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_562 = arith.constant 1.5707963267948966 : f64
    %835 = qlx.apply #qlx.action<pauli_rotation>(%830#0, %cst_562) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %836 = qlx.apply #qlx.action<h>(%835) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_563 = arith.constant 1.5707963267948966 : f64
    %837:2 = qlx.apply #qlx.action<pauli_rotation>(%834, %836, %cst_563) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_564 = arith.constant 1.5707963267948966 : f64
    %838 = qlx.apply #qlx.action<pauli_rotation>(%809#0, %cst_564) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %839 = qlx.apply #qlx.action<h>(%827#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_565 = arith.constant 1.5707963267948966 : f64
    %840:2 = qlx.apply #qlx.action<pauli_rotation>(%838, %839, %cst_565) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_566 = arith.constant 1.5707963267948966 : f64
    %841 = qlx.apply #qlx.action<pauli_rotation>(%806#0, %cst_566) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_567 = arith.constant 1.5707963267948966 : f64
    %842 = qlx.apply #qlx.action<pauli_rotation>(%840#1, %cst_567) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_568 = arith.constant 1.5707963267948966 : f64
    %843:2 = qlx.apply #qlx.action<pauli_rotation>(%841, %842, %cst_568) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_569 = arith.constant 1.5707963267948966 : f64
    %844 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %cst_569) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_570 = arith.constant 1.5707963267948966 : f64
    %845 = qlx.apply #qlx.action<pauli_rotation>(%843#1, %cst_570) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %846 = qlx.apply #qlx.action<h>(%845) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_571 = arith.constant 1.5707963267948966 : f64
    %847:2 = qlx.apply #qlx.action<pauli_rotation>(%844, %846, %cst_571) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_572 = arith.constant 1.5707963267948966 : f64
    %848 = qlx.apply #qlx.action<pauli_rotation>(%837#0, %cst_572) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %849 = qlx.apply #qlx.action<h>(%848) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_573 = arith.constant 1.5707963267948966 : f64
    %850 = qlx.apply #qlx.action<pauli_rotation>(%849, %cst_573) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_574 = arith.constant 1.5707963267948966 : f64
    %851 = qlx.apply #qlx.action<pauli_rotation>(%837#1, %cst_574) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_575 = arith.constant 1.5707963267948966 : f64
    %852:2 = qlx.apply #qlx.action<pauli_rotation>(%850, %851, %cst_575) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_576 = arith.constant 1.5707963267948966 : f64
    %853 = qlx.apply #qlx.action<pauli_rotation>(%833#0, %cst_576) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_577 = arith.constant 1.5707963267948966 : f64
    %854 = qlx.apply #qlx.action<pauli_rotation>(%833#1, %cst_577) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_578 = arith.constant 1.5707963267948966 : f64
    %855:2 = qlx.apply #qlx.action<pauli_rotation>(%853, %854, %cst_578) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_579 = arith.constant 1.5707963267948966 : f64
    %856 = qlx.apply #qlx.action<pauli_rotation>(%852#1, %cst_579) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %857 = qlx.apply #qlx.action<h>(%856) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_580 = arith.constant 1.5707963267948966 : f64
    %858 = qlx.apply #qlx.action<pauli_rotation>(%855#1, %cst_580) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_581 = arith.constant 1.5707963267948966 : f64
    %859:2 = qlx.apply #qlx.action<pauli_rotation>(%857, %858, %cst_581) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_582 = arith.constant 1.5707963267948966 : f64
    %860 = qlx.apply #qlx.action<pauli_rotation>(%544#0, %cst_582) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_583 = arith.constant 1.5707963267948966 : f64
    %861 = qlx.apply #qlx.action<pauli_rotation>(%859#1, %cst_583) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_584 = arith.constant 1.5707963267948966 : f64
    %862:2 = qlx.apply #qlx.action<pauli_rotation>(%860, %861, %cst_584) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_585 = arith.constant 1.5707963267948966 : f64
    %863 = qlx.apply #qlx.action<pauli_rotation>(%862#1, %cst_585) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %864 = qlx.apply #qlx.action<h>(%863) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_586 = arith.constant 1.5707963267948966 : f64
    %865 = qlx.apply #qlx.action<pauli_rotation>(%847#1, %cst_586) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %866 = qlx.apply #qlx.action<h>(%865) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_587 = arith.constant 1.250000e-01 : f64
    %867:2 = qlx.apply #qlx.action<pauli_rotation>(%864, %866, %cst_587) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_588 = arith.constant 1.5707963267948966 : f64
    %868 = qlx.apply #qlx.action<pauli_rotation>(%862#0, %cst_588) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %869 = qlx.apply #qlx.action<h>(%867#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_589 = arith.constant 1.5707963267948966 : f64
    %870:2 = qlx.apply #qlx.action<pauli_rotation>(%868, %869, %cst_589) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_590 = arith.constant 1.5707963267948966 : f64
    %871 = qlx.apply #qlx.action<pauli_rotation>(%859#0, %cst_590) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_591 = arith.constant 1.5707963267948966 : f64
    %872 = qlx.apply #qlx.action<pauli_rotation>(%870#1, %cst_591) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_592 = arith.constant 1.5707963267948966 : f64
    %873:2 = qlx.apply #qlx.action<pauli_rotation>(%871, %872, %cst_592) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_593 = arith.constant 1.5707963267948966 : f64
    %874 = qlx.apply #qlx.action<pauli_rotation>(%855#0, %cst_593) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_594 = arith.constant 1.5707963267948966 : f64
    %875 = qlx.apply #qlx.action<pauli_rotation>(%873#1, %cst_594) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_595 = arith.constant 1.5707963267948966 : f64
    %876:2 = qlx.apply #qlx.action<pauli_rotation>(%874, %875, %cst_595) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_596 = arith.constant 1.5707963267948966 : f64
    %877 = qlx.apply #qlx.action<pauli_rotation>(%852#0, %cst_596) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_597 = arith.constant 1.5707963267948966 : f64
    %878 = qlx.apply #qlx.action<pauli_rotation>(%873#0, %cst_597) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %879 = qlx.apply #qlx.action<h>(%878) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_598 = arith.constant 1.5707963267948966 : f64
    %880:2 = qlx.apply #qlx.action<pauli_rotation>(%877, %879, %cst_598) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_599 = arith.constant 1.5707963267948966 : f64
    %881 = qlx.apply #qlx.action<pauli_rotation>(%847#0, %cst_599) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %882 = qlx.apply #qlx.action<h>(%867#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_600 = arith.constant 1.5707963267948966 : f64
    %883:2 = qlx.apply #qlx.action<pauli_rotation>(%881, %882, %cst_600) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_601 = arith.constant 1.5707963267948966 : f64
    %884 = qlx.apply #qlx.action<pauli_rotation>(%883#0, %cst_601) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_602 = arith.constant 3.1415926535897931 : f64
    %885 = qlx.apply #qlx.action<pauli_rotation>(%883#1, %cst_602) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_603 = arith.constant 1.5707963267948966 : f64
    %886:2 = qlx.apply #qlx.action<pauli_rotation>(%884, %885, %cst_603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_604 = arith.constant 1.5707963267948966 : f64
    %887 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %cst_604) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_605 = arith.constant 1.5707963267948966 : f64
    %888 = qlx.apply #qlx.action<pauli_rotation>(%880#1, %cst_605) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_606 = arith.constant 1.5707963267948966 : f64
    %889:2 = qlx.apply #qlx.action<pauli_rotation>(%887, %888, %cst_606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_607 = arith.constant 1.5707963267948966 : f64
    %890 = qlx.apply #qlx.action<pauli_rotation>(%876#0, %cst_607) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_608 = arith.constant 1.5707963267948966 : f64
    %891 = qlx.apply #qlx.action<pauli_rotation>(%876#1, %cst_608) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_609 = arith.constant 1.5707963267948966 : f64
    %892:2 = qlx.apply #qlx.action<pauli_rotation>(%890, %891, %cst_609) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_610 = arith.constant 1.5707963267948966 : f64
    %893 = qlx.apply #qlx.action<pauli_rotation>(%889#1, %cst_610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %894 = qlx.apply #qlx.action<h>(%893) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_611 = arith.constant 1.5707963267948966 : f64
    %895 = qlx.apply #qlx.action<pauli_rotation>(%892#1, %cst_611) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_612 = arith.constant 1.5707963267948966 : f64
    %896:2 = qlx.apply #qlx.action<pauli_rotation>(%894, %895, %cst_612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_613 = arith.constant 1.5707963267948966 : f64
    %897 = qlx.apply #qlx.action<pauli_rotation>(%870#0, %cst_613) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %898 = qlx.apply #qlx.action<h>(%897) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_614 = arith.constant 1.5707963267948966 : f64
    %899 = qlx.apply #qlx.action<pauli_rotation>(%898, %cst_614) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %900 = qlx.apply #qlx.action<h>(%899) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_615 = arith.constant 1.5707963267948966 : f64
    %901 = qlx.apply #qlx.action<pauli_rotation>(%896#1, %cst_615) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_616 = arith.constant 1.5707963267948966 : f64
    %902:2 = qlx.apply #qlx.action<pauli_rotation>(%900, %901, %cst_616) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_617 = arith.constant 1.5707963267948966 : f64
    %903 = qlx.apply #qlx.action<pauli_rotation>(%902#1, %cst_617) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %904 = qlx.apply #qlx.action<h>(%903) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_618 = arith.constant 1.5707963267948966 : f64
    %905 = qlx.apply #qlx.action<pauli_rotation>(%886#1, %cst_618) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %906 = qlx.apply #qlx.action<h>(%905) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_619 = arith.constant 1.250000e-01 : f64
    %907:2 = qlx.apply #qlx.action<pauli_rotation>(%904, %906, %cst_619) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_620 = arith.constant 1.5707963267948966 : f64
    %908 = qlx.apply #qlx.action<pauli_rotation>(%902#0, %cst_620) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %909 = qlx.apply #qlx.action<h>(%907#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_621 = arith.constant 1.5707963267948966 : f64
    %910:2 = qlx.apply #qlx.action<pauli_rotation>(%908, %909, %cst_621) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_622 = arith.constant 1.5707963267948966 : f64
    %911 = qlx.apply #qlx.action<pauli_rotation>(%896#0, %cst_622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_623 = arith.constant 1.5707963267948966 : f64
    %912 = qlx.apply #qlx.action<pauli_rotation>(%910#1, %cst_623) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_624 = arith.constant 1.5707963267948966 : f64
    %913:2 = qlx.apply #qlx.action<pauli_rotation>(%911, %912, %cst_624) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_625 = arith.constant 1.5707963267948966 : f64
    %914 = qlx.apply #qlx.action<pauli_rotation>(%892#0, %cst_625) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_626 = arith.constant 1.5707963267948966 : f64
    %915 = qlx.apply #qlx.action<pauli_rotation>(%913#1, %cst_626) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_627 = arith.constant 1.5707963267948966 : f64
    %916:2 = qlx.apply #qlx.action<pauli_rotation>(%914, %915, %cst_627) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_628 = arith.constant 1.5707963267948966 : f64
    %917 = qlx.apply #qlx.action<pauli_rotation>(%889#0, %cst_628) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_629 = arith.constant 1.5707963267948966 : f64
    %918 = qlx.apply #qlx.action<pauli_rotation>(%913#0, %cst_629) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %919 = qlx.apply #qlx.action<h>(%918) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_630 = arith.constant 1.5707963267948966 : f64
    %920:2 = qlx.apply #qlx.action<pauli_rotation>(%917, %919, %cst_630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_631 = arith.constant 1.5707963267948966 : f64
    %921 = qlx.apply #qlx.action<pauli_rotation>(%886#0, %cst_631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %922 = qlx.apply #qlx.action<h>(%907#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_632 = arith.constant 1.5707963267948966 : f64
    %923:2 = qlx.apply #qlx.action<pauli_rotation>(%921, %922, %cst_632) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_633 = arith.constant 1.5707963267948966 : f64
    %924 = qlx.apply #qlx.action<pauli_rotation>(%916#1, %cst_633) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_634 = arith.constant 1.5707963267948966 : f64
    %925 = qlx.apply #qlx.action<pauli_rotation>(%916#0, %cst_634) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %926 = qlx.apply #qlx.action<h>(%925) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_635 = arith.constant 1.5707963267948966 : f64
    %927:2 = qlx.apply #qlx.action<pauli_rotation>(%924, %926, %cst_635) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_636 = arith.constant 1.5707963267948966 : f64
    %928 = qlx.apply #qlx.action<pauli_rotation>(%927#1, %cst_636) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %929 = qlx.apply #qlx.action<h>(%928) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_637 = arith.constant 1.5707963267948966 : f64
    %930 = qlx.apply #qlx.action<pauli_rotation>(%923#0, %cst_637) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %931 = qlx.apply #qlx.action<h>(%930) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_638 = arith.constant 1.250000e-01 : f64
    %932:2 = qlx.apply #qlx.action<pauli_rotation>(%929, %931, %cst_638) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_639 = arith.constant 1.5707963267948966 : f64
    %933 = qlx.apply #qlx.action<pauli_rotation>(%927#0, %cst_639) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %934 = qlx.apply #qlx.action<h>(%932#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_640 = arith.constant 1.5707963267948966 : f64
    %935:2 = qlx.apply #qlx.action<pauli_rotation>(%933, %934, %cst_640) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_641 = arith.constant 1.5707963267948966 : f64
    %936 = qlx.apply #qlx.action<pauli_rotation>(%935#0, %cst_641) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %937 = qlx.apply #qlx.action<h>(%936) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_642 = arith.constant 1.5707963267948966 : f64
    %938 = qlx.apply #qlx.action<pauli_rotation>(%937, %cst_642) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %939 = qlx.apply #qlx.action<h>(%938) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_643 = arith.constant 1.5707963267948966 : f64
    %940 = qlx.apply #qlx.action<pauli_rotation>(%935#1, %cst_643) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_644 = arith.constant 1.5707963267948966 : f64
    %941:2 = qlx.apply #qlx.action<pauli_rotation>(%939, %940, %cst_644) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_645 = arith.constant 1.5707963267948966 : f64
    %942 = qlx.apply #qlx.action<pauli_rotation>(%941#1, %cst_645) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %943 = qlx.apply #qlx.action<h>(%942) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %944 = qlx.apply #qlx.action<h>(%932#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_646 = arith.constant 1.5707963267948966 : f64
    %945 = qlx.apply #qlx.action<pauli_rotation>(%944, %cst_646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %946 = qlx.apply #qlx.action<h>(%945) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_647 = arith.constant 1.250000e-01 : f64
    %947:2 = qlx.apply #qlx.action<pauli_rotation>(%943, %946, %cst_647) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_648 = arith.constant 1.5707963267948966 : f64
    %948 = qlx.apply #qlx.action<pauli_rotation>(%941#0, %cst_648) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %949 = qlx.apply #qlx.action<h>(%947#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_649 = arith.constant 1.5707963267948966 : f64
    %950:2 = qlx.apply #qlx.action<pauli_rotation>(%948, %949, %cst_649) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_650 = arith.constant 1.5707963267948966 : f64
    %951 = qlx.apply #qlx.action<pauli_rotation>(%920#1, %cst_650) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_651 = arith.constant 1.5707963267948966 : f64
    %952 = qlx.apply #qlx.action<pauli_rotation>(%950#0, %cst_651) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %953 = qlx.apply #qlx.action<h>(%952) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_652 = arith.constant 1.5707963267948966 : f64
    %954 = qlx.apply #qlx.action<pauli_rotation>(%953, %cst_652) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %955 = qlx.apply #qlx.action<h>(%954) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_653 = arith.constant 1.5707963267948966 : f64
    %956:2 = qlx.apply #qlx.action<pauli_rotation>(%951, %955, %cst_653) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_654 = arith.constant 1.5707963267948966 : f64
    %957 = qlx.apply #qlx.action<pauli_rotation>(%956#1, %cst_654) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %958 = qlx.apply #qlx.action<h>(%957) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_655 = arith.constant 1.5707963267948966 : f64
    %959 = qlx.apply #qlx.action<pauli_rotation>(%950#1, %cst_655) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_656 = arith.constant 1.250000e-01 : f64
    %960:2 = qlx.apply #qlx.action<pauli_rotation>(%958, %959, %cst_656) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_657 = arith.constant 1.5707963267948966 : f64
    %961 = qlx.apply #qlx.action<pauli_rotation>(%956#0, %cst_657) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %962 = qlx.apply #qlx.action<h>(%960#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_658 = arith.constant 1.5707963267948966 : f64
    %963:2 = qlx.apply #qlx.action<pauli_rotation>(%961, %962, %cst_658) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_659 = arith.constant 1.5707963267948966 : f64
    %964 = qlx.apply #qlx.action<pauli_rotation>(%963#0, %cst_659) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %965 = qlx.apply #qlx.action<h>(%964) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_660 = arith.constant 1.5707963267948966 : f64
    %966 = qlx.apply #qlx.action<pauli_rotation>(%965, %cst_660) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %967 = qlx.apply #qlx.action<h>(%966) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_661 = arith.constant 1.5707963267948966 : f64
    %968 = qlx.apply #qlx.action<pauli_rotation>(%963#1, %cst_661) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_662 = arith.constant 1.5707963267948966 : f64
    %969:2 = qlx.apply #qlx.action<pauli_rotation>(%967, %968, %cst_662) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_663 = arith.constant 1.5707963267948966 : f64
    %970 = qlx.apply #qlx.action<pauli_rotation>(%969#1, %cst_663) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %971 = qlx.apply #qlx.action<h>(%970) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %972 = qlx.apply #qlx.action<h>(%960#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_664 = arith.constant 1.5707963267948966 : f64
    %973 = qlx.apply #qlx.action<pauli_rotation>(%972, %cst_664) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %974 = qlx.apply #qlx.action<h>(%973) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_665 = arith.constant 1.250000e-01 : f64
    %975:2 = qlx.apply #qlx.action<pauli_rotation>(%971, %974, %cst_665) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_666 = arith.constant 1.5707963267948966 : f64
    %976 = qlx.apply #qlx.action<pauli_rotation>(%969#0, %cst_666) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %977 = qlx.apply #qlx.action<h>(%975#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_667 = arith.constant 1.5707963267948966 : f64
    %978:2 = qlx.apply #qlx.action<pauli_rotation>(%976, %977, %cst_667) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_668 = arith.constant 1.5707963267948966 : f64
    %979 = qlx.apply #qlx.action<pauli_rotation>(%920#0, %cst_668) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %980 = qlx.apply #qlx.action<h>(%979) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_669 = arith.constant 1.5707963267948966 : f64
    %981 = qlx.apply #qlx.action<pauli_rotation>(%978#0, %cst_669) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %982 = qlx.apply #qlx.action<h>(%981) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_670 = arith.constant 1.5707963267948966 : f64
    %983 = qlx.apply #qlx.action<pauli_rotation>(%982, %cst_670) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %984 = qlx.apply #qlx.action<h>(%983) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_671 = arith.constant 1.5707963267948966 : f64
    %985:2 = qlx.apply #qlx.action<pauli_rotation>(%980, %984, %cst_671) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_672 = arith.constant 1.5707963267948966 : f64
    %986 = qlx.apply #qlx.action<pauli_rotation>(%985#1, %cst_672) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %987 = qlx.apply #qlx.action<h>(%986) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_673 = arith.constant 1.5707963267948966 : f64
    %988 = qlx.apply #qlx.action<pauli_rotation>(%978#1, %cst_673) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_674 = arith.constant 1.250000e-01 : f64
    %989:2 = qlx.apply #qlx.action<pauli_rotation>(%987, %988, %cst_674) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_675 = arith.constant 1.5707963267948966 : f64
    %990 = qlx.apply #qlx.action<pauli_rotation>(%985#0, %cst_675) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %991 = qlx.apply #qlx.action<h>(%989#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_676 = arith.constant 1.5707963267948966 : f64
    %992:2 = qlx.apply #qlx.action<pauli_rotation>(%990, %991, %cst_676) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_677 = arith.constant 1.5707963267948966 : f64
    %993 = qlx.apply #qlx.action<pauli_rotation>(%992#0, %cst_677) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %994 = qlx.apply #qlx.action<h>(%993) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_678 = arith.constant 1.5707963267948966 : f64
    %995 = qlx.apply #qlx.action<pauli_rotation>(%994, %cst_678) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %996 = qlx.apply #qlx.action<h>(%995) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_679 = arith.constant 1.5707963267948966 : f64
    %997 = qlx.apply #qlx.action<pauli_rotation>(%992#1, %cst_679) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_680 = arith.constant 1.5707963267948966 : f64
    %998:2 = qlx.apply #qlx.action<pauli_rotation>(%996, %997, %cst_680) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_681 = arith.constant 1.5707963267948966 : f64
    %999 = qlx.apply #qlx.action<pauli_rotation>(%998#1, %cst_681) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1000 = qlx.apply #qlx.action<h>(%999) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1001 = qlx.apply #qlx.action<h>(%989#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_682 = arith.constant 1.5707963267948966 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1001, %cst_682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1003 = qlx.apply #qlx.action<h>(%1002) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_683 = arith.constant 1.250000e-01 : f64
    %1004:2 = qlx.apply #qlx.action<pauli_rotation>(%1000, %1003, %cst_683) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_684 = arith.constant 1.5707963267948966 : f64
    %1005 = qlx.apply #qlx.action<pauli_rotation>(%998#0, %cst_684) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1006 = qlx.apply #qlx.action<h>(%1004#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_685 = arith.constant 1.5707963267948966 : f64
    %1007:2 = qlx.apply #qlx.action<pauli_rotation>(%1005, %1006, %cst_685) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_686 = arith.constant 1.5707963267948966 : f64
    %1008 = qlx.apply #qlx.action<pauli_rotation>(%910#0, %cst_686) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1009 = qlx.apply #qlx.action<h>(%1008) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_687 = arith.constant 1.5707963267948966 : f64
    %1010 = qlx.apply #qlx.action<pauli_rotation>(%1009, %cst_687) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1011 = qlx.apply #qlx.action<h>(%1010) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_688 = arith.constant 1.5707963267948966 : f64
    %1012 = qlx.apply #qlx.action<pauli_rotation>(%1007#0, %cst_688) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1013 = qlx.apply #qlx.action<h>(%1012) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_689 = arith.constant 1.5707963267948966 : f64
    %1014 = qlx.apply #qlx.action<pauli_rotation>(%1013, %cst_689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1015 = qlx.apply #qlx.action<h>(%1014) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_690 = arith.constant 1.5707963267948966 : f64
    %1016:2 = qlx.apply #qlx.action<pauli_rotation>(%1011, %1015, %cst_690) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_691 = arith.constant 1.5707963267948966 : f64
    %1017 = qlx.apply #qlx.action<pauli_rotation>(%1016#1, %cst_691) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1018 = qlx.apply #qlx.action<h>(%1017) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_692 = arith.constant 1.5707963267948966 : f64
    %1019 = qlx.apply #qlx.action<pauli_rotation>(%1007#1, %cst_692) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_693 = arith.constant 1.250000e-01 : f64
    %1020:2 = qlx.apply #qlx.action<pauli_rotation>(%1018, %1019, %cst_693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_694 = arith.constant 1.5707963267948966 : f64
    %1021 = qlx.apply #qlx.action<pauli_rotation>(%1016#0, %cst_694) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1022 = qlx.apply #qlx.action<h>(%1020#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_695 = arith.constant 1.5707963267948966 : f64
    %1023:2 = qlx.apply #qlx.action<pauli_rotation>(%1021, %1022, %cst_695) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_696 = arith.constant 1.5707963267948966 : f64
    %1024 = qlx.apply #qlx.action<pauli_rotation>(%1023#0, %cst_696) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1025 = qlx.apply #qlx.action<h>(%1024) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_697 = arith.constant 1.5707963267948966 : f64
    %1026 = qlx.apply #qlx.action<pauli_rotation>(%1025, %cst_697) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1027 = qlx.apply #qlx.action<h>(%1026) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_698 = arith.constant 1.5707963267948966 : f64
    %1028 = qlx.apply #qlx.action<pauli_rotation>(%1023#1, %cst_698) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_699 = arith.constant 1.5707963267948966 : f64
    %1029:2 = qlx.apply #qlx.action<pauli_rotation>(%1027, %1028, %cst_699) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_700 = arith.constant 1.5707963267948966 : f64
    %1030 = qlx.apply #qlx.action<pauli_rotation>(%1029#1, %cst_700) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1031 = qlx.apply #qlx.action<h>(%1030) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1032 = qlx.apply #qlx.action<h>(%1020#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_701 = arith.constant 1.5707963267948966 : f64
    %1033 = qlx.apply #qlx.action<pauli_rotation>(%1032, %cst_701) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1034 = qlx.apply #qlx.action<h>(%1033) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_702 = arith.constant 1.250000e-01 : f64
    %1035:2 = qlx.apply #qlx.action<pauli_rotation>(%1031, %1034, %cst_702) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_703 = arith.constant 1.5707963267948966 : f64
    %1036 = qlx.apply #qlx.action<pauli_rotation>(%1029#0, %cst_703) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1037 = qlx.apply #qlx.action<h>(%1035#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_704 = arith.constant 1.5707963267948966 : f64
    %1038:2 = qlx.apply #qlx.action<pauli_rotation>(%1036, %1037, %cst_704) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1039 = qlx.apply #qlx.action<h>(%947#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_705 = arith.constant 1.5707963267948966 : f64
    %1040 = qlx.apply #qlx.action<pauli_rotation>(%1039, %cst_705) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1041 = qlx.apply #qlx.action<h>(%975#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_706 = arith.constant 1.5707963267948966 : f64
    %1042 = qlx.apply #qlx.action<pauli_rotation>(%1041, %cst_706) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_707 = arith.constant 2.500000e-01 : f64
    %1043:2 = qlx.apply #qlx.action<pauli_rotation>(%1040, %1042, %cst_707) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1044 = qlx.apply #qlx.action<h>(%1004#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_708 = arith.constant 1.5707963267948966 : f64
    %1045 = qlx.apply #qlx.action<pauli_rotation>(%1044, %cst_708) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1046 = qlx.apply #qlx.action<h>(%1035#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_709 = arith.constant 1.5707963267948966 : f64
    %1047 = qlx.apply #qlx.action<pauli_rotation>(%1046, %cst_709) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_710 = arith.constant 2.500000e-01 : f64
    %1048:2 = qlx.apply #qlx.action<pauli_rotation>(%1045, %1047, %cst_710) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_711 = arith.constant 1.5707963267948966 : f64
    %1049 = qlx.apply #qlx.action<pauli_rotation>(%1038#1, %cst_711) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1050 = qlx.apply #qlx.action<h>(%1049) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_712 = arith.constant 1.5707963267948966 : f64
    %1051 = qlx.apply #qlx.action<pauli_rotation>(%1038#0, %cst_712) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1052 = qlx.apply #qlx.action<h>(%1051) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_713 = arith.constant 1.5707963267948966 : f64
    %1053 = qlx.apply #qlx.action<pauli_rotation>(%1052, %cst_713) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_714 = arith.constant 5.000000e-01 : f64
    %1054:2 = qlx.apply #qlx.action<pauli_rotation>(%1050, %1053, %cst_714) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_715 = arith.constant 2.500000e-01 : f64
    %1055:2 = qlx.apply #qlx.action<pauli_rotation>(%1048#0, %1048#1, %cst_715) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_716 = arith.constant 2.500000e-01 : f64
    %1056:2 = qlx.apply #qlx.action<pauli_rotation>(%1043#0, %1043#1, %cst_716) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_717 = arith.constant 1.5707963267948966 : f64
    %1057 = qlx.apply #qlx.action<pauli_rotation>(%1054#1, %cst_717) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1058 = qlx.apply #qlx.action<h>(%1057) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1059 = qlx.apply #qlx.action<h>(%1054#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_718 = arith.constant 1.5707963267948966 : f64
    %1060:2 = qlx.apply #qlx.action<pauli_rotation>(%1058, %1059, %cst_718) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_719 = arith.constant 1.5707963267948966 : f64
    %1061 = qlx.apply #qlx.action<pauli_rotation>(%1060#1, %cst_719) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1062 = qlx.apply #qlx.action<h>(%1061) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_720 = arith.constant 1.5707963267948966 : f64
    %1063 = qlx.apply #qlx.action<pauli_rotation>(%1055#1, %cst_720) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1064 = qlx.apply #qlx.action<h>(%1063) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_721 = arith.constant 1.250000e-01 : f64
    %1065:2 = qlx.apply #qlx.action<pauli_rotation>(%1062, %1064, %cst_721) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_722 = arith.constant 1.5707963267948966 : f64
    %1066 = qlx.apply #qlx.action<pauli_rotation>(%1060#0, %cst_722) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1067 = qlx.apply #qlx.action<h>(%1065#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_723 = arith.constant 1.5707963267948966 : f64
    %1068:2 = qlx.apply #qlx.action<pauli_rotation>(%1066, %1067, %cst_723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_724 = arith.constant 1.5707963267948966 : f64
    %1069 = qlx.apply #qlx.action<pauli_rotation>(%1068#0, %cst_724) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1070 = qlx.apply #qlx.action<h>(%1069) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_725 = arith.constant 1.5707963267948966 : f64
    %1071 = qlx.apply #qlx.action<pauli_rotation>(%1070, %cst_725) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1072 = qlx.apply #qlx.action<h>(%1071) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_726 = arith.constant 1.5707963267948966 : f64
    %1073 = qlx.apply #qlx.action<pauli_rotation>(%1068#1, %cst_726) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_727 = arith.constant 1.5707963267948966 : f64
    %1074:2 = qlx.apply #qlx.action<pauli_rotation>(%1072, %1073, %cst_727) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_728 = arith.constant 1.5707963267948966 : f64
    %1075 = qlx.apply #qlx.action<pauli_rotation>(%1074#1, %cst_728) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1076 = qlx.apply #qlx.action<h>(%1075) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1077 = qlx.apply #qlx.action<h>(%1065#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_729 = arith.constant 1.5707963267948966 : f64
    %1078 = qlx.apply #qlx.action<pauli_rotation>(%1077, %cst_729) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1079 = qlx.apply #qlx.action<h>(%1078) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_730 = arith.constant 1.250000e-01 : f64
    %1080:2 = qlx.apply #qlx.action<pauli_rotation>(%1076, %1079, %cst_730) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_731 = arith.constant 1.5707963267948966 : f64
    %1081 = qlx.apply #qlx.action<pauli_rotation>(%1074#0, %cst_731) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1082 = qlx.apply #qlx.action<h>(%1080#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_732 = arith.constant 1.5707963267948966 : f64
    %1083:2 = qlx.apply #qlx.action<pauli_rotation>(%1081, %1082, %cst_732) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_733 = arith.constant 1.5707963267948966 : f64
    %1084 = qlx.apply #qlx.action<pauli_rotation>(%1083#1, %cst_733) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1085 = qlx.apply #qlx.action<h>(%1084) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_734 = arith.constant 1.5707963267948966 : f64
    %1086 = qlx.apply #qlx.action<pauli_rotation>(%1085, %cst_734) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1087 = qlx.apply #qlx.action<h>(%1086) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_735 = arith.constant 1.5707963267948966 : f64
    %1088:2 = qlx.apply #qlx.action<pauli_rotation>(%1080#1, %1087, %cst_735) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_736 = arith.constant 1.5707963267948966 : f64
    %1089 = qlx.apply #qlx.action<pauli_rotation>(%1088#0, %cst_736) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1090 = qlx.apply #qlx.action<h>(%1089) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_737 = arith.constant 1.5707963267948966 : f64
    %1091 = qlx.apply #qlx.action<pauli_rotation>(%1055#0, %cst_737) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1092 = qlx.apply #qlx.action<h>(%1091) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_738 = arith.constant 1.250000e-01 : f64
    %1093:2 = qlx.apply #qlx.action<pauli_rotation>(%1090, %1092, %cst_738) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_739 = arith.constant 1.5707963267948966 : f64
    %1094 = qlx.apply #qlx.action<pauli_rotation>(%1088#1, %cst_739) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1095 = qlx.apply #qlx.action<h>(%1093#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_740 = arith.constant 1.5707963267948966 : f64
    %1096:2 = qlx.apply #qlx.action<pauli_rotation>(%1094, %1095, %cst_740) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_741 = arith.constant 1.5707963267948966 : f64
    %1097 = qlx.apply #qlx.action<pauli_rotation>(%1096#0, %cst_741) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1098 = qlx.apply #qlx.action<h>(%1097) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_742 = arith.constant 1.5707963267948966 : f64
    %1099 = qlx.apply #qlx.action<pauli_rotation>(%1098, %cst_742) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1100 = qlx.apply #qlx.action<h>(%1099) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_743 = arith.constant 1.5707963267948966 : f64
    %1101 = qlx.apply #qlx.action<pauli_rotation>(%1096#1, %cst_743) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_744 = arith.constant 1.5707963267948966 : f64
    %1102:2 = qlx.apply #qlx.action<pauli_rotation>(%1100, %1101, %cst_744) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_745 = arith.constant 1.5707963267948966 : f64
    %1103 = qlx.apply #qlx.action<pauli_rotation>(%1102#1, %cst_745) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1104 = qlx.apply #qlx.action<h>(%1103) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1105 = qlx.apply #qlx.action<h>(%1093#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_746 = arith.constant 1.5707963267948966 : f64
    %1106 = qlx.apply #qlx.action<pauli_rotation>(%1105, %cst_746) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1107 = qlx.apply #qlx.action<h>(%1106) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_747 = arith.constant 1.250000e-01 : f64
    %1108:2 = qlx.apply #qlx.action<pauli_rotation>(%1104, %1107, %cst_747) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_748 = arith.constant 1.5707963267948966 : f64
    %1109 = qlx.apply #qlx.action<pauli_rotation>(%1102#0, %cst_748) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1110 = qlx.apply #qlx.action<h>(%1108#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_749 = arith.constant 1.5707963267948966 : f64
    %1111:2 = qlx.apply #qlx.action<pauli_rotation>(%1109, %1110, %cst_749) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_750 = arith.constant 1.5707963267948966 : f64
    %1112 = qlx.apply #qlx.action<pauli_rotation>(%1111#1, %cst_750) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1113 = qlx.apply #qlx.action<h>(%1112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_751 = arith.constant 1.5707963267948966 : f64
    %1114 = qlx.apply #qlx.action<pauli_rotation>(%1113, %cst_751) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1115 = qlx.apply #qlx.action<h>(%1114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_752 = arith.constant 1.5707963267948966 : f64
    %1116:2 = qlx.apply #qlx.action<pauli_rotation>(%1108#1, %1115, %cst_752) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_753 = arith.constant 1.5707963267948966 : f64
    %1117 = qlx.apply #qlx.action<pauli_rotation>(%1116#0, %cst_753) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1118 = qlx.apply #qlx.action<h>(%1117) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_754 = arith.constant 1.5707963267948966 : f64
    %1119 = qlx.apply #qlx.action<pauli_rotation>(%1056#1, %cst_754) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1120 = qlx.apply #qlx.action<h>(%1119) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_755 = arith.constant 1.250000e-01 : f64
    %1121:2 = qlx.apply #qlx.action<pauli_rotation>(%1118, %1120, %cst_755) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_756 = arith.constant 1.5707963267948966 : f64
    %1122 = qlx.apply #qlx.action<pauli_rotation>(%1116#1, %cst_756) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1123 = qlx.apply #qlx.action<h>(%1121#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_757 = arith.constant 1.5707963267948966 : f64
    %1124:2 = qlx.apply #qlx.action<pauli_rotation>(%1122, %1123, %cst_757) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_758 = arith.constant 1.5707963267948966 : f64
    %1125 = qlx.apply #qlx.action<pauli_rotation>(%1124#0, %cst_758) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1126 = qlx.apply #qlx.action<h>(%1125) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_759 = arith.constant 1.5707963267948966 : f64
    %1127 = qlx.apply #qlx.action<pauli_rotation>(%1126, %cst_759) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1128 = qlx.apply #qlx.action<h>(%1127) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_760 = arith.constant 1.5707963267948966 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1124#1, %cst_760) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_761 = arith.constant 1.5707963267948966 : f64
    %1130:2 = qlx.apply #qlx.action<pauli_rotation>(%1128, %1129, %cst_761) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_762 = arith.constant 1.5707963267948966 : f64
    %1131 = qlx.apply #qlx.action<pauli_rotation>(%1130#1, %cst_762) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1132 = qlx.apply #qlx.action<h>(%1131) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1133 = qlx.apply #qlx.action<h>(%1121#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_763 = arith.constant 1.5707963267948966 : f64
    %1134 = qlx.apply #qlx.action<pauli_rotation>(%1133, %cst_763) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1135 = qlx.apply #qlx.action<h>(%1134) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_764 = arith.constant 1.250000e-01 : f64
    %1136:2 = qlx.apply #qlx.action<pauli_rotation>(%1132, %1135, %cst_764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_765 = arith.constant 1.5707963267948966 : f64
    %1137 = qlx.apply #qlx.action<pauli_rotation>(%1130#0, %cst_765) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1138 = qlx.apply #qlx.action<h>(%1136#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_766 = arith.constant 1.5707963267948966 : f64
    %1139:2 = qlx.apply #qlx.action<pauli_rotation>(%1137, %1138, %cst_766) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_767 = arith.constant 1.5707963267948966 : f64
    %1140 = qlx.apply #qlx.action<pauli_rotation>(%1139#1, %cst_767) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1141 = qlx.apply #qlx.action<h>(%1140) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_768 = arith.constant 1.5707963267948966 : f64
    %1142 = qlx.apply #qlx.action<pauli_rotation>(%1141, %cst_768) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1143 = qlx.apply #qlx.action<h>(%1142) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_769 = arith.constant 1.5707963267948966 : f64
    %1144:2 = qlx.apply #qlx.action<pauli_rotation>(%1136#1, %1143, %cst_769) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_770 = arith.constant 1.5707963267948966 : f64
    %1145 = qlx.apply #qlx.action<pauli_rotation>(%1144#0, %cst_770) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1146 = qlx.apply #qlx.action<h>(%1145) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_771 = arith.constant 1.5707963267948966 : f64
    %1147 = qlx.apply #qlx.action<pauli_rotation>(%1056#0, %cst_771) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1148 = qlx.apply #qlx.action<h>(%1147) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_772 = arith.constant 1.250000e-01 : f64
    %1149:2 = qlx.apply #qlx.action<pauli_rotation>(%1146, %1148, %cst_772) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_773 = arith.constant 1.5707963267948966 : f64
    %1150 = qlx.apply #qlx.action<pauli_rotation>(%1144#1, %cst_773) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1151 = qlx.apply #qlx.action<h>(%1149#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_774 = arith.constant 1.5707963267948966 : f64
    %1152:2 = qlx.apply #qlx.action<pauli_rotation>(%1150, %1151, %cst_774) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_775 = arith.constant 1.5707963267948966 : f64
    %1153 = qlx.apply #qlx.action<pauli_rotation>(%1152#0, %cst_775) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1154 = qlx.apply #qlx.action<h>(%1153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_776 = arith.constant 1.5707963267948966 : f64
    %1155 = qlx.apply #qlx.action<pauli_rotation>(%1154, %cst_776) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1156 = qlx.apply #qlx.action<h>(%1155) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_777 = arith.constant 1.5707963267948966 : f64
    %1157 = qlx.apply #qlx.action<pauli_rotation>(%1152#1, %cst_777) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_778 = arith.constant 1.5707963267948966 : f64
    %1158:2 = qlx.apply #qlx.action<pauli_rotation>(%1156, %1157, %cst_778) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_779 = arith.constant 1.5707963267948966 : f64
    %1159 = qlx.apply #qlx.action<pauli_rotation>(%1158#1, %cst_779) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1160 = qlx.apply #qlx.action<h>(%1159) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1161 = qlx.apply #qlx.action<h>(%1149#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_780 = arith.constant 1.5707963267948966 : f64
    %1162 = qlx.apply #qlx.action<pauli_rotation>(%1161, %cst_780) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1163 = qlx.apply #qlx.action<h>(%1162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_781 = arith.constant 1.250000e-01 : f64
    %1164:2 = qlx.apply #qlx.action<pauli_rotation>(%1160, %1163, %cst_781) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_782 = arith.constant 1.5707963267948966 : f64
    %1165 = qlx.apply #qlx.action<pauli_rotation>(%1158#0, %cst_782) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1166 = qlx.apply #qlx.action<h>(%1164#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_783 = arith.constant 1.5707963267948966 : f64
    %1167:2 = qlx.apply #qlx.action<pauli_rotation>(%1165, %1166, %cst_783) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1168 = qlx.apply #qlx.action<h>(%1164#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_784 = arith.constant 1.5707963267948966 : f64
    %1169 = qlx.apply #qlx.action<pauli_rotation>(%923#1, %cst_784) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_785 = arith.constant 1.5707963267948966 : f64
    %1170:2 = qlx.apply #qlx.action<pauli_rotation>(%1168, %1169, %cst_785) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_786 = arith.constant 1.5707963267948966 : f64
    %1171 = qlx.apply #qlx.action<pauli_rotation>(%1111#0, %cst_786) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1172 = qlx.apply #qlx.action<h>(%1171) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_787 = arith.constant 1.5707963267948966 : f64
    %1173 = qlx.apply #qlx.action<pauli_rotation>(%1139#0, %cst_787) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_788 = arith.constant 1.5707963267948966 : f64
    %1174:2 = qlx.apply #qlx.action<pauli_rotation>(%1172, %1173, %cst_788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_789 = arith.constant 1.5707963267948966 : f64
    %1175 = qlx.apply #qlx.action<pauli_rotation>(%1167#1, %cst_789) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1176 = qlx.apply #qlx.action<h>(%1175) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_790 = arith.constant 1.5707963267948966 : f64
    %1177 = qlx.apply #qlx.action<pauli_rotation>(%1167#0, %cst_790) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_791 = arith.constant 1.5707963267948966 : f64
    %1178:2 = qlx.apply #qlx.action<pauli_rotation>(%1176, %1177, %cst_791) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_792 = arith.constant 1.5707963267948966 : f64
    %1179 = qlx.apply #qlx.action<pauli_rotation>(%1174#1, %cst_792) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1180 = qlx.apply #qlx.action<h>(%1179) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_793 = arith.constant 1.5707963267948966 : f64
    %1181 = qlx.apply #qlx.action<pauli_rotation>(%1178#1, %cst_793) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_794 = arith.constant 1.5707963267948966 : f64
    %1182:2 = qlx.apply #qlx.action<pauli_rotation>(%1180, %1181, %cst_794) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_795 = arith.constant 1.5707963267948966 : f64
    %1183 = qlx.apply #qlx.action<pauli_rotation>(%1083#0, %cst_795) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1184 = qlx.apply #qlx.action<h>(%1183) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_796 = arith.constant 1.5707963267948966 : f64
    %1185 = qlx.apply #qlx.action<pauli_rotation>(%1184, %cst_796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1186 = qlx.apply #qlx.action<h>(%1185) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_797 = arith.constant 1.5707963267948966 : f64
    %1187 = qlx.apply #qlx.action<pauli_rotation>(%1182#1, %cst_797) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_798 = arith.constant 1.5707963267948966 : f64
    %1188:2 = qlx.apply #qlx.action<pauli_rotation>(%1186, %1187, %cst_798) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_799 = arith.constant 1.5707963267948966 : f64
    %1189 = qlx.apply #qlx.action<pauli_rotation>(%1188#1, %cst_799) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1190 = qlx.apply #qlx.action<h>(%1189) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_800 = arith.constant 1.5707963267948966 : f64
    %1191 = qlx.apply #qlx.action<pauli_rotation>(%1170#1, %cst_800) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1192 = qlx.apply #qlx.action<h>(%1191) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_801 = arith.constant 1.250000e-01 : f64
    %1193:2 = qlx.apply #qlx.action<pauli_rotation>(%1190, %1192, %cst_801) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_802 = arith.constant 1.5707963267948966 : f64
    %1194 = qlx.apply #qlx.action<pauli_rotation>(%1188#0, %cst_802) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1195 = qlx.apply #qlx.action<h>(%1193#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_803 = arith.constant 1.5707963267948966 : f64
    %1196:2 = qlx.apply #qlx.action<pauli_rotation>(%1194, %1195, %cst_803) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_804 = arith.constant 1.5707963267948966 : f64
    %1197 = qlx.apply #qlx.action<pauli_rotation>(%1182#0, %cst_804) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_805 = arith.constant 1.5707963267948966 : f64
    %1198 = qlx.apply #qlx.action<pauli_rotation>(%1196#1, %cst_805) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_806 = arith.constant 1.5707963267948966 : f64
    %1199:2 = qlx.apply #qlx.action<pauli_rotation>(%1197, %1198, %cst_806) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_807 = arith.constant 1.5707963267948966 : f64
    %1200 = qlx.apply #qlx.action<pauli_rotation>(%1178#0, %cst_807) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_808 = arith.constant 1.5707963267948966 : f64
    %1201 = qlx.apply #qlx.action<pauli_rotation>(%1199#1, %cst_808) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_809 = arith.constant 1.5707963267948966 : f64
    %1202:2 = qlx.apply #qlx.action<pauli_rotation>(%1200, %1201, %cst_809) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_810 = arith.constant 1.5707963267948966 : f64
    %1203 = qlx.apply #qlx.action<pauli_rotation>(%1174#0, %cst_810) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_811 = arith.constant 1.5707963267948966 : f64
    %1204 = qlx.apply #qlx.action<pauli_rotation>(%1199#0, %cst_811) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1205 = qlx.apply #qlx.action<h>(%1204) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_812 = arith.constant 1.5707963267948966 : f64
    %1206:2 = qlx.apply #qlx.action<pauli_rotation>(%1203, %1205, %cst_812) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_813 = arith.constant 1.5707963267948966 : f64
    %1207 = qlx.apply #qlx.action<pauli_rotation>(%1170#0, %cst_813) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1208 = qlx.apply #qlx.action<h>(%1193#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_814 = arith.constant 1.5707963267948966 : f64
    %1209:2 = qlx.apply #qlx.action<pauli_rotation>(%1207, %1208, %cst_814) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_815 = arith.constant 1.5707963267948966 : f64
    %1210 = qlx.apply #qlx.action<pauli_rotation>(%1209#0, %cst_815) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_816 = arith.constant 1.5707963267948966 : f64
    %1211:2 = qlx.apply #qlx.action<pauli_rotation>(%1209#1, %1210, %cst_816) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_817 = arith.constant 1.5707963267948966 : f64
    %1212 = qlx.apply #qlx.action<pauli_rotation>(%1206#0, %cst_817) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_818 = arith.constant 1.5707963267948966 : f64
    %1213 = qlx.apply #qlx.action<pauli_rotation>(%1206#1, %cst_818) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_819 = arith.constant 1.5707963267948966 : f64
    %1214:2 = qlx.apply #qlx.action<pauli_rotation>(%1212, %1213, %cst_819) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_820 = arith.constant 1.5707963267948966 : f64
    %1215 = qlx.apply #qlx.action<pauli_rotation>(%1202#0, %cst_820) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_821 = arith.constant 1.5707963267948966 : f64
    %1216 = qlx.apply #qlx.action<pauli_rotation>(%1202#1, %cst_821) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_822 = arith.constant 1.5707963267948966 : f64
    %1217:2 = qlx.apply #qlx.action<pauli_rotation>(%1215, %1216, %cst_822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_823 = arith.constant 1.5707963267948966 : f64
    %1218 = qlx.apply #qlx.action<pauli_rotation>(%1214#1, %cst_823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1219 = qlx.apply #qlx.action<h>(%1218) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_824 = arith.constant 1.5707963267948966 : f64
    %1220 = qlx.apply #qlx.action<pauli_rotation>(%1217#1, %cst_824) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_825 = arith.constant 1.5707963267948966 : f64
    %1221:2 = qlx.apply #qlx.action<pauli_rotation>(%1219, %1220, %cst_825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_826 = arith.constant 1.5707963267948966 : f64
    %1222 = qlx.apply #qlx.action<pauli_rotation>(%1196#0, %cst_826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1223 = qlx.apply #qlx.action<h>(%1222) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_827 = arith.constant 1.5707963267948966 : f64
    %1224 = qlx.apply #qlx.action<pauli_rotation>(%1223, %cst_827) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1225 = qlx.apply #qlx.action<h>(%1224) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_828 = arith.constant 1.5707963267948966 : f64
    %1226 = qlx.apply #qlx.action<pauli_rotation>(%1221#1, %cst_828) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_829 = arith.constant 1.5707963267948966 : f64
    %1227:2 = qlx.apply #qlx.action<pauli_rotation>(%1225, %1226, %cst_829) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_830 = arith.constant 1.5707963267948966 : f64
    %1228 = qlx.apply #qlx.action<pauli_rotation>(%1227#1, %cst_830) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1229 = qlx.apply #qlx.action<h>(%1228) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_831 = arith.constant 1.5707963267948966 : f64
    %1230 = qlx.apply #qlx.action<pauli_rotation>(%1211#0, %cst_831) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1231 = qlx.apply #qlx.action<h>(%1230) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_832 = arith.constant 1.250000e-01 : f64
    %1232:2 = qlx.apply #qlx.action<pauli_rotation>(%1229, %1231, %cst_832) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_833 = arith.constant 1.5707963267948966 : f64
    %1233 = qlx.apply #qlx.action<pauli_rotation>(%1227#0, %cst_833) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1234 = qlx.apply #qlx.action<h>(%1232#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_834 = arith.constant 1.5707963267948966 : f64
    %1235:2 = qlx.apply #qlx.action<pauli_rotation>(%1233, %1234, %cst_834) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_835 = arith.constant 1.5707963267948966 : f64
    %1236 = qlx.apply #qlx.action<pauli_rotation>(%1221#0, %cst_835) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_836 = arith.constant 1.5707963267948966 : f64
    %1237 = qlx.apply #qlx.action<pauli_rotation>(%1235#1, %cst_836) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_837 = arith.constant 1.5707963267948966 : f64
    %1238:2 = qlx.apply #qlx.action<pauli_rotation>(%1236, %1237, %cst_837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_838 = arith.constant 1.5707963267948966 : f64
    %1239 = qlx.apply #qlx.action<pauli_rotation>(%1217#0, %cst_838) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_839 = arith.constant 1.5707963267948966 : f64
    %1240 = qlx.apply #qlx.action<pauli_rotation>(%1238#1, %cst_839) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_840 = arith.constant 1.5707963267948966 : f64
    %1241:2 = qlx.apply #qlx.action<pauli_rotation>(%1239, %1240, %cst_840) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_841 = arith.constant 1.5707963267948966 : f64
    %1242 = qlx.apply #qlx.action<pauli_rotation>(%1214#0, %cst_841) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_842 = arith.constant 1.5707963267948966 : f64
    %1243 = qlx.apply #qlx.action<pauli_rotation>(%1238#0, %cst_842) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1244 = qlx.apply #qlx.action<h>(%1243) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_843 = arith.constant 1.5707963267948966 : f64
    %1245:2 = qlx.apply #qlx.action<pauli_rotation>(%1242, %1244, %cst_843) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_844 = arith.constant 1.5707963267948966 : f64
    %1246 = qlx.apply #qlx.action<pauli_rotation>(%1211#1, %cst_844) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1247 = qlx.apply #qlx.action<h>(%1232#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_845 = arith.constant 1.5707963267948966 : f64
    %1248:2 = qlx.apply #qlx.action<pauli_rotation>(%1246, %1247, %cst_845) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_846 = arith.constant 1.5707963267948966 : f64
    %1249 = qlx.apply #qlx.action<pauli_rotation>(%843#0, %cst_846) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_847 = arith.constant 1.5707963267948966 : f64
    %1250 = qlx.apply #qlx.action<pauli_rotation>(%1248#1, %cst_847) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1251 = qlx.apply #qlx.action<h>(%1250) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_848 = arith.constant 1.5707963267948966 : f64
    %1252:2 = qlx.apply #qlx.action<pauli_rotation>(%1249, %1251, %cst_848) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_849 = arith.constant 1.5707963267948966 : f64
    %1253 = qlx.apply #qlx.action<pauli_rotation>(%1248#0, %cst_849) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_850 = arith.constant 1.5707963267948966 : f64
    %1254 = qlx.apply #qlx.action<pauli_rotation>(%1252#1, %cst_850) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_851 = arith.constant 1.5707963267948966 : f64
    %1255:2 = qlx.apply #qlx.action<pauli_rotation>(%1253, %1254, %cst_851) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_852 = arith.constant 3.1415926535897931 : f64
    %1256 = qlx.apply #qlx.action<pauli_rotation>(%1245#0, %cst_852) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1257 = qlx.apply #qlx.action<h>(%1256) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_853 = arith.constant 1.5707963267948966 : f64
    %1258 = qlx.apply #qlx.action<pauli_rotation>(%1245#1, %cst_853) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_854 = arith.constant 1.5707963267948966 : f64
    %1259:2 = qlx.apply #qlx.action<pauli_rotation>(%1257, %1258, %cst_854) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_855 = arith.constant 1.5707963267948966 : f64
    %1260 = qlx.apply #qlx.action<pauli_rotation>(%1241#0, %cst_855) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_856 = arith.constant 1.5707963267948966 : f64
    %1261 = qlx.apply #qlx.action<pauli_rotation>(%1241#1, %cst_856) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_857 = arith.constant 1.5707963267948966 : f64
    %1262:2 = qlx.apply #qlx.action<pauli_rotation>(%1260, %1261, %cst_857) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_858 = arith.constant 1.5707963267948966 : f64
    %1263 = qlx.apply #qlx.action<pauli_rotation>(%1259#1, %cst_858) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1264 = qlx.apply #qlx.action<h>(%1263) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_859 = arith.constant 1.5707963267948966 : f64
    %1265 = qlx.apply #qlx.action<pauli_rotation>(%1262#1, %cst_859) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_860 = arith.constant 1.5707963267948966 : f64
    %1266:2 = qlx.apply #qlx.action<pauli_rotation>(%1264, %1265, %cst_860) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_861 = arith.constant 1.5707963267948966 : f64
    %1267 = qlx.apply #qlx.action<pauli_rotation>(%1266#1, %cst_861) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1268 = qlx.apply #qlx.action<h>(%1267) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_862 = arith.constant 1.5707963267948966 : f64
    %1269 = qlx.apply #qlx.action<pauli_rotation>(%1255#1, %cst_862) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1270 = qlx.apply #qlx.action<h>(%1269) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_863 = arith.constant 1.250000e-01 : f64
    %1271:2 = qlx.apply #qlx.action<pauli_rotation>(%1268, %1270, %cst_863) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_864 = arith.constant 1.5707963267948966 : f64
    %1272 = qlx.apply #qlx.action<pauli_rotation>(%1266#0, %cst_864) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1273 = qlx.apply #qlx.action<h>(%1271#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_865 = arith.constant 1.5707963267948966 : f64
    %1274:2 = qlx.apply #qlx.action<pauli_rotation>(%1272, %1273, %cst_865) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_866 = arith.constant 1.5707963267948966 : f64
    %1275 = qlx.apply #qlx.action<pauli_rotation>(%1262#0, %cst_866) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_867 = arith.constant 1.5707963267948966 : f64
    %1276 = qlx.apply #qlx.action<pauli_rotation>(%1274#1, %cst_867) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_868 = arith.constant 1.5707963267948966 : f64
    %1277:2 = qlx.apply #qlx.action<pauli_rotation>(%1275, %1276, %cst_868) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_869 = arith.constant 1.5707963267948966 : f64
    %1278 = qlx.apply #qlx.action<pauli_rotation>(%1259#0, %cst_869) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_870 = arith.constant 1.5707963267948966 : f64
    %1279 = qlx.apply #qlx.action<pauli_rotation>(%1274#0, %cst_870) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1280 = qlx.apply #qlx.action<h>(%1279) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_871 = arith.constant 1.5707963267948966 : f64
    %1281:2 = qlx.apply #qlx.action<pauli_rotation>(%1278, %1280, %cst_871) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_872 = arith.constant 1.5707963267948966 : f64
    %1282 = qlx.apply #qlx.action<pauli_rotation>(%1255#0, %cst_872) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1283 = qlx.apply #qlx.action<h>(%1271#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_873 = arith.constant 1.5707963267948966 : f64
    %1284:2 = qlx.apply #qlx.action<pauli_rotation>(%1282, %1283, %cst_873) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_874 = arith.constant 1.5707963267948966 : f64
    %1285 = qlx.apply #qlx.action<pauli_rotation>(%1252#0, %cst_874) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_875 = arith.constant 1.5707963267948966 : f64
    %1286 = qlx.apply #qlx.action<pauli_rotation>(%1284#1, %cst_875) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_876 = arith.constant 1.5707963267948966 : f64
    %1287:2 = qlx.apply #qlx.action<pauli_rotation>(%1285, %1286, %cst_876) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_877 = arith.constant 1.5707963267948966 : f64
    %1288 = qlx.apply #qlx.action<pauli_rotation>(%1287#0, %cst_877) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1289 = qlx.apply #qlx.action<h>(%1288) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_878 = arith.constant 1.5707963267948966 : f64
    %1290 = qlx.apply #qlx.action<pauli_rotation>(%1289, %cst_878) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1291 = qlx.apply #qlx.action<h>(%1290) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_879 = arith.constant 1.5707963267948966 : f64
    %1292 = qlx.apply #qlx.action<pauli_rotation>(%1287#1, %cst_879) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_880 = arith.constant 1.5707963267948966 : f64
    %1293:2 = qlx.apply #qlx.action<pauli_rotation>(%1291, %1292, %cst_880) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_881 = arith.constant 1.5707963267948966 : f64
    %1294 = qlx.apply #qlx.action<pauli_rotation>(%1284#0, %cst_881) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_882 = arith.constant 1.5707963267948966 : f64
    %1295 = qlx.apply #qlx.action<pauli_rotation>(%1293#1, %cst_882) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_883 = arith.constant 1.5707963267948966 : f64
    %1296:2 = qlx.apply #qlx.action<pauli_rotation>(%1294, %1295, %cst_883) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_884 = arith.constant 1.5707963267948966 : f64
    %1297 = qlx.apply #qlx.action<pauli_rotation>(%1281#0, %cst_884) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1298 = qlx.apply #qlx.action<h>(%1297) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_885 = arith.constant 1.5707963267948966 : f64
    %1299 = qlx.apply #qlx.action<pauli_rotation>(%1298, %cst_885) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1300 = qlx.apply #qlx.action<h>(%1299) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_886 = arith.constant 1.5707963267948966 : f64
    %1301 = qlx.apply #qlx.action<pauli_rotation>(%1281#1, %cst_886) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_887 = arith.constant 1.5707963267948966 : f64
    %1302:2 = qlx.apply #qlx.action<pauli_rotation>(%1300, %1301, %cst_887) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_888 = arith.constant 1.5707963267948966 : f64
    %1303 = qlx.apply #qlx.action<pauli_rotation>(%1277#0, %cst_888) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_889 = arith.constant 1.5707963267948966 : f64
    %1304 = qlx.apply #qlx.action<pauli_rotation>(%1277#1, %cst_889) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_890 = arith.constant 1.5707963267948966 : f64
    %1305:2 = qlx.apply #qlx.action<pauli_rotation>(%1303, %1304, %cst_890) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_891 = arith.constant 1.5707963267948966 : f64
    %1306 = qlx.apply #qlx.action<pauli_rotation>(%1302#1, %cst_891) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1307 = qlx.apply #qlx.action<h>(%1306) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_892 = arith.constant 1.5707963267948966 : f64
    %1308 = qlx.apply #qlx.action<pauli_rotation>(%1305#1, %cst_892) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_893 = arith.constant 1.5707963267948966 : f64
    %1309:2 = qlx.apply #qlx.action<pauli_rotation>(%1307, %1308, %cst_893) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_894 = arith.constant 1.5707963267948966 : f64
    %1310 = qlx.apply #qlx.action<pauli_rotation>(%1309#1, %cst_894) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1311 = qlx.apply #qlx.action<h>(%1310) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_895 = arith.constant 1.5707963267948966 : f64
    %1312 = qlx.apply #qlx.action<pauli_rotation>(%1296#1, %cst_895) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1313 = qlx.apply #qlx.action<h>(%1312) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_896 = arith.constant 1.250000e-01 : f64
    %1314:2 = qlx.apply #qlx.action<pauli_rotation>(%1311, %1313, %cst_896) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_897 = arith.constant 1.5707963267948966 : f64
    %1315 = qlx.apply #qlx.action<pauli_rotation>(%1309#0, %cst_897) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1316 = qlx.apply #qlx.action<h>(%1314#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_898 = arith.constant 1.5707963267948966 : f64
    %1317:2 = qlx.apply #qlx.action<pauli_rotation>(%1315, %1316, %cst_898) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_899 = arith.constant 1.5707963267948966 : f64
    %1318 = qlx.apply #qlx.action<pauli_rotation>(%1305#0, %cst_899) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_900 = arith.constant 1.5707963267948966 : f64
    %1319 = qlx.apply #qlx.action<pauli_rotation>(%1317#1, %cst_900) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_901 = arith.constant 1.5707963267948966 : f64
    %1320:2 = qlx.apply #qlx.action<pauli_rotation>(%1318, %1319, %cst_901) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_902 = arith.constant 1.5707963267948966 : f64
    %1321 = qlx.apply #qlx.action<pauli_rotation>(%1302#0, %cst_902) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_903 = arith.constant 1.5707963267948966 : f64
    %1322 = qlx.apply #qlx.action<pauli_rotation>(%1317#0, %cst_903) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1323 = qlx.apply #qlx.action<h>(%1322) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_904 = arith.constant 1.5707963267948966 : f64
    %1324:2 = qlx.apply #qlx.action<pauli_rotation>(%1321, %1323, %cst_904) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_905 = arith.constant 1.5707963267948966 : f64
    %1325 = qlx.apply #qlx.action<pauli_rotation>(%1296#0, %cst_905) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1326 = qlx.apply #qlx.action<h>(%1314#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_906 = arith.constant 1.5707963267948966 : f64
    %1327:2 = qlx.apply #qlx.action<pauli_rotation>(%1325, %1326, %cst_906) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_907 = arith.constant 1.5707963267948966 : f64
    %1328 = qlx.apply #qlx.action<pauli_rotation>(%1293#0, %cst_907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_908 = arith.constant 1.5707963267948966 : f64
    %1329 = qlx.apply #qlx.action<pauli_rotation>(%1327#1, %cst_908) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_909 = arith.constant 1.5707963267948966 : f64
    %1330:2 = qlx.apply #qlx.action<pauli_rotation>(%1328, %1329, %cst_909) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_910 = arith.constant 3.1415926535897931 : f64
    %1331 = qlx.apply #qlx.action<pauli_rotation>(%1320#0, %cst_910) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1332 = qlx.apply #qlx.action<h>(%1331) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_911 = arith.constant 1.5707963267948966 : f64
    %1333 = qlx.apply #qlx.action<pauli_rotation>(%1327#0, %cst_911) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1334 = qlx.apply #qlx.action<h>(%1333) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_912 = arith.constant 1.5707963267948966 : f64
    %1335:2 = qlx.apply #qlx.action<pauli_rotation>(%1332, %1334, %cst_912) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_913 = arith.constant 1.5707963267948966 : f64
    %1336 = qlx.apply #qlx.action<pauli_rotation>(%1335#1, %cst_913) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1337 = qlx.apply #qlx.action<h>(%1336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_914 = arith.constant 1.5707963267948966 : f64
    %1338 = qlx.apply #qlx.action<pauli_rotation>(%1330#1, %cst_914) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1339 = qlx.apply #qlx.action<h>(%1338) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_915 = arith.constant 1.5707963267948966 : f64
    %1340 = qlx.apply #qlx.action<pauli_rotation>(%1339, %cst_915) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1341 = qlx.apply #qlx.action<h>(%1340) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_916 = arith.constant 1.250000e-01 : f64
    %1342:2 = qlx.apply #qlx.action<pauli_rotation>(%1337, %1341, %cst_916) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_917 = arith.constant 1.5707963267948966 : f64
    %1343 = qlx.apply #qlx.action<pauli_rotation>(%1335#0, %cst_917) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1344 = qlx.apply #qlx.action<h>(%1342#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_918 = arith.constant 1.5707963267948966 : f64
    %1345:2 = qlx.apply #qlx.action<pauli_rotation>(%1343, %1344, %cst_918) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_919 = arith.constant 1.5707963267948966 : f64
    %1346 = qlx.apply #qlx.action<pauli_rotation>(%1345#0, %cst_919) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1347 = qlx.apply #qlx.action<h>(%1346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_920 = arith.constant 1.5707963267948966 : f64
    %1348 = qlx.apply #qlx.action<pauli_rotation>(%1347, %cst_920) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1349 = qlx.apply #qlx.action<h>(%1348) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_921 = arith.constant 1.5707963267948966 : f64
    %1350 = qlx.apply #qlx.action<pauli_rotation>(%1345#1, %cst_921) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_922 = arith.constant 1.5707963267948966 : f64
    %1351:2 = qlx.apply #qlx.action<pauli_rotation>(%1349, %1350, %cst_922) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_923 = arith.constant 1.5707963267948966 : f64
    %1352 = qlx.apply #qlx.action<pauli_rotation>(%1351#1, %cst_923) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1353 = qlx.apply #qlx.action<h>(%1352) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1354 = qlx.apply #qlx.action<h>(%1342#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_924 = arith.constant 1.5707963267948966 : f64
    %1355 = qlx.apply #qlx.action<pauli_rotation>(%1354, %cst_924) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1356 = qlx.apply #qlx.action<h>(%1355) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_925 = arith.constant 1.250000e-01 : f64
    %1357:2 = qlx.apply #qlx.action<pauli_rotation>(%1353, %1356, %cst_925) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_926 = arith.constant 1.5707963267948966 : f64
    %1358 = qlx.apply #qlx.action<pauli_rotation>(%1351#0, %cst_926) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1359 = qlx.apply #qlx.action<h>(%1357#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_927 = arith.constant 1.5707963267948966 : f64
    %1360:2 = qlx.apply #qlx.action<pauli_rotation>(%1358, %1359, %cst_927) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_928 = arith.constant 1.5707963267948966 : f64
    %1361 = qlx.apply #qlx.action<pauli_rotation>(%1360#1, %cst_928) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1362 = qlx.apply #qlx.action<h>(%1361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_929 = arith.constant 1.5707963267948966 : f64
    %1363 = qlx.apply #qlx.action<pauli_rotation>(%1362, %cst_929) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1364 = qlx.apply #qlx.action<h>(%1363) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_930 = arith.constant 1.5707963267948966 : f64
    %1365:2 = qlx.apply #qlx.action<pauli_rotation>(%1357#1, %1364, %cst_930) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_931 = arith.constant 1.5707963267948966 : f64
    %1366 = qlx.apply #qlx.action<pauli_rotation>(%1365#0, %cst_931) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1367 = qlx.apply #qlx.action<h>(%1366) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_932 = arith.constant 1.5707963267948966 : f64
    %1368 = qlx.apply #qlx.action<pauli_rotation>(%1330#0, %cst_932) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1369 = qlx.apply #qlx.action<h>(%1368) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_933 = arith.constant 1.5707963267948966 : f64
    %1370 = qlx.apply #qlx.action<pauli_rotation>(%1369, %cst_933) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1371 = qlx.apply #qlx.action<h>(%1370) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_934 = arith.constant 1.250000e-01 : f64
    %1372:2 = qlx.apply #qlx.action<pauli_rotation>(%1367, %1371, %cst_934) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_935 = arith.constant 1.5707963267948966 : f64
    %1373 = qlx.apply #qlx.action<pauli_rotation>(%1365#1, %cst_935) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1374 = qlx.apply #qlx.action<h>(%1372#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_936 = arith.constant 1.5707963267948966 : f64
    %1375:2 = qlx.apply #qlx.action<pauli_rotation>(%1373, %1374, %cst_936) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_937 = arith.constant 1.5707963267948966 : f64
    %1376 = qlx.apply #qlx.action<pauli_rotation>(%1375#0, %cst_937) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1377 = qlx.apply #qlx.action<h>(%1376) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_938 = arith.constant 1.5707963267948966 : f64
    %1378 = qlx.apply #qlx.action<pauli_rotation>(%1377, %cst_938) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1379 = qlx.apply #qlx.action<h>(%1378) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_939 = arith.constant 1.5707963267948966 : f64
    %1380 = qlx.apply #qlx.action<pauli_rotation>(%1375#1, %cst_939) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_940 = arith.constant 1.5707963267948966 : f64
    %1381:2 = qlx.apply #qlx.action<pauli_rotation>(%1379, %1380, %cst_940) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_941 = arith.constant 1.5707963267948966 : f64
    %1382 = qlx.apply #qlx.action<pauli_rotation>(%1381#1, %cst_941) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1383 = qlx.apply #qlx.action<h>(%1382) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1384 = qlx.apply #qlx.action<h>(%1372#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_942 = arith.constant 1.5707963267948966 : f64
    %1385 = qlx.apply #qlx.action<pauli_rotation>(%1384, %cst_942) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1386 = qlx.apply #qlx.action<h>(%1385) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_943 = arith.constant 1.250000e-01 : f64
    %1387:2 = qlx.apply #qlx.action<pauli_rotation>(%1383, %1386, %cst_943) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_944 = arith.constant 1.5707963267948966 : f64
    %1388 = qlx.apply #qlx.action<pauli_rotation>(%1381#0, %cst_944) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1389 = qlx.apply #qlx.action<h>(%1387#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_945 = arith.constant 1.5707963267948966 : f64
    %1390:2 = qlx.apply #qlx.action<pauli_rotation>(%1388, %1389, %cst_945) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1391 = qlx.apply #qlx.action<h>(%1387#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_946 = arith.constant 1.5707963267948966 : f64
    %1392 = qlx.apply #qlx.action<pauli_rotation>(%1390#1, %cst_946) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1393 = qlx.apply #qlx.action<h>(%1392) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_947 = arith.constant 5.000000e-01 : f64
    %1394:2 = qlx.apply #qlx.action<pauli_rotation>(%1391, %1393, %cst_947) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_948 = arith.constant 1.5707963267948966 : f64
    %1395 = qlx.apply #qlx.action<pauli_rotation>(%1390#0, %cst_948) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1396 = qlx.apply #qlx.action<h>(%1394#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_949 = arith.constant 1.5707963267948966 : f64
    %1397:2 = qlx.apply #qlx.action<pauli_rotation>(%1395, %1396, %cst_949) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_950 = arith.constant 1.5707963267948966 : f64
    %1398 = qlx.apply #qlx.action<pauli_rotation>(%1397#1, %cst_950) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1399 = qlx.apply #qlx.action<h>(%1398) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1400 = qlx.apply #qlx.action<h>(%1394#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_951 = arith.constant 1.250000e-01 : f64
    %1401:2 = qlx.apply #qlx.action<pauli_rotation>(%1399, %1400, %cst_951) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_952 = arith.constant 1.5707963267948966 : f64
    %1402 = qlx.apply #qlx.action<pauli_rotation>(%1397#0, %cst_952) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1403 = qlx.apply #qlx.action<h>(%1401#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_953 = arith.constant 1.5707963267948966 : f64
    %1404:2 = qlx.apply #qlx.action<pauli_rotation>(%1402, %1403, %cst_953) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_954 = arith.constant 1.5707963267948966 : f64
    %1405 = qlx.apply #qlx.action<pauli_rotation>(%1404#0, %cst_954) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1406 = qlx.apply #qlx.action<h>(%1405) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_955 = arith.constant 1.5707963267948966 : f64
    %1407 = qlx.apply #qlx.action<pauli_rotation>(%1406, %cst_955) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1408 = qlx.apply #qlx.action<h>(%1407) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_956 = arith.constant 1.5707963267948966 : f64
    %1409 = qlx.apply #qlx.action<pauli_rotation>(%1404#1, %cst_956) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_957 = arith.constant 1.5707963267948966 : f64
    %1410:2 = qlx.apply #qlx.action<pauli_rotation>(%1408, %1409, %cst_957) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_958 = arith.constant 1.5707963267948966 : f64
    %1411 = qlx.apply #qlx.action<pauli_rotation>(%1410#1, %cst_958) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1412 = qlx.apply #qlx.action<h>(%1411) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1413 = qlx.apply #qlx.action<h>(%1401#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_959 = arith.constant 1.5707963267948966 : f64
    %1414 = qlx.apply #qlx.action<pauli_rotation>(%1413, %cst_959) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1415 = qlx.apply #qlx.action<h>(%1414) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_960 = arith.constant 1.250000e-01 : f64
    %1416:2 = qlx.apply #qlx.action<pauli_rotation>(%1412, %1415, %cst_960) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_961 = arith.constant 1.5707963267948966 : f64
    %1417 = qlx.apply #qlx.action<pauli_rotation>(%1410#0, %cst_961) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1418 = qlx.apply #qlx.action<h>(%1416#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_962 = arith.constant 1.5707963267948966 : f64
    %1419:2 = qlx.apply #qlx.action<pauli_rotation>(%1417, %1418, %cst_962) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_963 = arith.constant 1.5707963267948966 : f64
    %1420 = qlx.apply #qlx.action<pauli_rotation>(%1360#0, %cst_963) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_964 = arith.constant 1.5707963267948966 : f64
    %1421 = qlx.apply #qlx.action<pauli_rotation>(%1419#0, %cst_964) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1422 = qlx.apply #qlx.action<h>(%1421) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_965 = arith.constant 1.5707963267948966 : f64
    %1423 = qlx.apply #qlx.action<pauli_rotation>(%1422, %cst_965) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1424 = qlx.apply #qlx.action<h>(%1423) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_966 = arith.constant 1.5707963267948966 : f64
    %1425:2 = qlx.apply #qlx.action<pauli_rotation>(%1420, %1424, %cst_966) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_967 = arith.constant 1.5707963267948966 : f64
    %1426 = qlx.apply #qlx.action<pauli_rotation>(%1425#1, %cst_967) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1427 = qlx.apply #qlx.action<h>(%1426) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_968 = arith.constant 1.5707963267948966 : f64
    %1428 = qlx.apply #qlx.action<pauli_rotation>(%1419#1, %cst_968) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_969 = arith.constant 1.250000e-01 : f64
    %1429:2 = qlx.apply #qlx.action<pauli_rotation>(%1427, %1428, %cst_969) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_970 = arith.constant 1.5707963267948966 : f64
    %1430 = qlx.apply #qlx.action<pauli_rotation>(%1425#0, %cst_970) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1431 = qlx.apply #qlx.action<h>(%1429#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_971 = arith.constant 1.5707963267948966 : f64
    %1432:2 = qlx.apply #qlx.action<pauli_rotation>(%1430, %1431, %cst_971) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_972 = arith.constant 1.5707963267948966 : f64
    %1433 = qlx.apply #qlx.action<pauli_rotation>(%1432#0, %cst_972) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1434 = qlx.apply #qlx.action<h>(%1433) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_973 = arith.constant 1.5707963267948966 : f64
    %1435 = qlx.apply #qlx.action<pauli_rotation>(%1434, %cst_973) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1436 = qlx.apply #qlx.action<h>(%1435) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_974 = arith.constant 1.5707963267948966 : f64
    %1437 = qlx.apply #qlx.action<pauli_rotation>(%1432#1, %cst_974) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_975 = arith.constant 1.5707963267948966 : f64
    %1438:2 = qlx.apply #qlx.action<pauli_rotation>(%1436, %1437, %cst_975) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_976 = arith.constant 1.5707963267948966 : f64
    %1439 = qlx.apply #qlx.action<pauli_rotation>(%1438#1, %cst_976) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1440 = qlx.apply #qlx.action<h>(%1439) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1441 = qlx.apply #qlx.action<h>(%1429#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_977 = arith.constant 1.5707963267948966 : f64
    %1442 = qlx.apply #qlx.action<pauli_rotation>(%1441, %cst_977) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1443 = qlx.apply #qlx.action<h>(%1442) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_978 = arith.constant 1.250000e-01 : f64
    %1444:2 = qlx.apply #qlx.action<pauli_rotation>(%1440, %1443, %cst_978) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_979 = arith.constant 1.5707963267948966 : f64
    %1445 = qlx.apply #qlx.action<pauli_rotation>(%1438#0, %cst_979) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1446 = qlx.apply #qlx.action<h>(%1444#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_980 = arith.constant 1.5707963267948966 : f64
    %1447:2 = qlx.apply #qlx.action<pauli_rotation>(%1445, %1446, %cst_980) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1448 = qlx.apply #qlx.action<h>(%1416#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_981 = arith.constant 1.5707963267948966 : f64
    %1449 = qlx.apply #qlx.action<pauli_rotation>(%1448, %cst_981) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1450 = qlx.apply #qlx.action<h>(%1449) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1451 = qlx.apply #qlx.action<h>(%1444#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_982 = arith.constant 1.5707963267948966 : f64
    %1452 = qlx.apply #qlx.action<pauli_rotation>(%1451, %cst_982) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1453 = qlx.apply #qlx.action<h>(%1452) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_983 = arith.constant 1.5707963267948966 : f64
    %1454:2 = qlx.apply #qlx.action<pauli_rotation>(%1450, %1453, %cst_983) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_984 = arith.constant 1.5707963267948966 : f64
    %1455 = qlx.apply #qlx.action<pauli_rotation>(%1447#1, %cst_984) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1456 = qlx.apply #qlx.action<h>(%1455) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_985 = arith.constant 1.5707963267948966 : f64
    %1457 = qlx.apply #qlx.action<pauli_rotation>(%1454#1, %cst_985) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_986 = arith.constant 1.5707963267948966 : f64
    %1458:2 = qlx.apply #qlx.action<pauli_rotation>(%1456, %1457, %cst_986) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_987 = arith.constant 1.5707963267948966 : f64
    %1459 = qlx.apply #qlx.action<pauli_rotation>(%1324#0, %cst_987) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_988 = arith.constant 1.5707963267948966 : f64
    %1460 = qlx.apply #qlx.action<pauli_rotation>(%1324#1, %cst_988) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_989 = arith.constant 1.5707963267948966 : f64
    %1461:2 = qlx.apply #qlx.action<pauli_rotation>(%1459, %1460, %cst_989) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_990 = arith.constant 1.5707963267948966 : f64
    %1462 = qlx.apply #qlx.action<pauli_rotation>(%1447#0, %cst_990) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1463 = qlx.apply #qlx.action<h>(%1462) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_991 = arith.constant 1.5707963267948966 : f64
    %1464 = qlx.apply #qlx.action<pauli_rotation>(%1463, %cst_991) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_992 = arith.constant 1.5707963267948966 : f64
    %1465 = qlx.apply #qlx.action<pauli_rotation>(%1320#1, %cst_992) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_993 = arith.constant 1.5707963267948966 : f64
    %1466:2 = qlx.apply #qlx.action<pauli_rotation>(%1464, %1465, %cst_993) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_994 = arith.constant 1.5707963267948966 : f64
    %1467 = qlx.apply #qlx.action<pauli_rotation>(%1461#1, %cst_994) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1468 = qlx.apply #qlx.action<h>(%1467) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_995 = arith.constant 1.5707963267948966 : f64
    %1469 = qlx.apply #qlx.action<pauli_rotation>(%1466#1, %cst_995) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_996 = arith.constant 1.5707963267948966 : f64
    %1470:2 = qlx.apply #qlx.action<pauli_rotation>(%1468, %1469, %cst_996) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_997 = arith.constant 1.5707963267948966 : f64
    %1471 = qlx.apply #qlx.action<pauli_rotation>(%1470#1, %cst_997) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1472 = qlx.apply #qlx.action<h>(%1471) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_998 = arith.constant 1.5707963267948966 : f64
    %1473 = qlx.apply #qlx.action<pauli_rotation>(%1458#1, %cst_998) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1474 = qlx.apply #qlx.action<h>(%1473) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_999 = arith.constant 1.250000e-01 : f64
    %1475:2 = qlx.apply #qlx.action<pauli_rotation>(%1472, %1474, %cst_999) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1000 = arith.constant 1.5707963267948966 : f64
    %1476 = qlx.apply #qlx.action<pauli_rotation>(%1470#0, %cst_1000) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1477 = qlx.apply #qlx.action<h>(%1475#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1001 = arith.constant 1.5707963267948966 : f64
    %1478:2 = qlx.apply #qlx.action<pauli_rotation>(%1476, %1477, %cst_1001) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1002 = arith.constant 1.5707963267948966 : f64
    %1479 = qlx.apply #qlx.action<pauli_rotation>(%1466#0, %cst_1002) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1003 = arith.constant 1.5707963267948966 : f64
    %1480 = qlx.apply #qlx.action<pauli_rotation>(%1478#1, %cst_1003) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1004 = arith.constant 1.5707963267948966 : f64
    %1481:2 = qlx.apply #qlx.action<pauli_rotation>(%1479, %1480, %cst_1004) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1005 = arith.constant 1.5707963267948966 : f64
    %1482 = qlx.apply #qlx.action<pauli_rotation>(%1461#0, %cst_1005) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1006 = arith.constant 1.5707963267948966 : f64
    %1483 = qlx.apply #qlx.action<pauli_rotation>(%1478#0, %cst_1006) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1484 = qlx.apply #qlx.action<h>(%1483) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1007 = arith.constant 1.5707963267948966 : f64
    %1485:2 = qlx.apply #qlx.action<pauli_rotation>(%1482, %1484, %cst_1007) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1008 = arith.constant 1.5707963267948966 : f64
    %1486 = qlx.apply #qlx.action<pauli_rotation>(%1458#0, %cst_1008) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1487 = qlx.apply #qlx.action<h>(%1475#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1009 = arith.constant 1.5707963267948966 : f64
    %1488:2 = qlx.apply #qlx.action<pauli_rotation>(%1486, %1487, %cst_1009) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1010 = arith.constant 1.5707963267948966 : f64
    %1489 = qlx.apply #qlx.action<pauli_rotation>(%1454#0, %cst_1010) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1011 = arith.constant 1.5707963267948966 : f64
    %1490 = qlx.apply #qlx.action<pauli_rotation>(%1488#1, %cst_1011) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1012 = arith.constant 1.5707963267948966 : f64
    %1491:2 = qlx.apply #qlx.action<pauli_rotation>(%1489, %1490, %cst_1012) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1013 = arith.constant 1.5707963267948966 : f64
    %1492 = qlx.apply #qlx.action<pauli_rotation>(%1491#0, %cst_1013) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1493 = qlx.apply #qlx.action<h>(%1492) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1014 = arith.constant 1.5707963267948966 : f64
    %1494 = qlx.apply #qlx.action<pauli_rotation>(%1493, %cst_1014) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1495 = qlx.apply #qlx.action<h>(%1494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1015 = arith.constant 1.5707963267948966 : f64
    %1496 = qlx.apply #qlx.action<pauli_rotation>(%1491#1, %cst_1015) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1016 = arith.constant 1.5707963267948966 : f64
    %1497:2 = qlx.apply #qlx.action<pauli_rotation>(%1495, %1496, %cst_1016) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1017 = arith.constant 1.5707963267948966 : f64
    %1498 = qlx.apply #qlx.action<pauli_rotation>(%1488#0, %cst_1017) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1018 = arith.constant 1.5707963267948966 : f64
    %1499 = qlx.apply #qlx.action<pauli_rotation>(%1497#1, %cst_1018) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1019 = arith.constant 1.5707963267948966 : f64
    %1500:2 = qlx.apply #qlx.action<pauli_rotation>(%1498, %1499, %cst_1019) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1020 = arith.constant 1.5707963267948966 : f64
    %1501 = qlx.apply #qlx.action<pauli_rotation>(%1485#0, %cst_1020) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1502 = qlx.apply #qlx.action<h>(%1501) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1021 = arith.constant 1.5707963267948966 : f64
    %1503 = qlx.apply #qlx.action<pauli_rotation>(%1502, %cst_1021) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1504 = qlx.apply #qlx.action<h>(%1503) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1022 = arith.constant 1.5707963267948966 : f64
    %1505 = qlx.apply #qlx.action<pauli_rotation>(%1485#1, %cst_1022) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1023 = arith.constant 1.5707963267948966 : f64
    %1506:2 = qlx.apply #qlx.action<pauli_rotation>(%1504, %1505, %cst_1023) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1024 = arith.constant 1.5707963267948966 : f64
    %1507 = qlx.apply #qlx.action<pauli_rotation>(%1481#0, %cst_1024) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1025 = arith.constant 1.5707963267948966 : f64
    %1508 = qlx.apply #qlx.action<pauli_rotation>(%1481#1, %cst_1025) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1026 = arith.constant 1.5707963267948966 : f64
    %1509:2 = qlx.apply #qlx.action<pauli_rotation>(%1507, %1508, %cst_1026) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1027 = arith.constant 1.5707963267948966 : f64
    %1510 = qlx.apply #qlx.action<pauli_rotation>(%1506#1, %cst_1027) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1511 = qlx.apply #qlx.action<h>(%1510) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1028 = arith.constant 1.5707963267948966 : f64
    %1512 = qlx.apply #qlx.action<pauli_rotation>(%1509#1, %cst_1028) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1029 = arith.constant 1.5707963267948966 : f64
    %1513:2 = qlx.apply #qlx.action<pauli_rotation>(%1511, %1512, %cst_1029) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1030 = arith.constant 1.5707963267948966 : f64
    %1514 = qlx.apply #qlx.action<pauli_rotation>(%1513#1, %cst_1030) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1515 = qlx.apply #qlx.action<h>(%1514) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1031 = arith.constant 1.5707963267948966 : f64
    %1516 = qlx.apply #qlx.action<pauli_rotation>(%1500#1, %cst_1031) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1517 = qlx.apply #qlx.action<h>(%1516) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1032 = arith.constant 1.250000e-01 : f64
    %1518:2 = qlx.apply #qlx.action<pauli_rotation>(%1515, %1517, %cst_1032) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1033 = arith.constant 1.5707963267948966 : f64
    %1519 = qlx.apply #qlx.action<pauli_rotation>(%1513#0, %cst_1033) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1520 = qlx.apply #qlx.action<h>(%1518#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1034 = arith.constant 1.5707963267948966 : f64
    %1521:2 = qlx.apply #qlx.action<pauli_rotation>(%1519, %1520, %cst_1034) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1035 = arith.constant 1.5707963267948966 : f64
    %1522 = qlx.apply #qlx.action<pauli_rotation>(%1509#0, %cst_1035) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1036 = arith.constant 1.5707963267948966 : f64
    %1523 = qlx.apply #qlx.action<pauli_rotation>(%1521#1, %cst_1036) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1037 = arith.constant 1.5707963267948966 : f64
    %1524:2 = qlx.apply #qlx.action<pauli_rotation>(%1522, %1523, %cst_1037) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1038 = arith.constant 1.5707963267948966 : f64
    %1525 = qlx.apply #qlx.action<pauli_rotation>(%1506#0, %cst_1038) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1039 = arith.constant 1.5707963267948966 : f64
    %1526 = qlx.apply #qlx.action<pauli_rotation>(%1521#0, %cst_1039) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1527 = qlx.apply #qlx.action<h>(%1526) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1040 = arith.constant 1.5707963267948966 : f64
    %1528:2 = qlx.apply #qlx.action<pauli_rotation>(%1525, %1527, %cst_1040) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1041 = arith.constant 1.5707963267948966 : f64
    %1529 = qlx.apply #qlx.action<pauli_rotation>(%1500#0, %cst_1041) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1530 = qlx.apply #qlx.action<h>(%1518#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1042 = arith.constant 1.5707963267948966 : f64
    %1531:2 = qlx.apply #qlx.action<pauli_rotation>(%1529, %1530, %cst_1042) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1043 = arith.constant 1.5707963267948966 : f64
    %1532 = qlx.apply #qlx.action<pauli_rotation>(%1497#0, %cst_1043) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1044 = arith.constant 1.5707963267948966 : f64
    %1533 = qlx.apply #qlx.action<pauli_rotation>(%1531#1, %cst_1044) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1045 = arith.constant 1.5707963267948966 : f64
    %1534:2 = qlx.apply #qlx.action<pauli_rotation>(%1532, %1533, %cst_1045) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1046 = arith.constant 1.5707963267948966 : f64
    %1535 = qlx.apply #qlx.action<pauli_rotation>(%1531#0, %cst_1046) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1047 = arith.constant 1.5707963267948966 : f64
    %1536 = qlx.apply #qlx.action<pauli_rotation>(%1534#1, %cst_1047) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1537 = qlx.apply #qlx.action<h>(%1536) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1048 = arith.constant 1.5707963267948966 : f64
    %1538:2 = qlx.apply #qlx.action<pauli_rotation>(%1535, %1537, %cst_1048) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1049 = arith.constant 1.5707963267948966 : f64
    %1539 = qlx.apply #qlx.action<pauli_rotation>(%1528#0, %cst_1049) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1540 = qlx.apply #qlx.action<h>(%1539) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1050 = arith.constant 1.5707963267948966 : f64
    %1541 = qlx.apply #qlx.action<pauli_rotation>(%1540, %cst_1050) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1051 = arith.constant 1.5707963267948966 : f64
    %1542 = qlx.apply #qlx.action<pauli_rotation>(%1528#1, %cst_1051) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1052 = arith.constant 1.5707963267948966 : f64
    %1543:2 = qlx.apply #qlx.action<pauli_rotation>(%1541, %1542, %cst_1052) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1053 = arith.constant 1.5707963267948966 : f64
    %1544 = qlx.apply #qlx.action<pauli_rotation>(%1524#0, %cst_1053) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1054 = arith.constant 1.5707963267948966 : f64
    %1545 = qlx.apply #qlx.action<pauli_rotation>(%1524#1, %cst_1054) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1055 = arith.constant 1.5707963267948966 : f64
    %1546:2 = qlx.apply #qlx.action<pauli_rotation>(%1544, %1545, %cst_1055) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1056 = arith.constant 1.5707963267948966 : f64
    %1547 = qlx.apply #qlx.action<pauli_rotation>(%1543#1, %cst_1056) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1548 = qlx.apply #qlx.action<h>(%1547) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1057 = arith.constant 1.5707963267948966 : f64
    %1549 = qlx.apply #qlx.action<pauli_rotation>(%1546#1, %cst_1057) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1058 = arith.constant 1.5707963267948966 : f64
    %1550:2 = qlx.apply #qlx.action<pauli_rotation>(%1548, %1549, %cst_1058) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1059 = arith.constant 1.5707963267948966 : f64
    %1551 = qlx.apply #qlx.action<pauli_rotation>(%1235#0, %cst_1059) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1060 = arith.constant 1.5707963267948966 : f64
    %1552 = qlx.apply #qlx.action<pauli_rotation>(%1550#1, %cst_1060) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1061 = arith.constant 1.5707963267948966 : f64
    %1553:2 = qlx.apply #qlx.action<pauli_rotation>(%1551, %1552, %cst_1061) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1062 = arith.constant 1.5707963267948966 : f64
    %1554 = qlx.apply #qlx.action<pauli_rotation>(%1553#1, %cst_1062) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1555 = qlx.apply #qlx.action<h>(%1554) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1063 = arith.constant 1.5707963267948966 : f64
    %1556 = qlx.apply #qlx.action<pauli_rotation>(%1538#1, %cst_1063) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1557 = qlx.apply #qlx.action<h>(%1556) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1064 = arith.constant 1.250000e-01 : f64
    %1558:2 = qlx.apply #qlx.action<pauli_rotation>(%1555, %1557, %cst_1064) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1065 = arith.constant 1.5707963267948966 : f64
    %1559 = qlx.apply #qlx.action<pauli_rotation>(%1553#0, %cst_1065) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1560 = qlx.apply #qlx.action<h>(%1558#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1066 = arith.constant 1.5707963267948966 : f64
    %1561:2 = qlx.apply #qlx.action<pauli_rotation>(%1559, %1560, %cst_1066) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1067 = arith.constant 1.5707963267948966 : f64
    %1562 = qlx.apply #qlx.action<pauli_rotation>(%1550#0, %cst_1067) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1068 = arith.constant 1.5707963267948966 : f64
    %1563 = qlx.apply #qlx.action<pauli_rotation>(%1561#1, %cst_1068) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1069 = arith.constant 1.5707963267948966 : f64
    %1564:2 = qlx.apply #qlx.action<pauli_rotation>(%1562, %1563, %cst_1069) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1070 = arith.constant 1.5707963267948966 : f64
    %1565 = qlx.apply #qlx.action<pauli_rotation>(%1546#0, %cst_1070) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1071 = arith.constant 1.5707963267948966 : f64
    %1566 = qlx.apply #qlx.action<pauli_rotation>(%1564#1, %cst_1071) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1072 = arith.constant 1.5707963267948966 : f64
    %1567:2 = qlx.apply #qlx.action<pauli_rotation>(%1565, %1566, %cst_1072) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1073 = arith.constant 1.5707963267948966 : f64
    %1568 = qlx.apply #qlx.action<pauli_rotation>(%1543#0, %cst_1073) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1074 = arith.constant 1.5707963267948966 : f64
    %1569 = qlx.apply #qlx.action<pauli_rotation>(%1564#0, %cst_1074) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1570 = qlx.apply #qlx.action<h>(%1569) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1075 = arith.constant 1.5707963267948966 : f64
    %1571:2 = qlx.apply #qlx.action<pauli_rotation>(%1568, %1570, %cst_1075) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1076 = arith.constant 1.5707963267948966 : f64
    %1572 = qlx.apply #qlx.action<pauli_rotation>(%1538#0, %cst_1076) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1573 = qlx.apply #qlx.action<h>(%1558#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1077 = arith.constant 1.5707963267948966 : f64
    %1574:2 = qlx.apply #qlx.action<pauli_rotation>(%1572, %1573, %cst_1077) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1078 = arith.constant 1.5707963267948966 : f64
    %1575 = qlx.apply #qlx.action<pauli_rotation>(%1574#0, %cst_1078) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1079 = arith.constant 3.1415926535897931 : f64
    %1576 = qlx.apply #qlx.action<pauli_rotation>(%1574#1, %cst_1079) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1080 = arith.constant 1.5707963267948966 : f64
    %1577:2 = qlx.apply #qlx.action<pauli_rotation>(%1575, %1576, %cst_1080) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1081 = arith.constant 1.5707963267948966 : f64
    %1578 = qlx.apply #qlx.action<pauli_rotation>(%1571#0, %cst_1081) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1082 = arith.constant 1.5707963267948966 : f64
    %1579 = qlx.apply #qlx.action<pauli_rotation>(%1571#1, %cst_1082) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1083 = arith.constant 1.5707963267948966 : f64
    %1580:2 = qlx.apply #qlx.action<pauli_rotation>(%1578, %1579, %cst_1083) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1084 = arith.constant 1.5707963267948966 : f64
    %1581 = qlx.apply #qlx.action<pauli_rotation>(%1567#0, %cst_1084) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1085 = arith.constant 1.5707963267948966 : f64
    %1582 = qlx.apply #qlx.action<pauli_rotation>(%1567#1, %cst_1085) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1086 = arith.constant 1.5707963267948966 : f64
    %1583:2 = qlx.apply #qlx.action<pauli_rotation>(%1581, %1582, %cst_1086) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1087 = arith.constant 1.5707963267948966 : f64
    %1584 = qlx.apply #qlx.action<pauli_rotation>(%1580#1, %cst_1087) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1585 = qlx.apply #qlx.action<h>(%1584) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1088 = arith.constant 1.5707963267948966 : f64
    %1586 = qlx.apply #qlx.action<pauli_rotation>(%1583#1, %cst_1088) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1089 = arith.constant 1.5707963267948966 : f64
    %1587:2 = qlx.apply #qlx.action<pauli_rotation>(%1585, %1586, %cst_1089) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1090 = arith.constant 1.5707963267948966 : f64
    %1588 = qlx.apply #qlx.action<pauli_rotation>(%1561#0, %cst_1090) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1589 = qlx.apply #qlx.action<h>(%1588) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1091 = arith.constant 1.5707963267948966 : f64
    %1590 = qlx.apply #qlx.action<pauli_rotation>(%1589, %cst_1091) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1591 = qlx.apply #qlx.action<h>(%1590) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1092 = arith.constant 1.5707963267948966 : f64
    %1592 = qlx.apply #qlx.action<pauli_rotation>(%1587#1, %cst_1092) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1093 = arith.constant 1.5707963267948966 : f64
    %1593:2 = qlx.apply #qlx.action<pauli_rotation>(%1591, %1592, %cst_1093) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1094 = arith.constant 1.5707963267948966 : f64
    %1594 = qlx.apply #qlx.action<pauli_rotation>(%1593#1, %cst_1094) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1595 = qlx.apply #qlx.action<h>(%1594) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1095 = arith.constant 1.5707963267948966 : f64
    %1596 = qlx.apply #qlx.action<pauli_rotation>(%1577#1, %cst_1095) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1597 = qlx.apply #qlx.action<h>(%1596) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1096 = arith.constant 1.250000e-01 : f64
    %1598:2 = qlx.apply #qlx.action<pauli_rotation>(%1595, %1597, %cst_1096) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1097 = arith.constant 1.5707963267948966 : f64
    %1599 = qlx.apply #qlx.action<pauli_rotation>(%1593#0, %cst_1097) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1600 = qlx.apply #qlx.action<h>(%1598#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1098 = arith.constant 1.5707963267948966 : f64
    %1601:2 = qlx.apply #qlx.action<pauli_rotation>(%1599, %1600, %cst_1098) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1099 = arith.constant 1.5707963267948966 : f64
    %1602 = qlx.apply #qlx.action<pauli_rotation>(%1587#0, %cst_1099) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1100 = arith.constant 1.5707963267948966 : f64
    %1603 = qlx.apply #qlx.action<pauli_rotation>(%1601#1, %cst_1100) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1101 = arith.constant 1.5707963267948966 : f64
    %1604:2 = qlx.apply #qlx.action<pauli_rotation>(%1602, %1603, %cst_1101) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1102 = arith.constant 1.5707963267948966 : f64
    %1605 = qlx.apply #qlx.action<pauli_rotation>(%1583#0, %cst_1102) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1103 = arith.constant 1.5707963267948966 : f64
    %1606 = qlx.apply #qlx.action<pauli_rotation>(%1604#1, %cst_1103) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1104 = arith.constant 1.5707963267948966 : f64
    %1607:2 = qlx.apply #qlx.action<pauli_rotation>(%1605, %1606, %cst_1104) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1105 = arith.constant 1.5707963267948966 : f64
    %1608 = qlx.apply #qlx.action<pauli_rotation>(%1580#0, %cst_1105) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1106 = arith.constant 1.5707963267948966 : f64
    %1609 = qlx.apply #qlx.action<pauli_rotation>(%1604#0, %cst_1106) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1610 = qlx.apply #qlx.action<h>(%1609) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1107 = arith.constant 1.5707963267948966 : f64
    %1611:2 = qlx.apply #qlx.action<pauli_rotation>(%1608, %1610, %cst_1107) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1108 = arith.constant 1.5707963267948966 : f64
    %1612 = qlx.apply #qlx.action<pauli_rotation>(%1577#0, %cst_1108) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1613 = qlx.apply #qlx.action<h>(%1598#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1109 = arith.constant 1.5707963267948966 : f64
    %1614:2 = qlx.apply #qlx.action<pauli_rotation>(%1612, %1613, %cst_1109) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1110 = arith.constant 1.5707963267948966 : f64
    %1615 = qlx.apply #qlx.action<pauli_rotation>(%1607#1, %cst_1110) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1111 = arith.constant 1.5707963267948966 : f64
    %1616 = qlx.apply #qlx.action<pauli_rotation>(%1607#0, %cst_1111) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1617 = qlx.apply #qlx.action<h>(%1616) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1112 = arith.constant 1.5707963267948966 : f64
    %1618:2 = qlx.apply #qlx.action<pauli_rotation>(%1615, %1617, %cst_1112) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1113 = arith.constant 1.5707963267948966 : f64
    %1619 = qlx.apply #qlx.action<pauli_rotation>(%1618#1, %cst_1113) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1620 = qlx.apply #qlx.action<h>(%1619) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1114 = arith.constant 1.5707963267948966 : f64
    %1621 = qlx.apply #qlx.action<pauli_rotation>(%1614#0, %cst_1114) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1622 = qlx.apply #qlx.action<h>(%1621) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1115 = arith.constant 1.250000e-01 : f64
    %1623:2 = qlx.apply #qlx.action<pauli_rotation>(%1620, %1622, %cst_1115) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1116 = arith.constant 1.5707963267948966 : f64
    %1624 = qlx.apply #qlx.action<pauli_rotation>(%1618#0, %cst_1116) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1625 = qlx.apply #qlx.action<h>(%1623#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1117 = arith.constant 1.5707963267948966 : f64
    %1626:2 = qlx.apply #qlx.action<pauli_rotation>(%1624, %1625, %cst_1117) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1118 = arith.constant 1.5707963267948966 : f64
    %1627 = qlx.apply #qlx.action<pauli_rotation>(%1626#0, %cst_1118) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1628 = qlx.apply #qlx.action<h>(%1627) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1119 = arith.constant 1.5707963267948966 : f64
    %1629 = qlx.apply #qlx.action<pauli_rotation>(%1628, %cst_1119) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1630 = qlx.apply #qlx.action<h>(%1629) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1120 = arith.constant 1.5707963267948966 : f64
    %1631 = qlx.apply #qlx.action<pauli_rotation>(%1626#1, %cst_1120) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1121 = arith.constant 1.5707963267948966 : f64
    %1632:2 = qlx.apply #qlx.action<pauli_rotation>(%1630, %1631, %cst_1121) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1122 = arith.constant 1.5707963267948966 : f64
    %1633 = qlx.apply #qlx.action<pauli_rotation>(%1632#1, %cst_1122) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1634 = qlx.apply #qlx.action<h>(%1633) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1635 = qlx.apply #qlx.action<h>(%1623#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1123 = arith.constant 1.5707963267948966 : f64
    %1636 = qlx.apply #qlx.action<pauli_rotation>(%1635, %cst_1123) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1637 = qlx.apply #qlx.action<h>(%1636) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1124 = arith.constant 1.250000e-01 : f64
    %1638:2 = qlx.apply #qlx.action<pauli_rotation>(%1634, %1637, %cst_1124) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1125 = arith.constant 1.5707963267948966 : f64
    %1639 = qlx.apply #qlx.action<pauli_rotation>(%1632#0, %cst_1125) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1640 = qlx.apply #qlx.action<h>(%1638#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1126 = arith.constant 1.5707963267948966 : f64
    %1641:2 = qlx.apply #qlx.action<pauli_rotation>(%1639, %1640, %cst_1126) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1127 = arith.constant 1.5707963267948966 : f64
    %1642 = qlx.apply #qlx.action<pauli_rotation>(%1611#1, %cst_1127) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1128 = arith.constant 1.5707963267948966 : f64
    %1643 = qlx.apply #qlx.action<pauli_rotation>(%1641#0, %cst_1128) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1644 = qlx.apply #qlx.action<h>(%1643) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1129 = arith.constant 1.5707963267948966 : f64
    %1645 = qlx.apply #qlx.action<pauli_rotation>(%1644, %cst_1129) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1646 = qlx.apply #qlx.action<h>(%1645) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1130 = arith.constant 1.5707963267948966 : f64
    %1647:2 = qlx.apply #qlx.action<pauli_rotation>(%1642, %1646, %cst_1130) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1131 = arith.constant 1.5707963267948966 : f64
    %1648 = qlx.apply #qlx.action<pauli_rotation>(%1647#1, %cst_1131) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1649 = qlx.apply #qlx.action<h>(%1648) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1132 = arith.constant 1.5707963267948966 : f64
    %1650 = qlx.apply #qlx.action<pauli_rotation>(%1641#1, %cst_1132) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1133 = arith.constant 1.250000e-01 : f64
    %1651:2 = qlx.apply #qlx.action<pauli_rotation>(%1649, %1650, %cst_1133) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1134 = arith.constant 1.5707963267948966 : f64
    %1652 = qlx.apply #qlx.action<pauli_rotation>(%1647#0, %cst_1134) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1653 = qlx.apply #qlx.action<h>(%1651#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1135 = arith.constant 1.5707963267948966 : f64
    %1654:2 = qlx.apply #qlx.action<pauli_rotation>(%1652, %1653, %cst_1135) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1136 = arith.constant 1.5707963267948966 : f64
    %1655 = qlx.apply #qlx.action<pauli_rotation>(%1654#0, %cst_1136) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1656 = qlx.apply #qlx.action<h>(%1655) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1137 = arith.constant 1.5707963267948966 : f64
    %1657 = qlx.apply #qlx.action<pauli_rotation>(%1656, %cst_1137) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1658 = qlx.apply #qlx.action<h>(%1657) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1138 = arith.constant 1.5707963267948966 : f64
    %1659 = qlx.apply #qlx.action<pauli_rotation>(%1654#1, %cst_1138) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1139 = arith.constant 1.5707963267948966 : f64
    %1660:2 = qlx.apply #qlx.action<pauli_rotation>(%1658, %1659, %cst_1139) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1140 = arith.constant 1.5707963267948966 : f64
    %1661 = qlx.apply #qlx.action<pauli_rotation>(%1660#1, %cst_1140) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1662 = qlx.apply #qlx.action<h>(%1661) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1663 = qlx.apply #qlx.action<h>(%1651#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1141 = arith.constant 1.5707963267948966 : f64
    %1664 = qlx.apply #qlx.action<pauli_rotation>(%1663, %cst_1141) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1665 = qlx.apply #qlx.action<h>(%1664) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1142 = arith.constant 1.250000e-01 : f64
    %1666:2 = qlx.apply #qlx.action<pauli_rotation>(%1662, %1665, %cst_1142) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1143 = arith.constant 1.5707963267948966 : f64
    %1667 = qlx.apply #qlx.action<pauli_rotation>(%1660#0, %cst_1143) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1668 = qlx.apply #qlx.action<h>(%1666#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1144 = arith.constant 1.5707963267948966 : f64
    %1669:2 = qlx.apply #qlx.action<pauli_rotation>(%1667, %1668, %cst_1144) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1145 = arith.constant 1.5707963267948966 : f64
    %1670 = qlx.apply #qlx.action<pauli_rotation>(%1611#0, %cst_1145) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1671 = qlx.apply #qlx.action<h>(%1670) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1146 = arith.constant 1.5707963267948966 : f64
    %1672 = qlx.apply #qlx.action<pauli_rotation>(%1669#0, %cst_1146) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1673 = qlx.apply #qlx.action<h>(%1672) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1147 = arith.constant 1.5707963267948966 : f64
    %1674 = qlx.apply #qlx.action<pauli_rotation>(%1673, %cst_1147) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1675 = qlx.apply #qlx.action<h>(%1674) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1148 = arith.constant 1.5707963267948966 : f64
    %1676:2 = qlx.apply #qlx.action<pauli_rotation>(%1671, %1675, %cst_1148) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1149 = arith.constant 1.5707963267948966 : f64
    %1677 = qlx.apply #qlx.action<pauli_rotation>(%1676#1, %cst_1149) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1678 = qlx.apply #qlx.action<h>(%1677) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1150 = arith.constant 1.5707963267948966 : f64
    %1679 = qlx.apply #qlx.action<pauli_rotation>(%1669#1, %cst_1150) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1151 = arith.constant 1.250000e-01 : f64
    %1680:2 = qlx.apply #qlx.action<pauli_rotation>(%1678, %1679, %cst_1151) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1152 = arith.constant 1.5707963267948966 : f64
    %1681 = qlx.apply #qlx.action<pauli_rotation>(%1676#0, %cst_1152) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1682 = qlx.apply #qlx.action<h>(%1680#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1153 = arith.constant 1.5707963267948966 : f64
    %1683:2 = qlx.apply #qlx.action<pauli_rotation>(%1681, %1682, %cst_1153) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1154 = arith.constant 1.5707963267948966 : f64
    %1684 = qlx.apply #qlx.action<pauli_rotation>(%1683#0, %cst_1154) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1685 = qlx.apply #qlx.action<h>(%1684) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1155 = arith.constant 1.5707963267948966 : f64
    %1686 = qlx.apply #qlx.action<pauli_rotation>(%1685, %cst_1155) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1687 = qlx.apply #qlx.action<h>(%1686) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1156 = arith.constant 1.5707963267948966 : f64
    %1688 = qlx.apply #qlx.action<pauli_rotation>(%1683#1, %cst_1156) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1157 = arith.constant 1.5707963267948966 : f64
    %1689:2 = qlx.apply #qlx.action<pauli_rotation>(%1687, %1688, %cst_1157) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1158 = arith.constant 1.5707963267948966 : f64
    %1690 = qlx.apply #qlx.action<pauli_rotation>(%1689#1, %cst_1158) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1691 = qlx.apply #qlx.action<h>(%1690) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1692 = qlx.apply #qlx.action<h>(%1680#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1159 = arith.constant 1.5707963267948966 : f64
    %1693 = qlx.apply #qlx.action<pauli_rotation>(%1692, %cst_1159) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1694 = qlx.apply #qlx.action<h>(%1693) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1160 = arith.constant 1.250000e-01 : f64
    %1695:2 = qlx.apply #qlx.action<pauli_rotation>(%1691, %1694, %cst_1160) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1161 = arith.constant 1.5707963267948966 : f64
    %1696 = qlx.apply #qlx.action<pauli_rotation>(%1689#0, %cst_1161) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1697 = qlx.apply #qlx.action<h>(%1695#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1162 = arith.constant 1.5707963267948966 : f64
    %1698:2 = qlx.apply #qlx.action<pauli_rotation>(%1696, %1697, %cst_1162) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1163 = arith.constant 1.5707963267948966 : f64
    %1699 = qlx.apply #qlx.action<pauli_rotation>(%1601#0, %cst_1163) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1700 = qlx.apply #qlx.action<h>(%1699) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1164 = arith.constant 1.5707963267948966 : f64
    %1701 = qlx.apply #qlx.action<pauli_rotation>(%1700, %cst_1164) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1702 = qlx.apply #qlx.action<h>(%1701) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1165 = arith.constant 1.5707963267948966 : f64
    %1703 = qlx.apply #qlx.action<pauli_rotation>(%1698#0, %cst_1165) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1704 = qlx.apply #qlx.action<h>(%1703) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1166 = arith.constant 1.5707963267948966 : f64
    %1705 = qlx.apply #qlx.action<pauli_rotation>(%1704, %cst_1166) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1706 = qlx.apply #qlx.action<h>(%1705) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1167 = arith.constant 1.5707963267948966 : f64
    %1707:2 = qlx.apply #qlx.action<pauli_rotation>(%1702, %1706, %cst_1167) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1168 = arith.constant 1.5707963267948966 : f64
    %1708 = qlx.apply #qlx.action<pauli_rotation>(%1707#1, %cst_1168) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1709 = qlx.apply #qlx.action<h>(%1708) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1169 = arith.constant 1.5707963267948966 : f64
    %1710 = qlx.apply #qlx.action<pauli_rotation>(%1698#1, %cst_1169) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1170 = arith.constant 1.250000e-01 : f64
    %1711:2 = qlx.apply #qlx.action<pauli_rotation>(%1709, %1710, %cst_1170) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1171 = arith.constant 1.5707963267948966 : f64
    %1712 = qlx.apply #qlx.action<pauli_rotation>(%1707#0, %cst_1171) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1713 = qlx.apply #qlx.action<h>(%1711#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1172 = arith.constant 1.5707963267948966 : f64
    %1714:2 = qlx.apply #qlx.action<pauli_rotation>(%1712, %1713, %cst_1172) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1173 = arith.constant 1.5707963267948966 : f64
    %1715 = qlx.apply #qlx.action<pauli_rotation>(%1714#0, %cst_1173) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1716 = qlx.apply #qlx.action<h>(%1715) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1174 = arith.constant 1.5707963267948966 : f64
    %1717 = qlx.apply #qlx.action<pauli_rotation>(%1716, %cst_1174) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1718 = qlx.apply #qlx.action<h>(%1717) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1175 = arith.constant 1.5707963267948966 : f64
    %1719 = qlx.apply #qlx.action<pauli_rotation>(%1714#1, %cst_1175) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1176 = arith.constant 1.5707963267948966 : f64
    %1720:2 = qlx.apply #qlx.action<pauli_rotation>(%1718, %1719, %cst_1176) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1177 = arith.constant 1.5707963267948966 : f64
    %1721 = qlx.apply #qlx.action<pauli_rotation>(%1720#1, %cst_1177) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1722 = qlx.apply #qlx.action<h>(%1721) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1723 = qlx.apply #qlx.action<h>(%1711#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1178 = arith.constant 1.5707963267948966 : f64
    %1724 = qlx.apply #qlx.action<pauli_rotation>(%1723, %cst_1178) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1725 = qlx.apply #qlx.action<h>(%1724) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1179 = arith.constant 1.250000e-01 : f64
    %1726:2 = qlx.apply #qlx.action<pauli_rotation>(%1722, %1725, %cst_1179) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1180 = arith.constant 1.5707963267948966 : f64
    %1727 = qlx.apply #qlx.action<pauli_rotation>(%1720#0, %cst_1180) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1728 = qlx.apply #qlx.action<h>(%1726#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1181 = arith.constant 1.5707963267948966 : f64
    %1729:2 = qlx.apply #qlx.action<pauli_rotation>(%1727, %1728, %cst_1181) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1730 = qlx.apply #qlx.action<h>(%1638#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1182 = arith.constant 1.5707963267948966 : f64
    %1731 = qlx.apply #qlx.action<pauli_rotation>(%1730, %cst_1182) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1732 = qlx.apply #qlx.action<h>(%1666#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1183 = arith.constant 1.5707963267948966 : f64
    %1733 = qlx.apply #qlx.action<pauli_rotation>(%1732, %cst_1183) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1184 = arith.constant 2.500000e-01 : f64
    %1734:2 = qlx.apply #qlx.action<pauli_rotation>(%1731, %1733, %cst_1184) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1735 = qlx.apply #qlx.action<h>(%1695#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1185 = arith.constant 1.5707963267948966 : f64
    %1736 = qlx.apply #qlx.action<pauli_rotation>(%1735, %cst_1185) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1737 = qlx.apply #qlx.action<h>(%1726#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1186 = arith.constant 1.5707963267948966 : f64
    %1738 = qlx.apply #qlx.action<pauli_rotation>(%1737, %cst_1186) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1187 = arith.constant 2.500000e-01 : f64
    %1739:2 = qlx.apply #qlx.action<pauli_rotation>(%1736, %1738, %cst_1187) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1188 = arith.constant 1.5707963267948966 : f64
    %1740 = qlx.apply #qlx.action<pauli_rotation>(%1729#1, %cst_1188) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1741 = qlx.apply #qlx.action<h>(%1740) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1189 = arith.constant 1.5707963267948966 : f64
    %1742 = qlx.apply #qlx.action<pauli_rotation>(%1729#0, %cst_1189) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1743 = qlx.apply #qlx.action<h>(%1742) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1190 = arith.constant 1.5707963267948966 : f64
    %1744 = qlx.apply #qlx.action<pauli_rotation>(%1743, %cst_1190) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1191 = arith.constant 5.000000e-01 : f64
    %1745:2 = qlx.apply #qlx.action<pauli_rotation>(%1741, %1744, %cst_1191) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1192 = arith.constant 2.500000e-01 : f64
    %1746:2 = qlx.apply #qlx.action<pauli_rotation>(%1739#0, %1739#1, %cst_1192) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1193 = arith.constant 2.500000e-01 : f64
    %1747:2 = qlx.apply #qlx.action<pauli_rotation>(%1734#0, %1734#1, %cst_1193) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1194 = arith.constant 1.5707963267948966 : f64
    %1748 = qlx.apply #qlx.action<pauli_rotation>(%1745#1, %cst_1194) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1749 = qlx.apply #qlx.action<h>(%1748) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1750 = qlx.apply #qlx.action<h>(%1745#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1195 = arith.constant 1.5707963267948966 : f64
    %1751:2 = qlx.apply #qlx.action<pauli_rotation>(%1749, %1750, %cst_1195) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1196 = arith.constant 1.5707963267948966 : f64
    %1752 = qlx.apply #qlx.action<pauli_rotation>(%1751#1, %cst_1196) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1753 = qlx.apply #qlx.action<h>(%1752) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1197 = arith.constant 1.5707963267948966 : f64
    %1754 = qlx.apply #qlx.action<pauli_rotation>(%1746#1, %cst_1197) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1755 = qlx.apply #qlx.action<h>(%1754) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1198 = arith.constant 1.250000e-01 : f64
    %1756:2 = qlx.apply #qlx.action<pauli_rotation>(%1753, %1755, %cst_1198) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1199 = arith.constant 1.5707963267948966 : f64
    %1757 = qlx.apply #qlx.action<pauli_rotation>(%1751#0, %cst_1199) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1758 = qlx.apply #qlx.action<h>(%1756#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1200 = arith.constant 1.5707963267948966 : f64
    %1759:2 = qlx.apply #qlx.action<pauli_rotation>(%1757, %1758, %cst_1200) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1201 = arith.constant 1.5707963267948966 : f64
    %1760 = qlx.apply #qlx.action<pauli_rotation>(%1759#0, %cst_1201) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1761 = qlx.apply #qlx.action<h>(%1760) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1202 = arith.constant 1.5707963267948966 : f64
    %1762 = qlx.apply #qlx.action<pauli_rotation>(%1761, %cst_1202) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1763 = qlx.apply #qlx.action<h>(%1762) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1203 = arith.constant 1.5707963267948966 : f64
    %1764 = qlx.apply #qlx.action<pauli_rotation>(%1759#1, %cst_1203) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1204 = arith.constant 1.5707963267948966 : f64
    %1765:2 = qlx.apply #qlx.action<pauli_rotation>(%1763, %1764, %cst_1204) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1205 = arith.constant 1.5707963267948966 : f64
    %1766 = qlx.apply #qlx.action<pauli_rotation>(%1765#1, %cst_1205) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1767 = qlx.apply #qlx.action<h>(%1766) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1768 = qlx.apply #qlx.action<h>(%1756#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1206 = arith.constant 1.5707963267948966 : f64
    %1769 = qlx.apply #qlx.action<pauli_rotation>(%1768, %cst_1206) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1770 = qlx.apply #qlx.action<h>(%1769) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1207 = arith.constant 1.250000e-01 : f64
    %1771:2 = qlx.apply #qlx.action<pauli_rotation>(%1767, %1770, %cst_1207) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1208 = arith.constant 1.5707963267948966 : f64
    %1772 = qlx.apply #qlx.action<pauli_rotation>(%1765#0, %cst_1208) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1773 = qlx.apply #qlx.action<h>(%1771#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1209 = arith.constant 1.5707963267948966 : f64
    %1774:2 = qlx.apply #qlx.action<pauli_rotation>(%1772, %1773, %cst_1209) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1210 = arith.constant 1.5707963267948966 : f64
    %1775 = qlx.apply #qlx.action<pauli_rotation>(%1774#1, %cst_1210) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1776 = qlx.apply #qlx.action<h>(%1775) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1211 = arith.constant 1.5707963267948966 : f64
    %1777 = qlx.apply #qlx.action<pauli_rotation>(%1776, %cst_1211) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1778 = qlx.apply #qlx.action<h>(%1777) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1212 = arith.constant 1.5707963267948966 : f64
    %1779:2 = qlx.apply #qlx.action<pauli_rotation>(%1771#1, %1778, %cst_1212) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1213 = arith.constant 1.5707963267948966 : f64
    %1780 = qlx.apply #qlx.action<pauli_rotation>(%1779#0, %cst_1213) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1781 = qlx.apply #qlx.action<h>(%1780) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1214 = arith.constant 1.5707963267948966 : f64
    %1782 = qlx.apply #qlx.action<pauli_rotation>(%1746#0, %cst_1214) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1783 = qlx.apply #qlx.action<h>(%1782) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1215 = arith.constant 1.250000e-01 : f64
    %1784:2 = qlx.apply #qlx.action<pauli_rotation>(%1781, %1783, %cst_1215) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1216 = arith.constant 1.5707963267948966 : f64
    %1785 = qlx.apply #qlx.action<pauli_rotation>(%1779#1, %cst_1216) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1786 = qlx.apply #qlx.action<h>(%1784#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1217 = arith.constant 1.5707963267948966 : f64
    %1787:2 = qlx.apply #qlx.action<pauli_rotation>(%1785, %1786, %cst_1217) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1218 = arith.constant 1.5707963267948966 : f64
    %1788 = qlx.apply #qlx.action<pauli_rotation>(%1787#0, %cst_1218) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1789 = qlx.apply #qlx.action<h>(%1788) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1219 = arith.constant 1.5707963267948966 : f64
    %1790 = qlx.apply #qlx.action<pauli_rotation>(%1789, %cst_1219) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1791 = qlx.apply #qlx.action<h>(%1790) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1220 = arith.constant 1.5707963267948966 : f64
    %1792 = qlx.apply #qlx.action<pauli_rotation>(%1787#1, %cst_1220) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1221 = arith.constant 1.5707963267948966 : f64
    %1793:2 = qlx.apply #qlx.action<pauli_rotation>(%1791, %1792, %cst_1221) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1222 = arith.constant 1.5707963267948966 : f64
    %1794 = qlx.apply #qlx.action<pauli_rotation>(%1793#1, %cst_1222) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1795 = qlx.apply #qlx.action<h>(%1794) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1796 = qlx.apply #qlx.action<h>(%1784#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1223 = arith.constant 1.5707963267948966 : f64
    %1797 = qlx.apply #qlx.action<pauli_rotation>(%1796, %cst_1223) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1798 = qlx.apply #qlx.action<h>(%1797) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1224 = arith.constant 1.250000e-01 : f64
    %1799:2 = qlx.apply #qlx.action<pauli_rotation>(%1795, %1798, %cst_1224) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1225 = arith.constant 1.5707963267948966 : f64
    %1800 = qlx.apply #qlx.action<pauli_rotation>(%1793#0, %cst_1225) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1801 = qlx.apply #qlx.action<h>(%1799#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1226 = arith.constant 1.5707963267948966 : f64
    %1802:2 = qlx.apply #qlx.action<pauli_rotation>(%1800, %1801, %cst_1226) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1227 = arith.constant 1.5707963267948966 : f64
    %1803 = qlx.apply #qlx.action<pauli_rotation>(%1802#1, %cst_1227) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1804 = qlx.apply #qlx.action<h>(%1803) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1228 = arith.constant 1.5707963267948966 : f64
    %1805 = qlx.apply #qlx.action<pauli_rotation>(%1804, %cst_1228) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1806 = qlx.apply #qlx.action<h>(%1805) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1229 = arith.constant 1.5707963267948966 : f64
    %1807:2 = qlx.apply #qlx.action<pauli_rotation>(%1799#1, %1806, %cst_1229) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1230 = arith.constant 1.5707963267948966 : f64
    %1808 = qlx.apply #qlx.action<pauli_rotation>(%1807#0, %cst_1230) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1809 = qlx.apply #qlx.action<h>(%1808) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1231 = arith.constant 1.5707963267948966 : f64
    %1810 = qlx.apply #qlx.action<pauli_rotation>(%1747#1, %cst_1231) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1811 = qlx.apply #qlx.action<h>(%1810) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1232 = arith.constant 1.250000e-01 : f64
    %1812:2 = qlx.apply #qlx.action<pauli_rotation>(%1809, %1811, %cst_1232) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1233 = arith.constant 1.5707963267948966 : f64
    %1813 = qlx.apply #qlx.action<pauli_rotation>(%1807#1, %cst_1233) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1814 = qlx.apply #qlx.action<h>(%1812#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1234 = arith.constant 1.5707963267948966 : f64
    %1815:2 = qlx.apply #qlx.action<pauli_rotation>(%1813, %1814, %cst_1234) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1235 = arith.constant 1.5707963267948966 : f64
    %1816 = qlx.apply #qlx.action<pauli_rotation>(%1815#0, %cst_1235) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1817 = qlx.apply #qlx.action<h>(%1816) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1236 = arith.constant 1.5707963267948966 : f64
    %1818 = qlx.apply #qlx.action<pauli_rotation>(%1817, %cst_1236) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1819 = qlx.apply #qlx.action<h>(%1818) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1237 = arith.constant 1.5707963267948966 : f64
    %1820 = qlx.apply #qlx.action<pauli_rotation>(%1815#1, %cst_1237) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1238 = arith.constant 1.5707963267948966 : f64
    %1821:2 = qlx.apply #qlx.action<pauli_rotation>(%1819, %1820, %cst_1238) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1239 = arith.constant 1.5707963267948966 : f64
    %1822 = qlx.apply #qlx.action<pauli_rotation>(%1821#1, %cst_1239) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1823 = qlx.apply #qlx.action<h>(%1822) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1824 = qlx.apply #qlx.action<h>(%1812#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1240 = arith.constant 1.5707963267948966 : f64
    %1825 = qlx.apply #qlx.action<pauli_rotation>(%1824, %cst_1240) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1826 = qlx.apply #qlx.action<h>(%1825) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1241 = arith.constant 1.250000e-01 : f64
    %1827:2 = qlx.apply #qlx.action<pauli_rotation>(%1823, %1826, %cst_1241) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1242 = arith.constant 1.5707963267948966 : f64
    %1828 = qlx.apply #qlx.action<pauli_rotation>(%1821#0, %cst_1242) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1829 = qlx.apply #qlx.action<h>(%1827#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1243 = arith.constant 1.5707963267948966 : f64
    %1830:2 = qlx.apply #qlx.action<pauli_rotation>(%1828, %1829, %cst_1243) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1244 = arith.constant 1.5707963267948966 : f64
    %1831 = qlx.apply #qlx.action<pauli_rotation>(%1830#1, %cst_1244) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1832 = qlx.apply #qlx.action<h>(%1831) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1245 = arith.constant 1.5707963267948966 : f64
    %1833 = qlx.apply #qlx.action<pauli_rotation>(%1832, %cst_1245) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1834 = qlx.apply #qlx.action<h>(%1833) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1246 = arith.constant 1.5707963267948966 : f64
    %1835:2 = qlx.apply #qlx.action<pauli_rotation>(%1827#1, %1834, %cst_1246) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1247 = arith.constant 1.5707963267948966 : f64
    %1836 = qlx.apply #qlx.action<pauli_rotation>(%1835#0, %cst_1247) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1837 = qlx.apply #qlx.action<h>(%1836) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1248 = arith.constant 1.5707963267948966 : f64
    %1838 = qlx.apply #qlx.action<pauli_rotation>(%1747#0, %cst_1248) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1839 = qlx.apply #qlx.action<h>(%1838) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1249 = arith.constant 1.250000e-01 : f64
    %1840:2 = qlx.apply #qlx.action<pauli_rotation>(%1837, %1839, %cst_1249) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1250 = arith.constant 1.5707963267948966 : f64
    %1841 = qlx.apply #qlx.action<pauli_rotation>(%1835#1, %cst_1250) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1842 = qlx.apply #qlx.action<h>(%1840#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1251 = arith.constant 1.5707963267948966 : f64
    %1843:2 = qlx.apply #qlx.action<pauli_rotation>(%1841, %1842, %cst_1251) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1252 = arith.constant 1.5707963267948966 : f64
    %1844 = qlx.apply #qlx.action<pauli_rotation>(%1843#0, %cst_1252) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1845 = qlx.apply #qlx.action<h>(%1844) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1253 = arith.constant 1.5707963267948966 : f64
    %1846 = qlx.apply #qlx.action<pauli_rotation>(%1845, %cst_1253) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1847 = qlx.apply #qlx.action<h>(%1846) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1254 = arith.constant 1.5707963267948966 : f64
    %1848 = qlx.apply #qlx.action<pauli_rotation>(%1843#1, %cst_1254) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1255 = arith.constant 1.5707963267948966 : f64
    %1849:2 = qlx.apply #qlx.action<pauli_rotation>(%1847, %1848, %cst_1255) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1256 = arith.constant 1.5707963267948966 : f64
    %1850 = qlx.apply #qlx.action<pauli_rotation>(%1849#1, %cst_1256) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1851 = qlx.apply #qlx.action<h>(%1850) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %1852 = qlx.apply #qlx.action<h>(%1840#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1257 = arith.constant 1.5707963267948966 : f64
    %1853 = qlx.apply #qlx.action<pauli_rotation>(%1852, %cst_1257) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1854 = qlx.apply #qlx.action<h>(%1853) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1258 = arith.constant 1.250000e-01 : f64
    %1855:2 = qlx.apply #qlx.action<pauli_rotation>(%1851, %1854, %cst_1258) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1259 = arith.constant 1.5707963267948966 : f64
    %1856 = qlx.apply #qlx.action<pauli_rotation>(%1849#0, %cst_1259) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1857 = qlx.apply #qlx.action<h>(%1855#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1260 = arith.constant 1.5707963267948966 : f64
    %1858:2 = qlx.apply #qlx.action<pauli_rotation>(%1856, %1857, %cst_1260) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %1859 = qlx.apply #qlx.action<h>(%1855#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1261 = arith.constant 1.5707963267948966 : f64
    %1860 = qlx.apply #qlx.action<pauli_rotation>(%1614#1, %cst_1261) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1262 = arith.constant 1.5707963267948966 : f64
    %1861:2 = qlx.apply #qlx.action<pauli_rotation>(%1859, %1860, %cst_1262) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1263 = arith.constant 1.5707963267948966 : f64
    %1862 = qlx.apply #qlx.action<pauli_rotation>(%1802#0, %cst_1263) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1863 = qlx.apply #qlx.action<h>(%1862) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1264 = arith.constant 1.5707963267948966 : f64
    %1864 = qlx.apply #qlx.action<pauli_rotation>(%1830#0, %cst_1264) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1265 = arith.constant 1.5707963267948966 : f64
    %1865:2 = qlx.apply #qlx.action<pauli_rotation>(%1863, %1864, %cst_1265) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1266 = arith.constant 1.5707963267948966 : f64
    %1866 = qlx.apply #qlx.action<pauli_rotation>(%1858#1, %cst_1266) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1867 = qlx.apply #qlx.action<h>(%1866) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1267 = arith.constant 1.5707963267948966 : f64
    %1868 = qlx.apply #qlx.action<pauli_rotation>(%1858#0, %cst_1267) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1268 = arith.constant 1.5707963267948966 : f64
    %1869:2 = qlx.apply #qlx.action<pauli_rotation>(%1867, %1868, %cst_1268) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1269 = arith.constant 1.5707963267948966 : f64
    %1870 = qlx.apply #qlx.action<pauli_rotation>(%1865#1, %cst_1269) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1871 = qlx.apply #qlx.action<h>(%1870) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1270 = arith.constant 1.5707963267948966 : f64
    %1872 = qlx.apply #qlx.action<pauli_rotation>(%1869#1, %cst_1270) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1271 = arith.constant 1.5707963267948966 : f64
    %1873:2 = qlx.apply #qlx.action<pauli_rotation>(%1871, %1872, %cst_1271) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1272 = arith.constant 1.5707963267948966 : f64
    %1874 = qlx.apply #qlx.action<pauli_rotation>(%1774#0, %cst_1272) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1875 = qlx.apply #qlx.action<h>(%1874) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1273 = arith.constant 1.5707963267948966 : f64
    %1876 = qlx.apply #qlx.action<pauli_rotation>(%1875, %cst_1273) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1877 = qlx.apply #qlx.action<h>(%1876) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1274 = arith.constant 1.5707963267948966 : f64
    %1878 = qlx.apply #qlx.action<pauli_rotation>(%1873#1, %cst_1274) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1275 = arith.constant 1.5707963267948966 : f64
    %1879:2 = qlx.apply #qlx.action<pauli_rotation>(%1877, %1878, %cst_1275) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1276 = arith.constant 1.5707963267948966 : f64
    %1880 = qlx.apply #qlx.action<pauli_rotation>(%1879#1, %cst_1276) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1881 = qlx.apply #qlx.action<h>(%1880) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1277 = arith.constant 1.5707963267948966 : f64
    %1882 = qlx.apply #qlx.action<pauli_rotation>(%1861#1, %cst_1277) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1883 = qlx.apply #qlx.action<h>(%1882) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1278 = arith.constant 1.250000e-01 : f64
    %1884:2 = qlx.apply #qlx.action<pauli_rotation>(%1881, %1883, %cst_1278) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1279 = arith.constant 1.5707963267948966 : f64
    %1885 = qlx.apply #qlx.action<pauli_rotation>(%1879#0, %cst_1279) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1886 = qlx.apply #qlx.action<h>(%1884#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1280 = arith.constant 1.5707963267948966 : f64
    %1887:2 = qlx.apply #qlx.action<pauli_rotation>(%1885, %1886, %cst_1280) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1281 = arith.constant 1.5707963267948966 : f64
    %1888 = qlx.apply #qlx.action<pauli_rotation>(%1873#0, %cst_1281) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1282 = arith.constant 1.5707963267948966 : f64
    %1889 = qlx.apply #qlx.action<pauli_rotation>(%1887#1, %cst_1282) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1283 = arith.constant 1.5707963267948966 : f64
    %1890:2 = qlx.apply #qlx.action<pauli_rotation>(%1888, %1889, %cst_1283) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1284 = arith.constant 1.5707963267948966 : f64
    %1891 = qlx.apply #qlx.action<pauli_rotation>(%1869#0, %cst_1284) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1285 = arith.constant 1.5707963267948966 : f64
    %1892 = qlx.apply #qlx.action<pauli_rotation>(%1890#1, %cst_1285) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1286 = arith.constant 1.5707963267948966 : f64
    %1893:2 = qlx.apply #qlx.action<pauli_rotation>(%1891, %1892, %cst_1286) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1287 = arith.constant 1.5707963267948966 : f64
    %1894 = qlx.apply #qlx.action<pauli_rotation>(%1865#0, %cst_1287) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1288 = arith.constant 1.5707963267948966 : f64
    %1895 = qlx.apply #qlx.action<pauli_rotation>(%1890#0, %cst_1288) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1896 = qlx.apply #qlx.action<h>(%1895) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1289 = arith.constant 1.5707963267948966 : f64
    %1897:2 = qlx.apply #qlx.action<pauli_rotation>(%1894, %1896, %cst_1289) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1290 = arith.constant 1.5707963267948966 : f64
    %1898 = qlx.apply #qlx.action<pauli_rotation>(%1861#0, %cst_1290) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1899 = qlx.apply #qlx.action<h>(%1884#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1291 = arith.constant 1.5707963267948966 : f64
    %1900:2 = qlx.apply #qlx.action<pauli_rotation>(%1898, %1899, %cst_1291) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1292 = arith.constant 1.5707963267948966 : f64
    %1901 = qlx.apply #qlx.action<pauli_rotation>(%1900#0, %cst_1292) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1293 = arith.constant 1.5707963267948966 : f64
    %1902:2 = qlx.apply #qlx.action<pauli_rotation>(%1900#1, %1901, %cst_1293) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1294 = arith.constant 1.5707963267948966 : f64
    %1903 = qlx.apply #qlx.action<pauli_rotation>(%1897#0, %cst_1294) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1295 = arith.constant 1.5707963267948966 : f64
    %1904 = qlx.apply #qlx.action<pauli_rotation>(%1897#1, %cst_1295) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1296 = arith.constant 1.5707963267948966 : f64
    %1905:2 = qlx.apply #qlx.action<pauli_rotation>(%1903, %1904, %cst_1296) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1297 = arith.constant 1.5707963267948966 : f64
    %1906 = qlx.apply #qlx.action<pauli_rotation>(%1893#0, %cst_1297) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1298 = arith.constant 1.5707963267948966 : f64
    %1907 = qlx.apply #qlx.action<pauli_rotation>(%1893#1, %cst_1298) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1299 = arith.constant 1.5707963267948966 : f64
    %1908:2 = qlx.apply #qlx.action<pauli_rotation>(%1906, %1907, %cst_1299) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1300 = arith.constant 1.5707963267948966 : f64
    %1909 = qlx.apply #qlx.action<pauli_rotation>(%1905#1, %cst_1300) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1910 = qlx.apply #qlx.action<h>(%1909) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1301 = arith.constant 1.5707963267948966 : f64
    %1911 = qlx.apply #qlx.action<pauli_rotation>(%1908#1, %cst_1301) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1302 = arith.constant 1.5707963267948966 : f64
    %1912:2 = qlx.apply #qlx.action<pauli_rotation>(%1910, %1911, %cst_1302) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1303 = arith.constant 1.5707963267948966 : f64
    %1913 = qlx.apply #qlx.action<pauli_rotation>(%1887#0, %cst_1303) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1914 = qlx.apply #qlx.action<h>(%1913) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1304 = arith.constant 1.5707963267948966 : f64
    %1915 = qlx.apply #qlx.action<pauli_rotation>(%1914, %cst_1304) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1916 = qlx.apply #qlx.action<h>(%1915) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1305 = arith.constant 1.5707963267948966 : f64
    %1917 = qlx.apply #qlx.action<pauli_rotation>(%1912#1, %cst_1305) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1306 = arith.constant 1.5707963267948966 : f64
    %1918:2 = qlx.apply #qlx.action<pauli_rotation>(%1916, %1917, %cst_1306) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1307 = arith.constant 1.5707963267948966 : f64
    %1919 = qlx.apply #qlx.action<pauli_rotation>(%1918#1, %cst_1307) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1920 = qlx.apply #qlx.action<h>(%1919) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1308 = arith.constant 1.5707963267948966 : f64
    %1921 = qlx.apply #qlx.action<pauli_rotation>(%1902#0, %cst_1308) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1922 = qlx.apply #qlx.action<h>(%1921) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1309 = arith.constant 1.250000e-01 : f64
    %1923:2 = qlx.apply #qlx.action<pauli_rotation>(%1920, %1922, %cst_1309) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1310 = arith.constant 1.5707963267948966 : f64
    %1924 = qlx.apply #qlx.action<pauli_rotation>(%1918#0, %cst_1310) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1925 = qlx.apply #qlx.action<h>(%1923#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1311 = arith.constant 1.5707963267948966 : f64
    %1926:2 = qlx.apply #qlx.action<pauli_rotation>(%1924, %1925, %cst_1311) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1312 = arith.constant 1.5707963267948966 : f64
    %1927 = qlx.apply #qlx.action<pauli_rotation>(%1912#0, %cst_1312) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1313 = arith.constant 1.5707963267948966 : f64
    %1928 = qlx.apply #qlx.action<pauli_rotation>(%1926#1, %cst_1313) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1314 = arith.constant 1.5707963267948966 : f64
    %1929:2 = qlx.apply #qlx.action<pauli_rotation>(%1927, %1928, %cst_1314) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1315 = arith.constant 1.5707963267948966 : f64
    %1930 = qlx.apply #qlx.action<pauli_rotation>(%1908#0, %cst_1315) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1316 = arith.constant 1.5707963267948966 : f64
    %1931 = qlx.apply #qlx.action<pauli_rotation>(%1929#1, %cst_1316) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1317 = arith.constant 1.5707963267948966 : f64
    %1932:2 = qlx.apply #qlx.action<pauli_rotation>(%1930, %1931, %cst_1317) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1318 = arith.constant 1.5707963267948966 : f64
    %1933 = qlx.apply #qlx.action<pauli_rotation>(%1905#0, %cst_1318) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1319 = arith.constant 1.5707963267948966 : f64
    %1934 = qlx.apply #qlx.action<pauli_rotation>(%1929#0, %cst_1319) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1935 = qlx.apply #qlx.action<h>(%1934) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1320 = arith.constant 1.5707963267948966 : f64
    %1936:2 = qlx.apply #qlx.action<pauli_rotation>(%1933, %1935, %cst_1320) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1321 = arith.constant 1.5707963267948966 : f64
    %1937 = qlx.apply #qlx.action<pauli_rotation>(%1902#1, %cst_1321) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1938 = qlx.apply #qlx.action<h>(%1923#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1322 = arith.constant 1.5707963267948966 : f64
    %1939:2 = qlx.apply #qlx.action<pauli_rotation>(%1937, %1938, %cst_1322) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1323 = arith.constant 1.5707963267948966 : f64
    %1940 = qlx.apply #qlx.action<pauli_rotation>(%1534#0, %cst_1323) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1324 = arith.constant 1.5707963267948966 : f64
    %1941 = qlx.apply #qlx.action<pauli_rotation>(%1939#1, %cst_1324) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1942 = qlx.apply #qlx.action<h>(%1941) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1325 = arith.constant 1.5707963267948966 : f64
    %1943:2 = qlx.apply #qlx.action<pauli_rotation>(%1940, %1942, %cst_1325) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1326 = arith.constant 1.5707963267948966 : f64
    %1944 = qlx.apply #qlx.action<pauli_rotation>(%1939#0, %cst_1326) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1327 = arith.constant 1.5707963267948966 : f64
    %1945 = qlx.apply #qlx.action<pauli_rotation>(%1943#1, %cst_1327) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1328 = arith.constant 1.5707963267948966 : f64
    %1946:2 = qlx.apply #qlx.action<pauli_rotation>(%1944, %1945, %cst_1328) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1329 = arith.constant 3.1415926535897931 : f64
    %1947 = qlx.apply #qlx.action<pauli_rotation>(%1936#0, %cst_1329) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1948 = qlx.apply #qlx.action<h>(%1947) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1330 = arith.constant 1.5707963267948966 : f64
    %1949 = qlx.apply #qlx.action<pauli_rotation>(%1936#1, %cst_1330) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1331 = arith.constant 1.5707963267948966 : f64
    %1950:2 = qlx.apply #qlx.action<pauli_rotation>(%1948, %1949, %cst_1331) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1332 = arith.constant 1.5707963267948966 : f64
    %1951 = qlx.apply #qlx.action<pauli_rotation>(%1932#0, %cst_1332) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1333 = arith.constant 1.5707963267948966 : f64
    %1952 = qlx.apply #qlx.action<pauli_rotation>(%1932#1, %cst_1333) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1334 = arith.constant 1.5707963267948966 : f64
    %1953:2 = qlx.apply #qlx.action<pauli_rotation>(%1951, %1952, %cst_1334) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1335 = arith.constant 1.5707963267948966 : f64
    %1954 = qlx.apply #qlx.action<pauli_rotation>(%1950#1, %cst_1335) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1955 = qlx.apply #qlx.action<h>(%1954) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1336 = arith.constant 1.5707963267948966 : f64
    %1956 = qlx.apply #qlx.action<pauli_rotation>(%1953#1, %cst_1336) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1337 = arith.constant 1.5707963267948966 : f64
    %1957:2 = qlx.apply #qlx.action<pauli_rotation>(%1955, %1956, %cst_1337) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1338 = arith.constant 1.5707963267948966 : f64
    %1958 = qlx.apply #qlx.action<pauli_rotation>(%1957#1, %cst_1338) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1959 = qlx.apply #qlx.action<h>(%1958) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1339 = arith.constant 1.5707963267948966 : f64
    %1960 = qlx.apply #qlx.action<pauli_rotation>(%1946#1, %cst_1339) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1961 = qlx.apply #qlx.action<h>(%1960) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1340 = arith.constant 1.250000e-01 : f64
    %1962:2 = qlx.apply #qlx.action<pauli_rotation>(%1959, %1961, %cst_1340) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1341 = arith.constant 1.5707963267948966 : f64
    %1963 = qlx.apply #qlx.action<pauli_rotation>(%1957#0, %cst_1341) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1964 = qlx.apply #qlx.action<h>(%1962#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1342 = arith.constant 1.5707963267948966 : f64
    %1965:2 = qlx.apply #qlx.action<pauli_rotation>(%1963, %1964, %cst_1342) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1343 = arith.constant 1.5707963267948966 : f64
    %1966 = qlx.apply #qlx.action<pauli_rotation>(%1953#0, %cst_1343) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1344 = arith.constant 1.5707963267948966 : f64
    %1967 = qlx.apply #qlx.action<pauli_rotation>(%1965#1, %cst_1344) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1345 = arith.constant 1.5707963267948966 : f64
    %1968:2 = qlx.apply #qlx.action<pauli_rotation>(%1966, %1967, %cst_1345) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1346 = arith.constant 1.5707963267948966 : f64
    %1969 = qlx.apply #qlx.action<pauli_rotation>(%1950#0, %cst_1346) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1347 = arith.constant 1.5707963267948966 : f64
    %1970 = qlx.apply #qlx.action<pauli_rotation>(%1965#0, %cst_1347) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1971 = qlx.apply #qlx.action<h>(%1970) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1348 = arith.constant 1.5707963267948966 : f64
    %1972:2 = qlx.apply #qlx.action<pauli_rotation>(%1969, %1971, %cst_1348) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1349 = arith.constant 1.5707963267948966 : f64
    %1973 = qlx.apply #qlx.action<pauli_rotation>(%1946#0, %cst_1349) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1974 = qlx.apply #qlx.action<h>(%1962#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1350 = arith.constant 1.5707963267948966 : f64
    %1975:2 = qlx.apply #qlx.action<pauli_rotation>(%1973, %1974, %cst_1350) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1351 = arith.constant 1.5707963267948966 : f64
    %1976 = qlx.apply #qlx.action<pauli_rotation>(%1943#0, %cst_1351) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1352 = arith.constant 1.5707963267948966 : f64
    %1977 = qlx.apply #qlx.action<pauli_rotation>(%1975#1, %cst_1352) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1353 = arith.constant 1.5707963267948966 : f64
    %1978:2 = qlx.apply #qlx.action<pauli_rotation>(%1976, %1977, %cst_1353) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1354 = arith.constant 1.5707963267948966 : f64
    %1979 = qlx.apply #qlx.action<pauli_rotation>(%1978#0, %cst_1354) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1980 = qlx.apply #qlx.action<h>(%1979) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1355 = arith.constant 1.5707963267948966 : f64
    %1981 = qlx.apply #qlx.action<pauli_rotation>(%1980, %cst_1355) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1982 = qlx.apply #qlx.action<h>(%1981) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1356 = arith.constant 1.5707963267948966 : f64
    %1983 = qlx.apply #qlx.action<pauli_rotation>(%1978#1, %cst_1356) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1357 = arith.constant 1.5707963267948966 : f64
    %1984:2 = qlx.apply #qlx.action<pauli_rotation>(%1982, %1983, %cst_1357) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1358 = arith.constant 1.5707963267948966 : f64
    %1985 = qlx.apply #qlx.action<pauli_rotation>(%1975#0, %cst_1358) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1359 = arith.constant 1.5707963267948966 : f64
    %1986 = qlx.apply #qlx.action<pauli_rotation>(%1984#1, %cst_1359) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1360 = arith.constant 1.5707963267948966 : f64
    %1987:2 = qlx.apply #qlx.action<pauli_rotation>(%1985, %1986, %cst_1360) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1361 = arith.constant 1.5707963267948966 : f64
    %1988 = qlx.apply #qlx.action<pauli_rotation>(%1972#0, %cst_1361) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1989 = qlx.apply #qlx.action<h>(%1988) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1362 = arith.constant 1.5707963267948966 : f64
    %1990 = qlx.apply #qlx.action<pauli_rotation>(%1989, %cst_1362) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1991 = qlx.apply #qlx.action<h>(%1990) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1363 = arith.constant 1.5707963267948966 : f64
    %1992 = qlx.apply #qlx.action<pauli_rotation>(%1972#1, %cst_1363) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1364 = arith.constant 1.5707963267948966 : f64
    %1993:2 = qlx.apply #qlx.action<pauli_rotation>(%1991, %1992, %cst_1364) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1365 = arith.constant 1.5707963267948966 : f64
    %1994 = qlx.apply #qlx.action<pauli_rotation>(%1968#0, %cst_1365) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1366 = arith.constant 1.5707963267948966 : f64
    %1995 = qlx.apply #qlx.action<pauli_rotation>(%1968#1, %cst_1366) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1367 = arith.constant 1.5707963267948966 : f64
    %1996:2 = qlx.apply #qlx.action<pauli_rotation>(%1994, %1995, %cst_1367) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1368 = arith.constant 1.5707963267948966 : f64
    %1997 = qlx.apply #qlx.action<pauli_rotation>(%1993#1, %cst_1368) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %1998 = qlx.apply #qlx.action<h>(%1997) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1369 = arith.constant 1.5707963267948966 : f64
    %1999 = qlx.apply #qlx.action<pauli_rotation>(%1996#1, %cst_1369) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1370 = arith.constant 1.5707963267948966 : f64
    %2000:2 = qlx.apply #qlx.action<pauli_rotation>(%1998, %1999, %cst_1370) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1371 = arith.constant 1.5707963267948966 : f64
    %2001 = qlx.apply #qlx.action<pauli_rotation>(%2000#1, %cst_1371) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2002 = qlx.apply #qlx.action<h>(%2001) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1372 = arith.constant 1.5707963267948966 : f64
    %2003 = qlx.apply #qlx.action<pauli_rotation>(%1987#1, %cst_1372) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2004 = qlx.apply #qlx.action<h>(%2003) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1373 = arith.constant 1.250000e-01 : f64
    %2005:2 = qlx.apply #qlx.action<pauli_rotation>(%2002, %2004, %cst_1373) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1374 = arith.constant 1.5707963267948966 : f64
    %2006 = qlx.apply #qlx.action<pauli_rotation>(%2000#0, %cst_1374) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2007 = qlx.apply #qlx.action<h>(%2005#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1375 = arith.constant 1.5707963267948966 : f64
    %2008:2 = qlx.apply #qlx.action<pauli_rotation>(%2006, %2007, %cst_1375) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1376 = arith.constant 1.5707963267948966 : f64
    %2009 = qlx.apply #qlx.action<pauli_rotation>(%1996#0, %cst_1376) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1377 = arith.constant 1.5707963267948966 : f64
    %2010 = qlx.apply #qlx.action<pauli_rotation>(%2008#1, %cst_1377) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1378 = arith.constant 1.5707963267948966 : f64
    %2011:2 = qlx.apply #qlx.action<pauli_rotation>(%2009, %2010, %cst_1378) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1379 = arith.constant 1.5707963267948966 : f64
    %2012 = qlx.apply #qlx.action<pauli_rotation>(%1993#0, %cst_1379) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1380 = arith.constant 1.5707963267948966 : f64
    %2013 = qlx.apply #qlx.action<pauli_rotation>(%2008#0, %cst_1380) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2014 = qlx.apply #qlx.action<h>(%2013) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1381 = arith.constant 1.5707963267948966 : f64
    %2015:2 = qlx.apply #qlx.action<pauli_rotation>(%2012, %2014, %cst_1381) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1382 = arith.constant 1.5707963267948966 : f64
    %2016 = qlx.apply #qlx.action<pauli_rotation>(%1987#0, %cst_1382) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2017 = qlx.apply #qlx.action<h>(%2005#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1383 = arith.constant 1.5707963267948966 : f64
    %2018:2 = qlx.apply #qlx.action<pauli_rotation>(%2016, %2017, %cst_1383) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1384 = arith.constant 1.5707963267948966 : f64
    %2019 = qlx.apply #qlx.action<pauli_rotation>(%1984#0, %cst_1384) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1385 = arith.constant 1.5707963267948966 : f64
    %2020 = qlx.apply #qlx.action<pauli_rotation>(%2018#1, %cst_1385) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1386 = arith.constant 1.5707963267948966 : f64
    %2021:2 = qlx.apply #qlx.action<pauli_rotation>(%2019, %2020, %cst_1386) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1387 = arith.constant 3.1415926535897931 : f64
    %2022 = qlx.apply #qlx.action<pauli_rotation>(%2011#0, %cst_1387) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2023 = qlx.apply #qlx.action<h>(%2022) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1388 = arith.constant 1.5707963267948966 : f64
    %2024 = qlx.apply #qlx.action<pauli_rotation>(%2018#0, %cst_1388) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2025 = qlx.apply #qlx.action<h>(%2024) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1389 = arith.constant 1.5707963267948966 : f64
    %2026:2 = qlx.apply #qlx.action<pauli_rotation>(%2023, %2025, %cst_1389) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1390 = arith.constant 1.5707963267948966 : f64
    %2027 = qlx.apply #qlx.action<pauli_rotation>(%2026#1, %cst_1390) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2028 = qlx.apply #qlx.action<h>(%2027) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1391 = arith.constant 1.5707963267948966 : f64
    %2029 = qlx.apply #qlx.action<pauli_rotation>(%2021#1, %cst_1391) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2030 = qlx.apply #qlx.action<h>(%2029) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1392 = arith.constant 1.5707963267948966 : f64
    %2031 = qlx.apply #qlx.action<pauli_rotation>(%2030, %cst_1392) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2032 = qlx.apply #qlx.action<h>(%2031) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1393 = arith.constant 1.250000e-01 : f64
    %2033:2 = qlx.apply #qlx.action<pauli_rotation>(%2028, %2032, %cst_1393) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1394 = arith.constant 1.5707963267948966 : f64
    %2034 = qlx.apply #qlx.action<pauli_rotation>(%2026#0, %cst_1394) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2035 = qlx.apply #qlx.action<h>(%2033#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1395 = arith.constant 1.5707963267948966 : f64
    %2036:2 = qlx.apply #qlx.action<pauli_rotation>(%2034, %2035, %cst_1395) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1396 = arith.constant 1.5707963267948966 : f64
    %2037 = qlx.apply #qlx.action<pauli_rotation>(%2036#0, %cst_1396) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2038 = qlx.apply #qlx.action<h>(%2037) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1397 = arith.constant 1.5707963267948966 : f64
    %2039 = qlx.apply #qlx.action<pauli_rotation>(%2038, %cst_1397) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2040 = qlx.apply #qlx.action<h>(%2039) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1398 = arith.constant 1.5707963267948966 : f64
    %2041 = qlx.apply #qlx.action<pauli_rotation>(%2036#1, %cst_1398) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1399 = arith.constant 1.5707963267948966 : f64
    %2042:2 = qlx.apply #qlx.action<pauli_rotation>(%2040, %2041, %cst_1399) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1400 = arith.constant 1.5707963267948966 : f64
    %2043 = qlx.apply #qlx.action<pauli_rotation>(%2042#1, %cst_1400) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2044 = qlx.apply #qlx.action<h>(%2043) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2045 = qlx.apply #qlx.action<h>(%2033#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1401 = arith.constant 1.5707963267948966 : f64
    %2046 = qlx.apply #qlx.action<pauli_rotation>(%2045, %cst_1401) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2047 = qlx.apply #qlx.action<h>(%2046) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1402 = arith.constant 1.250000e-01 : f64
    %2048:2 = qlx.apply #qlx.action<pauli_rotation>(%2044, %2047, %cst_1402) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1403 = arith.constant 1.5707963267948966 : f64
    %2049 = qlx.apply #qlx.action<pauli_rotation>(%2042#0, %cst_1403) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2050 = qlx.apply #qlx.action<h>(%2048#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1404 = arith.constant 1.5707963267948966 : f64
    %2051:2 = qlx.apply #qlx.action<pauli_rotation>(%2049, %2050, %cst_1404) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1405 = arith.constant 1.5707963267948966 : f64
    %2052 = qlx.apply #qlx.action<pauli_rotation>(%2051#1, %cst_1405) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2053 = qlx.apply #qlx.action<h>(%2052) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1406 = arith.constant 1.5707963267948966 : f64
    %2054 = qlx.apply #qlx.action<pauli_rotation>(%2053, %cst_1406) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2055 = qlx.apply #qlx.action<h>(%2054) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1407 = arith.constant 1.5707963267948966 : f64
    %2056:2 = qlx.apply #qlx.action<pauli_rotation>(%2048#1, %2055, %cst_1407) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1408 = arith.constant 1.5707963267948966 : f64
    %2057 = qlx.apply #qlx.action<pauli_rotation>(%2056#0, %cst_1408) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2058 = qlx.apply #qlx.action<h>(%2057) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1409 = arith.constant 1.5707963267948966 : f64
    %2059 = qlx.apply #qlx.action<pauli_rotation>(%2021#0, %cst_1409) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2060 = qlx.apply #qlx.action<h>(%2059) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1410 = arith.constant 1.5707963267948966 : f64
    %2061 = qlx.apply #qlx.action<pauli_rotation>(%2060, %cst_1410) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2062 = qlx.apply #qlx.action<h>(%2061) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1411 = arith.constant 1.250000e-01 : f64
    %2063:2 = qlx.apply #qlx.action<pauli_rotation>(%2058, %2062, %cst_1411) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1412 = arith.constant 1.5707963267948966 : f64
    %2064 = qlx.apply #qlx.action<pauli_rotation>(%2056#1, %cst_1412) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2065 = qlx.apply #qlx.action<h>(%2063#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1413 = arith.constant 1.5707963267948966 : f64
    %2066:2 = qlx.apply #qlx.action<pauli_rotation>(%2064, %2065, %cst_1413) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1414 = arith.constant 1.5707963267948966 : f64
    %2067 = qlx.apply #qlx.action<pauli_rotation>(%2066#0, %cst_1414) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2068 = qlx.apply #qlx.action<h>(%2067) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1415 = arith.constant 1.5707963267948966 : f64
    %2069 = qlx.apply #qlx.action<pauli_rotation>(%2068, %cst_1415) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2070 = qlx.apply #qlx.action<h>(%2069) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1416 = arith.constant 1.5707963267948966 : f64
    %2071 = qlx.apply #qlx.action<pauli_rotation>(%2066#1, %cst_1416) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1417 = arith.constant 1.5707963267948966 : f64
    %2072:2 = qlx.apply #qlx.action<pauli_rotation>(%2070, %2071, %cst_1417) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1418 = arith.constant 1.5707963267948966 : f64
    %2073 = qlx.apply #qlx.action<pauli_rotation>(%2072#1, %cst_1418) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2074 = qlx.apply #qlx.action<h>(%2073) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2075 = qlx.apply #qlx.action<h>(%2063#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1419 = arith.constant 1.5707963267948966 : f64
    %2076 = qlx.apply #qlx.action<pauli_rotation>(%2075, %cst_1419) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2077 = qlx.apply #qlx.action<h>(%2076) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1420 = arith.constant 1.250000e-01 : f64
    %2078:2 = qlx.apply #qlx.action<pauli_rotation>(%2074, %2077, %cst_1420) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1421 = arith.constant 1.5707963267948966 : f64
    %2079 = qlx.apply #qlx.action<pauli_rotation>(%2072#0, %cst_1421) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2080 = qlx.apply #qlx.action<h>(%2078#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1422 = arith.constant 1.5707963267948966 : f64
    %2081:2 = qlx.apply #qlx.action<pauli_rotation>(%2079, %2080, %cst_1422) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2082 = qlx.apply #qlx.action<h>(%2078#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1423 = arith.constant 1.5707963267948966 : f64
    %2083 = qlx.apply #qlx.action<pauli_rotation>(%2081#1, %cst_1423) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2084 = qlx.apply #qlx.action<h>(%2083) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1424 = arith.constant 5.000000e-01 : f64
    %2085:2 = qlx.apply #qlx.action<pauli_rotation>(%2082, %2084, %cst_1424) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1425 = arith.constant 1.5707963267948966 : f64
    %2086 = qlx.apply #qlx.action<pauli_rotation>(%2081#0, %cst_1425) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2087 = qlx.apply #qlx.action<h>(%2085#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1426 = arith.constant 1.5707963267948966 : f64
    %2088:2 = qlx.apply #qlx.action<pauli_rotation>(%2086, %2087, %cst_1426) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1427 = arith.constant 1.5707963267948966 : f64
    %2089 = qlx.apply #qlx.action<pauli_rotation>(%2088#1, %cst_1427) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2090 = qlx.apply #qlx.action<h>(%2089) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2091 = qlx.apply #qlx.action<h>(%2085#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1428 = arith.constant 1.250000e-01 : f64
    %2092:2 = qlx.apply #qlx.action<pauli_rotation>(%2090, %2091, %cst_1428) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1429 = arith.constant 1.5707963267948966 : f64
    %2093 = qlx.apply #qlx.action<pauli_rotation>(%2088#0, %cst_1429) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2094 = qlx.apply #qlx.action<h>(%2092#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1430 = arith.constant 1.5707963267948966 : f64
    %2095:2 = qlx.apply #qlx.action<pauli_rotation>(%2093, %2094, %cst_1430) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1431 = arith.constant 1.5707963267948966 : f64
    %2096 = qlx.apply #qlx.action<pauli_rotation>(%2095#0, %cst_1431) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2097 = qlx.apply #qlx.action<h>(%2096) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1432 = arith.constant 1.5707963267948966 : f64
    %2098 = qlx.apply #qlx.action<pauli_rotation>(%2097, %cst_1432) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2099 = qlx.apply #qlx.action<h>(%2098) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1433 = arith.constant 1.5707963267948966 : f64
    %2100 = qlx.apply #qlx.action<pauli_rotation>(%2095#1, %cst_1433) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1434 = arith.constant 1.5707963267948966 : f64
    %2101:2 = qlx.apply #qlx.action<pauli_rotation>(%2099, %2100, %cst_1434) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1435 = arith.constant 1.5707963267948966 : f64
    %2102 = qlx.apply #qlx.action<pauli_rotation>(%2101#1, %cst_1435) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2103 = qlx.apply #qlx.action<h>(%2102) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2104 = qlx.apply #qlx.action<h>(%2092#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1436 = arith.constant 1.5707963267948966 : f64
    %2105 = qlx.apply #qlx.action<pauli_rotation>(%2104, %cst_1436) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2106 = qlx.apply #qlx.action<h>(%2105) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1437 = arith.constant 1.250000e-01 : f64
    %2107:2 = qlx.apply #qlx.action<pauli_rotation>(%2103, %2106, %cst_1437) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1438 = arith.constant 1.5707963267948966 : f64
    %2108 = qlx.apply #qlx.action<pauli_rotation>(%2101#0, %cst_1438) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2109 = qlx.apply #qlx.action<h>(%2107#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1439 = arith.constant 1.5707963267948966 : f64
    %2110:2 = qlx.apply #qlx.action<pauli_rotation>(%2108, %2109, %cst_1439) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1440 = arith.constant 1.5707963267948966 : f64
    %2111 = qlx.apply #qlx.action<pauli_rotation>(%2051#0, %cst_1440) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1441 = arith.constant 1.5707963267948966 : f64
    %2112 = qlx.apply #qlx.action<pauli_rotation>(%2110#0, %cst_1441) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2113 = qlx.apply #qlx.action<h>(%2112) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1442 = arith.constant 1.5707963267948966 : f64
    %2114 = qlx.apply #qlx.action<pauli_rotation>(%2113, %cst_1442) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2115 = qlx.apply #qlx.action<h>(%2114) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1443 = arith.constant 1.5707963267948966 : f64
    %2116:2 = qlx.apply #qlx.action<pauli_rotation>(%2111, %2115, %cst_1443) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1444 = arith.constant 1.5707963267948966 : f64
    %2117 = qlx.apply #qlx.action<pauli_rotation>(%2116#1, %cst_1444) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2118 = qlx.apply #qlx.action<h>(%2117) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1445 = arith.constant 1.5707963267948966 : f64
    %2119 = qlx.apply #qlx.action<pauli_rotation>(%2110#1, %cst_1445) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1446 = arith.constant 1.250000e-01 : f64
    %2120:2 = qlx.apply #qlx.action<pauli_rotation>(%2118, %2119, %cst_1446) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1447 = arith.constant 1.5707963267948966 : f64
    %2121 = qlx.apply #qlx.action<pauli_rotation>(%2116#0, %cst_1447) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2122 = qlx.apply #qlx.action<h>(%2120#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1448 = arith.constant 1.5707963267948966 : f64
    %2123:2 = qlx.apply #qlx.action<pauli_rotation>(%2121, %2122, %cst_1448) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1449 = arith.constant 1.5707963267948966 : f64
    %2124 = qlx.apply #qlx.action<pauli_rotation>(%2123#0, %cst_1449) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2125 = qlx.apply #qlx.action<h>(%2124) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1450 = arith.constant 1.5707963267948966 : f64
    %2126 = qlx.apply #qlx.action<pauli_rotation>(%2125, %cst_1450) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2127 = qlx.apply #qlx.action<h>(%2126) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1451 = arith.constant 1.5707963267948966 : f64
    %2128 = qlx.apply #qlx.action<pauli_rotation>(%2123#1, %cst_1451) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1452 = arith.constant 1.5707963267948966 : f64
    %2129:2 = qlx.apply #qlx.action<pauli_rotation>(%2127, %2128, %cst_1452) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1453 = arith.constant 1.5707963267948966 : f64
    %2130 = qlx.apply #qlx.action<pauli_rotation>(%2129#1, %cst_1453) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2131 = qlx.apply #qlx.action<h>(%2130) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2132 = qlx.apply #qlx.action<h>(%2120#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1454 = arith.constant 1.5707963267948966 : f64
    %2133 = qlx.apply #qlx.action<pauli_rotation>(%2132, %cst_1454) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2134 = qlx.apply #qlx.action<h>(%2133) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1455 = arith.constant 1.250000e-01 : f64
    %2135:2 = qlx.apply #qlx.action<pauli_rotation>(%2131, %2134, %cst_1455) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1456 = arith.constant 1.5707963267948966 : f64
    %2136 = qlx.apply #qlx.action<pauli_rotation>(%2129#0, %cst_1456) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2137 = qlx.apply #qlx.action<h>(%2135#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1457 = arith.constant 1.5707963267948966 : f64
    %2138:2 = qlx.apply #qlx.action<pauli_rotation>(%2136, %2137, %cst_1457) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2139 = qlx.apply #qlx.action<h>(%2107#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1458 = arith.constant 1.5707963267948966 : f64
    %2140 = qlx.apply #qlx.action<pauli_rotation>(%2139, %cst_1458) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2141 = qlx.apply #qlx.action<h>(%2140) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2142 = qlx.apply #qlx.action<h>(%2135#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1459 = arith.constant 1.5707963267948966 : f64
    %2143 = qlx.apply #qlx.action<pauli_rotation>(%2142, %cst_1459) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2144 = qlx.apply #qlx.action<h>(%2143) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1460 = arith.constant 1.5707963267948966 : f64
    %2145:2 = qlx.apply #qlx.action<pauli_rotation>(%2141, %2144, %cst_1460) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1461 = arith.constant 1.5707963267948966 : f64
    %2146 = qlx.apply #qlx.action<pauli_rotation>(%2138#1, %cst_1461) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2147 = qlx.apply #qlx.action<h>(%2146) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1462 = arith.constant 1.5707963267948966 : f64
    %2148 = qlx.apply #qlx.action<pauli_rotation>(%2145#1, %cst_1462) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1463 = arith.constant 1.5707963267948966 : f64
    %2149:2 = qlx.apply #qlx.action<pauli_rotation>(%2147, %2148, %cst_1463) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1464 = arith.constant 1.5707963267948966 : f64
    %2150 = qlx.apply #qlx.action<pauli_rotation>(%2015#0, %cst_1464) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1465 = arith.constant 1.5707963267948966 : f64
    %2151 = qlx.apply #qlx.action<pauli_rotation>(%2015#1, %cst_1465) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1466 = arith.constant 1.5707963267948966 : f64
    %2152:2 = qlx.apply #qlx.action<pauli_rotation>(%2150, %2151, %cst_1466) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1467 = arith.constant 1.5707963267948966 : f64
    %2153 = qlx.apply #qlx.action<pauli_rotation>(%2138#0, %cst_1467) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2154 = qlx.apply #qlx.action<h>(%2153) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1468 = arith.constant 1.5707963267948966 : f64
    %2155 = qlx.apply #qlx.action<pauli_rotation>(%2154, %cst_1468) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1469 = arith.constant 1.5707963267948966 : f64
    %2156 = qlx.apply #qlx.action<pauli_rotation>(%2011#1, %cst_1469) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1470 = arith.constant 1.5707963267948966 : f64
    %2157:2 = qlx.apply #qlx.action<pauli_rotation>(%2155, %2156, %cst_1470) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1471 = arith.constant 1.5707963267948966 : f64
    %2158 = qlx.apply #qlx.action<pauli_rotation>(%2152#1, %cst_1471) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2159 = qlx.apply #qlx.action<h>(%2158) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1472 = arith.constant 1.5707963267948966 : f64
    %2160 = qlx.apply #qlx.action<pauli_rotation>(%2157#1, %cst_1472) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1473 = arith.constant 1.5707963267948966 : f64
    %2161:2 = qlx.apply #qlx.action<pauli_rotation>(%2159, %2160, %cst_1473) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1474 = arith.constant 1.5707963267948966 : f64
    %2162 = qlx.apply #qlx.action<pauli_rotation>(%2161#1, %cst_1474) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2163 = qlx.apply #qlx.action<h>(%2162) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1475 = arith.constant 1.5707963267948966 : f64
    %2164 = qlx.apply #qlx.action<pauli_rotation>(%2149#1, %cst_1475) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2165 = qlx.apply #qlx.action<h>(%2164) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1476 = arith.constant 1.250000e-01 : f64
    %2166:2 = qlx.apply #qlx.action<pauli_rotation>(%2163, %2165, %cst_1476) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1477 = arith.constant 1.5707963267948966 : f64
    %2167 = qlx.apply #qlx.action<pauli_rotation>(%2161#0, %cst_1477) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2168 = qlx.apply #qlx.action<h>(%2166#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1478 = arith.constant 1.5707963267948966 : f64
    %2169:2 = qlx.apply #qlx.action<pauli_rotation>(%2167, %2168, %cst_1478) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1479 = arith.constant 1.5707963267948966 : f64
    %2170 = qlx.apply #qlx.action<pauli_rotation>(%2157#0, %cst_1479) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1480 = arith.constant 1.5707963267948966 : f64
    %2171 = qlx.apply #qlx.action<pauli_rotation>(%2169#1, %cst_1480) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1481 = arith.constant 1.5707963267948966 : f64
    %2172:2 = qlx.apply #qlx.action<pauli_rotation>(%2170, %2171, %cst_1481) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1482 = arith.constant 1.5707963267948966 : f64
    %2173 = qlx.apply #qlx.action<pauli_rotation>(%2152#0, %cst_1482) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1483 = arith.constant 1.5707963267948966 : f64
    %2174 = qlx.apply #qlx.action<pauli_rotation>(%2169#0, %cst_1483) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2175 = qlx.apply #qlx.action<h>(%2174) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1484 = arith.constant 1.5707963267948966 : f64
    %2176:2 = qlx.apply #qlx.action<pauli_rotation>(%2173, %2175, %cst_1484) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1485 = arith.constant 1.5707963267948966 : f64
    %2177 = qlx.apply #qlx.action<pauli_rotation>(%2149#0, %cst_1485) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2178 = qlx.apply #qlx.action<h>(%2166#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1486 = arith.constant 1.5707963267948966 : f64
    %2179:2 = qlx.apply #qlx.action<pauli_rotation>(%2177, %2178, %cst_1486) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1487 = arith.constant 1.5707963267948966 : f64
    %2180 = qlx.apply #qlx.action<pauli_rotation>(%2145#0, %cst_1487) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1488 = arith.constant 1.5707963267948966 : f64
    %2181 = qlx.apply #qlx.action<pauli_rotation>(%2179#1, %cst_1488) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1489 = arith.constant 1.5707963267948966 : f64
    %2182:2 = qlx.apply #qlx.action<pauli_rotation>(%2180, %2181, %cst_1489) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1490 = arith.constant 1.5707963267948966 : f64
    %2183 = qlx.apply #qlx.action<pauli_rotation>(%2182#0, %cst_1490) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2184 = qlx.apply #qlx.action<h>(%2183) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1491 = arith.constant 1.5707963267948966 : f64
    %2185 = qlx.apply #qlx.action<pauli_rotation>(%2184, %cst_1491) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2186 = qlx.apply #qlx.action<h>(%2185) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1492 = arith.constant 1.5707963267948966 : f64
    %2187 = qlx.apply #qlx.action<pauli_rotation>(%2182#1, %cst_1492) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1493 = arith.constant 1.5707963267948966 : f64
    %2188:2 = qlx.apply #qlx.action<pauli_rotation>(%2186, %2187, %cst_1493) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1494 = arith.constant 1.5707963267948966 : f64
    %2189 = qlx.apply #qlx.action<pauli_rotation>(%2179#0, %cst_1494) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1495 = arith.constant 1.5707963267948966 : f64
    %2190 = qlx.apply #qlx.action<pauli_rotation>(%2188#1, %cst_1495) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1496 = arith.constant 1.5707963267948966 : f64
    %2191:2 = qlx.apply #qlx.action<pauli_rotation>(%2189, %2190, %cst_1496) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1497 = arith.constant 1.5707963267948966 : f64
    %2192 = qlx.apply #qlx.action<pauli_rotation>(%2176#0, %cst_1497) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2193 = qlx.apply #qlx.action<h>(%2192) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1498 = arith.constant 1.5707963267948966 : f64
    %2194 = qlx.apply #qlx.action<pauli_rotation>(%2193, %cst_1498) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2195 = qlx.apply #qlx.action<h>(%2194) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1499 = arith.constant 1.5707963267948966 : f64
    %2196 = qlx.apply #qlx.action<pauli_rotation>(%2176#1, %cst_1499) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1500 = arith.constant 1.5707963267948966 : f64
    %2197:2 = qlx.apply #qlx.action<pauli_rotation>(%2195, %2196, %cst_1500) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1501 = arith.constant 1.5707963267948966 : f64
    %2198 = qlx.apply #qlx.action<pauli_rotation>(%2172#0, %cst_1501) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1502 = arith.constant 1.5707963267948966 : f64
    %2199 = qlx.apply #qlx.action<pauli_rotation>(%2172#1, %cst_1502) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1503 = arith.constant 1.5707963267948966 : f64
    %2200:2 = qlx.apply #qlx.action<pauli_rotation>(%2198, %2199, %cst_1503) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1504 = arith.constant 1.5707963267948966 : f64
    %2201 = qlx.apply #qlx.action<pauli_rotation>(%2197#1, %cst_1504) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2202 = qlx.apply #qlx.action<h>(%2201) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1505 = arith.constant 1.5707963267948966 : f64
    %2203 = qlx.apply #qlx.action<pauli_rotation>(%2200#1, %cst_1505) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1506 = arith.constant 1.5707963267948966 : f64
    %2204:2 = qlx.apply #qlx.action<pauli_rotation>(%2202, %2203, %cst_1506) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1507 = arith.constant 1.5707963267948966 : f64
    %2205 = qlx.apply #qlx.action<pauli_rotation>(%2204#1, %cst_1507) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2206 = qlx.apply #qlx.action<h>(%2205) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1508 = arith.constant 1.5707963267948966 : f64
    %2207 = qlx.apply #qlx.action<pauli_rotation>(%2191#1, %cst_1508) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2208 = qlx.apply #qlx.action<h>(%2207) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1509 = arith.constant 1.250000e-01 : f64
    %2209:2 = qlx.apply #qlx.action<pauli_rotation>(%2206, %2208, %cst_1509) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1510 = arith.constant 1.5707963267948966 : f64
    %2210 = qlx.apply #qlx.action<pauli_rotation>(%2204#0, %cst_1510) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2211 = qlx.apply #qlx.action<h>(%2209#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1511 = arith.constant 1.5707963267948966 : f64
    %2212:2 = qlx.apply #qlx.action<pauli_rotation>(%2210, %2211, %cst_1511) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1512 = arith.constant 1.5707963267948966 : f64
    %2213 = qlx.apply #qlx.action<pauli_rotation>(%2200#0, %cst_1512) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1513 = arith.constant 1.5707963267948966 : f64
    %2214 = qlx.apply #qlx.action<pauli_rotation>(%2212#1, %cst_1513) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1514 = arith.constant 1.5707963267948966 : f64
    %2215:2 = qlx.apply #qlx.action<pauli_rotation>(%2213, %2214, %cst_1514) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1515 = arith.constant 1.5707963267948966 : f64
    %2216 = qlx.apply #qlx.action<pauli_rotation>(%2197#0, %cst_1515) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1516 = arith.constant 1.5707963267948966 : f64
    %2217 = qlx.apply #qlx.action<pauli_rotation>(%2212#0, %cst_1516) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2218 = qlx.apply #qlx.action<h>(%2217) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1517 = arith.constant 1.5707963267948966 : f64
    %2219:2 = qlx.apply #qlx.action<pauli_rotation>(%2216, %2218, %cst_1517) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1518 = arith.constant 1.5707963267948966 : f64
    %2220 = qlx.apply #qlx.action<pauli_rotation>(%2191#0, %cst_1518) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2221 = qlx.apply #qlx.action<h>(%2209#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1519 = arith.constant 1.5707963267948966 : f64
    %2222:2 = qlx.apply #qlx.action<pauli_rotation>(%2220, %2221, %cst_1519) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1520 = arith.constant 1.5707963267948966 : f64
    %2223 = qlx.apply #qlx.action<pauli_rotation>(%2188#0, %cst_1520) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1521 = arith.constant 1.5707963267948966 : f64
    %2224 = qlx.apply #qlx.action<pauli_rotation>(%2222#1, %cst_1521) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1522 = arith.constant 1.5707963267948966 : f64
    %2225:2 = qlx.apply #qlx.action<pauli_rotation>(%2223, %2224, %cst_1522) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1523 = arith.constant 1.5707963267948966 : f64
    %2226 = qlx.apply #qlx.action<pauli_rotation>(%2222#0, %cst_1523) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1524 = arith.constant 1.5707963267948966 : f64
    %2227 = qlx.apply #qlx.action<pauli_rotation>(%2225#1, %cst_1524) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2228 = qlx.apply #qlx.action<h>(%2227) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1525 = arith.constant 1.5707963267948966 : f64
    %2229:2 = qlx.apply #qlx.action<pauli_rotation>(%2226, %2228, %cst_1525) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1526 = arith.constant 1.5707963267948966 : f64
    %2230 = qlx.apply #qlx.action<pauli_rotation>(%2219#0, %cst_1526) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2231 = qlx.apply #qlx.action<h>(%2230) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1527 = arith.constant 1.5707963267948966 : f64
    %2232 = qlx.apply #qlx.action<pauli_rotation>(%2231, %cst_1527) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1528 = arith.constant 1.5707963267948966 : f64
    %2233 = qlx.apply #qlx.action<pauli_rotation>(%2219#1, %cst_1528) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1529 = arith.constant 1.5707963267948966 : f64
    %2234:2 = qlx.apply #qlx.action<pauli_rotation>(%2232, %2233, %cst_1529) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1530 = arith.constant 1.5707963267948966 : f64
    %2235 = qlx.apply #qlx.action<pauli_rotation>(%2215#0, %cst_1530) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1531 = arith.constant 1.5707963267948966 : f64
    %2236 = qlx.apply #qlx.action<pauli_rotation>(%2215#1, %cst_1531) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1532 = arith.constant 1.5707963267948966 : f64
    %2237:2 = qlx.apply #qlx.action<pauli_rotation>(%2235, %2236, %cst_1532) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1533 = arith.constant 1.5707963267948966 : f64
    %2238 = qlx.apply #qlx.action<pauli_rotation>(%2234#1, %cst_1533) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2239 = qlx.apply #qlx.action<h>(%2238) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1534 = arith.constant 1.5707963267948966 : f64
    %2240 = qlx.apply #qlx.action<pauli_rotation>(%2237#1, %cst_1534) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1535 = arith.constant 1.5707963267948966 : f64
    %2241:2 = qlx.apply #qlx.action<pauli_rotation>(%2239, %2240, %cst_1535) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1536 = arith.constant 1.5707963267948966 : f64
    %2242 = qlx.apply #qlx.action<pauli_rotation>(%1926#0, %cst_1536) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1537 = arith.constant 1.5707963267948966 : f64
    %2243 = qlx.apply #qlx.action<pauli_rotation>(%2241#1, %cst_1537) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1538 = arith.constant 1.5707963267948966 : f64
    %2244:2 = qlx.apply #qlx.action<pauli_rotation>(%2242, %2243, %cst_1538) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1539 = arith.constant 1.5707963267948966 : f64
    %2245 = qlx.apply #qlx.action<pauli_rotation>(%2244#1, %cst_1539) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2246 = qlx.apply #qlx.action<h>(%2245) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1540 = arith.constant 1.5707963267948966 : f64
    %2247 = qlx.apply #qlx.action<pauli_rotation>(%2229#1, %cst_1540) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2248 = qlx.apply #qlx.action<h>(%2247) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1541 = arith.constant 1.250000e-01 : f64
    %2249:2 = qlx.apply #qlx.action<pauli_rotation>(%2246, %2248, %cst_1541) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1542 = arith.constant 1.5707963267948966 : f64
    %2250 = qlx.apply #qlx.action<pauli_rotation>(%2244#0, %cst_1542) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2251 = qlx.apply #qlx.action<h>(%2249#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1543 = arith.constant 1.5707963267948966 : f64
    %2252:2 = qlx.apply #qlx.action<pauli_rotation>(%2250, %2251, %cst_1543) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1544 = arith.constant 1.5707963267948966 : f64
    %2253 = qlx.apply #qlx.action<pauli_rotation>(%2241#0, %cst_1544) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1545 = arith.constant 1.5707963267948966 : f64
    %2254 = qlx.apply #qlx.action<pauli_rotation>(%2252#1, %cst_1545) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1546 = arith.constant 1.5707963267948966 : f64
    %2255:2 = qlx.apply #qlx.action<pauli_rotation>(%2253, %2254, %cst_1546) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1547 = arith.constant 1.5707963267948966 : f64
    %2256 = qlx.apply #qlx.action<pauli_rotation>(%2237#0, %cst_1547) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1548 = arith.constant 1.5707963267948966 : f64
    %2257 = qlx.apply #qlx.action<pauli_rotation>(%2255#1, %cst_1548) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1549 = arith.constant 1.5707963267948966 : f64
    %2258:2 = qlx.apply #qlx.action<pauli_rotation>(%2256, %2257, %cst_1549) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1550 = arith.constant 1.5707963267948966 : f64
    %2259 = qlx.apply #qlx.action<pauli_rotation>(%2234#0, %cst_1550) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1551 = arith.constant 1.5707963267948966 : f64
    %2260 = qlx.apply #qlx.action<pauli_rotation>(%2255#0, %cst_1551) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2261 = qlx.apply #qlx.action<h>(%2260) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1552 = arith.constant 1.5707963267948966 : f64
    %2262:2 = qlx.apply #qlx.action<pauli_rotation>(%2259, %2261, %cst_1552) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1553 = arith.constant 1.5707963267948966 : f64
    %2263 = qlx.apply #qlx.action<pauli_rotation>(%2229#0, %cst_1553) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2264 = qlx.apply #qlx.action<h>(%2249#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1554 = arith.constant 1.5707963267948966 : f64
    %2265:2 = qlx.apply #qlx.action<pauli_rotation>(%2263, %2264, %cst_1554) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1555 = arith.constant 1.5707963267948966 : f64
    %2266 = qlx.apply #qlx.action<pauli_rotation>(%2265#0, %cst_1555) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1556 = arith.constant 3.1415926535897931 : f64
    %2267 = qlx.apply #qlx.action<pauli_rotation>(%2265#1, %cst_1556) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1557 = arith.constant 1.5707963267948966 : f64
    %2268:2 = qlx.apply #qlx.action<pauli_rotation>(%2266, %2267, %cst_1557) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1558 = arith.constant 1.5707963267948966 : f64
    %2269 = qlx.apply #qlx.action<pauli_rotation>(%2262#0, %cst_1558) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1559 = arith.constant 1.5707963267948966 : f64
    %2270 = qlx.apply #qlx.action<pauli_rotation>(%2262#1, %cst_1559) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1560 = arith.constant 1.5707963267948966 : f64
    %2271:2 = qlx.apply #qlx.action<pauli_rotation>(%2269, %2270, %cst_1560) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1561 = arith.constant 1.5707963267948966 : f64
    %2272 = qlx.apply #qlx.action<pauli_rotation>(%2258#0, %cst_1561) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1562 = arith.constant 1.5707963267948966 : f64
    %2273 = qlx.apply #qlx.action<pauli_rotation>(%2258#1, %cst_1562) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1563 = arith.constant 1.5707963267948966 : f64
    %2274:2 = qlx.apply #qlx.action<pauli_rotation>(%2272, %2273, %cst_1563) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1564 = arith.constant 1.5707963267948966 : f64
    %2275 = qlx.apply #qlx.action<pauli_rotation>(%2271#1, %cst_1564) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2276 = qlx.apply #qlx.action<h>(%2275) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1565 = arith.constant 1.5707963267948966 : f64
    %2277 = qlx.apply #qlx.action<pauli_rotation>(%2274#1, %cst_1565) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1566 = arith.constant 1.5707963267948966 : f64
    %2278:2 = qlx.apply #qlx.action<pauli_rotation>(%2276, %2277, %cst_1566) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1567 = arith.constant 1.5707963267948966 : f64
    %2279 = qlx.apply #qlx.action<pauli_rotation>(%2252#0, %cst_1567) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2280 = qlx.apply #qlx.action<h>(%2279) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1568 = arith.constant 1.5707963267948966 : f64
    %2281 = qlx.apply #qlx.action<pauli_rotation>(%2280, %cst_1568) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2282 = qlx.apply #qlx.action<h>(%2281) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1569 = arith.constant 1.5707963267948966 : f64
    %2283 = qlx.apply #qlx.action<pauli_rotation>(%2278#1, %cst_1569) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1570 = arith.constant 1.5707963267948966 : f64
    %2284:2 = qlx.apply #qlx.action<pauli_rotation>(%2282, %2283, %cst_1570) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1571 = arith.constant 1.5707963267948966 : f64
    %2285 = qlx.apply #qlx.action<pauli_rotation>(%2284#1, %cst_1571) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2286 = qlx.apply #qlx.action<h>(%2285) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1572 = arith.constant 1.5707963267948966 : f64
    %2287 = qlx.apply #qlx.action<pauli_rotation>(%2268#1, %cst_1572) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2288 = qlx.apply #qlx.action<h>(%2287) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1573 = arith.constant 1.250000e-01 : f64
    %2289:2 = qlx.apply #qlx.action<pauli_rotation>(%2286, %2288, %cst_1573) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1574 = arith.constant 1.5707963267948966 : f64
    %2290 = qlx.apply #qlx.action<pauli_rotation>(%2284#0, %cst_1574) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2291 = qlx.apply #qlx.action<h>(%2289#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1575 = arith.constant 1.5707963267948966 : f64
    %2292:2 = qlx.apply #qlx.action<pauli_rotation>(%2290, %2291, %cst_1575) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1576 = arith.constant 1.5707963267948966 : f64
    %2293 = qlx.apply #qlx.action<pauli_rotation>(%2278#0, %cst_1576) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1577 = arith.constant 1.5707963267948966 : f64
    %2294 = qlx.apply #qlx.action<pauli_rotation>(%2292#1, %cst_1577) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1578 = arith.constant 1.5707963267948966 : f64
    %2295:2 = qlx.apply #qlx.action<pauli_rotation>(%2293, %2294, %cst_1578) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1579 = arith.constant 1.5707963267948966 : f64
    %2296 = qlx.apply #qlx.action<pauli_rotation>(%2274#0, %cst_1579) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1580 = arith.constant 1.5707963267948966 : f64
    %2297 = qlx.apply #qlx.action<pauli_rotation>(%2295#1, %cst_1580) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1581 = arith.constant 1.5707963267948966 : f64
    %2298:2 = qlx.apply #qlx.action<pauli_rotation>(%2296, %2297, %cst_1581) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1582 = arith.constant 1.5707963267948966 : f64
    %2299 = qlx.apply #qlx.action<pauli_rotation>(%2271#0, %cst_1582) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1583 = arith.constant 1.5707963267948966 : f64
    %2300 = qlx.apply #qlx.action<pauli_rotation>(%2295#0, %cst_1583) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2301 = qlx.apply #qlx.action<h>(%2300) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1584 = arith.constant 1.5707963267948966 : f64
    %2302:2 = qlx.apply #qlx.action<pauli_rotation>(%2299, %2301, %cst_1584) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1585 = arith.constant 1.5707963267948966 : f64
    %2303 = qlx.apply #qlx.action<pauli_rotation>(%2268#0, %cst_1585) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2304 = qlx.apply #qlx.action<h>(%2289#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1586 = arith.constant 1.5707963267948966 : f64
    %2305:2 = qlx.apply #qlx.action<pauli_rotation>(%2303, %2304, %cst_1586) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1587 = arith.constant 1.5707963267948966 : f64
    %2306 = qlx.apply #qlx.action<pauli_rotation>(%2298#1, %cst_1587) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1588 = arith.constant 1.5707963267948966 : f64
    %2307 = qlx.apply #qlx.action<pauli_rotation>(%2298#0, %cst_1588) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2308 = qlx.apply #qlx.action<h>(%2307) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1589 = arith.constant 1.5707963267948966 : f64
    %2309:2 = qlx.apply #qlx.action<pauli_rotation>(%2306, %2308, %cst_1589) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1590 = arith.constant 1.5707963267948966 : f64
    %2310 = qlx.apply #qlx.action<pauli_rotation>(%2309#1, %cst_1590) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2311 = qlx.apply #qlx.action<h>(%2310) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1591 = arith.constant 1.5707963267948966 : f64
    %2312 = qlx.apply #qlx.action<pauli_rotation>(%2305#0, %cst_1591) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2313 = qlx.apply #qlx.action<h>(%2312) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1592 = arith.constant 1.250000e-01 : f64
    %2314:2 = qlx.apply #qlx.action<pauli_rotation>(%2311, %2313, %cst_1592) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1593 = arith.constant 1.5707963267948966 : f64
    %2315 = qlx.apply #qlx.action<pauli_rotation>(%2309#0, %cst_1593) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2316 = qlx.apply #qlx.action<h>(%2314#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1594 = arith.constant 1.5707963267948966 : f64
    %2317:2 = qlx.apply #qlx.action<pauli_rotation>(%2315, %2316, %cst_1594) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1595 = arith.constant 1.5707963267948966 : f64
    %2318 = qlx.apply #qlx.action<pauli_rotation>(%2317#0, %cst_1595) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2319 = qlx.apply #qlx.action<h>(%2318) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1596 = arith.constant 1.5707963267948966 : f64
    %2320 = qlx.apply #qlx.action<pauli_rotation>(%2319, %cst_1596) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2321 = qlx.apply #qlx.action<h>(%2320) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1597 = arith.constant 1.5707963267948966 : f64
    %2322 = qlx.apply #qlx.action<pauli_rotation>(%2317#1, %cst_1597) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1598 = arith.constant 1.5707963267948966 : f64
    %2323:2 = qlx.apply #qlx.action<pauli_rotation>(%2321, %2322, %cst_1598) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1599 = arith.constant 1.5707963267948966 : f64
    %2324 = qlx.apply #qlx.action<pauli_rotation>(%2323#1, %cst_1599) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2325 = qlx.apply #qlx.action<h>(%2324) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2326 = qlx.apply #qlx.action<h>(%2314#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1600 = arith.constant 1.5707963267948966 : f64
    %2327 = qlx.apply #qlx.action<pauli_rotation>(%2326, %cst_1600) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2328 = qlx.apply #qlx.action<h>(%2327) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1601 = arith.constant 1.250000e-01 : f64
    %2329:2 = qlx.apply #qlx.action<pauli_rotation>(%2325, %2328, %cst_1601) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1602 = arith.constant 1.5707963267948966 : f64
    %2330 = qlx.apply #qlx.action<pauli_rotation>(%2323#0, %cst_1602) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2331 = qlx.apply #qlx.action<h>(%2329#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1603 = arith.constant 1.5707963267948966 : f64
    %2332:2 = qlx.apply #qlx.action<pauli_rotation>(%2330, %2331, %cst_1603) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1604 = arith.constant 1.5707963267948966 : f64
    %2333 = qlx.apply #qlx.action<pauli_rotation>(%2302#1, %cst_1604) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1605 = arith.constant 1.5707963267948966 : f64
    %2334 = qlx.apply #qlx.action<pauli_rotation>(%2332#0, %cst_1605) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2335 = qlx.apply #qlx.action<h>(%2334) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1606 = arith.constant 1.5707963267948966 : f64
    %2336 = qlx.apply #qlx.action<pauli_rotation>(%2335, %cst_1606) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2337 = qlx.apply #qlx.action<h>(%2336) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1607 = arith.constant 1.5707963267948966 : f64
    %2338:2 = qlx.apply #qlx.action<pauli_rotation>(%2333, %2337, %cst_1607) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1608 = arith.constant 1.5707963267948966 : f64
    %2339 = qlx.apply #qlx.action<pauli_rotation>(%2338#1, %cst_1608) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2340 = qlx.apply #qlx.action<h>(%2339) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1609 = arith.constant 1.5707963267948966 : f64
    %2341 = qlx.apply #qlx.action<pauli_rotation>(%2332#1, %cst_1609) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1610 = arith.constant 1.250000e-01 : f64
    %2342:2 = qlx.apply #qlx.action<pauli_rotation>(%2340, %2341, %cst_1610) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1611 = arith.constant 1.5707963267948966 : f64
    %2343 = qlx.apply #qlx.action<pauli_rotation>(%2338#0, %cst_1611) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2344 = qlx.apply #qlx.action<h>(%2342#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1612 = arith.constant 1.5707963267948966 : f64
    %2345:2 = qlx.apply #qlx.action<pauli_rotation>(%2343, %2344, %cst_1612) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1613 = arith.constant 1.5707963267948966 : f64
    %2346 = qlx.apply #qlx.action<pauli_rotation>(%2345#0, %cst_1613) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2347 = qlx.apply #qlx.action<h>(%2346) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1614 = arith.constant 1.5707963267948966 : f64
    %2348 = qlx.apply #qlx.action<pauli_rotation>(%2347, %cst_1614) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2349 = qlx.apply #qlx.action<h>(%2348) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1615 = arith.constant 1.5707963267948966 : f64
    %2350 = qlx.apply #qlx.action<pauli_rotation>(%2345#1, %cst_1615) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1616 = arith.constant 1.5707963267948966 : f64
    %2351:2 = qlx.apply #qlx.action<pauli_rotation>(%2349, %2350, %cst_1616) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1617 = arith.constant 1.5707963267948966 : f64
    %2352 = qlx.apply #qlx.action<pauli_rotation>(%2351#1, %cst_1617) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2353 = qlx.apply #qlx.action<h>(%2352) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2354 = qlx.apply #qlx.action<h>(%2342#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1618 = arith.constant 1.5707963267948966 : f64
    %2355 = qlx.apply #qlx.action<pauli_rotation>(%2354, %cst_1618) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2356 = qlx.apply #qlx.action<h>(%2355) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1619 = arith.constant 1.250000e-01 : f64
    %2357:2 = qlx.apply #qlx.action<pauli_rotation>(%2353, %2356, %cst_1619) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1620 = arith.constant 1.5707963267948966 : f64
    %2358 = qlx.apply #qlx.action<pauli_rotation>(%2351#0, %cst_1620) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2359 = qlx.apply #qlx.action<h>(%2357#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1621 = arith.constant 1.5707963267948966 : f64
    %2360:2 = qlx.apply #qlx.action<pauli_rotation>(%2358, %2359, %cst_1621) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1622 = arith.constant 1.5707963267948966 : f64
    %2361 = qlx.apply #qlx.action<pauli_rotation>(%2302#0, %cst_1622) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2362 = qlx.apply #qlx.action<h>(%2361) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1623 = arith.constant 1.5707963267948966 : f64
    %2363 = qlx.apply #qlx.action<pauli_rotation>(%2360#0, %cst_1623) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2364 = qlx.apply #qlx.action<h>(%2363) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1624 = arith.constant 1.5707963267948966 : f64
    %2365 = qlx.apply #qlx.action<pauli_rotation>(%2364, %cst_1624) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2366 = qlx.apply #qlx.action<h>(%2365) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1625 = arith.constant 1.5707963267948966 : f64
    %2367:2 = qlx.apply #qlx.action<pauli_rotation>(%2362, %2366, %cst_1625) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1626 = arith.constant 1.5707963267948966 : f64
    %2368 = qlx.apply #qlx.action<pauli_rotation>(%2367#1, %cst_1626) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2369 = qlx.apply #qlx.action<h>(%2368) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1627 = arith.constant 1.5707963267948966 : f64
    %2370 = qlx.apply #qlx.action<pauli_rotation>(%2360#1, %cst_1627) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1628 = arith.constant 1.250000e-01 : f64
    %2371:2 = qlx.apply #qlx.action<pauli_rotation>(%2369, %2370, %cst_1628) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1629 = arith.constant 1.5707963267948966 : f64
    %2372 = qlx.apply #qlx.action<pauli_rotation>(%2367#0, %cst_1629) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2373 = qlx.apply #qlx.action<h>(%2371#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1630 = arith.constant 1.5707963267948966 : f64
    %2374:2 = qlx.apply #qlx.action<pauli_rotation>(%2372, %2373, %cst_1630) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1631 = arith.constant 1.5707963267948966 : f64
    %2375 = qlx.apply #qlx.action<pauli_rotation>(%2374#0, %cst_1631) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2376 = qlx.apply #qlx.action<h>(%2375) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1632 = arith.constant 1.5707963267948966 : f64
    %2377 = qlx.apply #qlx.action<pauli_rotation>(%2376, %cst_1632) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2378 = qlx.apply #qlx.action<h>(%2377) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1633 = arith.constant 1.5707963267948966 : f64
    %2379 = qlx.apply #qlx.action<pauli_rotation>(%2374#1, %cst_1633) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1634 = arith.constant 1.5707963267948966 : f64
    %2380:2 = qlx.apply #qlx.action<pauli_rotation>(%2378, %2379, %cst_1634) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1635 = arith.constant 1.5707963267948966 : f64
    %2381 = qlx.apply #qlx.action<pauli_rotation>(%2380#1, %cst_1635) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2382 = qlx.apply #qlx.action<h>(%2381) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2383 = qlx.apply #qlx.action<h>(%2371#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1636 = arith.constant 1.5707963267948966 : f64
    %2384 = qlx.apply #qlx.action<pauli_rotation>(%2383, %cst_1636) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2385 = qlx.apply #qlx.action<h>(%2384) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1637 = arith.constant 1.250000e-01 : f64
    %2386:2 = qlx.apply #qlx.action<pauli_rotation>(%2382, %2385, %cst_1637) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1638 = arith.constant 1.5707963267948966 : f64
    %2387 = qlx.apply #qlx.action<pauli_rotation>(%2380#0, %cst_1638) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2388 = qlx.apply #qlx.action<h>(%2386#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1639 = arith.constant 1.5707963267948966 : f64
    %2389:2 = qlx.apply #qlx.action<pauli_rotation>(%2387, %2388, %cst_1639) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1640 = arith.constant 1.5707963267948966 : f64
    %2390 = qlx.apply #qlx.action<pauli_rotation>(%2292#0, %cst_1640) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2391 = qlx.apply #qlx.action<h>(%2390) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1641 = arith.constant 1.5707963267948966 : f64
    %2392 = qlx.apply #qlx.action<pauli_rotation>(%2391, %cst_1641) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2393 = qlx.apply #qlx.action<h>(%2392) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1642 = arith.constant 1.5707963267948966 : f64
    %2394 = qlx.apply #qlx.action<pauli_rotation>(%2389#0, %cst_1642) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2395 = qlx.apply #qlx.action<h>(%2394) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1643 = arith.constant 1.5707963267948966 : f64
    %2396 = qlx.apply #qlx.action<pauli_rotation>(%2395, %cst_1643) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2397 = qlx.apply #qlx.action<h>(%2396) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1644 = arith.constant 1.5707963267948966 : f64
    %2398:2 = qlx.apply #qlx.action<pauli_rotation>(%2393, %2397, %cst_1644) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1645 = arith.constant 1.5707963267948966 : f64
    %2399 = qlx.apply #qlx.action<pauli_rotation>(%2398#1, %cst_1645) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2400 = qlx.apply #qlx.action<h>(%2399) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1646 = arith.constant 1.5707963267948966 : f64
    %2401 = qlx.apply #qlx.action<pauli_rotation>(%2389#1, %cst_1646) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1647 = arith.constant 1.250000e-01 : f64
    %2402:2 = qlx.apply #qlx.action<pauli_rotation>(%2400, %2401, %cst_1647) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1648 = arith.constant 1.5707963267948966 : f64
    %2403 = qlx.apply #qlx.action<pauli_rotation>(%2398#0, %cst_1648) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2404 = qlx.apply #qlx.action<h>(%2402#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1649 = arith.constant 1.5707963267948966 : f64
    %2405:2 = qlx.apply #qlx.action<pauli_rotation>(%2403, %2404, %cst_1649) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1650 = arith.constant 1.5707963267948966 : f64
    %2406 = qlx.apply #qlx.action<pauli_rotation>(%2405#0, %cst_1650) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2407 = qlx.apply #qlx.action<h>(%2406) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1651 = arith.constant 1.5707963267948966 : f64
    %2408 = qlx.apply #qlx.action<pauli_rotation>(%2407, %cst_1651) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2409 = qlx.apply #qlx.action<h>(%2408) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1652 = arith.constant 1.5707963267948966 : f64
    %2410 = qlx.apply #qlx.action<pauli_rotation>(%2405#1, %cst_1652) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1653 = arith.constant 1.5707963267948966 : f64
    %2411:2 = qlx.apply #qlx.action<pauli_rotation>(%2409, %2410, %cst_1653) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1654 = arith.constant 1.5707963267948966 : f64
    %2412 = qlx.apply #qlx.action<pauli_rotation>(%2411#1, %cst_1654) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2413 = qlx.apply #qlx.action<h>(%2412) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2414 = qlx.apply #qlx.action<h>(%2402#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1655 = arith.constant 1.5707963267948966 : f64
    %2415 = qlx.apply #qlx.action<pauli_rotation>(%2414, %cst_1655) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2416 = qlx.apply #qlx.action<h>(%2415) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1656 = arith.constant 1.250000e-01 : f64
    %2417:2 = qlx.apply #qlx.action<pauli_rotation>(%2413, %2416, %cst_1656) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1657 = arith.constant 1.5707963267948966 : f64
    %2418 = qlx.apply #qlx.action<pauli_rotation>(%2411#0, %cst_1657) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2419 = qlx.apply #qlx.action<h>(%2417#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1658 = arith.constant 1.5707963267948966 : f64
    %2420:2 = qlx.apply #qlx.action<pauli_rotation>(%2418, %2419, %cst_1658) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2421 = qlx.apply #qlx.action<h>(%2329#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1659 = arith.constant 1.5707963267948966 : f64
    %2422 = qlx.apply #qlx.action<pauli_rotation>(%2421, %cst_1659) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2423 = qlx.apply #qlx.action<h>(%2357#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1660 = arith.constant 1.5707963267948966 : f64
    %2424 = qlx.apply #qlx.action<pauli_rotation>(%2423, %cst_1660) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1661 = arith.constant 2.500000e-01 : f64
    %2425:2 = qlx.apply #qlx.action<pauli_rotation>(%2422, %2424, %cst_1661) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2426 = qlx.apply #qlx.action<h>(%2386#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1662 = arith.constant 1.5707963267948966 : f64
    %2427 = qlx.apply #qlx.action<pauli_rotation>(%2426, %cst_1662) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2428 = qlx.apply #qlx.action<h>(%2417#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1663 = arith.constant 1.5707963267948966 : f64
    %2429 = qlx.apply #qlx.action<pauli_rotation>(%2428, %cst_1663) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1664 = arith.constant 2.500000e-01 : f64
    %2430:2 = qlx.apply #qlx.action<pauli_rotation>(%2427, %2429, %cst_1664) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1665 = arith.constant 1.5707963267948966 : f64
    %2431 = qlx.apply #qlx.action<pauli_rotation>(%2420#1, %cst_1665) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2432 = qlx.apply #qlx.action<h>(%2431) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1666 = arith.constant 1.5707963267948966 : f64
    %2433 = qlx.apply #qlx.action<pauli_rotation>(%2420#0, %cst_1666) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2434 = qlx.apply #qlx.action<h>(%2433) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1667 = arith.constant 1.5707963267948966 : f64
    %2435 = qlx.apply #qlx.action<pauli_rotation>(%2434, %cst_1667) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1668 = arith.constant 5.000000e-01 : f64
    %2436:2 = qlx.apply #qlx.action<pauli_rotation>(%2432, %2435, %cst_1668) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1669 = arith.constant 2.500000e-01 : f64
    %2437:2 = qlx.apply #qlx.action<pauli_rotation>(%2430#0, %2430#1, %cst_1669) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1670 = arith.constant 2.500000e-01 : f64
    %2438:2 = qlx.apply #qlx.action<pauli_rotation>(%2425#0, %2425#1, %cst_1670) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1671 = arith.constant 1.5707963267948966 : f64
    %2439 = qlx.apply #qlx.action<pauli_rotation>(%2436#1, %cst_1671) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2440 = qlx.apply #qlx.action<h>(%2439) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2441 = qlx.apply #qlx.action<h>(%2436#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1672 = arith.constant 1.5707963267948966 : f64
    %2442:2 = qlx.apply #qlx.action<pauli_rotation>(%2440, %2441, %cst_1672) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1673 = arith.constant 1.5707963267948966 : f64
    %2443 = qlx.apply #qlx.action<pauli_rotation>(%2442#1, %cst_1673) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2444 = qlx.apply #qlx.action<h>(%2443) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1674 = arith.constant 1.5707963267948966 : f64
    %2445 = qlx.apply #qlx.action<pauli_rotation>(%2437#1, %cst_1674) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2446 = qlx.apply #qlx.action<h>(%2445) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1675 = arith.constant 1.250000e-01 : f64
    %2447:2 = qlx.apply #qlx.action<pauli_rotation>(%2444, %2446, %cst_1675) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1676 = arith.constant 1.5707963267948966 : f64
    %2448 = qlx.apply #qlx.action<pauli_rotation>(%2442#0, %cst_1676) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2449 = qlx.apply #qlx.action<h>(%2447#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1677 = arith.constant 1.5707963267948966 : f64
    %2450:2 = qlx.apply #qlx.action<pauli_rotation>(%2448, %2449, %cst_1677) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1678 = arith.constant 1.5707963267948966 : f64
    %2451 = qlx.apply #qlx.action<pauli_rotation>(%2450#0, %cst_1678) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2452 = qlx.apply #qlx.action<h>(%2451) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1679 = arith.constant 1.5707963267948966 : f64
    %2453 = qlx.apply #qlx.action<pauli_rotation>(%2452, %cst_1679) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2454 = qlx.apply #qlx.action<h>(%2453) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1680 = arith.constant 1.5707963267948966 : f64
    %2455 = qlx.apply #qlx.action<pauli_rotation>(%2450#1, %cst_1680) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1681 = arith.constant 1.5707963267948966 : f64
    %2456:2 = qlx.apply #qlx.action<pauli_rotation>(%2454, %2455, %cst_1681) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1682 = arith.constant 1.5707963267948966 : f64
    %2457 = qlx.apply #qlx.action<pauli_rotation>(%2456#1, %cst_1682) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2458 = qlx.apply #qlx.action<h>(%2457) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2459 = qlx.apply #qlx.action<h>(%2447#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1683 = arith.constant 1.5707963267948966 : f64
    %2460 = qlx.apply #qlx.action<pauli_rotation>(%2459, %cst_1683) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2461 = qlx.apply #qlx.action<h>(%2460) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1684 = arith.constant 1.250000e-01 : f64
    %2462:2 = qlx.apply #qlx.action<pauli_rotation>(%2458, %2461, %cst_1684) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1685 = arith.constant 1.5707963267948966 : f64
    %2463 = qlx.apply #qlx.action<pauli_rotation>(%2456#0, %cst_1685) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2464 = qlx.apply #qlx.action<h>(%2462#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1686 = arith.constant 1.5707963267948966 : f64
    %2465:2 = qlx.apply #qlx.action<pauli_rotation>(%2463, %2464, %cst_1686) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1687 = arith.constant 1.5707963267948966 : f64
    %2466 = qlx.apply #qlx.action<pauli_rotation>(%2465#1, %cst_1687) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2467 = qlx.apply #qlx.action<h>(%2466) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1688 = arith.constant 1.5707963267948966 : f64
    %2468 = qlx.apply #qlx.action<pauli_rotation>(%2467, %cst_1688) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2469 = qlx.apply #qlx.action<h>(%2468) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1689 = arith.constant 1.5707963267948966 : f64
    %2470:2 = qlx.apply #qlx.action<pauli_rotation>(%2462#1, %2469, %cst_1689) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1690 = arith.constant 1.5707963267948966 : f64
    %2471 = qlx.apply #qlx.action<pauli_rotation>(%2470#0, %cst_1690) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2472 = qlx.apply #qlx.action<h>(%2471) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1691 = arith.constant 1.5707963267948966 : f64
    %2473 = qlx.apply #qlx.action<pauli_rotation>(%2437#0, %cst_1691) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2474 = qlx.apply #qlx.action<h>(%2473) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1692 = arith.constant 1.250000e-01 : f64
    %2475:2 = qlx.apply #qlx.action<pauli_rotation>(%2472, %2474, %cst_1692) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1693 = arith.constant 1.5707963267948966 : f64
    %2476 = qlx.apply #qlx.action<pauli_rotation>(%2470#1, %cst_1693) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2477 = qlx.apply #qlx.action<h>(%2475#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1694 = arith.constant 1.5707963267948966 : f64
    %2478:2 = qlx.apply #qlx.action<pauli_rotation>(%2476, %2477, %cst_1694) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1695 = arith.constant 1.5707963267948966 : f64
    %2479 = qlx.apply #qlx.action<pauli_rotation>(%2478#0, %cst_1695) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2480 = qlx.apply #qlx.action<h>(%2479) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1696 = arith.constant 1.5707963267948966 : f64
    %2481 = qlx.apply #qlx.action<pauli_rotation>(%2480, %cst_1696) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2482 = qlx.apply #qlx.action<h>(%2481) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1697 = arith.constant 1.5707963267948966 : f64
    %2483 = qlx.apply #qlx.action<pauli_rotation>(%2478#1, %cst_1697) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1698 = arith.constant 1.5707963267948966 : f64
    %2484:2 = qlx.apply #qlx.action<pauli_rotation>(%2482, %2483, %cst_1698) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1699 = arith.constant 1.5707963267948966 : f64
    %2485 = qlx.apply #qlx.action<pauli_rotation>(%2484#1, %cst_1699) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2486 = qlx.apply #qlx.action<h>(%2485) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2487 = qlx.apply #qlx.action<h>(%2475#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1700 = arith.constant 1.5707963267948966 : f64
    %2488 = qlx.apply #qlx.action<pauli_rotation>(%2487, %cst_1700) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2489 = qlx.apply #qlx.action<h>(%2488) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1701 = arith.constant 1.250000e-01 : f64
    %2490:2 = qlx.apply #qlx.action<pauli_rotation>(%2486, %2489, %cst_1701) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1702 = arith.constant 1.5707963267948966 : f64
    %2491 = qlx.apply #qlx.action<pauli_rotation>(%2484#0, %cst_1702) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2492 = qlx.apply #qlx.action<h>(%2490#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1703 = arith.constant 1.5707963267948966 : f64
    %2493:2 = qlx.apply #qlx.action<pauli_rotation>(%2491, %2492, %cst_1703) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1704 = arith.constant 1.5707963267948966 : f64
    %2494 = qlx.apply #qlx.action<pauli_rotation>(%2493#1, %cst_1704) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2495 = qlx.apply #qlx.action<h>(%2494) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1705 = arith.constant 1.5707963267948966 : f64
    %2496 = qlx.apply #qlx.action<pauli_rotation>(%2495, %cst_1705) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2497 = qlx.apply #qlx.action<h>(%2496) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1706 = arith.constant 1.5707963267948966 : f64
    %2498:2 = qlx.apply #qlx.action<pauli_rotation>(%2490#1, %2497, %cst_1706) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1707 = arith.constant 1.5707963267948966 : f64
    %2499 = qlx.apply #qlx.action<pauli_rotation>(%2498#0, %cst_1707) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2500 = qlx.apply #qlx.action<h>(%2499) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1708 = arith.constant 1.5707963267948966 : f64
    %2501 = qlx.apply #qlx.action<pauli_rotation>(%2438#1, %cst_1708) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2502 = qlx.apply #qlx.action<h>(%2501) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1709 = arith.constant 1.250000e-01 : f64
    %2503:2 = qlx.apply #qlx.action<pauli_rotation>(%2500, %2502, %cst_1709) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1710 = arith.constant 1.5707963267948966 : f64
    %2504 = qlx.apply #qlx.action<pauli_rotation>(%2498#1, %cst_1710) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2505 = qlx.apply #qlx.action<h>(%2503#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1711 = arith.constant 1.5707963267948966 : f64
    %2506:2 = qlx.apply #qlx.action<pauli_rotation>(%2504, %2505, %cst_1711) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1712 = arith.constant 1.5707963267948966 : f64
    %2507 = qlx.apply #qlx.action<pauli_rotation>(%2506#0, %cst_1712) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2508 = qlx.apply #qlx.action<h>(%2507) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1713 = arith.constant 1.5707963267948966 : f64
    %2509 = qlx.apply #qlx.action<pauli_rotation>(%2508, %cst_1713) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2510 = qlx.apply #qlx.action<h>(%2509) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1714 = arith.constant 1.5707963267948966 : f64
    %2511 = qlx.apply #qlx.action<pauli_rotation>(%2506#1, %cst_1714) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1715 = arith.constant 1.5707963267948966 : f64
    %2512:2 = qlx.apply #qlx.action<pauli_rotation>(%2510, %2511, %cst_1715) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1716 = arith.constant 1.5707963267948966 : f64
    %2513 = qlx.apply #qlx.action<pauli_rotation>(%2512#1, %cst_1716) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2514 = qlx.apply #qlx.action<h>(%2513) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2515 = qlx.apply #qlx.action<h>(%2503#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1717 = arith.constant 1.5707963267948966 : f64
    %2516 = qlx.apply #qlx.action<pauli_rotation>(%2515, %cst_1717) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2517 = qlx.apply #qlx.action<h>(%2516) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1718 = arith.constant 1.250000e-01 : f64
    %2518:2 = qlx.apply #qlx.action<pauli_rotation>(%2514, %2517, %cst_1718) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1719 = arith.constant 1.5707963267948966 : f64
    %2519 = qlx.apply #qlx.action<pauli_rotation>(%2512#0, %cst_1719) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2520 = qlx.apply #qlx.action<h>(%2518#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1720 = arith.constant 1.5707963267948966 : f64
    %2521:2 = qlx.apply #qlx.action<pauli_rotation>(%2519, %2520, %cst_1720) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1721 = arith.constant 1.5707963267948966 : f64
    %2522 = qlx.apply #qlx.action<pauli_rotation>(%2521#1, %cst_1721) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2523 = qlx.apply #qlx.action<h>(%2522) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1722 = arith.constant 1.5707963267948966 : f64
    %2524 = qlx.apply #qlx.action<pauli_rotation>(%2523, %cst_1722) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2525 = qlx.apply #qlx.action<h>(%2524) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1723 = arith.constant 1.5707963267948966 : f64
    %2526:2 = qlx.apply #qlx.action<pauli_rotation>(%2518#1, %2525, %cst_1723) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1724 = arith.constant 1.5707963267948966 : f64
    %2527 = qlx.apply #qlx.action<pauli_rotation>(%2526#0, %cst_1724) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2528 = qlx.apply #qlx.action<h>(%2527) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1725 = arith.constant 1.5707963267948966 : f64
    %2529 = qlx.apply #qlx.action<pauli_rotation>(%2438#0, %cst_1725) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2530 = qlx.apply #qlx.action<h>(%2529) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1726 = arith.constant 1.250000e-01 : f64
    %2531:2 = qlx.apply #qlx.action<pauli_rotation>(%2528, %2530, %cst_1726) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1727 = arith.constant 1.5707963267948966 : f64
    %2532 = qlx.apply #qlx.action<pauli_rotation>(%2526#1, %cst_1727) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2533 = qlx.apply #qlx.action<h>(%2531#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1728 = arith.constant 1.5707963267948966 : f64
    %2534:2 = qlx.apply #qlx.action<pauli_rotation>(%2532, %2533, %cst_1728) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1729 = arith.constant 1.5707963267948966 : f64
    %2535 = qlx.apply #qlx.action<pauli_rotation>(%2534#0, %cst_1729) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2536 = qlx.apply #qlx.action<h>(%2535) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1730 = arith.constant 1.5707963267948966 : f64
    %2537 = qlx.apply #qlx.action<pauli_rotation>(%2536, %cst_1730) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2538 = qlx.apply #qlx.action<h>(%2537) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1731 = arith.constant 1.5707963267948966 : f64
    %2539 = qlx.apply #qlx.action<pauli_rotation>(%2534#1, %cst_1731) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1732 = arith.constant 1.5707963267948966 : f64
    %2540:2 = qlx.apply #qlx.action<pauli_rotation>(%2538, %2539, %cst_1732) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1733 = arith.constant 1.5707963267948966 : f64
    %2541 = qlx.apply #qlx.action<pauli_rotation>(%2540#1, %cst_1733) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2542 = qlx.apply #qlx.action<h>(%2541) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2543 = qlx.apply #qlx.action<h>(%2531#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1734 = arith.constant 1.5707963267948966 : f64
    %2544 = qlx.apply #qlx.action<pauli_rotation>(%2543, %cst_1734) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2545 = qlx.apply #qlx.action<h>(%2544) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1735 = arith.constant 1.250000e-01 : f64
    %2546:2 = qlx.apply #qlx.action<pauli_rotation>(%2542, %2545, %cst_1735) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1736 = arith.constant 1.5707963267948966 : f64
    %2547 = qlx.apply #qlx.action<pauli_rotation>(%2540#0, %cst_1736) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2548 = qlx.apply #qlx.action<h>(%2546#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1737 = arith.constant 1.5707963267948966 : f64
    %2549:2 = qlx.apply #qlx.action<pauli_rotation>(%2547, %2548, %cst_1737) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2550 = qlx.apply #qlx.action<h>(%2546#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1738 = arith.constant 1.5707963267948966 : f64
    %2551 = qlx.apply #qlx.action<pauli_rotation>(%2305#1, %cst_1738) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1739 = arith.constant 1.5707963267948966 : f64
    %2552:2 = qlx.apply #qlx.action<pauli_rotation>(%2550, %2551, %cst_1739) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1740 = arith.constant 1.5707963267948966 : f64
    %2553 = qlx.apply #qlx.action<pauli_rotation>(%2493#0, %cst_1740) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2554 = qlx.apply #qlx.action<h>(%2553) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1741 = arith.constant 1.5707963267948966 : f64
    %2555 = qlx.apply #qlx.action<pauli_rotation>(%2521#0, %cst_1741) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1742 = arith.constant 1.5707963267948966 : f64
    %2556:2 = qlx.apply #qlx.action<pauli_rotation>(%2554, %2555, %cst_1742) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1743 = arith.constant 1.5707963267948966 : f64
    %2557 = qlx.apply #qlx.action<pauli_rotation>(%2549#1, %cst_1743) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2558 = qlx.apply #qlx.action<h>(%2557) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1744 = arith.constant 1.5707963267948966 : f64
    %2559 = qlx.apply #qlx.action<pauli_rotation>(%2549#0, %cst_1744) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1745 = arith.constant 1.5707963267948966 : f64
    %2560:2 = qlx.apply #qlx.action<pauli_rotation>(%2558, %2559, %cst_1745) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1746 = arith.constant 1.5707963267948966 : f64
    %2561 = qlx.apply #qlx.action<pauli_rotation>(%2556#1, %cst_1746) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2562 = qlx.apply #qlx.action<h>(%2561) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1747 = arith.constant 1.5707963267948966 : f64
    %2563 = qlx.apply #qlx.action<pauli_rotation>(%2560#1, %cst_1747) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1748 = arith.constant 1.5707963267948966 : f64
    %2564:2 = qlx.apply #qlx.action<pauli_rotation>(%2562, %2563, %cst_1748) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1749 = arith.constant 1.5707963267948966 : f64
    %2565 = qlx.apply #qlx.action<pauli_rotation>(%2465#0, %cst_1749) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2566 = qlx.apply #qlx.action<h>(%2565) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1750 = arith.constant 1.5707963267948966 : f64
    %2567 = qlx.apply #qlx.action<pauli_rotation>(%2566, %cst_1750) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2568 = qlx.apply #qlx.action<h>(%2567) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1751 = arith.constant 1.5707963267948966 : f64
    %2569 = qlx.apply #qlx.action<pauli_rotation>(%2564#1, %cst_1751) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1752 = arith.constant 1.5707963267948966 : f64
    %2570:2 = qlx.apply #qlx.action<pauli_rotation>(%2568, %2569, %cst_1752) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1753 = arith.constant 1.5707963267948966 : f64
    %2571 = qlx.apply #qlx.action<pauli_rotation>(%2570#1, %cst_1753) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2572 = qlx.apply #qlx.action<h>(%2571) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1754 = arith.constant 1.5707963267948966 : f64
    %2573 = qlx.apply #qlx.action<pauli_rotation>(%2552#1, %cst_1754) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2574 = qlx.apply #qlx.action<h>(%2573) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1755 = arith.constant 1.250000e-01 : f64
    %2575:2 = qlx.apply #qlx.action<pauli_rotation>(%2572, %2574, %cst_1755) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1756 = arith.constant 1.5707963267948966 : f64
    %2576 = qlx.apply #qlx.action<pauli_rotation>(%2570#0, %cst_1756) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2577 = qlx.apply #qlx.action<h>(%2575#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1757 = arith.constant 1.5707963267948966 : f64
    %2578:2 = qlx.apply #qlx.action<pauli_rotation>(%2576, %2577, %cst_1757) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1758 = arith.constant 1.5707963267948966 : f64
    %2579 = qlx.apply #qlx.action<pauli_rotation>(%2564#0, %cst_1758) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1759 = arith.constant 1.5707963267948966 : f64
    %2580 = qlx.apply #qlx.action<pauli_rotation>(%2578#1, %cst_1759) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1760 = arith.constant 1.5707963267948966 : f64
    %2581:2 = qlx.apply #qlx.action<pauli_rotation>(%2579, %2580, %cst_1760) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1761 = arith.constant 1.5707963267948966 : f64
    %2582 = qlx.apply #qlx.action<pauli_rotation>(%2560#0, %cst_1761) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1762 = arith.constant 1.5707963267948966 : f64
    %2583 = qlx.apply #qlx.action<pauli_rotation>(%2581#1, %cst_1762) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1763 = arith.constant 1.5707963267948966 : f64
    %2584:2 = qlx.apply #qlx.action<pauli_rotation>(%2582, %2583, %cst_1763) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1764 = arith.constant 1.5707963267948966 : f64
    %2585 = qlx.apply #qlx.action<pauli_rotation>(%2556#0, %cst_1764) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1765 = arith.constant 1.5707963267948966 : f64
    %2586 = qlx.apply #qlx.action<pauli_rotation>(%2581#0, %cst_1765) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2587 = qlx.apply #qlx.action<h>(%2586) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1766 = arith.constant 1.5707963267948966 : f64
    %2588:2 = qlx.apply #qlx.action<pauli_rotation>(%2585, %2587, %cst_1766) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1767 = arith.constant 1.5707963267948966 : f64
    %2589 = qlx.apply #qlx.action<pauli_rotation>(%2552#0, %cst_1767) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2590 = qlx.apply #qlx.action<h>(%2575#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1768 = arith.constant 1.5707963267948966 : f64
    %2591:2 = qlx.apply #qlx.action<pauli_rotation>(%2589, %2590, %cst_1768) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1769 = arith.constant 1.5707963267948966 : f64
    %2592 = qlx.apply #qlx.action<pauli_rotation>(%2591#0, %cst_1769) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1770 = arith.constant 1.5707963267948966 : f64
    %2593:2 = qlx.apply #qlx.action<pauli_rotation>(%2591#1, %2592, %cst_1770) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1771 = arith.constant 1.5707963267948966 : f64
    %2594 = qlx.apply #qlx.action<pauli_rotation>(%2588#0, %cst_1771) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1772 = arith.constant 1.5707963267948966 : f64
    %2595 = qlx.apply #qlx.action<pauli_rotation>(%2588#1, %cst_1772) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1773 = arith.constant 1.5707963267948966 : f64
    %2596:2 = qlx.apply #qlx.action<pauli_rotation>(%2594, %2595, %cst_1773) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1774 = arith.constant 1.5707963267948966 : f64
    %2597 = qlx.apply #qlx.action<pauli_rotation>(%2584#0, %cst_1774) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1775 = arith.constant 1.5707963267948966 : f64
    %2598 = qlx.apply #qlx.action<pauli_rotation>(%2584#1, %cst_1775) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1776 = arith.constant 1.5707963267948966 : f64
    %2599:2 = qlx.apply #qlx.action<pauli_rotation>(%2597, %2598, %cst_1776) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1777 = arith.constant 1.5707963267948966 : f64
    %2600 = qlx.apply #qlx.action<pauli_rotation>(%2596#1, %cst_1777) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2601 = qlx.apply #qlx.action<h>(%2600) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1778 = arith.constant 1.5707963267948966 : f64
    %2602 = qlx.apply #qlx.action<pauli_rotation>(%2599#1, %cst_1778) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1779 = arith.constant 1.5707963267948966 : f64
    %2603:2 = qlx.apply #qlx.action<pauli_rotation>(%2601, %2602, %cst_1779) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1780 = arith.constant 1.5707963267948966 : f64
    %2604 = qlx.apply #qlx.action<pauli_rotation>(%2578#0, %cst_1780) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2605 = qlx.apply #qlx.action<h>(%2604) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1781 = arith.constant 1.5707963267948966 : f64
    %2606 = qlx.apply #qlx.action<pauli_rotation>(%2605, %cst_1781) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2607 = qlx.apply #qlx.action<h>(%2606) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1782 = arith.constant 1.5707963267948966 : f64
    %2608 = qlx.apply #qlx.action<pauli_rotation>(%2603#1, %cst_1782) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1783 = arith.constant 1.5707963267948966 : f64
    %2609:2 = qlx.apply #qlx.action<pauli_rotation>(%2607, %2608, %cst_1783) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1784 = arith.constant 1.5707963267948966 : f64
    %2610 = qlx.apply #qlx.action<pauli_rotation>(%2609#1, %cst_1784) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2611 = qlx.apply #qlx.action<h>(%2610) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1785 = arith.constant 1.5707963267948966 : f64
    %2612 = qlx.apply #qlx.action<pauli_rotation>(%2593#0, %cst_1785) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2613 = qlx.apply #qlx.action<h>(%2612) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1786 = arith.constant 1.250000e-01 : f64
    %2614:2 = qlx.apply #qlx.action<pauli_rotation>(%2611, %2613, %cst_1786) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1787 = arith.constant 1.5707963267948966 : f64
    %2615 = qlx.apply #qlx.action<pauli_rotation>(%2609#0, %cst_1787) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2616 = qlx.apply #qlx.action<h>(%2614#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1788 = arith.constant 1.5707963267948966 : f64
    %2617:2 = qlx.apply #qlx.action<pauli_rotation>(%2615, %2616, %cst_1788) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1789 = arith.constant 1.5707963267948966 : f64
    %2618 = qlx.apply #qlx.action<pauli_rotation>(%2603#0, %cst_1789) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1790 = arith.constant 1.5707963267948966 : f64
    %2619 = qlx.apply #qlx.action<pauli_rotation>(%2617#1, %cst_1790) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1791 = arith.constant 1.5707963267948966 : f64
    %2620:2 = qlx.apply #qlx.action<pauli_rotation>(%2618, %2619, %cst_1791) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1792 = arith.constant 1.5707963267948966 : f64
    %2621 = qlx.apply #qlx.action<pauli_rotation>(%2599#0, %cst_1792) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1793 = arith.constant 1.5707963267948966 : f64
    %2622 = qlx.apply #qlx.action<pauli_rotation>(%2620#1, %cst_1793) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1794 = arith.constant 1.5707963267948966 : f64
    %2623:2 = qlx.apply #qlx.action<pauli_rotation>(%2621, %2622, %cst_1794) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1795 = arith.constant 1.5707963267948966 : f64
    %2624 = qlx.apply #qlx.action<pauli_rotation>(%2596#0, %cst_1795) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1796 = arith.constant 1.5707963267948966 : f64
    %2625 = qlx.apply #qlx.action<pauli_rotation>(%2620#0, %cst_1796) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2626 = qlx.apply #qlx.action<h>(%2625) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1797 = arith.constant 1.5707963267948966 : f64
    %2627:2 = qlx.apply #qlx.action<pauli_rotation>(%2624, %2626, %cst_1797) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1798 = arith.constant 1.5707963267948966 : f64
    %2628 = qlx.apply #qlx.action<pauli_rotation>(%2593#1, %cst_1798) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2629 = qlx.apply #qlx.action<h>(%2614#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1799 = arith.constant 1.5707963267948966 : f64
    %2630:2 = qlx.apply #qlx.action<pauli_rotation>(%2628, %2629, %cst_1799) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1800 = arith.constant 1.5707963267948966 : f64
    %2631 = qlx.apply #qlx.action<pauli_rotation>(%2225#0, %cst_1800) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1801 = arith.constant 1.5707963267948966 : f64
    %2632 = qlx.apply #qlx.action<pauli_rotation>(%2630#1, %cst_1801) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2633 = qlx.apply #qlx.action<h>(%2632) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1802 = arith.constant 1.5707963267948966 : f64
    %2634:2 = qlx.apply #qlx.action<pauli_rotation>(%2631, %2633, %cst_1802) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1803 = arith.constant 1.5707963267948966 : f64
    %2635 = qlx.apply #qlx.action<pauli_rotation>(%2630#0, %cst_1803) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1804 = arith.constant 1.5707963267948966 : f64
    %2636 = qlx.apply #qlx.action<pauli_rotation>(%2634#1, %cst_1804) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1805 = arith.constant 1.5707963267948966 : f64
    %2637:2 = qlx.apply #qlx.action<pauli_rotation>(%2635, %2636, %cst_1805) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1806 = arith.constant 3.1415926535897931 : f64
    %2638 = qlx.apply #qlx.action<pauli_rotation>(%2627#0, %cst_1806) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2639 = qlx.apply #qlx.action<h>(%2638) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1807 = arith.constant 1.5707963267948966 : f64
    %2640 = qlx.apply #qlx.action<pauli_rotation>(%2627#1, %cst_1807) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1808 = arith.constant 1.5707963267948966 : f64
    %2641:2 = qlx.apply #qlx.action<pauli_rotation>(%2639, %2640, %cst_1808) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1809 = arith.constant 1.5707963267948966 : f64
    %2642 = qlx.apply #qlx.action<pauli_rotation>(%2623#0, %cst_1809) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1810 = arith.constant 1.5707963267948966 : f64
    %2643 = qlx.apply #qlx.action<pauli_rotation>(%2623#1, %cst_1810) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1811 = arith.constant 1.5707963267948966 : f64
    %2644:2 = qlx.apply #qlx.action<pauli_rotation>(%2642, %2643, %cst_1811) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1812 = arith.constant 1.5707963267948966 : f64
    %2645 = qlx.apply #qlx.action<pauli_rotation>(%2641#1, %cst_1812) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2646 = qlx.apply #qlx.action<h>(%2645) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1813 = arith.constant 1.5707963267948966 : f64
    %2647 = qlx.apply #qlx.action<pauli_rotation>(%2644#1, %cst_1813) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1814 = arith.constant 1.5707963267948966 : f64
    %2648:2 = qlx.apply #qlx.action<pauli_rotation>(%2646, %2647, %cst_1814) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1815 = arith.constant 1.5707963267948966 : f64
    %2649 = qlx.apply #qlx.action<pauli_rotation>(%2648#1, %cst_1815) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2650 = qlx.apply #qlx.action<h>(%2649) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1816 = arith.constant 1.5707963267948966 : f64
    %2651 = qlx.apply #qlx.action<pauli_rotation>(%2637#1, %cst_1816) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2652 = qlx.apply #qlx.action<h>(%2651) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1817 = arith.constant 1.250000e-01 : f64
    %2653:2 = qlx.apply #qlx.action<pauli_rotation>(%2650, %2652, %cst_1817) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1818 = arith.constant 1.5707963267948966 : f64
    %2654 = qlx.apply #qlx.action<pauli_rotation>(%2648#0, %cst_1818) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2655 = qlx.apply #qlx.action<h>(%2653#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1819 = arith.constant 1.5707963267948966 : f64
    %2656:2 = qlx.apply #qlx.action<pauli_rotation>(%2654, %2655, %cst_1819) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1820 = arith.constant 1.5707963267948966 : f64
    %2657 = qlx.apply #qlx.action<pauli_rotation>(%2644#0, %cst_1820) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1821 = arith.constant 1.5707963267948966 : f64
    %2658 = qlx.apply #qlx.action<pauli_rotation>(%2656#1, %cst_1821) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1822 = arith.constant 1.5707963267948966 : f64
    %2659:2 = qlx.apply #qlx.action<pauli_rotation>(%2657, %2658, %cst_1822) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1823 = arith.constant 1.5707963267948966 : f64
    %2660 = qlx.apply #qlx.action<pauli_rotation>(%2641#0, %cst_1823) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1824 = arith.constant 1.5707963267948966 : f64
    %2661 = qlx.apply #qlx.action<pauli_rotation>(%2656#0, %cst_1824) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2662 = qlx.apply #qlx.action<h>(%2661) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1825 = arith.constant 1.5707963267948966 : f64
    %2663:2 = qlx.apply #qlx.action<pauli_rotation>(%2660, %2662, %cst_1825) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1826 = arith.constant 1.5707963267948966 : f64
    %2664 = qlx.apply #qlx.action<pauli_rotation>(%2637#0, %cst_1826) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2665 = qlx.apply #qlx.action<h>(%2653#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1827 = arith.constant 1.5707963267948966 : f64
    %2666:2 = qlx.apply #qlx.action<pauli_rotation>(%2664, %2665, %cst_1827) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1828 = arith.constant 1.5707963267948966 : f64
    %2667 = qlx.apply #qlx.action<pauli_rotation>(%2634#0, %cst_1828) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1829 = arith.constant 1.5707963267948966 : f64
    %2668 = qlx.apply #qlx.action<pauli_rotation>(%2666#1, %cst_1829) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1830 = arith.constant 1.5707963267948966 : f64
    %2669:2 = qlx.apply #qlx.action<pauli_rotation>(%2667, %2668, %cst_1830) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1831 = arith.constant 1.5707963267948966 : f64
    %2670 = qlx.apply #qlx.action<pauli_rotation>(%2669#0, %cst_1831) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2671 = qlx.apply #qlx.action<h>(%2670) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1832 = arith.constant 1.5707963267948966 : f64
    %2672 = qlx.apply #qlx.action<pauli_rotation>(%2671, %cst_1832) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2673 = qlx.apply #qlx.action<h>(%2672) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1833 = arith.constant 1.5707963267948966 : f64
    %2674 = qlx.apply #qlx.action<pauli_rotation>(%2669#1, %cst_1833) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1834 = arith.constant 1.5707963267948966 : f64
    %2675:2 = qlx.apply #qlx.action<pauli_rotation>(%2673, %2674, %cst_1834) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1835 = arith.constant 1.5707963267948966 : f64
    %2676 = qlx.apply #qlx.action<pauli_rotation>(%2666#0, %cst_1835) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1836 = arith.constant 1.5707963267948966 : f64
    %2677 = qlx.apply #qlx.action<pauli_rotation>(%2675#1, %cst_1836) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1837 = arith.constant 1.5707963267948966 : f64
    %2678:2 = qlx.apply #qlx.action<pauli_rotation>(%2676, %2677, %cst_1837) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1838 = arith.constant 1.5707963267948966 : f64
    %2679 = qlx.apply #qlx.action<pauli_rotation>(%2663#0, %cst_1838) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2680 = qlx.apply #qlx.action<h>(%2679) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1839 = arith.constant 1.5707963267948966 : f64
    %2681 = qlx.apply #qlx.action<pauli_rotation>(%2680, %cst_1839) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2682 = qlx.apply #qlx.action<h>(%2681) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1840 = arith.constant 1.5707963267948966 : f64
    %2683 = qlx.apply #qlx.action<pauli_rotation>(%2663#1, %cst_1840) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1841 = arith.constant 1.5707963267948966 : f64
    %2684:2 = qlx.apply #qlx.action<pauli_rotation>(%2682, %2683, %cst_1841) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1842 = arith.constant 1.5707963267948966 : f64
    %2685 = qlx.apply #qlx.action<pauli_rotation>(%2659#0, %cst_1842) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1843 = arith.constant 1.5707963267948966 : f64
    %2686 = qlx.apply #qlx.action<pauli_rotation>(%2659#1, %cst_1843) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1844 = arith.constant 1.5707963267948966 : f64
    %2687:2 = qlx.apply #qlx.action<pauli_rotation>(%2685, %2686, %cst_1844) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1845 = arith.constant 1.5707963267948966 : f64
    %2688 = qlx.apply #qlx.action<pauli_rotation>(%2684#1, %cst_1845) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2689 = qlx.apply #qlx.action<h>(%2688) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1846 = arith.constant 1.5707963267948966 : f64
    %2690 = qlx.apply #qlx.action<pauli_rotation>(%2687#1, %cst_1846) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1847 = arith.constant 1.5707963267948966 : f64
    %2691:2 = qlx.apply #qlx.action<pauli_rotation>(%2689, %2690, %cst_1847) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1848 = arith.constant 1.5707963267948966 : f64
    %2692 = qlx.apply #qlx.action<pauli_rotation>(%2691#1, %cst_1848) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2693 = qlx.apply #qlx.action<h>(%2692) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1849 = arith.constant 1.5707963267948966 : f64
    %2694 = qlx.apply #qlx.action<pauli_rotation>(%2678#1, %cst_1849) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2695 = qlx.apply #qlx.action<h>(%2694) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1850 = arith.constant 1.250000e-01 : f64
    %2696:2 = qlx.apply #qlx.action<pauli_rotation>(%2693, %2695, %cst_1850) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1851 = arith.constant 1.5707963267948966 : f64
    %2697 = qlx.apply #qlx.action<pauli_rotation>(%2691#0, %cst_1851) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2698 = qlx.apply #qlx.action<h>(%2696#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1852 = arith.constant 1.5707963267948966 : f64
    %2699:2 = qlx.apply #qlx.action<pauli_rotation>(%2697, %2698, %cst_1852) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1853 = arith.constant 1.5707963267948966 : f64
    %2700 = qlx.apply #qlx.action<pauli_rotation>(%2687#0, %cst_1853) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1854 = arith.constant 1.5707963267948966 : f64
    %2701 = qlx.apply #qlx.action<pauli_rotation>(%2699#1, %cst_1854) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1855 = arith.constant 1.5707963267948966 : f64
    %2702:2 = qlx.apply #qlx.action<pauli_rotation>(%2700, %2701, %cst_1855) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1856 = arith.constant 1.5707963267948966 : f64
    %2703 = qlx.apply #qlx.action<pauli_rotation>(%2684#0, %cst_1856) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1857 = arith.constant 1.5707963267948966 : f64
    %2704 = qlx.apply #qlx.action<pauli_rotation>(%2699#0, %cst_1857) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2705 = qlx.apply #qlx.action<h>(%2704) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1858 = arith.constant 1.5707963267948966 : f64
    %2706:2 = qlx.apply #qlx.action<pauli_rotation>(%2703, %2705, %cst_1858) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1859 = arith.constant 1.5707963267948966 : f64
    %2707 = qlx.apply #qlx.action<pauli_rotation>(%2678#0, %cst_1859) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2708 = qlx.apply #qlx.action<h>(%2696#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1860 = arith.constant 1.5707963267948966 : f64
    %2709:2 = qlx.apply #qlx.action<pauli_rotation>(%2707, %2708, %cst_1860) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1861 = arith.constant 1.5707963267948966 : f64
    %2710 = qlx.apply #qlx.action<pauli_rotation>(%2675#0, %cst_1861) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1862 = arith.constant 1.5707963267948966 : f64
    %2711 = qlx.apply #qlx.action<pauli_rotation>(%2709#1, %cst_1862) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1863 = arith.constant 1.5707963267948966 : f64
    %2712:2 = qlx.apply #qlx.action<pauli_rotation>(%2710, %2711, %cst_1863) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1864 = arith.constant 3.1415926535897931 : f64
    %2713 = qlx.apply #qlx.action<pauli_rotation>(%2702#0, %cst_1864) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2714 = qlx.apply #qlx.action<h>(%2713) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1865 = arith.constant 1.5707963267948966 : f64
    %2715 = qlx.apply #qlx.action<pauli_rotation>(%2709#0, %cst_1865) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2716 = qlx.apply #qlx.action<h>(%2715) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1866 = arith.constant 1.5707963267948966 : f64
    %2717:2 = qlx.apply #qlx.action<pauli_rotation>(%2714, %2716, %cst_1866) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1867 = arith.constant 1.5707963267948966 : f64
    %2718 = qlx.apply #qlx.action<pauli_rotation>(%2717#1, %cst_1867) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2719 = qlx.apply #qlx.action<h>(%2718) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1868 = arith.constant 1.5707963267948966 : f64
    %2720 = qlx.apply #qlx.action<pauli_rotation>(%2712#1, %cst_1868) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2721 = qlx.apply #qlx.action<h>(%2720) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1869 = arith.constant 1.5707963267948966 : f64
    %2722 = qlx.apply #qlx.action<pauli_rotation>(%2721, %cst_1869) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2723 = qlx.apply #qlx.action<h>(%2722) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1870 = arith.constant 1.250000e-01 : f64
    %2724:2 = qlx.apply #qlx.action<pauli_rotation>(%2719, %2723, %cst_1870) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1871 = arith.constant 1.5707963267948966 : f64
    %2725 = qlx.apply #qlx.action<pauli_rotation>(%2717#0, %cst_1871) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2726 = qlx.apply #qlx.action<h>(%2724#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1872 = arith.constant 1.5707963267948966 : f64
    %2727:2 = qlx.apply #qlx.action<pauli_rotation>(%2725, %2726, %cst_1872) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1873 = arith.constant 1.5707963267948966 : f64
    %2728 = qlx.apply #qlx.action<pauli_rotation>(%2727#0, %cst_1873) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2729 = qlx.apply #qlx.action<h>(%2728) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1874 = arith.constant 1.5707963267948966 : f64
    %2730 = qlx.apply #qlx.action<pauli_rotation>(%2729, %cst_1874) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2731 = qlx.apply #qlx.action<h>(%2730) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1875 = arith.constant 1.5707963267948966 : f64
    %2732 = qlx.apply #qlx.action<pauli_rotation>(%2727#1, %cst_1875) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1876 = arith.constant 1.5707963267948966 : f64
    %2733:2 = qlx.apply #qlx.action<pauli_rotation>(%2731, %2732, %cst_1876) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1877 = arith.constant 1.5707963267948966 : f64
    %2734 = qlx.apply #qlx.action<pauli_rotation>(%2733#1, %cst_1877) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2735 = qlx.apply #qlx.action<h>(%2734) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2736 = qlx.apply #qlx.action<h>(%2724#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1878 = arith.constant 1.5707963267948966 : f64
    %2737 = qlx.apply #qlx.action<pauli_rotation>(%2736, %cst_1878) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2738 = qlx.apply #qlx.action<h>(%2737) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1879 = arith.constant 1.250000e-01 : f64
    %2739:2 = qlx.apply #qlx.action<pauli_rotation>(%2735, %2738, %cst_1879) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1880 = arith.constant 1.5707963267948966 : f64
    %2740 = qlx.apply #qlx.action<pauli_rotation>(%2733#0, %cst_1880) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2741 = qlx.apply #qlx.action<h>(%2739#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1881 = arith.constant 1.5707963267948966 : f64
    %2742:2 = qlx.apply #qlx.action<pauli_rotation>(%2740, %2741, %cst_1881) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1882 = arith.constant 1.5707963267948966 : f64
    %2743 = qlx.apply #qlx.action<pauli_rotation>(%2742#1, %cst_1882) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2744 = qlx.apply #qlx.action<h>(%2743) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1883 = arith.constant 1.5707963267948966 : f64
    %2745 = qlx.apply #qlx.action<pauli_rotation>(%2744, %cst_1883) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2746 = qlx.apply #qlx.action<h>(%2745) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1884 = arith.constant 1.5707963267948966 : f64
    %2747:2 = qlx.apply #qlx.action<pauli_rotation>(%2739#1, %2746, %cst_1884) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1885 = arith.constant 1.5707963267948966 : f64
    %2748 = qlx.apply #qlx.action<pauli_rotation>(%2747#0, %cst_1885) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2749 = qlx.apply #qlx.action<h>(%2748) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1886 = arith.constant 1.5707963267948966 : f64
    %2750 = qlx.apply #qlx.action<pauli_rotation>(%2712#0, %cst_1886) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2751 = qlx.apply #qlx.action<h>(%2750) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1887 = arith.constant 1.5707963267948966 : f64
    %2752 = qlx.apply #qlx.action<pauli_rotation>(%2751, %cst_1887) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2753 = qlx.apply #qlx.action<h>(%2752) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1888 = arith.constant 1.250000e-01 : f64
    %2754:2 = qlx.apply #qlx.action<pauli_rotation>(%2749, %2753, %cst_1888) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1889 = arith.constant 1.5707963267948966 : f64
    %2755 = qlx.apply #qlx.action<pauli_rotation>(%2747#1, %cst_1889) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2756 = qlx.apply #qlx.action<h>(%2754#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1890 = arith.constant 1.5707963267948966 : f64
    %2757:2 = qlx.apply #qlx.action<pauli_rotation>(%2755, %2756, %cst_1890) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1891 = arith.constant 1.5707963267948966 : f64
    %2758 = qlx.apply #qlx.action<pauli_rotation>(%2757#0, %cst_1891) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2759 = qlx.apply #qlx.action<h>(%2758) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1892 = arith.constant 1.5707963267948966 : f64
    %2760 = qlx.apply #qlx.action<pauli_rotation>(%2759, %cst_1892) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2761 = qlx.apply #qlx.action<h>(%2760) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1893 = arith.constant 1.5707963267948966 : f64
    %2762 = qlx.apply #qlx.action<pauli_rotation>(%2757#1, %cst_1893) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1894 = arith.constant 1.5707963267948966 : f64
    %2763:2 = qlx.apply #qlx.action<pauli_rotation>(%2761, %2762, %cst_1894) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1895 = arith.constant 1.5707963267948966 : f64
    %2764 = qlx.apply #qlx.action<pauli_rotation>(%2763#1, %cst_1895) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2765 = qlx.apply #qlx.action<h>(%2764) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2766 = qlx.apply #qlx.action<h>(%2754#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1896 = arith.constant 1.5707963267948966 : f64
    %2767 = qlx.apply #qlx.action<pauli_rotation>(%2766, %cst_1896) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2768 = qlx.apply #qlx.action<h>(%2767) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1897 = arith.constant 1.250000e-01 : f64
    %2769:2 = qlx.apply #qlx.action<pauli_rotation>(%2765, %2768, %cst_1897) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1898 = arith.constant 1.5707963267948966 : f64
    %2770 = qlx.apply #qlx.action<pauli_rotation>(%2763#0, %cst_1898) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2771 = qlx.apply #qlx.action<h>(%2769#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1899 = arith.constant 1.5707963267948966 : f64
    %2772:2 = qlx.apply #qlx.action<pauli_rotation>(%2770, %2771, %cst_1899) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2773 = qlx.apply #qlx.action<h>(%2769#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1900 = arith.constant 1.5707963267948966 : f64
    %2774 = qlx.apply #qlx.action<pauli_rotation>(%2772#1, %cst_1900) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2775 = qlx.apply #qlx.action<h>(%2774) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1901 = arith.constant 2.500000e-01 : f64
    %2776:2 = qlx.apply #qlx.action<pauli_rotation>(%2773, %2775, %cst_1901) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1902 = arith.constant 1.5707963267948966 : f64
    %2777 = qlx.apply #qlx.action<pauli_rotation>(%2772#0, %cst_1902) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2778 = qlx.apply #qlx.action<h>(%2777) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1903 = arith.constant 1.5707963267948966 : f64
    %2779 = qlx.apply #qlx.action<pauli_rotation>(%2742#0, %cst_1903) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2780 = qlx.apply #qlx.action<h>(%2779) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1904 = arith.constant 1.5707963267948966 : f64
    %2781 = qlx.apply #qlx.action<pauli_rotation>(%2702#1, %cst_1904) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2782 = qlx.apply #qlx.action<h>(%2781) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1905 = arith.constant 1.5707963267948966 : f64
    %2783 = qlx.apply #qlx.action<pauli_rotation>(%2706#1, %cst_1905) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2784 = qlx.apply #qlx.action<h>(%2783) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1906 = arith.constant 1.5707963267948966 : f64
    %2785 = qlx.apply #qlx.action<pauli_rotation>(%2706#0, %cst_1906) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2786 = qlx.apply #qlx.action<h>(%2785) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_1907 = arith.constant 1.5707963267948966 : f64
    %2787 = qlx.apply #qlx.action<pauli_rotation>(%2617#0, %cst_1907) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %2788 = qlx.apply #qlx.action<h>(%2787) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %2789 = qlx.measure <Z> %2776#0 : !qlx.logical_qubit -> i1
    %2790 = qlx.measure <Z> %2776#1 : !qlx.logical_qubit -> i1
    %2791 = qlx.measure <Z> %2778 : !qlx.logical_qubit -> i1
    %2792 = qlx.measure <Z> %2780 : !qlx.logical_qubit -> i1
    %2793 = qlx.measure <Z> %2782 : !qlx.logical_qubit -> i1
    %2794 = qlx.measure <Z> %2784 : !qlx.logical_qubit -> i1
    %2795 = qlx.measure <Z> %2786 : !qlx.logical_qubit -> i1
    %2796 = qlx.measure <Z> %2788 : !qlx.logical_qubit -> i1
  }
}
