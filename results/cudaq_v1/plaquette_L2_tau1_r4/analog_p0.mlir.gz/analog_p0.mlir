module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %10 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %11 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %12:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_0 = arith.constant 2.500000e-01 : f64
    %13:2 = qlx.apply #qlx.action<pauli_rotation>(%2, %9, %cst_0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1 = arith.constant 2.500000e-01 : f64
    %14:2 = qlx.apply #qlx.action<pauli_rotation>(%10, %5, %cst_1) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2 = arith.constant 2.500000e-01 : f64
    %15:2 = qlx.apply #qlx.action<pauli_rotation>(%6, %11, %cst_2) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %16:5 = qlx.apply #qlx.action<pauli_rotation>(%12#0, %12#1, %13#0, %13#1, %14#0, %cst_3) {parameters = {sign = -1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %17:5 = qlx.apply #qlx.action<pauli_rotation>(%16#0, %16#1, %16#2, %16#3, %16#4, %cst_4) {parameters = {sign = 1 : i64, x_mask = 17 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %18 = qlx.apply #qlx.action<z>(%17#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %19:5 = qlx.apply #qlx.action<pauli_rotation>(%14#1, %15#0, %17#2, %17#3, %17#4, %cst_5) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_6 = arith.constant 0.78539816339744828 : f64
    %20:5 = qlx.apply #qlx.action<pauli_rotation>(%19#0, %19#1, %19#2, %19#3, %19#4, %cst_6) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %21 = qlx.apply #qlx.action<z>(%20#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_7 = arith.constant 5.000000e-01 : f64
    %22:3 = qlx.apply #qlx.action<pauli_rotation>(%20#2, %20#3, %20#4, %cst_7) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_8 = arith.constant 5.000000e-01 : f64
    %23:3 = qlx.apply #qlx.action<pauli_rotation>(%22#0, %22#1, %22#2, %cst_8) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_9 = arith.constant 0.78539816339744828 : f64
    %24:5 = qlx.apply #qlx.action<pauli_rotation>(%17#1, %18, %23#0, %23#1, %23#2, %cst_9) {parameters = {sign = -1 : i64, x_mask = 18 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_10 = arith.constant 0.78539816339744828 : f64
    %25:5 = qlx.apply #qlx.action<pauli_rotation>(%24#0, %24#1, %24#2, %24#3, %24#4, %cst_10) {parameters = {sign = 1 : i64, x_mask = 18 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %26 = qlx.apply #qlx.action<z>(%25#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %27:5 = qlx.apply #qlx.action<pauli_rotation>(%20#0, %21, %25#2, %25#3, %25#4, %cst_11) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 0.78539816339744828 : f64
    %28:5 = qlx.apply #qlx.action<pauli_rotation>(%27#0, %27#1, %27#2, %27#3, %27#4, %cst_12) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %29 = qlx.apply #qlx.action<z>(%28#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_13 = arith.constant 0.78539816339744828 : f64
    %30:5 = qlx.apply #qlx.action<pauli_rotation>(%25#0, %28#0, %28#2, %28#3, %28#4, %cst_13) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %31:5 = qlx.apply #qlx.action<pauli_rotation>(%30#0, %30#1, %30#2, %30#3, %30#4, %cst_14) {parameters = {sign = 1 : i64, x_mask = 3 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %32 = qlx.apply #qlx.action<z>(%31#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_15 = arith.constant 0.78539816339744828 : f64
    %33:5 = qlx.apply #qlx.action<pauli_rotation>(%15#1, %29, %31#1, %31#3, %31#4, %cst_15) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_16 = arith.constant 0.78539816339744828 : f64
    %34:5 = qlx.apply #qlx.action<pauli_rotation>(%33#0, %33#1, %33#2, %33#3, %33#4, %cst_16) {parameters = {sign = 1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %35 = qlx.apply #qlx.action<z>(%34#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_17 = arith.constant 5.000000e-01 : f64
    %36:3 = qlx.apply #qlx.action<pauli_rotation>(%34#2, %34#3, %34#4, %cst_17) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 5.000000e-01 : f64
    %37:3 = qlx.apply #qlx.action<pauli_rotation>(%36#0, %36#1, %36#2, %cst_18) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_19 = arith.constant 0.78539816339744828 : f64
    %38:5 = qlx.apply #qlx.action<pauli_rotation>(%31#2, %32, %37#0, %37#1, %37#2, %cst_19) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_20 = arith.constant 0.78539816339744828 : f64
    %39:5 = qlx.apply #qlx.action<pauli_rotation>(%38#0, %38#1, %38#2, %38#3, %38#4, %cst_20) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %40 = qlx.apply #qlx.action<z>(%39#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_21 = arith.constant 0.78539816339744828 : f64
    %41:5 = qlx.apply #qlx.action<pauli_rotation>(%34#1, %35, %39#2, %39#3, %39#4, %cst_21) {parameters = {sign = -1 : i64, x_mask = 10 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %42:5 = qlx.apply #qlx.action<pauli_rotation>(%41#0, %41#1, %41#2, %41#3, %41#4, %cst_22) {parameters = {sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %43 = qlx.apply #qlx.action<z>(%42#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_23 = arith.constant 5.000000e-01 : f64
    %44:2 = qlx.apply #qlx.action<pauli_rotation>(%26, %40, %cst_23) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 5.000000e-01 : f64
    %45:2 = qlx.apply #qlx.action<pauli_rotation>(%39#0, %42#3, %cst_24) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_25 = arith.constant 5.000000e-01 : f64
    %46:2 = qlx.apply #qlx.action<pauli_rotation>(%42#2, %42#4, %cst_25) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_26 = arith.constant 5.000000e-01 : f64
    %47:2 = qlx.apply #qlx.action<pauli_rotation>(%42#0, %43, %cst_26) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_27 = arith.constant 0.78539816339744828 : f64
    %48:5 = qlx.apply #qlx.action<pauli_rotation>(%44#0, %44#1, %45#0, %45#1, %46#1, %cst_27) {parameters = {sign = -1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_28 = arith.constant 0.78539816339744828 : f64
    %49:5 = qlx.apply #qlx.action<pauli_rotation>(%48#0, %48#1, %48#2, %48#3, %48#4, %cst_28) {parameters = {sign = 1 : i64, x_mask = 17 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %50 = qlx.apply #qlx.action<z>(%49#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_29 = arith.constant 0.78539816339744828 : f64
    %51:5 = qlx.apply #qlx.action<pauli_rotation>(%46#0, %47#0, %49#2, %49#3, %49#4, %cst_29) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 0.78539816339744828 : f64
    %52:5 = qlx.apply #qlx.action<pauli_rotation>(%51#0, %51#1, %51#2, %51#3, %51#4, %cst_30) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %53 = qlx.apply #qlx.action<z>(%52#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_31 = arith.constant 5.000000e-01 : f64
    %54:3 = qlx.apply #qlx.action<pauli_rotation>(%52#2, %52#3, %52#4, %cst_31) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_32 = arith.constant 5.000000e-01 : f64
    %55:3 = qlx.apply #qlx.action<pauli_rotation>(%54#0, %54#1, %54#2, %cst_32) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_33 = arith.constant 0.78539816339744828 : f64
    %56:5 = qlx.apply #qlx.action<pauli_rotation>(%49#1, %50, %55#0, %55#1, %55#2, %cst_33) {parameters = {sign = -1 : i64, x_mask = 18 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 0.78539816339744828 : f64
    %57:5 = qlx.apply #qlx.action<pauli_rotation>(%56#0, %56#1, %56#2, %56#3, %56#4, %cst_34) {parameters = {sign = 1 : i64, x_mask = 18 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %58 = qlx.apply #qlx.action<z>(%57#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_35 = arith.constant 0.78539816339744828 : f64
    %59:5 = qlx.apply #qlx.action<pauli_rotation>(%52#0, %53, %57#2, %57#3, %57#4, %cst_35) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_36 = arith.constant 0.78539816339744828 : f64
    %60:5 = qlx.apply #qlx.action<pauli_rotation>(%59#0, %59#1, %59#2, %59#3, %59#4, %cst_36) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %61 = qlx.apply #qlx.action<z>(%60#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_37 = arith.constant 0.78539816339744828 : f64
    %62:5 = qlx.apply #qlx.action<pauli_rotation>(%57#0, %60#0, %60#2, %60#3, %60#4, %cst_37) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_38 = arith.constant 0.78539816339744828 : f64
    %63:5 = qlx.apply #qlx.action<pauli_rotation>(%62#0, %62#1, %62#2, %62#3, %62#4, %cst_38) {parameters = {sign = 1 : i64, x_mask = 3 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %64 = qlx.apply #qlx.action<z>(%63#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_39 = arith.constant 0.78539816339744828 : f64
    %65:5 = qlx.apply #qlx.action<pauli_rotation>(%47#1, %61, %63#1, %63#3, %63#4, %cst_39) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_40 = arith.constant 0.78539816339744828 : f64
    %66:5 = qlx.apply #qlx.action<pauli_rotation>(%65#0, %65#1, %65#2, %65#3, %65#4, %cst_40) {parameters = {sign = 1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %67 = qlx.apply #qlx.action<z>(%66#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_41 = arith.constant 5.000000e-01 : f64
    %68:3 = qlx.apply #qlx.action<pauli_rotation>(%66#2, %66#3, %66#4, %cst_41) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_42 = arith.constant 5.000000e-01 : f64
    %69:3 = qlx.apply #qlx.action<pauli_rotation>(%68#0, %68#1, %68#2, %cst_42) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_43 = arith.constant 0.78539816339744828 : f64
    %70:5 = qlx.apply #qlx.action<pauli_rotation>(%63#2, %64, %69#0, %69#1, %69#2, %cst_43) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_44 = arith.constant 0.78539816339744828 : f64
    %71:5 = qlx.apply #qlx.action<pauli_rotation>(%70#0, %70#1, %70#2, %70#3, %70#4, %cst_44) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %72 = qlx.apply #qlx.action<z>(%71#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_45 = arith.constant 0.78539816339744828 : f64
    %73:5 = qlx.apply #qlx.action<pauli_rotation>(%66#1, %67, %71#2, %71#3, %71#4, %cst_45) {parameters = {sign = -1 : i64, x_mask = 10 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_46 = arith.constant 0.78539816339744828 : f64
    %74:5 = qlx.apply #qlx.action<pauli_rotation>(%73#0, %73#1, %73#2, %73#3, %73#4, %cst_46) {parameters = {sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %75 = qlx.apply #qlx.action<z>(%74#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_47 = arith.constant 5.000000e-01 : f64
    %76:2 = qlx.apply #qlx.action<pauli_rotation>(%58, %72, %cst_47) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_48 = arith.constant 5.000000e-01 : f64
    %77:2 = qlx.apply #qlx.action<pauli_rotation>(%71#0, %74#3, %cst_48) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_49 = arith.constant 5.000000e-01 : f64
    %78:2 = qlx.apply #qlx.action<pauli_rotation>(%74#2, %74#4, %cst_49) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_50 = arith.constant 5.000000e-01 : f64
    %79:2 = qlx.apply #qlx.action<pauli_rotation>(%74#0, %75, %cst_50) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 0.78539816339744828 : f64
    %80:5 = qlx.apply #qlx.action<pauli_rotation>(%76#0, %76#1, %77#0, %77#1, %78#1, %cst_51) {parameters = {sign = -1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_52 = arith.constant 0.78539816339744828 : f64
    %81:5 = qlx.apply #qlx.action<pauli_rotation>(%80#0, %80#1, %80#2, %80#3, %80#4, %cst_52) {parameters = {sign = 1 : i64, x_mask = 17 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %82 = qlx.apply #qlx.action<z>(%81#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_53 = arith.constant 0.78539816339744828 : f64
    %83:5 = qlx.apply #qlx.action<pauli_rotation>(%78#0, %79#0, %81#2, %81#3, %81#4, %cst_53) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_54 = arith.constant 0.78539816339744828 : f64
    %84:5 = qlx.apply #qlx.action<pauli_rotation>(%83#0, %83#1, %83#2, %83#3, %83#4, %cst_54) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %85 = qlx.apply #qlx.action<z>(%84#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_55 = arith.constant 5.000000e-01 : f64
    %86:3 = qlx.apply #qlx.action<pauli_rotation>(%84#2, %84#3, %84#4, %cst_55) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_56 = arith.constant 5.000000e-01 : f64
    %87:3 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %86#1, %86#2, %cst_56) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_57 = arith.constant 0.78539816339744828 : f64
    %88:5 = qlx.apply #qlx.action<pauli_rotation>(%81#1, %82, %87#0, %87#1, %87#2, %cst_57) {parameters = {sign = -1 : i64, x_mask = 18 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_58 = arith.constant 0.78539816339744828 : f64
    %89:5 = qlx.apply #qlx.action<pauli_rotation>(%88#0, %88#1, %88#2, %88#3, %88#4, %cst_58) {parameters = {sign = 1 : i64, x_mask = 18 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %90 = qlx.apply #qlx.action<z>(%89#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_59 = arith.constant 0.78539816339744828 : f64
    %91:5 = qlx.apply #qlx.action<pauli_rotation>(%84#0, %85, %89#2, %89#3, %89#4, %cst_59) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_60 = arith.constant 0.78539816339744828 : f64
    %92:5 = qlx.apply #qlx.action<pauli_rotation>(%91#0, %91#1, %91#2, %91#3, %91#4, %cst_60) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %93 = qlx.apply #qlx.action<z>(%92#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_61 = arith.constant 0.78539816339744828 : f64
    %94:5 = qlx.apply #qlx.action<pauli_rotation>(%89#0, %92#0, %92#2, %92#3, %92#4, %cst_61) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_62 = arith.constant 0.78539816339744828 : f64
    %95:5 = qlx.apply #qlx.action<pauli_rotation>(%94#0, %94#1, %94#2, %94#3, %94#4, %cst_62) {parameters = {sign = 1 : i64, x_mask = 3 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %96 = qlx.apply #qlx.action<z>(%95#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_63 = arith.constant 0.78539816339744828 : f64
    %97:5 = qlx.apply #qlx.action<pauli_rotation>(%79#1, %93, %95#1, %95#3, %95#4, %cst_63) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 0.78539816339744828 : f64
    %98:5 = qlx.apply #qlx.action<pauli_rotation>(%97#0, %97#1, %97#2, %97#3, %97#4, %cst_64) {parameters = {sign = 1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %99 = qlx.apply #qlx.action<z>(%98#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_65 = arith.constant 5.000000e-01 : f64
    %100:3 = qlx.apply #qlx.action<pauli_rotation>(%98#2, %98#3, %98#4, %cst_65) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 5.000000e-01 : f64
    %101:3 = qlx.apply #qlx.action<pauli_rotation>(%100#0, %100#1, %100#2, %cst_66) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_67 = arith.constant 0.78539816339744828 : f64
    %102:5 = qlx.apply #qlx.action<pauli_rotation>(%95#2, %96, %101#0, %101#1, %101#2, %cst_67) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_68 = arith.constant 0.78539816339744828 : f64
    %103:5 = qlx.apply #qlx.action<pauli_rotation>(%102#0, %102#1, %102#2, %102#3, %102#4, %cst_68) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %104 = qlx.apply #qlx.action<z>(%103#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_69 = arith.constant 0.78539816339744828 : f64
    %105:5 = qlx.apply #qlx.action<pauli_rotation>(%98#1, %99, %103#2, %103#3, %103#4, %cst_69) {parameters = {sign = -1 : i64, x_mask = 10 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_70 = arith.constant 0.78539816339744828 : f64
    %106:5 = qlx.apply #qlx.action<pauli_rotation>(%105#0, %105#1, %105#2, %105#3, %105#4, %cst_70) {parameters = {sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %107 = qlx.apply #qlx.action<z>(%106#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_71 = arith.constant 5.000000e-01 : f64
    %108:2 = qlx.apply #qlx.action<pauli_rotation>(%90, %104, %cst_71) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 5.000000e-01 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%103#0, %106#3, %cst_72) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_73 = arith.constant 5.000000e-01 : f64
    %110:2 = qlx.apply #qlx.action<pauli_rotation>(%106#2, %106#4, %cst_73) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 5.000000e-01 : f64
    %111:2 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %107, %cst_74) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_75 = arith.constant 0.78539816339744828 : f64
    %112:5 = qlx.apply #qlx.action<pauli_rotation>(%108#0, %108#1, %109#0, %109#1, %110#1, %cst_75) {parameters = {sign = -1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 0.78539816339744828 : f64
    %113:5 = qlx.apply #qlx.action<pauli_rotation>(%112#0, %112#1, %112#2, %112#3, %112#4, %cst_76) {parameters = {sign = 1 : i64, x_mask = 17 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %114 = qlx.apply #qlx.action<z>(%113#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_77 = arith.constant 0.78539816339744828 : f64
    %115:5 = qlx.apply #qlx.action<pauli_rotation>(%110#0, %111#0, %113#2, %113#3, %113#4, %cst_77) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_78 = arith.constant 0.78539816339744828 : f64
    %116:5 = qlx.apply #qlx.action<pauli_rotation>(%115#0, %115#1, %115#2, %115#3, %115#4, %cst_78) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %117 = qlx.apply #qlx.action<z>(%116#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_79 = arith.constant 5.000000e-01 : f64
    %118:3 = qlx.apply #qlx.action<pauli_rotation>(%116#2, %116#3, %116#4, %cst_79) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_80 = arith.constant 5.000000e-01 : f64
    %119:3 = qlx.apply #qlx.action<pauli_rotation>(%118#0, %118#1, %118#2, %cst_80) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_81 = arith.constant 0.78539816339744828 : f64
    %120:5 = qlx.apply #qlx.action<pauli_rotation>(%113#1, %114, %119#0, %119#1, %119#2, %cst_81) {parameters = {sign = -1 : i64, x_mask = 18 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 0.78539816339744828 : f64
    %121:5 = qlx.apply #qlx.action<pauli_rotation>(%120#0, %120#1, %120#2, %120#3, %120#4, %cst_82) {parameters = {sign = 1 : i64, x_mask = 18 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %122 = qlx.apply #qlx.action<z>(%121#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_83 = arith.constant 0.78539816339744828 : f64
    %123:5 = qlx.apply #qlx.action<pauli_rotation>(%116#0, %117, %121#2, %121#3, %121#4, %cst_83) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_84 = arith.constant 0.78539816339744828 : f64
    %124:5 = qlx.apply #qlx.action<pauli_rotation>(%123#0, %123#1, %123#2, %123#3, %123#4, %cst_84) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %125 = qlx.apply #qlx.action<z>(%124#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_85 = arith.constant 0.78539816339744828 : f64
    %126:5 = qlx.apply #qlx.action<pauli_rotation>(%121#0, %124#0, %124#2, %124#3, %124#4, %cst_85) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_86 = arith.constant 0.78539816339744828 : f64
    %127:5 = qlx.apply #qlx.action<pauli_rotation>(%126#0, %126#1, %126#2, %126#3, %126#4, %cst_86) {parameters = {sign = 1 : i64, x_mask = 3 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %128 = qlx.apply #qlx.action<z>(%127#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_87 = arith.constant 0.78539816339744828 : f64
    %129:5 = qlx.apply #qlx.action<pauli_rotation>(%111#1, %125, %127#1, %127#3, %127#4, %cst_87) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 0.78539816339744828 : f64
    %130:5 = qlx.apply #qlx.action<pauli_rotation>(%129#0, %129#1, %129#2, %129#3, %129#4, %cst_88) {parameters = {sign = 1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %131 = qlx.apply #qlx.action<z>(%130#0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_89 = arith.constant 5.000000e-01 : f64
    %132:3 = qlx.apply #qlx.action<pauli_rotation>(%130#2, %130#3, %130#4, %cst_89) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_90 = arith.constant 5.000000e-01 : f64
    %133:3 = qlx.apply #qlx.action<pauli_rotation>(%132#0, %132#1, %132#2, %cst_90) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_91 = arith.constant 0.78539816339744828 : f64
    %134:5 = qlx.apply #qlx.action<pauli_rotation>(%127#2, %128, %133#0, %133#1, %133#2, %cst_91) {parameters = {sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_92 = arith.constant 0.78539816339744828 : f64
    %135:5 = qlx.apply #qlx.action<pauli_rotation>(%134#0, %134#1, %134#2, %134#3, %134#4, %cst_92) {parameters = {sign = 1 : i64, x_mask = 6 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %136 = qlx.apply #qlx.action<z>(%135#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_93 = arith.constant 0.78539816339744828 : f64
    %137:5 = qlx.apply #qlx.action<pauli_rotation>(%130#1, %131, %135#2, %135#3, %135#4, %cst_93) {parameters = {sign = -1 : i64, x_mask = 10 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 0.78539816339744828 : f64
    %138:5 = qlx.apply #qlx.action<pauli_rotation>(%137#0, %137#1, %137#2, %137#3, %137#4, %cst_94) {parameters = {sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %139 = qlx.apply #qlx.action<z>(%138#1) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst_95 = arith.constant 2.500000e-01 : f64
    %140:2 = qlx.apply #qlx.action<pauli_rotation>(%122, %136, %cst_95) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_96 = arith.constant 2.500000e-01 : f64
    %141:2 = qlx.apply #qlx.action<pauli_rotation>(%135#0, %138#3, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_97 = arith.constant 2.500000e-01 : f64
    %142:2 = qlx.apply #qlx.action<pauli_rotation>(%138#2, %138#4, %cst_97) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_98 = arith.constant 2.500000e-01 : f64
    %143:2 = qlx.apply #qlx.action<pauli_rotation>(%138#0, %139, %cst_98) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %144 = qlx.measure <Z> %140#0 : !qlx.logical_qubit -> i1
    %145 = qlx.measure <Z> %140#1 : !qlx.logical_qubit -> i1
    %146 = qlx.measure <Z> %141#0 : !qlx.logical_qubit -> i1
    %147 = qlx.measure <Z> %141#1 : !qlx.logical_qubit -> i1
    %148 = qlx.measure <Z> %142#1 : !qlx.logical_qubit -> i1
    %149 = qlx.measure <Z> %142#0 : !qlx.logical_qubit -> i1
    %150 = qlx.measure <Z> %143#0 : !qlx.logical_qubit -> i1
    %151 = qlx.measure <Z> %143#1 : !qlx.logical_qubit -> i1
  }
}
