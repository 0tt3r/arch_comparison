module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %cst = arith.constant 0.78539816339744828 : f64
    %8:2 = qlx.apply #qlx.action<pauli_rotation>(%0, %1, %cst) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_0 = arith.constant 0.78539816339744828 : f64
    %9 = qlx.apply #qlx.action<pauli_rotation>(%8#1, %cst_0) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1 = arith.constant 0.78539816339744828 : f64
    %10:2 = qlx.apply #qlx.action<pauli_rotation>(%8#0, %9, %cst_1) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %11:2 = qlx.apply #qlx.action<pauli_rotation>(%10#0, %10#1, %cst_2) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_3 = arith.constant 0.78539816339744828 : f64
    %12:2 = qlx.apply #qlx.action<pauli_rotation>(%11#0, %11#1, %cst_3) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 0.78539816339744828 : f64
    %13 = qlx.apply #qlx.action<pauli_rotation>(%12#1, %cst_4) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_5 = arith.constant 0.78539816339744828 : f64
    %14:2 = qlx.apply #qlx.action<pauli_rotation>(%12#0, %13, %cst_5) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_6 = arith.constant 0.78539816339744828 : f64
    %15 = qlx.apply #qlx.action<pauli_rotation>(%14#1, %cst_6) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_7 = arith.constant 0.78539816339744828 : f64
    %16:2 = qlx.apply #qlx.action<pauli_rotation>(%14#0, %15, %cst_7) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_8 = arith.constant 0.78539816339744828 : f64
    %17 = qlx.apply #qlx.action<pauli_rotation>(%16#1, %cst_8) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_9 = arith.constant 0.78539816339744828 : f64
    %18:2 = qlx.apply #qlx.action<pauli_rotation>(%16#0, %17, %cst_9) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_10 = arith.constant 0.78539816339744828 : f64
    %19 = qlx.apply #qlx.action<pauli_rotation>(%18#1, %cst_10) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_11 = arith.constant 0.78539816339744828 : f64
    %20:2 = qlx.apply #qlx.action<pauli_rotation>(%18#0, %19, %cst_11) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 0.78539816339744828 : f64
    %21 = qlx.apply #qlx.action<pauli_rotation>(%20#1, %cst_12) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_13 = arith.constant 0.78539816339744828 : f64
    %22:2 = qlx.apply #qlx.action<pauli_rotation>(%20#0, %21, %cst_13) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_14 = arith.constant 0.78539816339744828 : f64
    %23 = qlx.apply #qlx.action<pauli_rotation>(%22#1, %cst_14) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_15 = arith.constant 0.78539816339744828 : f64
    %24:2 = qlx.apply #qlx.action<pauli_rotation>(%22#0, %23, %cst_15) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_16 = arith.constant 0.78539816339744828 : f64
    %25 = qlx.apply #qlx.action<pauli_rotation>(%24#1, %cst_16) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_17 = arith.constant 0.78539816339744828 : f64
    %26:2 = qlx.apply #qlx.action<pauli_rotation>(%24#0, %25, %cst_17) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 0.78539816339744828 : f64
    %27 = qlx.apply #qlx.action<pauli_rotation>(%26#1, %cst_18) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_19 = arith.constant 0.78539816339744828 : f64
    %28:2 = qlx.apply #qlx.action<pauli_rotation>(%26#0, %27, %cst_19) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_20 = arith.constant 0.78539816339744828 : f64
    %29:2 = qlx.apply #qlx.action<pauli_rotation>(%28#0, %28#1, %cst_20) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_21 = arith.constant 0.78539816339744828 : f64
    %30:2 = qlx.apply #qlx.action<pauli_rotation>(%29#0, %29#1, %cst_21) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_22 = arith.constant 0.78539816339744828 : f64
    %31:2 = qlx.apply #qlx.action<pauli_rotation>(%30#0, %30#1, %cst_22) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_23 = arith.constant 0.78539816339744828 : f64
    %32:2 = qlx.apply #qlx.action<pauli_rotation>(%31#0, %31#1, %cst_23) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 0.78539816339744828 : f64
    %33:2 = qlx.apply #qlx.action<pauli_rotation>(%32#0, %32#1, %cst_24) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_25 = arith.constant 0.78539816339744828 : f64
    %34 = qlx.apply #qlx.action<pauli_rotation>(%33#1, %cst_25) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_26 = arith.constant 0.78539816339744828 : f64
    %35:2 = qlx.apply #qlx.action<pauli_rotation>(%33#0, %34, %cst_26) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_27 = arith.constant 0.78539816339744828 : f64
    %36 = qlx.apply #qlx.action<pauli_rotation>(%35#1, %cst_27) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_28 = arith.constant 0.78539816339744828 : f64
    %37:2 = qlx.apply #qlx.action<pauli_rotation>(%35#0, %36, %cst_28) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_29 = arith.constant 0.78539816339744828 : f64
    %38:2 = qlx.apply #qlx.action<pauli_rotation>(%37#0, %37#1, %cst_29) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 0.78539816339744828 : f64
    %39 = qlx.apply #qlx.action<pauli_rotation>(%38#1, %cst_30) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_31 = arith.constant 0.78539816339744828 : f64
    %40:2 = qlx.apply #qlx.action<pauli_rotation>(%38#0, %39, %cst_31) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_32 = arith.constant 0.78539816339744828 : f64
    %41 = qlx.apply #qlx.action<pauli_rotation>(%40#1, %cst_32) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_33 = arith.constant 0.78539816339744828 : f64
    %42:2 = qlx.apply #qlx.action<pauli_rotation>(%40#0, %41, %cst_33) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 0.78539816339744828 : f64
    %43:2 = qlx.apply #qlx.action<pauli_rotation>(%42#0, %42#1, %cst_34) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_35 = arith.constant 0.78539816339744828 : f64
    %44:2 = qlx.apply #qlx.action<pauli_rotation>(%43#0, %43#1, %cst_35) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_36 = arith.constant 0.78539816339744828 : f64
    %45:2 = qlx.apply #qlx.action<pauli_rotation>(%44#0, %44#1, %cst_36) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_37 = arith.constant 0.78539816339744828 : f64
    %46:2 = qlx.apply #qlx.action<pauli_rotation>(%45#0, %45#1, %cst_37) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_38 = arith.constant 0.78539816339744828 : f64
    %47:2 = qlx.apply #qlx.action<pauli_rotation>(%46#0, %46#1, %cst_38) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_39 = arith.constant 0.78539816339744828 : f64
    %48 = qlx.apply #qlx.action<pauli_rotation>(%47#1, %cst_39) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_40 = arith.constant 0.78539816339744828 : f64
    %49:2 = qlx.apply #qlx.action<pauli_rotation>(%47#0, %48, %cst_40) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_41 = arith.constant 0.78539816339744828 : f64
    %50 = qlx.apply #qlx.action<pauli_rotation>(%49#1, %cst_41) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_42 = arith.constant 0.78539816339744828 : f64
    %51:2 = qlx.apply #qlx.action<pauli_rotation>(%49#0, %50, %cst_42) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_43 = arith.constant 0.78539816339744828 : f64
    %52 = qlx.apply #qlx.action<pauli_rotation>(%51#1, %cst_43) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_44 = arith.constant 0.78539816339744828 : f64
    %53:2 = qlx.apply #qlx.action<pauli_rotation>(%51#0, %52, %cst_44) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_45 = arith.constant 0.78539816339744828 : f64
    %54 = qlx.apply #qlx.action<pauli_rotation>(%53#1, %cst_45) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_46 = arith.constant 0.78539816339744828 : f64
    %55:2 = qlx.apply #qlx.action<pauli_rotation>(%53#0, %54, %cst_46) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_47 = arith.constant 0.78539816339744828 : f64
    %56 = qlx.apply #qlx.action<pauli_rotation>(%55#1, %cst_47) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_48 = arith.constant 0.78539816339744828 : f64
    %57:2 = qlx.apply #qlx.action<pauli_rotation>(%55#0, %56, %cst_48) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_49 = arith.constant 0.78539816339744828 : f64
    %58 = qlx.apply #qlx.action<pauli_rotation>(%57#1, %cst_49) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_50 = arith.constant 0.78539816339744828 : f64
    %59:2 = qlx.apply #qlx.action<pauli_rotation>(%57#0, %58, %cst_50) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 0.78539816339744828 : f64
    %60 = qlx.apply #qlx.action<pauli_rotation>(%59#1, %cst_51) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_52 = arith.constant 0.78539816339744828 : f64
    %61:2 = qlx.apply #qlx.action<pauli_rotation>(%59#0, %60, %cst_52) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_53 = arith.constant 0.78539816339744828 : f64
    %62 = qlx.apply #qlx.action<pauli_rotation>(%61#1, %cst_53) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_54 = arith.constant 0.78539816339744828 : f64
    %63:2 = qlx.apply #qlx.action<pauli_rotation>(%61#0, %62, %cst_54) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_55 = arith.constant 0.78539816339744828 : f64
    %64:2 = qlx.apply #qlx.action<pauli_rotation>(%63#0, %63#1, %cst_55) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_56 = arith.constant 0.78539816339744828 : f64
    %65:2 = qlx.apply #qlx.action<pauli_rotation>(%64#0, %64#1, %cst_56) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_57 = arith.constant 0.78539816339744828 : f64
    %66 = qlx.apply #qlx.action<pauli_rotation>(%65#1, %cst_57) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_58 = arith.constant 0.78539816339744828 : f64
    %67:2 = qlx.apply #qlx.action<pauli_rotation>(%65#0, %66, %cst_58) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_59 = arith.constant 0.78539816339744828 : f64
    %68:2 = qlx.apply #qlx.action<pauli_rotation>(%2, %3, %cst_59) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_60 = arith.constant 0.78539816339744828 : f64
    %69 = qlx.apply #qlx.action<pauli_rotation>(%68#1, %cst_60) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_61 = arith.constant 0.78539816339744828 : f64
    %70:2 = qlx.apply #qlx.action<pauli_rotation>(%68#0, %69, %cst_61) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_62 = arith.constant 0.78539816339744828 : f64
    %71:2 = qlx.apply #qlx.action<pauli_rotation>(%70#0, %70#1, %cst_62) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_63 = arith.constant 0.78539816339744828 : f64
    %72:2 = qlx.apply #qlx.action<pauli_rotation>(%71#0, %71#1, %cst_63) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 0.78539816339744828 : f64
    %73 = qlx.apply #qlx.action<pauli_rotation>(%72#1, %cst_64) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_65 = arith.constant 0.78539816339744828 : f64
    %74:2 = qlx.apply #qlx.action<pauli_rotation>(%72#0, %73, %cst_65) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 0.78539816339744828 : f64
    %75 = qlx.apply #qlx.action<pauli_rotation>(%74#1, %cst_66) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_67 = arith.constant 0.78539816339744828 : f64
    %76:2 = qlx.apply #qlx.action<pauli_rotation>(%74#0, %75, %cst_67) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_68 = arith.constant 0.78539816339744828 : f64
    %77 = qlx.apply #qlx.action<pauli_rotation>(%76#1, %cst_68) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_69 = arith.constant 0.78539816339744828 : f64
    %78:2 = qlx.apply #qlx.action<pauli_rotation>(%76#0, %77, %cst_69) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_70 = arith.constant 0.78539816339744828 : f64
    %79 = qlx.apply #qlx.action<pauli_rotation>(%78#1, %cst_70) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_71 = arith.constant 0.78539816339744828 : f64
    %80:2 = qlx.apply #qlx.action<pauli_rotation>(%78#0, %79, %cst_71) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 0.78539816339744828 : f64
    %81 = qlx.apply #qlx.action<pauli_rotation>(%80#1, %cst_72) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_73 = arith.constant 0.78539816339744828 : f64
    %82:2 = qlx.apply #qlx.action<pauli_rotation>(%80#0, %81, %cst_73) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 0.78539816339744828 : f64
    %83 = qlx.apply #qlx.action<pauli_rotation>(%82#1, %cst_74) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_75 = arith.constant 0.78539816339744828 : f64
    %84:2 = qlx.apply #qlx.action<pauli_rotation>(%82#0, %83, %cst_75) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 0.78539816339744828 : f64
    %85 = qlx.apply #qlx.action<pauli_rotation>(%84#1, %cst_76) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_77 = arith.constant 0.78539816339744828 : f64
    %86:2 = qlx.apply #qlx.action<pauli_rotation>(%84#0, %85, %cst_77) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_78 = arith.constant 0.78539816339744828 : f64
    %87 = qlx.apply #qlx.action<pauli_rotation>(%86#1, %cst_78) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_79 = arith.constant 0.78539816339744828 : f64
    %88:2 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %87, %cst_79) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_80 = arith.constant 0.78539816339744828 : f64
    %89:2 = qlx.apply #qlx.action<pauli_rotation>(%88#0, %88#1, %cst_80) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_81 = arith.constant 0.78539816339744828 : f64
    %90:2 = qlx.apply #qlx.action<pauli_rotation>(%89#0, %89#1, %cst_81) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 0.78539816339744828 : f64
    %91:2 = qlx.apply #qlx.action<pauli_rotation>(%90#0, %90#1, %cst_82) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_83 = arith.constant 0.78539816339744828 : f64
    %92:2 = qlx.apply #qlx.action<pauli_rotation>(%91#0, %91#1, %cst_83) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_84 = arith.constant 0.78539816339744828 : f64
    %93:2 = qlx.apply #qlx.action<pauli_rotation>(%92#0, %92#1, %cst_84) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_85 = arith.constant 0.78539816339744828 : f64
    %94 = qlx.apply #qlx.action<pauli_rotation>(%93#1, %cst_85) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_86 = arith.constant 0.78539816339744828 : f64
    %95:2 = qlx.apply #qlx.action<pauli_rotation>(%93#0, %94, %cst_86) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_87 = arith.constant 0.78539816339744828 : f64
    %96 = qlx.apply #qlx.action<pauli_rotation>(%95#1, %cst_87) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_88 = arith.constant 0.78539816339744828 : f64
    %97:2 = qlx.apply #qlx.action<pauli_rotation>(%95#0, %96, %cst_88) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_89 = arith.constant 0.78539816339744828 : f64
    %98:2 = qlx.apply #qlx.action<pauli_rotation>(%97#0, %97#1, %cst_89) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_90 = arith.constant 0.78539816339744828 : f64
    %99 = qlx.apply #qlx.action<pauli_rotation>(%98#1, %cst_90) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_91 = arith.constant 0.78539816339744828 : f64
    %100:2 = qlx.apply #qlx.action<pauli_rotation>(%98#0, %99, %cst_91) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_92 = arith.constant 0.78539816339744828 : f64
    %101 = qlx.apply #qlx.action<pauli_rotation>(%100#1, %cst_92) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_93 = arith.constant 0.78539816339744828 : f64
    %102:2 = qlx.apply #qlx.action<pauli_rotation>(%100#0, %101, %cst_93) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 0.78539816339744828 : f64
    %103:2 = qlx.apply #qlx.action<pauli_rotation>(%102#0, %102#1, %cst_94) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_95 = arith.constant 0.78539816339744828 : f64
    %104:2 = qlx.apply #qlx.action<pauli_rotation>(%103#0, %103#1, %cst_95) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_96 = arith.constant 0.78539816339744828 : f64
    %105:2 = qlx.apply #qlx.action<pauli_rotation>(%104#0, %104#1, %cst_96) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_97 = arith.constant 0.78539816339744828 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%105#0, %105#1, %cst_97) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_98 = arith.constant 0.78539816339744828 : f64
    %107:2 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %106#1, %cst_98) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_99 = arith.constant 0.78539816339744828 : f64
    %108 = qlx.apply #qlx.action<pauli_rotation>(%107#1, %cst_99) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_100 = arith.constant 0.78539816339744828 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%107#0, %108, %cst_100) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_101 = arith.constant 0.78539816339744828 : f64
    %110 = qlx.apply #qlx.action<pauli_rotation>(%109#1, %cst_101) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_102 = arith.constant 0.78539816339744828 : f64
    %111:2 = qlx.apply #qlx.action<pauli_rotation>(%109#0, %110, %cst_102) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_103 = arith.constant 0.78539816339744828 : f64
    %112 = qlx.apply #qlx.action<pauli_rotation>(%111#1, %cst_103) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_104 = arith.constant 0.78539816339744828 : f64
    %113:2 = qlx.apply #qlx.action<pauli_rotation>(%111#0, %112, %cst_104) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_105 = arith.constant 0.78539816339744828 : f64
    %114 = qlx.apply #qlx.action<pauli_rotation>(%113#1, %cst_105) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_106 = arith.constant 0.78539816339744828 : f64
    %115:2 = qlx.apply #qlx.action<pauli_rotation>(%113#0, %114, %cst_106) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_107 = arith.constant 0.78539816339744828 : f64
    %116 = qlx.apply #qlx.action<pauli_rotation>(%115#1, %cst_107) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_108 = arith.constant 0.78539816339744828 : f64
    %117:2 = qlx.apply #qlx.action<pauli_rotation>(%115#0, %116, %cst_108) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_109 = arith.constant 0.78539816339744828 : f64
    %118 = qlx.apply #qlx.action<pauli_rotation>(%117#1, %cst_109) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_110 = arith.constant 0.78539816339744828 : f64
    %119:2 = qlx.apply #qlx.action<pauli_rotation>(%117#0, %118, %cst_110) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_111 = arith.constant 0.78539816339744828 : f64
    %120 = qlx.apply #qlx.action<pauli_rotation>(%119#1, %cst_111) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_112 = arith.constant 0.78539816339744828 : f64
    %121:2 = qlx.apply #qlx.action<pauli_rotation>(%119#0, %120, %cst_112) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_113 = arith.constant 0.78539816339744828 : f64
    %122 = qlx.apply #qlx.action<pauli_rotation>(%121#1, %cst_113) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_114 = arith.constant 0.78539816339744828 : f64
    %123:2 = qlx.apply #qlx.action<pauli_rotation>(%121#0, %122, %cst_114) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_115 = arith.constant 0.78539816339744828 : f64
    %124:2 = qlx.apply #qlx.action<pauli_rotation>(%123#0, %123#1, %cst_115) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 0.78539816339744828 : f64
    %125:2 = qlx.apply #qlx.action<pauli_rotation>(%124#0, %124#1, %cst_116) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_117 = arith.constant 0.78539816339744828 : f64
    %126 = qlx.apply #qlx.action<pauli_rotation>(%125#1, %cst_117) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_118 = arith.constant 0.78539816339744828 : f64
    %127:2 = qlx.apply #qlx.action<pauli_rotation>(%125#0, %126, %cst_118) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_119 = arith.constant 0.78539816339744828 : f64
    %128:2 = qlx.apply #qlx.action<pauli_rotation>(%4, %5, %cst_119) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_120 = arith.constant 0.78539816339744828 : f64
    %129 = qlx.apply #qlx.action<pauli_rotation>(%128#1, %cst_120) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_121 = arith.constant 0.78539816339744828 : f64
    %130:2 = qlx.apply #qlx.action<pauli_rotation>(%128#0, %129, %cst_121) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_122 = arith.constant 0.78539816339744828 : f64
    %131:2 = qlx.apply #qlx.action<pauli_rotation>(%130#0, %130#1, %cst_122) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_123 = arith.constant 0.78539816339744828 : f64
    %132:2 = qlx.apply #qlx.action<pauli_rotation>(%131#0, %131#1, %cst_123) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 0.78539816339744828 : f64
    %133 = qlx.apply #qlx.action<pauli_rotation>(%132#1, %cst_124) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_125 = arith.constant 0.78539816339744828 : f64
    %134:2 = qlx.apply #qlx.action<pauli_rotation>(%132#0, %133, %cst_125) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_126 = arith.constant 0.78539816339744828 : f64
    %135 = qlx.apply #qlx.action<pauli_rotation>(%134#1, %cst_126) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_127 = arith.constant 0.78539816339744828 : f64
    %136:2 = qlx.apply #qlx.action<pauli_rotation>(%134#0, %135, %cst_127) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_128 = arith.constant 0.78539816339744828 : f64
    %137 = qlx.apply #qlx.action<pauli_rotation>(%136#1, %cst_128) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_129 = arith.constant 0.78539816339744828 : f64
    %138:2 = qlx.apply #qlx.action<pauli_rotation>(%136#0, %137, %cst_129) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 0.78539816339744828 : f64
    %139 = qlx.apply #qlx.action<pauli_rotation>(%138#1, %cst_130) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_131 = arith.constant 0.78539816339744828 : f64
    %140:2 = qlx.apply #qlx.action<pauli_rotation>(%138#0, %139, %cst_131) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_132 = arith.constant 0.78539816339744828 : f64
    %141 = qlx.apply #qlx.action<pauli_rotation>(%140#1, %cst_132) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_133 = arith.constant 0.78539816339744828 : f64
    %142:2 = qlx.apply #qlx.action<pauli_rotation>(%140#0, %141, %cst_133) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_134 = arith.constant 0.78539816339744828 : f64
    %143 = qlx.apply #qlx.action<pauli_rotation>(%142#1, %cst_134) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_135 = arith.constant 0.78539816339744828 : f64
    %144:2 = qlx.apply #qlx.action<pauli_rotation>(%142#0, %143, %cst_135) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 0.78539816339744828 : f64
    %145 = qlx.apply #qlx.action<pauli_rotation>(%144#1, %cst_136) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_137 = arith.constant 0.78539816339744828 : f64
    %146:2 = qlx.apply #qlx.action<pauli_rotation>(%144#0, %145, %cst_137) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_138 = arith.constant 0.78539816339744828 : f64
    %147 = qlx.apply #qlx.action<pauli_rotation>(%146#1, %cst_138) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_139 = arith.constant 0.78539816339744828 : f64
    %148:2 = qlx.apply #qlx.action<pauli_rotation>(%146#0, %147, %cst_139) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_140 = arith.constant 0.78539816339744828 : f64
    %149:2 = qlx.apply #qlx.action<pauli_rotation>(%148#0, %148#1, %cst_140) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_141 = arith.constant 0.78539816339744828 : f64
    %150:2 = qlx.apply #qlx.action<pauli_rotation>(%149#0, %149#1, %cst_141) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 0.78539816339744828 : f64
    %151:2 = qlx.apply #qlx.action<pauli_rotation>(%150#0, %150#1, %cst_142) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_143 = arith.constant 0.78539816339744828 : f64
    %152:2 = qlx.apply #qlx.action<pauli_rotation>(%151#0, %151#1, %cst_143) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_144 = arith.constant 0.78539816339744828 : f64
    %153:2 = qlx.apply #qlx.action<pauli_rotation>(%152#0, %152#1, %cst_144) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_145 = arith.constant 0.78539816339744828 : f64
    %154 = qlx.apply #qlx.action<pauli_rotation>(%153#1, %cst_145) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_146 = arith.constant 0.78539816339744828 : f64
    %155:2 = qlx.apply #qlx.action<pauli_rotation>(%153#0, %154, %cst_146) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_147 = arith.constant 0.78539816339744828 : f64
    %156 = qlx.apply #qlx.action<pauli_rotation>(%155#1, %cst_147) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_148 = arith.constant 0.78539816339744828 : f64
    %157:2 = qlx.apply #qlx.action<pauli_rotation>(%155#0, %156, %cst_148) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_149 = arith.constant 0.78539816339744828 : f64
    %158:2 = qlx.apply #qlx.action<pauli_rotation>(%157#0, %157#1, %cst_149) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_150 = arith.constant 0.78539816339744828 : f64
    %159 = qlx.apply #qlx.action<pauli_rotation>(%158#1, %cst_150) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_151 = arith.constant 0.78539816339744828 : f64
    %160:2 = qlx.apply #qlx.action<pauli_rotation>(%158#0, %159, %cst_151) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_152 = arith.constant 0.78539816339744828 : f64
    %161 = qlx.apply #qlx.action<pauli_rotation>(%160#1, %cst_152) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_153 = arith.constant 0.78539816339744828 : f64
    %162:2 = qlx.apply #qlx.action<pauli_rotation>(%160#0, %161, %cst_153) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_154 = arith.constant 0.78539816339744828 : f64
    %163:2 = qlx.apply #qlx.action<pauli_rotation>(%162#0, %162#1, %cst_154) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_155 = arith.constant 0.78539816339744828 : f64
    %164:2 = qlx.apply #qlx.action<pauli_rotation>(%163#0, %163#1, %cst_155) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_156 = arith.constant 0.78539816339744828 : f64
    %165:2 = qlx.apply #qlx.action<pauli_rotation>(%164#0, %164#1, %cst_156) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_157 = arith.constant 0.78539816339744828 : f64
    %166:2 = qlx.apply #qlx.action<pauli_rotation>(%165#0, %165#1, %cst_157) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_158 = arith.constant 0.78539816339744828 : f64
    %167:2 = qlx.apply #qlx.action<pauli_rotation>(%166#0, %166#1, %cst_158) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_159 = arith.constant 0.78539816339744828 : f64
    %168 = qlx.apply #qlx.action<pauli_rotation>(%167#1, %cst_159) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_160 = arith.constant 0.78539816339744828 : f64
    %169:2 = qlx.apply #qlx.action<pauli_rotation>(%167#0, %168, %cst_160) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_161 = arith.constant 0.78539816339744828 : f64
    %170 = qlx.apply #qlx.action<pauli_rotation>(%169#1, %cst_161) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_162 = arith.constant 0.78539816339744828 : f64
    %171:2 = qlx.apply #qlx.action<pauli_rotation>(%169#0, %170, %cst_162) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_163 = arith.constant 0.78539816339744828 : f64
    %172 = qlx.apply #qlx.action<pauli_rotation>(%171#1, %cst_163) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_164 = arith.constant 0.78539816339744828 : f64
    %173:2 = qlx.apply #qlx.action<pauli_rotation>(%171#0, %172, %cst_164) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_165 = arith.constant 0.78539816339744828 : f64
    %174 = qlx.apply #qlx.action<pauli_rotation>(%173#1, %cst_165) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_166 = arith.constant 0.78539816339744828 : f64
    %175:2 = qlx.apply #qlx.action<pauli_rotation>(%173#0, %174, %cst_166) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_167 = arith.constant 0.78539816339744828 : f64
    %176 = qlx.apply #qlx.action<pauli_rotation>(%175#1, %cst_167) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_168 = arith.constant 0.78539816339744828 : f64
    %177:2 = qlx.apply #qlx.action<pauli_rotation>(%175#0, %176, %cst_168) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_169 = arith.constant 0.78539816339744828 : f64
    %178 = qlx.apply #qlx.action<pauli_rotation>(%177#1, %cst_169) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_170 = arith.constant 0.78539816339744828 : f64
    %179:2 = qlx.apply #qlx.action<pauli_rotation>(%177#0, %178, %cst_170) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_171 = arith.constant 0.78539816339744828 : f64
    %180 = qlx.apply #qlx.action<pauli_rotation>(%179#1, %cst_171) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_172 = arith.constant 0.78539816339744828 : f64
    %181:2 = qlx.apply #qlx.action<pauli_rotation>(%179#0, %180, %cst_172) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_173 = arith.constant 0.78539816339744828 : f64
    %182 = qlx.apply #qlx.action<pauli_rotation>(%181#1, %cst_173) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_174 = arith.constant 0.78539816339744828 : f64
    %183:2 = qlx.apply #qlx.action<pauli_rotation>(%181#0, %182, %cst_174) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_175 = arith.constant 0.78539816339744828 : f64
    %184:2 = qlx.apply #qlx.action<pauli_rotation>(%183#0, %183#1, %cst_175) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_176 = arith.constant 0.78539816339744828 : f64
    %185:2 = qlx.apply #qlx.action<pauli_rotation>(%184#0, %184#1, %cst_176) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_177 = arith.constant 0.78539816339744828 : f64
    %186 = qlx.apply #qlx.action<pauli_rotation>(%185#1, %cst_177) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_178 = arith.constant 0.78539816339744828 : f64
    %187:2 = qlx.apply #qlx.action<pauli_rotation>(%185#0, %186, %cst_178) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_179 = arith.constant 0.78539816339744828 : f64
    %188:2 = qlx.apply #qlx.action<pauli_rotation>(%6, %7, %cst_179) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_180 = arith.constant 0.78539816339744828 : f64
    %189 = qlx.apply #qlx.action<pauli_rotation>(%188#1, %cst_180) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_181 = arith.constant 0.78539816339744828 : f64
    %190:2 = qlx.apply #qlx.action<pauli_rotation>(%188#0, %189, %cst_181) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_182 = arith.constant 0.78539816339744828 : f64
    %191:2 = qlx.apply #qlx.action<pauli_rotation>(%190#0, %190#1, %cst_182) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_183 = arith.constant 0.78539816339744828 : f64
    %192:2 = qlx.apply #qlx.action<pauli_rotation>(%191#0, %191#1, %cst_183) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_184 = arith.constant 0.78539816339744828 : f64
    %193 = qlx.apply #qlx.action<pauli_rotation>(%192#1, %cst_184) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_185 = arith.constant 0.78539816339744828 : f64
    %194:2 = qlx.apply #qlx.action<pauli_rotation>(%192#0, %193, %cst_185) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_186 = arith.constant 0.78539816339744828 : f64
    %195 = qlx.apply #qlx.action<pauli_rotation>(%194#1, %cst_186) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_187 = arith.constant 0.78539816339744828 : f64
    %196:2 = qlx.apply #qlx.action<pauli_rotation>(%194#0, %195, %cst_187) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_188 = arith.constant 0.78539816339744828 : f64
    %197 = qlx.apply #qlx.action<pauli_rotation>(%196#1, %cst_188) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_189 = arith.constant 0.78539816339744828 : f64
    %198:2 = qlx.apply #qlx.action<pauli_rotation>(%196#0, %197, %cst_189) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_190 = arith.constant 0.78539816339744828 : f64
    %199 = qlx.apply #qlx.action<pauli_rotation>(%198#1, %cst_190) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_191 = arith.constant 0.78539816339744828 : f64
    %200:2 = qlx.apply #qlx.action<pauli_rotation>(%198#0, %199, %cst_191) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_192 = arith.constant 0.78539816339744828 : f64
    %201 = qlx.apply #qlx.action<pauli_rotation>(%200#1, %cst_192) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_193 = arith.constant 0.78539816339744828 : f64
    %202:2 = qlx.apply #qlx.action<pauli_rotation>(%200#0, %201, %cst_193) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_194 = arith.constant 0.78539816339744828 : f64
    %203 = qlx.apply #qlx.action<pauli_rotation>(%202#1, %cst_194) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_195 = arith.constant 0.78539816339744828 : f64
    %204:2 = qlx.apply #qlx.action<pauli_rotation>(%202#0, %203, %cst_195) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_196 = arith.constant 0.78539816339744828 : f64
    %205 = qlx.apply #qlx.action<pauli_rotation>(%204#1, %cst_196) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_197 = arith.constant 0.78539816339744828 : f64
    %206:2 = qlx.apply #qlx.action<pauli_rotation>(%204#0, %205, %cst_197) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_198 = arith.constant 0.78539816339744828 : f64
    %207 = qlx.apply #qlx.action<pauli_rotation>(%206#1, %cst_198) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_199 = arith.constant 0.78539816339744828 : f64
    %208:2 = qlx.apply #qlx.action<pauli_rotation>(%206#0, %207, %cst_199) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_200 = arith.constant 0.78539816339744828 : f64
    %209:2 = qlx.apply #qlx.action<pauli_rotation>(%208#0, %208#1, %cst_200) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_201 = arith.constant 0.78539816339744828 : f64
    %210:2 = qlx.apply #qlx.action<pauli_rotation>(%209#0, %209#1, %cst_201) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_202 = arith.constant 0.78539816339744828 : f64
    %211:2 = qlx.apply #qlx.action<pauli_rotation>(%210#0, %210#1, %cst_202) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_203 = arith.constant 0.78539816339744828 : f64
    %212:2 = qlx.apply #qlx.action<pauli_rotation>(%211#0, %211#1, %cst_203) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_204 = arith.constant 0.78539816339744828 : f64
    %213:2 = qlx.apply #qlx.action<pauli_rotation>(%212#0, %212#1, %cst_204) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_205 = arith.constant 0.78539816339744828 : f64
    %214 = qlx.apply #qlx.action<pauli_rotation>(%213#1, %cst_205) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_206 = arith.constant 0.78539816339744828 : f64
    %215:2 = qlx.apply #qlx.action<pauli_rotation>(%213#0, %214, %cst_206) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_207 = arith.constant 0.78539816339744828 : f64
    %216 = qlx.apply #qlx.action<pauli_rotation>(%215#1, %cst_207) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_208 = arith.constant 0.78539816339744828 : f64
    %217:2 = qlx.apply #qlx.action<pauli_rotation>(%215#0, %216, %cst_208) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_209 = arith.constant 0.78539816339744828 : f64
    %218:2 = qlx.apply #qlx.action<pauli_rotation>(%217#0, %217#1, %cst_209) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_210 = arith.constant 0.78539816339744828 : f64
    %219 = qlx.apply #qlx.action<pauli_rotation>(%218#1, %cst_210) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_211 = arith.constant 0.78539816339744828 : f64
    %220:2 = qlx.apply #qlx.action<pauli_rotation>(%218#0, %219, %cst_211) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_212 = arith.constant 0.78539816339744828 : f64
    %221 = qlx.apply #qlx.action<pauli_rotation>(%220#1, %cst_212) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_213 = arith.constant 0.78539816339744828 : f64
    %222:2 = qlx.apply #qlx.action<pauli_rotation>(%220#0, %221, %cst_213) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_214 = arith.constant 0.78539816339744828 : f64
    %223:2 = qlx.apply #qlx.action<pauli_rotation>(%222#0, %222#1, %cst_214) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_215 = arith.constant 0.78539816339744828 : f64
    %224:2 = qlx.apply #qlx.action<pauli_rotation>(%223#0, %223#1, %cst_215) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_216 = arith.constant 0.78539816339744828 : f64
    %225:2 = qlx.apply #qlx.action<pauli_rotation>(%224#0, %224#1, %cst_216) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_217 = arith.constant 0.78539816339744828 : f64
    %226:2 = qlx.apply #qlx.action<pauli_rotation>(%225#0, %225#1, %cst_217) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_218 = arith.constant 0.78539816339744828 : f64
    %227:2 = qlx.apply #qlx.action<pauli_rotation>(%226#0, %226#1, %cst_218) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_219 = arith.constant 0.78539816339744828 : f64
    %228 = qlx.apply #qlx.action<pauli_rotation>(%227#1, %cst_219) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_220 = arith.constant 0.78539816339744828 : f64
    %229:2 = qlx.apply #qlx.action<pauli_rotation>(%227#0, %228, %cst_220) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_221 = arith.constant 0.78539816339744828 : f64
    %230 = qlx.apply #qlx.action<pauli_rotation>(%229#1, %cst_221) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_222 = arith.constant 0.78539816339744828 : f64
    %231:2 = qlx.apply #qlx.action<pauli_rotation>(%229#0, %230, %cst_222) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_223 = arith.constant 0.78539816339744828 : f64
    %232 = qlx.apply #qlx.action<pauli_rotation>(%231#1, %cst_223) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_224 = arith.constant 0.78539816339744828 : f64
    %233:2 = qlx.apply #qlx.action<pauli_rotation>(%231#0, %232, %cst_224) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_225 = arith.constant 0.78539816339744828 : f64
    %234 = qlx.apply #qlx.action<pauli_rotation>(%233#1, %cst_225) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_226 = arith.constant 0.78539816339744828 : f64
    %235:2 = qlx.apply #qlx.action<pauli_rotation>(%233#0, %234, %cst_226) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_227 = arith.constant 0.78539816339744828 : f64
    %236 = qlx.apply #qlx.action<pauli_rotation>(%235#1, %cst_227) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_228 = arith.constant 0.78539816339744828 : f64
    %237:2 = qlx.apply #qlx.action<pauli_rotation>(%235#0, %236, %cst_228) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_229 = arith.constant 0.78539816339744828 : f64
    %238 = qlx.apply #qlx.action<pauli_rotation>(%237#1, %cst_229) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_230 = arith.constant 0.78539816339744828 : f64
    %239:2 = qlx.apply #qlx.action<pauli_rotation>(%237#0, %238, %cst_230) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_231 = arith.constant 0.78539816339744828 : f64
    %240 = qlx.apply #qlx.action<pauli_rotation>(%239#1, %cst_231) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_232 = arith.constant 0.78539816339744828 : f64
    %241:2 = qlx.apply #qlx.action<pauli_rotation>(%239#0, %240, %cst_232) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_233 = arith.constant 0.78539816339744828 : f64
    %242 = qlx.apply #qlx.action<pauli_rotation>(%241#1, %cst_233) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_234 = arith.constant 0.78539816339744828 : f64
    %243:2 = qlx.apply #qlx.action<pauli_rotation>(%241#0, %242, %cst_234) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_235 = arith.constant 0.78539816339744828 : f64
    %244:2 = qlx.apply #qlx.action<pauli_rotation>(%243#0, %243#1, %cst_235) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_236 = arith.constant 0.78539816339744828 : f64
    %245:2 = qlx.apply #qlx.action<pauli_rotation>(%244#0, %244#1, %cst_236) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_237 = arith.constant 0.78539816339744828 : f64
    %246 = qlx.apply #qlx.action<pauli_rotation>(%245#1, %cst_237) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_238 = arith.constant 0.78539816339744828 : f64
    %247:2 = qlx.apply #qlx.action<pauli_rotation>(%245#0, %246, %cst_238) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_239 = arith.constant 0.78539816339744828 : f64
    %248:5 = qlx.apply #qlx.action<pauli_rotation>(%67#0, %127#0, %127#1, %187#0, %187#1, %cst_239) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_240 = arith.constant 0.78539816339744828 : f64
    %249:5 = qlx.apply #qlx.action<pauli_rotation>(%248#0, %248#1, %248#2, %248#3, %248#4, %cst_240) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_241 = arith.constant 0.78539816339744828 : f64
    %250:5 = qlx.apply #qlx.action<pauli_rotation>(%249#1, %249#3, %249#4, %247#0, %247#1, %cst_241) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_242 = arith.constant 0.78539816339744828 : f64
    %251:5 = qlx.apply #qlx.action<pauli_rotation>(%250#0, %250#1, %250#2, %250#3, %250#4, %cst_242) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_243 = arith.constant 0.78539816339744828 : f64
    %252:3 = qlx.apply #qlx.action<pauli_rotation>(%251#1, %251#3, %251#4, %cst_243) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_244 = arith.constant 0.78539816339744828 : f64
    %253:7 = qlx.apply #qlx.action<pauli_rotation>(%249#0, %251#0, %249#2, %252#0, %251#2, %252#1, %252#2, %cst_244) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_245 = arith.constant 0.78539816339744828 : f64
    %254:5 = qlx.apply #qlx.action<pauli_rotation>(%253#0, %253#1, %253#2, %253#3, %253#4, %cst_245) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_246 = arith.constant 0.78539816339744828 : f64
    %255:3 = qlx.apply #qlx.action<pauli_rotation>(%254#3, %253#5, %253#6, %cst_246) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_247 = arith.constant 0.78539816339744828 : f64
    %256:7 = qlx.apply #qlx.action<pauli_rotation>(%254#0, %254#1, %254#2, %255#0, %254#4, %255#1, %255#2, %cst_247) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_248 = arith.constant 0.78539816339744828 : f64
    %257:3 = qlx.apply #qlx.action<pauli_rotation>(%256#3, %256#5, %256#6, %cst_248) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_249 = arith.constant 0.78539816339744828 : f64
    %258:5 = qlx.apply #qlx.action<pauli_rotation>(%256#0, %256#1, %256#2, %257#0, %256#4, %cst_249) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_250 = arith.constant 0.78539816339744828 : f64
    %259:3 = qlx.apply #qlx.action<pauli_rotation>(%258#3, %257#1, %257#2, %cst_250) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_251 = arith.constant 0.78539816339744828 : f64
    %260:5 = qlx.apply #qlx.action<pauli_rotation>(%258#0, %258#1, %258#2, %259#0, %258#4, %cst_251) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_252 = arith.constant 0.78539816339744828 : f64
    %261:3 = qlx.apply #qlx.action<pauli_rotation>(%260#3, %259#1, %259#2, %cst_252) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_253 = arith.constant 0.78539816339744828 : f64
    %262:5 = qlx.apply #qlx.action<pauli_rotation>(%260#0, %260#1, %260#2, %261#0, %260#4, %cst_253) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_254 = arith.constant 0.78539816339744828 : f64
    %263:3 = qlx.apply #qlx.action<pauli_rotation>(%262#3, %261#1, %261#2, %cst_254) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_255 = arith.constant 0.78539816339744828 : f64
    %264:7 = qlx.apply #qlx.action<pauli_rotation>(%262#0, %262#1, %262#2, %263#0, %262#4, %263#1, %263#2, %cst_255) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_256 = arith.constant 0.78539816339744828 : f64
    %265:5 = qlx.apply #qlx.action<pauli_rotation>(%264#0, %264#1, %264#2, %264#3, %264#4, %cst_256) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_257 = arith.constant 0.78539816339744828 : f64
    %266:7 = qlx.apply #qlx.action<pauli_rotation>(%265#0, %265#1, %265#2, %265#3, %265#4, %264#5, %264#6, %cst_257) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_258 = arith.constant 0.78539816339744828 : f64
    %267:3 = qlx.apply #qlx.action<pauli_rotation>(%266#3, %266#5, %266#6, %cst_258) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_259 = arith.constant 0.78539816339744828 : f64
    %268:7 = qlx.apply #qlx.action<pauli_rotation>(%266#0, %266#1, %266#2, %267#0, %266#4, %267#1, %267#2, %cst_259) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_260 = arith.constant 0.78539816339744828 : f64
    %269:5 = qlx.apply #qlx.action<pauli_rotation>(%268#0, %268#1, %268#2, %268#3, %268#4, %cst_260) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_261 = arith.constant 0.78539816339744828 : f64
    %270:3 = qlx.apply #qlx.action<pauli_rotation>(%269#3, %268#5, %268#6, %cst_261) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_262 = arith.constant 0.78539816339744828 : f64
    %271:5 = qlx.apply #qlx.action<pauli_rotation>(%269#0, %269#1, %269#2, %270#0, %269#4, %cst_262) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_263 = arith.constant 0.78539816339744828 : f64
    %272:3 = qlx.apply #qlx.action<pauli_rotation>(%271#3, %270#1, %270#2, %cst_263) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_264 = arith.constant 0.78539816339744828 : f64
    %273:5 = qlx.apply #qlx.action<pauli_rotation>(%271#0, %271#1, %271#2, %272#0, %271#4, %cst_264) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_265 = arith.constant 0.78539816339744828 : f64
    %274:3 = qlx.apply #qlx.action<pauli_rotation>(%273#3, %272#1, %272#2, %cst_265) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_266 = arith.constant 0.78539816339744828 : f64
    %275:7 = qlx.apply #qlx.action<pauli_rotation>(%273#0, %273#1, %273#2, %274#0, %273#4, %274#1, %274#2, %cst_266) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_267 = arith.constant 0.78539816339744828 : f64
    %276:3 = qlx.apply #qlx.action<pauli_rotation>(%275#3, %275#5, %275#6, %cst_267) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_268 = arith.constant 0.78539816339744828 : f64
    %277:5 = qlx.apply #qlx.action<pauli_rotation>(%275#0, %275#1, %275#2, %276#0, %275#4, %cst_268) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_269 = arith.constant 0.78539816339744828 : f64
    %278:7 = qlx.apply #qlx.action<pauli_rotation>(%277#0, %277#1, %277#2, %277#3, %277#4, %276#1, %276#2, %cst_269) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_270 = arith.constant 0.78539816339744828 : f64
    %279:3 = qlx.apply #qlx.action<pauli_rotation>(%278#3, %278#5, %278#6, %cst_270) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_271 = arith.constant 0.78539816339744828 : f64
    %280:7 = qlx.apply #qlx.action<pauli_rotation>(%278#0, %278#1, %278#2, %279#0, %278#4, %279#1, %279#2, %cst_271) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_272 = arith.constant 0.78539816339744828 : f64
    %281:5 = qlx.apply #qlx.action<pauli_rotation>(%280#0, %280#1, %280#2, %280#3, %280#4, %cst_272) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_273 = arith.constant 0.78539816339744828 : f64
    %282:7 = qlx.apply #qlx.action<pauli_rotation>(%281#0, %281#1, %281#2, %281#3, %281#4, %280#5, %280#6, %cst_273) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_274 = arith.constant 0.78539816339744828 : f64
    %283:3 = qlx.apply #qlx.action<pauli_rotation>(%282#3, %282#5, %282#6, %cst_274) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_275 = arith.constant 0.78539816339744828 : f64
    %284:5 = qlx.apply #qlx.action<pauli_rotation>(%282#0, %282#1, %282#2, %283#0, %282#4, %cst_275) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_276 = arith.constant 0.78539816339744828 : f64
    %285:7 = qlx.apply #qlx.action<pauli_rotation>(%284#0, %284#1, %284#2, %284#3, %284#4, %283#1, %283#2, %cst_276) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_277 = arith.constant 0.78539816339744828 : f64
    %286:5 = qlx.apply #qlx.action<pauli_rotation>(%285#0, %285#1, %285#2, %285#3, %285#4, %cst_277) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_278 = arith.constant 0.78539816339744828 : f64
    %287:3 = qlx.apply #qlx.action<pauli_rotation>(%286#3, %285#5, %285#6, %cst_278) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_279 = arith.constant 0.78539816339744828 : f64
    %288:5 = qlx.apply #qlx.action<pauli_rotation>(%286#0, %286#1, %286#2, %287#0, %286#4, %cst_279) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_280 = arith.constant 0.78539816339744828 : f64
    %289:3 = qlx.apply #qlx.action<pauli_rotation>(%288#3, %287#1, %287#2, %cst_280) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_281 = arith.constant 0.78539816339744828 : f64
    %290:7 = qlx.apply #qlx.action<pauli_rotation>(%288#0, %288#1, %288#2, %289#0, %288#4, %289#1, %289#2, %cst_281) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_282 = arith.constant 0.78539816339744828 : f64
    %291:3 = qlx.apply #qlx.action<pauli_rotation>(%290#3, %290#5, %290#6, %cst_282) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_283 = arith.constant 0.78539816339744828 : f64
    %292:5 = qlx.apply #qlx.action<pauli_rotation>(%290#0, %290#1, %290#2, %291#0, %290#4, %cst_283) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_284 = arith.constant 0.78539816339744828 : f64
    %293:7 = qlx.apply #qlx.action<pauli_rotation>(%292#0, %292#1, %292#2, %292#3, %292#4, %291#1, %291#2, %cst_284) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_285 = arith.constant 0.78539816339744828 : f64
    %294:5 = qlx.apply #qlx.action<pauli_rotation>(%293#0, %293#1, %293#2, %293#3, %293#4, %cst_285) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_286 = arith.constant 0.78539816339744828 : f64
    %295:7 = qlx.apply #qlx.action<pauli_rotation>(%294#0, %294#1, %294#2, %294#3, %294#4, %293#5, %293#6, %cst_286) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_287 = arith.constant 0.78539816339744828 : f64
    %296:3 = qlx.apply #qlx.action<pauli_rotation>(%295#3, %295#5, %295#6, %cst_287) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_288 = arith.constant 0.78539816339744828 : f64
    %297:7 = qlx.apply #qlx.action<pauli_rotation>(%295#0, %295#1, %295#2, %296#0, %295#4, %296#1, %296#2, %cst_288) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_289 = arith.constant 0.78539816339744828 : f64
    %298:3 = qlx.apply #qlx.action<pauli_rotation>(%297#3, %297#5, %297#6, %cst_289) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_290 = arith.constant 0.78539816339744828 : f64
    %299:7 = qlx.apply #qlx.action<pauli_rotation>(%297#0, %297#1, %297#2, %298#0, %297#4, %298#1, %298#2, %cst_290) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_291 = arith.constant 0.78539816339744828 : f64
    %300:5 = qlx.apply #qlx.action<pauli_rotation>(%299#0, %299#1, %299#2, %299#3, %299#4, %cst_291) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_292 = arith.constant 0.78539816339744828 : f64
    %301:3 = qlx.apply #qlx.action<pauli_rotation>(%300#3, %299#5, %299#6, %cst_292) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_293 = arith.constant 0.78539816339744828 : f64
    %302:5 = qlx.apply #qlx.action<pauli_rotation>(%300#0, %300#1, %300#2, %301#0, %300#4, %cst_293) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_294 = arith.constant 0.78539816339744828 : f64
    %303:7 = qlx.apply #qlx.action<pauli_rotation>(%302#0, %302#1, %302#2, %302#3, %302#4, %301#1, %301#2, %cst_294) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_295 = arith.constant 0.78539816339744828 : f64
    %304:5 = qlx.apply #qlx.action<pauli_rotation>(%303#0, %303#1, %303#2, %303#3, %303#4, %cst_295) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_296 = arith.constant 0.78539816339744828 : f64
    %305:3 = qlx.apply #qlx.action<pauli_rotation>(%304#3, %303#5, %303#6, %cst_296) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_297 = arith.constant 0.78539816339744828 : f64
    %306:5 = qlx.apply #qlx.action<pauli_rotation>(%304#0, %304#1, %304#2, %305#0, %304#4, %cst_297) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_298 = arith.constant 0.78539816339744828 : f64
    %307:3 = qlx.apply #qlx.action<pauli_rotation>(%306#3, %305#1, %305#2, %cst_298) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_299 = arith.constant 0.78539816339744828 : f64
    %308:5 = qlx.apply #qlx.action<pauli_rotation>(%306#0, %306#1, %306#2, %307#0, %306#4, %cst_299) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_300 = arith.constant 0.78539816339744828 : f64
    %309:3 = qlx.apply #qlx.action<pauli_rotation>(%308#3, %307#1, %307#2, %cst_300) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_301 = arith.constant 0.78539816339744828 : f64
    %310:5 = qlx.apply #qlx.action<pauli_rotation>(%308#0, %308#1, %308#2, %309#0, %308#4, %cst_301) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_302 = arith.constant 0.78539816339744828 : f64
    %311:7 = qlx.apply #qlx.action<pauli_rotation>(%310#0, %310#1, %310#2, %310#3, %310#4, %309#1, %309#2, %cst_302) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_303 = arith.constant 0.78539816339744828 : f64
    %312:3 = qlx.apply #qlx.action<pauli_rotation>(%311#0, %311#1, %311#2, %cst_303) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_304 = arith.constant 0.78539816339744828 : f64
    %313:3 = qlx.apply #qlx.action<pauli_rotation>(%312#1, %311#3, %311#4, %cst_304) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_305 = arith.constant 0.78539816339744828 : f64
    %314:5 = qlx.apply #qlx.action<pauli_rotation>(%312#0, %313#0, %312#2, %313#1, %313#2, %cst_305) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_306 = arith.constant 0.78539816339744828 : f64
    %315:3 = qlx.apply #qlx.action<pauli_rotation>(%314#0, %314#1, %314#2, %cst_306) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_307 = arith.constant 0.78539816339744828 : f64
    %316:3 = qlx.apply #qlx.action<pauli_rotation>(%315#1, %314#3, %314#4, %cst_307) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_308 = arith.constant 0.78539816339744828 : f64
    %317:3 = qlx.apply #qlx.action<pauli_rotation>(%315#0, %316#0, %315#2, %cst_308) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_309 = arith.constant 0.78539816339744828 : f64
    %318:5 = qlx.apply #qlx.action<pauli_rotation>(%317#0, %317#1, %317#2, %316#1, %316#2, %cst_309) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_310 = arith.constant 0.78539816339744828 : f64
    %319:3 = qlx.apply #qlx.action<pauli_rotation>(%318#0, %318#1, %318#2, %cst_310) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_311 = arith.constant 0.78539816339744828 : f64
    %320:5 = qlx.apply #qlx.action<pauli_rotation>(%319#0, %319#1, %319#2, %318#3, %318#4, %cst_311) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_312 = arith.constant 0.78539816339744828 : f64
    %321:3 = qlx.apply #qlx.action<pauli_rotation>(%320#0, %320#1, %320#2, %cst_312) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_313 = arith.constant 0.78539816339744828 : f64
    %322:5 = qlx.apply #qlx.action<pauli_rotation>(%321#0, %321#1, %321#2, %320#3, %320#4, %cst_313) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_314 = arith.constant 0.78539816339744828 : f64
    %323:3 = qlx.apply #qlx.action<pauli_rotation>(%322#0, %322#1, %322#2, %cst_314) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_315 = arith.constant 0.78539816339744828 : f64
    %324:3 = qlx.apply #qlx.action<pauli_rotation>(%323#1, %322#3, %322#4, %cst_315) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_316 = arith.constant 0.78539816339744828 : f64
    %325:5 = qlx.apply #qlx.action<pauli_rotation>(%323#0, %324#0, %323#2, %324#1, %324#2, %cst_316) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_317 = arith.constant 0.78539816339744828 : f64
    %326:3 = qlx.apply #qlx.action<pauli_rotation>(%325#1, %325#3, %325#4, %cst_317) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_318 = arith.constant 0.78539816339744828 : f64
    %327:3 = qlx.apply #qlx.action<pauli_rotation>(%325#0, %326#0, %325#2, %cst_318) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_319 = arith.constant 0.78539816339744828 : f64
    %328:3 = qlx.apply #qlx.action<pauli_rotation>(%327#1, %326#1, %326#2, %cst_319) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_320 = arith.constant 0.78539816339744828 : f64
    %329:5 = qlx.apply #qlx.action<pauli_rotation>(%327#0, %328#0, %327#2, %328#1, %328#2, %cst_320) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_321 = arith.constant 0.78539816339744828 : f64
    %330:3 = qlx.apply #qlx.action<pauli_rotation>(%329#0, %329#1, %329#2, %cst_321) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_322 = arith.constant 0.78539816339744828 : f64
    %331:5 = qlx.apply #qlx.action<pauli_rotation>(%330#0, %330#1, %330#2, %329#3, %329#4, %cst_322) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_323 = arith.constant 0.78539816339744828 : f64
    %332:3 = qlx.apply #qlx.action<pauli_rotation>(%331#0, %331#1, %331#2, %cst_323) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_324 = arith.constant 0.78539816339744828 : f64
    %333:5 = qlx.apply #qlx.action<pauli_rotation>(%332#0, %332#1, %332#2, %331#3, %331#4, %cst_324) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_325 = arith.constant 0.78539816339744828 : f64
    %334:3 = qlx.apply #qlx.action<pauli_rotation>(%333#0, %333#1, %333#2, %cst_325) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_326 = arith.constant 0.78539816339744828 : f64
    %335:3 = qlx.apply #qlx.action<pauli_rotation>(%334#1, %333#3, %333#4, %cst_326) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_327 = arith.constant 0.78539816339744828 : f64
    %336:3 = qlx.apply #qlx.action<pauli_rotation>(%334#0, %335#0, %334#2, %cst_327) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_328 = arith.constant 0.78539816339744828 : f64
    %337:5 = qlx.apply #qlx.action<pauli_rotation>(%336#0, %336#1, %336#2, %335#1, %335#2, %cst_328) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_329 = arith.constant 0.78539816339744828 : f64
    %338:3 = qlx.apply #qlx.action<pauli_rotation>(%337#1, %337#3, %337#4, %cst_329) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_330 = arith.constant 0.78539816339744828 : f64
    %339:3 = qlx.apply #qlx.action<pauli_rotation>(%337#0, %338#0, %337#2, %cst_330) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_331 = arith.constant 0.78539816339744828 : f64
    %340:3 = qlx.apply #qlx.action<pauli_rotation>(%339#1, %338#1, %338#2, %cst_331) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_332 = arith.constant 0.78539816339744828 : f64
    %341:5 = qlx.apply #qlx.action<pauli_rotation>(%339#0, %340#0, %339#2, %340#1, %340#2, %cst_332) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_333 = arith.constant 0.78539816339744828 : f64
    %342:3 = qlx.apply #qlx.action<pauli_rotation>(%341#1, %341#3, %341#4, %cst_333) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_334 = arith.constant 0.78539816339744828 : f64
    %343:3 = qlx.apply #qlx.action<pauli_rotation>(%341#0, %342#0, %341#2, %cst_334) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_335 = arith.constant 0.78539816339744828 : f64
    %344:5 = qlx.apply #qlx.action<pauli_rotation>(%343#0, %343#1, %343#2, %342#1, %342#2, %cst_335) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_336 = arith.constant 0.78539816339744828 : f64
    %345:3 = qlx.apply #qlx.action<pauli_rotation>(%344#1, %344#3, %344#4, %cst_336) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_337 = arith.constant 0.78539816339744828 : f64
    %346:5 = qlx.apply #qlx.action<pauli_rotation>(%344#0, %345#0, %344#2, %345#1, %345#2, %cst_337) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_338 = arith.constant 0.78539816339744828 : f64
    %347:3 = qlx.apply #qlx.action<pauli_rotation>(%346#0, %346#1, %346#2, %cst_338) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_339 = arith.constant 0.78539816339744828 : f64
    %348:5 = qlx.apply #qlx.action<pauli_rotation>(%347#0, %347#1, %347#2, %346#3, %346#4, %cst_339) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_340 = arith.constant 0.78539816339744828 : f64
    %349:3 = qlx.apply #qlx.action<pauli_rotation>(%348#0, %348#1, %348#2, %cst_340) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_341 = arith.constant 0.78539816339744828 : f64
    %350:3 = qlx.apply #qlx.action<pauli_rotation>(%349#1, %348#3, %348#4, %cst_341) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_342 = arith.constant 0.78539816339744828 : f64
    %351:3 = qlx.apply #qlx.action<pauli_rotation>(%349#0, %350#0, %349#2, %cst_342) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_343 = arith.constant 0.78539816339744828 : f64
    %352:5 = qlx.apply #qlx.action<pauli_rotation>(%351#0, %351#1, %351#2, %350#1, %350#2, %cst_343) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_344 = arith.constant 0.78539816339744828 : f64
    %353:3 = qlx.apply #qlx.action<pauli_rotation>(%352#1, %352#3, %352#4, %cst_344) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_345 = arith.constant 0.78539816339744828 : f64
    %354:5 = qlx.apply #qlx.action<pauli_rotation>(%352#0, %353#0, %352#2, %353#1, %353#2, %cst_345) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_346 = arith.constant 0.78539816339744828 : f64
    %355:3 = qlx.apply #qlx.action<pauli_rotation>(%354#1, %354#3, %354#4, %cst_346) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_347 = arith.constant 0.78539816339744828 : f64
    %356:3 = qlx.apply #qlx.action<pauli_rotation>(%354#0, %355#0, %354#2, %cst_347) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_348 = arith.constant 0.78539816339744828 : f64
    %357:3 = qlx.apply #qlx.action<pauli_rotation>(%356#1, %355#1, %355#2, %cst_348) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_349 = arith.constant 0.78539816339744828 : f64
    %358:3 = qlx.apply #qlx.action<pauli_rotation>(%356#0, %357#0, %356#2, %cst_349) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_350 = arith.constant 0.78539816339744828 : f64
    %359:3 = qlx.apply #qlx.action<pauli_rotation>(%358#1, %357#1, %357#2, %cst_350) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_351 = arith.constant 0.78539816339744828 : f64
    %360:5 = qlx.apply #qlx.action<pauli_rotation>(%358#0, %359#0, %358#2, %359#1, %359#2, %cst_351) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_352 = arith.constant 0.78539816339744828 : f64
    %361:3 = qlx.apply #qlx.action<pauli_rotation>(%360#0, %360#1, %360#2, %cst_352) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_353 = arith.constant 0.78539816339744828 : f64
    %362:5 = qlx.apply #qlx.action<pauli_rotation>(%361#0, %361#1, %361#2, %360#3, %360#4, %cst_353) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_354 = arith.constant 0.78539816339744828 : f64
    %363:3 = qlx.apply #qlx.action<pauli_rotation>(%362#1, %362#3, %362#4, %cst_354) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_355 = arith.constant 0.78539816339744828 : f64
    %364:5 = qlx.apply #qlx.action<pauli_rotation>(%362#0, %363#0, %362#2, %363#1, %363#2, %cst_355) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_356 = arith.constant 0.78539816339744828 : f64
    %365:3 = qlx.apply #qlx.action<pauli_rotation>(%364#0, %364#1, %364#2, %cst_356) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_357 = arith.constant 0.78539816339744828 : f64
    %366:5 = qlx.apply #qlx.action<pauli_rotation>(%365#0, %365#1, %365#2, %364#3, %364#4, %cst_357) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_358 = arith.constant 0.78539816339744828 : f64
    %367:3 = qlx.apply #qlx.action<pauli_rotation>(%366#0, %366#1, %366#2, %cst_358) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_359 = arith.constant 0.78539816339744828 : f64
    %368:5 = qlx.apply #qlx.action<pauli_rotation>(%367#0, %367#1, %367#2, %366#3, %366#4, %cst_359) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_360 = arith.constant 0.78539816339744828 : f64
    %369:3 = qlx.apply #qlx.action<pauli_rotation>(%368#0, %368#1, %368#2, %cst_360) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_361 = arith.constant 0.78539816339744828 : f64
    %370:5 = qlx.apply #qlx.action<pauli_rotation>(%369#0, %369#1, %369#2, %368#3, %368#4, %cst_361) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_362 = arith.constant 0.78539816339744828 : f64
    %371:3 = qlx.apply #qlx.action<pauli_rotation>(%370#1, %370#3, %370#4, %cst_362) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_363 = arith.constant 0.78539816339744828 : f64
    %372:5 = qlx.apply #qlx.action<pauli_rotation>(%370#0, %371#0, %370#2, %371#1, %371#2, %cst_363) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_364 = arith.constant 0.78539816339744828 : f64
    %373:5 = qlx.apply #qlx.action<pauli_rotation>(%372#0, %372#1, %372#2, %372#3, %372#4, %cst_364) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_365 = arith.constant 0.78539816339744828 : f64
    %374:5 = qlx.apply #qlx.action<pauli_rotation>(%373#1, %373#3, %373#4, %311#5, %311#6, %cst_365) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_366 = arith.constant 0.78539816339744828 : f64
    %375:5 = qlx.apply #qlx.action<pauli_rotation>(%374#0, %374#1, %374#2, %374#3, %374#4, %cst_366) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_367 = arith.constant 0.78539816339744828 : f64
    %376:5 = qlx.apply #qlx.action<pauli_rotation>(%373#0, %67#1, %375#0, %373#2, %375#2, %cst_367) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_368 = arith.constant 0.78539816339744828 : f64
    %377:5 = qlx.apply #qlx.action<pauli_rotation>(%376#0, %376#1, %376#2, %376#3, %376#4, %cst_368) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_369 = arith.constant 0.78539816339744828 : f64
    %378:5 = qlx.apply #qlx.action<pauli_rotation>(%377#2, %377#3, %375#1, %377#4, %375#4, %cst_369) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_370 = arith.constant 0.78539816339744828 : f64
    %379:5 = qlx.apply #qlx.action<pauli_rotation>(%378#0, %378#1, %378#2, %378#3, %378#4, %cst_370) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_371 = arith.constant 0.78539816339744828 : f64
    %380:4 = qlx.apply #qlx.action<pauli_rotation>(%379#0, %379#1, %379#2, %379#3, %cst_371) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_372 = arith.constant 0.78539816339744828 : f64
    %381:7 = qlx.apply #qlx.action<pauli_rotation>(%377#0, %377#1, %380#0, %380#1, %380#2, %380#3, %379#4, %cst_372) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_373 = arith.constant 0.78539816339744828 : f64
    %382:6 = qlx.apply #qlx.action<pauli_rotation>(%381#0, %381#1, %381#3, %381#4, %381#5, %381#6, %cst_373) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_374 = arith.constant 0.78539816339744828 : f64
    %383:4 = qlx.apply #qlx.action<pauli_rotation>(%381#2, %382#2, %382#3, %382#4, %cst_374) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_375 = arith.constant 0.78539816339744828 : f64
    %384:7 = qlx.apply #qlx.action<pauli_rotation>(%382#0, %382#1, %383#0, %383#1, %383#2, %383#3, %382#5, %cst_375) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_376 = arith.constant 0.78539816339744828 : f64
    %385:4 = qlx.apply #qlx.action<pauli_rotation>(%384#2, %384#3, %384#4, %384#5, %cst_376) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_377 = arith.constant 0.78539816339744828 : f64
    %386:6 = qlx.apply #qlx.action<pauli_rotation>(%384#0, %384#1, %385#1, %385#2, %385#3, %384#6, %cst_377) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_378 = arith.constant 0.78539816339744828 : f64
    %387:4 = qlx.apply #qlx.action<pauli_rotation>(%385#0, %386#2, %386#3, %386#4, %cst_378) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_379 = arith.constant 0.78539816339744828 : f64
    %388:6 = qlx.apply #qlx.action<pauli_rotation>(%386#0, %386#1, %387#1, %387#2, %387#3, %386#5, %cst_379) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_380 = arith.constant 0.78539816339744828 : f64
    %389:4 = qlx.apply #qlx.action<pauli_rotation>(%387#0, %388#2, %388#3, %388#4, %cst_380) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_381 = arith.constant 0.78539816339744828 : f64
    %390:6 = qlx.apply #qlx.action<pauli_rotation>(%388#0, %388#1, %389#1, %389#2, %389#3, %388#5, %cst_381) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_382 = arith.constant 0.78539816339744828 : f64
    %391:4 = qlx.apply #qlx.action<pauli_rotation>(%389#0, %390#2, %390#3, %390#4, %cst_382) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_383 = arith.constant 0.78539816339744828 : f64
    %392:7 = qlx.apply #qlx.action<pauli_rotation>(%390#0, %390#1, %391#0, %391#1, %391#2, %391#3, %390#5, %cst_383) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_384 = arith.constant 0.78539816339744828 : f64
    %393:6 = qlx.apply #qlx.action<pauli_rotation>(%392#0, %392#1, %392#3, %392#4, %392#5, %392#6, %cst_384) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_385 = arith.constant 0.78539816339744828 : f64
    %394:7 = qlx.apply #qlx.action<pauli_rotation>(%393#0, %393#1, %392#2, %393#2, %393#3, %393#4, %393#5, %cst_385) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_386 = arith.constant 0.78539816339744828 : f64
    %395:4 = qlx.apply #qlx.action<pauli_rotation>(%394#2, %394#3, %394#4, %394#5, %cst_386) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_387 = arith.constant 0.78539816339744828 : f64
    %396:7 = qlx.apply #qlx.action<pauli_rotation>(%394#0, %394#1, %395#0, %395#1, %395#2, %395#3, %394#6, %cst_387) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_388 = arith.constant 0.78539816339744828 : f64
    %397:6 = qlx.apply #qlx.action<pauli_rotation>(%396#0, %396#1, %396#3, %396#4, %396#5, %396#6, %cst_388) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_389 = arith.constant 0.78539816339744828 : f64
    %398:4 = qlx.apply #qlx.action<pauli_rotation>(%396#2, %397#2, %397#3, %397#4, %cst_389) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_390 = arith.constant 0.78539816339744828 : f64
    %399:6 = qlx.apply #qlx.action<pauli_rotation>(%397#0, %397#1, %398#1, %398#2, %398#3, %397#5, %cst_390) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_391 = arith.constant 0.78539816339744828 : f64
    %400:4 = qlx.apply #qlx.action<pauli_rotation>(%398#0, %399#2, %399#3, %399#4, %cst_391) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_392 = arith.constant 0.78539816339744828 : f64
    %401:6 = qlx.apply #qlx.action<pauli_rotation>(%399#0, %399#1, %400#1, %400#2, %400#3, %399#5, %cst_392) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_393 = arith.constant 0.78539816339744828 : f64
    %402:4 = qlx.apply #qlx.action<pauli_rotation>(%400#0, %401#2, %401#3, %401#4, %cst_393) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_394 = arith.constant 0.78539816339744828 : f64
    %403:7 = qlx.apply #qlx.action<pauli_rotation>(%401#0, %401#1, %402#0, %402#1, %402#2, %402#3, %401#5, %cst_394) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_395 = arith.constant 0.78539816339744828 : f64
    %404:4 = qlx.apply #qlx.action<pauli_rotation>(%403#2, %403#3, %403#4, %403#5, %cst_395) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_396 = arith.constant 0.78539816339744828 : f64
    %405:6 = qlx.apply #qlx.action<pauli_rotation>(%403#0, %403#1, %404#1, %404#2, %404#3, %403#6, %cst_396) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_397 = arith.constant 0.78539816339744828 : f64
    %406:7 = qlx.apply #qlx.action<pauli_rotation>(%405#0, %405#1, %404#0, %405#2, %405#3, %405#4, %405#5, %cst_397) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_398 = arith.constant 0.78539816339744828 : f64
    %407:4 = qlx.apply #qlx.action<pauli_rotation>(%406#2, %406#3, %406#4, %406#5, %cst_398) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_399 = arith.constant 0.78539816339744828 : f64
    %408:7 = qlx.apply #qlx.action<pauli_rotation>(%406#0, %406#1, %407#0, %407#1, %407#2, %407#3, %406#6, %cst_399) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_400 = arith.constant 0.78539816339744828 : f64
    %409:6 = qlx.apply #qlx.action<pauli_rotation>(%408#0, %408#1, %408#3, %408#4, %408#5, %408#6, %cst_400) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_401 = arith.constant 0.78539816339744828 : f64
    %410:7 = qlx.apply #qlx.action<pauli_rotation>(%409#0, %409#1, %408#2, %409#2, %409#3, %409#4, %409#5, %cst_401) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_402 = arith.constant 0.78539816339744828 : f64
    %411:4 = qlx.apply #qlx.action<pauli_rotation>(%410#2, %410#3, %410#4, %410#5, %cst_402) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_403 = arith.constant 0.78539816339744828 : f64
    %412:6 = qlx.apply #qlx.action<pauli_rotation>(%410#0, %410#1, %411#1, %411#2, %411#3, %410#6, %cst_403) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_404 = arith.constant 0.78539816339744828 : f64
    %413:7 = qlx.apply #qlx.action<pauli_rotation>(%412#0, %412#1, %411#0, %412#2, %412#3, %412#4, %412#5, %cst_404) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_405 = arith.constant 0.78539816339744828 : f64
    %414:6 = qlx.apply #qlx.action<pauli_rotation>(%413#0, %413#1, %413#3, %413#4, %413#5, %413#6, %cst_405) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_406 = arith.constant 0.78539816339744828 : f64
    %415:4 = qlx.apply #qlx.action<pauli_rotation>(%413#2, %414#2, %414#3, %414#4, %cst_406) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_407 = arith.constant 0.78539816339744828 : f64
    %416:6 = qlx.apply #qlx.action<pauli_rotation>(%414#0, %414#1, %415#1, %415#2, %415#3, %414#5, %cst_407) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_408 = arith.constant 0.78539816339744828 : f64
    %417:4 = qlx.apply #qlx.action<pauli_rotation>(%415#0, %416#2, %416#3, %416#4, %cst_408) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_409 = arith.constant 0.78539816339744828 : f64
    %418:7 = qlx.apply #qlx.action<pauli_rotation>(%416#0, %416#1, %417#0, %417#1, %417#2, %417#3, %416#5, %cst_409) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_410 = arith.constant 0.78539816339744828 : f64
    %419:4 = qlx.apply #qlx.action<pauli_rotation>(%418#2, %418#3, %418#4, %418#5, %cst_410) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_411 = arith.constant 0.78539816339744828 : f64
    %420:6 = qlx.apply #qlx.action<pauli_rotation>(%418#0, %418#1, %419#1, %419#2, %419#3, %418#6, %cst_411) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_412 = arith.constant 0.78539816339744828 : f64
    %421:7 = qlx.apply #qlx.action<pauli_rotation>(%420#0, %420#1, %419#0, %420#2, %420#3, %420#4, %420#5, %cst_412) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_413 = arith.constant 0.78539816339744828 : f64
    %422:6 = qlx.apply #qlx.action<pauli_rotation>(%421#0, %421#1, %421#3, %421#4, %421#5, %421#6, %cst_413) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_414 = arith.constant 0.78539816339744828 : f64
    %423:7 = qlx.apply #qlx.action<pauli_rotation>(%422#0, %422#1, %421#2, %422#2, %422#3, %422#4, %422#5, %cst_414) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_415 = arith.constant 0.78539816339744828 : f64
    %424:4 = qlx.apply #qlx.action<pauli_rotation>(%423#2, %423#3, %423#4, %423#5, %cst_415) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_416 = arith.constant 0.78539816339744828 : f64
    %425:7 = qlx.apply #qlx.action<pauli_rotation>(%423#0, %423#1, %424#0, %424#1, %424#2, %424#3, %423#6, %cst_416) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_417 = arith.constant 0.78539816339744828 : f64
    %426:4 = qlx.apply #qlx.action<pauli_rotation>(%425#2, %425#3, %425#4, %425#5, %cst_417) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_418 = arith.constant 0.78539816339744828 : f64
    %427:7 = qlx.apply #qlx.action<pauli_rotation>(%425#0, %425#1, %426#0, %426#1, %426#2, %426#3, %425#6, %cst_418) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_419 = arith.constant 0.78539816339744828 : f64
    %428:6 = qlx.apply #qlx.action<pauli_rotation>(%427#0, %427#1, %427#3, %427#4, %427#5, %427#6, %cst_419) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_420 = arith.constant 0.78539816339744828 : f64
    %429:4 = qlx.apply #qlx.action<pauli_rotation>(%427#2, %428#2, %428#3, %428#4, %cst_420) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_421 = arith.constant 0.78539816339744828 : f64
    %430:6 = qlx.apply #qlx.action<pauli_rotation>(%428#0, %428#1, %429#1, %429#2, %429#3, %428#5, %cst_421) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_422 = arith.constant 0.78539816339744828 : f64
    %431:7 = qlx.apply #qlx.action<pauli_rotation>(%430#0, %430#1, %429#0, %430#2, %430#3, %430#4, %430#5, %cst_422) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_423 = arith.constant 0.78539816339744828 : f64
    %432:6 = qlx.apply #qlx.action<pauli_rotation>(%431#0, %431#1, %431#3, %431#4, %431#5, %431#6, %cst_423) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_424 = arith.constant 0.78539816339744828 : f64
    %433:4 = qlx.apply #qlx.action<pauli_rotation>(%431#2, %432#2, %432#3, %432#4, %cst_424) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_425 = arith.constant 0.78539816339744828 : f64
    %434:6 = qlx.apply #qlx.action<pauli_rotation>(%432#0, %432#1, %433#1, %433#2, %433#3, %432#5, %cst_425) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_426 = arith.constant 0.78539816339744828 : f64
    %435:4 = qlx.apply #qlx.action<pauli_rotation>(%433#0, %434#2, %434#3, %434#4, %cst_426) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_427 = arith.constant 0.78539816339744828 : f64
    %436:6 = qlx.apply #qlx.action<pauli_rotation>(%434#0, %434#1, %435#1, %435#2, %435#3, %434#5, %cst_427) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_428 = arith.constant 0.78539816339744828 : f64
    %437:4 = qlx.apply #qlx.action<pauli_rotation>(%435#0, %436#2, %436#3, %436#4, %cst_428) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_429 = arith.constant 0.78539816339744828 : f64
    %438:6 = qlx.apply #qlx.action<pauli_rotation>(%436#0, %436#1, %437#1, %437#2, %437#3, %436#5, %cst_429) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_430 = arith.constant 0.78539816339744828 : f64
    %439:7 = qlx.apply #qlx.action<pauli_rotation>(%438#0, %438#1, %437#0, %438#2, %438#3, %438#4, %438#5, %cst_430) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_431 = arith.constant 0.78539816339744828 : f64
    %440:6 = qlx.apply #qlx.action<pauli_rotation>(%439#0, %439#1, %439#2, %439#4, %439#5, %439#6, %cst_431) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_432 = arith.constant 0.78539816339744828 : f64
    %441:3 = qlx.apply #qlx.action<pauli_rotation>(%440#2, %439#3, %440#4, %cst_432) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_433 = arith.constant 0.78539816339744828 : f64
    %442:6 = qlx.apply #qlx.action<pauli_rotation>(%440#0, %440#1, %441#1, %440#3, %441#2, %440#5, %cst_433) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_434 = arith.constant 0.78539816339744828 : f64
    %443:6 = qlx.apply #qlx.action<pauli_rotation>(%442#0, %442#1, %441#0, %442#3, %442#4, %442#5, %cst_434) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_435 = arith.constant 0.78539816339744828 : f64
    %444:3 = qlx.apply #qlx.action<pauli_rotation>(%443#2, %442#2, %443#4, %cst_435) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_436 = arith.constant 0.78539816339744828 : f64
    %445:6 = qlx.apply #qlx.action<pauli_rotation>(%443#0, %443#1, %444#0, %443#3, %444#2, %443#5, %cst_436) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_437 = arith.constant 0.78539816339744828 : f64
    %446:6 = qlx.apply #qlx.action<pauli_rotation>(%445#0, %445#1, %444#1, %445#3, %445#4, %445#5, %cst_437) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_438 = arith.constant 0.78539816339744828 : f64
    %447:6 = qlx.apply #qlx.action<pauli_rotation>(%446#0, %446#1, %445#2, %446#3, %446#4, %446#5, %cst_438) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_439 = arith.constant 0.78539816339744828 : f64
    %448:6 = qlx.apply #qlx.action<pauli_rotation>(%447#0, %447#1, %446#2, %447#3, %447#4, %447#5, %cst_439) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_440 = arith.constant 0.78539816339744828 : f64
    %449:6 = qlx.apply #qlx.action<pauli_rotation>(%448#0, %448#1, %447#2, %448#3, %448#4, %448#5, %cst_440) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_441 = arith.constant 0.78539816339744828 : f64
    %450:6 = qlx.apply #qlx.action<pauli_rotation>(%449#0, %449#1, %448#2, %449#3, %449#4, %449#5, %cst_441) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_442 = arith.constant 0.78539816339744828 : f64
    %451:6 = qlx.apply #qlx.action<pauli_rotation>(%450#0, %450#1, %449#2, %450#3, %450#4, %450#5, %cst_442) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_443 = arith.constant 0.78539816339744828 : f64
    %452:3 = qlx.apply #qlx.action<pauli_rotation>(%451#2, %450#2, %451#4, %cst_443) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_444 = arith.constant 0.78539816339744828 : f64
    %453:6 = qlx.apply #qlx.action<pauli_rotation>(%451#0, %451#1, %452#1, %451#3, %452#2, %451#5, %cst_444) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_445 = arith.constant 0.78539816339744828 : f64
    %454:3 = qlx.apply #qlx.action<pauli_rotation>(%452#0, %453#2, %453#4, %cst_445) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_446 = arith.constant 0.78539816339744828 : f64
    %455:6 = qlx.apply #qlx.action<pauli_rotation>(%453#0, %453#1, %454#0, %453#3, %454#2, %453#5, %cst_446) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_447 = arith.constant 0.78539816339744828 : f64
    %456:3 = qlx.apply #qlx.action<pauli_rotation>(%455#2, %454#1, %455#4, %cst_447) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_448 = arith.constant 0.78539816339744828 : f64
    %457:6 = qlx.apply #qlx.action<pauli_rotation>(%455#0, %455#1, %456#1, %455#3, %456#2, %455#5, %cst_448) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_449 = arith.constant 0.78539816339744828 : f64
    %458:6 = qlx.apply #qlx.action<pauli_rotation>(%457#0, %457#1, %456#0, %457#3, %457#4, %457#5, %cst_449) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_450 = arith.constant 0.78539816339744828 : f64
    %459:6 = qlx.apply #qlx.action<pauli_rotation>(%458#0, %458#1, %457#2, %458#3, %458#4, %458#5, %cst_450) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_451 = arith.constant 0.78539816339744828 : f64
    %460:6 = qlx.apply #qlx.action<pauli_rotation>(%459#0, %459#1, %458#2, %459#3, %459#4, %459#5, %cst_451) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_452 = arith.constant 0.78539816339744828 : f64
    %461:6 = qlx.apply #qlx.action<pauli_rotation>(%460#0, %460#1, %459#2, %460#3, %460#4, %460#5, %cst_452) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_453 = arith.constant 0.78539816339744828 : f64
    %462:6 = qlx.apply #qlx.action<pauli_rotation>(%461#0, %461#1, %460#2, %461#3, %461#4, %461#5, %cst_453) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_454 = arith.constant 0.78539816339744828 : f64
    %463:3 = qlx.apply #qlx.action<pauli_rotation>(%462#2, %461#2, %462#4, %cst_454) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_455 = arith.constant 0.78539816339744828 : f64
    %464:6 = qlx.apply #qlx.action<pauli_rotation>(%462#0, %462#1, %463#0, %462#3, %463#2, %462#5, %cst_455) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_456 = arith.constant 0.78539816339744828 : f64
    %465:6 = qlx.apply #qlx.action<pauli_rotation>(%464#0, %464#1, %463#1, %464#3, %464#4, %464#5, %cst_456) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_457 = arith.constant 0.78539816339744828 : f64
    %466:3 = qlx.apply #qlx.action<pauli_rotation>(%464#2, %465#2, %465#4, %cst_457) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_458 = arith.constant 0.78539816339744828 : f64
    %467:6 = qlx.apply #qlx.action<pauli_rotation>(%465#0, %465#1, %466#0, %465#3, %466#2, %465#5, %cst_458) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_459 = arith.constant 0.78539816339744828 : f64
    %468:3 = qlx.apply #qlx.action<pauli_rotation>(%467#2, %466#1, %467#4, %cst_459) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_460 = arith.constant 0.78539816339744828 : f64
    %469:6 = qlx.apply #qlx.action<pauli_rotation>(%467#0, %467#1, %468#1, %467#3, %468#2, %467#5, %cst_460) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_461 = arith.constant 0.78539816339744828 : f64
    %470:3 = qlx.apply #qlx.action<pauli_rotation>(%468#0, %469#2, %469#4, %cst_461) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_462 = arith.constant 0.78539816339744828 : f64
    %471:6 = qlx.apply #qlx.action<pauli_rotation>(%469#0, %469#1, %470#0, %469#3, %470#2, %469#5, %cst_462) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_463 = arith.constant 0.78539816339744828 : f64
    %472:6 = qlx.apply #qlx.action<pauli_rotation>(%471#0, %471#1, %470#1, %471#3, %471#4, %471#5, %cst_463) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_464 = arith.constant 0.78539816339744828 : f64
    %473:3 = qlx.apply #qlx.action<pauli_rotation>(%471#2, %472#2, %472#4, %cst_464) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_465 = arith.constant 0.78539816339744828 : f64
    %474:6 = qlx.apply #qlx.action<pauli_rotation>(%472#0, %472#1, %473#1, %472#3, %473#2, %472#5, %cst_465) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_466 = arith.constant 0.78539816339744828 : f64
    %475:6 = qlx.apply #qlx.action<pauli_rotation>(%474#0, %474#1, %473#0, %474#3, %474#4, %474#5, %cst_466) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_467 = arith.constant 0.78539816339744828 : f64
    %476:6 = qlx.apply #qlx.action<pauli_rotation>(%475#0, %475#1, %474#2, %475#3, %475#4, %475#5, %cst_467) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_468 = arith.constant 0.78539816339744828 : f64
    %477:6 = qlx.apply #qlx.action<pauli_rotation>(%476#0, %476#1, %475#2, %476#3, %476#4, %476#5, %cst_468) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_469 = arith.constant 0.78539816339744828 : f64
    %478:3 = qlx.apply #qlx.action<pauli_rotation>(%477#2, %476#2, %477#4, %cst_469) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_470 = arith.constant 0.78539816339744828 : f64
    %479:6 = qlx.apply #qlx.action<pauli_rotation>(%477#0, %477#1, %478#0, %477#3, %478#2, %477#5, %cst_470) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_471 = arith.constant 0.78539816339744828 : f64
    %480:6 = qlx.apply #qlx.action<pauli_rotation>(%479#0, %479#1, %478#1, %479#3, %479#4, %479#5, %cst_471) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_472 = arith.constant 0.78539816339744828 : f64
    %481:3 = qlx.apply #qlx.action<pauli_rotation>(%479#2, %480#2, %480#4, %cst_472) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_473 = arith.constant 0.78539816339744828 : f64
    %482:6 = qlx.apply #qlx.action<pauli_rotation>(%480#0, %480#1, %481#1, %480#3, %481#2, %480#5, %cst_473) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_474 = arith.constant 0.78539816339744828 : f64
    %483:3 = qlx.apply #qlx.action<pauli_rotation>(%481#0, %482#2, %482#4, %cst_474) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_475 = arith.constant 0.78539816339744828 : f64
    %484:6 = qlx.apply #qlx.action<pauli_rotation>(%482#0, %482#1, %483#0, %482#3, %483#2, %482#5, %cst_475) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_476 = arith.constant 0.78539816339744828 : f64
    %485:3 = qlx.apply #qlx.action<pauli_rotation>(%484#2, %483#1, %484#4, %cst_476) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_477 = arith.constant 0.78539816339744828 : f64
    %486:6 = qlx.apply #qlx.action<pauli_rotation>(%484#0, %484#1, %485#0, %484#3, %485#2, %484#5, %cst_477) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_478 = arith.constant 0.78539816339744828 : f64
    %487:3 = qlx.apply #qlx.action<pauli_rotation>(%486#2, %485#1, %486#4, %cst_478) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_479 = arith.constant 0.78539816339744828 : f64
    %488:6 = qlx.apply #qlx.action<pauli_rotation>(%486#0, %486#1, %487#1, %486#3, %487#2, %486#5, %cst_479) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_480 = arith.constant 0.78539816339744828 : f64
    %489:6 = qlx.apply #qlx.action<pauli_rotation>(%488#0, %488#1, %487#0, %488#3, %488#4, %488#5, %cst_480) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_481 = arith.constant 0.78539816339744828 : f64
    %490:6 = qlx.apply #qlx.action<pauli_rotation>(%489#0, %489#1, %488#2, %489#3, %489#4, %489#5, %cst_481) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_482 = arith.constant 0.78539816339744828 : f64
    %491:3 = qlx.apply #qlx.action<pauli_rotation>(%489#2, %490#2, %490#4, %cst_482) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_483 = arith.constant 0.78539816339744828 : f64
    %492:6 = qlx.apply #qlx.action<pauli_rotation>(%490#0, %490#1, %491#1, %490#3, %491#2, %490#5, %cst_483) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_484 = arith.constant 0.78539816339744828 : f64
    %493:6 = qlx.apply #qlx.action<pauli_rotation>(%492#0, %492#1, %491#0, %492#3, %492#4, %492#5, %cst_484) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_485 = arith.constant 0.78539816339744828 : f64
    %494:6 = qlx.apply #qlx.action<pauli_rotation>(%493#0, %493#1, %492#2, %493#3, %493#4, %493#5, %cst_485) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_486 = arith.constant 0.78539816339744828 : f64
    %495:6 = qlx.apply #qlx.action<pauli_rotation>(%494#0, %494#1, %493#2, %494#3, %494#4, %494#5, %cst_486) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_487 = arith.constant 0.78539816339744828 : f64
    %496:6 = qlx.apply #qlx.action<pauli_rotation>(%495#0, %495#1, %494#2, %495#3, %495#4, %495#5, %cst_487) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_488 = arith.constant 0.78539816339744828 : f64
    %497:6 = qlx.apply #qlx.action<pauli_rotation>(%496#0, %496#1, %495#2, %496#3, %496#4, %496#5, %cst_488) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_489 = arith.constant 0.78539816339744828 : f64
    %498:6 = qlx.apply #qlx.action<pauli_rotation>(%497#0, %497#1, %496#2, %497#3, %497#4, %497#5, %cst_489) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_490 = arith.constant 0.78539816339744828 : f64
    %499:3 = qlx.apply #qlx.action<pauli_rotation>(%497#2, %498#2, %498#4, %cst_490) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_491 = arith.constant 0.78539816339744828 : f64
    %500:5 = qlx.apply #qlx.action<pauli_rotation>(%498#0, %498#1, %499#0, %499#1, %499#2, %cst_491) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_492 = arith.constant 0.78539816339744828 : f64
    %501:5 = qlx.apply #qlx.action<pauli_rotation>(%500#0, %500#1, %500#2, %500#3, %500#4, %cst_492) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_493 = arith.constant 0.78539816339744828 : f64
    %502:5 = qlx.apply #qlx.action<pauli_rotation>(%501#2, %501#3, %498#3, %501#4, %498#5, %cst_493) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_494 = arith.constant 0.78539816339744828 : f64
    %503:5 = qlx.apply #qlx.action<pauli_rotation>(%502#0, %502#1, %502#2, %502#3, %502#4, %cst_494) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_495 = arith.constant 0.78539816339744828 : f64
    %504:2 = qlx.apply #qlx.action<pauli_rotation>(%501#0, %501#1, %cst_495) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_496 = arith.constant 0.78539816339744828 : f64
    %505:2 = qlx.apply #qlx.action<pauli_rotation>(%504#0, %504#1, %cst_496) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_497 = arith.constant 0.78539816339744828 : f64
    %506:2 = qlx.apply #qlx.action<pauli_rotation>(%505#0, %505#1, %cst_497) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_498 = arith.constant 0.78539816339744828 : f64
    %507 = qlx.apply #qlx.action<pauli_rotation>(%506#1, %cst_498) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_499 = arith.constant 0.78539816339744828 : f64
    %508:2 = qlx.apply #qlx.action<pauli_rotation>(%506#0, %507, %cst_499) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_500 = arith.constant 0.78539816339744828 : f64
    %509:2 = qlx.apply #qlx.action<pauli_rotation>(%508#0, %508#1, %cst_500) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_501 = arith.constant 0.78539816339744828 : f64
    %510 = qlx.apply #qlx.action<pauli_rotation>(%509#1, %cst_501) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_502 = arith.constant 0.78539816339744828 : f64
    %511:2 = qlx.apply #qlx.action<pauli_rotation>(%509#0, %510, %cst_502) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_503 = arith.constant 0.78539816339744828 : f64
    %512 = qlx.apply #qlx.action<pauli_rotation>(%511#1, %cst_503) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_504 = arith.constant 0.78539816339744828 : f64
    %513:2 = qlx.apply #qlx.action<pauli_rotation>(%511#0, %512, %cst_504) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_505 = arith.constant 0.78539816339744828 : f64
    %514:2 = qlx.apply #qlx.action<pauli_rotation>(%513#0, %513#1, %cst_505) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_506 = arith.constant 0.78539816339744828 : f64
    %515 = qlx.apply #qlx.action<pauli_rotation>(%514#1, %cst_506) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_507 = arith.constant 0.78539816339744828 : f64
    %516:2 = qlx.apply #qlx.action<pauli_rotation>(%514#0, %515, %cst_507) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_508 = arith.constant 0.78539816339744828 : f64
    %517:2 = qlx.apply #qlx.action<pauli_rotation>(%516#0, %516#1, %cst_508) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_509 = arith.constant 0.78539816339744828 : f64
    %518 = qlx.apply #qlx.action<pauli_rotation>(%517#1, %cst_509) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_510 = arith.constant 0.78539816339744828 : f64
    %519:2 = qlx.apply #qlx.action<pauli_rotation>(%517#0, %518, %cst_510) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_511 = arith.constant 0.78539816339744828 : f64
    %520 = qlx.apply #qlx.action<pauli_rotation>(%519#1, %cst_511) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_512 = arith.constant 0.78539816339744828 : f64
    %521:2 = qlx.apply #qlx.action<pauli_rotation>(%519#0, %520, %cst_512) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_513 = arith.constant 0.78539816339744828 : f64
    %522:2 = qlx.apply #qlx.action<pauli_rotation>(%521#0, %521#1, %cst_513) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_514 = arith.constant 0.78539816339744828 : f64
    %523:2 = qlx.apply #qlx.action<pauli_rotation>(%522#0, %522#1, %cst_514) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_515 = arith.constant 0.78539816339744828 : f64
    %524:2 = qlx.apply #qlx.action<pauli_rotation>(%523#0, %523#1, %cst_515) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_516 = arith.constant 0.78539816339744828 : f64
    %525:2 = qlx.apply #qlx.action<pauli_rotation>(%524#0, %524#1, %cst_516) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_517 = arith.constant 0.78539816339744828 : f64
    %526:2 = qlx.apply #qlx.action<pauli_rotation>(%525#0, %525#1, %cst_517) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_518 = arith.constant 0.78539816339744828 : f64
    %527:2 = qlx.apply #qlx.action<pauli_rotation>(%526#0, %526#1, %cst_518) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_519 = arith.constant 0.78539816339744828 : f64
    %528 = qlx.apply #qlx.action<pauli_rotation>(%527#1, %cst_519) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_520 = arith.constant 0.78539816339744828 : f64
    %529:2 = qlx.apply #qlx.action<pauli_rotation>(%527#0, %528, %cst_520) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_521 = arith.constant 0.78539816339744828 : f64
    %530 = qlx.apply #qlx.action<pauli_rotation>(%529#1, %cst_521) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_522 = arith.constant 0.78539816339744828 : f64
    %531:2 = qlx.apply #qlx.action<pauli_rotation>(%529#0, %530, %cst_522) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_523 = arith.constant 0.78539816339744828 : f64
    %532:2 = qlx.apply #qlx.action<pauli_rotation>(%531#0, %531#1, %cst_523) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_524 = arith.constant 0.78539816339744828 : f64
    %533:2 = qlx.apply #qlx.action<pauli_rotation>(%532#0, %532#1, %cst_524) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_525 = arith.constant 0.78539816339744828 : f64
    %534:2 = qlx.apply #qlx.action<pauli_rotation>(%533#0, %533#1, %cst_525) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_526 = arith.constant 0.78539816339744828 : f64
    %535:2 = qlx.apply #qlx.action<pauli_rotation>(%534#0, %534#1, %cst_526) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_527 = arith.constant 0.78539816339744828 : f64
    %536:2 = qlx.apply #qlx.action<pauli_rotation>(%535#0, %535#1, %cst_527) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_528 = arith.constant 0.78539816339744828 : f64
    %537 = qlx.apply #qlx.action<pauli_rotation>(%536#1, %cst_528) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_529 = arith.constant 0.78539816339744828 : f64
    %538:2 = qlx.apply #qlx.action<pauli_rotation>(%536#0, %537, %cst_529) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_530 = arith.constant 0.78539816339744828 : f64
    %539 = qlx.apply #qlx.action<pauli_rotation>(%538#1, %cst_530) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_531 = arith.constant 0.78539816339744828 : f64
    %540:2 = qlx.apply #qlx.action<pauli_rotation>(%538#0, %539, %cst_531) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_532 = arith.constant 0.78539816339744828 : f64
    %541 = qlx.apply #qlx.action<pauli_rotation>(%540#1, %cst_532) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_533 = arith.constant 0.78539816339744828 : f64
    %542:2 = qlx.apply #qlx.action<pauli_rotation>(%540#0, %541, %cst_533) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_534 = arith.constant 0.78539816339744828 : f64
    %543:2 = qlx.apply #qlx.action<pauli_rotation>(%542#0, %542#1, %cst_534) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_535 = arith.constant 0.78539816339744828 : f64
    %544:2 = qlx.apply #qlx.action<pauli_rotation>(%543#0, %543#1, %cst_535) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_536 = arith.constant 0.78539816339744828 : f64
    %545 = qlx.apply #qlx.action<pauli_rotation>(%544#1, %cst_536) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_537 = arith.constant 0.78539816339744828 : f64
    %546:2 = qlx.apply #qlx.action<pauli_rotation>(%544#0, %545, %cst_537) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_538 = arith.constant 0.78539816339744828 : f64
    %547:2 = qlx.apply #qlx.action<pauli_rotation>(%546#0, %546#1, %cst_538) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_539 = arith.constant 0.78539816339744828 : f64
    %548:2 = qlx.apply #qlx.action<pauli_rotation>(%547#0, %547#1, %cst_539) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_540 = arith.constant 0.78539816339744828 : f64
    %549 = qlx.apply #qlx.action<pauli_rotation>(%548#1, %cst_540) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_541 = arith.constant 0.78539816339744828 : f64
    %550:2 = qlx.apply #qlx.action<pauli_rotation>(%548#0, %549, %cst_541) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_542 = arith.constant 0.78539816339744828 : f64
    %551:2 = qlx.apply #qlx.action<pauli_rotation>(%550#0, %550#1, %cst_542) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_543 = arith.constant 0.78539816339744828 : f64
    %552:2 = qlx.apply #qlx.action<pauli_rotation>(%551#0, %551#1, %cst_543) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_544 = arith.constant 0.78539816339744828 : f64
    %553 = qlx.apply #qlx.action<pauli_rotation>(%552#1, %cst_544) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_545 = arith.constant 0.78539816339744828 : f64
    %554:2 = qlx.apply #qlx.action<pauli_rotation>(%552#0, %553, %cst_545) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_546 = arith.constant 0.78539816339744828 : f64
    %555:2 = qlx.apply #qlx.action<pauli_rotation>(%554#0, %554#1, %cst_546) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_547 = arith.constant 0.78539816339744828 : f64
    %556:2 = qlx.apply #qlx.action<pauli_rotation>(%555#0, %555#1, %cst_547) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_548 = arith.constant 0.78539816339744828 : f64
    %557 = qlx.apply #qlx.action<pauli_rotation>(%556#1, %cst_548) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_549 = arith.constant 0.78539816339744828 : f64
    %558:2 = qlx.apply #qlx.action<pauli_rotation>(%556#0, %557, %cst_549) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_550 = arith.constant 0.78539816339744828 : f64
    %559:2 = qlx.apply #qlx.action<pauli_rotation>(%558#0, %558#1, %cst_550) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_551 = arith.constant 0.78539816339744828 : f64
    %560 = qlx.apply #qlx.action<pauli_rotation>(%559#1, %cst_551) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_552 = arith.constant 0.78539816339744828 : f64
    %561:2 = qlx.apply #qlx.action<pauli_rotation>(%559#0, %560, %cst_552) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_553 = arith.constant 0.78539816339744828 : f64
    %562:2 = qlx.apply #qlx.action<pauli_rotation>(%561#0, %561#1, %cst_553) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_554 = arith.constant 0.78539816339744828 : f64
    %563:2 = qlx.apply #qlx.action<pauli_rotation>(%562#0, %562#1, %cst_554) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_555 = arith.constant 0.78539816339744828 : f64
    %564:2 = qlx.apply #qlx.action<pauli_rotation>(%503#0, %503#1, %cst_555) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_556 = arith.constant 0.78539816339744828 : f64
    %565:2 = qlx.apply #qlx.action<pauli_rotation>(%564#0, %564#1, %cst_556) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_557 = arith.constant 0.78539816339744828 : f64
    %566:2 = qlx.apply #qlx.action<pauli_rotation>(%565#0, %565#1, %cst_557) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_558 = arith.constant 0.78539816339744828 : f64
    %567 = qlx.apply #qlx.action<pauli_rotation>(%566#1, %cst_558) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_559 = arith.constant 0.78539816339744828 : f64
    %568:2 = qlx.apply #qlx.action<pauli_rotation>(%566#0, %567, %cst_559) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_560 = arith.constant 0.78539816339744828 : f64
    %569:2 = qlx.apply #qlx.action<pauli_rotation>(%568#0, %568#1, %cst_560) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_561 = arith.constant 0.78539816339744828 : f64
    %570 = qlx.apply #qlx.action<pauli_rotation>(%569#1, %cst_561) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_562 = arith.constant 0.78539816339744828 : f64
    %571:2 = qlx.apply #qlx.action<pauli_rotation>(%569#0, %570, %cst_562) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_563 = arith.constant 0.78539816339744828 : f64
    %572 = qlx.apply #qlx.action<pauli_rotation>(%571#1, %cst_563) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_564 = arith.constant 0.78539816339744828 : f64
    %573:2 = qlx.apply #qlx.action<pauli_rotation>(%571#0, %572, %cst_564) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_565 = arith.constant 0.78539816339744828 : f64
    %574:2 = qlx.apply #qlx.action<pauli_rotation>(%573#0, %573#1, %cst_565) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_566 = arith.constant 0.78539816339744828 : f64
    %575 = qlx.apply #qlx.action<pauli_rotation>(%574#1, %cst_566) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_567 = arith.constant 0.78539816339744828 : f64
    %576:2 = qlx.apply #qlx.action<pauli_rotation>(%574#0, %575, %cst_567) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_568 = arith.constant 0.78539816339744828 : f64
    %577:2 = qlx.apply #qlx.action<pauli_rotation>(%576#0, %576#1, %cst_568) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_569 = arith.constant 0.78539816339744828 : f64
    %578 = qlx.apply #qlx.action<pauli_rotation>(%577#1, %cst_569) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_570 = arith.constant 0.78539816339744828 : f64
    %579:2 = qlx.apply #qlx.action<pauli_rotation>(%577#0, %578, %cst_570) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_571 = arith.constant 0.78539816339744828 : f64
    %580 = qlx.apply #qlx.action<pauli_rotation>(%579#1, %cst_571) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_572 = arith.constant 0.78539816339744828 : f64
    %581:2 = qlx.apply #qlx.action<pauli_rotation>(%579#0, %580, %cst_572) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_573 = arith.constant 0.78539816339744828 : f64
    %582:2 = qlx.apply #qlx.action<pauli_rotation>(%581#0, %581#1, %cst_573) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_574 = arith.constant 0.78539816339744828 : f64
    %583:2 = qlx.apply #qlx.action<pauli_rotation>(%582#0, %582#1, %cst_574) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_575 = arith.constant 0.78539816339744828 : f64
    %584:2 = qlx.apply #qlx.action<pauli_rotation>(%583#0, %583#1, %cst_575) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_576 = arith.constant 0.78539816339744828 : f64
    %585:2 = qlx.apply #qlx.action<pauli_rotation>(%584#0, %584#1, %cst_576) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_577 = arith.constant 0.78539816339744828 : f64
    %586:2 = qlx.apply #qlx.action<pauli_rotation>(%585#0, %585#1, %cst_577) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_578 = arith.constant 0.78539816339744828 : f64
    %587:2 = qlx.apply #qlx.action<pauli_rotation>(%586#0, %586#1, %cst_578) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_579 = arith.constant 0.78539816339744828 : f64
    %588 = qlx.apply #qlx.action<pauli_rotation>(%587#1, %cst_579) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_580 = arith.constant 0.78539816339744828 : f64
    %589:2 = qlx.apply #qlx.action<pauli_rotation>(%587#0, %588, %cst_580) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_581 = arith.constant 0.78539816339744828 : f64
    %590 = qlx.apply #qlx.action<pauli_rotation>(%589#1, %cst_581) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_582 = arith.constant 0.78539816339744828 : f64
    %591:2 = qlx.apply #qlx.action<pauli_rotation>(%589#0, %590, %cst_582) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_583 = arith.constant 0.78539816339744828 : f64
    %592:2 = qlx.apply #qlx.action<pauli_rotation>(%591#0, %591#1, %cst_583) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_584 = arith.constant 0.78539816339744828 : f64
    %593:2 = qlx.apply #qlx.action<pauli_rotation>(%592#0, %592#1, %cst_584) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_585 = arith.constant 0.78539816339744828 : f64
    %594:2 = qlx.apply #qlx.action<pauli_rotation>(%593#0, %593#1, %cst_585) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_586 = arith.constant 0.78539816339744828 : f64
    %595:2 = qlx.apply #qlx.action<pauli_rotation>(%594#0, %594#1, %cst_586) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_587 = arith.constant 0.78539816339744828 : f64
    %596:2 = qlx.apply #qlx.action<pauli_rotation>(%595#0, %595#1, %cst_587) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_588 = arith.constant 0.78539816339744828 : f64
    %597 = qlx.apply #qlx.action<pauli_rotation>(%596#1, %cst_588) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_589 = arith.constant 0.78539816339744828 : f64
    %598:2 = qlx.apply #qlx.action<pauli_rotation>(%596#0, %597, %cst_589) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_590 = arith.constant 0.78539816339744828 : f64
    %599 = qlx.apply #qlx.action<pauli_rotation>(%598#1, %cst_590) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_591 = arith.constant 0.78539816339744828 : f64
    %600:2 = qlx.apply #qlx.action<pauli_rotation>(%598#0, %599, %cst_591) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_592 = arith.constant 0.78539816339744828 : f64
    %601 = qlx.apply #qlx.action<pauli_rotation>(%600#1, %cst_592) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_593 = arith.constant 0.78539816339744828 : f64
    %602:2 = qlx.apply #qlx.action<pauli_rotation>(%600#0, %601, %cst_593) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_594 = arith.constant 0.78539816339744828 : f64
    %603:2 = qlx.apply #qlx.action<pauli_rotation>(%602#0, %602#1, %cst_594) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_595 = arith.constant 0.78539816339744828 : f64
    %604:2 = qlx.apply #qlx.action<pauli_rotation>(%603#0, %603#1, %cst_595) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_596 = arith.constant 0.78539816339744828 : f64
    %605 = qlx.apply #qlx.action<pauli_rotation>(%604#1, %cst_596) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_597 = arith.constant 0.78539816339744828 : f64
    %606:2 = qlx.apply #qlx.action<pauli_rotation>(%604#0, %605, %cst_597) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_598 = arith.constant 0.78539816339744828 : f64
    %607:2 = qlx.apply #qlx.action<pauli_rotation>(%606#0, %606#1, %cst_598) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_599 = arith.constant 0.78539816339744828 : f64
    %608:2 = qlx.apply #qlx.action<pauli_rotation>(%607#0, %607#1, %cst_599) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_600 = arith.constant 0.78539816339744828 : f64
    %609 = qlx.apply #qlx.action<pauli_rotation>(%608#1, %cst_600) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_601 = arith.constant 0.78539816339744828 : f64
    %610:2 = qlx.apply #qlx.action<pauli_rotation>(%608#0, %609, %cst_601) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_602 = arith.constant 0.78539816339744828 : f64
    %611:2 = qlx.apply #qlx.action<pauli_rotation>(%610#0, %610#1, %cst_602) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_603 = arith.constant 0.78539816339744828 : f64
    %612:2 = qlx.apply #qlx.action<pauli_rotation>(%611#0, %611#1, %cst_603) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_604 = arith.constant 0.78539816339744828 : f64
    %613 = qlx.apply #qlx.action<pauli_rotation>(%612#1, %cst_604) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_605 = arith.constant 0.78539816339744828 : f64
    %614:2 = qlx.apply #qlx.action<pauli_rotation>(%612#0, %613, %cst_605) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_606 = arith.constant 0.78539816339744828 : f64
    %615:2 = qlx.apply #qlx.action<pauli_rotation>(%614#0, %614#1, %cst_606) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_607 = arith.constant 0.78539816339744828 : f64
    %616:2 = qlx.apply #qlx.action<pauli_rotation>(%615#0, %615#1, %cst_607) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_608 = arith.constant 0.78539816339744828 : f64
    %617 = qlx.apply #qlx.action<pauli_rotation>(%616#1, %cst_608) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_609 = arith.constant 0.78539816339744828 : f64
    %618:2 = qlx.apply #qlx.action<pauli_rotation>(%616#0, %617, %cst_609) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_610 = arith.constant 0.78539816339744828 : f64
    %619:2 = qlx.apply #qlx.action<pauli_rotation>(%618#0, %618#1, %cst_610) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_611 = arith.constant 0.78539816339744828 : f64
    %620 = qlx.apply #qlx.action<pauli_rotation>(%619#1, %cst_611) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_612 = arith.constant 0.78539816339744828 : f64
    %621:2 = qlx.apply #qlx.action<pauli_rotation>(%619#0, %620, %cst_612) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_613 = arith.constant 0.78539816339744828 : f64
    %622:2 = qlx.apply #qlx.action<pauli_rotation>(%621#0, %621#1, %cst_613) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_614 = arith.constant 0.78539816339744828 : f64
    %623:2 = qlx.apply #qlx.action<pauli_rotation>(%622#0, %622#1, %cst_614) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_615 = arith.constant 0.78539816339744828 : f64
    %624:2 = qlx.apply #qlx.action<pauli_rotation>(%503#2, %503#3, %cst_615) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_616 = arith.constant 0.78539816339744828 : f64
    %625:2 = qlx.apply #qlx.action<pauli_rotation>(%624#0, %624#1, %cst_616) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_617 = arith.constant 0.78539816339744828 : f64
    %626:2 = qlx.apply #qlx.action<pauli_rotation>(%625#0, %625#1, %cst_617) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_618 = arith.constant 0.78539816339744828 : f64
    %627 = qlx.apply #qlx.action<pauli_rotation>(%626#0, %cst_618) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_619 = arith.constant 0.78539816339744828 : f64
    %628:2 = qlx.apply #qlx.action<pauli_rotation>(%627, %626#1, %cst_619) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_620 = arith.constant 0.78539816339744828 : f64
    %629:2 = qlx.apply #qlx.action<pauli_rotation>(%628#0, %628#1, %cst_620) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_621 = arith.constant 0.78539816339744828 : f64
    %630 = qlx.apply #qlx.action<pauli_rotation>(%629#0, %cst_621) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_622 = arith.constant 0.78539816339744828 : f64
    %631:2 = qlx.apply #qlx.action<pauli_rotation>(%630, %629#1, %cst_622) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_623 = arith.constant 0.78539816339744828 : f64
    %632 = qlx.apply #qlx.action<pauli_rotation>(%631#0, %cst_623) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_624 = arith.constant 0.78539816339744828 : f64
    %633:2 = qlx.apply #qlx.action<pauli_rotation>(%632, %631#1, %cst_624) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_625 = arith.constant 0.78539816339744828 : f64
    %634:2 = qlx.apply #qlx.action<pauli_rotation>(%633#0, %633#1, %cst_625) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_626 = arith.constant 0.78539816339744828 : f64
    %635 = qlx.apply #qlx.action<pauli_rotation>(%634#0, %cst_626) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_627 = arith.constant 0.78539816339744828 : f64
    %636:2 = qlx.apply #qlx.action<pauli_rotation>(%635, %634#1, %cst_627) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_628 = arith.constant 0.78539816339744828 : f64
    %637:2 = qlx.apply #qlx.action<pauli_rotation>(%636#0, %636#1, %cst_628) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_629 = arith.constant 0.78539816339744828 : f64
    %638 = qlx.apply #qlx.action<pauli_rotation>(%637#0, %cst_629) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_630 = arith.constant 0.78539816339744828 : f64
    %639:2 = qlx.apply #qlx.action<pauli_rotation>(%638, %637#1, %cst_630) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_631 = arith.constant 0.78539816339744828 : f64
    %640 = qlx.apply #qlx.action<pauli_rotation>(%639#0, %cst_631) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_632 = arith.constant 0.78539816339744828 : f64
    %641:2 = qlx.apply #qlx.action<pauli_rotation>(%640, %639#1, %cst_632) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_633 = arith.constant 0.78539816339744828 : f64
    %642:2 = qlx.apply #qlx.action<pauli_rotation>(%641#0, %641#1, %cst_633) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_634 = arith.constant 0.78539816339744828 : f64
    %643:2 = qlx.apply #qlx.action<pauli_rotation>(%642#0, %642#1, %cst_634) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_635 = arith.constant 0.78539816339744828 : f64
    %644:2 = qlx.apply #qlx.action<pauli_rotation>(%643#0, %643#1, %cst_635) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_636 = arith.constant 0.78539816339744828 : f64
    %645:2 = qlx.apply #qlx.action<pauli_rotation>(%644#0, %644#1, %cst_636) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_637 = arith.constant 0.78539816339744828 : f64
    %646:2 = qlx.apply #qlx.action<pauli_rotation>(%645#0, %645#1, %cst_637) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_638 = arith.constant 0.78539816339744828 : f64
    %647:2 = qlx.apply #qlx.action<pauli_rotation>(%646#0, %646#1, %cst_638) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_639 = arith.constant 0.78539816339744828 : f64
    %648 = qlx.apply #qlx.action<pauli_rotation>(%647#0, %cst_639) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_640 = arith.constant 0.78539816339744828 : f64
    %649:2 = qlx.apply #qlx.action<pauli_rotation>(%648, %647#1, %cst_640) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_641 = arith.constant 0.78539816339744828 : f64
    %650 = qlx.apply #qlx.action<pauli_rotation>(%649#0, %cst_641) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_642 = arith.constant 0.78539816339744828 : f64
    %651:2 = qlx.apply #qlx.action<pauli_rotation>(%650, %649#1, %cst_642) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_643 = arith.constant 0.78539816339744828 : f64
    %652:2 = qlx.apply #qlx.action<pauli_rotation>(%651#0, %651#1, %cst_643) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_644 = arith.constant 0.78539816339744828 : f64
    %653:2 = qlx.apply #qlx.action<pauli_rotation>(%652#0, %652#1, %cst_644) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_645 = arith.constant 0.78539816339744828 : f64
    %654:2 = qlx.apply #qlx.action<pauli_rotation>(%653#0, %653#1, %cst_645) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_646 = arith.constant 0.78539816339744828 : f64
    %655:2 = qlx.apply #qlx.action<pauli_rotation>(%654#0, %654#1, %cst_646) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_647 = arith.constant 0.78539816339744828 : f64
    %656:2 = qlx.apply #qlx.action<pauli_rotation>(%655#0, %655#1, %cst_647) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_648 = arith.constant 0.78539816339744828 : f64
    %657 = qlx.apply #qlx.action<pauli_rotation>(%656#0, %cst_648) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_649 = arith.constant 0.78539816339744828 : f64
    %658:2 = qlx.apply #qlx.action<pauli_rotation>(%657, %656#1, %cst_649) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_650 = arith.constant 0.78539816339744828 : f64
    %659 = qlx.apply #qlx.action<pauli_rotation>(%658#0, %cst_650) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_651 = arith.constant 0.78539816339744828 : f64
    %660:2 = qlx.apply #qlx.action<pauli_rotation>(%659, %658#1, %cst_651) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_652 = arith.constant 0.78539816339744828 : f64
    %661 = qlx.apply #qlx.action<pauli_rotation>(%660#0, %cst_652) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_653 = arith.constant 0.78539816339744828 : f64
    %662:2 = qlx.apply #qlx.action<pauli_rotation>(%661, %660#1, %cst_653) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_654 = arith.constant 0.78539816339744828 : f64
    %663:2 = qlx.apply #qlx.action<pauli_rotation>(%662#0, %662#1, %cst_654) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_655 = arith.constant 0.78539816339744828 : f64
    %664:2 = qlx.apply #qlx.action<pauli_rotation>(%663#0, %663#1, %cst_655) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_656 = arith.constant 0.78539816339744828 : f64
    %665 = qlx.apply #qlx.action<pauli_rotation>(%664#0, %cst_656) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_657 = arith.constant 0.78539816339744828 : f64
    %666:2 = qlx.apply #qlx.action<pauli_rotation>(%665, %664#1, %cst_657) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_658 = arith.constant 0.78539816339744828 : f64
    %667:2 = qlx.apply #qlx.action<pauli_rotation>(%666#0, %666#1, %cst_658) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_659 = arith.constant 0.78539816339744828 : f64
    %668:2 = qlx.apply #qlx.action<pauli_rotation>(%667#0, %667#1, %cst_659) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_660 = arith.constant 0.78539816339744828 : f64
    %669 = qlx.apply #qlx.action<pauli_rotation>(%668#0, %cst_660) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_661 = arith.constant 0.78539816339744828 : f64
    %670:2 = qlx.apply #qlx.action<pauli_rotation>(%669, %668#1, %cst_661) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_662 = arith.constant 0.78539816339744828 : f64
    %671:2 = qlx.apply #qlx.action<pauli_rotation>(%670#0, %670#1, %cst_662) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_663 = arith.constant 0.78539816339744828 : f64
    %672:2 = qlx.apply #qlx.action<pauli_rotation>(%671#0, %671#1, %cst_663) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_664 = arith.constant 0.78539816339744828 : f64
    %673 = qlx.apply #qlx.action<pauli_rotation>(%672#0, %cst_664) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_665 = arith.constant 0.78539816339744828 : f64
    %674:2 = qlx.apply #qlx.action<pauli_rotation>(%673, %672#1, %cst_665) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_666 = arith.constant 0.78539816339744828 : f64
    %675:2 = qlx.apply #qlx.action<pauli_rotation>(%674#0, %674#1, %cst_666) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_667 = arith.constant 0.78539816339744828 : f64
    %676:2 = qlx.apply #qlx.action<pauli_rotation>(%675#0, %675#1, %cst_667) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_668 = arith.constant 0.78539816339744828 : f64
    %677 = qlx.apply #qlx.action<pauli_rotation>(%676#0, %cst_668) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_669 = arith.constant 0.78539816339744828 : f64
    %678:2 = qlx.apply #qlx.action<pauli_rotation>(%677, %676#1, %cst_669) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_670 = arith.constant 0.78539816339744828 : f64
    %679:2 = qlx.apply #qlx.action<pauli_rotation>(%678#0, %678#1, %cst_670) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_671 = arith.constant 0.78539816339744828 : f64
    %680 = qlx.apply #qlx.action<pauli_rotation>(%679#0, %cst_671) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_672 = arith.constant 0.78539816339744828 : f64
    %681:2 = qlx.apply #qlx.action<pauli_rotation>(%680, %679#1, %cst_672) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_673 = arith.constant 0.78539816339744828 : f64
    %682:2 = qlx.apply #qlx.action<pauli_rotation>(%681#0, %681#1, %cst_673) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_674 = arith.constant 0.78539816339744828 : f64
    %683:2 = qlx.apply #qlx.action<pauli_rotation>(%682#0, %682#1, %cst_674) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_675 = arith.constant 0.78539816339744828 : f64
    %684:2 = qlx.apply #qlx.action<pauli_rotation>(%375#3, %503#4, %cst_675) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_676 = arith.constant 0.78539816339744828 : f64
    %685:2 = qlx.apply #qlx.action<pauli_rotation>(%684#0, %684#1, %cst_676) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_677 = arith.constant 0.78539816339744828 : f64
    %686:2 = qlx.apply #qlx.action<pauli_rotation>(%685#0, %685#1, %cst_677) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_678 = arith.constant 0.78539816339744828 : f64
    %687 = qlx.apply #qlx.action<pauli_rotation>(%686#1, %cst_678) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_679 = arith.constant 0.78539816339744828 : f64
    %688:2 = qlx.apply #qlx.action<pauli_rotation>(%686#0, %687, %cst_679) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_680 = arith.constant 0.78539816339744828 : f64
    %689:2 = qlx.apply #qlx.action<pauli_rotation>(%688#0, %688#1, %cst_680) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_681 = arith.constant 0.78539816339744828 : f64
    %690 = qlx.apply #qlx.action<pauli_rotation>(%689#1, %cst_681) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_682 = arith.constant 0.78539816339744828 : f64
    %691:2 = qlx.apply #qlx.action<pauli_rotation>(%689#0, %690, %cst_682) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_683 = arith.constant 0.78539816339744828 : f64
    %692 = qlx.apply #qlx.action<pauli_rotation>(%691#1, %cst_683) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_684 = arith.constant 0.78539816339744828 : f64
    %693:2 = qlx.apply #qlx.action<pauli_rotation>(%691#0, %692, %cst_684) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_685 = arith.constant 0.78539816339744828 : f64
    %694:2 = qlx.apply #qlx.action<pauli_rotation>(%693#0, %693#1, %cst_685) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_686 = arith.constant 0.78539816339744828 : f64
    %695 = qlx.apply #qlx.action<pauli_rotation>(%694#1, %cst_686) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_687 = arith.constant 0.78539816339744828 : f64
    %696:2 = qlx.apply #qlx.action<pauli_rotation>(%694#0, %695, %cst_687) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_688 = arith.constant 0.78539816339744828 : f64
    %697:2 = qlx.apply #qlx.action<pauli_rotation>(%696#0, %696#1, %cst_688) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_689 = arith.constant 0.78539816339744828 : f64
    %698 = qlx.apply #qlx.action<pauli_rotation>(%697#1, %cst_689) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_690 = arith.constant 0.78539816339744828 : f64
    %699:2 = qlx.apply #qlx.action<pauli_rotation>(%697#0, %698, %cst_690) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_691 = arith.constant 0.78539816339744828 : f64
    %700 = qlx.apply #qlx.action<pauli_rotation>(%699#1, %cst_691) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_692 = arith.constant 0.78539816339744828 : f64
    %701:2 = qlx.apply #qlx.action<pauli_rotation>(%699#0, %700, %cst_692) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_693 = arith.constant 0.78539816339744828 : f64
    %702:2 = qlx.apply #qlx.action<pauli_rotation>(%701#0, %701#1, %cst_693) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_694 = arith.constant 0.78539816339744828 : f64
    %703:2 = qlx.apply #qlx.action<pauli_rotation>(%702#0, %702#1, %cst_694) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_695 = arith.constant 0.78539816339744828 : f64
    %704:2 = qlx.apply #qlx.action<pauli_rotation>(%703#0, %703#1, %cst_695) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_696 = arith.constant 0.78539816339744828 : f64
    %705:2 = qlx.apply #qlx.action<pauli_rotation>(%704#0, %704#1, %cst_696) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_697 = arith.constant 0.78539816339744828 : f64
    %706:2 = qlx.apply #qlx.action<pauli_rotation>(%705#0, %705#1, %cst_697) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_698 = arith.constant 0.78539816339744828 : f64
    %707:2 = qlx.apply #qlx.action<pauli_rotation>(%706#0, %706#1, %cst_698) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_699 = arith.constant 0.78539816339744828 : f64
    %708 = qlx.apply #qlx.action<pauli_rotation>(%707#1, %cst_699) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_700 = arith.constant 0.78539816339744828 : f64
    %709:2 = qlx.apply #qlx.action<pauli_rotation>(%707#0, %708, %cst_700) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_701 = arith.constant 0.78539816339744828 : f64
    %710 = qlx.apply #qlx.action<pauli_rotation>(%709#1, %cst_701) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_702 = arith.constant 0.78539816339744828 : f64
    %711:2 = qlx.apply #qlx.action<pauli_rotation>(%709#0, %710, %cst_702) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_703 = arith.constant 0.78539816339744828 : f64
    %712:2 = qlx.apply #qlx.action<pauli_rotation>(%711#0, %711#1, %cst_703) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_704 = arith.constant 0.78539816339744828 : f64
    %713:2 = qlx.apply #qlx.action<pauli_rotation>(%712#0, %712#1, %cst_704) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_705 = arith.constant 0.78539816339744828 : f64
    %714:2 = qlx.apply #qlx.action<pauli_rotation>(%713#0, %713#1, %cst_705) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_706 = arith.constant 0.78539816339744828 : f64
    %715:2 = qlx.apply #qlx.action<pauli_rotation>(%714#0, %714#1, %cst_706) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_707 = arith.constant 0.78539816339744828 : f64
    %716:2 = qlx.apply #qlx.action<pauli_rotation>(%715#0, %715#1, %cst_707) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_708 = arith.constant 0.78539816339744828 : f64
    %717 = qlx.apply #qlx.action<pauli_rotation>(%716#1, %cst_708) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_709 = arith.constant 0.78539816339744828 : f64
    %718:2 = qlx.apply #qlx.action<pauli_rotation>(%716#0, %717, %cst_709) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_710 = arith.constant 0.78539816339744828 : f64
    %719 = qlx.apply #qlx.action<pauli_rotation>(%718#1, %cst_710) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_711 = arith.constant 0.78539816339744828 : f64
    %720:2 = qlx.apply #qlx.action<pauli_rotation>(%718#0, %719, %cst_711) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_712 = arith.constant 0.78539816339744828 : f64
    %721 = qlx.apply #qlx.action<pauli_rotation>(%720#1, %cst_712) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_713 = arith.constant 0.78539816339744828 : f64
    %722:2 = qlx.apply #qlx.action<pauli_rotation>(%720#0, %721, %cst_713) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_714 = arith.constant 0.78539816339744828 : f64
    %723:2 = qlx.apply #qlx.action<pauli_rotation>(%722#0, %722#1, %cst_714) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_715 = arith.constant 0.78539816339744828 : f64
    %724:2 = qlx.apply #qlx.action<pauli_rotation>(%723#0, %723#1, %cst_715) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_716 = arith.constant 0.78539816339744828 : f64
    %725 = qlx.apply #qlx.action<pauli_rotation>(%724#1, %cst_716) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_717 = arith.constant 0.78539816339744828 : f64
    %726:2 = qlx.apply #qlx.action<pauli_rotation>(%724#0, %725, %cst_717) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_718 = arith.constant 0.78539816339744828 : f64
    %727:2 = qlx.apply #qlx.action<pauli_rotation>(%726#0, %726#1, %cst_718) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_719 = arith.constant 0.78539816339744828 : f64
    %728:2 = qlx.apply #qlx.action<pauli_rotation>(%727#0, %727#1, %cst_719) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_720 = arith.constant 0.78539816339744828 : f64
    %729 = qlx.apply #qlx.action<pauli_rotation>(%728#1, %cst_720) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_721 = arith.constant 0.78539816339744828 : f64
    %730:2 = qlx.apply #qlx.action<pauli_rotation>(%728#0, %729, %cst_721) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_722 = arith.constant 0.78539816339744828 : f64
    %731:2 = qlx.apply #qlx.action<pauli_rotation>(%730#0, %730#1, %cst_722) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_723 = arith.constant 0.78539816339744828 : f64
    %732:2 = qlx.apply #qlx.action<pauli_rotation>(%731#0, %731#1, %cst_723) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_724 = arith.constant 0.78539816339744828 : f64
    %733 = qlx.apply #qlx.action<pauli_rotation>(%732#1, %cst_724) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_725 = arith.constant 0.78539816339744828 : f64
    %734:2 = qlx.apply #qlx.action<pauli_rotation>(%732#0, %733, %cst_725) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_726 = arith.constant 0.78539816339744828 : f64
    %735:2 = qlx.apply #qlx.action<pauli_rotation>(%734#0, %734#1, %cst_726) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_727 = arith.constant 0.78539816339744828 : f64
    %736:2 = qlx.apply #qlx.action<pauli_rotation>(%735#0, %735#1, %cst_727) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_728 = arith.constant 0.78539816339744828 : f64
    %737 = qlx.apply #qlx.action<pauli_rotation>(%736#1, %cst_728) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_729 = arith.constant 0.78539816339744828 : f64
    %738:2 = qlx.apply #qlx.action<pauli_rotation>(%736#0, %737, %cst_729) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_730 = arith.constant 0.78539816339744828 : f64
    %739:2 = qlx.apply #qlx.action<pauli_rotation>(%738#0, %738#1, %cst_730) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_731 = arith.constant 0.78539816339744828 : f64
    %740 = qlx.apply #qlx.action<pauli_rotation>(%739#1, %cst_731) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_732 = arith.constant 0.78539816339744828 : f64
    %741:2 = qlx.apply #qlx.action<pauli_rotation>(%739#0, %740, %cst_732) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_733 = arith.constant 0.78539816339744828 : f64
    %742:2 = qlx.apply #qlx.action<pauli_rotation>(%741#0, %741#1, %cst_733) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_734 = arith.constant 0.78539816339744828 : f64
    %743:2 = qlx.apply #qlx.action<pauli_rotation>(%742#0, %742#1, %cst_734) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_735 = arith.constant 0.78539816339744828 : f64
    %744:5 = qlx.apply #qlx.action<pauli_rotation>(%563#0, %563#1, %623#1, %683#0, %683#1, %cst_735) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 23 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_736 = arith.constant 0.78539816339744828 : f64
    %745:4 = qlx.apply #qlx.action<pauli_rotation>(%744#0, %744#1, %744#2, %744#3, %cst_736) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 10 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_737 = arith.constant 0.78539816339744828 : f64
    %746:5 = qlx.apply #qlx.action<pauli_rotation>(%623#0, %745#2, %745#3, %743#0, %743#1, %cst_737) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 18 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_738 = arith.constant 0.78539816339744828 : f64
    %747:5 = qlx.apply #qlx.action<pauli_rotation>(%746#0, %746#1, %746#2, %746#3, %746#4, %cst_738) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_739 = arith.constant 0.78539816339744828 : f64
    %748:3 = qlx.apply #qlx.action<pauli_rotation>(%747#2, %747#3, %747#4, %cst_739) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_740 = arith.constant 0.78539816339744828 : f64
    %749:6 = qlx.apply #qlx.action<pauli_rotation>(%745#0, %745#1, %747#1, %748#0, %748#1, %748#2, %cst_740) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_741 = arith.constant 0.78539816339744828 : f64
    %750:4 = qlx.apply #qlx.action<pauli_rotation>(%749#0, %749#1, %749#2, %749#3, %cst_741) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_742 = arith.constant 0.78539816339744828 : f64
    %751:3 = qlx.apply #qlx.action<pauli_rotation>(%750#3, %749#4, %749#5, %cst_742) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_743 = arith.constant 0.78539816339744828 : f64
    %752:6 = qlx.apply #qlx.action<pauli_rotation>(%750#0, %750#1, %750#2, %751#0, %751#1, %751#2, %cst_743) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_744 = arith.constant 0.78539816339744828 : f64
    %753:3 = qlx.apply #qlx.action<pauli_rotation>(%752#3, %752#4, %752#5, %cst_744) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_745 = arith.constant 0.78539816339744828 : f64
    %754:4 = qlx.apply #qlx.action<pauli_rotation>(%752#0, %752#1, %752#2, %753#0, %cst_745) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_746 = arith.constant 0.78539816339744828 : f64
    %755:3 = qlx.apply #qlx.action<pauli_rotation>(%754#3, %753#1, %753#2, %cst_746) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_747 = arith.constant 0.78539816339744828 : f64
    %756:4 = qlx.apply #qlx.action<pauli_rotation>(%754#0, %754#1, %754#2, %755#0, %cst_747) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_748 = arith.constant 0.78539816339744828 : f64
    %757:3 = qlx.apply #qlx.action<pauli_rotation>(%756#3, %755#1, %755#2, %cst_748) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_749 = arith.constant 0.78539816339744828 : f64
    %758:4 = qlx.apply #qlx.action<pauli_rotation>(%756#0, %756#1, %756#2, %757#0, %cst_749) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_750 = arith.constant 0.78539816339744828 : f64
    %759:3 = qlx.apply #qlx.action<pauli_rotation>(%758#3, %757#1, %757#2, %cst_750) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_751 = arith.constant 0.78539816339744828 : f64
    %760:6 = qlx.apply #qlx.action<pauli_rotation>(%758#0, %758#1, %758#2, %759#0, %759#1, %759#2, %cst_751) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_752 = arith.constant 0.78539816339744828 : f64
    %761:4 = qlx.apply #qlx.action<pauli_rotation>(%760#0, %760#1, %760#2, %760#3, %cst_752) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_753 = arith.constant 0.78539816339744828 : f64
    %762:6 = qlx.apply #qlx.action<pauli_rotation>(%761#0, %761#1, %761#2, %761#3, %760#4, %760#5, %cst_753) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_754 = arith.constant 0.78539816339744828 : f64
    %763:3 = qlx.apply #qlx.action<pauli_rotation>(%762#3, %762#4, %762#5, %cst_754) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_755 = arith.constant 0.78539816339744828 : f64
    %764:6 = qlx.apply #qlx.action<pauli_rotation>(%762#0, %762#1, %762#2, %763#0, %763#1, %763#2, %cst_755) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_756 = arith.constant 0.78539816339744828 : f64
    %765:4 = qlx.apply #qlx.action<pauli_rotation>(%764#0, %764#1, %764#2, %764#3, %cst_756) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_757 = arith.constant 0.78539816339744828 : f64
    %766:3 = qlx.apply #qlx.action<pauli_rotation>(%765#3, %764#4, %764#5, %cst_757) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_758 = arith.constant 0.78539816339744828 : f64
    %767:4 = qlx.apply #qlx.action<pauli_rotation>(%765#0, %765#1, %765#2, %766#0, %cst_758) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_759 = arith.constant 0.78539816339744828 : f64
    %768:3 = qlx.apply #qlx.action<pauli_rotation>(%767#3, %766#1, %766#2, %cst_759) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_760 = arith.constant 0.78539816339744828 : f64
    %769:4 = qlx.apply #qlx.action<pauli_rotation>(%767#0, %767#1, %767#2, %768#0, %cst_760) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_761 = arith.constant 0.78539816339744828 : f64
    %770:3 = qlx.apply #qlx.action<pauli_rotation>(%769#3, %768#1, %768#2, %cst_761) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_762 = arith.constant 0.78539816339744828 : f64
    %771:6 = qlx.apply #qlx.action<pauli_rotation>(%769#0, %769#1, %769#2, %770#0, %770#1, %770#2, %cst_762) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_763 = arith.constant 0.78539816339744828 : f64
    %772:3 = qlx.apply #qlx.action<pauli_rotation>(%771#3, %771#4, %771#5, %cst_763) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_764 = arith.constant 0.78539816339744828 : f64
    %773:4 = qlx.apply #qlx.action<pauli_rotation>(%771#0, %771#1, %771#2, %772#0, %cst_764) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_765 = arith.constant 0.78539816339744828 : f64
    %774:6 = qlx.apply #qlx.action<pauli_rotation>(%773#0, %773#1, %773#2, %773#3, %772#1, %772#2, %cst_765) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_766 = arith.constant 0.78539816339744828 : f64
    %775:3 = qlx.apply #qlx.action<pauli_rotation>(%774#3, %774#4, %774#5, %cst_766) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_767 = arith.constant 0.78539816339744828 : f64
    %776:6 = qlx.apply #qlx.action<pauli_rotation>(%774#0, %774#1, %774#2, %775#0, %775#1, %775#2, %cst_767) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_768 = arith.constant 0.78539816339744828 : f64
    %777:4 = qlx.apply #qlx.action<pauli_rotation>(%776#0, %776#1, %776#2, %776#3, %cst_768) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_769 = arith.constant 0.78539816339744828 : f64
    %778:6 = qlx.apply #qlx.action<pauli_rotation>(%777#0, %777#1, %777#2, %777#3, %776#4, %776#5, %cst_769) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_770 = arith.constant 0.78539816339744828 : f64
    %779:3 = qlx.apply #qlx.action<pauli_rotation>(%778#3, %778#4, %778#5, %cst_770) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_771 = arith.constant 0.78539816339744828 : f64
    %780:4 = qlx.apply #qlx.action<pauli_rotation>(%778#0, %778#1, %778#2, %779#0, %cst_771) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_772 = arith.constant 0.78539816339744828 : f64
    %781:6 = qlx.apply #qlx.action<pauli_rotation>(%780#0, %780#1, %780#2, %780#3, %779#1, %779#2, %cst_772) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_773 = arith.constant 0.78539816339744828 : f64
    %782:4 = qlx.apply #qlx.action<pauli_rotation>(%781#0, %781#1, %781#2, %781#3, %cst_773) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_774 = arith.constant 0.78539816339744828 : f64
    %783:3 = qlx.apply #qlx.action<pauli_rotation>(%782#3, %781#4, %781#5, %cst_774) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_775 = arith.constant 0.78539816339744828 : f64
    %784:4 = qlx.apply #qlx.action<pauli_rotation>(%782#0, %782#1, %782#2, %783#0, %cst_775) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_776 = arith.constant 0.78539816339744828 : f64
    %785:3 = qlx.apply #qlx.action<pauli_rotation>(%784#3, %783#1, %783#2, %cst_776) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_777 = arith.constant 0.78539816339744828 : f64
    %786:6 = qlx.apply #qlx.action<pauli_rotation>(%784#0, %784#1, %784#2, %785#0, %785#1, %785#2, %cst_777) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_778 = arith.constant 0.78539816339744828 : f64
    %787:3 = qlx.apply #qlx.action<pauli_rotation>(%786#3, %786#4, %786#5, %cst_778) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_779 = arith.constant 0.78539816339744828 : f64
    %788:4 = qlx.apply #qlx.action<pauli_rotation>(%786#0, %786#1, %786#2, %787#0, %cst_779) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_780 = arith.constant 0.78539816339744828 : f64
    %789:6 = qlx.apply #qlx.action<pauli_rotation>(%788#0, %788#1, %788#2, %788#3, %787#1, %787#2, %cst_780) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_781 = arith.constant 0.78539816339744828 : f64
    %790:4 = qlx.apply #qlx.action<pauli_rotation>(%789#0, %789#1, %789#2, %789#3, %cst_781) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_782 = arith.constant 0.78539816339744828 : f64
    %791:6 = qlx.apply #qlx.action<pauli_rotation>(%790#0, %790#1, %790#2, %790#3, %789#4, %789#5, %cst_782) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_783 = arith.constant 0.78539816339744828 : f64
    %792:3 = qlx.apply #qlx.action<pauli_rotation>(%791#3, %791#4, %791#5, %cst_783) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_784 = arith.constant 0.78539816339744828 : f64
    %793:6 = qlx.apply #qlx.action<pauli_rotation>(%791#0, %791#1, %791#2, %792#0, %792#1, %792#2, %cst_784) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_785 = arith.constant 0.78539816339744828 : f64
    %794:3 = qlx.apply #qlx.action<pauli_rotation>(%793#3, %793#4, %793#5, %cst_785) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_786 = arith.constant 0.78539816339744828 : f64
    %795:6 = qlx.apply #qlx.action<pauli_rotation>(%793#0, %793#1, %793#2, %794#0, %794#1, %794#2, %cst_786) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_787 = arith.constant 0.78539816339744828 : f64
    %796:4 = qlx.apply #qlx.action<pauli_rotation>(%795#0, %795#1, %795#2, %795#3, %cst_787) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_788 = arith.constant 0.78539816339744828 : f64
    %797:3 = qlx.apply #qlx.action<pauli_rotation>(%796#3, %795#4, %795#5, %cst_788) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_789 = arith.constant 0.78539816339744828 : f64
    %798:4 = qlx.apply #qlx.action<pauli_rotation>(%796#0, %796#1, %796#2, %797#0, %cst_789) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_790 = arith.constant 0.78539816339744828 : f64
    %799:6 = qlx.apply #qlx.action<pauli_rotation>(%798#0, %798#1, %798#2, %798#3, %797#1, %797#2, %cst_790) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_791 = arith.constant 0.78539816339744828 : f64
    %800:4 = qlx.apply #qlx.action<pauli_rotation>(%799#0, %799#1, %799#2, %799#3, %cst_791) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_792 = arith.constant 0.78539816339744828 : f64
    %801:3 = qlx.apply #qlx.action<pauli_rotation>(%800#3, %799#4, %799#5, %cst_792) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_793 = arith.constant 0.78539816339744828 : f64
    %802:4 = qlx.apply #qlx.action<pauli_rotation>(%800#0, %800#1, %800#2, %801#0, %cst_793) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_794 = arith.constant 0.78539816339744828 : f64
    %803:3 = qlx.apply #qlx.action<pauli_rotation>(%802#3, %801#1, %801#2, %cst_794) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_795 = arith.constant 0.78539816339744828 : f64
    %804:4 = qlx.apply #qlx.action<pauli_rotation>(%802#0, %802#1, %802#2, %803#0, %cst_795) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_796 = arith.constant 0.78539816339744828 : f64
    %805:3 = qlx.apply #qlx.action<pauli_rotation>(%804#3, %803#1, %803#2, %cst_796) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_797 = arith.constant 0.78539816339744828 : f64
    %806:4 = qlx.apply #qlx.action<pauli_rotation>(%804#0, %804#1, %804#2, %805#0, %cst_797) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_798 = arith.constant 0.78539816339744828 : f64
    %807:6 = qlx.apply #qlx.action<pauli_rotation>(%806#0, %806#1, %806#2, %806#3, %805#1, %805#2, %cst_798) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 31 : i64, z_mask = 35 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_799 = arith.constant 0.78539816339744828 : f64
    %808:4 = qlx.apply #qlx.action<pauli_rotation>(%807#0, %807#1, %747#0, %807#2, %cst_799) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_800 = arith.constant 0.78539816339744828 : f64
    %809:3 = qlx.apply #qlx.action<pauli_rotation>(%808#2, %808#3, %807#3, %cst_800) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_801 = arith.constant 0.78539816339744828 : f64
    %810:4 = qlx.apply #qlx.action<pauli_rotation>(%808#0, %808#1, %809#1, %809#2, %cst_801) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_802 = arith.constant 0.78539816339744828 : f64
    %811:4 = qlx.apply #qlx.action<pauli_rotation>(%810#0, %810#1, %809#0, %810#2, %cst_802) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_803 = arith.constant 0.78539816339744828 : f64
    %812:3 = qlx.apply #qlx.action<pauli_rotation>(%811#2, %811#3, %810#3, %cst_803) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_804 = arith.constant 0.78539816339744828 : f64
    %813:4 = qlx.apply #qlx.action<pauli_rotation>(%811#0, %811#1, %812#0, %812#1, %cst_804) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_805 = arith.constant 0.78539816339744828 : f64
    %814:4 = qlx.apply #qlx.action<pauli_rotation>(%813#0, %813#1, %813#3, %812#2, %cst_805) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_806 = arith.constant 0.78539816339744828 : f64
    %815:4 = qlx.apply #qlx.action<pauli_rotation>(%814#0, %814#1, %813#2, %814#2, %cst_806) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_807 = arith.constant 0.78539816339744828 : f64
    %816:4 = qlx.apply #qlx.action<pauli_rotation>(%815#0, %815#1, %815#3, %814#3, %cst_807) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_808 = arith.constant 0.78539816339744828 : f64
    %817:4 = qlx.apply #qlx.action<pauli_rotation>(%816#0, %816#1, %815#2, %816#2, %cst_808) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_809 = arith.constant 0.78539816339744828 : f64
    %818:4 = qlx.apply #qlx.action<pauli_rotation>(%817#0, %817#1, %817#3, %816#3, %cst_809) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_810 = arith.constant 0.78539816339744828 : f64
    %819:4 = qlx.apply #qlx.action<pauli_rotation>(%818#0, %818#1, %817#2, %818#2, %cst_810) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_811 = arith.constant 0.78539816339744828 : f64
    %820:3 = qlx.apply #qlx.action<pauli_rotation>(%819#2, %819#3, %818#3, %cst_811) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_812 = arith.constant 0.78539816339744828 : f64
    %821:4 = qlx.apply #qlx.action<pauli_rotation>(%819#0, %819#1, %820#1, %820#2, %cst_812) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_813 = arith.constant 0.78539816339744828 : f64
    %822:3 = qlx.apply #qlx.action<pauli_rotation>(%820#0, %821#2, %821#3, %cst_813) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_814 = arith.constant 0.78539816339744828 : f64
    %823:4 = qlx.apply #qlx.action<pauli_rotation>(%821#0, %821#1, %822#0, %822#1, %cst_814) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_815 = arith.constant 0.78539816339744828 : f64
    %824:3 = qlx.apply #qlx.action<pauli_rotation>(%823#2, %823#3, %822#2, %cst_815) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_816 = arith.constant 0.78539816339744828 : f64
    %825:4 = qlx.apply #qlx.action<pauli_rotation>(%823#0, %823#1, %824#1, %824#2, %cst_816) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_817 = arith.constant 0.78539816339744828 : f64
    %826:4 = qlx.apply #qlx.action<pauli_rotation>(%825#0, %825#1, %824#0, %825#2, %cst_817) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_818 = arith.constant 0.78539816339744828 : f64
    %827:4 = qlx.apply #qlx.action<pauli_rotation>(%826#0, %826#1, %826#3, %825#3, %cst_818) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_819 = arith.constant 0.78539816339744828 : f64
    %828:4 = qlx.apply #qlx.action<pauli_rotation>(%827#0, %827#1, %826#2, %827#2, %cst_819) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_820 = arith.constant 0.78539816339744828 : f64
    %829:4 = qlx.apply #qlx.action<pauli_rotation>(%828#0, %828#1, %828#3, %827#3, %cst_820) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_821 = arith.constant 0.78539816339744828 : f64
    %830:4 = qlx.apply #qlx.action<pauli_rotation>(%829#0, %829#1, %828#2, %829#2, %cst_821) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_822 = arith.constant 0.78539816339744828 : f64
    %831:3 = qlx.apply #qlx.action<pauli_rotation>(%830#2, %830#3, %829#3, %cst_822) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_823 = arith.constant 0.78539816339744828 : f64
    %832:4 = qlx.apply #qlx.action<pauli_rotation>(%830#0, %830#1, %831#0, %831#1, %cst_823) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_824 = arith.constant 0.78539816339744828 : f64
    %833:4 = qlx.apply #qlx.action<pauli_rotation>(%832#0, %832#1, %832#3, %831#2, %cst_824) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_825 = arith.constant 0.78539816339744828 : f64
    %834:3 = qlx.apply #qlx.action<pauli_rotation>(%832#2, %833#2, %833#3, %cst_825) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_826 = arith.constant 0.78539816339744828 : f64
    %835:4 = qlx.apply #qlx.action<pauli_rotation>(%833#0, %833#1, %834#0, %834#1, %cst_826) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_827 = arith.constant 0.78539816339744828 : f64
    %836:3 = qlx.apply #qlx.action<pauli_rotation>(%835#2, %835#3, %834#2, %cst_827) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_828 = arith.constant 0.78539816339744828 : f64
    %837:4 = qlx.apply #qlx.action<pauli_rotation>(%835#0, %835#1, %836#1, %836#2, %cst_828) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_829 = arith.constant 0.78539816339744828 : f64
    %838:3 = qlx.apply #qlx.action<pauli_rotation>(%836#0, %837#2, %837#3, %cst_829) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_830 = arith.constant 0.78539816339744828 : f64
    %839:4 = qlx.apply #qlx.action<pauli_rotation>(%837#0, %837#1, %838#0, %838#1, %cst_830) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_831 = arith.constant 0.78539816339744828 : f64
    %840:4 = qlx.apply #qlx.action<pauli_rotation>(%839#0, %839#1, %839#3, %838#2, %cst_831) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_832 = arith.constant 0.78539816339744828 : f64
    %841:3 = qlx.apply #qlx.action<pauli_rotation>(%839#2, %840#2, %840#3, %cst_832) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_833 = arith.constant 0.78539816339744828 : f64
    %842:4 = qlx.apply #qlx.action<pauli_rotation>(%840#0, %840#1, %841#1, %841#2, %cst_833) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_834 = arith.constant 0.78539816339744828 : f64
    %843:4 = qlx.apply #qlx.action<pauli_rotation>(%842#0, %842#1, %841#0, %842#2, %cst_834) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_835 = arith.constant 0.78539816339744828 : f64
    %844:4 = qlx.apply #qlx.action<pauli_rotation>(%843#0, %843#1, %843#3, %842#3, %cst_835) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_836 = arith.constant 0.78539816339744828 : f64
    %845:4 = qlx.apply #qlx.action<pauli_rotation>(%844#0, %844#1, %843#2, %844#2, %cst_836) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_837 = arith.constant 0.78539816339744828 : f64
    %846:3 = qlx.apply #qlx.action<pauli_rotation>(%845#2, %845#3, %844#3, %cst_837) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_838 = arith.constant 0.78539816339744828 : f64
    %847:4 = qlx.apply #qlx.action<pauli_rotation>(%845#0, %845#1, %846#0, %846#1, %cst_838) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_839 = arith.constant 0.78539816339744828 : f64
    %848:4 = qlx.apply #qlx.action<pauli_rotation>(%847#0, %847#1, %847#3, %846#2, %cst_839) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_840 = arith.constant 0.78539816339744828 : f64
    %849:3 = qlx.apply #qlx.action<pauli_rotation>(%847#2, %848#2, %848#3, %cst_840) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_841 = arith.constant 0.78539816339744828 : f64
    %850:4 = qlx.apply #qlx.action<pauli_rotation>(%848#0, %848#1, %849#1, %849#2, %cst_841) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_842 = arith.constant 0.78539816339744828 : f64
    %851:3 = qlx.apply #qlx.action<pauli_rotation>(%849#0, %850#2, %850#3, %cst_842) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_843 = arith.constant 0.78539816339744828 : f64
    %852:4 = qlx.apply #qlx.action<pauli_rotation>(%850#0, %850#1, %851#0, %851#1, %cst_843) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_844 = arith.constant 0.78539816339744828 : f64
    %853:3 = qlx.apply #qlx.action<pauli_rotation>(%852#2, %852#3, %851#2, %cst_844) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_845 = arith.constant 0.78539816339744828 : f64
    %854:4 = qlx.apply #qlx.action<pauli_rotation>(%852#0, %852#1, %853#0, %853#1, %cst_845) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_846 = arith.constant 0.78539816339744828 : f64
    %855:3 = qlx.apply #qlx.action<pauli_rotation>(%854#2, %854#3, %853#2, %cst_846) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_847 = arith.constant 0.78539816339744828 : f64
    %856:4 = qlx.apply #qlx.action<pauli_rotation>(%854#0, %854#1, %855#1, %855#2, %cst_847) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_848 = arith.constant 0.78539816339744828 : f64
    %857:4 = qlx.apply #qlx.action<pauli_rotation>(%856#0, %856#1, %855#0, %856#2, %cst_848) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_849 = arith.constant 0.78539816339744828 : f64
    %858:4 = qlx.apply #qlx.action<pauli_rotation>(%857#0, %857#1, %857#3, %856#3, %cst_849) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_850 = arith.constant 0.78539816339744828 : f64
    %859:3 = qlx.apply #qlx.action<pauli_rotation>(%857#2, %858#2, %858#3, %cst_850) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_851 = arith.constant 0.78539816339744828 : f64
    %860:4 = qlx.apply #qlx.action<pauli_rotation>(%858#0, %858#1, %859#1, %859#2, %cst_851) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_852 = arith.constant 0.78539816339744828 : f64
    %861:4 = qlx.apply #qlx.action<pauli_rotation>(%860#0, %860#1, %859#0, %860#2, %cst_852) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_853 = arith.constant 0.78539816339744828 : f64
    %862:4 = qlx.apply #qlx.action<pauli_rotation>(%861#0, %861#1, %861#3, %860#3, %cst_853) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_854 = arith.constant 0.78539816339744828 : f64
    %863:4 = qlx.apply #qlx.action<pauli_rotation>(%862#0, %862#1, %861#2, %862#2, %cst_854) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_855 = arith.constant 0.78539816339744828 : f64
    %864:4 = qlx.apply #qlx.action<pauli_rotation>(%863#0, %863#1, %863#3, %862#3, %cst_855) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_856 = arith.constant 0.78539816339744828 : f64
    %865:4 = qlx.apply #qlx.action<pauli_rotation>(%864#0, %864#1, %863#2, %864#2, %cst_856) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_857 = arith.constant 0.78539816339744828 : f64
    %866:4 = qlx.apply #qlx.action<pauli_rotation>(%865#0, %865#1, %865#3, %864#3, %cst_857) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 11 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_858 = arith.constant 0.78539816339744828 : f64
    %867:3 = qlx.apply #qlx.action<pauli_rotation>(%865#2, %866#2, %866#3, %cst_858) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_859 = arith.constant 0.78539816339744828 : f64
    %868:5 = qlx.apply #qlx.action<pauli_rotation>(%866#0, %866#1, %867#1, %867#2, %744#4, %cst_859) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 23 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_860 = arith.constant 0.78539816339744828 : f64
    %869:4 = qlx.apply #qlx.action<pauli_rotation>(%868#0, %868#1, %868#2, %868#3, %cst_860) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 10 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_861 = arith.constant 0.78539816339744828 : f64
    %870:5 = qlx.apply #qlx.action<pauli_rotation>(%867#0, %869#2, %869#3, %807#4, %807#5, %cst_861) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 15 : i64, z_mask = 18 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_862 = arith.constant 0.78539816339744828 : f64
    %871:5 = qlx.apply #qlx.action<pauli_rotation>(%870#0, %870#1, %870#2, %870#3, %870#4, %cst_862) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 15 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_863 = arith.constant 0.78539816339744828 : f64
    %872:4 = qlx.apply #qlx.action<pauli_rotation>(%869#1, %871#1, %871#2, %868#4, %cst_863) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 10 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_864 = arith.constant 0.78539816339744828 : f64
    %873:5 = qlx.apply #qlx.action<pauli_rotation>(%869#0, %872#0, %872#1, %872#2, %872#3, %cst_864) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_865 = arith.constant 0.78539816339744828 : f64
    %874:5 = qlx.apply #qlx.action<pauli_rotation>(%871#0, %873#2, %873#3, %871#3, %871#4, %cst_865) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_866 = arith.constant 0.78539816339744828 : f64
    %875:3 = qlx.apply #qlx.action<pauli_rotation>(%874#1, %874#2, %874#4, %cst_866) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_867 = arith.constant 0.78539816339744828 : f64
    %876:3 = qlx.apply #qlx.action<pauli_rotation>(%874#0, %875#0, %873#4, %cst_867) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_868 = arith.constant 0.78539816339744828 : f64
    %877:5 = qlx.apply #qlx.action<pauli_rotation>(%873#1, %876#1, %875#1, %874#3, %875#2, %cst_868) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_869 = arith.constant 0.78539816339744828 : f64
    %878:7 = qlx.apply #qlx.action<pauli_rotation>(%877#0, %876#0, %877#1, %877#2, %876#2, %877#3, %877#4, %cst_869) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_870 = arith.constant 0.78539816339744828 : f64
    %879:3 = qlx.apply #qlx.action<pauli_rotation>(%878#1, %878#2, %878#4, %cst_870) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_871 = arith.constant 0.78539816339744828 : f64
    %880:5 = qlx.apply #qlx.action<pauli_rotation>(%878#0, %879#1, %878#3, %878#5, %878#6, %cst_871) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_872 = arith.constant 0.78539816339744828 : f64
    %881:3 = qlx.apply #qlx.action<pauli_rotation>(%879#0, %880#1, %879#2, %cst_872) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_873 = arith.constant 0.78539816339744828 : f64
    %882:7 = qlx.apply #qlx.action<pauli_rotation>(%880#0, %881#0, %881#1, %880#2, %881#2, %880#3, %880#4, %cst_873) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_874 = arith.constant 0.78539816339744828 : f64
    %883:3 = qlx.apply #qlx.action<pauli_rotation>(%882#1, %882#2, %882#4, %cst_874) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_875 = arith.constant 0.78539816339744828 : f64
    %884:7 = qlx.apply #qlx.action<pauli_rotation>(%882#0, %883#0, %883#1, %882#3, %883#2, %882#5, %882#6, %cst_875) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_876 = arith.constant 0.78539816339744828 : f64
    %885:3 = qlx.apply #qlx.action<pauli_rotation>(%884#1, %884#2, %884#4, %cst_876) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_877 = arith.constant 0.78539816339744828 : f64
    %886:7 = qlx.apply #qlx.action<pauli_rotation>(%884#0, %885#0, %885#1, %884#3, %885#2, %884#5, %884#6, %cst_877) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_878 = arith.constant 0.78539816339744828 : f64
    %887:3 = qlx.apply #qlx.action<pauli_rotation>(%886#1, %886#2, %886#4, %cst_878) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_879 = arith.constant 0.78539816339744828 : f64
    %888:5 = qlx.apply #qlx.action<pauli_rotation>(%886#0, %887#1, %886#3, %886#5, %886#6, %cst_879) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_880 = arith.constant 0.78539816339744828 : f64
    %889:7 = qlx.apply #qlx.action<pauli_rotation>(%888#0, %887#0, %888#1, %888#2, %887#2, %888#3, %888#4, %cst_880) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_881 = arith.constant 0.78539816339744828 : f64
    %890:5 = qlx.apply #qlx.action<pauli_rotation>(%889#0, %889#2, %889#3, %889#5, %889#6, %cst_881) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_882 = arith.constant 0.78539816339744828 : f64
    %891:3 = qlx.apply #qlx.action<pauli_rotation>(%889#1, %890#1, %889#4, %cst_882) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_883 = arith.constant 0.78539816339744828 : f64
    %892:5 = qlx.apply #qlx.action<pauli_rotation>(%890#0, %891#1, %890#2, %890#3, %890#4, %cst_883) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_884 = arith.constant 0.78539816339744828 : f64
    %893:7 = qlx.apply #qlx.action<pauli_rotation>(%892#0, %891#0, %892#1, %892#2, %891#2, %892#3, %892#4, %cst_884) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_885 = arith.constant 0.78539816339744828 : f64
    %894:3 = qlx.apply #qlx.action<pauli_rotation>(%893#1, %893#2, %893#4, %cst_885) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_886 = arith.constant 0.78539816339744828 : f64
    %895:7 = qlx.apply #qlx.action<pauli_rotation>(%893#0, %894#0, %894#1, %893#3, %894#2, %893#5, %893#6, %cst_886) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_887 = arith.constant 0.78539816339744828 : f64
    %896:3 = qlx.apply #qlx.action<pauli_rotation>(%895#1, %895#2, %895#4, %cst_887) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_888 = arith.constant 0.78539816339744828 : f64
    %897:7 = qlx.apply #qlx.action<pauli_rotation>(%895#0, %896#0, %896#1, %895#3, %896#2, %895#5, %895#6, %cst_888) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_889 = arith.constant 0.78539816339744828 : f64
    %898:3 = qlx.apply #qlx.action<pauli_rotation>(%897#1, %897#2, %897#4, %cst_889) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_890 = arith.constant 0.78539816339744828 : f64
    %899:5 = qlx.apply #qlx.action<pauli_rotation>(%897#0, %898#1, %897#3, %897#5, %897#6, %cst_890) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_891 = arith.constant 0.78539816339744828 : f64
    %900:3 = qlx.apply #qlx.action<pauli_rotation>(%898#0, %899#1, %898#2, %cst_891) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_892 = arith.constant 0.78539816339744828 : f64
    %901:7 = qlx.apply #qlx.action<pauli_rotation>(%899#0, %900#0, %900#1, %899#2, %900#2, %899#3, %899#4, %cst_892) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_893 = arith.constant 0.78539816339744828 : f64
    %902:5 = qlx.apply #qlx.action<pauli_rotation>(%901#0, %901#2, %901#3, %901#5, %901#6, %cst_893) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_894 = arith.constant 0.78539816339744828 : f64
    %903:3 = qlx.apply #qlx.action<pauli_rotation>(%901#1, %902#1, %901#4, %cst_894) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_895 = arith.constant 0.78539816339744828 : f64
    %904:5 = qlx.apply #qlx.action<pauli_rotation>(%902#0, %903#1, %902#2, %902#3, %902#4, %cst_895) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_896 = arith.constant 0.78539816339744828 : f64
    %905:7 = qlx.apply #qlx.action<pauli_rotation>(%904#0, %903#0, %904#1, %904#2, %903#2, %904#3, %904#4, %cst_896) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_897 = arith.constant 0.78539816339744828 : f64
    %906:5 = qlx.apply #qlx.action<pauli_rotation>(%905#0, %905#2, %905#3, %905#5, %905#6, %cst_897) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_898 = arith.constant 0.78539816339744828 : f64
    %907:3 = qlx.apply #qlx.action<pauli_rotation>(%905#1, %906#1, %905#4, %cst_898) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_899 = arith.constant 0.78539816339744828 : f64
    %908:7 = qlx.apply #qlx.action<pauli_rotation>(%906#0, %907#0, %907#1, %906#2, %907#2, %906#3, %906#4, %cst_899) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_900 = arith.constant 0.78539816339744828 : f64
    %909:5 = qlx.apply #qlx.action<pauli_rotation>(%908#0, %908#2, %908#3, %908#5, %908#6, %cst_900) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_901 = arith.constant 0.78539816339744828 : f64
    %910:7 = qlx.apply #qlx.action<pauli_rotation>(%909#0, %908#1, %909#1, %909#2, %908#4, %909#3, %909#4, %cst_901) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_902 = arith.constant 0.78539816339744828 : f64
    %911:3 = qlx.apply #qlx.action<pauli_rotation>(%910#1, %910#2, %910#4, %cst_902) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_903 = arith.constant 0.78539816339744828 : f64
    %912:7 = qlx.apply #qlx.action<pauli_rotation>(%910#0, %911#0, %911#1, %910#3, %911#2, %910#5, %910#6, %cst_903) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_904 = arith.constant 0.78539816339744828 : f64
    %913:3 = qlx.apply #qlx.action<pauli_rotation>(%912#1, %912#2, %912#4, %cst_904) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_905 = arith.constant 0.78539816339744828 : f64
    %914:5 = qlx.apply #qlx.action<pauli_rotation>(%912#0, %913#1, %912#3, %912#5, %912#6, %cst_905) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_906 = arith.constant 0.78539816339744828 : f64
    %915:3 = qlx.apply #qlx.action<pauli_rotation>(%913#0, %914#1, %913#2, %cst_906) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_907 = arith.constant 0.78539816339744828 : f64
    %916:7 = qlx.apply #qlx.action<pauli_rotation>(%914#0, %915#0, %915#1, %914#2, %915#2, %914#3, %914#4, %cst_907) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_908 = arith.constant 0.78539816339744828 : f64
    %917:5 = qlx.apply #qlx.action<pauli_rotation>(%916#0, %916#2, %916#3, %916#5, %916#6, %cst_908) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_909 = arith.constant 0.78539816339744828 : f64
    %918:7 = qlx.apply #qlx.action<pauli_rotation>(%917#0, %916#1, %917#1, %917#2, %916#4, %917#3, %917#4, %cst_909) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_910 = arith.constant 0.78539816339744828 : f64
    %919:5 = qlx.apply #qlx.action<pauli_rotation>(%918#0, %918#2, %918#3, %918#5, %918#6, %cst_910) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_911 = arith.constant 0.78539816339744828 : f64
    %920:3 = qlx.apply #qlx.action<pauli_rotation>(%918#1, %919#1, %918#4, %cst_911) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_912 = arith.constant 0.78539816339744828 : f64
    %921:5 = qlx.apply #qlx.action<pauli_rotation>(%919#0, %920#1, %919#2, %919#3, %919#4, %cst_912) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_913 = arith.constant 0.78539816339744828 : f64
    %922:3 = qlx.apply #qlx.action<pauli_rotation>(%920#0, %921#1, %920#2, %cst_913) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_914 = arith.constant 0.78539816339744828 : f64
    %923:5 = qlx.apply #qlx.action<pauli_rotation>(%921#0, %922#1, %921#2, %921#3, %921#4, %cst_914) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_915 = arith.constant 0.78539816339744828 : f64
    %924:7 = qlx.apply #qlx.action<pauli_rotation>(%923#0, %922#0, %923#1, %923#2, %922#2, %923#3, %923#4, %cst_915) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_916 = arith.constant 0.78539816339744828 : f64
    %925:3 = qlx.apply #qlx.action<pauli_rotation>(%924#1, %924#2, %924#4, %cst_916) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_917 = arith.constant 0.78539816339744828 : f64
    %926:7 = qlx.apply #qlx.action<pauli_rotation>(%924#0, %925#0, %925#1, %924#3, %925#2, %924#5, %924#6, %cst_917) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_918 = arith.constant 0.78539816339744828 : f64
    %927:5 = qlx.apply #qlx.action<pauli_rotation>(%926#0, %926#2, %926#3, %926#5, %926#6, %cst_918) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_919 = arith.constant 0.78539816339744828 : f64
    %928:7 = qlx.apply #qlx.action<pauli_rotation>(%927#0, %926#1, %927#1, %927#2, %926#4, %927#3, %927#4, %cst_919) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_920 = arith.constant 0.78539816339744828 : f64
    %929:3 = qlx.apply #qlx.action<pauli_rotation>(%928#1, %928#2, %928#4, %cst_920) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_921 = arith.constant 0.78539816339744828 : f64
    %930:7 = qlx.apply #qlx.action<pauli_rotation>(%928#0, %929#0, %929#1, %928#3, %929#2, %928#5, %928#6, %cst_921) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_922 = arith.constant 0.78539816339744828 : f64
    %931:3 = qlx.apply #qlx.action<pauli_rotation>(%930#1, %930#2, %930#4, %cst_922) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_923 = arith.constant 0.78539816339744828 : f64
    %932:7 = qlx.apply #qlx.action<pauli_rotation>(%930#0, %931#0, %931#1, %930#3, %931#2, %930#5, %930#6, %cst_923) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_924 = arith.constant 0.78539816339744828 : f64
    %933:3 = qlx.apply #qlx.action<pauli_rotation>(%932#1, %932#2, %932#4, %cst_924) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_925 = arith.constant 0.78539816339744828 : f64
    %934:7 = qlx.apply #qlx.action<pauli_rotation>(%932#0, %933#0, %933#1, %932#3, %933#2, %932#5, %932#6, %cst_925) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_926 = arith.constant 0.78539816339744828 : f64
    %935:5 = qlx.apply #qlx.action<pauli_rotation>(%934#0, %934#2, %934#3, %934#5, %934#6, %cst_926) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 25 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_927 = arith.constant 0.78539816339744828 : f64
    %936:5 = qlx.apply #qlx.action<pauli_rotation>(%935#0, %934#1, %935#2, %935#3, %935#4, %cst_927) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_928 = arith.constant 0.78539816339744828 : f64
    %937:3 = qlx.apply #qlx.action<pauli_rotation>(%935#1, %936#2, %934#4, %cst_928) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_929 = arith.constant 0.78539816339744828 : f64
    %938:7 = qlx.apply #qlx.action<pauli_rotation>(%936#0, %936#1, %937#0, %937#1, %937#2, %936#3, %936#4, %cst_929) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_930 = arith.constant 0.78539816339744828 : f64
    %939:5 = qlx.apply #qlx.action<pauli_rotation>(%938#0, %938#1, %938#3, %938#5, %938#6, %cst_930) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_931 = arith.constant 0.78539816339744828 : f64
    %940:3 = qlx.apply #qlx.action<pauli_rotation>(%938#2, %939#2, %938#4, %cst_931) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_932 = arith.constant 0.78539816339744828 : f64
    %941:5 = qlx.apply #qlx.action<pauli_rotation>(%939#0, %939#1, %940#1, %939#3, %939#4, %cst_932) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_933 = arith.constant 0.78539816339744828 : f64
    %942:7 = qlx.apply #qlx.action<pauli_rotation>(%941#0, %941#1, %940#0, %941#2, %940#2, %941#3, %941#4, %cst_933) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_934 = arith.constant 0.78539816339744828 : f64
    %943:5 = qlx.apply #qlx.action<pauli_rotation>(%942#0, %942#1, %942#3, %942#5, %942#6, %cst_934) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_935 = arith.constant 0.78539816339744828 : f64
    %944:7 = qlx.apply #qlx.action<pauli_rotation>(%943#0, %943#1, %942#2, %943#2, %942#4, %943#3, %943#4, %cst_935) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_936 = arith.constant 0.78539816339744828 : f64
    %945:5 = qlx.apply #qlx.action<pauli_rotation>(%944#0, %944#1, %944#3, %944#5, %944#6, %cst_936) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_937 = arith.constant 0.78539816339744828 : f64
    %946:7 = qlx.apply #qlx.action<pauli_rotation>(%945#0, %945#1, %944#2, %945#2, %944#4, %945#3, %945#4, %cst_937) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_938 = arith.constant 0.78539816339744828 : f64
    %947:5 = qlx.apply #qlx.action<pauli_rotation>(%946#0, %946#1, %946#3, %946#5, %946#6, %cst_938) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_939 = arith.constant 0.78539816339744828 : f64
    %948:3 = qlx.apply #qlx.action<pauli_rotation>(%946#2, %947#2, %946#4, %cst_939) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_940 = arith.constant 0.78539816339744828 : f64
    %949:7 = qlx.apply #qlx.action<pauli_rotation>(%947#0, %947#1, %948#0, %948#1, %948#2, %947#3, %947#4, %cst_940) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_941 = arith.constant 0.78539816339744828 : f64
    %950:3 = qlx.apply #qlx.action<pauli_rotation>(%949#2, %949#3, %949#4, %cst_941) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_942 = arith.constant 0.78539816339744828 : f64
    %951:5 = qlx.apply #qlx.action<pauli_rotation>(%949#0, %949#1, %950#1, %949#5, %949#6, %cst_942) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_943 = arith.constant 0.78539816339744828 : f64
    %952:3 = qlx.apply #qlx.action<pauli_rotation>(%950#0, %951#2, %950#2, %cst_943) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_944 = arith.constant 0.78539816339744828 : f64
    %953:7 = qlx.apply #qlx.action<pauli_rotation>(%951#0, %951#1, %952#0, %952#1, %952#2, %951#3, %951#4, %cst_944) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_945 = arith.constant 0.78539816339744828 : f64
    %954:5 = qlx.apply #qlx.action<pauli_rotation>(%953#0, %953#1, %953#3, %953#5, %953#6, %cst_945) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_946 = arith.constant 0.78539816339744828 : f64
    %955:7 = qlx.apply #qlx.action<pauli_rotation>(%954#0, %954#1, %953#2, %954#2, %953#4, %954#3, %954#4, %cst_946) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_947 = arith.constant 0.78539816339744828 : f64
    %956:5 = qlx.apply #qlx.action<pauli_rotation>(%955#0, %955#1, %955#3, %955#5, %955#6, %cst_947) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_948 = arith.constant 0.78539816339744828 : f64
    %957:7 = qlx.apply #qlx.action<pauli_rotation>(%956#0, %956#1, %955#2, %956#2, %955#4, %956#3, %956#4, %cst_948) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_949 = arith.constant 0.78539816339744828 : f64
    %958:5 = qlx.apply #qlx.action<pauli_rotation>(%957#0, %957#1, %957#3, %957#5, %957#6, %cst_949) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_950 = arith.constant 0.78539816339744828 : f64
    %959:3 = qlx.apply #qlx.action<pauli_rotation>(%957#2, %958#2, %957#4, %cst_950) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_951 = arith.constant 0.78539816339744828 : f64
    %960:5 = qlx.apply #qlx.action<pauli_rotation>(%958#0, %958#1, %959#1, %958#3, %958#4, %cst_951) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_952 = arith.constant 0.78539816339744828 : f64
    %961:7 = qlx.apply #qlx.action<pauli_rotation>(%960#0, %960#1, %959#0, %960#2, %959#2, %960#3, %960#4, %cst_952) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_953 = arith.constant 0.78539816339744828 : f64
    %962:3 = qlx.apply #qlx.action<pauli_rotation>(%961#2, %961#3, %961#4, %cst_953) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_954 = arith.constant 0.78539816339744828 : f64
    %963:5 = qlx.apply #qlx.action<pauli_rotation>(%961#0, %961#1, %962#1, %961#5, %961#6, %cst_954) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_955 = arith.constant 0.78539816339744828 : f64
    %964:3 = qlx.apply #qlx.action<pauli_rotation>(%962#0, %963#2, %962#2, %cst_955) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_956 = arith.constant 0.78539816339744828 : f64
    %965:7 = qlx.apply #qlx.action<pauli_rotation>(%963#0, %963#1, %964#0, %964#1, %964#2, %963#3, %963#4, %cst_956) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_957 = arith.constant 0.78539816339744828 : f64
    %966:3 = qlx.apply #qlx.action<pauli_rotation>(%965#2, %965#3, %965#4, %cst_957) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_958 = arith.constant 0.78539816339744828 : f64
    %967:5 = qlx.apply #qlx.action<pauli_rotation>(%965#0, %965#1, %966#1, %965#5, %965#6, %cst_958) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_959 = arith.constant 0.78539816339744828 : f64
    %968:7 = qlx.apply #qlx.action<pauli_rotation>(%967#0, %967#1, %966#0, %967#2, %966#2, %967#3, %967#4, %cst_959) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_960 = arith.constant 0.78539816339744828 : f64
    %969:3 = qlx.apply #qlx.action<pauli_rotation>(%968#2, %968#3, %968#4, %cst_960) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_961 = arith.constant 0.78539816339744828 : f64
    %970:7 = qlx.apply #qlx.action<pauli_rotation>(%968#0, %968#1, %969#0, %969#1, %969#2, %968#5, %968#6, %cst_961) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_962 = arith.constant 0.78539816339744828 : f64
    %971:5 = qlx.apply #qlx.action<pauli_rotation>(%970#0, %970#1, %970#3, %970#5, %970#6, %cst_962) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_963 = arith.constant 0.78539816339744828 : f64
    %972:7 = qlx.apply #qlx.action<pauli_rotation>(%971#0, %971#1, %970#2, %971#2, %970#4, %971#3, %971#4, %cst_963) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_964 = arith.constant 0.78539816339744828 : f64
    %973:5 = qlx.apply #qlx.action<pauli_rotation>(%972#0, %972#1, %972#3, %972#5, %972#6, %cst_964) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_965 = arith.constant 0.78539816339744828 : f64
    %974:3 = qlx.apply #qlx.action<pauli_rotation>(%972#2, %973#2, %972#4, %cst_965) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_966 = arith.constant 0.78539816339744828 : f64
    %975:5 = qlx.apply #qlx.action<pauli_rotation>(%973#0, %973#1, %974#1, %973#3, %973#4, %cst_966) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_967 = arith.constant 0.78539816339744828 : f64
    %976:7 = qlx.apply #qlx.action<pauli_rotation>(%975#0, %975#1, %974#0, %975#2, %974#2, %975#3, %975#4, %cst_967) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_968 = arith.constant 0.78539816339744828 : f64
    %977:3 = qlx.apply #qlx.action<pauli_rotation>(%976#2, %976#3, %976#4, %cst_968) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_969 = arith.constant 0.78539816339744828 : f64
    %978:7 = qlx.apply #qlx.action<pauli_rotation>(%976#0, %976#1, %977#0, %977#1, %977#2, %976#5, %976#6, %cst_969) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_970 = arith.constant 0.78539816339744828 : f64
    %979:3 = qlx.apply #qlx.action<pauli_rotation>(%978#2, %978#3, %978#4, %cst_970) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_971 = arith.constant 0.78539816339744828 : f64
    %980:5 = qlx.apply #qlx.action<pauli_rotation>(%978#0, %978#1, %979#1, %978#5, %978#6, %cst_971) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_972 = arith.constant 0.78539816339744828 : f64
    %981:3 = qlx.apply #qlx.action<pauli_rotation>(%979#0, %980#2, %979#2, %cst_972) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_973 = arith.constant 0.78539816339744828 : f64
    %982:5 = qlx.apply #qlx.action<pauli_rotation>(%980#0, %980#1, %981#1, %980#3, %980#4, %cst_973) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_974 = arith.constant 0.78539816339744828 : f64
    %983:3 = qlx.apply #qlx.action<pauli_rotation>(%981#0, %982#2, %981#2, %cst_974) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_975 = arith.constant 0.78539816339744828 : f64
    %984:7 = qlx.apply #qlx.action<pauli_rotation>(%982#0, %982#1, %983#0, %983#1, %983#2, %982#3, %982#4, %cst_975) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_976 = arith.constant 0.78539816339744828 : f64
    %985:5 = qlx.apply #qlx.action<pauli_rotation>(%984#0, %984#1, %984#3, %984#5, %984#6, %cst_976) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_977 = arith.constant 0.78539816339744828 : f64
    %986:7 = qlx.apply #qlx.action<pauli_rotation>(%985#0, %985#1, %984#2, %985#2, %984#4, %985#3, %985#4, %cst_977) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_978 = arith.constant 0.78539816339744828 : f64
    %987:3 = qlx.apply #qlx.action<pauli_rotation>(%986#2, %986#3, %986#4, %cst_978) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_979 = arith.constant 0.78539816339744828 : f64
    %988:7 = qlx.apply #qlx.action<pauli_rotation>(%986#0, %986#1, %987#0, %987#1, %987#2, %986#5, %986#6, %cst_979) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_980 = arith.constant 0.78539816339744828 : f64
    %989:5 = qlx.apply #qlx.action<pauli_rotation>(%988#0, %988#1, %988#3, %988#5, %988#6, %cst_980) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_981 = arith.constant 0.78539816339744828 : f64
    %990:7 = qlx.apply #qlx.action<pauli_rotation>(%989#0, %989#1, %988#2, %989#2, %988#4, %989#3, %989#4, %cst_981) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_982 = arith.constant 0.78539816339744828 : f64
    %991:5 = qlx.apply #qlx.action<pauli_rotation>(%990#0, %990#1, %990#3, %990#5, %990#6, %cst_982) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_983 = arith.constant 0.78539816339744828 : f64
    %992:7 = qlx.apply #qlx.action<pauli_rotation>(%991#0, %991#1, %990#2, %991#2, %990#4, %991#3, %991#4, %cst_983) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_984 = arith.constant 0.78539816339744828 : f64
    %993:5 = qlx.apply #qlx.action<pauli_rotation>(%992#0, %992#1, %992#3, %992#5, %992#6, %cst_984) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 4 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_985 = arith.constant 0.78539816339744828 : f64
    %994:7 = qlx.apply #qlx.action<pauli_rotation>(%993#0, %993#1, %992#2, %993#2, %992#4, %993#3, %993#4, %cst_985) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 8 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_986 = arith.constant 0.78539816339744828 : f64
    %995:3 = qlx.apply #qlx.action<pauli_rotation>(%994#2, %994#3, %994#4, %cst_986) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_987 = arith.constant 0.78539816339744828 : f64
    %996:4 = qlx.apply #qlx.action<pauli_rotation>(%994#0, %995#0, %995#1, %995#2, %cst_987) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 10 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_988 = arith.constant 0.78539816339744828 : f64
    %997:5 = qlx.apply #qlx.action<pauli_rotation>(%873#0, %996#0, %996#1, %996#2, %996#3, %cst_988) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_989 = arith.constant 0.78539816339744828 : f64
    %998:5 = qlx.apply #qlx.action<pauli_rotation>(%994#1, %997#2, %997#3, %994#5, %994#6, %cst_989) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 27 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_990 = arith.constant 0.78539816339744828 : f64
    %999:3 = qlx.apply #qlx.action<pauli_rotation>(%998#1, %998#2, %998#4, %cst_990) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_991 = arith.constant 0.78539816339744828 : f64
    %1000 = qlx.apply #qlx.action<pauli_rotation>(%997#1, %cst_991) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_992 = arith.constant 0.78539816339744828 : f64
    %1001:2 = qlx.apply #qlx.action<pauli_rotation>(%997#0, %1000, %cst_992) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_993 = arith.constant 0.78539816339744828 : f64
    %1002 = qlx.apply #qlx.action<pauli_rotation>(%1001#1, %cst_993) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_994 = arith.constant 0.78539816339744828 : f64
    %1003:2 = qlx.apply #qlx.action<pauli_rotation>(%1001#0, %1002, %cst_994) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_995 = arith.constant 0.78539816339744828 : f64
    %1004 = qlx.apply #qlx.action<pauli_rotation>(%1003#1, %cst_995) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_996 = arith.constant 0.78539816339744828 : f64
    %1005:2 = qlx.apply #qlx.action<pauli_rotation>(%1003#0, %1004, %cst_996) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_997 = arith.constant 0.78539816339744828 : f64
    %1006:2 = qlx.apply #qlx.action<pauli_rotation>(%1005#0, %1005#1, %cst_997) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_998 = arith.constant 0.78539816339744828 : f64
    %1007:2 = qlx.apply #qlx.action<pauli_rotation>(%1006#0, %1006#1, %cst_998) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_999 = arith.constant 0.78539816339744828 : f64
    %1008:2 = qlx.apply #qlx.action<pauli_rotation>(%1007#0, %1007#1, %cst_999) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1000 = arith.constant 0.78539816339744828 : f64
    %1009 = qlx.apply #qlx.action<pauli_rotation>(%1008#1, %cst_1000) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1001 = arith.constant 0.78539816339744828 : f64
    %1010:2 = qlx.apply #qlx.action<pauli_rotation>(%1008#0, %1009, %cst_1001) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1002 = arith.constant 0.78539816339744828 : f64
    %1011:2 = qlx.apply #qlx.action<pauli_rotation>(%1010#0, %1010#1, %cst_1002) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1003 = arith.constant 0.78539816339744828 : f64
    %1012:2 = qlx.apply #qlx.action<pauli_rotation>(%1011#0, %1011#1, %cst_1003) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1004 = arith.constant 0.78539816339744828 : f64
    %1013 = qlx.apply #qlx.action<pauli_rotation>(%1012#1, %cst_1004) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1005 = arith.constant 0.78539816339744828 : f64
    %1014:2 = qlx.apply #qlx.action<pauli_rotation>(%1012#0, %1013, %cst_1005) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1006 = arith.constant 0.78539816339744828 : f64
    %1015:2 = qlx.apply #qlx.action<pauli_rotation>(%1014#0, %1014#1, %cst_1006) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1007 = arith.constant 0.78539816339744828 : f64
    %1016:2 = qlx.apply #qlx.action<pauli_rotation>(%1015#0, %1015#1, %cst_1007) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1008 = arith.constant 0.78539816339744828 : f64
    %1017:2 = qlx.apply #qlx.action<pauli_rotation>(%1016#0, %1016#1, %cst_1008) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1009 = arith.constant 0.78539816339744828 : f64
    %1018 = qlx.apply #qlx.action<pauli_rotation>(%1017#1, %cst_1009) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1010 = arith.constant 0.78539816339744828 : f64
    %1019:2 = qlx.apply #qlx.action<pauli_rotation>(%1017#0, %1018, %cst_1010) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1011 = arith.constant 0.78539816339744828 : f64
    %1020 = qlx.apply #qlx.action<pauli_rotation>(%1019#1, %cst_1011) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1012 = arith.constant 0.78539816339744828 : f64
    %1021:2 = qlx.apply #qlx.action<pauli_rotation>(%1019#0, %1020, %cst_1012) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1013 = arith.constant 0.78539816339744828 : f64
    %1022 = qlx.apply #qlx.action<pauli_rotation>(%1021#1, %cst_1013) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1014 = arith.constant 0.78539816339744828 : f64
    %1023:2 = qlx.apply #qlx.action<pauli_rotation>(%1021#0, %1022, %cst_1014) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1015 = arith.constant 0.78539816339744828 : f64
    %1024:2 = qlx.apply #qlx.action<pauli_rotation>(%1023#0, %1023#1, %cst_1015) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1016 = arith.constant 0.78539816339744828 : f64
    %1025:2 = qlx.apply #qlx.action<pauli_rotation>(%1024#0, %1024#1, %cst_1016) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1017 = arith.constant 0.78539816339744828 : f64
    %1026:2 = qlx.apply #qlx.action<pauli_rotation>(%1025#0, %1025#1, %cst_1017) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1018 = arith.constant 0.78539816339744828 : f64
    %1027 = qlx.apply #qlx.action<pauli_rotation>(%1026#1, %cst_1018) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1019 = arith.constant 0.78539816339744828 : f64
    %1028:2 = qlx.apply #qlx.action<pauli_rotation>(%1026#0, %1027, %cst_1019) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1020 = arith.constant 0.78539816339744828 : f64
    %1029 = qlx.apply #qlx.action<pauli_rotation>(%1028#1, %cst_1020) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1021 = arith.constant 0.78539816339744828 : f64
    %1030:2 = qlx.apply #qlx.action<pauli_rotation>(%1028#0, %1029, %cst_1021) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1022 = arith.constant 0.78539816339744828 : f64
    %1031 = qlx.apply #qlx.action<pauli_rotation>(%1030#1, %cst_1022) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1023 = arith.constant 0.78539816339744828 : f64
    %1032:2 = qlx.apply #qlx.action<pauli_rotation>(%1030#0, %1031, %cst_1023) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1024 = arith.constant 0.78539816339744828 : f64
    %1033:2 = qlx.apply #qlx.action<pauli_rotation>(%1032#0, %1032#1, %cst_1024) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1025 = arith.constant 0.78539816339744828 : f64
    %1034 = qlx.apply #qlx.action<pauli_rotation>(%1033#1, %cst_1025) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1026 = arith.constant 0.78539816339744828 : f64
    %1035:2 = qlx.apply #qlx.action<pauli_rotation>(%1033#0, %1034, %cst_1026) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1027 = arith.constant 0.78539816339744828 : f64
    %1036 = qlx.apply #qlx.action<pauli_rotation>(%1035#1, %cst_1027) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1028 = arith.constant 0.78539816339744828 : f64
    %1037:2 = qlx.apply #qlx.action<pauli_rotation>(%1035#0, %1036, %cst_1028) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1029 = arith.constant 0.78539816339744828 : f64
    %1038 = qlx.apply #qlx.action<pauli_rotation>(%1037#1, %cst_1029) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1030 = arith.constant 0.78539816339744828 : f64
    %1039:2 = qlx.apply #qlx.action<pauli_rotation>(%1037#0, %1038, %cst_1030) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1031 = arith.constant 0.78539816339744828 : f64
    %1040 = qlx.apply #qlx.action<pauli_rotation>(%1039#1, %cst_1031) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1032 = arith.constant 0.78539816339744828 : f64
    %1041:2 = qlx.apply #qlx.action<pauli_rotation>(%1039#0, %1040, %cst_1032) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1033 = arith.constant 0.78539816339744828 : f64
    %1042:2 = qlx.apply #qlx.action<pauli_rotation>(%1041#0, %1041#1, %cst_1033) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1034 = arith.constant 0.78539816339744828 : f64
    %1043 = qlx.apply #qlx.action<pauli_rotation>(%1042#1, %cst_1034) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1035 = arith.constant 0.78539816339744828 : f64
    %1044:2 = qlx.apply #qlx.action<pauli_rotation>(%1042#0, %1043, %cst_1035) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1036 = arith.constant 0.78539816339744828 : f64
    %1045:2 = qlx.apply #qlx.action<pauli_rotation>(%1044#0, %1044#1, %cst_1036) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1037 = arith.constant 0.78539816339744828 : f64
    %1046 = qlx.apply #qlx.action<pauli_rotation>(%1045#1, %cst_1037) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1038 = arith.constant 0.78539816339744828 : f64
    %1047:2 = qlx.apply #qlx.action<pauli_rotation>(%1045#0, %1046, %cst_1038) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1039 = arith.constant 0.78539816339744828 : f64
    %1048 = qlx.apply #qlx.action<pauli_rotation>(%1047#1, %cst_1039) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1040 = arith.constant 0.78539816339744828 : f64
    %1049:2 = qlx.apply #qlx.action<pauli_rotation>(%1047#0, %1048, %cst_1040) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1041 = arith.constant 0.78539816339744828 : f64
    %1050:2 = qlx.apply #qlx.action<pauli_rotation>(%1049#0, %1049#1, %cst_1041) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1042 = arith.constant 0.78539816339744828 : f64
    %1051 = qlx.apply #qlx.action<pauli_rotation>(%1050#1, %cst_1042) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1043 = arith.constant 0.78539816339744828 : f64
    %1052:2 = qlx.apply #qlx.action<pauli_rotation>(%1050#0, %1051, %cst_1043) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1044 = arith.constant 0.78539816339744828 : f64
    %1053:2 = qlx.apply #qlx.action<pauli_rotation>(%1052#0, %1052#1, %cst_1044) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1045 = arith.constant 0.78539816339744828 : f64
    %1054 = qlx.apply #qlx.action<pauli_rotation>(%1053#1, %cst_1045) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1046 = arith.constant 0.78539816339744828 : f64
    %1055:2 = qlx.apply #qlx.action<pauli_rotation>(%1053#0, %1054, %cst_1046) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1047 = arith.constant 0.78539816339744828 : f64
    %1056:2 = qlx.apply #qlx.action<pauli_rotation>(%1055#0, %1055#1, %cst_1047) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1048 = arith.constant 0.78539816339744828 : f64
    %1057:2 = qlx.apply #qlx.action<pauli_rotation>(%1056#0, %1056#1, %cst_1048) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1049 = arith.constant 0.78539816339744828 : f64
    %1058 = qlx.apply #qlx.action<pauli_rotation>(%1057#1, %cst_1049) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1050 = arith.constant 0.78539816339744828 : f64
    %1059:2 = qlx.apply #qlx.action<pauli_rotation>(%1057#0, %1058, %cst_1050) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1051 = arith.constant 0.78539816339744828 : f64
    %1060 = qlx.apply #qlx.action<pauli_rotation>(%999#0, %cst_1051) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1052 = arith.constant 0.78539816339744828 : f64
    %1061:2 = qlx.apply #qlx.action<pauli_rotation>(%998#0, %1060, %cst_1052) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1053 = arith.constant 0.78539816339744828 : f64
    %1062 = qlx.apply #qlx.action<pauli_rotation>(%1061#1, %cst_1053) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1054 = arith.constant 0.78539816339744828 : f64
    %1063:2 = qlx.apply #qlx.action<pauli_rotation>(%1061#0, %1062, %cst_1054) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1055 = arith.constant 0.78539816339744828 : f64
    %1064 = qlx.apply #qlx.action<pauli_rotation>(%1063#1, %cst_1055) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1056 = arith.constant 0.78539816339744828 : f64
    %1065:2 = qlx.apply #qlx.action<pauli_rotation>(%1063#0, %1064, %cst_1056) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1057 = arith.constant 0.78539816339744828 : f64
    %1066:2 = qlx.apply #qlx.action<pauli_rotation>(%1065#0, %1065#1, %cst_1057) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1058 = arith.constant 0.78539816339744828 : f64
    %1067:2 = qlx.apply #qlx.action<pauli_rotation>(%1066#0, %1066#1, %cst_1058) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1059 = arith.constant 0.78539816339744828 : f64
    %1068:2 = qlx.apply #qlx.action<pauli_rotation>(%1067#0, %1067#1, %cst_1059) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1060 = arith.constant 0.78539816339744828 : f64
    %1069 = qlx.apply #qlx.action<pauli_rotation>(%1068#1, %cst_1060) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1061 = arith.constant 0.78539816339744828 : f64
    %1070:2 = qlx.apply #qlx.action<pauli_rotation>(%1068#0, %1069, %cst_1061) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1062 = arith.constant 0.78539816339744828 : f64
    %1071:2 = qlx.apply #qlx.action<pauli_rotation>(%1070#0, %1070#1, %cst_1062) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1063 = arith.constant 0.78539816339744828 : f64
    %1072:2 = qlx.apply #qlx.action<pauli_rotation>(%1071#0, %1071#1, %cst_1063) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1064 = arith.constant 0.78539816339744828 : f64
    %1073 = qlx.apply #qlx.action<pauli_rotation>(%1072#1, %cst_1064) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1065 = arith.constant 0.78539816339744828 : f64
    %1074:2 = qlx.apply #qlx.action<pauli_rotation>(%1072#0, %1073, %cst_1065) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1066 = arith.constant 0.78539816339744828 : f64
    %1075:2 = qlx.apply #qlx.action<pauli_rotation>(%1074#0, %1074#1, %cst_1066) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1067 = arith.constant 0.78539816339744828 : f64
    %1076:2 = qlx.apply #qlx.action<pauli_rotation>(%1075#0, %1075#1, %cst_1067) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1068 = arith.constant 0.78539816339744828 : f64
    %1077:2 = qlx.apply #qlx.action<pauli_rotation>(%1076#0, %1076#1, %cst_1068) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1069 = arith.constant 0.78539816339744828 : f64
    %1078 = qlx.apply #qlx.action<pauli_rotation>(%1077#1, %cst_1069) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1070 = arith.constant 0.78539816339744828 : f64
    %1079:2 = qlx.apply #qlx.action<pauli_rotation>(%1077#0, %1078, %cst_1070) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1071 = arith.constant 0.78539816339744828 : f64
    %1080 = qlx.apply #qlx.action<pauli_rotation>(%1079#1, %cst_1071) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1072 = arith.constant 0.78539816339744828 : f64
    %1081:2 = qlx.apply #qlx.action<pauli_rotation>(%1079#0, %1080, %cst_1072) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1073 = arith.constant 0.78539816339744828 : f64
    %1082 = qlx.apply #qlx.action<pauli_rotation>(%1081#1, %cst_1073) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1074 = arith.constant 0.78539816339744828 : f64
    %1083:2 = qlx.apply #qlx.action<pauli_rotation>(%1081#0, %1082, %cst_1074) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1075 = arith.constant 0.78539816339744828 : f64
    %1084:2 = qlx.apply #qlx.action<pauli_rotation>(%1083#0, %1083#1, %cst_1075) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1076 = arith.constant 0.78539816339744828 : f64
    %1085:2 = qlx.apply #qlx.action<pauli_rotation>(%1084#0, %1084#1, %cst_1076) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1077 = arith.constant 0.78539816339744828 : f64
    %1086:2 = qlx.apply #qlx.action<pauli_rotation>(%1085#0, %1085#1, %cst_1077) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1078 = arith.constant 0.78539816339744828 : f64
    %1087 = qlx.apply #qlx.action<pauli_rotation>(%1086#1, %cst_1078) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1079 = arith.constant 0.78539816339744828 : f64
    %1088:2 = qlx.apply #qlx.action<pauli_rotation>(%1086#0, %1087, %cst_1079) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1080 = arith.constant 0.78539816339744828 : f64
    %1089 = qlx.apply #qlx.action<pauli_rotation>(%1088#1, %cst_1080) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1081 = arith.constant 0.78539816339744828 : f64
    %1090:2 = qlx.apply #qlx.action<pauli_rotation>(%1088#0, %1089, %cst_1081) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1082 = arith.constant 0.78539816339744828 : f64
    %1091 = qlx.apply #qlx.action<pauli_rotation>(%1090#1, %cst_1082) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1083 = arith.constant 0.78539816339744828 : f64
    %1092:2 = qlx.apply #qlx.action<pauli_rotation>(%1090#0, %1091, %cst_1083) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1084 = arith.constant 0.78539816339744828 : f64
    %1093:2 = qlx.apply #qlx.action<pauli_rotation>(%1092#0, %1092#1, %cst_1084) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1085 = arith.constant 0.78539816339744828 : f64
    %1094 = qlx.apply #qlx.action<pauli_rotation>(%1093#1, %cst_1085) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1086 = arith.constant 0.78539816339744828 : f64
    %1095:2 = qlx.apply #qlx.action<pauli_rotation>(%1093#0, %1094, %cst_1086) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1087 = arith.constant 0.78539816339744828 : f64
    %1096 = qlx.apply #qlx.action<pauli_rotation>(%1095#1, %cst_1087) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1088 = arith.constant 0.78539816339744828 : f64
    %1097:2 = qlx.apply #qlx.action<pauli_rotation>(%1095#0, %1096, %cst_1088) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1089 = arith.constant 0.78539816339744828 : f64
    %1098 = qlx.apply #qlx.action<pauli_rotation>(%1097#1, %cst_1089) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1090 = arith.constant 0.78539816339744828 : f64
    %1099:2 = qlx.apply #qlx.action<pauli_rotation>(%1097#0, %1098, %cst_1090) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1091 = arith.constant 0.78539816339744828 : f64
    %1100 = qlx.apply #qlx.action<pauli_rotation>(%1099#1, %cst_1091) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1092 = arith.constant 0.78539816339744828 : f64
    %1101:2 = qlx.apply #qlx.action<pauli_rotation>(%1099#0, %1100, %cst_1092) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1093 = arith.constant 0.78539816339744828 : f64
    %1102:2 = qlx.apply #qlx.action<pauli_rotation>(%1101#0, %1101#1, %cst_1093) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1094 = arith.constant 0.78539816339744828 : f64
    %1103 = qlx.apply #qlx.action<pauli_rotation>(%1102#1, %cst_1094) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1095 = arith.constant 0.78539816339744828 : f64
    %1104:2 = qlx.apply #qlx.action<pauli_rotation>(%1102#0, %1103, %cst_1095) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1096 = arith.constant 0.78539816339744828 : f64
    %1105:2 = qlx.apply #qlx.action<pauli_rotation>(%1104#0, %1104#1, %cst_1096) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1097 = arith.constant 0.78539816339744828 : f64
    %1106 = qlx.apply #qlx.action<pauli_rotation>(%1105#1, %cst_1097) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1098 = arith.constant 0.78539816339744828 : f64
    %1107:2 = qlx.apply #qlx.action<pauli_rotation>(%1105#0, %1106, %cst_1098) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1099 = arith.constant 0.78539816339744828 : f64
    %1108 = qlx.apply #qlx.action<pauli_rotation>(%1107#1, %cst_1099) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1100 = arith.constant 0.78539816339744828 : f64
    %1109:2 = qlx.apply #qlx.action<pauli_rotation>(%1107#0, %1108, %cst_1100) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1101 = arith.constant 0.78539816339744828 : f64
    %1110:2 = qlx.apply #qlx.action<pauli_rotation>(%1109#0, %1109#1, %cst_1101) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1102 = arith.constant 0.78539816339744828 : f64
    %1111 = qlx.apply #qlx.action<pauli_rotation>(%1110#1, %cst_1102) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1103 = arith.constant 0.78539816339744828 : f64
    %1112:2 = qlx.apply #qlx.action<pauli_rotation>(%1110#0, %1111, %cst_1103) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1104 = arith.constant 0.78539816339744828 : f64
    %1113:2 = qlx.apply #qlx.action<pauli_rotation>(%1112#0, %1112#1, %cst_1104) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1105 = arith.constant 0.78539816339744828 : f64
    %1114 = qlx.apply #qlx.action<pauli_rotation>(%1113#1, %cst_1105) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1106 = arith.constant 0.78539816339744828 : f64
    %1115:2 = qlx.apply #qlx.action<pauli_rotation>(%1113#0, %1114, %cst_1106) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1107 = arith.constant 0.78539816339744828 : f64
    %1116:2 = qlx.apply #qlx.action<pauli_rotation>(%1115#0, %1115#1, %cst_1107) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1108 = arith.constant 0.78539816339744828 : f64
    %1117:2 = qlx.apply #qlx.action<pauli_rotation>(%1116#0, %1116#1, %cst_1108) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1109 = arith.constant 0.78539816339744828 : f64
    %1118 = qlx.apply #qlx.action<pauli_rotation>(%1117#1, %cst_1109) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1110 = arith.constant 0.78539816339744828 : f64
    %1119:2 = qlx.apply #qlx.action<pauli_rotation>(%1117#0, %1118, %cst_1110) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1111 = arith.constant 0.78539816339744828 : f64
    %1120 = qlx.apply #qlx.action<pauli_rotation>(%999#1, %cst_1111) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1112 = arith.constant 0.78539816339744828 : f64
    %1121:2 = qlx.apply #qlx.action<pauli_rotation>(%1120, %997#4, %cst_1112) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1113 = arith.constant 0.78539816339744828 : f64
    %1122 = qlx.apply #qlx.action<pauli_rotation>(%1121#0, %cst_1113) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1114 = arith.constant 0.78539816339744828 : f64
    %1123:2 = qlx.apply #qlx.action<pauli_rotation>(%1122, %1121#1, %cst_1114) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1115 = arith.constant 0.78539816339744828 : f64
    %1124 = qlx.apply #qlx.action<pauli_rotation>(%1123#0, %cst_1115) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1116 = arith.constant 0.78539816339744828 : f64
    %1125:2 = qlx.apply #qlx.action<pauli_rotation>(%1124, %1123#1, %cst_1116) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1117 = arith.constant 0.78539816339744828 : f64
    %1126:2 = qlx.apply #qlx.action<pauli_rotation>(%1125#0, %1125#1, %cst_1117) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1118 = arith.constant 0.78539816339744828 : f64
    %1127:2 = qlx.apply #qlx.action<pauli_rotation>(%1126#0, %1126#1, %cst_1118) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1119 = arith.constant 0.78539816339744828 : f64
    %1128:2 = qlx.apply #qlx.action<pauli_rotation>(%1127#0, %1127#1, %cst_1119) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1120 = arith.constant 0.78539816339744828 : f64
    %1129 = qlx.apply #qlx.action<pauli_rotation>(%1128#0, %cst_1120) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1121 = arith.constant 0.78539816339744828 : f64
    %1130:2 = qlx.apply #qlx.action<pauli_rotation>(%1129, %1128#1, %cst_1121) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1122 = arith.constant 0.78539816339744828 : f64
    %1131:2 = qlx.apply #qlx.action<pauli_rotation>(%1130#0, %1130#1, %cst_1122) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1123 = arith.constant 0.78539816339744828 : f64
    %1132:2 = qlx.apply #qlx.action<pauli_rotation>(%1131#0, %1131#1, %cst_1123) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1124 = arith.constant 0.78539816339744828 : f64
    %1133 = qlx.apply #qlx.action<pauli_rotation>(%1132#0, %cst_1124) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1125 = arith.constant 0.78539816339744828 : f64
    %1134:2 = qlx.apply #qlx.action<pauli_rotation>(%1133, %1132#1, %cst_1125) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1126 = arith.constant 0.78539816339744828 : f64
    %1135:2 = qlx.apply #qlx.action<pauli_rotation>(%1134#0, %1134#1, %cst_1126) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1127 = arith.constant 0.78539816339744828 : f64
    %1136:2 = qlx.apply #qlx.action<pauli_rotation>(%1135#0, %1135#1, %cst_1127) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1128 = arith.constant 0.78539816339744828 : f64
    %1137:2 = qlx.apply #qlx.action<pauli_rotation>(%1136#0, %1136#1, %cst_1128) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1129 = arith.constant 0.78539816339744828 : f64
    %1138 = qlx.apply #qlx.action<pauli_rotation>(%1137#0, %cst_1129) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1130 = arith.constant 0.78539816339744828 : f64
    %1139:2 = qlx.apply #qlx.action<pauli_rotation>(%1138, %1137#1, %cst_1130) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1131 = arith.constant 0.78539816339744828 : f64
    %1140 = qlx.apply #qlx.action<pauli_rotation>(%1139#0, %cst_1131) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1132 = arith.constant 0.78539816339744828 : f64
    %1141:2 = qlx.apply #qlx.action<pauli_rotation>(%1140, %1139#1, %cst_1132) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1133 = arith.constant 0.78539816339744828 : f64
    %1142 = qlx.apply #qlx.action<pauli_rotation>(%1141#0, %cst_1133) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1134 = arith.constant 0.78539816339744828 : f64
    %1143:2 = qlx.apply #qlx.action<pauli_rotation>(%1142, %1141#1, %cst_1134) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1135 = arith.constant 0.78539816339744828 : f64
    %1144:2 = qlx.apply #qlx.action<pauli_rotation>(%1143#0, %1143#1, %cst_1135) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1136 = arith.constant 0.78539816339744828 : f64
    %1145:2 = qlx.apply #qlx.action<pauli_rotation>(%1144#0, %1144#1, %cst_1136) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1137 = arith.constant 0.78539816339744828 : f64
    %1146:2 = qlx.apply #qlx.action<pauli_rotation>(%1145#0, %1145#1, %cst_1137) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1138 = arith.constant 0.78539816339744828 : f64
    %1147 = qlx.apply #qlx.action<pauli_rotation>(%1146#0, %cst_1138) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1139 = arith.constant 0.78539816339744828 : f64
    %1148:2 = qlx.apply #qlx.action<pauli_rotation>(%1147, %1146#1, %cst_1139) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1140 = arith.constant 0.78539816339744828 : f64
    %1149 = qlx.apply #qlx.action<pauli_rotation>(%1148#0, %cst_1140) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1141 = arith.constant 0.78539816339744828 : f64
    %1150:2 = qlx.apply #qlx.action<pauli_rotation>(%1149, %1148#1, %cst_1141) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1142 = arith.constant 0.78539816339744828 : f64
    %1151 = qlx.apply #qlx.action<pauli_rotation>(%1150#0, %cst_1142) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1143 = arith.constant 0.78539816339744828 : f64
    %1152:2 = qlx.apply #qlx.action<pauli_rotation>(%1151, %1150#1, %cst_1143) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1144 = arith.constant 0.78539816339744828 : f64
    %1153:2 = qlx.apply #qlx.action<pauli_rotation>(%1152#0, %1152#1, %cst_1144) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1145 = arith.constant 0.78539816339744828 : f64
    %1154 = qlx.apply #qlx.action<pauli_rotation>(%1153#0, %cst_1145) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1146 = arith.constant 0.78539816339744828 : f64
    %1155:2 = qlx.apply #qlx.action<pauli_rotation>(%1154, %1153#1, %cst_1146) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1147 = arith.constant 0.78539816339744828 : f64
    %1156 = qlx.apply #qlx.action<pauli_rotation>(%1155#0, %cst_1147) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1148 = arith.constant 0.78539816339744828 : f64
    %1157:2 = qlx.apply #qlx.action<pauli_rotation>(%1156, %1155#1, %cst_1148) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1149 = arith.constant 0.78539816339744828 : f64
    %1158 = qlx.apply #qlx.action<pauli_rotation>(%1157#0, %cst_1149) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1150 = arith.constant 0.78539816339744828 : f64
    %1159:2 = qlx.apply #qlx.action<pauli_rotation>(%1158, %1157#1, %cst_1150) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1151 = arith.constant 0.78539816339744828 : f64
    %1160 = qlx.apply #qlx.action<pauli_rotation>(%1159#0, %cst_1151) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1152 = arith.constant 0.78539816339744828 : f64
    %1161:2 = qlx.apply #qlx.action<pauli_rotation>(%1160, %1159#1, %cst_1152) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1153 = arith.constant 0.78539816339744828 : f64
    %1162:2 = qlx.apply #qlx.action<pauli_rotation>(%1161#0, %1161#1, %cst_1153) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1154 = arith.constant 0.78539816339744828 : f64
    %1163 = qlx.apply #qlx.action<pauli_rotation>(%1162#0, %cst_1154) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1155 = arith.constant 0.78539816339744828 : f64
    %1164:2 = qlx.apply #qlx.action<pauli_rotation>(%1163, %1162#1, %cst_1155) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1156 = arith.constant 0.78539816339744828 : f64
    %1165:2 = qlx.apply #qlx.action<pauli_rotation>(%1164#0, %1164#1, %cst_1156) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1157 = arith.constant 0.78539816339744828 : f64
    %1166 = qlx.apply #qlx.action<pauli_rotation>(%1165#0, %cst_1157) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1158 = arith.constant 0.78539816339744828 : f64
    %1167:2 = qlx.apply #qlx.action<pauli_rotation>(%1166, %1165#1, %cst_1158) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1159 = arith.constant 0.78539816339744828 : f64
    %1168 = qlx.apply #qlx.action<pauli_rotation>(%1167#0, %cst_1159) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1160 = arith.constant 0.78539816339744828 : f64
    %1169:2 = qlx.apply #qlx.action<pauli_rotation>(%1168, %1167#1, %cst_1160) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1161 = arith.constant 0.78539816339744828 : f64
    %1170:2 = qlx.apply #qlx.action<pauli_rotation>(%1169#0, %1169#1, %cst_1161) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1162 = arith.constant 0.78539816339744828 : f64
    %1171 = qlx.apply #qlx.action<pauli_rotation>(%1170#0, %cst_1162) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1163 = arith.constant 0.78539816339744828 : f64
    %1172:2 = qlx.apply #qlx.action<pauli_rotation>(%1171, %1170#1, %cst_1163) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1164 = arith.constant 0.78539816339744828 : f64
    %1173:2 = qlx.apply #qlx.action<pauli_rotation>(%1172#0, %1172#1, %cst_1164) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1165 = arith.constant 0.78539816339744828 : f64
    %1174 = qlx.apply #qlx.action<pauli_rotation>(%1173#0, %cst_1165) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1166 = arith.constant 0.78539816339744828 : f64
    %1175:2 = qlx.apply #qlx.action<pauli_rotation>(%1174, %1173#1, %cst_1166) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1167 = arith.constant 0.78539816339744828 : f64
    %1176:2 = qlx.apply #qlx.action<pauli_rotation>(%1175#0, %1175#1, %cst_1167) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1168 = arith.constant 0.78539816339744828 : f64
    %1177:2 = qlx.apply #qlx.action<pauli_rotation>(%1176#0, %1176#1, %cst_1168) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1169 = arith.constant 0.78539816339744828 : f64
    %1178 = qlx.apply #qlx.action<pauli_rotation>(%1177#0, %cst_1169) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1170 = arith.constant 0.78539816339744828 : f64
    %1179:2 = qlx.apply #qlx.action<pauli_rotation>(%1178, %1177#1, %cst_1170) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1171 = arith.constant 0.78539816339744828 : f64
    %1180 = qlx.apply #qlx.action<pauli_rotation>(%999#2, %cst_1171) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1172 = arith.constant 0.78539816339744828 : f64
    %1181:2 = qlx.apply #qlx.action<pauli_rotation>(%998#3, %1180, %cst_1172) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1173 = arith.constant 0.78539816339744828 : f64
    %1182 = qlx.apply #qlx.action<pauli_rotation>(%1181#1, %cst_1173) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1174 = arith.constant 0.78539816339744828 : f64
    %1183:2 = qlx.apply #qlx.action<pauli_rotation>(%1181#0, %1182, %cst_1174) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1175 = arith.constant 0.78539816339744828 : f64
    %1184 = qlx.apply #qlx.action<pauli_rotation>(%1183#1, %cst_1175) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1176 = arith.constant 0.78539816339744828 : f64
    %1185:2 = qlx.apply #qlx.action<pauli_rotation>(%1183#0, %1184, %cst_1176) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1177 = arith.constant 0.78539816339744828 : f64
    %1186:2 = qlx.apply #qlx.action<pauli_rotation>(%1185#0, %1185#1, %cst_1177) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1178 = arith.constant 0.78539816339744828 : f64
    %1187:2 = qlx.apply #qlx.action<pauli_rotation>(%1186#0, %1186#1, %cst_1178) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1179 = arith.constant 0.78539816339744828 : f64
    %1188:2 = qlx.apply #qlx.action<pauli_rotation>(%1187#0, %1187#1, %cst_1179) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1180 = arith.constant 0.78539816339744828 : f64
    %1189 = qlx.apply #qlx.action<pauli_rotation>(%1188#1, %cst_1180) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1181 = arith.constant 0.78539816339744828 : f64
    %1190:2 = qlx.apply #qlx.action<pauli_rotation>(%1188#0, %1189, %cst_1181) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1182 = arith.constant 0.78539816339744828 : f64
    %1191:2 = qlx.apply #qlx.action<pauli_rotation>(%1190#0, %1190#1, %cst_1182) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1183 = arith.constant 0.78539816339744828 : f64
    %1192:2 = qlx.apply #qlx.action<pauli_rotation>(%1191#0, %1191#1, %cst_1183) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1184 = arith.constant 0.78539816339744828 : f64
    %1193 = qlx.apply #qlx.action<pauli_rotation>(%1192#1, %cst_1184) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1185 = arith.constant 0.78539816339744828 : f64
    %1194:2 = qlx.apply #qlx.action<pauli_rotation>(%1192#0, %1193, %cst_1185) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1186 = arith.constant 0.78539816339744828 : f64
    %1195:2 = qlx.apply #qlx.action<pauli_rotation>(%1194#0, %1194#1, %cst_1186) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1187 = arith.constant 0.78539816339744828 : f64
    %1196:2 = qlx.apply #qlx.action<pauli_rotation>(%1195#0, %1195#1, %cst_1187) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1188 = arith.constant 0.78539816339744828 : f64
    %1197:2 = qlx.apply #qlx.action<pauli_rotation>(%1196#0, %1196#1, %cst_1188) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1189 = arith.constant 0.78539816339744828 : f64
    %1198 = qlx.apply #qlx.action<pauli_rotation>(%1197#1, %cst_1189) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1190 = arith.constant 0.78539816339744828 : f64
    %1199:2 = qlx.apply #qlx.action<pauli_rotation>(%1197#0, %1198, %cst_1190) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1191 = arith.constant 0.78539816339744828 : f64
    %1200 = qlx.apply #qlx.action<pauli_rotation>(%1199#1, %cst_1191) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1192 = arith.constant 0.78539816339744828 : f64
    %1201:2 = qlx.apply #qlx.action<pauli_rotation>(%1199#0, %1200, %cst_1192) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1193 = arith.constant 0.78539816339744828 : f64
    %1202 = qlx.apply #qlx.action<pauli_rotation>(%1201#1, %cst_1193) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1194 = arith.constant 0.78539816339744828 : f64
    %1203:2 = qlx.apply #qlx.action<pauli_rotation>(%1201#0, %1202, %cst_1194) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1195 = arith.constant 0.78539816339744828 : f64
    %1204:2 = qlx.apply #qlx.action<pauli_rotation>(%1203#0, %1203#1, %cst_1195) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1196 = arith.constant 0.78539816339744828 : f64
    %1205:2 = qlx.apply #qlx.action<pauli_rotation>(%1204#0, %1204#1, %cst_1196) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1197 = arith.constant 0.78539816339744828 : f64
    %1206:2 = qlx.apply #qlx.action<pauli_rotation>(%1205#0, %1205#1, %cst_1197) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1198 = arith.constant 0.78539816339744828 : f64
    %1207 = qlx.apply #qlx.action<pauli_rotation>(%1206#1, %cst_1198) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1199 = arith.constant 0.78539816339744828 : f64
    %1208:2 = qlx.apply #qlx.action<pauli_rotation>(%1206#0, %1207, %cst_1199) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1200 = arith.constant 0.78539816339744828 : f64
    %1209 = qlx.apply #qlx.action<pauli_rotation>(%1208#1, %cst_1200) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1201 = arith.constant 0.78539816339744828 : f64
    %1210:2 = qlx.apply #qlx.action<pauli_rotation>(%1208#0, %1209, %cst_1201) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1202 = arith.constant 0.78539816339744828 : f64
    %1211 = qlx.apply #qlx.action<pauli_rotation>(%1210#1, %cst_1202) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1203 = arith.constant 0.78539816339744828 : f64
    %1212:2 = qlx.apply #qlx.action<pauli_rotation>(%1210#0, %1211, %cst_1203) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1204 = arith.constant 0.78539816339744828 : f64
    %1213:2 = qlx.apply #qlx.action<pauli_rotation>(%1212#0, %1212#1, %cst_1204) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1205 = arith.constant 0.78539816339744828 : f64
    %1214 = qlx.apply #qlx.action<pauli_rotation>(%1213#1, %cst_1205) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1206 = arith.constant 0.78539816339744828 : f64
    %1215:2 = qlx.apply #qlx.action<pauli_rotation>(%1213#0, %1214, %cst_1206) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1207 = arith.constant 0.78539816339744828 : f64
    %1216 = qlx.apply #qlx.action<pauli_rotation>(%1215#1, %cst_1207) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1208 = arith.constant 0.78539816339744828 : f64
    %1217:2 = qlx.apply #qlx.action<pauli_rotation>(%1215#0, %1216, %cst_1208) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1209 = arith.constant 0.78539816339744828 : f64
    %1218 = qlx.apply #qlx.action<pauli_rotation>(%1217#1, %cst_1209) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1210 = arith.constant 0.78539816339744828 : f64
    %1219:2 = qlx.apply #qlx.action<pauli_rotation>(%1217#0, %1218, %cst_1210) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1211 = arith.constant 0.78539816339744828 : f64
    %1220 = qlx.apply #qlx.action<pauli_rotation>(%1219#1, %cst_1211) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1212 = arith.constant 0.78539816339744828 : f64
    %1221:2 = qlx.apply #qlx.action<pauli_rotation>(%1219#0, %1220, %cst_1212) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1213 = arith.constant 0.78539816339744828 : f64
    %1222:2 = qlx.apply #qlx.action<pauli_rotation>(%1221#0, %1221#1, %cst_1213) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1214 = arith.constant 0.78539816339744828 : f64
    %1223 = qlx.apply #qlx.action<pauli_rotation>(%1222#1, %cst_1214) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1215 = arith.constant 0.78539816339744828 : f64
    %1224:2 = qlx.apply #qlx.action<pauli_rotation>(%1222#0, %1223, %cst_1215) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1216 = arith.constant 0.78539816339744828 : f64
    %1225:2 = qlx.apply #qlx.action<pauli_rotation>(%1224#0, %1224#1, %cst_1216) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1217 = arith.constant 0.78539816339744828 : f64
    %1226 = qlx.apply #qlx.action<pauli_rotation>(%1225#1, %cst_1217) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1218 = arith.constant 0.78539816339744828 : f64
    %1227:2 = qlx.apply #qlx.action<pauli_rotation>(%1225#0, %1226, %cst_1218) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1219 = arith.constant 0.78539816339744828 : f64
    %1228 = qlx.apply #qlx.action<pauli_rotation>(%1227#1, %cst_1219) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1220 = arith.constant 0.78539816339744828 : f64
    %1229:2 = qlx.apply #qlx.action<pauli_rotation>(%1227#0, %1228, %cst_1220) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1221 = arith.constant 0.78539816339744828 : f64
    %1230:2 = qlx.apply #qlx.action<pauli_rotation>(%1229#0, %1229#1, %cst_1221) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1222 = arith.constant 0.78539816339744828 : f64
    %1231 = qlx.apply #qlx.action<pauli_rotation>(%1230#1, %cst_1222) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1223 = arith.constant 0.78539816339744828 : f64
    %1232:2 = qlx.apply #qlx.action<pauli_rotation>(%1230#0, %1231, %cst_1223) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1224 = arith.constant 0.78539816339744828 : f64
    %1233:2 = qlx.apply #qlx.action<pauli_rotation>(%1232#0, %1232#1, %cst_1224) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1225 = arith.constant 0.78539816339744828 : f64
    %1234 = qlx.apply #qlx.action<pauli_rotation>(%1233#1, %cst_1225) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1226 = arith.constant 0.78539816339744828 : f64
    %1235:2 = qlx.apply #qlx.action<pauli_rotation>(%1233#0, %1234, %cst_1226) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1227 = arith.constant 0.78539816339744828 : f64
    %1236:2 = qlx.apply #qlx.action<pauli_rotation>(%1235#0, %1235#1, %cst_1227) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1228 = arith.constant 0.78539816339744828 : f64
    %1237:2 = qlx.apply #qlx.action<pauli_rotation>(%1236#0, %1236#1, %cst_1228) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1229 = arith.constant 0.78539816339744828 : f64
    %1238 = qlx.apply #qlx.action<pauli_rotation>(%1237#1, %cst_1229) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1230 = arith.constant 0.78539816339744828 : f64
    %1239:2 = qlx.apply #qlx.action<pauli_rotation>(%1237#0, %1238, %cst_1230) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1231 = arith.constant 0.78539816339744828 : f64
    %1240:5 = qlx.apply #qlx.action<pauli_rotation>(%1059#0, %1059#1, %1119#0, %1119#1, %1179#0, %cst_1231) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1232 = arith.constant 0.78539816339744828 : f64
    %1241:5 = qlx.apply #qlx.action<pauli_rotation>(%1240#0, %1240#1, %1240#2, %1240#3, %1240#4, %cst_1232) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1233 = arith.constant 0.78539816339744828 : f64
    %1242:5 = qlx.apply #qlx.action<pauli_rotation>(%1241#2, %1241#3, %1241#4, %1179#1, %1239#0, %cst_1233) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1234 = arith.constant 0.78539816339744828 : f64
    %1243:5 = qlx.apply #qlx.action<pauli_rotation>(%1242#0, %1242#1, %1242#2, %1242#3, %1242#4, %cst_1234) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1235 = arith.constant 0.78539816339744828 : f64
    %1244:3 = qlx.apply #qlx.action<pauli_rotation>(%1243#2, %1243#3, %1243#4, %cst_1235) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1236 = arith.constant 0.78539816339744828 : f64
    %1245:7 = qlx.apply #qlx.action<pauli_rotation>(%1241#0, %1241#1, %1243#0, %1243#1, %1244#0, %1244#1, %1244#2, %cst_1236) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1237 = arith.constant 0.78539816339744828 : f64
    %1246:5 = qlx.apply #qlx.action<pauli_rotation>(%1245#0, %1245#1, %1245#2, %1245#3, %1245#4, %cst_1237) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1238 = arith.constant 0.78539816339744828 : f64
    %1247:3 = qlx.apply #qlx.action<pauli_rotation>(%1246#4, %1245#5, %1245#6, %cst_1238) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1239 = arith.constant 0.78539816339744828 : f64
    %1248:7 = qlx.apply #qlx.action<pauli_rotation>(%1246#0, %1246#1, %1246#2, %1246#3, %1247#0, %1247#1, %1247#2, %cst_1239) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1240 = arith.constant 0.78539816339744828 : f64
    %1249:3 = qlx.apply #qlx.action<pauli_rotation>(%1248#4, %1248#5, %1248#6, %cst_1240) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1241 = arith.constant 0.78539816339744828 : f64
    %1250:5 = qlx.apply #qlx.action<pauli_rotation>(%1248#0, %1248#1, %1248#2, %1248#3, %1249#0, %cst_1241) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1242 = arith.constant 0.78539816339744828 : f64
    %1251:3 = qlx.apply #qlx.action<pauli_rotation>(%1250#4, %1249#1, %1249#2, %cst_1242) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1243 = arith.constant 0.78539816339744828 : f64
    %1252:5 = qlx.apply #qlx.action<pauli_rotation>(%1250#0, %1250#1, %1250#2, %1250#3, %1251#0, %cst_1243) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1244 = arith.constant 0.78539816339744828 : f64
    %1253:3 = qlx.apply #qlx.action<pauli_rotation>(%1252#4, %1251#1, %1251#2, %cst_1244) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1245 = arith.constant 0.78539816339744828 : f64
    %1254:5 = qlx.apply #qlx.action<pauli_rotation>(%1252#0, %1252#1, %1252#2, %1252#3, %1253#0, %cst_1245) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1246 = arith.constant 0.78539816339744828 : f64
    %1255:3 = qlx.apply #qlx.action<pauli_rotation>(%1254#4, %1253#1, %1253#2, %cst_1246) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1247 = arith.constant 0.78539816339744828 : f64
    %1256:7 = qlx.apply #qlx.action<pauli_rotation>(%1254#0, %1254#1, %1254#2, %1254#3, %1255#0, %1255#1, %1255#2, %cst_1247) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1248 = arith.constant 0.78539816339744828 : f64
    %1257:5 = qlx.apply #qlx.action<pauli_rotation>(%1256#0, %1256#1, %1256#2, %1256#3, %1256#4, %cst_1248) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1249 = arith.constant 0.78539816339744828 : f64
    %1258:7 = qlx.apply #qlx.action<pauli_rotation>(%1257#0, %1257#1, %1257#2, %1257#3, %1257#4, %1256#5, %1256#6, %cst_1249) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1250 = arith.constant 0.78539816339744828 : f64
    %1259:3 = qlx.apply #qlx.action<pauli_rotation>(%1258#4, %1258#5, %1258#6, %cst_1250) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1251 = arith.constant 0.78539816339744828 : f64
    %1260:7 = qlx.apply #qlx.action<pauli_rotation>(%1258#0, %1258#1, %1258#2, %1258#3, %1259#0, %1259#1, %1259#2, %cst_1251) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1252 = arith.constant 0.78539816339744828 : f64
    %1261:5 = qlx.apply #qlx.action<pauli_rotation>(%1260#0, %1260#1, %1260#2, %1260#3, %1260#4, %cst_1252) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1253 = arith.constant 0.78539816339744828 : f64
    %1262:3 = qlx.apply #qlx.action<pauli_rotation>(%1261#4, %1260#5, %1260#6, %cst_1253) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1254 = arith.constant 0.78539816339744828 : f64
    %1263:5 = qlx.apply #qlx.action<pauli_rotation>(%1261#0, %1261#1, %1261#2, %1261#3, %1262#0, %cst_1254) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1255 = arith.constant 0.78539816339744828 : f64
    %1264:3 = qlx.apply #qlx.action<pauli_rotation>(%1263#4, %1262#1, %1262#2, %cst_1255) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1256 = arith.constant 0.78539816339744828 : f64
    %1265:5 = qlx.apply #qlx.action<pauli_rotation>(%1263#0, %1263#1, %1263#2, %1263#3, %1264#0, %cst_1256) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1257 = arith.constant 0.78539816339744828 : f64
    %1266:3 = qlx.apply #qlx.action<pauli_rotation>(%1265#4, %1264#1, %1264#2, %cst_1257) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1258 = arith.constant 0.78539816339744828 : f64
    %1267:7 = qlx.apply #qlx.action<pauli_rotation>(%1265#0, %1265#1, %1265#2, %1265#3, %1266#0, %1266#1, %1266#2, %cst_1258) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1259 = arith.constant 0.78539816339744828 : f64
    %1268:3 = qlx.apply #qlx.action<pauli_rotation>(%1267#4, %1267#5, %1267#6, %cst_1259) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1260 = arith.constant 0.78539816339744828 : f64
    %1269:5 = qlx.apply #qlx.action<pauli_rotation>(%1267#0, %1267#1, %1267#2, %1267#3, %1268#0, %cst_1260) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1261 = arith.constant 0.78539816339744828 : f64
    %1270:7 = qlx.apply #qlx.action<pauli_rotation>(%1269#0, %1269#1, %1269#2, %1269#3, %1269#4, %1268#1, %1268#2, %cst_1261) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1262 = arith.constant 0.78539816339744828 : f64
    %1271:3 = qlx.apply #qlx.action<pauli_rotation>(%1270#4, %1270#5, %1270#6, %cst_1262) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1263 = arith.constant 0.78539816339744828 : f64
    %1272:7 = qlx.apply #qlx.action<pauli_rotation>(%1270#0, %1270#1, %1270#2, %1270#3, %1271#0, %1271#1, %1271#2, %cst_1263) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1264 = arith.constant 0.78539816339744828 : f64
    %1273:5 = qlx.apply #qlx.action<pauli_rotation>(%1272#0, %1272#1, %1272#2, %1272#3, %1272#4, %cst_1264) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1265 = arith.constant 0.78539816339744828 : f64
    %1274:7 = qlx.apply #qlx.action<pauli_rotation>(%1273#0, %1273#1, %1273#2, %1273#3, %1273#4, %1272#5, %1272#6, %cst_1265) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1266 = arith.constant 0.78539816339744828 : f64
    %1275:3 = qlx.apply #qlx.action<pauli_rotation>(%1274#4, %1274#5, %1274#6, %cst_1266) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1267 = arith.constant 0.78539816339744828 : f64
    %1276:5 = qlx.apply #qlx.action<pauli_rotation>(%1274#0, %1274#1, %1274#2, %1274#3, %1275#0, %cst_1267) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1268 = arith.constant 0.78539816339744828 : f64
    %1277:7 = qlx.apply #qlx.action<pauli_rotation>(%1276#0, %1276#1, %1276#2, %1276#3, %1276#4, %1275#1, %1275#2, %cst_1268) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1269 = arith.constant 0.78539816339744828 : f64
    %1278:5 = qlx.apply #qlx.action<pauli_rotation>(%1277#0, %1277#1, %1277#2, %1277#3, %1277#4, %cst_1269) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1270 = arith.constant 0.78539816339744828 : f64
    %1279:3 = qlx.apply #qlx.action<pauli_rotation>(%1278#4, %1277#5, %1277#6, %cst_1270) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1271 = arith.constant 0.78539816339744828 : f64
    %1280:5 = qlx.apply #qlx.action<pauli_rotation>(%1278#0, %1278#1, %1278#2, %1278#3, %1279#0, %cst_1271) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1272 = arith.constant 0.78539816339744828 : f64
    %1281:3 = qlx.apply #qlx.action<pauli_rotation>(%1280#4, %1279#1, %1279#2, %cst_1272) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1273 = arith.constant 0.78539816339744828 : f64
    %1282:7 = qlx.apply #qlx.action<pauli_rotation>(%1280#0, %1280#1, %1280#2, %1280#3, %1281#0, %1281#1, %1281#2, %cst_1273) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1274 = arith.constant 0.78539816339744828 : f64
    %1283:3 = qlx.apply #qlx.action<pauli_rotation>(%1282#4, %1282#5, %1282#6, %cst_1274) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1275 = arith.constant 0.78539816339744828 : f64
    %1284:5 = qlx.apply #qlx.action<pauli_rotation>(%1282#0, %1282#1, %1282#2, %1282#3, %1283#0, %cst_1275) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1276 = arith.constant 0.78539816339744828 : f64
    %1285:7 = qlx.apply #qlx.action<pauli_rotation>(%1284#0, %1284#1, %1284#2, %1284#3, %1284#4, %1283#1, %1283#2, %cst_1276) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1277 = arith.constant 0.78539816339744828 : f64
    %1286:5 = qlx.apply #qlx.action<pauli_rotation>(%1285#0, %1285#1, %1285#2, %1285#3, %1285#4, %cst_1277) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1278 = arith.constant 0.78539816339744828 : f64
    %1287:7 = qlx.apply #qlx.action<pauli_rotation>(%1286#0, %1286#1, %1286#2, %1286#3, %1286#4, %1285#5, %1285#6, %cst_1278) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1279 = arith.constant 0.78539816339744828 : f64
    %1288:3 = qlx.apply #qlx.action<pauli_rotation>(%1287#4, %1287#5, %1287#6, %cst_1279) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1280 = arith.constant 0.78539816339744828 : f64
    %1289:7 = qlx.apply #qlx.action<pauli_rotation>(%1287#0, %1287#1, %1287#2, %1287#3, %1288#0, %1288#1, %1288#2, %cst_1280) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1281 = arith.constant 0.78539816339744828 : f64
    %1290:3 = qlx.apply #qlx.action<pauli_rotation>(%1289#4, %1289#5, %1289#6, %cst_1281) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1282 = arith.constant 0.78539816339744828 : f64
    %1291:7 = qlx.apply #qlx.action<pauli_rotation>(%1289#0, %1289#1, %1289#2, %1289#3, %1290#0, %1290#1, %1290#2, %cst_1282) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1283 = arith.constant 0.78539816339744828 : f64
    %1292:5 = qlx.apply #qlx.action<pauli_rotation>(%1291#0, %1291#1, %1291#2, %1291#3, %1291#4, %cst_1283) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1284 = arith.constant 0.78539816339744828 : f64
    %1293:3 = qlx.apply #qlx.action<pauli_rotation>(%1292#4, %1291#5, %1291#6, %cst_1284) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1285 = arith.constant 0.78539816339744828 : f64
    %1294:5 = qlx.apply #qlx.action<pauli_rotation>(%1292#0, %1292#1, %1292#2, %1292#3, %1293#0, %cst_1285) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1286 = arith.constant 0.78539816339744828 : f64
    %1295:7 = qlx.apply #qlx.action<pauli_rotation>(%1294#0, %1294#1, %1294#2, %1294#3, %1294#4, %1293#1, %1293#2, %cst_1286) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1287 = arith.constant 0.78539816339744828 : f64
    %1296:5 = qlx.apply #qlx.action<pauli_rotation>(%1295#0, %1295#1, %1295#2, %1295#3, %1295#4, %cst_1287) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1288 = arith.constant 0.78539816339744828 : f64
    %1297:3 = qlx.apply #qlx.action<pauli_rotation>(%1296#4, %1295#5, %1295#6, %cst_1288) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1289 = arith.constant 0.78539816339744828 : f64
    %1298:5 = qlx.apply #qlx.action<pauli_rotation>(%1296#0, %1296#1, %1296#2, %1296#3, %1297#0, %cst_1289) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1290 = arith.constant 0.78539816339744828 : f64
    %1299:3 = qlx.apply #qlx.action<pauli_rotation>(%1298#4, %1297#1, %1297#2, %cst_1290) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1291 = arith.constant 0.78539816339744828 : f64
    %1300:5 = qlx.apply #qlx.action<pauli_rotation>(%1298#0, %1298#1, %1298#2, %1298#3, %1299#0, %cst_1291) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1292 = arith.constant 0.78539816339744828 : f64
    %1301:3 = qlx.apply #qlx.action<pauli_rotation>(%1300#4, %1299#1, %1299#2, %cst_1292) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1293 = arith.constant 0.78539816339744828 : f64
    %1302:5 = qlx.apply #qlx.action<pauli_rotation>(%1300#0, %1300#1, %1300#2, %1300#3, %1301#0, %cst_1293) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1294 = arith.constant 0.78539816339744828 : f64
    %1303:7 = qlx.apply #qlx.action<pauli_rotation>(%1302#0, %1302#1, %1302#2, %1302#3, %1302#4, %1301#1, %1301#2, %cst_1294) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 113 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1295 = arith.constant 0.78539816339744828 : f64
    %1304:3 = qlx.apply #qlx.action<pauli_rotation>(%1303#0, %1303#1, %1303#2, %cst_1295) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1296 = arith.constant 0.78539816339744828 : f64
    %1305:3 = qlx.apply #qlx.action<pauli_rotation>(%1304#2, %1303#3, %1303#4, %cst_1296) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1297 = arith.constant 0.78539816339744828 : f64
    %1306:5 = qlx.apply #qlx.action<pauli_rotation>(%1304#0, %1304#1, %1305#0, %1305#1, %1305#2, %cst_1297) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1298 = arith.constant 0.78539816339744828 : f64
    %1307:3 = qlx.apply #qlx.action<pauli_rotation>(%1306#0, %1306#1, %1306#2, %cst_1298) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1299 = arith.constant 0.78539816339744828 : f64
    %1308:3 = qlx.apply #qlx.action<pauli_rotation>(%1307#2, %1306#3, %1306#4, %cst_1299) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1300 = arith.constant 0.78539816339744828 : f64
    %1309:3 = qlx.apply #qlx.action<pauli_rotation>(%1307#0, %1307#1, %1308#0, %cst_1300) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1301 = arith.constant 0.78539816339744828 : f64
    %1310:5 = qlx.apply #qlx.action<pauli_rotation>(%1309#0, %1309#1, %1309#2, %1308#1, %1308#2, %cst_1301) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1302 = arith.constant 0.78539816339744828 : f64
    %1311:3 = qlx.apply #qlx.action<pauli_rotation>(%1310#0, %1310#1, %1310#2, %cst_1302) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1303 = arith.constant 0.78539816339744828 : f64
    %1312:5 = qlx.apply #qlx.action<pauli_rotation>(%1311#0, %1311#1, %1311#2, %1310#3, %1310#4, %cst_1303) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1304 = arith.constant 0.78539816339744828 : f64
    %1313:3 = qlx.apply #qlx.action<pauli_rotation>(%1312#0, %1312#1, %1312#2, %cst_1304) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1305 = arith.constant 0.78539816339744828 : f64
    %1314:5 = qlx.apply #qlx.action<pauli_rotation>(%1313#0, %1313#1, %1313#2, %1312#3, %1312#4, %cst_1305) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1306 = arith.constant 0.78539816339744828 : f64
    %1315:3 = qlx.apply #qlx.action<pauli_rotation>(%1314#0, %1314#1, %1314#2, %cst_1306) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1307 = arith.constant 0.78539816339744828 : f64
    %1316:3 = qlx.apply #qlx.action<pauli_rotation>(%1315#2, %1314#3, %1314#4, %cst_1307) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1308 = arith.constant 0.78539816339744828 : f64
    %1317:5 = qlx.apply #qlx.action<pauli_rotation>(%1315#0, %1315#1, %1316#0, %1316#1, %1316#2, %cst_1308) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1309 = arith.constant 0.78539816339744828 : f64
    %1318:3 = qlx.apply #qlx.action<pauli_rotation>(%1317#2, %1317#3, %1317#4, %cst_1309) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1310 = arith.constant 0.78539816339744828 : f64
    %1319:3 = qlx.apply #qlx.action<pauli_rotation>(%1317#0, %1317#1, %1318#0, %cst_1310) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1311 = arith.constant 0.78539816339744828 : f64
    %1320:3 = qlx.apply #qlx.action<pauli_rotation>(%1319#2, %1318#1, %1318#2, %cst_1311) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1312 = arith.constant 0.78539816339744828 : f64
    %1321:5 = qlx.apply #qlx.action<pauli_rotation>(%1319#0, %1319#1, %1320#0, %1320#1, %1320#2, %cst_1312) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1313 = arith.constant 0.78539816339744828 : f64
    %1322:3 = qlx.apply #qlx.action<pauli_rotation>(%1321#0, %1321#1, %1321#2, %cst_1313) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1314 = arith.constant 0.78539816339744828 : f64
    %1323:5 = qlx.apply #qlx.action<pauli_rotation>(%1322#0, %1322#1, %1322#2, %1321#3, %1321#4, %cst_1314) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1315 = arith.constant 0.78539816339744828 : f64
    %1324:3 = qlx.apply #qlx.action<pauli_rotation>(%1323#0, %1323#1, %1323#2, %cst_1315) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1316 = arith.constant 0.78539816339744828 : f64
    %1325:5 = qlx.apply #qlx.action<pauli_rotation>(%1324#0, %1324#1, %1324#2, %1323#3, %1323#4, %cst_1316) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1317 = arith.constant 0.78539816339744828 : f64
    %1326:3 = qlx.apply #qlx.action<pauli_rotation>(%1325#0, %1325#1, %1325#2, %cst_1317) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1318 = arith.constant 0.78539816339744828 : f64
    %1327:3 = qlx.apply #qlx.action<pauli_rotation>(%1326#2, %1325#3, %1325#4, %cst_1318) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1319 = arith.constant 0.78539816339744828 : f64
    %1328:3 = qlx.apply #qlx.action<pauli_rotation>(%1326#0, %1326#1, %1327#0, %cst_1319) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1320 = arith.constant 0.78539816339744828 : f64
    %1329:5 = qlx.apply #qlx.action<pauli_rotation>(%1328#0, %1328#1, %1328#2, %1327#1, %1327#2, %cst_1320) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1321 = arith.constant 0.78539816339744828 : f64
    %1330:3 = qlx.apply #qlx.action<pauli_rotation>(%1329#2, %1329#3, %1329#4, %cst_1321) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1322 = arith.constant 0.78539816339744828 : f64
    %1331:3 = qlx.apply #qlx.action<pauli_rotation>(%1329#0, %1329#1, %1330#0, %cst_1322) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1323 = arith.constant 0.78539816339744828 : f64
    %1332:3 = qlx.apply #qlx.action<pauli_rotation>(%1331#2, %1330#1, %1330#2, %cst_1323) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1324 = arith.constant 0.78539816339744828 : f64
    %1333:5 = qlx.apply #qlx.action<pauli_rotation>(%1331#0, %1331#1, %1332#0, %1332#1, %1332#2, %cst_1324) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1325 = arith.constant 0.78539816339744828 : f64
    %1334:3 = qlx.apply #qlx.action<pauli_rotation>(%1333#2, %1333#3, %1333#4, %cst_1325) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1326 = arith.constant 0.78539816339744828 : f64
    %1335:3 = qlx.apply #qlx.action<pauli_rotation>(%1333#0, %1333#1, %1334#0, %cst_1326) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1327 = arith.constant 0.78539816339744828 : f64
    %1336:5 = qlx.apply #qlx.action<pauli_rotation>(%1335#0, %1335#1, %1335#2, %1334#1, %1334#2, %cst_1327) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1328 = arith.constant 0.78539816339744828 : f64
    %1337:3 = qlx.apply #qlx.action<pauli_rotation>(%1336#2, %1336#3, %1336#4, %cst_1328) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1329 = arith.constant 0.78539816339744828 : f64
    %1338:5 = qlx.apply #qlx.action<pauli_rotation>(%1336#0, %1336#1, %1337#0, %1337#1, %1337#2, %cst_1329) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1330 = arith.constant 0.78539816339744828 : f64
    %1339:3 = qlx.apply #qlx.action<pauli_rotation>(%1338#0, %1338#1, %1338#2, %cst_1330) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1331 = arith.constant 0.78539816339744828 : f64
    %1340:5 = qlx.apply #qlx.action<pauli_rotation>(%1339#0, %1339#1, %1339#2, %1338#3, %1338#4, %cst_1331) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1332 = arith.constant 0.78539816339744828 : f64
    %1341:3 = qlx.apply #qlx.action<pauli_rotation>(%1340#0, %1340#1, %1340#2, %cst_1332) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1333 = arith.constant 0.78539816339744828 : f64
    %1342:3 = qlx.apply #qlx.action<pauli_rotation>(%1341#2, %1340#3, %1340#4, %cst_1333) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1334 = arith.constant 0.78539816339744828 : f64
    %1343:3 = qlx.apply #qlx.action<pauli_rotation>(%1341#0, %1341#1, %1342#0, %cst_1334) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1335 = arith.constant 0.78539816339744828 : f64
    %1344:5 = qlx.apply #qlx.action<pauli_rotation>(%1343#0, %1343#1, %1343#2, %1342#1, %1342#2, %cst_1335) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1336 = arith.constant 0.78539816339744828 : f64
    %1345:3 = qlx.apply #qlx.action<pauli_rotation>(%1344#2, %1344#3, %1344#4, %cst_1336) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1337 = arith.constant 0.78539816339744828 : f64
    %1346:5 = qlx.apply #qlx.action<pauli_rotation>(%1344#0, %1344#1, %1345#0, %1345#1, %1345#2, %cst_1337) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1338 = arith.constant 0.78539816339744828 : f64
    %1347:3 = qlx.apply #qlx.action<pauli_rotation>(%1346#2, %1346#3, %1346#4, %cst_1338) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1339 = arith.constant 0.78539816339744828 : f64
    %1348:3 = qlx.apply #qlx.action<pauli_rotation>(%1346#0, %1346#1, %1347#0, %cst_1339) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1340 = arith.constant 0.78539816339744828 : f64
    %1349:3 = qlx.apply #qlx.action<pauli_rotation>(%1348#2, %1347#1, %1347#2, %cst_1340) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1341 = arith.constant 0.78539816339744828 : f64
    %1350:3 = qlx.apply #qlx.action<pauli_rotation>(%1348#0, %1348#1, %1349#0, %cst_1341) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1342 = arith.constant 0.78539816339744828 : f64
    %1351:3 = qlx.apply #qlx.action<pauli_rotation>(%1350#2, %1349#1, %1349#2, %cst_1342) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1343 = arith.constant 0.78539816339744828 : f64
    %1352:5 = qlx.apply #qlx.action<pauli_rotation>(%1350#0, %1350#1, %1351#0, %1351#1, %1351#2, %cst_1343) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1344 = arith.constant 0.78539816339744828 : f64
    %1353:3 = qlx.apply #qlx.action<pauli_rotation>(%1352#0, %1352#1, %1352#2, %cst_1344) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1345 = arith.constant 0.78539816339744828 : f64
    %1354:5 = qlx.apply #qlx.action<pauli_rotation>(%1353#0, %1353#1, %1353#2, %1352#3, %1352#4, %cst_1345) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1346 = arith.constant 0.78539816339744828 : f64
    %1355:3 = qlx.apply #qlx.action<pauli_rotation>(%1354#2, %1354#3, %1354#4, %cst_1346) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1347 = arith.constant 0.78539816339744828 : f64
    %1356:5 = qlx.apply #qlx.action<pauli_rotation>(%1354#0, %1354#1, %1355#0, %1355#1, %1355#2, %cst_1347) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1348 = arith.constant 0.78539816339744828 : f64
    %1357:3 = qlx.apply #qlx.action<pauli_rotation>(%1356#0, %1356#1, %1356#2, %cst_1348) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1349 = arith.constant 0.78539816339744828 : f64
    %1358:5 = qlx.apply #qlx.action<pauli_rotation>(%1357#0, %1357#1, %1357#2, %1356#3, %1356#4, %cst_1349) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1350 = arith.constant 0.78539816339744828 : f64
    %1359:3 = qlx.apply #qlx.action<pauli_rotation>(%1358#0, %1358#1, %1358#2, %cst_1350) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1351 = arith.constant 0.78539816339744828 : f64
    %1360:5 = qlx.apply #qlx.action<pauli_rotation>(%1359#0, %1359#1, %1359#2, %1358#3, %1358#4, %cst_1351) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1352 = arith.constant 0.78539816339744828 : f64
    %1361:3 = qlx.apply #qlx.action<pauli_rotation>(%1360#0, %1360#1, %1360#2, %cst_1352) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1353 = arith.constant 0.78539816339744828 : f64
    %1362:5 = qlx.apply #qlx.action<pauli_rotation>(%1361#0, %1361#1, %1361#2, %1360#3, %1360#4, %cst_1353) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1354 = arith.constant 0.78539816339744828 : f64
    %1363:3 = qlx.apply #qlx.action<pauli_rotation>(%1362#2, %1362#3, %1362#4, %cst_1354) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1355 = arith.constant 0.78539816339744828 : f64
    %1364:5 = qlx.apply #qlx.action<pauli_rotation>(%1362#0, %1362#1, %1363#0, %1363#1, %1363#2, %cst_1355) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1356 = arith.constant 0.78539816339744828 : f64
    %1365:5 = qlx.apply #qlx.action<pauli_rotation>(%1364#0, %1364#1, %1364#2, %1364#3, %1364#4, %cst_1356) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1357 = arith.constant 0.78539816339744828 : f64
    %1366:5 = qlx.apply #qlx.action<pauli_rotation>(%1365#2, %1365#3, %1365#4, %1303#5, %1303#6, %cst_1357) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1358 = arith.constant 0.78539816339744828 : f64
    %1367:5 = qlx.apply #qlx.action<pauli_rotation>(%1366#0, %1366#1, %1366#2, %1366#3, %1366#4, %cst_1358) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1359 = arith.constant 0.78539816339744828 : f64
    %1368:5 = qlx.apply #qlx.action<pauli_rotation>(%1365#1, %1367#0, %1367#1, %1367#2, %1367#3, %cst_1359) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 25 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1360 = arith.constant 0.78539816339744828 : f64
    %1369:5 = qlx.apply #qlx.action<pauli_rotation>(%1368#0, %1368#1, %1368#2, %1368#3, %1368#4, %cst_1360) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1361 = arith.constant 0.78539816339744828 : f64
    %1370:5 = qlx.apply #qlx.action<pauli_rotation>(%1369#2, %1369#3, %1369#4, %1367#4, %1239#1, %cst_1361) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 23 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1362 = arith.constant 0.78539816339744828 : f64
    %1371:5 = qlx.apply #qlx.action<pauli_rotation>(%1370#0, %1370#1, %1370#2, %1370#3, %1370#4, %cst_1362) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 23 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1363 = arith.constant 0.78539816339744828 : f64
    %1372:3 = qlx.apply #qlx.action<pauli_rotation>(%1371#0, %1371#1, %1371#2, %cst_1363) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1364 = arith.constant 0.78539816339744828 : f64
    %1373:7 = qlx.apply #qlx.action<pauli_rotation>(%1369#0, %1369#1, %1372#0, %1372#1, %1372#2, %1371#3, %1371#4, %cst_1364) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1365 = arith.constant 0.78539816339744828 : f64
    %1374:7 = qlx.apply #qlx.action<pauli_rotation>(%1373#0, %1373#1, %1373#2, %1373#3, %1373#4, %1373#5, %1373#6, %cst_1365) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1366 = arith.constant 0.78539816339744828 : f64
    %1375:3 = qlx.apply #qlx.action<pauli_rotation>(%1374#2, %1374#3, %1374#4, %cst_1366) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1367 = arith.constant 0.78539816339744828 : f64
    %1376:7 = qlx.apply #qlx.action<pauli_rotation>(%1374#0, %1374#1, %1375#0, %1375#1, %1375#2, %1374#5, %1374#6, %cst_1367) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1368 = arith.constant 0.78539816339744828 : f64
    %1377:3 = qlx.apply #qlx.action<pauli_rotation>(%1376#2, %1376#3, %1376#4, %cst_1368) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1369 = arith.constant 0.78539816339744828 : f64
    %1378:7 = qlx.apply #qlx.action<pauli_rotation>(%1376#0, %1376#1, %1377#0, %1377#1, %1377#2, %1376#5, %1376#6, %cst_1369) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1370 = arith.constant 0.78539816339744828 : f64
    %1379:3 = qlx.apply #qlx.action<pauli_rotation>(%1378#2, %1378#3, %1378#4, %cst_1370) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1371 = arith.constant 0.78539816339744828 : f64
    %1380:7 = qlx.apply #qlx.action<pauli_rotation>(%1378#0, %1378#1, %1379#0, %1379#1, %1379#2, %1378#5, %1378#6, %cst_1371) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1372 = arith.constant 0.78539816339744828 : f64
    %1381:3 = qlx.apply #qlx.action<pauli_rotation>(%1380#2, %1380#3, %1380#4, %cst_1372) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1373 = arith.constant 0.78539816339744828 : f64
    %1382:7 = qlx.apply #qlx.action<pauli_rotation>(%1380#0, %1380#1, %1381#0, %1381#1, %1381#2, %1380#5, %1380#6, %cst_1373) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1374 = arith.constant 0.78539816339744828 : f64
    %1383:3 = qlx.apply #qlx.action<pauli_rotation>(%1382#2, %1382#3, %1382#4, %cst_1374) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1375 = arith.constant 0.78539816339744828 : f64
    %1384:7 = qlx.apply #qlx.action<pauli_rotation>(%1382#0, %1382#1, %1383#0, %1383#1, %1383#2, %1382#5, %1382#6, %cst_1375) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1376 = arith.constant 0.78539816339744828 : f64
    %1385:7 = qlx.apply #qlx.action<pauli_rotation>(%1384#0, %1384#1, %1384#2, %1384#3, %1384#4, %1384#5, %1384#6, %cst_1376) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1377 = arith.constant 0.78539816339744828 : f64
    %1386:7 = qlx.apply #qlx.action<pauli_rotation>(%1385#0, %1385#1, %1385#2, %1385#3, %1385#4, %1385#5, %1385#6, %cst_1377) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1378 = arith.constant 0.78539816339744828 : f64
    %1387:3 = qlx.apply #qlx.action<pauli_rotation>(%1386#2, %1386#3, %1386#4, %cst_1378) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1379 = arith.constant 0.78539816339744828 : f64
    %1388:7 = qlx.apply #qlx.action<pauli_rotation>(%1386#0, %1386#1, %1387#0, %1387#1, %1387#2, %1386#5, %1386#6, %cst_1379) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1380 = arith.constant 0.78539816339744828 : f64
    %1389:7 = qlx.apply #qlx.action<pauli_rotation>(%1388#0, %1388#1, %1388#2, %1388#3, %1388#4, %1388#5, %1388#6, %cst_1380) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1381 = arith.constant 0.78539816339744828 : f64
    %1390:3 = qlx.apply #qlx.action<pauli_rotation>(%1389#2, %1389#3, %1389#4, %cst_1381) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1382 = arith.constant 0.78539816339744828 : f64
    %1391:7 = qlx.apply #qlx.action<pauli_rotation>(%1389#0, %1389#1, %1390#0, %1390#1, %1390#2, %1389#5, %1389#6, %cst_1382) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1383 = arith.constant 0.78539816339744828 : f64
    %1392:3 = qlx.apply #qlx.action<pauli_rotation>(%1391#2, %1391#3, %1391#4, %cst_1383) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1384 = arith.constant 0.78539816339744828 : f64
    %1393:7 = qlx.apply #qlx.action<pauli_rotation>(%1391#0, %1391#1, %1392#0, %1392#1, %1392#2, %1391#5, %1391#6, %cst_1384) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1385 = arith.constant 0.78539816339744828 : f64
    %1394:3 = qlx.apply #qlx.action<pauli_rotation>(%1393#2, %1393#3, %1393#4, %cst_1385) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1386 = arith.constant 0.78539816339744828 : f64
    %1395:7 = qlx.apply #qlx.action<pauli_rotation>(%1393#0, %1393#1, %1394#0, %1394#1, %1394#2, %1393#5, %1393#6, %cst_1386) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1387 = arith.constant 0.78539816339744828 : f64
    %1396:3 = qlx.apply #qlx.action<pauli_rotation>(%1395#2, %1395#3, %1395#4, %cst_1387) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1388 = arith.constant 0.78539816339744828 : f64
    %1397:7 = qlx.apply #qlx.action<pauli_rotation>(%1395#0, %1395#1, %1396#0, %1396#1, %1396#2, %1395#5, %1395#6, %cst_1388) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1389 = arith.constant 0.78539816339744828 : f64
    %1398:7 = qlx.apply #qlx.action<pauli_rotation>(%1397#0, %1397#1, %1397#2, %1397#3, %1397#4, %1397#5, %1397#6, %cst_1389) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1390 = arith.constant 0.78539816339744828 : f64
    %1399:3 = qlx.apply #qlx.action<pauli_rotation>(%1398#2, %1398#3, %1398#4, %cst_1390) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1391 = arith.constant 0.78539816339744828 : f64
    %1400:7 = qlx.apply #qlx.action<pauli_rotation>(%1398#0, %1398#1, %1399#0, %1399#1, %1399#2, %1398#5, %1398#6, %cst_1391) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1392 = arith.constant 0.78539816339744828 : f64
    %1401:7 = qlx.apply #qlx.action<pauli_rotation>(%1400#0, %1400#1, %1400#2, %1400#3, %1400#4, %1400#5, %1400#6, %cst_1392) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1393 = arith.constant 0.78539816339744828 : f64
    %1402:7 = qlx.apply #qlx.action<pauli_rotation>(%1401#0, %1401#1, %1401#2, %1401#3, %1401#4, %1401#5, %1401#6, %cst_1393) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1394 = arith.constant 0.78539816339744828 : f64
    %1403:3 = qlx.apply #qlx.action<pauli_rotation>(%1402#2, %1402#3, %1402#4, %cst_1394) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1395 = arith.constant 0.78539816339744828 : f64
    %1404:7 = qlx.apply #qlx.action<pauli_rotation>(%1402#0, %1402#1, %1403#0, %1403#1, %1403#2, %1402#5, %1402#6, %cst_1395) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1396 = arith.constant 0.78539816339744828 : f64
    %1405:7 = qlx.apply #qlx.action<pauli_rotation>(%1404#0, %1404#1, %1404#2, %1404#3, %1404#4, %1404#5, %1404#6, %cst_1396) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1397 = arith.constant 0.78539816339744828 : f64
    %1406:7 = qlx.apply #qlx.action<pauli_rotation>(%1405#0, %1405#1, %1405#2, %1405#3, %1405#4, %1405#5, %1405#6, %cst_1397) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1398 = arith.constant 0.78539816339744828 : f64
    %1407:3 = qlx.apply #qlx.action<pauli_rotation>(%1406#2, %1406#3, %1406#4, %cst_1398) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1399 = arith.constant 0.78539816339744828 : f64
    %1408:7 = qlx.apply #qlx.action<pauli_rotation>(%1406#0, %1406#1, %1407#0, %1407#1, %1407#2, %1406#5, %1406#6, %cst_1399) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1400 = arith.constant 0.78539816339744828 : f64
    %1409:3 = qlx.apply #qlx.action<pauli_rotation>(%1408#2, %1408#3, %1408#4, %cst_1400) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1401 = arith.constant 0.78539816339744828 : f64
    %1410:7 = qlx.apply #qlx.action<pauli_rotation>(%1408#0, %1408#1, %1409#0, %1409#1, %1409#2, %1408#5, %1408#6, %cst_1401) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1402 = arith.constant 0.78539816339744828 : f64
    %1411:3 = qlx.apply #qlx.action<pauli_rotation>(%1410#2, %1410#3, %1410#4, %cst_1402) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1403 = arith.constant 0.78539816339744828 : f64
    %1412:7 = qlx.apply #qlx.action<pauli_rotation>(%1410#0, %1410#1, %1411#0, %1411#1, %1411#2, %1410#5, %1410#6, %cst_1403) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1404 = arith.constant 0.78539816339744828 : f64
    %1413:7 = qlx.apply #qlx.action<pauli_rotation>(%1412#0, %1412#1, %1412#2, %1412#3, %1412#4, %1412#5, %1412#6, %cst_1404) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1405 = arith.constant 0.78539816339744828 : f64
    %1414:7 = qlx.apply #qlx.action<pauli_rotation>(%1413#0, %1413#1, %1413#2, %1413#3, %1413#4, %1413#5, %1413#6, %cst_1405) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1406 = arith.constant 0.78539816339744828 : f64
    %1415:7 = qlx.apply #qlx.action<pauli_rotation>(%1414#0, %1414#1, %1414#2, %1414#3, %1414#4, %1414#5, %1414#6, %cst_1406) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1407 = arith.constant 0.78539816339744828 : f64
    %1416:3 = qlx.apply #qlx.action<pauli_rotation>(%1415#2, %1415#3, %1415#4, %cst_1407) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1408 = arith.constant 0.78539816339744828 : f64
    %1417:7 = qlx.apply #qlx.action<pauli_rotation>(%1415#0, %1415#1, %1416#0, %1416#1, %1416#2, %1415#5, %1415#6, %cst_1408) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1409 = arith.constant 0.78539816339744828 : f64
    %1418:3 = qlx.apply #qlx.action<pauli_rotation>(%1417#2, %1417#3, %1417#4, %cst_1409) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1410 = arith.constant 0.78539816339744828 : f64
    %1419:7 = qlx.apply #qlx.action<pauli_rotation>(%1417#0, %1417#1, %1418#0, %1418#1, %1418#2, %1417#5, %1417#6, %cst_1410) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1411 = arith.constant 0.78539816339744828 : f64
    %1420:7 = qlx.apply #qlx.action<pauli_rotation>(%1419#0, %1419#1, %1419#2, %1419#3, %1419#4, %1419#5, %1419#6, %cst_1411) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1412 = arith.constant 0.78539816339744828 : f64
    %1421:3 = qlx.apply #qlx.action<pauli_rotation>(%1420#2, %1420#3, %1420#4, %cst_1412) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1413 = arith.constant 0.78539816339744828 : f64
    %1422:7 = qlx.apply #qlx.action<pauli_rotation>(%1420#0, %1420#1, %1421#0, %1421#1, %1421#2, %1420#5, %1420#6, %cst_1413) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1414 = arith.constant 0.78539816339744828 : f64
    %1423:7 = qlx.apply #qlx.action<pauli_rotation>(%1422#0, %1422#1, %1422#2, %1422#3, %1422#4, %1422#5, %1422#6, %cst_1414) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1415 = arith.constant 0.78539816339744828 : f64
    %1424:7 = qlx.apply #qlx.action<pauli_rotation>(%1423#0, %1423#1, %1423#2, %1423#3, %1423#4, %1423#5, %1423#6, %cst_1415) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1416 = arith.constant 0.78539816339744828 : f64
    %1425:3 = qlx.apply #qlx.action<pauli_rotation>(%1424#2, %1424#3, %1424#4, %cst_1416) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1417 = arith.constant 0.78539816339744828 : f64
    %1426:7 = qlx.apply #qlx.action<pauli_rotation>(%1424#0, %1424#1, %1425#0, %1425#1, %1425#2, %1424#5, %1424#6, %cst_1417) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1418 = arith.constant 0.78539816339744828 : f64
    %1427:3 = qlx.apply #qlx.action<pauli_rotation>(%1426#2, %1426#3, %1426#4, %cst_1418) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1419 = arith.constant 0.78539816339744828 : f64
    %1428:7 = qlx.apply #qlx.action<pauli_rotation>(%1426#0, %1426#1, %1427#0, %1427#1, %1427#2, %1426#5, %1426#6, %cst_1419) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1420 = arith.constant 0.78539816339744828 : f64
    %1429:3 = qlx.apply #qlx.action<pauli_rotation>(%1428#2, %1428#3, %1428#4, %cst_1420) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1421 = arith.constant 0.78539816339744828 : f64
    %1430:7 = qlx.apply #qlx.action<pauli_rotation>(%1428#0, %1428#1, %1429#0, %1429#1, %1429#2, %1428#5, %1428#6, %cst_1421) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1422 = arith.constant 0.78539816339744828 : f64
    %1431:7 = qlx.apply #qlx.action<pauli_rotation>(%1430#0, %1430#1, %1430#2, %1430#3, %1430#4, %1430#5, %1430#6, %cst_1422) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 89 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1423 = arith.constant 0.78539816339744828 : f64
    %1432:5 = qlx.apply #qlx.action<pauli_rotation>(%1431#0, %1431#1, %1431#3, %1431#5, %1431#6, %cst_1423) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1424 = arith.constant 0.78539816339744828 : f64
    %1433:3 = qlx.apply #qlx.action<pauli_rotation>(%1431#2, %1432#2, %1431#4, %cst_1424) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1425 = arith.constant 0.78539816339744828 : f64
    %1434:7 = qlx.apply #qlx.action<pauli_rotation>(%1432#0, %1432#1, %1433#0, %1433#1, %1433#2, %1432#3, %1432#4, %cst_1425) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1426 = arith.constant 0.78539816339744828 : f64
    %1435:5 = qlx.apply #qlx.action<pauli_rotation>(%1434#0, %1434#1, %1434#3, %1434#5, %1434#6, %cst_1426) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1427 = arith.constant 0.78539816339744828 : f64
    %1436:3 = qlx.apply #qlx.action<pauli_rotation>(%1434#2, %1435#2, %1434#4, %cst_1427) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1428 = arith.constant 0.78539816339744828 : f64
    %1437:5 = qlx.apply #qlx.action<pauli_rotation>(%1435#0, %1435#1, %1436#1, %1435#3, %1435#4, %cst_1428) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1429 = arith.constant 0.78539816339744828 : f64
    %1438:7 = qlx.apply #qlx.action<pauli_rotation>(%1437#0, %1437#1, %1436#0, %1437#2, %1436#2, %1437#3, %1437#4, %cst_1429) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1430 = arith.constant 0.78539816339744828 : f64
    %1439:5 = qlx.apply #qlx.action<pauli_rotation>(%1438#0, %1438#1, %1438#3, %1438#5, %1438#6, %cst_1430) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1431 = arith.constant 0.78539816339744828 : f64
    %1440:7 = qlx.apply #qlx.action<pauli_rotation>(%1439#0, %1439#1, %1438#2, %1439#2, %1438#4, %1439#3, %1439#4, %cst_1431) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1432 = arith.constant 0.78539816339744828 : f64
    %1441:5 = qlx.apply #qlx.action<pauli_rotation>(%1440#0, %1440#1, %1440#3, %1440#5, %1440#6, %cst_1432) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1433 = arith.constant 0.78539816339744828 : f64
    %1442:7 = qlx.apply #qlx.action<pauli_rotation>(%1441#0, %1441#1, %1440#2, %1441#2, %1440#4, %1441#3, %1441#4, %cst_1433) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1434 = arith.constant 0.78539816339744828 : f64
    %1443:5 = qlx.apply #qlx.action<pauli_rotation>(%1442#0, %1442#1, %1442#3, %1442#5, %1442#6, %cst_1434) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1435 = arith.constant 0.78539816339744828 : f64
    %1444:3 = qlx.apply #qlx.action<pauli_rotation>(%1442#2, %1443#2, %1442#4, %cst_1435) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1436 = arith.constant 0.78539816339744828 : f64
    %1445:7 = qlx.apply #qlx.action<pauli_rotation>(%1443#0, %1443#1, %1444#0, %1444#1, %1444#2, %1443#3, %1443#4, %cst_1436) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1437 = arith.constant 0.78539816339744828 : f64
    %1446:3 = qlx.apply #qlx.action<pauli_rotation>(%1445#2, %1445#3, %1445#4, %cst_1437) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1438 = arith.constant 0.78539816339744828 : f64
    %1447:5 = qlx.apply #qlx.action<pauli_rotation>(%1445#0, %1445#1, %1446#1, %1445#5, %1445#6, %cst_1438) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1439 = arith.constant 0.78539816339744828 : f64
    %1448:3 = qlx.apply #qlx.action<pauli_rotation>(%1446#0, %1447#2, %1446#2, %cst_1439) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1440 = arith.constant 0.78539816339744828 : f64
    %1449:7 = qlx.apply #qlx.action<pauli_rotation>(%1447#0, %1447#1, %1448#0, %1448#1, %1448#2, %1447#3, %1447#4, %cst_1440) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1441 = arith.constant 0.78539816339744828 : f64
    %1450:5 = qlx.apply #qlx.action<pauli_rotation>(%1449#0, %1449#1, %1449#3, %1449#5, %1449#6, %cst_1441) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1442 = arith.constant 0.78539816339744828 : f64
    %1451:7 = qlx.apply #qlx.action<pauli_rotation>(%1450#0, %1450#1, %1449#2, %1450#2, %1449#4, %1450#3, %1450#4, %cst_1442) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1443 = arith.constant 0.78539816339744828 : f64
    %1452:5 = qlx.apply #qlx.action<pauli_rotation>(%1451#0, %1451#1, %1451#3, %1451#5, %1451#6, %cst_1443) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1444 = arith.constant 0.78539816339744828 : f64
    %1453:7 = qlx.apply #qlx.action<pauli_rotation>(%1452#0, %1452#1, %1451#2, %1452#2, %1451#4, %1452#3, %1452#4, %cst_1444) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1445 = arith.constant 0.78539816339744828 : f64
    %1454:5 = qlx.apply #qlx.action<pauli_rotation>(%1453#0, %1453#1, %1453#3, %1453#5, %1453#6, %cst_1445) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1446 = arith.constant 0.78539816339744828 : f64
    %1455:3 = qlx.apply #qlx.action<pauli_rotation>(%1453#2, %1454#2, %1453#4, %cst_1446) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1447 = arith.constant 0.78539816339744828 : f64
    %1456:5 = qlx.apply #qlx.action<pauli_rotation>(%1454#0, %1454#1, %1455#1, %1454#3, %1454#4, %cst_1447) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1448 = arith.constant 0.78539816339744828 : f64
    %1457:7 = qlx.apply #qlx.action<pauli_rotation>(%1456#0, %1456#1, %1455#0, %1456#2, %1455#2, %1456#3, %1456#4, %cst_1448) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1449 = arith.constant 0.78539816339744828 : f64
    %1458:3 = qlx.apply #qlx.action<pauli_rotation>(%1457#2, %1457#3, %1457#4, %cst_1449) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1450 = arith.constant 0.78539816339744828 : f64
    %1459:5 = qlx.apply #qlx.action<pauli_rotation>(%1457#0, %1457#1, %1458#1, %1457#5, %1457#6, %cst_1450) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1451 = arith.constant 0.78539816339744828 : f64
    %1460:3 = qlx.apply #qlx.action<pauli_rotation>(%1458#0, %1459#2, %1458#2, %cst_1451) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1452 = arith.constant 0.78539816339744828 : f64
    %1461:7 = qlx.apply #qlx.action<pauli_rotation>(%1459#0, %1459#1, %1460#0, %1460#1, %1460#2, %1459#3, %1459#4, %cst_1452) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1453 = arith.constant 0.78539816339744828 : f64
    %1462:3 = qlx.apply #qlx.action<pauli_rotation>(%1461#2, %1461#3, %1461#4, %cst_1453) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1454 = arith.constant 0.78539816339744828 : f64
    %1463:5 = qlx.apply #qlx.action<pauli_rotation>(%1461#0, %1461#1, %1462#1, %1461#5, %1461#6, %cst_1454) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1455 = arith.constant 0.78539816339744828 : f64
    %1464:7 = qlx.apply #qlx.action<pauli_rotation>(%1463#0, %1463#1, %1462#0, %1463#2, %1462#2, %1463#3, %1463#4, %cst_1455) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1456 = arith.constant 0.78539816339744828 : f64
    %1465:3 = qlx.apply #qlx.action<pauli_rotation>(%1464#2, %1464#3, %1464#4, %cst_1456) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1457 = arith.constant 0.78539816339744828 : f64
    %1466:7 = qlx.apply #qlx.action<pauli_rotation>(%1464#0, %1464#1, %1465#0, %1465#1, %1465#2, %1464#5, %1464#6, %cst_1457) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1458 = arith.constant 0.78539816339744828 : f64
    %1467:5 = qlx.apply #qlx.action<pauli_rotation>(%1466#0, %1466#1, %1466#3, %1466#5, %1466#6, %cst_1458) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1459 = arith.constant 0.78539816339744828 : f64
    %1468:7 = qlx.apply #qlx.action<pauli_rotation>(%1467#0, %1467#1, %1466#2, %1467#2, %1466#4, %1467#3, %1467#4, %cst_1459) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1460 = arith.constant 0.78539816339744828 : f64
    %1469:5 = qlx.apply #qlx.action<pauli_rotation>(%1468#0, %1468#1, %1468#3, %1468#5, %1468#6, %cst_1460) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1461 = arith.constant 0.78539816339744828 : f64
    %1470:3 = qlx.apply #qlx.action<pauli_rotation>(%1468#2, %1469#2, %1468#4, %cst_1461) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1462 = arith.constant 0.78539816339744828 : f64
    %1471:5 = qlx.apply #qlx.action<pauli_rotation>(%1469#0, %1469#1, %1470#1, %1469#3, %1469#4, %cst_1462) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1463 = arith.constant 0.78539816339744828 : f64
    %1472:7 = qlx.apply #qlx.action<pauli_rotation>(%1471#0, %1471#1, %1470#0, %1471#2, %1470#2, %1471#3, %1471#4, %cst_1463) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1464 = arith.constant 0.78539816339744828 : f64
    %1473:3 = qlx.apply #qlx.action<pauli_rotation>(%1472#2, %1472#3, %1472#4, %cst_1464) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1465 = arith.constant 0.78539816339744828 : f64
    %1474:7 = qlx.apply #qlx.action<pauli_rotation>(%1472#0, %1472#1, %1473#0, %1473#1, %1473#2, %1472#5, %1472#6, %cst_1465) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1466 = arith.constant 0.78539816339744828 : f64
    %1475:3 = qlx.apply #qlx.action<pauli_rotation>(%1474#2, %1474#3, %1474#4, %cst_1466) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1467 = arith.constant 0.78539816339744828 : f64
    %1476:5 = qlx.apply #qlx.action<pauli_rotation>(%1474#0, %1474#1, %1475#1, %1474#5, %1474#6, %cst_1467) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1468 = arith.constant 0.78539816339744828 : f64
    %1477:3 = qlx.apply #qlx.action<pauli_rotation>(%1475#0, %1476#2, %1475#2, %cst_1468) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1469 = arith.constant 0.78539816339744828 : f64
    %1478:5 = qlx.apply #qlx.action<pauli_rotation>(%1476#0, %1476#1, %1477#1, %1476#3, %1476#4, %cst_1469) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1470 = arith.constant 0.78539816339744828 : f64
    %1479:3 = qlx.apply #qlx.action<pauli_rotation>(%1477#0, %1478#2, %1477#2, %cst_1470) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1471 = arith.constant 0.78539816339744828 : f64
    %1480:7 = qlx.apply #qlx.action<pauli_rotation>(%1478#0, %1478#1, %1479#0, %1479#1, %1479#2, %1478#3, %1478#4, %cst_1471) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1472 = arith.constant 0.78539816339744828 : f64
    %1481:5 = qlx.apply #qlx.action<pauli_rotation>(%1480#0, %1480#1, %1480#3, %1480#5, %1480#6, %cst_1472) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1473 = arith.constant 0.78539816339744828 : f64
    %1482:7 = qlx.apply #qlx.action<pauli_rotation>(%1481#0, %1481#1, %1480#2, %1481#2, %1480#4, %1481#3, %1481#4, %cst_1473) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1474 = arith.constant 0.78539816339744828 : f64
    %1483:3 = qlx.apply #qlx.action<pauli_rotation>(%1482#2, %1482#3, %1482#4, %cst_1474) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1475 = arith.constant 0.78539816339744828 : f64
    %1484:7 = qlx.apply #qlx.action<pauli_rotation>(%1482#0, %1482#1, %1483#0, %1483#1, %1483#2, %1482#5, %1482#6, %cst_1475) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1476 = arith.constant 0.78539816339744828 : f64
    %1485:5 = qlx.apply #qlx.action<pauli_rotation>(%1484#0, %1484#1, %1484#3, %1484#5, %1484#6, %cst_1476) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1477 = arith.constant 0.78539816339744828 : f64
    %1486:7 = qlx.apply #qlx.action<pauli_rotation>(%1485#0, %1485#1, %1484#2, %1485#2, %1484#4, %1485#3, %1485#4, %cst_1477) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1478 = arith.constant 0.78539816339744828 : f64
    %1487:5 = qlx.apply #qlx.action<pauli_rotation>(%1486#0, %1486#1, %1486#3, %1486#5, %1486#6, %cst_1478) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1479 = arith.constant 0.78539816339744828 : f64
    %1488:7 = qlx.apply #qlx.action<pauli_rotation>(%1487#0, %1487#1, %1486#2, %1487#2, %1486#4, %1487#3, %1487#4, %cst_1479) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1480 = arith.constant 0.78539816339744828 : f64
    %1489:5 = qlx.apply #qlx.action<pauli_rotation>(%1488#0, %1488#1, %1488#3, %1488#5, %1488#6, %cst_1480) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 17 : i64, z_mask = 31 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1481 = arith.constant 0.78539816339744828 : f64
    %1490:7 = qlx.apply #qlx.action<pauli_rotation>(%1489#0, %1489#1, %1488#2, %1489#2, %1488#4, %1489#3, %1489#4, %cst_1481) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 77 : i64, z_mask = 119 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1482 = arith.constant 0.78539816339744828 : f64
    %1491:3 = qlx.apply #qlx.action<pauli_rotation>(%1490#2, %1490#3, %1490#4, %cst_1482) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1483 = arith.constant 0.78539816339744828 : f64
    %1492:5 = qlx.apply #qlx.action<pauli_rotation>(%1490#0, %1490#1, %1491#0, %1491#1, %1491#2, %cst_1483) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 25 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1484 = arith.constant 0.78539816339744828 : f64
    %1493:5 = qlx.apply #qlx.action<pauli_rotation>(%1492#0, %1492#1, %1492#2, %1492#3, %1492#4, %cst_1484) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 9 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1485 = arith.constant 0.78539816339744828 : f64
    %1494:5 = qlx.apply #qlx.action<pauli_rotation>(%1493#2, %1493#3, %1493#4, %1490#5, %1490#6, %cst_1485) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 23 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1486 = arith.constant 0.78539816339744828 : f64
    %1495:5 = qlx.apply #qlx.action<pauli_rotation>(%1494#0, %1494#1, %1494#2, %1494#3, %1494#4, %cst_1486) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 23 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1487 = arith.constant 0.78539816339744828 : f64
    %1496:2 = qlx.apply #qlx.action<pauli_rotation>(%1365#0, %1493#0, %cst_1487) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1488 = arith.constant 0.78539816339744828 : f64
    %1497 = qlx.apply #qlx.action<pauli_rotation>(%1496#1, %cst_1488) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1489 = arith.constant 0.78539816339744828 : f64
    %1498:2 = qlx.apply #qlx.action<pauli_rotation>(%1496#0, %1497, %cst_1489) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1490 = arith.constant 0.78539816339744828 : f64
    %1499:2 = qlx.apply #qlx.action<pauli_rotation>(%1498#0, %1498#1, %cst_1490) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1491 = arith.constant 0.78539816339744828 : f64
    %1500:2 = qlx.apply #qlx.action<pauli_rotation>(%1499#0, %1499#1, %cst_1491) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1492 = arith.constant 0.78539816339744828 : f64
    %1501 = qlx.apply #qlx.action<pauli_rotation>(%1500#1, %cst_1492) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1493 = arith.constant 0.78539816339744828 : f64
    %1502:2 = qlx.apply #qlx.action<pauli_rotation>(%1500#0, %1501, %cst_1493) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1494 = arith.constant 0.78539816339744828 : f64
    %1503 = qlx.apply #qlx.action<pauli_rotation>(%1502#1, %cst_1494) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1495 = arith.constant 0.78539816339744828 : f64
    %1504:2 = qlx.apply #qlx.action<pauli_rotation>(%1502#0, %1503, %cst_1495) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1496 = arith.constant 0.78539816339744828 : f64
    %1505:2 = qlx.apply #qlx.action<pauli_rotation>(%1504#0, %1504#1, %cst_1496) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1497 = arith.constant 0.78539816339744828 : f64
    %1506 = qlx.apply #qlx.action<pauli_rotation>(%1505#1, %cst_1497) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1498 = arith.constant 0.78539816339744828 : f64
    %1507:2 = qlx.apply #qlx.action<pauli_rotation>(%1505#0, %1506, %cst_1498) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1499 = arith.constant 0.78539816339744828 : f64
    %1508 = qlx.apply #qlx.action<pauli_rotation>(%1507#1, %cst_1499) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1500 = arith.constant 0.78539816339744828 : f64
    %1509:2 = qlx.apply #qlx.action<pauli_rotation>(%1507#0, %1508, %cst_1500) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1501 = arith.constant 0.78539816339744828 : f64
    %1510:2 = qlx.apply #qlx.action<pauli_rotation>(%1509#0, %1509#1, %cst_1501) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1502 = arith.constant 0.78539816339744828 : f64
    %1511 = qlx.apply #qlx.action<pauli_rotation>(%1510#1, %cst_1502) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1503 = arith.constant 0.78539816339744828 : f64
    %1512:2 = qlx.apply #qlx.action<pauli_rotation>(%1510#0, %1511, %cst_1503) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1504 = arith.constant 0.78539816339744828 : f64
    %1513 = qlx.apply #qlx.action<pauli_rotation>(%1512#1, %cst_1504) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1505 = arith.constant 0.78539816339744828 : f64
    %1514:2 = qlx.apply #qlx.action<pauli_rotation>(%1512#0, %1513, %cst_1505) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1506 = arith.constant 0.78539816339744828 : f64
    %1515 = qlx.apply #qlx.action<pauli_rotation>(%1514#1, %cst_1506) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1507 = arith.constant 0.78539816339744828 : f64
    %1516:2 = qlx.apply #qlx.action<pauli_rotation>(%1514#0, %1515, %cst_1507) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1508 = arith.constant 0.78539816339744828 : f64
    %1517 = qlx.apply #qlx.action<pauli_rotation>(%1516#1, %cst_1508) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1509 = arith.constant 0.78539816339744828 : f64
    %1518:2 = qlx.apply #qlx.action<pauli_rotation>(%1516#0, %1517, %cst_1509) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1510 = arith.constant 0.78539816339744828 : f64
    %1519 = qlx.apply #qlx.action<pauli_rotation>(%1518#1, %cst_1510) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1511 = arith.constant 0.78539816339744828 : f64
    %1520:2 = qlx.apply #qlx.action<pauli_rotation>(%1518#0, %1519, %cst_1511) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1512 = arith.constant 0.78539816339744828 : f64
    %1521 = qlx.apply #qlx.action<pauli_rotation>(%1520#1, %cst_1512) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1513 = arith.constant 0.78539816339744828 : f64
    %1522:2 = qlx.apply #qlx.action<pauli_rotation>(%1520#0, %1521, %cst_1513) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1514 = arith.constant 0.78539816339744828 : f64
    %1523:2 = qlx.apply #qlx.action<pauli_rotation>(%1522#0, %1522#1, %cst_1514) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1515 = arith.constant 0.78539816339744828 : f64
    %1524 = qlx.apply #qlx.action<pauli_rotation>(%1523#1, %cst_1515) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1516 = arith.constant 0.78539816339744828 : f64
    %1525:2 = qlx.apply #qlx.action<pauli_rotation>(%1523#0, %1524, %cst_1516) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1517 = arith.constant 0.78539816339744828 : f64
    %1526 = qlx.apply #qlx.action<pauli_rotation>(%1525#1, %cst_1517) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1518 = arith.constant 0.78539816339744828 : f64
    %1527:2 = qlx.apply #qlx.action<pauli_rotation>(%1525#0, %1526, %cst_1518) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1519 = arith.constant 0.78539816339744828 : f64
    %1528 = qlx.apply #qlx.action<pauli_rotation>(%1527#1, %cst_1519) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1520 = arith.constant 0.78539816339744828 : f64
    %1529:2 = qlx.apply #qlx.action<pauli_rotation>(%1527#0, %1528, %cst_1520) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1521 = arith.constant 0.78539816339744828 : f64
    %1530:2 = qlx.apply #qlx.action<pauli_rotation>(%1529#0, %1529#1, %cst_1521) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1522 = arith.constant 0.78539816339744828 : f64
    %1531:2 = qlx.apply #qlx.action<pauli_rotation>(%1530#0, %1530#1, %cst_1522) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1523 = arith.constant 0.78539816339744828 : f64
    %1532:2 = qlx.apply #qlx.action<pauli_rotation>(%1531#0, %1531#1, %cst_1523) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1524 = arith.constant 0.78539816339744828 : f64
    %1533:2 = qlx.apply #qlx.action<pauli_rotation>(%1532#0, %1532#1, %cst_1524) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1525 = arith.constant 0.78539816339744828 : f64
    %1534:2 = qlx.apply #qlx.action<pauli_rotation>(%1533#0, %1533#1, %cst_1525) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1526 = arith.constant 0.78539816339744828 : f64
    %1535 = qlx.apply #qlx.action<pauli_rotation>(%1534#1, %cst_1526) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1527 = arith.constant 0.78539816339744828 : f64
    %1536:2 = qlx.apply #qlx.action<pauli_rotation>(%1534#0, %1535, %cst_1527) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1528 = arith.constant 0.78539816339744828 : f64
    %1537:2 = qlx.apply #qlx.action<pauli_rotation>(%1536#0, %1536#1, %cst_1528) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1529 = arith.constant 0.78539816339744828 : f64
    %1538 = qlx.apply #qlx.action<pauli_rotation>(%1537#1, %cst_1529) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1530 = arith.constant 0.78539816339744828 : f64
    %1539:2 = qlx.apply #qlx.action<pauli_rotation>(%1537#0, %1538, %cst_1530) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1531 = arith.constant 0.78539816339744828 : f64
    %1540 = qlx.apply #qlx.action<pauli_rotation>(%1539#1, %cst_1531) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1532 = arith.constant 0.78539816339744828 : f64
    %1541:2 = qlx.apply #qlx.action<pauli_rotation>(%1539#0, %1540, %cst_1532) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1533 = arith.constant 0.78539816339744828 : f64
    %1542:2 = qlx.apply #qlx.action<pauli_rotation>(%1541#0, %1541#1, %cst_1533) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1534 = arith.constant 0.78539816339744828 : f64
    %1543 = qlx.apply #qlx.action<pauli_rotation>(%1542#1, %cst_1534) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1535 = arith.constant 0.78539816339744828 : f64
    %1544:2 = qlx.apply #qlx.action<pauli_rotation>(%1542#0, %1543, %cst_1535) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1536 = arith.constant 0.78539816339744828 : f64
    %1545:2 = qlx.apply #qlx.action<pauli_rotation>(%1544#0, %1544#1, %cst_1536) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1537 = arith.constant 0.78539816339744828 : f64
    %1546 = qlx.apply #qlx.action<pauli_rotation>(%1545#1, %cst_1537) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1538 = arith.constant 0.78539816339744828 : f64
    %1547:2 = qlx.apply #qlx.action<pauli_rotation>(%1545#0, %1546, %cst_1538) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1539 = arith.constant 0.78539816339744828 : f64
    %1548 = qlx.apply #qlx.action<pauli_rotation>(%1547#1, %cst_1539) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1540 = arith.constant 0.78539816339744828 : f64
    %1549:2 = qlx.apply #qlx.action<pauli_rotation>(%1547#0, %1548, %cst_1540) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1541 = arith.constant 0.78539816339744828 : f64
    %1550:2 = qlx.apply #qlx.action<pauli_rotation>(%1549#0, %1549#1, %cst_1541) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1542 = arith.constant 0.78539816339744828 : f64
    %1551 = qlx.apply #qlx.action<pauli_rotation>(%1550#1, %cst_1542) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1543 = arith.constant 0.78539816339744828 : f64
    %1552:2 = qlx.apply #qlx.action<pauli_rotation>(%1550#0, %1551, %cst_1543) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1544 = arith.constant 0.78539816339744828 : f64
    %1553 = qlx.apply #qlx.action<pauli_rotation>(%1552#1, %cst_1544) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1545 = arith.constant 0.78539816339744828 : f64
    %1554:2 = qlx.apply #qlx.action<pauli_rotation>(%1552#0, %1553, %cst_1545) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1546 = arith.constant 0.78539816339744828 : f64
    %1555 = qlx.apply #qlx.action<pauli_rotation>(%1554#1, %cst_1546) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1547 = arith.constant 0.78539816339744828 : f64
    %1556:2 = qlx.apply #qlx.action<pauli_rotation>(%1493#1, %1495#0, %cst_1547) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1548 = arith.constant 0.78539816339744828 : f64
    %1557 = qlx.apply #qlx.action<pauli_rotation>(%1556#1, %cst_1548) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1549 = arith.constant 0.78539816339744828 : f64
    %1558:2 = qlx.apply #qlx.action<pauli_rotation>(%1556#0, %1557, %cst_1549) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1550 = arith.constant 0.78539816339744828 : f64
    %1559:2 = qlx.apply #qlx.action<pauli_rotation>(%1558#0, %1558#1, %cst_1550) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1551 = arith.constant 0.78539816339744828 : f64
    %1560:2 = qlx.apply #qlx.action<pauli_rotation>(%1559#0, %1559#1, %cst_1551) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1552 = arith.constant 0.78539816339744828 : f64
    %1561 = qlx.apply #qlx.action<pauli_rotation>(%1560#1, %cst_1552) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1553 = arith.constant 0.78539816339744828 : f64
    %1562:2 = qlx.apply #qlx.action<pauli_rotation>(%1560#0, %1561, %cst_1553) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1554 = arith.constant 0.78539816339744828 : f64
    %1563 = qlx.apply #qlx.action<pauli_rotation>(%1562#1, %cst_1554) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1555 = arith.constant 0.78539816339744828 : f64
    %1564:2 = qlx.apply #qlx.action<pauli_rotation>(%1562#0, %1563, %cst_1555) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1556 = arith.constant 0.78539816339744828 : f64
    %1565:2 = qlx.apply #qlx.action<pauli_rotation>(%1564#0, %1564#1, %cst_1556) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1557 = arith.constant 0.78539816339744828 : f64
    %1566 = qlx.apply #qlx.action<pauli_rotation>(%1565#1, %cst_1557) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1558 = arith.constant 0.78539816339744828 : f64
    %1567:2 = qlx.apply #qlx.action<pauli_rotation>(%1565#0, %1566, %cst_1558) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1559 = arith.constant 0.78539816339744828 : f64
    %1568 = qlx.apply #qlx.action<pauli_rotation>(%1567#1, %cst_1559) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1560 = arith.constant 0.78539816339744828 : f64
    %1569:2 = qlx.apply #qlx.action<pauli_rotation>(%1567#0, %1568, %cst_1560) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1561 = arith.constant 0.78539816339744828 : f64
    %1570:2 = qlx.apply #qlx.action<pauli_rotation>(%1569#0, %1569#1, %cst_1561) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1562 = arith.constant 0.78539816339744828 : f64
    %1571 = qlx.apply #qlx.action<pauli_rotation>(%1570#1, %cst_1562) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1563 = arith.constant 0.78539816339744828 : f64
    %1572:2 = qlx.apply #qlx.action<pauli_rotation>(%1570#0, %1571, %cst_1563) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1564 = arith.constant 0.78539816339744828 : f64
    %1573 = qlx.apply #qlx.action<pauli_rotation>(%1572#1, %cst_1564) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1565 = arith.constant 0.78539816339744828 : f64
    %1574:2 = qlx.apply #qlx.action<pauli_rotation>(%1572#0, %1573, %cst_1565) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1566 = arith.constant 0.78539816339744828 : f64
    %1575 = qlx.apply #qlx.action<pauli_rotation>(%1574#1, %cst_1566) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1567 = arith.constant 0.78539816339744828 : f64
    %1576:2 = qlx.apply #qlx.action<pauli_rotation>(%1574#0, %1575, %cst_1567) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1568 = arith.constant 0.78539816339744828 : f64
    %1577 = qlx.apply #qlx.action<pauli_rotation>(%1576#1, %cst_1568) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1569 = arith.constant 0.78539816339744828 : f64
    %1578:2 = qlx.apply #qlx.action<pauli_rotation>(%1576#0, %1577, %cst_1569) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1570 = arith.constant 0.78539816339744828 : f64
    %1579 = qlx.apply #qlx.action<pauli_rotation>(%1578#1, %cst_1570) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1571 = arith.constant 0.78539816339744828 : f64
    %1580:2 = qlx.apply #qlx.action<pauli_rotation>(%1578#0, %1579, %cst_1571) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1572 = arith.constant 0.78539816339744828 : f64
    %1581 = qlx.apply #qlx.action<pauli_rotation>(%1580#1, %cst_1572) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1573 = arith.constant 0.78539816339744828 : f64
    %1582:2 = qlx.apply #qlx.action<pauli_rotation>(%1580#0, %1581, %cst_1573) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1574 = arith.constant 0.78539816339744828 : f64
    %1583:2 = qlx.apply #qlx.action<pauli_rotation>(%1582#0, %1582#1, %cst_1574) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1575 = arith.constant 0.78539816339744828 : f64
    %1584 = qlx.apply #qlx.action<pauli_rotation>(%1583#1, %cst_1575) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1576 = arith.constant 0.78539816339744828 : f64
    %1585:2 = qlx.apply #qlx.action<pauli_rotation>(%1583#0, %1584, %cst_1576) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1577 = arith.constant 0.78539816339744828 : f64
    %1586 = qlx.apply #qlx.action<pauli_rotation>(%1585#1, %cst_1577) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1578 = arith.constant 0.78539816339744828 : f64
    %1587:2 = qlx.apply #qlx.action<pauli_rotation>(%1585#0, %1586, %cst_1578) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1579 = arith.constant 0.78539816339744828 : f64
    %1588 = qlx.apply #qlx.action<pauli_rotation>(%1587#1, %cst_1579) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1580 = arith.constant 0.78539816339744828 : f64
    %1589:2 = qlx.apply #qlx.action<pauli_rotation>(%1587#0, %1588, %cst_1580) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1581 = arith.constant 0.78539816339744828 : f64
    %1590:2 = qlx.apply #qlx.action<pauli_rotation>(%1589#0, %1589#1, %cst_1581) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1582 = arith.constant 0.78539816339744828 : f64
    %1591:2 = qlx.apply #qlx.action<pauli_rotation>(%1590#0, %1590#1, %cst_1582) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1583 = arith.constant 0.78539816339744828 : f64
    %1592:2 = qlx.apply #qlx.action<pauli_rotation>(%1591#0, %1591#1, %cst_1583) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1584 = arith.constant 0.78539816339744828 : f64
    %1593:2 = qlx.apply #qlx.action<pauli_rotation>(%1592#0, %1592#1, %cst_1584) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1585 = arith.constant 0.78539816339744828 : f64
    %1594:2 = qlx.apply #qlx.action<pauli_rotation>(%1593#0, %1593#1, %cst_1585) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1586 = arith.constant 0.78539816339744828 : f64
    %1595 = qlx.apply #qlx.action<pauli_rotation>(%1594#1, %cst_1586) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1587 = arith.constant 0.78539816339744828 : f64
    %1596:2 = qlx.apply #qlx.action<pauli_rotation>(%1594#0, %1595, %cst_1587) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1588 = arith.constant 0.78539816339744828 : f64
    %1597:2 = qlx.apply #qlx.action<pauli_rotation>(%1596#0, %1596#1, %cst_1588) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1589 = arith.constant 0.78539816339744828 : f64
    %1598 = qlx.apply #qlx.action<pauli_rotation>(%1597#1, %cst_1589) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1590 = arith.constant 0.78539816339744828 : f64
    %1599:2 = qlx.apply #qlx.action<pauli_rotation>(%1597#0, %1598, %cst_1590) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1591 = arith.constant 0.78539816339744828 : f64
    %1600 = qlx.apply #qlx.action<pauli_rotation>(%1599#1, %cst_1591) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1592 = arith.constant 0.78539816339744828 : f64
    %1601:2 = qlx.apply #qlx.action<pauli_rotation>(%1599#0, %1600, %cst_1592) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1593 = arith.constant 0.78539816339744828 : f64
    %1602:2 = qlx.apply #qlx.action<pauli_rotation>(%1601#0, %1601#1, %cst_1593) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1594 = arith.constant 0.78539816339744828 : f64
    %1603 = qlx.apply #qlx.action<pauli_rotation>(%1602#1, %cst_1594) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1595 = arith.constant 0.78539816339744828 : f64
    %1604:2 = qlx.apply #qlx.action<pauli_rotation>(%1602#0, %1603, %cst_1595) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1596 = arith.constant 0.78539816339744828 : f64
    %1605:2 = qlx.apply #qlx.action<pauli_rotation>(%1604#0, %1604#1, %cst_1596) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1597 = arith.constant 0.78539816339744828 : f64
    %1606 = qlx.apply #qlx.action<pauli_rotation>(%1605#1, %cst_1597) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1598 = arith.constant 0.78539816339744828 : f64
    %1607:2 = qlx.apply #qlx.action<pauli_rotation>(%1605#0, %1606, %cst_1598) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1599 = arith.constant 0.78539816339744828 : f64
    %1608 = qlx.apply #qlx.action<pauli_rotation>(%1607#1, %cst_1599) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1600 = arith.constant 0.78539816339744828 : f64
    %1609:2 = qlx.apply #qlx.action<pauli_rotation>(%1607#0, %1608, %cst_1600) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1601 = arith.constant 0.78539816339744828 : f64
    %1610:2 = qlx.apply #qlx.action<pauli_rotation>(%1609#0, %1609#1, %cst_1601) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1602 = arith.constant 0.78539816339744828 : f64
    %1611 = qlx.apply #qlx.action<pauli_rotation>(%1610#1, %cst_1602) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1603 = arith.constant 0.78539816339744828 : f64
    %1612:2 = qlx.apply #qlx.action<pauli_rotation>(%1610#0, %1611, %cst_1603) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1604 = arith.constant 0.78539816339744828 : f64
    %1613 = qlx.apply #qlx.action<pauli_rotation>(%1612#1, %cst_1604) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1605 = arith.constant 0.78539816339744828 : f64
    %1614:2 = qlx.apply #qlx.action<pauli_rotation>(%1612#0, %1613, %cst_1605) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1606 = arith.constant 0.78539816339744828 : f64
    %1615 = qlx.apply #qlx.action<pauli_rotation>(%1614#1, %cst_1606) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1607 = arith.constant 0.78539816339744828 : f64
    %1616:2 = qlx.apply #qlx.action<pauli_rotation>(%1495#1, %1495#2, %cst_1607) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1608 = arith.constant 0.78539816339744828 : f64
    %1617 = qlx.apply #qlx.action<pauli_rotation>(%1616#0, %cst_1608) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1609 = arith.constant 0.78539816339744828 : f64
    %1618:2 = qlx.apply #qlx.action<pauli_rotation>(%1617, %1616#1, %cst_1609) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1610 = arith.constant 0.78539816339744828 : f64
    %1619:2 = qlx.apply #qlx.action<pauli_rotation>(%1618#0, %1618#1, %cst_1610) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1611 = arith.constant 0.78539816339744828 : f64
    %1620:2 = qlx.apply #qlx.action<pauli_rotation>(%1619#0, %1619#1, %cst_1611) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1612 = arith.constant 0.78539816339744828 : f64
    %1621 = qlx.apply #qlx.action<pauli_rotation>(%1620#0, %cst_1612) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1613 = arith.constant 0.78539816339744828 : f64
    %1622:2 = qlx.apply #qlx.action<pauli_rotation>(%1621, %1620#1, %cst_1613) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1614 = arith.constant 0.78539816339744828 : f64
    %1623 = qlx.apply #qlx.action<pauli_rotation>(%1622#0, %cst_1614) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1615 = arith.constant 0.78539816339744828 : f64
    %1624:2 = qlx.apply #qlx.action<pauli_rotation>(%1623, %1622#1, %cst_1615) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1616 = arith.constant 0.78539816339744828 : f64
    %1625:2 = qlx.apply #qlx.action<pauli_rotation>(%1624#0, %1624#1, %cst_1616) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1617 = arith.constant 0.78539816339744828 : f64
    %1626 = qlx.apply #qlx.action<pauli_rotation>(%1625#0, %cst_1617) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1618 = arith.constant 0.78539816339744828 : f64
    %1627:2 = qlx.apply #qlx.action<pauli_rotation>(%1626, %1625#1, %cst_1618) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1619 = arith.constant 0.78539816339744828 : f64
    %1628 = qlx.apply #qlx.action<pauli_rotation>(%1627#0, %cst_1619) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1620 = arith.constant 0.78539816339744828 : f64
    %1629:2 = qlx.apply #qlx.action<pauli_rotation>(%1628, %1627#1, %cst_1620) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1621 = arith.constant 0.78539816339744828 : f64
    %1630:2 = qlx.apply #qlx.action<pauli_rotation>(%1629#0, %1629#1, %cst_1621) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1622 = arith.constant 0.78539816339744828 : f64
    %1631 = qlx.apply #qlx.action<pauli_rotation>(%1630#0, %cst_1622) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1623 = arith.constant 0.78539816339744828 : f64
    %1632:2 = qlx.apply #qlx.action<pauli_rotation>(%1631, %1630#1, %cst_1623) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1624 = arith.constant 0.78539816339744828 : f64
    %1633 = qlx.apply #qlx.action<pauli_rotation>(%1632#0, %cst_1624) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1625 = arith.constant 0.78539816339744828 : f64
    %1634:2 = qlx.apply #qlx.action<pauli_rotation>(%1633, %1632#1, %cst_1625) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1626 = arith.constant 0.78539816339744828 : f64
    %1635 = qlx.apply #qlx.action<pauli_rotation>(%1634#0, %cst_1626) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1627 = arith.constant 0.78539816339744828 : f64
    %1636:2 = qlx.apply #qlx.action<pauli_rotation>(%1635, %1634#1, %cst_1627) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1628 = arith.constant 0.78539816339744828 : f64
    %1637 = qlx.apply #qlx.action<pauli_rotation>(%1636#0, %cst_1628) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1629 = arith.constant 0.78539816339744828 : f64
    %1638:2 = qlx.apply #qlx.action<pauli_rotation>(%1637, %1636#1, %cst_1629) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1630 = arith.constant 0.78539816339744828 : f64
    %1639 = qlx.apply #qlx.action<pauli_rotation>(%1638#0, %cst_1630) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1631 = arith.constant 0.78539816339744828 : f64
    %1640:2 = qlx.apply #qlx.action<pauli_rotation>(%1639, %1638#1, %cst_1631) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1632 = arith.constant 0.78539816339744828 : f64
    %1641 = qlx.apply #qlx.action<pauli_rotation>(%1640#0, %cst_1632) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1633 = arith.constant 0.78539816339744828 : f64
    %1642:2 = qlx.apply #qlx.action<pauli_rotation>(%1641, %1640#1, %cst_1633) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1634 = arith.constant 0.78539816339744828 : f64
    %1643:2 = qlx.apply #qlx.action<pauli_rotation>(%1642#0, %1642#1, %cst_1634) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1635 = arith.constant 0.78539816339744828 : f64
    %1644 = qlx.apply #qlx.action<pauli_rotation>(%1643#0, %cst_1635) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1636 = arith.constant 0.78539816339744828 : f64
    %1645:2 = qlx.apply #qlx.action<pauli_rotation>(%1644, %1643#1, %cst_1636) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1637 = arith.constant 0.78539816339744828 : f64
    %1646 = qlx.apply #qlx.action<pauli_rotation>(%1645#0, %cst_1637) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1638 = arith.constant 0.78539816339744828 : f64
    %1647:2 = qlx.apply #qlx.action<pauli_rotation>(%1646, %1645#1, %cst_1638) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1639 = arith.constant 0.78539816339744828 : f64
    %1648 = qlx.apply #qlx.action<pauli_rotation>(%1647#0, %cst_1639) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1640 = arith.constant 0.78539816339744828 : f64
    %1649:2 = qlx.apply #qlx.action<pauli_rotation>(%1648, %1647#1, %cst_1640) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1641 = arith.constant 0.78539816339744828 : f64
    %1650:2 = qlx.apply #qlx.action<pauli_rotation>(%1649#0, %1649#1, %cst_1641) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1642 = arith.constant 0.78539816339744828 : f64
    %1651:2 = qlx.apply #qlx.action<pauli_rotation>(%1650#0, %1650#1, %cst_1642) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1643 = arith.constant 0.78539816339744828 : f64
    %1652:2 = qlx.apply #qlx.action<pauli_rotation>(%1651#0, %1651#1, %cst_1643) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1644 = arith.constant 0.78539816339744828 : f64
    %1653:2 = qlx.apply #qlx.action<pauli_rotation>(%1652#0, %1652#1, %cst_1644) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1645 = arith.constant 0.78539816339744828 : f64
    %1654:2 = qlx.apply #qlx.action<pauli_rotation>(%1653#0, %1653#1, %cst_1645) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1646 = arith.constant 0.78539816339744828 : f64
    %1655 = qlx.apply #qlx.action<pauli_rotation>(%1654#0, %cst_1646) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1647 = arith.constant 0.78539816339744828 : f64
    %1656:2 = qlx.apply #qlx.action<pauli_rotation>(%1655, %1654#1, %cst_1647) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1648 = arith.constant 0.78539816339744828 : f64
    %1657:2 = qlx.apply #qlx.action<pauli_rotation>(%1656#0, %1656#1, %cst_1648) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1649 = arith.constant 0.78539816339744828 : f64
    %1658 = qlx.apply #qlx.action<pauli_rotation>(%1657#0, %cst_1649) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1650 = arith.constant 0.78539816339744828 : f64
    %1659:2 = qlx.apply #qlx.action<pauli_rotation>(%1658, %1657#1, %cst_1650) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1651 = arith.constant 0.78539816339744828 : f64
    %1660 = qlx.apply #qlx.action<pauli_rotation>(%1659#0, %cst_1651) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1652 = arith.constant 0.78539816339744828 : f64
    %1661:2 = qlx.apply #qlx.action<pauli_rotation>(%1660, %1659#1, %cst_1652) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1653 = arith.constant 0.78539816339744828 : f64
    %1662:2 = qlx.apply #qlx.action<pauli_rotation>(%1661#0, %1661#1, %cst_1653) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1654 = arith.constant 0.78539816339744828 : f64
    %1663 = qlx.apply #qlx.action<pauli_rotation>(%1662#0, %cst_1654) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1655 = arith.constant 0.78539816339744828 : f64
    %1664:2 = qlx.apply #qlx.action<pauli_rotation>(%1663, %1662#1, %cst_1655) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1656 = arith.constant 0.78539816339744828 : f64
    %1665:2 = qlx.apply #qlx.action<pauli_rotation>(%1664#0, %1664#1, %cst_1656) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1657 = arith.constant 0.78539816339744828 : f64
    %1666 = qlx.apply #qlx.action<pauli_rotation>(%1665#0, %cst_1657) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1658 = arith.constant 0.78539816339744828 : f64
    %1667:2 = qlx.apply #qlx.action<pauli_rotation>(%1666, %1665#1, %cst_1658) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1659 = arith.constant 0.78539816339744828 : f64
    %1668 = qlx.apply #qlx.action<pauli_rotation>(%1667#0, %cst_1659) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1660 = arith.constant 0.78539816339744828 : f64
    %1669:2 = qlx.apply #qlx.action<pauli_rotation>(%1668, %1667#1, %cst_1660) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1661 = arith.constant 0.78539816339744828 : f64
    %1670:2 = qlx.apply #qlx.action<pauli_rotation>(%1669#0, %1669#1, %cst_1661) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1662 = arith.constant 0.78539816339744828 : f64
    %1671 = qlx.apply #qlx.action<pauli_rotation>(%1670#0, %cst_1662) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1663 = arith.constant 0.78539816339744828 : f64
    %1672:2 = qlx.apply #qlx.action<pauli_rotation>(%1671, %1670#1, %cst_1663) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1664 = arith.constant 0.78539816339744828 : f64
    %1673 = qlx.apply #qlx.action<pauli_rotation>(%1672#0, %cst_1664) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1665 = arith.constant 0.78539816339744828 : f64
    %1674:2 = qlx.apply #qlx.action<pauli_rotation>(%1673, %1672#1, %cst_1665) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1666 = arith.constant 0.78539816339744828 : f64
    %1675 = qlx.apply #qlx.action<pauli_rotation>(%1674#0, %cst_1666) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1667 = arith.constant 0.78539816339744828 : f64
    %1676:2 = qlx.apply #qlx.action<pauli_rotation>(%1495#3, %1495#4, %cst_1667) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1668 = arith.constant 0.78539816339744828 : f64
    %1677 = qlx.apply #qlx.action<pauli_rotation>(%1676#1, %cst_1668) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1669 = arith.constant 0.78539816339744828 : f64
    %1678:2 = qlx.apply #qlx.action<pauli_rotation>(%1676#0, %1677, %cst_1669) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1670 = arith.constant 0.78539816339744828 : f64
    %1679:2 = qlx.apply #qlx.action<pauli_rotation>(%1678#0, %1678#1, %cst_1670) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1671 = arith.constant 0.78539816339744828 : f64
    %1680:2 = qlx.apply #qlx.action<pauli_rotation>(%1679#0, %1679#1, %cst_1671) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1672 = arith.constant 0.78539816339744828 : f64
    %1681 = qlx.apply #qlx.action<pauli_rotation>(%1680#1, %cst_1672) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1673 = arith.constant 0.78539816339744828 : f64
    %1682:2 = qlx.apply #qlx.action<pauli_rotation>(%1680#0, %1681, %cst_1673) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1674 = arith.constant 0.78539816339744828 : f64
    %1683 = qlx.apply #qlx.action<pauli_rotation>(%1682#1, %cst_1674) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1675 = arith.constant 0.78539816339744828 : f64
    %1684:2 = qlx.apply #qlx.action<pauli_rotation>(%1682#0, %1683, %cst_1675) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1676 = arith.constant 0.78539816339744828 : f64
    %1685:2 = qlx.apply #qlx.action<pauli_rotation>(%1684#0, %1684#1, %cst_1676) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1677 = arith.constant 0.78539816339744828 : f64
    %1686 = qlx.apply #qlx.action<pauli_rotation>(%1685#1, %cst_1677) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1678 = arith.constant 0.78539816339744828 : f64
    %1687:2 = qlx.apply #qlx.action<pauli_rotation>(%1685#0, %1686, %cst_1678) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1679 = arith.constant 0.78539816339744828 : f64
    %1688 = qlx.apply #qlx.action<pauli_rotation>(%1687#1, %cst_1679) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1680 = arith.constant 0.78539816339744828 : f64
    %1689:2 = qlx.apply #qlx.action<pauli_rotation>(%1687#0, %1688, %cst_1680) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1681 = arith.constant 0.78539816339744828 : f64
    %1690:2 = qlx.apply #qlx.action<pauli_rotation>(%1689#0, %1689#1, %cst_1681) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1682 = arith.constant 0.78539816339744828 : f64
    %1691 = qlx.apply #qlx.action<pauli_rotation>(%1690#1, %cst_1682) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1683 = arith.constant 0.78539816339744828 : f64
    %1692:2 = qlx.apply #qlx.action<pauli_rotation>(%1690#0, %1691, %cst_1683) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1684 = arith.constant 0.78539816339744828 : f64
    %1693 = qlx.apply #qlx.action<pauli_rotation>(%1692#1, %cst_1684) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1685 = arith.constant 0.78539816339744828 : f64
    %1694:2 = qlx.apply #qlx.action<pauli_rotation>(%1692#0, %1693, %cst_1685) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1686 = arith.constant 0.78539816339744828 : f64
    %1695 = qlx.apply #qlx.action<pauli_rotation>(%1694#1, %cst_1686) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1687 = arith.constant 0.78539816339744828 : f64
    %1696:2 = qlx.apply #qlx.action<pauli_rotation>(%1694#0, %1695, %cst_1687) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1688 = arith.constant 0.78539816339744828 : f64
    %1697 = qlx.apply #qlx.action<pauli_rotation>(%1696#1, %cst_1688) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1689 = arith.constant 0.78539816339744828 : f64
    %1698:2 = qlx.apply #qlx.action<pauli_rotation>(%1696#0, %1697, %cst_1689) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1690 = arith.constant 0.78539816339744828 : f64
    %1699 = qlx.apply #qlx.action<pauli_rotation>(%1698#1, %cst_1690) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1691 = arith.constant 0.78539816339744828 : f64
    %1700:2 = qlx.apply #qlx.action<pauli_rotation>(%1698#0, %1699, %cst_1691) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1692 = arith.constant 0.78539816339744828 : f64
    %1701 = qlx.apply #qlx.action<pauli_rotation>(%1700#1, %cst_1692) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1693 = arith.constant 0.78539816339744828 : f64
    %1702:2 = qlx.apply #qlx.action<pauli_rotation>(%1700#0, %1701, %cst_1693) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1694 = arith.constant 0.78539816339744828 : f64
    %1703:2 = qlx.apply #qlx.action<pauli_rotation>(%1702#0, %1702#1, %cst_1694) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1695 = arith.constant 0.78539816339744828 : f64
    %1704 = qlx.apply #qlx.action<pauli_rotation>(%1703#1, %cst_1695) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1696 = arith.constant 0.78539816339744828 : f64
    %1705:2 = qlx.apply #qlx.action<pauli_rotation>(%1703#0, %1704, %cst_1696) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1697 = arith.constant 0.78539816339744828 : f64
    %1706 = qlx.apply #qlx.action<pauli_rotation>(%1705#1, %cst_1697) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1698 = arith.constant 0.78539816339744828 : f64
    %1707:2 = qlx.apply #qlx.action<pauli_rotation>(%1705#0, %1706, %cst_1698) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1699 = arith.constant 0.78539816339744828 : f64
    %1708 = qlx.apply #qlx.action<pauli_rotation>(%1707#1, %cst_1699) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1700 = arith.constant 0.78539816339744828 : f64
    %1709:2 = qlx.apply #qlx.action<pauli_rotation>(%1707#0, %1708, %cst_1700) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1701 = arith.constant 0.78539816339744828 : f64
    %1710:2 = qlx.apply #qlx.action<pauli_rotation>(%1709#0, %1709#1, %cst_1701) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1702 = arith.constant 0.78539816339744828 : f64
    %1711:2 = qlx.apply #qlx.action<pauli_rotation>(%1710#0, %1710#1, %cst_1702) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1703 = arith.constant 0.78539816339744828 : f64
    %1712:2 = qlx.apply #qlx.action<pauli_rotation>(%1711#0, %1711#1, %cst_1703) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1704 = arith.constant 0.78539816339744828 : f64
    %1713:2 = qlx.apply #qlx.action<pauli_rotation>(%1712#0, %1712#1, %cst_1704) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1705 = arith.constant 0.78539816339744828 : f64
    %1714:2 = qlx.apply #qlx.action<pauli_rotation>(%1713#0, %1713#1, %cst_1705) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1706 = arith.constant 0.78539816339744828 : f64
    %1715 = qlx.apply #qlx.action<pauli_rotation>(%1714#1, %cst_1706) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1707 = arith.constant 0.78539816339744828 : f64
    %1716:2 = qlx.apply #qlx.action<pauli_rotation>(%1714#0, %1715, %cst_1707) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1708 = arith.constant 0.78539816339744828 : f64
    %1717:2 = qlx.apply #qlx.action<pauli_rotation>(%1716#0, %1716#1, %cst_1708) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1709 = arith.constant 0.78539816339744828 : f64
    %1718 = qlx.apply #qlx.action<pauli_rotation>(%1717#1, %cst_1709) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1710 = arith.constant 0.78539816339744828 : f64
    %1719:2 = qlx.apply #qlx.action<pauli_rotation>(%1717#0, %1718, %cst_1710) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1711 = arith.constant 0.78539816339744828 : f64
    %1720 = qlx.apply #qlx.action<pauli_rotation>(%1719#1, %cst_1711) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1712 = arith.constant 0.78539816339744828 : f64
    %1721:2 = qlx.apply #qlx.action<pauli_rotation>(%1719#0, %1720, %cst_1712) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1713 = arith.constant 0.78539816339744828 : f64
    %1722:2 = qlx.apply #qlx.action<pauli_rotation>(%1721#0, %1721#1, %cst_1713) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1714 = arith.constant 0.78539816339744828 : f64
    %1723 = qlx.apply #qlx.action<pauli_rotation>(%1722#1, %cst_1714) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1715 = arith.constant 0.78539816339744828 : f64
    %1724:2 = qlx.apply #qlx.action<pauli_rotation>(%1722#0, %1723, %cst_1715) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1716 = arith.constant 0.78539816339744828 : f64
    %1725:2 = qlx.apply #qlx.action<pauli_rotation>(%1724#0, %1724#1, %cst_1716) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1717 = arith.constant 0.78539816339744828 : f64
    %1726 = qlx.apply #qlx.action<pauli_rotation>(%1725#1, %cst_1717) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1718 = arith.constant 0.78539816339744828 : f64
    %1727:2 = qlx.apply #qlx.action<pauli_rotation>(%1725#0, %1726, %cst_1718) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1719 = arith.constant 0.78539816339744828 : f64
    %1728 = qlx.apply #qlx.action<pauli_rotation>(%1727#1, %cst_1719) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1720 = arith.constant 0.78539816339744828 : f64
    %1729:2 = qlx.apply #qlx.action<pauli_rotation>(%1727#0, %1728, %cst_1720) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1721 = arith.constant 0.78539816339744828 : f64
    %1730:2 = qlx.apply #qlx.action<pauli_rotation>(%1729#0, %1729#1, %cst_1721) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1722 = arith.constant 0.78539816339744828 : f64
    %1731 = qlx.apply #qlx.action<pauli_rotation>(%1730#1, %cst_1722) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1723 = arith.constant 0.78539816339744828 : f64
    %1732:2 = qlx.apply #qlx.action<pauli_rotation>(%1730#0, %1731, %cst_1723) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1724 = arith.constant 0.78539816339744828 : f64
    %1733 = qlx.apply #qlx.action<pauli_rotation>(%1732#1, %cst_1724) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1725 = arith.constant 0.78539816339744828 : f64
    %1734:2 = qlx.apply #qlx.action<pauli_rotation>(%1732#0, %1733, %cst_1725) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1726 = arith.constant 0.78539816339744828 : f64
    %1735 = qlx.apply #qlx.action<pauli_rotation>(%1734#1, %cst_1726) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1727 = arith.constant 0.78539816339744828 : f64
    %1736:5 = qlx.apply #qlx.action<pauli_rotation>(%1554#0, %1614#0, %1615, %1675, %1674#1, %cst_1727) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1728 = arith.constant 0.78539816339744828 : f64
    %1737:5 = qlx.apply #qlx.action<pauli_rotation>(%1736#0, %1736#1, %1736#2, %1736#3, %1736#4, %cst_1728) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1729 = arith.constant 0.78539816339744828 : f64
    %1738:5 = qlx.apply #qlx.action<pauli_rotation>(%1737#1, %1737#3, %1737#4, %1734#0, %1735, %cst_1729) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1730 = arith.constant 0.78539816339744828 : f64
    %1739:5 = qlx.apply #qlx.action<pauli_rotation>(%1738#0, %1738#1, %1738#2, %1738#3, %1738#4, %cst_1730) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1731 = arith.constant 0.78539816339744828 : f64
    %1740:3 = qlx.apply #qlx.action<pauli_rotation>(%1739#1, %1739#3, %1739#4, %cst_1731) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1732 = arith.constant 0.78539816339744828 : f64
    %1741:7 = qlx.apply #qlx.action<pauli_rotation>(%1737#0, %1739#0, %1737#2, %1740#0, %1739#2, %1740#1, %1740#2, %cst_1732) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1733 = arith.constant 0.78539816339744828 : f64
    %1742:5 = qlx.apply #qlx.action<pauli_rotation>(%1741#0, %1741#1, %1741#2, %1741#3, %1741#4, %cst_1733) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1734 = arith.constant 0.78539816339744828 : f64
    %1743:3 = qlx.apply #qlx.action<pauli_rotation>(%1742#3, %1741#5, %1741#6, %cst_1734) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1735 = arith.constant 0.78539816339744828 : f64
    %1744:7 = qlx.apply #qlx.action<pauli_rotation>(%1742#0, %1742#1, %1742#2, %1743#0, %1742#4, %1743#1, %1743#2, %cst_1735) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1736 = arith.constant 0.78539816339744828 : f64
    %1745:3 = qlx.apply #qlx.action<pauli_rotation>(%1744#3, %1744#5, %1744#6, %cst_1736) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1737 = arith.constant 0.78539816339744828 : f64
    %1746:5 = qlx.apply #qlx.action<pauli_rotation>(%1744#0, %1744#1, %1744#2, %1745#0, %1744#4, %cst_1737) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1738 = arith.constant 0.78539816339744828 : f64
    %1747:3 = qlx.apply #qlx.action<pauli_rotation>(%1746#3, %1745#1, %1745#2, %cst_1738) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1739 = arith.constant 0.78539816339744828 : f64
    %1748:5 = qlx.apply #qlx.action<pauli_rotation>(%1746#0, %1746#1, %1746#2, %1747#0, %1746#4, %cst_1739) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1740 = arith.constant 0.78539816339744828 : f64
    %1749:3 = qlx.apply #qlx.action<pauli_rotation>(%1748#3, %1747#1, %1747#2, %cst_1740) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1741 = arith.constant 0.78539816339744828 : f64
    %1750:5 = qlx.apply #qlx.action<pauli_rotation>(%1748#0, %1748#1, %1748#2, %1749#0, %1748#4, %cst_1741) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1742 = arith.constant 0.78539816339744828 : f64
    %1751:3 = qlx.apply #qlx.action<pauli_rotation>(%1750#3, %1749#1, %1749#2, %cst_1742) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1743 = arith.constant 0.78539816339744828 : f64
    %1752:7 = qlx.apply #qlx.action<pauli_rotation>(%1750#0, %1750#1, %1750#2, %1751#0, %1750#4, %1751#1, %1751#2, %cst_1743) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1744 = arith.constant 0.78539816339744828 : f64
    %1753:5 = qlx.apply #qlx.action<pauli_rotation>(%1752#0, %1752#1, %1752#2, %1752#3, %1752#4, %cst_1744) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1745 = arith.constant 0.78539816339744828 : f64
    %1754:7 = qlx.apply #qlx.action<pauli_rotation>(%1753#0, %1753#1, %1753#2, %1753#3, %1753#4, %1752#5, %1752#6, %cst_1745) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1746 = arith.constant 0.78539816339744828 : f64
    %1755:3 = qlx.apply #qlx.action<pauli_rotation>(%1754#3, %1754#5, %1754#6, %cst_1746) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1747 = arith.constant 0.78539816339744828 : f64
    %1756:7 = qlx.apply #qlx.action<pauli_rotation>(%1754#0, %1754#1, %1754#2, %1755#0, %1754#4, %1755#1, %1755#2, %cst_1747) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1748 = arith.constant 0.78539816339744828 : f64
    %1757:5 = qlx.apply #qlx.action<pauli_rotation>(%1756#0, %1756#1, %1756#2, %1756#3, %1756#4, %cst_1748) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1749 = arith.constant 0.78539816339744828 : f64
    %1758:3 = qlx.apply #qlx.action<pauli_rotation>(%1757#3, %1756#5, %1756#6, %cst_1749) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1750 = arith.constant 0.78539816339744828 : f64
    %1759:5 = qlx.apply #qlx.action<pauli_rotation>(%1757#0, %1757#1, %1757#2, %1758#0, %1757#4, %cst_1750) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1751 = arith.constant 0.78539816339744828 : f64
    %1760:3 = qlx.apply #qlx.action<pauli_rotation>(%1759#3, %1758#1, %1758#2, %cst_1751) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1752 = arith.constant 0.78539816339744828 : f64
    %1761:5 = qlx.apply #qlx.action<pauli_rotation>(%1759#0, %1759#1, %1759#2, %1760#0, %1759#4, %cst_1752) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1753 = arith.constant 0.78539816339744828 : f64
    %1762:3 = qlx.apply #qlx.action<pauli_rotation>(%1761#3, %1760#1, %1760#2, %cst_1753) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1754 = arith.constant 0.78539816339744828 : f64
    %1763:7 = qlx.apply #qlx.action<pauli_rotation>(%1761#0, %1761#1, %1761#2, %1762#0, %1761#4, %1762#1, %1762#2, %cst_1754) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1755 = arith.constant 0.78539816339744828 : f64
    %1764:3 = qlx.apply #qlx.action<pauli_rotation>(%1763#3, %1763#5, %1763#6, %cst_1755) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1756 = arith.constant 0.78539816339744828 : f64
    %1765:5 = qlx.apply #qlx.action<pauli_rotation>(%1763#0, %1763#1, %1763#2, %1764#0, %1763#4, %cst_1756) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1757 = arith.constant 0.78539816339744828 : f64
    %1766:7 = qlx.apply #qlx.action<pauli_rotation>(%1765#0, %1765#1, %1765#2, %1765#3, %1765#4, %1764#1, %1764#2, %cst_1757) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1758 = arith.constant 0.78539816339744828 : f64
    %1767:3 = qlx.apply #qlx.action<pauli_rotation>(%1766#3, %1766#5, %1766#6, %cst_1758) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1759 = arith.constant 0.78539816339744828 : f64
    %1768:7 = qlx.apply #qlx.action<pauli_rotation>(%1766#0, %1766#1, %1766#2, %1767#0, %1766#4, %1767#1, %1767#2, %cst_1759) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1760 = arith.constant 0.78539816339744828 : f64
    %1769:5 = qlx.apply #qlx.action<pauli_rotation>(%1768#0, %1768#1, %1768#2, %1768#3, %1768#4, %cst_1760) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1761 = arith.constant 0.78539816339744828 : f64
    %1770:7 = qlx.apply #qlx.action<pauli_rotation>(%1769#0, %1769#1, %1769#2, %1769#3, %1769#4, %1768#5, %1768#6, %cst_1761) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1762 = arith.constant 0.78539816339744828 : f64
    %1771:3 = qlx.apply #qlx.action<pauli_rotation>(%1770#3, %1770#5, %1770#6, %cst_1762) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1763 = arith.constant 0.78539816339744828 : f64
    %1772:5 = qlx.apply #qlx.action<pauli_rotation>(%1770#0, %1770#1, %1770#2, %1771#0, %1770#4, %cst_1763) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1764 = arith.constant 0.78539816339744828 : f64
    %1773:7 = qlx.apply #qlx.action<pauli_rotation>(%1772#0, %1772#1, %1772#2, %1772#3, %1772#4, %1771#1, %1771#2, %cst_1764) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1765 = arith.constant 0.78539816339744828 : f64
    %1774:5 = qlx.apply #qlx.action<pauli_rotation>(%1773#0, %1773#1, %1773#2, %1773#3, %1773#4, %cst_1765) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1766 = arith.constant 0.78539816339744828 : f64
    %1775:3 = qlx.apply #qlx.action<pauli_rotation>(%1774#3, %1773#5, %1773#6, %cst_1766) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1767 = arith.constant 0.78539816339744828 : f64
    %1776:5 = qlx.apply #qlx.action<pauli_rotation>(%1774#0, %1774#1, %1774#2, %1775#0, %1774#4, %cst_1767) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1768 = arith.constant 0.78539816339744828 : f64
    %1777:3 = qlx.apply #qlx.action<pauli_rotation>(%1776#3, %1775#1, %1775#2, %cst_1768) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1769 = arith.constant 0.78539816339744828 : f64
    %1778:7 = qlx.apply #qlx.action<pauli_rotation>(%1776#0, %1776#1, %1776#2, %1777#0, %1776#4, %1777#1, %1777#2, %cst_1769) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1770 = arith.constant 0.78539816339744828 : f64
    %1779:3 = qlx.apply #qlx.action<pauli_rotation>(%1778#3, %1778#5, %1778#6, %cst_1770) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1771 = arith.constant 0.78539816339744828 : f64
    %1780:5 = qlx.apply #qlx.action<pauli_rotation>(%1778#0, %1778#1, %1778#2, %1779#0, %1778#4, %cst_1771) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1772 = arith.constant 0.78539816339744828 : f64
    %1781:7 = qlx.apply #qlx.action<pauli_rotation>(%1780#0, %1780#1, %1780#2, %1780#3, %1780#4, %1779#1, %1779#2, %cst_1772) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1773 = arith.constant 0.78539816339744828 : f64
    %1782:5 = qlx.apply #qlx.action<pauli_rotation>(%1781#0, %1781#1, %1781#2, %1781#3, %1781#4, %cst_1773) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1774 = arith.constant 0.78539816339744828 : f64
    %1783:7 = qlx.apply #qlx.action<pauli_rotation>(%1782#0, %1782#1, %1782#2, %1782#3, %1782#4, %1781#5, %1781#6, %cst_1774) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1775 = arith.constant 0.78539816339744828 : f64
    %1784:3 = qlx.apply #qlx.action<pauli_rotation>(%1783#3, %1783#5, %1783#6, %cst_1775) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1776 = arith.constant 0.78539816339744828 : f64
    %1785:7 = qlx.apply #qlx.action<pauli_rotation>(%1783#0, %1783#1, %1783#2, %1784#0, %1783#4, %1784#1, %1784#2, %cst_1776) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1777 = arith.constant 0.78539816339744828 : f64
    %1786:3 = qlx.apply #qlx.action<pauli_rotation>(%1785#3, %1785#5, %1785#6, %cst_1777) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1778 = arith.constant 0.78539816339744828 : f64
    %1787:7 = qlx.apply #qlx.action<pauli_rotation>(%1785#0, %1785#1, %1785#2, %1786#0, %1785#4, %1786#1, %1786#2, %cst_1778) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1779 = arith.constant 0.78539816339744828 : f64
    %1788:5 = qlx.apply #qlx.action<pauli_rotation>(%1787#0, %1787#1, %1787#2, %1787#3, %1787#4, %cst_1779) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1780 = arith.constant 0.78539816339744828 : f64
    %1789:3 = qlx.apply #qlx.action<pauli_rotation>(%1788#3, %1787#5, %1787#6, %cst_1780) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1781 = arith.constant 0.78539816339744828 : f64
    %1790:5 = qlx.apply #qlx.action<pauli_rotation>(%1788#0, %1788#1, %1788#2, %1789#0, %1788#4, %cst_1781) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1782 = arith.constant 0.78539816339744828 : f64
    %1791:7 = qlx.apply #qlx.action<pauli_rotation>(%1790#0, %1790#1, %1790#2, %1790#3, %1790#4, %1789#1, %1789#2, %cst_1782) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1783 = arith.constant 0.78539816339744828 : f64
    %1792:5 = qlx.apply #qlx.action<pauli_rotation>(%1791#0, %1791#1, %1791#2, %1791#3, %1791#4, %cst_1783) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1784 = arith.constant 0.78539816339744828 : f64
    %1793:3 = qlx.apply #qlx.action<pauli_rotation>(%1792#3, %1791#5, %1791#6, %cst_1784) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1785 = arith.constant 0.78539816339744828 : f64
    %1794:5 = qlx.apply #qlx.action<pauli_rotation>(%1792#0, %1792#1, %1792#2, %1793#0, %1792#4, %cst_1785) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1786 = arith.constant 0.78539816339744828 : f64
    %1795:3 = qlx.apply #qlx.action<pauli_rotation>(%1794#3, %1793#1, %1793#2, %cst_1786) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1787 = arith.constant 0.78539816339744828 : f64
    %1796:5 = qlx.apply #qlx.action<pauli_rotation>(%1794#0, %1794#1, %1794#2, %1795#0, %1794#4, %cst_1787) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1788 = arith.constant 0.78539816339744828 : f64
    %1797:3 = qlx.apply #qlx.action<pauli_rotation>(%1796#3, %1795#1, %1795#2, %cst_1788) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 5 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1789 = arith.constant 0.78539816339744828 : f64
    %1798:5 = qlx.apply #qlx.action<pauli_rotation>(%1796#0, %1796#1, %1796#2, %1797#0, %1796#4, %cst_1789) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1790 = arith.constant 0.78539816339744828 : f64
    %1799:7 = qlx.apply #qlx.action<pauli_rotation>(%1798#0, %1798#1, %1798#2, %1798#3, %1798#4, %1797#1, %1797#2, %cst_1790) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 117 : i64, z_mask = 94 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1791 = arith.constant 0.78539816339744828 : f64
    %1800:3 = qlx.apply #qlx.action<pauli_rotation>(%1799#0, %1799#1, %1799#2, %cst_1791) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1792 = arith.constant 0.78539816339744828 : f64
    %1801:3 = qlx.apply #qlx.action<pauli_rotation>(%1800#1, %1799#3, %1799#4, %cst_1792) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1793 = arith.constant 0.78539816339744828 : f64
    %1802:5 = qlx.apply #qlx.action<pauli_rotation>(%1800#0, %1801#0, %1800#2, %1801#1, %1801#2, %cst_1793) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1794 = arith.constant 0.78539816339744828 : f64
    %1803:3 = qlx.apply #qlx.action<pauli_rotation>(%1802#0, %1802#1, %1802#2, %cst_1794) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1795 = arith.constant 0.78539816339744828 : f64
    %1804:3 = qlx.apply #qlx.action<pauli_rotation>(%1803#1, %1802#3, %1802#4, %cst_1795) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1796 = arith.constant 0.78539816339744828 : f64
    %1805:3 = qlx.apply #qlx.action<pauli_rotation>(%1803#0, %1804#0, %1803#2, %cst_1796) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1797 = arith.constant 0.78539816339744828 : f64
    %1806:5 = qlx.apply #qlx.action<pauli_rotation>(%1805#0, %1805#1, %1805#2, %1804#1, %1804#2, %cst_1797) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1798 = arith.constant 0.78539816339744828 : f64
    %1807:3 = qlx.apply #qlx.action<pauli_rotation>(%1806#0, %1806#1, %1806#2, %cst_1798) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1799 = arith.constant 0.78539816339744828 : f64
    %1808:5 = qlx.apply #qlx.action<pauli_rotation>(%1807#0, %1807#1, %1807#2, %1806#3, %1806#4, %cst_1799) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1800 = arith.constant 0.78539816339744828 : f64
    %1809:3 = qlx.apply #qlx.action<pauli_rotation>(%1808#0, %1808#1, %1808#2, %cst_1800) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1801 = arith.constant 0.78539816339744828 : f64
    %1810:5 = qlx.apply #qlx.action<pauli_rotation>(%1809#0, %1809#1, %1809#2, %1808#3, %1808#4, %cst_1801) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1802 = arith.constant 0.78539816339744828 : f64
    %1811:3 = qlx.apply #qlx.action<pauli_rotation>(%1810#0, %1810#1, %1810#2, %cst_1802) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1803 = arith.constant 0.78539816339744828 : f64
    %1812:3 = qlx.apply #qlx.action<pauli_rotation>(%1811#1, %1810#3, %1810#4, %cst_1803) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1804 = arith.constant 0.78539816339744828 : f64
    %1813:5 = qlx.apply #qlx.action<pauli_rotation>(%1811#0, %1812#0, %1811#2, %1812#1, %1812#2, %cst_1804) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1805 = arith.constant 0.78539816339744828 : f64
    %1814:3 = qlx.apply #qlx.action<pauli_rotation>(%1813#1, %1813#3, %1813#4, %cst_1805) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1806 = arith.constant 0.78539816339744828 : f64
    %1815:3 = qlx.apply #qlx.action<pauli_rotation>(%1813#0, %1814#0, %1813#2, %cst_1806) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1807 = arith.constant 0.78539816339744828 : f64
    %1816:3 = qlx.apply #qlx.action<pauli_rotation>(%1815#1, %1814#1, %1814#2, %cst_1807) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1808 = arith.constant 0.78539816339744828 : f64
    %1817:5 = qlx.apply #qlx.action<pauli_rotation>(%1815#0, %1816#0, %1815#2, %1816#1, %1816#2, %cst_1808) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1809 = arith.constant 0.78539816339744828 : f64
    %1818:3 = qlx.apply #qlx.action<pauli_rotation>(%1817#0, %1817#1, %1817#2, %cst_1809) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1810 = arith.constant 0.78539816339744828 : f64
    %1819:5 = qlx.apply #qlx.action<pauli_rotation>(%1818#0, %1818#1, %1818#2, %1817#3, %1817#4, %cst_1810) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1811 = arith.constant 0.78539816339744828 : f64
    %1820:3 = qlx.apply #qlx.action<pauli_rotation>(%1819#0, %1819#1, %1819#2, %cst_1811) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1812 = arith.constant 0.78539816339744828 : f64
    %1821:5 = qlx.apply #qlx.action<pauli_rotation>(%1820#0, %1820#1, %1820#2, %1819#3, %1819#4, %cst_1812) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1813 = arith.constant 0.78539816339744828 : f64
    %1822:3 = qlx.apply #qlx.action<pauli_rotation>(%1821#0, %1821#1, %1821#2, %cst_1813) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1814 = arith.constant 0.78539816339744828 : f64
    %1823:3 = qlx.apply #qlx.action<pauli_rotation>(%1822#1, %1821#3, %1821#4, %cst_1814) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1815 = arith.constant 0.78539816339744828 : f64
    %1824:3 = qlx.apply #qlx.action<pauli_rotation>(%1822#0, %1823#0, %1822#2, %cst_1815) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1816 = arith.constant 0.78539816339744828 : f64
    %1825:5 = qlx.apply #qlx.action<pauli_rotation>(%1824#0, %1824#1, %1824#2, %1823#1, %1823#2, %cst_1816) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1817 = arith.constant 0.78539816339744828 : f64
    %1826:3 = qlx.apply #qlx.action<pauli_rotation>(%1825#1, %1825#3, %1825#4, %cst_1817) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1818 = arith.constant 0.78539816339744828 : f64
    %1827:3 = qlx.apply #qlx.action<pauli_rotation>(%1825#0, %1826#0, %1825#2, %cst_1818) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1819 = arith.constant 0.78539816339744828 : f64
    %1828:3 = qlx.apply #qlx.action<pauli_rotation>(%1827#1, %1826#1, %1826#2, %cst_1819) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1820 = arith.constant 0.78539816339744828 : f64
    %1829:5 = qlx.apply #qlx.action<pauli_rotation>(%1827#0, %1828#0, %1827#2, %1828#1, %1828#2, %cst_1820) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1821 = arith.constant 0.78539816339744828 : f64
    %1830:3 = qlx.apply #qlx.action<pauli_rotation>(%1829#1, %1829#3, %1829#4, %cst_1821) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1822 = arith.constant 0.78539816339744828 : f64
    %1831:3 = qlx.apply #qlx.action<pauli_rotation>(%1829#0, %1830#0, %1829#2, %cst_1822) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1823 = arith.constant 0.78539816339744828 : f64
    %1832:5 = qlx.apply #qlx.action<pauli_rotation>(%1831#0, %1831#1, %1831#2, %1830#1, %1830#2, %cst_1823) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1824 = arith.constant 0.78539816339744828 : f64
    %1833:3 = qlx.apply #qlx.action<pauli_rotation>(%1832#1, %1832#3, %1832#4, %cst_1824) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1825 = arith.constant 0.78539816339744828 : f64
    %1834:5 = qlx.apply #qlx.action<pauli_rotation>(%1832#0, %1833#0, %1832#2, %1833#1, %1833#2, %cst_1825) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1826 = arith.constant 0.78539816339744828 : f64
    %1835:3 = qlx.apply #qlx.action<pauli_rotation>(%1834#0, %1834#1, %1834#2, %cst_1826) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1827 = arith.constant 0.78539816339744828 : f64
    %1836:5 = qlx.apply #qlx.action<pauli_rotation>(%1835#0, %1835#1, %1835#2, %1834#3, %1834#4, %cst_1827) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1828 = arith.constant 0.78539816339744828 : f64
    %1837:3 = qlx.apply #qlx.action<pauli_rotation>(%1836#0, %1836#1, %1836#2, %cst_1828) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1829 = arith.constant 0.78539816339744828 : f64
    %1838:3 = qlx.apply #qlx.action<pauli_rotation>(%1837#1, %1836#3, %1836#4, %cst_1829) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1830 = arith.constant 0.78539816339744828 : f64
    %1839:3 = qlx.apply #qlx.action<pauli_rotation>(%1837#0, %1838#0, %1837#2, %cst_1830) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1831 = arith.constant 0.78539816339744828 : f64
    %1840:5 = qlx.apply #qlx.action<pauli_rotation>(%1839#0, %1839#1, %1839#2, %1838#1, %1838#2, %cst_1831) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1832 = arith.constant 0.78539816339744828 : f64
    %1841:3 = qlx.apply #qlx.action<pauli_rotation>(%1840#1, %1840#3, %1840#4, %cst_1832) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1833 = arith.constant 0.78539816339744828 : f64
    %1842:5 = qlx.apply #qlx.action<pauli_rotation>(%1840#0, %1841#0, %1840#2, %1841#1, %1841#2, %cst_1833) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1834 = arith.constant 0.78539816339744828 : f64
    %1843:3 = qlx.apply #qlx.action<pauli_rotation>(%1842#1, %1842#3, %1842#4, %cst_1834) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1835 = arith.constant 0.78539816339744828 : f64
    %1844:3 = qlx.apply #qlx.action<pauli_rotation>(%1842#0, %1843#0, %1842#2, %cst_1835) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1836 = arith.constant 0.78539816339744828 : f64
    %1845:3 = qlx.apply #qlx.action<pauli_rotation>(%1844#1, %1843#1, %1843#2, %cst_1836) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1837 = arith.constant 0.78539816339744828 : f64
    %1846:3 = qlx.apply #qlx.action<pauli_rotation>(%1844#0, %1845#0, %1844#2, %cst_1837) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1838 = arith.constant 0.78539816339744828 : f64
    %1847:3 = qlx.apply #qlx.action<pauli_rotation>(%1846#1, %1845#1, %1845#2, %cst_1838) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1839 = arith.constant 0.78539816339744828 : f64
    %1848:5 = qlx.apply #qlx.action<pauli_rotation>(%1846#0, %1847#0, %1846#2, %1847#1, %1847#2, %cst_1839) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1840 = arith.constant 0.78539816339744828 : f64
    %1849:3 = qlx.apply #qlx.action<pauli_rotation>(%1848#0, %1848#1, %1848#2, %cst_1840) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1841 = arith.constant 0.78539816339744828 : f64
    %1850:5 = qlx.apply #qlx.action<pauli_rotation>(%1849#0, %1849#1, %1849#2, %1848#3, %1848#4, %cst_1841) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1842 = arith.constant 0.78539816339744828 : f64
    %1851:3 = qlx.apply #qlx.action<pauli_rotation>(%1850#1, %1850#3, %1850#4, %cst_1842) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1843 = arith.constant 0.78539816339744828 : f64
    %1852:5 = qlx.apply #qlx.action<pauli_rotation>(%1850#0, %1851#0, %1850#2, %1851#1, %1851#2, %cst_1843) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1844 = arith.constant 0.78539816339744828 : f64
    %1853:3 = qlx.apply #qlx.action<pauli_rotation>(%1852#0, %1852#1, %1852#2, %cst_1844) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1845 = arith.constant 0.78539816339744828 : f64
    %1854:5 = qlx.apply #qlx.action<pauli_rotation>(%1853#0, %1853#1, %1853#2, %1852#3, %1852#4, %cst_1845) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1846 = arith.constant 0.78539816339744828 : f64
    %1855:3 = qlx.apply #qlx.action<pauli_rotation>(%1854#0, %1854#1, %1854#2, %cst_1846) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1847 = arith.constant 0.78539816339744828 : f64
    %1856:5 = qlx.apply #qlx.action<pauli_rotation>(%1855#0, %1855#1, %1855#2, %1854#3, %1854#4, %cst_1847) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1848 = arith.constant 0.78539816339744828 : f64
    %1857:3 = qlx.apply #qlx.action<pauli_rotation>(%1856#0, %1856#1, %1856#2, %cst_1848) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 6 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1849 = arith.constant 0.78539816339744828 : f64
    %1858:5 = qlx.apply #qlx.action<pauli_rotation>(%1857#0, %1857#1, %1857#2, %1856#3, %1856#4, %cst_1849) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 22 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1850 = arith.constant 0.78539816339744828 : f64
    %1859:3 = qlx.apply #qlx.action<pauli_rotation>(%1858#1, %1858#3, %1858#4, %cst_1850) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 7 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1851 = arith.constant 0.78539816339744828 : f64
    %1860:5 = qlx.apply #qlx.action<pauli_rotation>(%1858#0, %1859#0, %1858#2, %1859#1, %1859#2, %cst_1851) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1852 = arith.constant 0.78539816339744828 : f64
    %1861:5 = qlx.apply #qlx.action<pauli_rotation>(%1860#0, %1860#1, %1860#2, %1860#3, %1860#4, %cst_1852) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1853 = arith.constant 0.78539816339744828 : f64
    %1862:5 = qlx.apply #qlx.action<pauli_rotation>(%1861#1, %1861#3, %1861#4, %1799#5, %1799#6, %cst_1853) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 23 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1854 = arith.constant 0.78539816339744828 : f64
    %1863:5 = qlx.apply #qlx.action<pauli_rotation>(%1862#0, %1862#1, %1862#2, %1862#3, %1862#4, %cst_1854) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 29 : i64, z_mask = 30 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1855 = arith.constant 0.78539816339744828 : f64
    %1864:5 = qlx.apply #qlx.action<pauli_rotation>(%1861#0, %1555, %1863#0, %1861#2, %1863#2, %cst_1855) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1856 = arith.constant 0.78539816339744828 : f64
    %1865:5 = qlx.apply #qlx.action<pauli_rotation>(%1864#0, %1864#1, %1864#2, %1864#3, %1864#4, %cst_1856) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1857 = arith.constant 0.78539816339744828 : f64
    %1866:5 = qlx.apply #qlx.action<pauli_rotation>(%1865#2, %1865#3, %1863#1, %1865#4, %1863#4, %cst_1857) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1858 = arith.constant 0.78539816339744828 : f64
    %1867:5 = qlx.apply #qlx.action<pauli_rotation>(%1866#0, %1866#1, %1866#2, %1866#3, %1866#4, %cst_1858) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1859 = arith.constant 0.78539816339744828 : f64
    %1868:4 = qlx.apply #qlx.action<pauli_rotation>(%1867#0, %1867#1, %1867#2, %1867#3, %cst_1859) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1860 = arith.constant 0.78539816339744828 : f64
    %1869:7 = qlx.apply #qlx.action<pauli_rotation>(%1865#0, %1865#1, %1868#0, %1868#1, %1868#2, %1868#3, %1867#4, %cst_1860) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1861 = arith.constant 0.78539816339744828 : f64
    %1870:6 = qlx.apply #qlx.action<pauli_rotation>(%1869#0, %1869#1, %1869#3, %1869#4, %1869#5, %1869#6, %cst_1861) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1862 = arith.constant 0.78539816339744828 : f64
    %1871:4 = qlx.apply #qlx.action<pauli_rotation>(%1869#2, %1870#2, %1870#3, %1870#4, %cst_1862) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1863 = arith.constant 0.78539816339744828 : f64
    %1872:7 = qlx.apply #qlx.action<pauli_rotation>(%1870#0, %1870#1, %1871#0, %1871#1, %1871#2, %1871#3, %1870#5, %cst_1863) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1864 = arith.constant 0.78539816339744828 : f64
    %1873:4 = qlx.apply #qlx.action<pauli_rotation>(%1872#2, %1872#3, %1872#4, %1872#5, %cst_1864) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1865 = arith.constant 0.78539816339744828 : f64
    %1874:6 = qlx.apply #qlx.action<pauli_rotation>(%1872#0, %1872#1, %1873#1, %1873#2, %1873#3, %1872#6, %cst_1865) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1866 = arith.constant 0.78539816339744828 : f64
    %1875:4 = qlx.apply #qlx.action<pauli_rotation>(%1873#0, %1874#2, %1874#3, %1874#4, %cst_1866) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1867 = arith.constant 0.78539816339744828 : f64
    %1876:6 = qlx.apply #qlx.action<pauli_rotation>(%1874#0, %1874#1, %1875#1, %1875#2, %1875#3, %1874#5, %cst_1867) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1868 = arith.constant 0.78539816339744828 : f64
    %1877:4 = qlx.apply #qlx.action<pauli_rotation>(%1875#0, %1876#2, %1876#3, %1876#4, %cst_1868) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1869 = arith.constant 0.78539816339744828 : f64
    %1878:6 = qlx.apply #qlx.action<pauli_rotation>(%1876#0, %1876#1, %1877#1, %1877#2, %1877#3, %1876#5, %cst_1869) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1870 = arith.constant 0.78539816339744828 : f64
    %1879:4 = qlx.apply #qlx.action<pauli_rotation>(%1877#0, %1878#2, %1878#3, %1878#4, %cst_1870) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1871 = arith.constant 0.78539816339744828 : f64
    %1880:7 = qlx.apply #qlx.action<pauli_rotation>(%1878#0, %1878#1, %1879#0, %1879#1, %1879#2, %1879#3, %1878#5, %cst_1871) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1872 = arith.constant 0.78539816339744828 : f64
    %1881:6 = qlx.apply #qlx.action<pauli_rotation>(%1880#0, %1880#1, %1880#3, %1880#4, %1880#5, %1880#6, %cst_1872) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1873 = arith.constant 0.78539816339744828 : f64
    %1882:7 = qlx.apply #qlx.action<pauli_rotation>(%1881#0, %1881#1, %1880#2, %1881#2, %1881#3, %1881#4, %1881#5, %cst_1873) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1874 = arith.constant 0.78539816339744828 : f64
    %1883:4 = qlx.apply #qlx.action<pauli_rotation>(%1882#2, %1882#3, %1882#4, %1882#5, %cst_1874) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1875 = arith.constant 0.78539816339744828 : f64
    %1884:7 = qlx.apply #qlx.action<pauli_rotation>(%1882#0, %1882#1, %1883#0, %1883#1, %1883#2, %1883#3, %1882#6, %cst_1875) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1876 = arith.constant 0.78539816339744828 : f64
    %1885:6 = qlx.apply #qlx.action<pauli_rotation>(%1884#0, %1884#1, %1884#3, %1884#4, %1884#5, %1884#6, %cst_1876) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1877 = arith.constant 0.78539816339744828 : f64
    %1886:4 = qlx.apply #qlx.action<pauli_rotation>(%1884#2, %1885#2, %1885#3, %1885#4, %cst_1877) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1878 = arith.constant 0.78539816339744828 : f64
    %1887:6 = qlx.apply #qlx.action<pauli_rotation>(%1885#0, %1885#1, %1886#1, %1886#2, %1886#3, %1885#5, %cst_1878) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1879 = arith.constant 0.78539816339744828 : f64
    %1888:4 = qlx.apply #qlx.action<pauli_rotation>(%1886#0, %1887#2, %1887#3, %1887#4, %cst_1879) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1880 = arith.constant 0.78539816339744828 : f64
    %1889:6 = qlx.apply #qlx.action<pauli_rotation>(%1887#0, %1887#1, %1888#1, %1888#2, %1888#3, %1887#5, %cst_1880) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1881 = arith.constant 0.78539816339744828 : f64
    %1890:4 = qlx.apply #qlx.action<pauli_rotation>(%1888#0, %1889#2, %1889#3, %1889#4, %cst_1881) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1882 = arith.constant 0.78539816339744828 : f64
    %1891:7 = qlx.apply #qlx.action<pauli_rotation>(%1889#0, %1889#1, %1890#0, %1890#1, %1890#2, %1890#3, %1889#5, %cst_1882) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1883 = arith.constant 0.78539816339744828 : f64
    %1892:4 = qlx.apply #qlx.action<pauli_rotation>(%1891#2, %1891#3, %1891#4, %1891#5, %cst_1883) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1884 = arith.constant 0.78539816339744828 : f64
    %1893:6 = qlx.apply #qlx.action<pauli_rotation>(%1891#0, %1891#1, %1892#1, %1892#2, %1892#3, %1891#6, %cst_1884) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1885 = arith.constant 0.78539816339744828 : f64
    %1894:7 = qlx.apply #qlx.action<pauli_rotation>(%1893#0, %1893#1, %1892#0, %1893#2, %1893#3, %1893#4, %1893#5, %cst_1885) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1886 = arith.constant 0.78539816339744828 : f64
    %1895:4 = qlx.apply #qlx.action<pauli_rotation>(%1894#2, %1894#3, %1894#4, %1894#5, %cst_1886) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1887 = arith.constant 0.78539816339744828 : f64
    %1896:7 = qlx.apply #qlx.action<pauli_rotation>(%1894#0, %1894#1, %1895#0, %1895#1, %1895#2, %1895#3, %1894#6, %cst_1887) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1888 = arith.constant 0.78539816339744828 : f64
    %1897:6 = qlx.apply #qlx.action<pauli_rotation>(%1896#0, %1896#1, %1896#3, %1896#4, %1896#5, %1896#6, %cst_1888) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1889 = arith.constant 0.78539816339744828 : f64
    %1898:7 = qlx.apply #qlx.action<pauli_rotation>(%1897#0, %1897#1, %1896#2, %1897#2, %1897#3, %1897#4, %1897#5, %cst_1889) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1890 = arith.constant 0.78539816339744828 : f64
    %1899:4 = qlx.apply #qlx.action<pauli_rotation>(%1898#2, %1898#3, %1898#4, %1898#5, %cst_1890) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1891 = arith.constant 0.78539816339744828 : f64
    %1900:6 = qlx.apply #qlx.action<pauli_rotation>(%1898#0, %1898#1, %1899#1, %1899#2, %1899#3, %1898#6, %cst_1891) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1892 = arith.constant 0.78539816339744828 : f64
    %1901:7 = qlx.apply #qlx.action<pauli_rotation>(%1900#0, %1900#1, %1899#0, %1900#2, %1900#3, %1900#4, %1900#5, %cst_1892) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1893 = arith.constant 0.78539816339744828 : f64
    %1902:6 = qlx.apply #qlx.action<pauli_rotation>(%1901#0, %1901#1, %1901#3, %1901#4, %1901#5, %1901#6, %cst_1893) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1894 = arith.constant 0.78539816339744828 : f64
    %1903:4 = qlx.apply #qlx.action<pauli_rotation>(%1901#2, %1902#2, %1902#3, %1902#4, %cst_1894) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1895 = arith.constant 0.78539816339744828 : f64
    %1904:6 = qlx.apply #qlx.action<pauli_rotation>(%1902#0, %1902#1, %1903#1, %1903#2, %1903#3, %1902#5, %cst_1895) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1896 = arith.constant 0.78539816339744828 : f64
    %1905:4 = qlx.apply #qlx.action<pauli_rotation>(%1903#0, %1904#2, %1904#3, %1904#4, %cst_1896) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1897 = arith.constant 0.78539816339744828 : f64
    %1906:7 = qlx.apply #qlx.action<pauli_rotation>(%1904#0, %1904#1, %1905#0, %1905#1, %1905#2, %1905#3, %1904#5, %cst_1897) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1898 = arith.constant 0.78539816339744828 : f64
    %1907:4 = qlx.apply #qlx.action<pauli_rotation>(%1906#2, %1906#3, %1906#4, %1906#5, %cst_1898) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1899 = arith.constant 0.78539816339744828 : f64
    %1908:6 = qlx.apply #qlx.action<pauli_rotation>(%1906#0, %1906#1, %1907#1, %1907#2, %1907#3, %1906#6, %cst_1899) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1900 = arith.constant 0.78539816339744828 : f64
    %1909:7 = qlx.apply #qlx.action<pauli_rotation>(%1908#0, %1908#1, %1907#0, %1908#2, %1908#3, %1908#4, %1908#5, %cst_1900) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1901 = arith.constant 0.78539816339744828 : f64
    %1910:6 = qlx.apply #qlx.action<pauli_rotation>(%1909#0, %1909#1, %1909#3, %1909#4, %1909#5, %1909#6, %cst_1901) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1902 = arith.constant 0.78539816339744828 : f64
    %1911:7 = qlx.apply #qlx.action<pauli_rotation>(%1910#0, %1910#1, %1909#2, %1910#2, %1910#3, %1910#4, %1910#5, %cst_1902) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1903 = arith.constant 0.78539816339744828 : f64
    %1912:4 = qlx.apply #qlx.action<pauli_rotation>(%1911#2, %1911#3, %1911#4, %1911#5, %cst_1903) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1904 = arith.constant 0.78539816339744828 : f64
    %1913:7 = qlx.apply #qlx.action<pauli_rotation>(%1911#0, %1911#1, %1912#0, %1912#1, %1912#2, %1912#3, %1911#6, %cst_1904) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1905 = arith.constant 0.78539816339744828 : f64
    %1914:4 = qlx.apply #qlx.action<pauli_rotation>(%1913#2, %1913#3, %1913#4, %1913#5, %cst_1905) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1906 = arith.constant 0.78539816339744828 : f64
    %1915:7 = qlx.apply #qlx.action<pauli_rotation>(%1913#0, %1913#1, %1914#0, %1914#1, %1914#2, %1914#3, %1913#6, %cst_1906) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1907 = arith.constant 0.78539816339744828 : f64
    %1916:6 = qlx.apply #qlx.action<pauli_rotation>(%1915#0, %1915#1, %1915#3, %1915#4, %1915#5, %1915#6, %cst_1907) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1908 = arith.constant 0.78539816339744828 : f64
    %1917:4 = qlx.apply #qlx.action<pauli_rotation>(%1915#2, %1916#2, %1916#3, %1916#4, %cst_1908) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1909 = arith.constant 0.78539816339744828 : f64
    %1918:6 = qlx.apply #qlx.action<pauli_rotation>(%1916#0, %1916#1, %1917#1, %1917#2, %1917#3, %1916#5, %cst_1909) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1910 = arith.constant 0.78539816339744828 : f64
    %1919:7 = qlx.apply #qlx.action<pauli_rotation>(%1918#0, %1918#1, %1917#0, %1918#2, %1918#3, %1918#4, %1918#5, %cst_1910) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1911 = arith.constant 0.78539816339744828 : f64
    %1920:6 = qlx.apply #qlx.action<pauli_rotation>(%1919#0, %1919#1, %1919#3, %1919#4, %1919#5, %1919#6, %cst_1911) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1912 = arith.constant 0.78539816339744828 : f64
    %1921:4 = qlx.apply #qlx.action<pauli_rotation>(%1919#2, %1920#2, %1920#3, %1920#4, %cst_1912) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1913 = arith.constant 0.78539816339744828 : f64
    %1922:6 = qlx.apply #qlx.action<pauli_rotation>(%1920#0, %1920#1, %1921#1, %1921#2, %1921#3, %1920#5, %cst_1913) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1914 = arith.constant 0.78539816339744828 : f64
    %1923:4 = qlx.apply #qlx.action<pauli_rotation>(%1921#0, %1922#2, %1922#3, %1922#4, %cst_1914) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1915 = arith.constant 0.78539816339744828 : f64
    %1924:6 = qlx.apply #qlx.action<pauli_rotation>(%1922#0, %1922#1, %1923#1, %1923#2, %1923#3, %1922#5, %cst_1915) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1916 = arith.constant 0.78539816339744828 : f64
    %1925:4 = qlx.apply #qlx.action<pauli_rotation>(%1923#0, %1924#2, %1924#3, %1924#4, %cst_1916) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 12 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1917 = arith.constant 0.78539816339744828 : f64
    %1926:6 = qlx.apply #qlx.action<pauli_rotation>(%1924#0, %1924#1, %1925#1, %1925#2, %1925#3, %1924#5, %cst_1917) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1918 = arith.constant 0.78539816339744828 : f64
    %1927:7 = qlx.apply #qlx.action<pauli_rotation>(%1926#0, %1926#1, %1925#0, %1926#2, %1926#3, %1926#4, %1926#5, %cst_1918) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 106 : i64, z_mask = 61 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1919 = arith.constant 0.78539816339744828 : f64
    %1928:6 = qlx.apply #qlx.action<pauli_rotation>(%1927#0, %1927#1, %1927#2, %1927#4, %1927#5, %1927#6, %cst_1919) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1920 = arith.constant 0.78539816339744828 : f64
    %1929:3 = qlx.apply #qlx.action<pauli_rotation>(%1928#2, %1927#3, %1928#4, %cst_1920) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1921 = arith.constant 0.78539816339744828 : f64
    %1930:6 = qlx.apply #qlx.action<pauli_rotation>(%1928#0, %1928#1, %1929#1, %1928#3, %1929#2, %1928#5, %cst_1921) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1922 = arith.constant 0.78539816339744828 : f64
    %1931:6 = qlx.apply #qlx.action<pauli_rotation>(%1930#0, %1930#1, %1929#0, %1930#3, %1930#4, %1930#5, %cst_1922) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1923 = arith.constant 0.78539816339744828 : f64
    %1932:3 = qlx.apply #qlx.action<pauli_rotation>(%1931#2, %1930#2, %1931#4, %cst_1923) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1924 = arith.constant 0.78539816339744828 : f64
    %1933:6 = qlx.apply #qlx.action<pauli_rotation>(%1931#0, %1931#1, %1932#0, %1931#3, %1932#2, %1931#5, %cst_1924) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1925 = arith.constant 0.78539816339744828 : f64
    %1934:6 = qlx.apply #qlx.action<pauli_rotation>(%1933#0, %1933#1, %1932#1, %1933#3, %1933#4, %1933#5, %cst_1925) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1926 = arith.constant 0.78539816339744828 : f64
    %1935:6 = qlx.apply #qlx.action<pauli_rotation>(%1934#0, %1934#1, %1933#2, %1934#3, %1934#4, %1934#5, %cst_1926) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1927 = arith.constant 0.78539816339744828 : f64
    %1936:6 = qlx.apply #qlx.action<pauli_rotation>(%1935#0, %1935#1, %1934#2, %1935#3, %1935#4, %1935#5, %cst_1927) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1928 = arith.constant 0.78539816339744828 : f64
    %1937:6 = qlx.apply #qlx.action<pauli_rotation>(%1936#0, %1936#1, %1935#2, %1936#3, %1936#4, %1936#5, %cst_1928) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1929 = arith.constant 0.78539816339744828 : f64
    %1938:6 = qlx.apply #qlx.action<pauli_rotation>(%1937#0, %1937#1, %1936#2, %1937#3, %1937#4, %1937#5, %cst_1929) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1930 = arith.constant 0.78539816339744828 : f64
    %1939:6 = qlx.apply #qlx.action<pauli_rotation>(%1938#0, %1938#1, %1937#2, %1938#3, %1938#4, %1938#5, %cst_1930) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1931 = arith.constant 0.78539816339744828 : f64
    %1940:3 = qlx.apply #qlx.action<pauli_rotation>(%1939#2, %1938#2, %1939#4, %cst_1931) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1932 = arith.constant 0.78539816339744828 : f64
    %1941:6 = qlx.apply #qlx.action<pauli_rotation>(%1939#0, %1939#1, %1940#1, %1939#3, %1940#2, %1939#5, %cst_1932) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1933 = arith.constant 0.78539816339744828 : f64
    %1942:3 = qlx.apply #qlx.action<pauli_rotation>(%1940#0, %1941#2, %1941#4, %cst_1933) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1934 = arith.constant 0.78539816339744828 : f64
    %1943:6 = qlx.apply #qlx.action<pauli_rotation>(%1941#0, %1941#1, %1942#0, %1941#3, %1942#2, %1941#5, %cst_1934) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1935 = arith.constant 0.78539816339744828 : f64
    %1944:3 = qlx.apply #qlx.action<pauli_rotation>(%1943#2, %1942#1, %1943#4, %cst_1935) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1936 = arith.constant 0.78539816339744828 : f64
    %1945:6 = qlx.apply #qlx.action<pauli_rotation>(%1943#0, %1943#1, %1944#1, %1943#3, %1944#2, %1943#5, %cst_1936) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1937 = arith.constant 0.78539816339744828 : f64
    %1946:6 = qlx.apply #qlx.action<pauli_rotation>(%1945#0, %1945#1, %1944#0, %1945#3, %1945#4, %1945#5, %cst_1937) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1938 = arith.constant 0.78539816339744828 : f64
    %1947:6 = qlx.apply #qlx.action<pauli_rotation>(%1946#0, %1946#1, %1945#2, %1946#3, %1946#4, %1946#5, %cst_1938) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1939 = arith.constant 0.78539816339744828 : f64
    %1948:6 = qlx.apply #qlx.action<pauli_rotation>(%1947#0, %1947#1, %1946#2, %1947#3, %1947#4, %1947#5, %cst_1939) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1940 = arith.constant 0.78539816339744828 : f64
    %1949:6 = qlx.apply #qlx.action<pauli_rotation>(%1948#0, %1948#1, %1947#2, %1948#3, %1948#4, %1948#5, %cst_1940) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1941 = arith.constant 0.78539816339744828 : f64
    %1950:6 = qlx.apply #qlx.action<pauli_rotation>(%1949#0, %1949#1, %1948#2, %1949#3, %1949#4, %1949#5, %cst_1941) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1942 = arith.constant 0.78539816339744828 : f64
    %1951:3 = qlx.apply #qlx.action<pauli_rotation>(%1950#2, %1949#2, %1950#4, %cst_1942) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1943 = arith.constant 0.78539816339744828 : f64
    %1952:6 = qlx.apply #qlx.action<pauli_rotation>(%1950#0, %1950#1, %1951#0, %1950#3, %1951#2, %1950#5, %cst_1943) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1944 = arith.constant 0.78539816339744828 : f64
    %1953:6 = qlx.apply #qlx.action<pauli_rotation>(%1952#0, %1952#1, %1951#1, %1952#3, %1952#4, %1952#5, %cst_1944) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1945 = arith.constant 0.78539816339744828 : f64
    %1954:3 = qlx.apply #qlx.action<pauli_rotation>(%1952#2, %1953#2, %1953#4, %cst_1945) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1946 = arith.constant 0.78539816339744828 : f64
    %1955:6 = qlx.apply #qlx.action<pauli_rotation>(%1953#0, %1953#1, %1954#0, %1953#3, %1954#2, %1953#5, %cst_1946) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1947 = arith.constant 0.78539816339744828 : f64
    %1956:3 = qlx.apply #qlx.action<pauli_rotation>(%1955#2, %1954#1, %1955#4, %cst_1947) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1948 = arith.constant 0.78539816339744828 : f64
    %1957:6 = qlx.apply #qlx.action<pauli_rotation>(%1955#0, %1955#1, %1956#1, %1955#3, %1956#2, %1955#5, %cst_1948) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1949 = arith.constant 0.78539816339744828 : f64
    %1958:3 = qlx.apply #qlx.action<pauli_rotation>(%1956#0, %1957#2, %1957#4, %cst_1949) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1950 = arith.constant 0.78539816339744828 : f64
    %1959:6 = qlx.apply #qlx.action<pauli_rotation>(%1957#0, %1957#1, %1958#0, %1957#3, %1958#2, %1957#5, %cst_1950) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1951 = arith.constant 0.78539816339744828 : f64
    %1960:6 = qlx.apply #qlx.action<pauli_rotation>(%1959#0, %1959#1, %1958#1, %1959#3, %1959#4, %1959#5, %cst_1951) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1952 = arith.constant 0.78539816339744828 : f64
    %1961:3 = qlx.apply #qlx.action<pauli_rotation>(%1959#2, %1960#2, %1960#4, %cst_1952) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1953 = arith.constant 0.78539816339744828 : f64
    %1962:6 = qlx.apply #qlx.action<pauli_rotation>(%1960#0, %1960#1, %1961#1, %1960#3, %1961#2, %1960#5, %cst_1953) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1954 = arith.constant 0.78539816339744828 : f64
    %1963:6 = qlx.apply #qlx.action<pauli_rotation>(%1962#0, %1962#1, %1961#0, %1962#3, %1962#4, %1962#5, %cst_1954) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1955 = arith.constant 0.78539816339744828 : f64
    %1964:6 = qlx.apply #qlx.action<pauli_rotation>(%1963#0, %1963#1, %1962#2, %1963#3, %1963#4, %1963#5, %cst_1955) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1956 = arith.constant 0.78539816339744828 : f64
    %1965:6 = qlx.apply #qlx.action<pauli_rotation>(%1964#0, %1964#1, %1963#2, %1964#3, %1964#4, %1964#5, %cst_1956) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1957 = arith.constant 0.78539816339744828 : f64
    %1966:3 = qlx.apply #qlx.action<pauli_rotation>(%1965#2, %1964#2, %1965#4, %cst_1957) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1958 = arith.constant 0.78539816339744828 : f64
    %1967:6 = qlx.apply #qlx.action<pauli_rotation>(%1965#0, %1965#1, %1966#0, %1965#3, %1966#2, %1965#5, %cst_1958) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1959 = arith.constant 0.78539816339744828 : f64
    %1968:6 = qlx.apply #qlx.action<pauli_rotation>(%1967#0, %1967#1, %1966#1, %1967#3, %1967#4, %1967#5, %cst_1959) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1960 = arith.constant 0.78539816339744828 : f64
    %1969:3 = qlx.apply #qlx.action<pauli_rotation>(%1967#2, %1968#2, %1968#4, %cst_1960) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1961 = arith.constant 0.78539816339744828 : f64
    %1970:6 = qlx.apply #qlx.action<pauli_rotation>(%1968#0, %1968#1, %1969#1, %1968#3, %1969#2, %1968#5, %cst_1961) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1962 = arith.constant 0.78539816339744828 : f64
    %1971:3 = qlx.apply #qlx.action<pauli_rotation>(%1969#0, %1970#2, %1970#4, %cst_1962) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1963 = arith.constant 0.78539816339744828 : f64
    %1972:6 = qlx.apply #qlx.action<pauli_rotation>(%1970#0, %1970#1, %1971#0, %1970#3, %1971#2, %1970#5, %cst_1963) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1964 = arith.constant 0.78539816339744828 : f64
    %1973:3 = qlx.apply #qlx.action<pauli_rotation>(%1972#2, %1971#1, %1972#4, %cst_1964) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1965 = arith.constant 0.78539816339744828 : f64
    %1974:6 = qlx.apply #qlx.action<pauli_rotation>(%1972#0, %1972#1, %1973#0, %1972#3, %1973#2, %1972#5, %cst_1965) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1966 = arith.constant 0.78539816339744828 : f64
    %1975:3 = qlx.apply #qlx.action<pauli_rotation>(%1974#2, %1973#1, %1974#4, %cst_1966) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1967 = arith.constant 0.78539816339744828 : f64
    %1976:6 = qlx.apply #qlx.action<pauli_rotation>(%1974#0, %1974#1, %1975#1, %1974#3, %1975#2, %1974#5, %cst_1967) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1968 = arith.constant 0.78539816339744828 : f64
    %1977:6 = qlx.apply #qlx.action<pauli_rotation>(%1976#0, %1976#1, %1975#0, %1976#3, %1976#4, %1976#5, %cst_1968) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1969 = arith.constant 0.78539816339744828 : f64
    %1978:6 = qlx.apply #qlx.action<pauli_rotation>(%1977#0, %1977#1, %1976#2, %1977#3, %1977#4, %1977#5, %cst_1969) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1970 = arith.constant 0.78539816339744828 : f64
    %1979:3 = qlx.apply #qlx.action<pauli_rotation>(%1977#2, %1978#2, %1978#4, %cst_1970) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1971 = arith.constant 0.78539816339744828 : f64
    %1980:6 = qlx.apply #qlx.action<pauli_rotation>(%1978#0, %1978#1, %1979#1, %1978#3, %1979#2, %1978#5, %cst_1971) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1972 = arith.constant 0.78539816339744828 : f64
    %1981:6 = qlx.apply #qlx.action<pauli_rotation>(%1980#0, %1980#1, %1979#0, %1980#3, %1980#4, %1980#5, %cst_1972) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1973 = arith.constant 0.78539816339744828 : f64
    %1982:6 = qlx.apply #qlx.action<pauli_rotation>(%1981#0, %1981#1, %1980#2, %1981#3, %1981#4, %1981#5, %cst_1973) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1974 = arith.constant 0.78539816339744828 : f64
    %1983:6 = qlx.apply #qlx.action<pauli_rotation>(%1982#0, %1982#1, %1981#2, %1982#3, %1982#4, %1982#5, %cst_1974) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1975 = arith.constant 0.78539816339744828 : f64
    %1984:6 = qlx.apply #qlx.action<pauli_rotation>(%1983#0, %1983#1, %1982#2, %1983#3, %1983#4, %1983#5, %cst_1975) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1976 = arith.constant 0.78539816339744828 : f64
    %1985:6 = qlx.apply #qlx.action<pauli_rotation>(%1984#0, %1984#1, %1983#2, %1984#3, %1984#4, %1984#5, %cst_1976) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 58 : i64, z_mask = 21 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1977 = arith.constant 0.78539816339744828 : f64
    %1986:6 = qlx.apply #qlx.action<pauli_rotation>(%1985#0, %1985#1, %1984#2, %1985#3, %1985#4, %1985#5, %cst_1977) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 46 : i64, z_mask = 17 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1978 = arith.constant 0.78539816339744828 : f64
    %1987:3 = qlx.apply #qlx.action<pauli_rotation>(%1985#2, %1986#2, %1986#4, %cst_1978) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 6 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1979 = arith.constant 0.78539816339744828 : f64
    %1988:5 = qlx.apply #qlx.action<pauli_rotation>(%1986#0, %1986#1, %1987#0, %1987#1, %1987#2, %cst_1979) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1980 = arith.constant 0.78539816339744828 : f64
    %1989:5 = qlx.apply #qlx.action<pauli_rotation>(%1988#0, %1988#1, %1988#2, %1988#3, %1988#4, %cst_1980) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1981 = arith.constant 0.78539816339744828 : f64
    %1990:5 = qlx.apply #qlx.action<pauli_rotation>(%1989#2, %1989#3, %1986#3, %1989#4, %1986#5, %cst_1981) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 24 : i64, z_mask = 15 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1982 = arith.constant 0.78539816339744828 : f64
    %1991:5 = qlx.apply #qlx.action<pauli_rotation>(%1990#0, %1990#1, %1990#2, %1990#3, %1990#4, %cst_1982) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 10 : i64, z_mask = 29 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1983 = arith.constant 0.78539816339744828 : f64
    %1992 = qlx.apply #qlx.action<pauli_rotation>(%1989#1, %cst_1983) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1984 = arith.constant 0.78539816339744828 : f64
    %1993:2 = qlx.apply #qlx.action<pauli_rotation>(%1989#0, %1992, %cst_1984) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1985 = arith.constant 0.78539816339744828 : f64
    %1994 = qlx.apply #qlx.action<pauli_rotation>(%1993#1, %cst_1985) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1986 = arith.constant 0.78539816339744828 : f64
    %1995:2 = qlx.apply #qlx.action<pauli_rotation>(%1993#0, %1994, %cst_1986) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1987 = arith.constant 0.78539816339744828 : f64
    %1996 = qlx.apply #qlx.action<pauli_rotation>(%1995#1, %cst_1987) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1988 = arith.constant 0.78539816339744828 : f64
    %1997:2 = qlx.apply #qlx.action<pauli_rotation>(%1995#0, %1996, %cst_1988) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1989 = arith.constant 0.78539816339744828 : f64
    %1998:2 = qlx.apply #qlx.action<pauli_rotation>(%1997#0, %1997#1, %cst_1989) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1990 = arith.constant 0.78539816339744828 : f64
    %1999:2 = qlx.apply #qlx.action<pauli_rotation>(%1998#0, %1998#1, %cst_1990) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1991 = arith.constant 0.78539816339744828 : f64
    %2000 = qlx.apply #qlx.action<pauli_rotation>(%1999#1, %cst_1991) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1992 = arith.constant 0.78539816339744828 : f64
    %2001:2 = qlx.apply #qlx.action<pauli_rotation>(%1999#0, %2000, %cst_1992) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1993 = arith.constant 0.78539816339744828 : f64
    %2002:2 = qlx.apply #qlx.action<pauli_rotation>(%2001#0, %2001#1, %cst_1993) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1994 = arith.constant 0.78539816339744828 : f64
    %2003:2 = qlx.apply #qlx.action<pauli_rotation>(%2002#0, %2002#1, %cst_1994) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1995 = arith.constant 0.78539816339744828 : f64
    %2004:2 = qlx.apply #qlx.action<pauli_rotation>(%2003#0, %2003#1, %cst_1995) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1996 = arith.constant 0.78539816339744828 : f64
    %2005:2 = qlx.apply #qlx.action<pauli_rotation>(%2004#0, %2004#1, %cst_1996) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1997 = arith.constant 0.78539816339744828 : f64
    %2006 = qlx.apply #qlx.action<pauli_rotation>(%2005#1, %cst_1997) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_1998 = arith.constant 0.78539816339744828 : f64
    %2007:2 = qlx.apply #qlx.action<pauli_rotation>(%2005#0, %2006, %cst_1998) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1999 = arith.constant 0.78539816339744828 : f64
    %2008:2 = qlx.apply #qlx.action<pauli_rotation>(%2007#0, %2007#1, %cst_1999) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2000 = arith.constant 0.78539816339744828 : f64
    %2009:2 = qlx.apply #qlx.action<pauli_rotation>(%2008#0, %2008#1, %cst_2000) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2001 = arith.constant 0.78539816339744828 : f64
    %2010 = qlx.apply #qlx.action<pauli_rotation>(%2009#1, %cst_2001) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2002 = arith.constant 0.78539816339744828 : f64
    %2011:2 = qlx.apply #qlx.action<pauli_rotation>(%2009#0, %2010, %cst_2002) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2003 = arith.constant 0.78539816339744828 : f64
    %2012:2 = qlx.apply #qlx.action<pauli_rotation>(%2011#0, %2011#1, %cst_2003) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2004 = arith.constant 0.78539816339744828 : f64
    %2013 = qlx.apply #qlx.action<pauli_rotation>(%2012#1, %cst_2004) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2005 = arith.constant 0.78539816339744828 : f64
    %2014:2 = qlx.apply #qlx.action<pauli_rotation>(%2012#0, %2013, %cst_2005) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2006 = arith.constant 0.78539816339744828 : f64
    %2015 = qlx.apply #qlx.action<pauli_rotation>(%2014#1, %cst_2006) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2007 = arith.constant 0.78539816339744828 : f64
    %2016:2 = qlx.apply #qlx.action<pauli_rotation>(%2014#0, %2015, %cst_2007) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2008 = arith.constant 0.78539816339744828 : f64
    %2017 = qlx.apply #qlx.action<pauli_rotation>(%2016#1, %cst_2008) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2009 = arith.constant 0.78539816339744828 : f64
    %2018:2 = qlx.apply #qlx.action<pauli_rotation>(%2016#0, %2017, %cst_2009) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2010 = arith.constant 0.78539816339744828 : f64
    %2019 = qlx.apply #qlx.action<pauli_rotation>(%2018#1, %cst_2010) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2011 = arith.constant 0.78539816339744828 : f64
    %2020:2 = qlx.apply #qlx.action<pauli_rotation>(%2018#0, %2019, %cst_2011) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2012 = arith.constant 0.78539816339744828 : f64
    %2021:2 = qlx.apply #qlx.action<pauli_rotation>(%2020#0, %2020#1, %cst_2012) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2013 = arith.constant 0.78539816339744828 : f64
    %2022 = qlx.apply #qlx.action<pauli_rotation>(%2021#1, %cst_2013) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2014 = arith.constant 0.78539816339744828 : f64
    %2023:2 = qlx.apply #qlx.action<pauli_rotation>(%2021#0, %2022, %cst_2014) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2015 = arith.constant 0.78539816339744828 : f64
    %2024:2 = qlx.apply #qlx.action<pauli_rotation>(%2023#0, %2023#1, %cst_2015) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2016 = arith.constant 0.78539816339744828 : f64
    %2025:2 = qlx.apply #qlx.action<pauli_rotation>(%2024#0, %2024#1, %cst_2016) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2017 = arith.constant 0.78539816339744828 : f64
    %2026:2 = qlx.apply #qlx.action<pauli_rotation>(%2025#0, %2025#1, %cst_2017) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2018 = arith.constant 0.78539816339744828 : f64
    %2027 = qlx.apply #qlx.action<pauli_rotation>(%2026#1, %cst_2018) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2019 = arith.constant 0.78539816339744828 : f64
    %2028:2 = qlx.apply #qlx.action<pauli_rotation>(%2026#0, %2027, %cst_2019) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2020 = arith.constant 0.78539816339744828 : f64
    %2029 = qlx.apply #qlx.action<pauli_rotation>(%2028#1, %cst_2020) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2021 = arith.constant 0.78539816339744828 : f64
    %2030:2 = qlx.apply #qlx.action<pauli_rotation>(%2028#0, %2029, %cst_2021) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2022 = arith.constant 0.78539816339744828 : f64
    %2031 = qlx.apply #qlx.action<pauli_rotation>(%2030#1, %cst_2022) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2023 = arith.constant 0.78539816339744828 : f64
    %2032:2 = qlx.apply #qlx.action<pauli_rotation>(%2030#0, %2031, %cst_2023) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2024 = arith.constant 0.78539816339744828 : f64
    %2033:2 = qlx.apply #qlx.action<pauli_rotation>(%2032#0, %2032#1, %cst_2024) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2025 = arith.constant 0.78539816339744828 : f64
    %2034:2 = qlx.apply #qlx.action<pauli_rotation>(%2033#0, %2033#1, %cst_2025) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2026 = arith.constant 0.78539816339744828 : f64
    %2035 = qlx.apply #qlx.action<pauli_rotation>(%2034#1, %cst_2026) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2027 = arith.constant 0.78539816339744828 : f64
    %2036:2 = qlx.apply #qlx.action<pauli_rotation>(%2034#0, %2035, %cst_2027) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2028 = arith.constant 0.78539816339744828 : f64
    %2037:2 = qlx.apply #qlx.action<pauli_rotation>(%2036#0, %2036#1, %cst_2028) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2029 = arith.constant 0.78539816339744828 : f64
    %2038:2 = qlx.apply #qlx.action<pauli_rotation>(%2037#0, %2037#1, %cst_2029) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2030 = arith.constant 0.78539816339744828 : f64
    %2039 = qlx.apply #qlx.action<pauli_rotation>(%2038#1, %cst_2030) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2031 = arith.constant 0.78539816339744828 : f64
    %2040:2 = qlx.apply #qlx.action<pauli_rotation>(%2038#0, %2039, %cst_2031) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2032 = arith.constant 0.78539816339744828 : f64
    %2041 = qlx.apply #qlx.action<pauli_rotation>(%2040#1, %cst_2032) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2033 = arith.constant 0.78539816339744828 : f64
    %2042:2 = qlx.apply #qlx.action<pauli_rotation>(%2040#0, %2041, %cst_2033) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2034 = arith.constant 0.78539816339744828 : f64
    %2043:2 = qlx.apply #qlx.action<pauli_rotation>(%2042#0, %2042#1, %cst_2034) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2035 = arith.constant 0.78539816339744828 : f64
    %2044:2 = qlx.apply #qlx.action<pauli_rotation>(%2043#0, %2043#1, %cst_2035) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2036 = arith.constant 0.78539816339744828 : f64
    %2045 = qlx.apply #qlx.action<pauli_rotation>(%2044#1, %cst_2036) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2037 = arith.constant 0.78539816339744828 : f64
    %2046:2 = qlx.apply #qlx.action<pauli_rotation>(%2044#0, %2045, %cst_2037) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2038 = arith.constant 0.78539816339744828 : f64
    %2047:2 = qlx.apply #qlx.action<pauli_rotation>(%2046#0, %2046#1, %cst_2038) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2039 = arith.constant 0.78539816339744828 : f64
    %2048 = qlx.apply #qlx.action<pauli_rotation>(%2047#1, %cst_2039) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2040 = arith.constant 0.78539816339744828 : f64
    %2049:2 = qlx.apply #qlx.action<pauli_rotation>(%2047#0, %2048, %cst_2040) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2041 = arith.constant 0.78539816339744828 : f64
    %2050:2 = qlx.apply #qlx.action<pauli_rotation>(%2049#0, %2049#1, %cst_2041) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2042 = arith.constant 0.78539816339744828 : f64
    %2051:2 = qlx.apply #qlx.action<pauli_rotation>(%2050#0, %2050#1, %cst_2042) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2043 = arith.constant 0.78539816339744828 : f64
    %2052 = qlx.apply #qlx.action<pauli_rotation>(%1991#1, %cst_2043) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2044 = arith.constant 0.78539816339744828 : f64
    %2053:2 = qlx.apply #qlx.action<pauli_rotation>(%1991#0, %2052, %cst_2044) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2045 = arith.constant 0.78539816339744828 : f64
    %2054 = qlx.apply #qlx.action<pauli_rotation>(%2053#1, %cst_2045) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2046 = arith.constant 0.78539816339744828 : f64
    %2055:2 = qlx.apply #qlx.action<pauli_rotation>(%2053#0, %2054, %cst_2046) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2047 = arith.constant 0.78539816339744828 : f64
    %2056 = qlx.apply #qlx.action<pauli_rotation>(%2055#1, %cst_2047) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2048 = arith.constant 0.78539816339744828 : f64
    %2057:2 = qlx.apply #qlx.action<pauli_rotation>(%2055#0, %2056, %cst_2048) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2049 = arith.constant 0.78539816339744828 : f64
    %2058:2 = qlx.apply #qlx.action<pauli_rotation>(%2057#0, %2057#1, %cst_2049) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2050 = arith.constant 0.78539816339744828 : f64
    %2059:2 = qlx.apply #qlx.action<pauli_rotation>(%2058#0, %2058#1, %cst_2050) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2051 = arith.constant 0.78539816339744828 : f64
    %2060 = qlx.apply #qlx.action<pauli_rotation>(%2059#1, %cst_2051) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2052 = arith.constant 0.78539816339744828 : f64
    %2061:2 = qlx.apply #qlx.action<pauli_rotation>(%2059#0, %2060, %cst_2052) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2053 = arith.constant 0.78539816339744828 : f64
    %2062:2 = qlx.apply #qlx.action<pauli_rotation>(%2061#0, %2061#1, %cst_2053) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2054 = arith.constant 0.78539816339744828 : f64
    %2063:2 = qlx.apply #qlx.action<pauli_rotation>(%2062#0, %2062#1, %cst_2054) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2055 = arith.constant 0.78539816339744828 : f64
    %2064:2 = qlx.apply #qlx.action<pauli_rotation>(%2063#0, %2063#1, %cst_2055) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2056 = arith.constant 0.78539816339744828 : f64
    %2065:2 = qlx.apply #qlx.action<pauli_rotation>(%2064#0, %2064#1, %cst_2056) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2057 = arith.constant 0.78539816339744828 : f64
    %2066 = qlx.apply #qlx.action<pauli_rotation>(%2065#1, %cst_2057) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2058 = arith.constant 0.78539816339744828 : f64
    %2067:2 = qlx.apply #qlx.action<pauli_rotation>(%2065#0, %2066, %cst_2058) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2059 = arith.constant 0.78539816339744828 : f64
    %2068:2 = qlx.apply #qlx.action<pauli_rotation>(%2067#0, %2067#1, %cst_2059) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2060 = arith.constant 0.78539816339744828 : f64
    %2069:2 = qlx.apply #qlx.action<pauli_rotation>(%2068#0, %2068#1, %cst_2060) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2061 = arith.constant 0.78539816339744828 : f64
    %2070 = qlx.apply #qlx.action<pauli_rotation>(%2069#1, %cst_2061) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2062 = arith.constant 0.78539816339744828 : f64
    %2071:2 = qlx.apply #qlx.action<pauli_rotation>(%2069#0, %2070, %cst_2062) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2063 = arith.constant 0.78539816339744828 : f64
    %2072:2 = qlx.apply #qlx.action<pauli_rotation>(%2071#0, %2071#1, %cst_2063) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2064 = arith.constant 0.78539816339744828 : f64
    %2073 = qlx.apply #qlx.action<pauli_rotation>(%2072#1, %cst_2064) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2065 = arith.constant 0.78539816339744828 : f64
    %2074:2 = qlx.apply #qlx.action<pauli_rotation>(%2072#0, %2073, %cst_2065) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2066 = arith.constant 0.78539816339744828 : f64
    %2075 = qlx.apply #qlx.action<pauli_rotation>(%2074#1, %cst_2066) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2067 = arith.constant 0.78539816339744828 : f64
    %2076:2 = qlx.apply #qlx.action<pauli_rotation>(%2074#0, %2075, %cst_2067) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2068 = arith.constant 0.78539816339744828 : f64
    %2077 = qlx.apply #qlx.action<pauli_rotation>(%2076#1, %cst_2068) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2069 = arith.constant 0.78539816339744828 : f64
    %2078:2 = qlx.apply #qlx.action<pauli_rotation>(%2076#0, %2077, %cst_2069) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2070 = arith.constant 0.78539816339744828 : f64
    %2079 = qlx.apply #qlx.action<pauli_rotation>(%2078#1, %cst_2070) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2071 = arith.constant 0.78539816339744828 : f64
    %2080:2 = qlx.apply #qlx.action<pauli_rotation>(%2078#0, %2079, %cst_2071) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2072 = arith.constant 0.78539816339744828 : f64
    %2081:2 = qlx.apply #qlx.action<pauli_rotation>(%2080#0, %2080#1, %cst_2072) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2073 = arith.constant 0.78539816339744828 : f64
    %2082 = qlx.apply #qlx.action<pauli_rotation>(%2081#1, %cst_2073) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2074 = arith.constant 0.78539816339744828 : f64
    %2083:2 = qlx.apply #qlx.action<pauli_rotation>(%2081#0, %2082, %cst_2074) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2075 = arith.constant 0.78539816339744828 : f64
    %2084:2 = qlx.apply #qlx.action<pauli_rotation>(%2083#0, %2083#1, %cst_2075) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2076 = arith.constant 0.78539816339744828 : f64
    %2085:2 = qlx.apply #qlx.action<pauli_rotation>(%2084#0, %2084#1, %cst_2076) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2077 = arith.constant 0.78539816339744828 : f64
    %2086:2 = qlx.apply #qlx.action<pauli_rotation>(%2085#0, %2085#1, %cst_2077) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2078 = arith.constant 0.78539816339744828 : f64
    %2087 = qlx.apply #qlx.action<pauli_rotation>(%2086#1, %cst_2078) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2079 = arith.constant 0.78539816339744828 : f64
    %2088:2 = qlx.apply #qlx.action<pauli_rotation>(%2086#0, %2087, %cst_2079) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2080 = arith.constant 0.78539816339744828 : f64
    %2089 = qlx.apply #qlx.action<pauli_rotation>(%2088#1, %cst_2080) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2081 = arith.constant 0.78539816339744828 : f64
    %2090:2 = qlx.apply #qlx.action<pauli_rotation>(%2088#0, %2089, %cst_2081) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2082 = arith.constant 0.78539816339744828 : f64
    %2091 = qlx.apply #qlx.action<pauli_rotation>(%2090#1, %cst_2082) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2083 = arith.constant 0.78539816339744828 : f64
    %2092:2 = qlx.apply #qlx.action<pauli_rotation>(%2090#0, %2091, %cst_2083) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2084 = arith.constant 0.78539816339744828 : f64
    %2093:2 = qlx.apply #qlx.action<pauli_rotation>(%2092#0, %2092#1, %cst_2084) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2085 = arith.constant 0.78539816339744828 : f64
    %2094:2 = qlx.apply #qlx.action<pauli_rotation>(%2093#0, %2093#1, %cst_2085) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2086 = arith.constant 0.78539816339744828 : f64
    %2095 = qlx.apply #qlx.action<pauli_rotation>(%2094#1, %cst_2086) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2087 = arith.constant 0.78539816339744828 : f64
    %2096:2 = qlx.apply #qlx.action<pauli_rotation>(%2094#0, %2095, %cst_2087) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2088 = arith.constant 0.78539816339744828 : f64
    %2097:2 = qlx.apply #qlx.action<pauli_rotation>(%2096#0, %2096#1, %cst_2088) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2089 = arith.constant 0.78539816339744828 : f64
    %2098:2 = qlx.apply #qlx.action<pauli_rotation>(%2097#0, %2097#1, %cst_2089) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2090 = arith.constant 0.78539816339744828 : f64
    %2099 = qlx.apply #qlx.action<pauli_rotation>(%2098#1, %cst_2090) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2091 = arith.constant 0.78539816339744828 : f64
    %2100:2 = qlx.apply #qlx.action<pauli_rotation>(%2098#0, %2099, %cst_2091) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2092 = arith.constant 0.78539816339744828 : f64
    %2101 = qlx.apply #qlx.action<pauli_rotation>(%2100#1, %cst_2092) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2093 = arith.constant 0.78539816339744828 : f64
    %2102:2 = qlx.apply #qlx.action<pauli_rotation>(%2100#0, %2101, %cst_2093) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2094 = arith.constant 0.78539816339744828 : f64
    %2103:2 = qlx.apply #qlx.action<pauli_rotation>(%2102#0, %2102#1, %cst_2094) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2095 = arith.constant 0.78539816339744828 : f64
    %2104:2 = qlx.apply #qlx.action<pauli_rotation>(%2103#0, %2103#1, %cst_2095) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2096 = arith.constant 0.78539816339744828 : f64
    %2105 = qlx.apply #qlx.action<pauli_rotation>(%2104#1, %cst_2096) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2097 = arith.constant 0.78539816339744828 : f64
    %2106:2 = qlx.apply #qlx.action<pauli_rotation>(%2104#0, %2105, %cst_2097) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2098 = arith.constant 0.78539816339744828 : f64
    %2107:2 = qlx.apply #qlx.action<pauli_rotation>(%2106#0, %2106#1, %cst_2098) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2099 = arith.constant 0.78539816339744828 : f64
    %2108 = qlx.apply #qlx.action<pauli_rotation>(%2107#1, %cst_2099) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2100 = arith.constant 0.78539816339744828 : f64
    %2109:2 = qlx.apply #qlx.action<pauli_rotation>(%2107#0, %2108, %cst_2100) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2101 = arith.constant 0.78539816339744828 : f64
    %2110:2 = qlx.apply #qlx.action<pauli_rotation>(%2109#0, %2109#1, %cst_2101) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2102 = arith.constant 0.78539816339744828 : f64
    %2111:2 = qlx.apply #qlx.action<pauli_rotation>(%2110#0, %2110#1, %cst_2102) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2103 = arith.constant 0.78539816339744828 : f64
    %2112 = qlx.apply #qlx.action<pauli_rotation>(%1991#2, %cst_2103) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2104 = arith.constant 0.78539816339744828 : f64
    %2113:2 = qlx.apply #qlx.action<pauli_rotation>(%2112, %1991#3, %cst_2104) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2105 = arith.constant 0.78539816339744828 : f64
    %2114 = qlx.apply #qlx.action<pauli_rotation>(%2113#0, %cst_2105) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2106 = arith.constant 0.78539816339744828 : f64
    %2115:2 = qlx.apply #qlx.action<pauli_rotation>(%2114, %2113#1, %cst_2106) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2107 = arith.constant 0.78539816339744828 : f64
    %2116 = qlx.apply #qlx.action<pauli_rotation>(%2115#0, %cst_2107) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2108 = arith.constant 0.78539816339744828 : f64
    %2117:2 = qlx.apply #qlx.action<pauli_rotation>(%2116, %2115#1, %cst_2108) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2109 = arith.constant 0.78539816339744828 : f64
    %2118:2 = qlx.apply #qlx.action<pauli_rotation>(%2117#0, %2117#1, %cst_2109) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2110 = arith.constant 0.78539816339744828 : f64
    %2119:2 = qlx.apply #qlx.action<pauli_rotation>(%2118#0, %2118#1, %cst_2110) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2111 = arith.constant 0.78539816339744828 : f64
    %2120 = qlx.apply #qlx.action<pauli_rotation>(%2119#0, %cst_2111) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2112 = arith.constant 0.78539816339744828 : f64
    %2121:2 = qlx.apply #qlx.action<pauli_rotation>(%2120, %2119#1, %cst_2112) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2113 = arith.constant 0.78539816339744828 : f64
    %2122:2 = qlx.apply #qlx.action<pauli_rotation>(%2121#0, %2121#1, %cst_2113) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2114 = arith.constant 0.78539816339744828 : f64
    %2123:2 = qlx.apply #qlx.action<pauli_rotation>(%2122#0, %2122#1, %cst_2114) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2115 = arith.constant 0.78539816339744828 : f64
    %2124:2 = qlx.apply #qlx.action<pauli_rotation>(%2123#0, %2123#1, %cst_2115) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2116 = arith.constant 0.78539816339744828 : f64
    %2125:2 = qlx.apply #qlx.action<pauli_rotation>(%2124#0, %2124#1, %cst_2116) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2117 = arith.constant 0.78539816339744828 : f64
    %2126 = qlx.apply #qlx.action<pauli_rotation>(%2125#0, %cst_2117) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2118 = arith.constant 0.78539816339744828 : f64
    %2127:2 = qlx.apply #qlx.action<pauli_rotation>(%2126, %2125#1, %cst_2118) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2119 = arith.constant 0.78539816339744828 : f64
    %2128:2 = qlx.apply #qlx.action<pauli_rotation>(%2127#0, %2127#1, %cst_2119) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2120 = arith.constant 0.78539816339744828 : f64
    %2129:2 = qlx.apply #qlx.action<pauli_rotation>(%2128#0, %2128#1, %cst_2120) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2121 = arith.constant 0.78539816339744828 : f64
    %2130 = qlx.apply #qlx.action<pauli_rotation>(%2129#0, %cst_2121) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2122 = arith.constant 0.78539816339744828 : f64
    %2131:2 = qlx.apply #qlx.action<pauli_rotation>(%2130, %2129#1, %cst_2122) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2123 = arith.constant 0.78539816339744828 : f64
    %2132:2 = qlx.apply #qlx.action<pauli_rotation>(%2131#0, %2131#1, %cst_2123) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2124 = arith.constant 0.78539816339744828 : f64
    %2133 = qlx.apply #qlx.action<pauli_rotation>(%2132#0, %cst_2124) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2125 = arith.constant 0.78539816339744828 : f64
    %2134:2 = qlx.apply #qlx.action<pauli_rotation>(%2133, %2132#1, %cst_2125) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2126 = arith.constant 0.78539816339744828 : f64
    %2135 = qlx.apply #qlx.action<pauli_rotation>(%2134#0, %cst_2126) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2127 = arith.constant 0.78539816339744828 : f64
    %2136:2 = qlx.apply #qlx.action<pauli_rotation>(%2135, %2134#1, %cst_2127) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2128 = arith.constant 0.78539816339744828 : f64
    %2137 = qlx.apply #qlx.action<pauli_rotation>(%2136#0, %cst_2128) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2129 = arith.constant 0.78539816339744828 : f64
    %2138:2 = qlx.apply #qlx.action<pauli_rotation>(%2137, %2136#1, %cst_2129) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2130 = arith.constant 0.78539816339744828 : f64
    %2139 = qlx.apply #qlx.action<pauli_rotation>(%2138#0, %cst_2130) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2131 = arith.constant 0.78539816339744828 : f64
    %2140:2 = qlx.apply #qlx.action<pauli_rotation>(%2139, %2138#1, %cst_2131) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2132 = arith.constant 0.78539816339744828 : f64
    %2141:2 = qlx.apply #qlx.action<pauli_rotation>(%2140#0, %2140#1, %cst_2132) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2133 = arith.constant 0.78539816339744828 : f64
    %2142 = qlx.apply #qlx.action<pauli_rotation>(%2141#0, %cst_2133) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2134 = arith.constant 0.78539816339744828 : f64
    %2143:2 = qlx.apply #qlx.action<pauli_rotation>(%2142, %2141#1, %cst_2134) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2135 = arith.constant 0.78539816339744828 : f64
    %2144:2 = qlx.apply #qlx.action<pauli_rotation>(%2143#0, %2143#1, %cst_2135) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2136 = arith.constant 0.78539816339744828 : f64
    %2145:2 = qlx.apply #qlx.action<pauli_rotation>(%2144#0, %2144#1, %cst_2136) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2137 = arith.constant 0.78539816339744828 : f64
    %2146:2 = qlx.apply #qlx.action<pauli_rotation>(%2145#0, %2145#1, %cst_2137) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2138 = arith.constant 0.78539816339744828 : f64
    %2147 = qlx.apply #qlx.action<pauli_rotation>(%2146#0, %cst_2138) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2139 = arith.constant 0.78539816339744828 : f64
    %2148:2 = qlx.apply #qlx.action<pauli_rotation>(%2147, %2146#1, %cst_2139) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2140 = arith.constant 0.78539816339744828 : f64
    %2149 = qlx.apply #qlx.action<pauli_rotation>(%2148#0, %cst_2140) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2141 = arith.constant 0.78539816339744828 : f64
    %2150:2 = qlx.apply #qlx.action<pauli_rotation>(%2149, %2148#1, %cst_2141) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2142 = arith.constant 0.78539816339744828 : f64
    %2151 = qlx.apply #qlx.action<pauli_rotation>(%2150#0, %cst_2142) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2143 = arith.constant 0.78539816339744828 : f64
    %2152:2 = qlx.apply #qlx.action<pauli_rotation>(%2151, %2150#1, %cst_2143) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2144 = arith.constant 0.78539816339744828 : f64
    %2153:2 = qlx.apply #qlx.action<pauli_rotation>(%2152#0, %2152#1, %cst_2144) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2145 = arith.constant 0.78539816339744828 : f64
    %2154:2 = qlx.apply #qlx.action<pauli_rotation>(%2153#0, %2153#1, %cst_2145) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2146 = arith.constant 0.78539816339744828 : f64
    %2155 = qlx.apply #qlx.action<pauli_rotation>(%2154#0, %cst_2146) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2147 = arith.constant 0.78539816339744828 : f64
    %2156:2 = qlx.apply #qlx.action<pauli_rotation>(%2155, %2154#1, %cst_2147) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2148 = arith.constant 0.78539816339744828 : f64
    %2157:2 = qlx.apply #qlx.action<pauli_rotation>(%2156#0, %2156#1, %cst_2148) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2149 = arith.constant 0.78539816339744828 : f64
    %2158:2 = qlx.apply #qlx.action<pauli_rotation>(%2157#0, %2157#1, %cst_2149) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2150 = arith.constant 0.78539816339744828 : f64
    %2159 = qlx.apply #qlx.action<pauli_rotation>(%2158#0, %cst_2150) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2151 = arith.constant 0.78539816339744828 : f64
    %2160:2 = qlx.apply #qlx.action<pauli_rotation>(%2159, %2158#1, %cst_2151) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2152 = arith.constant 0.78539816339744828 : f64
    %2161 = qlx.apply #qlx.action<pauli_rotation>(%2160#0, %cst_2152) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2153 = arith.constant 0.78539816339744828 : f64
    %2162:2 = qlx.apply #qlx.action<pauli_rotation>(%2161, %2160#1, %cst_2153) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2154 = arith.constant 0.78539816339744828 : f64
    %2163:2 = qlx.apply #qlx.action<pauli_rotation>(%2162#0, %2162#1, %cst_2154) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2155 = arith.constant 0.78539816339744828 : f64
    %2164:2 = qlx.apply #qlx.action<pauli_rotation>(%2163#0, %2163#1, %cst_2155) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2156 = arith.constant 0.78539816339744828 : f64
    %2165 = qlx.apply #qlx.action<pauli_rotation>(%2164#0, %cst_2156) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2157 = arith.constant 0.78539816339744828 : f64
    %2166:2 = qlx.apply #qlx.action<pauli_rotation>(%2165, %2164#1, %cst_2157) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2158 = arith.constant 0.78539816339744828 : f64
    %2167:2 = qlx.apply #qlx.action<pauli_rotation>(%2166#0, %2166#1, %cst_2158) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2159 = arith.constant 0.78539816339744828 : f64
    %2168 = qlx.apply #qlx.action<pauli_rotation>(%2167#0, %cst_2159) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2160 = arith.constant 0.78539816339744828 : f64
    %2169:2 = qlx.apply #qlx.action<pauli_rotation>(%2168, %2167#1, %cst_2160) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2161 = arith.constant 0.78539816339744828 : f64
    %2170:2 = qlx.apply #qlx.action<pauli_rotation>(%2169#0, %2169#1, %cst_2161) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 3 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2162 = arith.constant 0.78539816339744828 : f64
    %2171:2 = qlx.apply #qlx.action<pauli_rotation>(%2170#0, %2170#1, %cst_2162) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2163 = arith.constant 0.78539816339744828 : f64
    %2172 = qlx.apply #qlx.action<pauli_rotation>(%1991#4, %cst_2163) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2164 = arith.constant 0.78539816339744828 : f64
    %2173:2 = qlx.apply #qlx.action<pauli_rotation>(%1863#3, %2172, %cst_2164) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2165 = arith.constant 0.78539816339744828 : f64
    %2174 = qlx.apply #qlx.action<pauli_rotation>(%2173#1, %cst_2165) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2166 = arith.constant 0.78539816339744828 : f64
    %2175:2 = qlx.apply #qlx.action<pauli_rotation>(%2173#0, %2174, %cst_2166) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2167 = arith.constant 0.78539816339744828 : f64
    %2176 = qlx.apply #qlx.action<pauli_rotation>(%2175#1, %cst_2167) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2168 = arith.constant 0.78539816339744828 : f64
    %2177:2 = qlx.apply #qlx.action<pauli_rotation>(%2175#0, %2176, %cst_2168) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2169 = arith.constant 0.78539816339744828 : f64
    %2178:2 = qlx.apply #qlx.action<pauli_rotation>(%2177#0, %2177#1, %cst_2169) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2170 = arith.constant 0.78539816339744828 : f64
    %2179:2 = qlx.apply #qlx.action<pauli_rotation>(%2178#0, %2178#1, %cst_2170) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2171 = arith.constant 0.78539816339744828 : f64
    %2180 = qlx.apply #qlx.action<pauli_rotation>(%2179#1, %cst_2171) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2172 = arith.constant 0.78539816339744828 : f64
    %2181:2 = qlx.apply #qlx.action<pauli_rotation>(%2179#0, %2180, %cst_2172) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2173 = arith.constant 0.78539816339744828 : f64
    %2182:2 = qlx.apply #qlx.action<pauli_rotation>(%2181#0, %2181#1, %cst_2173) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2174 = arith.constant 0.78539816339744828 : f64
    %2183:2 = qlx.apply #qlx.action<pauli_rotation>(%2182#0, %2182#1, %cst_2174) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2175 = arith.constant 0.78539816339744828 : f64
    %2184:2 = qlx.apply #qlx.action<pauli_rotation>(%2183#0, %2183#1, %cst_2175) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2176 = arith.constant 0.78539816339744828 : f64
    %2185:2 = qlx.apply #qlx.action<pauli_rotation>(%2184#0, %2184#1, %cst_2176) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2177 = arith.constant 0.78539816339744828 : f64
    %2186 = qlx.apply #qlx.action<pauli_rotation>(%2185#1, %cst_2177) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2178 = arith.constant 0.78539816339744828 : f64
    %2187:2 = qlx.apply #qlx.action<pauli_rotation>(%2185#0, %2186, %cst_2178) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2179 = arith.constant 0.78539816339744828 : f64
    %2188:2 = qlx.apply #qlx.action<pauli_rotation>(%2187#0, %2187#1, %cst_2179) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2180 = arith.constant 0.78539816339744828 : f64
    %2189:2 = qlx.apply #qlx.action<pauli_rotation>(%2188#0, %2188#1, %cst_2180) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2181 = arith.constant 0.78539816339744828 : f64
    %2190 = qlx.apply #qlx.action<pauli_rotation>(%2189#1, %cst_2181) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2182 = arith.constant 0.78539816339744828 : f64
    %2191:2 = qlx.apply #qlx.action<pauli_rotation>(%2189#0, %2190, %cst_2182) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2183 = arith.constant 0.78539816339744828 : f64
    %2192:2 = qlx.apply #qlx.action<pauli_rotation>(%2191#0, %2191#1, %cst_2183) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2184 = arith.constant 0.78539816339744828 : f64
    %2193 = qlx.apply #qlx.action<pauli_rotation>(%2192#1, %cst_2184) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2185 = arith.constant 0.78539816339744828 : f64
    %2194:2 = qlx.apply #qlx.action<pauli_rotation>(%2192#0, %2193, %cst_2185) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2186 = arith.constant 0.78539816339744828 : f64
    %2195 = qlx.apply #qlx.action<pauli_rotation>(%2194#1, %cst_2186) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2187 = arith.constant 0.78539816339744828 : f64
    %2196:2 = qlx.apply #qlx.action<pauli_rotation>(%2194#0, %2195, %cst_2187) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2188 = arith.constant 0.78539816339744828 : f64
    %2197 = qlx.apply #qlx.action<pauli_rotation>(%2196#1, %cst_2188) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2189 = arith.constant 0.78539816339744828 : f64
    %2198:2 = qlx.apply #qlx.action<pauli_rotation>(%2196#0, %2197, %cst_2189) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2190 = arith.constant 0.78539816339744828 : f64
    %2199 = qlx.apply #qlx.action<pauli_rotation>(%2198#1, %cst_2190) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2191 = arith.constant 0.78539816339744828 : f64
    %2200:2 = qlx.apply #qlx.action<pauli_rotation>(%2198#0, %2199, %cst_2191) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2192 = arith.constant 0.78539816339744828 : f64
    %2201:2 = qlx.apply #qlx.action<pauli_rotation>(%2200#0, %2200#1, %cst_2192) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2193 = arith.constant 0.78539816339744828 : f64
    %2202 = qlx.apply #qlx.action<pauli_rotation>(%2201#1, %cst_2193) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2194 = arith.constant 0.78539816339744828 : f64
    %2203:2 = qlx.apply #qlx.action<pauli_rotation>(%2201#0, %2202, %cst_2194) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2195 = arith.constant 0.78539816339744828 : f64
    %2204:2 = qlx.apply #qlx.action<pauli_rotation>(%2203#0, %2203#1, %cst_2195) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2196 = arith.constant 0.78539816339744828 : f64
    %2205:2 = qlx.apply #qlx.action<pauli_rotation>(%2204#0, %2204#1, %cst_2196) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2197 = arith.constant 0.78539816339744828 : f64
    %2206:2 = qlx.apply #qlx.action<pauli_rotation>(%2205#0, %2205#1, %cst_2197) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2198 = arith.constant 0.78539816339744828 : f64
    %2207 = qlx.apply #qlx.action<pauli_rotation>(%2206#1, %cst_2198) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2199 = arith.constant 0.78539816339744828 : f64
    %2208:2 = qlx.apply #qlx.action<pauli_rotation>(%2206#0, %2207, %cst_2199) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2200 = arith.constant 0.78539816339744828 : f64
    %2209 = qlx.apply #qlx.action<pauli_rotation>(%2208#1, %cst_2200) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2201 = arith.constant 0.78539816339744828 : f64
    %2210:2 = qlx.apply #qlx.action<pauli_rotation>(%2208#0, %2209, %cst_2201) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2202 = arith.constant 0.78539816339744828 : f64
    %2211 = qlx.apply #qlx.action<pauli_rotation>(%2210#1, %cst_2202) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2203 = arith.constant 0.78539816339744828 : f64
    %2212:2 = qlx.apply #qlx.action<pauli_rotation>(%2210#0, %2211, %cst_2203) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2204 = arith.constant 0.78539816339744828 : f64
    %2213:2 = qlx.apply #qlx.action<pauli_rotation>(%2212#0, %2212#1, %cst_2204) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2205 = arith.constant 0.78539816339744828 : f64
    %2214:2 = qlx.apply #qlx.action<pauli_rotation>(%2213#0, %2213#1, %cst_2205) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2206 = arith.constant 0.78539816339744828 : f64
    %2215 = qlx.apply #qlx.action<pauli_rotation>(%2214#1, %cst_2206) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2207 = arith.constant 0.78539816339744828 : f64
    %2216:2 = qlx.apply #qlx.action<pauli_rotation>(%2214#0, %2215, %cst_2207) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2208 = arith.constant 0.78539816339744828 : f64
    %2217:2 = qlx.apply #qlx.action<pauli_rotation>(%2216#0, %2216#1, %cst_2208) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2209 = arith.constant 0.78539816339744828 : f64
    %2218:2 = qlx.apply #qlx.action<pauli_rotation>(%2217#0, %2217#1, %cst_2209) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2210 = arith.constant 0.78539816339744828 : f64
    %2219 = qlx.apply #qlx.action<pauli_rotation>(%2218#1, %cst_2210) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2211 = arith.constant 0.78539816339744828 : f64
    %2220:2 = qlx.apply #qlx.action<pauli_rotation>(%2218#0, %2219, %cst_2211) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2212 = arith.constant 0.78539816339744828 : f64
    %2221 = qlx.apply #qlx.action<pauli_rotation>(%2220#1, %cst_2212) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2213 = arith.constant 0.78539816339744828 : f64
    %2222:2 = qlx.apply #qlx.action<pauli_rotation>(%2220#0, %2221, %cst_2213) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2214 = arith.constant 0.78539816339744828 : f64
    %2223:2 = qlx.apply #qlx.action<pauli_rotation>(%2222#0, %2222#1, %cst_2214) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2215 = arith.constant 0.78539816339744828 : f64
    %2224:2 = qlx.apply #qlx.action<pauli_rotation>(%2223#0, %2223#1, %cst_2215) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2216 = arith.constant 0.78539816339744828 : f64
    %2225 = qlx.apply #qlx.action<pauli_rotation>(%2224#1, %cst_2216) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2217 = arith.constant 0.78539816339744828 : f64
    %2226:2 = qlx.apply #qlx.action<pauli_rotation>(%2224#0, %2225, %cst_2217) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = -1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2218 = arith.constant 0.78539816339744828 : f64
    %2227:2 = qlx.apply #qlx.action<pauli_rotation>(%2226#0, %2226#1, %cst_2218) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2219 = arith.constant 0.78539816339744828 : f64
    %2228 = qlx.apply #qlx.action<pauli_rotation>(%2227#1, %cst_2219) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 1 : i64, z_mask = 0 : i64}} : (!qlx.logical_qubit, f64) -> !qlx.logical_qubit
    %cst_2220 = arith.constant 0.78539816339744828 : f64
    %2229:2 = qlx.apply #qlx.action<pauli_rotation>(%2227#0, %2228, %cst_2220) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2221 = arith.constant 0.78539816339744828 : f64
    %2230:2 = qlx.apply #qlx.action<pauli_rotation>(%2229#0, %2229#1, %cst_2221) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2222 = arith.constant 0.78539816339744828 : f64
    %2231:2 = qlx.apply #qlx.action<pauli_rotation>(%2230#0, %2230#1, %cst_2222) {parameters = {angle_pi_denom = 4 : i64, angle_pi_numer = 1 : i64, sign = 1 : i64, x_mask = 2 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %2232:2 = qlx.instrument #qlx.instrument<mpp>(%2051#0) {parameters = {sign = -1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit) -> (!qlx.logical_qubit, i1)
    %2233:3 = qlx.instrument #qlx.instrument<mpp>(%2232#0, %2051#1) {parameters = {sign = 1 : i64, x_mask = 2 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit, i1)
    %2234:2 = qlx.instrument #qlx.instrument<mpp>(%2111#0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit) -> (!qlx.logical_qubit, i1)
    %2235:3 = qlx.instrument #qlx.instrument<mpp>(%2234#0, %2111#1) {parameters = {sign = -1 : i64, x_mask = 2 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit, i1)
    %2236:3 = qlx.instrument #qlx.instrument<mpp>(%2171#0, %2171#1) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit, i1)
    %2237:2 = qlx.instrument #qlx.instrument<mpp>(%2236#1) {parameters = {sign = 1 : i64, x_mask = 1 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit) -> (!qlx.logical_qubit, i1)
    %2238:2 = qlx.instrument #qlx.instrument<mpp>(%2231#0) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit) -> (!qlx.logical_qubit, i1)
    %2239:3 = qlx.instrument #qlx.instrument<mpp>(%2238#0, %2231#1) {parameters = {sign = -1 : i64, x_mask = 2 : i64, z_mask = 1 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit) -> (!qlx.logical_qubit, !qlx.logical_qubit, i1)
    qlx.discard %2233#0, %2233#1, %2235#0, %2235#1, %2236#0, %2237#0, %2239#0, %2239#1 : !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit
    %cst_2223 = arith.constant 2.500000e-01 : f64
    %cst_2224 = arith.constant 2.500000e-01 : f64
    %cst_2225 = arith.constant 2.500000e-01 : f64
    %cst_2226 = arith.constant 2.500000e-01 : f64
    %cst_2227 = arith.constant 0.78539816339744828 : f64
    %cst_2228 = arith.constant 0.78539816339744828 : f64
    %cst_2229 = arith.constant 0.78539816339744828 : f64
    %cst_2230 = arith.constant 0.78539816339744828 : f64
    %cst_2231 = arith.constant 5.000000e-01 : f64
    %cst_2232 = arith.constant 5.000000e-01 : f64
    %cst_2233 = arith.constant 0.78539816339744828 : f64
    %cst_2234 = arith.constant 0.78539816339744828 : f64
    %cst_2235 = arith.constant 0.78539816339744828 : f64
    %cst_2236 = arith.constant 0.78539816339744828 : f64
    %cst_2237 = arith.constant 0.78539816339744828 : f64
    %cst_2238 = arith.constant 0.78539816339744828 : f64
    %cst_2239 = arith.constant 0.78539816339744828 : f64
    %cst_2240 = arith.constant 0.78539816339744828 : f64
    %cst_2241 = arith.constant 5.000000e-01 : f64
    %cst_2242 = arith.constant 5.000000e-01 : f64
    %cst_2243 = arith.constant 0.78539816339744828 : f64
    %cst_2244 = arith.constant 0.78539816339744828 : f64
    %cst_2245 = arith.constant 0.78539816339744828 : f64
    %cst_2246 = arith.constant 0.78539816339744828 : f64
    %cst_2247 = arith.constant 5.000000e-01 : f64
    %cst_2248 = arith.constant 5.000000e-01 : f64
    %cst_2249 = arith.constant 5.000000e-01 : f64
    %cst_2250 = arith.constant 5.000000e-01 : f64
    %cst_2251 = arith.constant 0.78539816339744828 : f64
    %cst_2252 = arith.constant 0.78539816339744828 : f64
    %cst_2253 = arith.constant 0.78539816339744828 : f64
    %cst_2254 = arith.constant 0.78539816339744828 : f64
    %cst_2255 = arith.constant 5.000000e-01 : f64
    %cst_2256 = arith.constant 5.000000e-01 : f64
    %cst_2257 = arith.constant 0.78539816339744828 : f64
    %cst_2258 = arith.constant 0.78539816339744828 : f64
    %cst_2259 = arith.constant 0.78539816339744828 : f64
    %cst_2260 = arith.constant 0.78539816339744828 : f64
    %cst_2261 = arith.constant 0.78539816339744828 : f64
    %cst_2262 = arith.constant 0.78539816339744828 : f64
    %cst_2263 = arith.constant 0.78539816339744828 : f64
    %cst_2264 = arith.constant 0.78539816339744828 : f64
    %cst_2265 = arith.constant 5.000000e-01 : f64
    %cst_2266 = arith.constant 5.000000e-01 : f64
    %cst_2267 = arith.constant 0.78539816339744828 : f64
    %cst_2268 = arith.constant 0.78539816339744828 : f64
    %cst_2269 = arith.constant 0.78539816339744828 : f64
    %cst_2270 = arith.constant 0.78539816339744828 : f64
    %cst_2271 = arith.constant 5.000000e-01 : f64
    %cst_2272 = arith.constant 5.000000e-01 : f64
    %cst_2273 = arith.constant 5.000000e-01 : f64
    %cst_2274 = arith.constant 5.000000e-01 : f64
    %cst_2275 = arith.constant 0.78539816339744828 : f64
    %cst_2276 = arith.constant 0.78539816339744828 : f64
    %cst_2277 = arith.constant 0.78539816339744828 : f64
    %cst_2278 = arith.constant 0.78539816339744828 : f64
    %cst_2279 = arith.constant 5.000000e-01 : f64
    %cst_2280 = arith.constant 5.000000e-01 : f64
    %cst_2281 = arith.constant 0.78539816339744828 : f64
    %cst_2282 = arith.constant 0.78539816339744828 : f64
    %cst_2283 = arith.constant 0.78539816339744828 : f64
    %cst_2284 = arith.constant 0.78539816339744828 : f64
    %cst_2285 = arith.constant 0.78539816339744828 : f64
    %cst_2286 = arith.constant 0.78539816339744828 : f64
    %cst_2287 = arith.constant 0.78539816339744828 : f64
    %cst_2288 = arith.constant 0.78539816339744828 : f64
    %cst_2289 = arith.constant 5.000000e-01 : f64
    %cst_2290 = arith.constant 5.000000e-01 : f64
    %cst_2291 = arith.constant 0.78539816339744828 : f64
    %cst_2292 = arith.constant 0.78539816339744828 : f64
    %cst_2293 = arith.constant 0.78539816339744828 : f64
    %cst_2294 = arith.constant 0.78539816339744828 : f64
    %cst_2295 = arith.constant 5.000000e-01 : f64
    %cst_2296 = arith.constant 5.000000e-01 : f64
    %cst_2297 = arith.constant 5.000000e-01 : f64
    %cst_2298 = arith.constant 5.000000e-01 : f64
    %cst_2299 = arith.constant 0.78539816339744828 : f64
    %cst_2300 = arith.constant 0.78539816339744828 : f64
    %cst_2301 = arith.constant 0.78539816339744828 : f64
    %cst_2302 = arith.constant 0.78539816339744828 : f64
    %cst_2303 = arith.constant 5.000000e-01 : f64
    %cst_2304 = arith.constant 5.000000e-01 : f64
    %cst_2305 = arith.constant 0.78539816339744828 : f64
    %cst_2306 = arith.constant 0.78539816339744828 : f64
    %cst_2307 = arith.constant 0.78539816339744828 : f64
    %cst_2308 = arith.constant 0.78539816339744828 : f64
    %cst_2309 = arith.constant 0.78539816339744828 : f64
    %cst_2310 = arith.constant 0.78539816339744828 : f64
    %cst_2311 = arith.constant 0.78539816339744828 : f64
    %cst_2312 = arith.constant 0.78539816339744828 : f64
    %cst_2313 = arith.constant 5.000000e-01 : f64
    %cst_2314 = arith.constant 5.000000e-01 : f64
    %cst_2315 = arith.constant 0.78539816339744828 : f64
    %cst_2316 = arith.constant 0.78539816339744828 : f64
    %cst_2317 = arith.constant 0.78539816339744828 : f64
    %cst_2318 = arith.constant 0.78539816339744828 : f64
    %cst_2319 = arith.constant 2.500000e-01 : f64
    %cst_2320 = arith.constant 2.500000e-01 : f64
    %cst_2321 = arith.constant 2.500000e-01 : f64
    %cst_2322 = arith.constant 2.500000e-01 : f64
  }
}
