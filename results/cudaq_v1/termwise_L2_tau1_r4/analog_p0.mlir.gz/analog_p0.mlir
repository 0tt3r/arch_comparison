module attributes {qlx.facets = [], qlx.ir_version = "0.4-draft", qlx.model_version = "0.3.10-proposed", qlx.profiles = ["p0"], qlx.stages = ["p0"]} {
  qlx.program @program : () -> () attributes {qlx.profile = "p0", qlx.stage = "p0"} {
    %0 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 0 : i64} : !qlx.logical_qubit
    %1 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 1 : i64} : !qlx.logical_qubit
    %2 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 2 : i64} : !qlx.logical_qubit
    %3 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 3 : i64} : !qlx.logical_qubit
    %4 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 4 : i64} : !qlx.logical_qubit
    %5 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 5 : i64} : !qlx.logical_qubit
    %6 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 6 : i64} : !qlx.logical_qubit
    %7 = qlx.prepare "zero" {allocation = 0 : i64, value_index = 7 : i64} : !qlx.logical_qubit
    %8 = qlx.apply #qlx.action<x>(%0) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %9 = qlx.apply #qlx.action<x>(%3) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %10 = qlx.apply #qlx.action<x>(%4) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %11 = qlx.apply #qlx.action<x>(%7) : (!qlx.logical_qubit) -> !qlx.logical_qubit
    %cst = arith.constant 2.500000e-01 : f64
    %12:2 = qlx.apply #qlx.action<pauli_rotation>(%8, %1, %cst) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_0 = arith.constant 1.250000e-01 : f64
    %13:3 = qlx.apply #qlx.action<pauli_rotation>(%2, %12#0, %12#1, %cst_0) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_1 = arith.constant 1.250000e-01 : f64
    %14:3 = qlx.apply #qlx.action<pauli_rotation>(%13#0, %13#1, %13#2, %cst_1) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_2 = arith.constant 1.250000e-01 : f64
    %15:3 = qlx.apply #qlx.action<pauli_rotation>(%9, %14#0, %14#2, %cst_2) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_3 = arith.constant 1.250000e-01 : f64
    %16:3 = qlx.apply #qlx.action<pauli_rotation>(%15#0, %15#1, %15#2, %cst_3) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_4 = arith.constant 1.250000e-01 : f64
    %17:7 = qlx.apply #qlx.action<pauli_rotation>(%10, %5, %6, %14#1, %16#0, %16#1, %16#2, %cst_4) {parameters = {sign = -1 : i64, x_mask = 12 : i64, z_mask = 115 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_5 = arith.constant 1.250000e-01 : f64
    %18:7 = qlx.apply #qlx.action<pauli_rotation>(%17#0, %17#1, %17#2, %17#3, %17#4, %17#5, %17#6, %cst_5) {parameters = {sign = -1 : i64, x_mask = 12 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_6 = arith.constant 1.250000e-01 : f64
    %19:7 = qlx.apply #qlx.action<pauli_rotation>(%11, %18#0, %18#1, %18#2, %18#4, %18#5, %18#6, %cst_6) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 62 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_7 = arith.constant 1.250000e-01 : f64
    %20:7 = qlx.apply #qlx.action<pauli_rotation>(%19#0, %19#1, %19#2, %19#3, %19#4, %19#5, %19#6, %cst_7) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_8 = arith.constant 1.250000e-01 : f64
    %21:3 = qlx.apply #qlx.action<pauli_rotation>(%20#1, %20#4, %20#5, %cst_8) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_9 = arith.constant 1.250000e-01 : f64
    %22:3 = qlx.apply #qlx.action<pauli_rotation>(%21#0, %21#1, %21#2, %cst_9) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_10 = arith.constant 1.250000e-01 : f64
    %23:3 = qlx.apply #qlx.action<pauli_rotation>(%20#2, %22#0, %22#1, %cst_10) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_11 = arith.constant 1.250000e-01 : f64
    %24:3 = qlx.apply #qlx.action<pauli_rotation>(%23#0, %23#1, %23#2, %cst_11) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_12 = arith.constant 1.250000e-01 : f64
    %25:3 = qlx.apply #qlx.action<pauli_rotation>(%20#3, %24#0, %24#1, %cst_12) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_13 = arith.constant 1.250000e-01 : f64
    %26:3 = qlx.apply #qlx.action<pauli_rotation>(%25#0, %25#1, %25#2, %cst_13) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_14 = arith.constant 1.250000e-01 : f64
    %27:3 = qlx.apply #qlx.action<pauli_rotation>(%20#0, %26#0, %26#1, %cst_14) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_15 = arith.constant 1.250000e-01 : f64
    %28:3 = qlx.apply #qlx.action<pauli_rotation>(%27#0, %27#1, %27#2, %cst_15) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_16 = arith.constant 2.500000e-01 : f64
    %29:2 = qlx.apply #qlx.action<pauli_rotation>(%22#2, %24#2, %cst_16) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_17 = arith.constant 2.500000e-01 : f64
    %30:2 = qlx.apply #qlx.action<pauli_rotation>(%26#2, %28#2, %cst_17) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_18 = arith.constant 5.000000e-01 : f64
    %31:2 = qlx.apply #qlx.action<pauli_rotation>(%28#0, %28#1, %cst_18) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_19 = arith.constant 2.500000e-01 : f64
    %32:2 = qlx.apply #qlx.action<pauli_rotation>(%30#0, %30#1, %cst_19) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_20 = arith.constant 2.500000e-01 : f64
    %33:2 = qlx.apply #qlx.action<pauli_rotation>(%29#0, %29#1, %cst_20) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_21 = arith.constant 1.250000e-01 : f64
    %34:3 = qlx.apply #qlx.action<pauli_rotation>(%31#0, %31#1, %32#1, %cst_21) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_22 = arith.constant 1.250000e-01 : f64
    %35:3 = qlx.apply #qlx.action<pauli_rotation>(%34#0, %34#1, %34#2, %cst_22) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_23 = arith.constant 1.250000e-01 : f64
    %36:3 = qlx.apply #qlx.action<pauli_rotation>(%32#0, %35#1, %35#2, %cst_23) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_24 = arith.constant 1.250000e-01 : f64
    %37:3 = qlx.apply #qlx.action<pauli_rotation>(%36#0, %36#1, %36#2, %cst_24) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_25 = arith.constant 1.250000e-01 : f64
    %38:3 = qlx.apply #qlx.action<pauli_rotation>(%33#1, %37#0, %37#2, %cst_25) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_26 = arith.constant 1.250000e-01 : f64
    %39:3 = qlx.apply #qlx.action<pauli_rotation>(%38#0, %38#1, %38#2, %cst_26) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_27 = arith.constant 1.250000e-01 : f64
    %40:3 = qlx.apply #qlx.action<pauli_rotation>(%33#0, %39#0, %39#1, %cst_27) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_28 = arith.constant 1.250000e-01 : f64
    %41:3 = qlx.apply #qlx.action<pauli_rotation>(%40#0, %40#1, %40#2, %cst_28) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_29 = arith.constant 1.250000e-01 : f64
    %42:7 = qlx.apply #qlx.action<pauli_rotation>(%20#6, %35#0, %37#1, %39#2, %41#0, %41#1, %41#2, %cst_29) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_30 = arith.constant 1.250000e-01 : f64
    %43:7 = qlx.apply #qlx.action<pauli_rotation>(%42#0, %42#1, %42#2, %42#3, %42#4, %42#5, %42#6, %cst_30) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 124 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_31 = arith.constant 1.250000e-01 : f64
    %44:7 = qlx.apply #qlx.action<pauli_rotation>(%18#3, %43#0, %43#2, %43#3, %43#4, %43#5, %43#6, %cst_31) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_32 = arith.constant 1.250000e-01 : f64
    %45:7 = qlx.apply #qlx.action<pauli_rotation>(%44#0, %44#1, %44#2, %44#3, %44#4, %44#5, %44#6, %cst_32) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 122 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_33 = arith.constant 1.250000e-01 : f64
    %46:3 = qlx.apply #qlx.action<pauli_rotation>(%45#1, %45#4, %45#5, %cst_33) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_34 = arith.constant 1.250000e-01 : f64
    %47:3 = qlx.apply #qlx.action<pauli_rotation>(%46#0, %46#1, %46#2, %cst_34) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_35 = arith.constant 1.250000e-01 : f64
    %48:3 = qlx.apply #qlx.action<pauli_rotation>(%45#0, %47#0, %47#1, %cst_35) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_36 = arith.constant 1.250000e-01 : f64
    %49:3 = qlx.apply #qlx.action<pauli_rotation>(%48#0, %48#1, %48#2, %cst_36) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_37 = arith.constant 5.000000e-01 : f64
    %50:2 = qlx.apply #qlx.action<pauli_rotation>(%49#0, %49#1, %cst_37) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_38 = arith.constant 1.250000e-01 : f64
    %51:3 = qlx.apply #qlx.action<pauli_rotation>(%49#2, %50#0, %50#1, %cst_38) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_39 = arith.constant 1.250000e-01 : f64
    %52:3 = qlx.apply #qlx.action<pauli_rotation>(%51#0, %51#1, %51#2, %cst_39) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_40 = arith.constant 1.250000e-01 : f64
    %53:3 = qlx.apply #qlx.action<pauli_rotation>(%47#2, %52#0, %52#2, %cst_40) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_41 = arith.constant 1.250000e-01 : f64
    %54:3 = qlx.apply #qlx.action<pauli_rotation>(%53#0, %53#1, %53#2, %cst_41) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_42 = arith.constant 1.250000e-01 : f64
    %55:7 = qlx.apply #qlx.action<pauli_rotation>(%45#2, %45#3, %45#6, %52#1, %54#0, %54#1, %54#2, %cst_42) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 118 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_43 = arith.constant 1.250000e-01 : f64
    %56:7 = qlx.apply #qlx.action<pauli_rotation>(%55#0, %55#1, %55#2, %55#3, %55#4, %55#5, %55#6, %cst_43) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_44 = arith.constant 1.250000e-01 : f64
    %57:7 = qlx.apply #qlx.action<pauli_rotation>(%43#1, %56#0, %56#1, %56#2, %56#4, %56#5, %56#6, %cst_44) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 62 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_45 = arith.constant 1.250000e-01 : f64
    %58:7 = qlx.apply #qlx.action<pauli_rotation>(%57#0, %57#1, %57#2, %57#3, %57#4, %57#5, %57#6, %cst_45) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_46 = arith.constant 1.250000e-01 : f64
    %59:3 = qlx.apply #qlx.action<pauli_rotation>(%58#3, %58#4, %58#5, %cst_46) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_47 = arith.constant 1.250000e-01 : f64
    %60:3 = qlx.apply #qlx.action<pauli_rotation>(%59#0, %59#1, %59#2, %cst_47) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_48 = arith.constant 1.250000e-01 : f64
    %61:3 = qlx.apply #qlx.action<pauli_rotation>(%58#2, %60#0, %60#1, %cst_48) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_49 = arith.constant 1.250000e-01 : f64
    %62:3 = qlx.apply #qlx.action<pauli_rotation>(%61#0, %61#1, %61#2, %cst_49) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_50 = arith.constant 1.250000e-01 : f64
    %63:3 = qlx.apply #qlx.action<pauli_rotation>(%58#1, %62#0, %62#1, %cst_50) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_51 = arith.constant 1.250000e-01 : f64
    %64:3 = qlx.apply #qlx.action<pauli_rotation>(%63#0, %63#1, %63#2, %cst_51) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_52 = arith.constant 1.250000e-01 : f64
    %65:3 = qlx.apply #qlx.action<pauli_rotation>(%58#0, %64#0, %64#1, %cst_52) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_53 = arith.constant 1.250000e-01 : f64
    %66:3 = qlx.apply #qlx.action<pauli_rotation>(%65#0, %65#1, %65#2, %cst_53) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_54 = arith.constant 2.500000e-01 : f64
    %67:2 = qlx.apply #qlx.action<pauli_rotation>(%60#2, %62#2, %cst_54) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_55 = arith.constant 2.500000e-01 : f64
    %68:2 = qlx.apply #qlx.action<pauli_rotation>(%64#2, %66#2, %cst_55) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_56 = arith.constant 5.000000e-01 : f64
    %69:2 = qlx.apply #qlx.action<pauli_rotation>(%66#0, %66#1, %cst_56) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_57 = arith.constant 2.500000e-01 : f64
    %70:2 = qlx.apply #qlx.action<pauli_rotation>(%68#0, %68#1, %cst_57) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_58 = arith.constant 2.500000e-01 : f64
    %71:2 = qlx.apply #qlx.action<pauli_rotation>(%67#0, %67#1, %cst_58) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_59 = arith.constant 1.250000e-01 : f64
    %72:3 = qlx.apply #qlx.action<pauli_rotation>(%69#0, %69#1, %70#1, %cst_59) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_60 = arith.constant 1.250000e-01 : f64
    %73:3 = qlx.apply #qlx.action<pauli_rotation>(%72#0, %72#1, %72#2, %cst_60) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_61 = arith.constant 1.250000e-01 : f64
    %74:3 = qlx.apply #qlx.action<pauli_rotation>(%70#0, %73#1, %73#2, %cst_61) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_62 = arith.constant 1.250000e-01 : f64
    %75:3 = qlx.apply #qlx.action<pauli_rotation>(%74#0, %74#1, %74#2, %cst_62) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_63 = arith.constant 1.250000e-01 : f64
    %76:3 = qlx.apply #qlx.action<pauli_rotation>(%71#1, %75#0, %75#2, %cst_63) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_64 = arith.constant 1.250000e-01 : f64
    %77:3 = qlx.apply #qlx.action<pauli_rotation>(%76#0, %76#1, %76#2, %cst_64) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_65 = arith.constant 1.250000e-01 : f64
    %78:3 = qlx.apply #qlx.action<pauli_rotation>(%71#0, %77#0, %77#1, %cst_65) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_66 = arith.constant 1.250000e-01 : f64
    %79:3 = qlx.apply #qlx.action<pauli_rotation>(%78#0, %78#1, %78#2, %cst_66) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_67 = arith.constant 1.250000e-01 : f64
    %80:7 = qlx.apply #qlx.action<pauli_rotation>(%58#6, %73#0, %75#1, %77#2, %79#0, %79#1, %79#2, %cst_67) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_68 = arith.constant 1.250000e-01 : f64
    %81:7 = qlx.apply #qlx.action<pauli_rotation>(%80#0, %80#1, %80#2, %80#3, %80#4, %80#5, %80#6, %cst_68) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 124 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_69 = arith.constant 1.250000e-01 : f64
    %82:7 = qlx.apply #qlx.action<pauli_rotation>(%56#3, %81#0, %81#2, %81#3, %81#4, %81#5, %81#6, %cst_69) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_70 = arith.constant 1.250000e-01 : f64
    %83:7 = qlx.apply #qlx.action<pauli_rotation>(%82#0, %82#1, %82#2, %82#3, %82#4, %82#5, %82#6, %cst_70) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 122 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_71 = arith.constant 1.250000e-01 : f64
    %84:3 = qlx.apply #qlx.action<pauli_rotation>(%83#1, %83#4, %83#5, %cst_71) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_72 = arith.constant 1.250000e-01 : f64
    %85:3 = qlx.apply #qlx.action<pauli_rotation>(%84#0, %84#1, %84#2, %cst_72) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_73 = arith.constant 1.250000e-01 : f64
    %86:3 = qlx.apply #qlx.action<pauli_rotation>(%83#0, %85#0, %85#1, %cst_73) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_74 = arith.constant 1.250000e-01 : f64
    %87:3 = qlx.apply #qlx.action<pauli_rotation>(%86#0, %86#1, %86#2, %cst_74) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_75 = arith.constant 5.000000e-01 : f64
    %88:2 = qlx.apply #qlx.action<pauli_rotation>(%87#0, %87#1, %cst_75) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_76 = arith.constant 1.250000e-01 : f64
    %89:3 = qlx.apply #qlx.action<pauli_rotation>(%87#2, %88#0, %88#1, %cst_76) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_77 = arith.constant 1.250000e-01 : f64
    %90:3 = qlx.apply #qlx.action<pauli_rotation>(%89#0, %89#1, %89#2, %cst_77) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_78 = arith.constant 1.250000e-01 : f64
    %91:3 = qlx.apply #qlx.action<pauli_rotation>(%85#2, %90#0, %90#2, %cst_78) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_79 = arith.constant 1.250000e-01 : f64
    %92:3 = qlx.apply #qlx.action<pauli_rotation>(%91#0, %91#1, %91#2, %cst_79) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_80 = arith.constant 1.250000e-01 : f64
    %93:7 = qlx.apply #qlx.action<pauli_rotation>(%83#2, %83#3, %83#6, %90#1, %92#0, %92#1, %92#2, %cst_80) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 118 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_81 = arith.constant 1.250000e-01 : f64
    %94:7 = qlx.apply #qlx.action<pauli_rotation>(%93#0, %93#1, %93#2, %93#3, %93#4, %93#5, %93#6, %cst_81) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_82 = arith.constant 1.250000e-01 : f64
    %95:7 = qlx.apply #qlx.action<pauli_rotation>(%81#1, %94#0, %94#1, %94#2, %94#4, %94#5, %94#6, %cst_82) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 62 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_83 = arith.constant 1.250000e-01 : f64
    %96:7 = qlx.apply #qlx.action<pauli_rotation>(%95#0, %95#1, %95#2, %95#3, %95#4, %95#5, %95#6, %cst_83) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_84 = arith.constant 1.250000e-01 : f64
    %97:3 = qlx.apply #qlx.action<pauli_rotation>(%96#3, %96#4, %96#5, %cst_84) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_85 = arith.constant 1.250000e-01 : f64
    %98:3 = qlx.apply #qlx.action<pauli_rotation>(%97#0, %97#1, %97#2, %cst_85) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_86 = arith.constant 1.250000e-01 : f64
    %99:3 = qlx.apply #qlx.action<pauli_rotation>(%96#2, %98#0, %98#1, %cst_86) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_87 = arith.constant 1.250000e-01 : f64
    %100:3 = qlx.apply #qlx.action<pauli_rotation>(%99#0, %99#1, %99#2, %cst_87) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_88 = arith.constant 1.250000e-01 : f64
    %101:3 = qlx.apply #qlx.action<pauli_rotation>(%96#1, %100#0, %100#1, %cst_88) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_89 = arith.constant 1.250000e-01 : f64
    %102:3 = qlx.apply #qlx.action<pauli_rotation>(%101#0, %101#1, %101#2, %cst_89) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_90 = arith.constant 1.250000e-01 : f64
    %103:3 = qlx.apply #qlx.action<pauli_rotation>(%96#0, %102#0, %102#1, %cst_90) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_91 = arith.constant 1.250000e-01 : f64
    %104:3 = qlx.apply #qlx.action<pauli_rotation>(%103#0, %103#1, %103#2, %cst_91) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_92 = arith.constant 2.500000e-01 : f64
    %105:2 = qlx.apply #qlx.action<pauli_rotation>(%98#2, %100#2, %cst_92) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_93 = arith.constant 2.500000e-01 : f64
    %106:2 = qlx.apply #qlx.action<pauli_rotation>(%102#2, %104#2, %cst_93) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_94 = arith.constant 5.000000e-01 : f64
    %107:2 = qlx.apply #qlx.action<pauli_rotation>(%104#0, %104#1, %cst_94) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_95 = arith.constant 2.500000e-01 : f64
    %108:2 = qlx.apply #qlx.action<pauli_rotation>(%106#0, %106#1, %cst_95) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_96 = arith.constant 2.500000e-01 : f64
    %109:2 = qlx.apply #qlx.action<pauli_rotation>(%105#0, %105#1, %cst_96) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_97 = arith.constant 1.250000e-01 : f64
    %110:3 = qlx.apply #qlx.action<pauli_rotation>(%107#0, %107#1, %108#1, %cst_97) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_98 = arith.constant 1.250000e-01 : f64
    %111:3 = qlx.apply #qlx.action<pauli_rotation>(%110#0, %110#1, %110#2, %cst_98) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_99 = arith.constant 1.250000e-01 : f64
    %112:3 = qlx.apply #qlx.action<pauli_rotation>(%108#0, %111#1, %111#2, %cst_99) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_100 = arith.constant 1.250000e-01 : f64
    %113:3 = qlx.apply #qlx.action<pauli_rotation>(%112#0, %112#1, %112#2, %cst_100) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_101 = arith.constant 1.250000e-01 : f64
    %114:3 = qlx.apply #qlx.action<pauli_rotation>(%109#1, %113#0, %113#2, %cst_101) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_102 = arith.constant 1.250000e-01 : f64
    %115:3 = qlx.apply #qlx.action<pauli_rotation>(%114#0, %114#1, %114#2, %cst_102) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_103 = arith.constant 1.250000e-01 : f64
    %116:3 = qlx.apply #qlx.action<pauli_rotation>(%109#0, %115#0, %115#1, %cst_103) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_104 = arith.constant 1.250000e-01 : f64
    %117:3 = qlx.apply #qlx.action<pauli_rotation>(%116#0, %116#1, %116#2, %cst_104) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_105 = arith.constant 1.250000e-01 : f64
    %118:7 = qlx.apply #qlx.action<pauli_rotation>(%96#6, %111#0, %113#1, %115#2, %117#0, %117#1, %117#2, %cst_105) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_106 = arith.constant 1.250000e-01 : f64
    %119:7 = qlx.apply #qlx.action<pauli_rotation>(%118#0, %118#1, %118#2, %118#3, %118#4, %118#5, %118#6, %cst_106) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 124 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_107 = arith.constant 1.250000e-01 : f64
    %120:7 = qlx.apply #qlx.action<pauli_rotation>(%94#3, %119#0, %119#2, %119#3, %119#4, %119#5, %119#6, %cst_107) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_108 = arith.constant 1.250000e-01 : f64
    %121:7 = qlx.apply #qlx.action<pauli_rotation>(%120#0, %120#1, %120#2, %120#3, %120#4, %120#5, %120#6, %cst_108) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 122 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_109 = arith.constant 1.250000e-01 : f64
    %122:3 = qlx.apply #qlx.action<pauli_rotation>(%121#1, %121#4, %121#5, %cst_109) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_110 = arith.constant 1.250000e-01 : f64
    %123:3 = qlx.apply #qlx.action<pauli_rotation>(%122#0, %122#1, %122#2, %cst_110) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_111 = arith.constant 1.250000e-01 : f64
    %124:3 = qlx.apply #qlx.action<pauli_rotation>(%121#0, %123#0, %123#1, %cst_111) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_112 = arith.constant 1.250000e-01 : f64
    %125:3 = qlx.apply #qlx.action<pauli_rotation>(%124#0, %124#1, %124#2, %cst_112) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_113 = arith.constant 5.000000e-01 : f64
    %126:2 = qlx.apply #qlx.action<pauli_rotation>(%125#0, %125#1, %cst_113) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_114 = arith.constant 1.250000e-01 : f64
    %127:3 = qlx.apply #qlx.action<pauli_rotation>(%125#2, %126#0, %126#1, %cst_114) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_115 = arith.constant 1.250000e-01 : f64
    %128:3 = qlx.apply #qlx.action<pauli_rotation>(%127#0, %127#1, %127#2, %cst_115) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_116 = arith.constant 1.250000e-01 : f64
    %129:3 = qlx.apply #qlx.action<pauli_rotation>(%123#2, %128#0, %128#2, %cst_116) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_117 = arith.constant 1.250000e-01 : f64
    %130:3 = qlx.apply #qlx.action<pauli_rotation>(%129#0, %129#1, %129#2, %cst_117) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_118 = arith.constant 1.250000e-01 : f64
    %131:7 = qlx.apply #qlx.action<pauli_rotation>(%121#2, %121#3, %121#6, %128#1, %130#0, %130#1, %130#2, %cst_118) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 118 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_119 = arith.constant 1.250000e-01 : f64
    %132:7 = qlx.apply #qlx.action<pauli_rotation>(%131#0, %131#1, %131#2, %131#3, %131#4, %131#5, %131#6, %cst_119) {parameters = {sign = -1 : i64, x_mask = 9 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_120 = arith.constant 1.250000e-01 : f64
    %133:7 = qlx.apply #qlx.action<pauli_rotation>(%119#1, %132#0, %132#1, %132#2, %132#4, %132#5, %132#6, %cst_120) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 62 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_121 = arith.constant 1.250000e-01 : f64
    %134:7 = qlx.apply #qlx.action<pauli_rotation>(%133#0, %133#1, %133#2, %133#3, %133#4, %133#5, %133#6, %cst_121) {parameters = {sign = -1 : i64, x_mask = 65 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_122 = arith.constant 1.250000e-01 : f64
    %135:3 = qlx.apply #qlx.action<pauli_rotation>(%134#3, %134#4, %134#5, %cst_122) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_123 = arith.constant 1.250000e-01 : f64
    %136:3 = qlx.apply #qlx.action<pauli_rotation>(%135#0, %135#1, %135#2, %cst_123) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_124 = arith.constant 1.250000e-01 : f64
    %137:3 = qlx.apply #qlx.action<pauli_rotation>(%134#2, %136#0, %136#1, %cst_124) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_125 = arith.constant 1.250000e-01 : f64
    %138:3 = qlx.apply #qlx.action<pauli_rotation>(%137#0, %137#1, %137#2, %cst_125) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_126 = arith.constant 1.250000e-01 : f64
    %139:3 = qlx.apply #qlx.action<pauli_rotation>(%134#1, %138#0, %138#1, %cst_126) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_127 = arith.constant 1.250000e-01 : f64
    %140:3 = qlx.apply #qlx.action<pauli_rotation>(%139#0, %139#1, %139#2, %cst_127) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_128 = arith.constant 1.250000e-01 : f64
    %141:3 = qlx.apply #qlx.action<pauli_rotation>(%134#0, %140#0, %140#1, %cst_128) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_129 = arith.constant 1.250000e-01 : f64
    %142:3 = qlx.apply #qlx.action<pauli_rotation>(%141#0, %141#1, %141#2, %cst_129) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_130 = arith.constant 2.500000e-01 : f64
    %143:2 = qlx.apply #qlx.action<pauli_rotation>(%136#2, %138#2, %cst_130) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_131 = arith.constant 2.500000e-01 : f64
    %144:2 = qlx.apply #qlx.action<pauli_rotation>(%140#2, %142#2, %cst_131) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_132 = arith.constant 5.000000e-01 : f64
    %145:2 = qlx.apply #qlx.action<pauli_rotation>(%142#0, %142#1, %cst_132) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_133 = arith.constant 2.500000e-01 : f64
    %146:2 = qlx.apply #qlx.action<pauli_rotation>(%144#0, %144#1, %cst_133) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_134 = arith.constant 2.500000e-01 : f64
    %147:2 = qlx.apply #qlx.action<pauli_rotation>(%143#0, %143#1, %cst_134) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %cst_135 = arith.constant 1.250000e-01 : f64
    %148:3 = qlx.apply #qlx.action<pauli_rotation>(%145#0, %145#1, %146#1, %cst_135) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_136 = arith.constant 1.250000e-01 : f64
    %149:3 = qlx.apply #qlx.action<pauli_rotation>(%148#0, %148#1, %148#2, %cst_136) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_137 = arith.constant 1.250000e-01 : f64
    %150:3 = qlx.apply #qlx.action<pauli_rotation>(%146#0, %149#1, %149#2, %cst_137) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_138 = arith.constant 1.250000e-01 : f64
    %151:3 = qlx.apply #qlx.action<pauli_rotation>(%150#0, %150#1, %150#2, %cst_138) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 4 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_139 = arith.constant 1.250000e-01 : f64
    %152:3 = qlx.apply #qlx.action<pauli_rotation>(%147#1, %151#0, %151#2, %cst_139) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_140 = arith.constant 1.250000e-01 : f64
    %153:3 = qlx.apply #qlx.action<pauli_rotation>(%152#0, %152#1, %152#2, %cst_140) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_141 = arith.constant 1.250000e-01 : f64
    %154:3 = qlx.apply #qlx.action<pauli_rotation>(%147#0, %153#0, %153#1, %cst_141) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_142 = arith.constant 1.250000e-01 : f64
    %155:3 = qlx.apply #qlx.action<pauli_rotation>(%154#0, %154#1, %154#2, %cst_142) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_143 = arith.constant 1.250000e-01 : f64
    %156:7 = qlx.apply #qlx.action<pauli_rotation>(%134#6, %149#0, %151#1, %153#2, %155#0, %155#1, %155#2, %cst_143) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_144 = arith.constant 1.250000e-01 : f64
    %157:7 = qlx.apply #qlx.action<pauli_rotation>(%156#0, %156#1, %156#2, %156#3, %156#4, %156#5, %156#6, %cst_144) {parameters = {sign = -1 : i64, x_mask = 3 : i64, z_mask = 124 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_145 = arith.constant 1.250000e-01 : f64
    %158:7 = qlx.apply #qlx.action<pauli_rotation>(%132#3, %157#0, %157#2, %157#3, %157#4, %157#5, %157#6, %cst_145) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 127 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_146 = arith.constant 1.250000e-01 : f64
    %159:7 = qlx.apply #qlx.action<pauli_rotation>(%158#0, %158#1, %158#2, %158#3, %158#4, %158#5, %158#6, %cst_146) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 122 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_147 = arith.constant 1.250000e-01 : f64
    %160:3 = qlx.apply #qlx.action<pauli_rotation>(%159#1, %159#4, %159#5, %cst_147) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_148 = arith.constant 1.250000e-01 : f64
    %161:3 = qlx.apply #qlx.action<pauli_rotation>(%160#0, %160#1, %160#2, %cst_148) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_149 = arith.constant 1.250000e-01 : f64
    %162:3 = qlx.apply #qlx.action<pauli_rotation>(%159#0, %161#0, %161#1, %cst_149) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 7 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_150 = arith.constant 1.250000e-01 : f64
    %163:3 = qlx.apply #qlx.action<pauli_rotation>(%162#0, %162#1, %162#2, %cst_150) {parameters = {sign = -1 : i64, x_mask = 5 : i64, z_mask = 2 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit, !qlx.logical_qubit)
    %cst_151 = arith.constant 2.500000e-01 : f64
    %164:2 = qlx.apply #qlx.action<pauli_rotation>(%163#0, %163#1, %cst_151) {parameters = {sign = 1 : i64, x_mask = 0 : i64, z_mask = 3 : i64}} : (!qlx.logical_qubit, !qlx.logical_qubit, f64) -> (!qlx.logical_qubit, !qlx.logical_qubit)
    %165 = qlx.measure <Z> %164#0 : !qlx.logical_qubit -> i1
    %166 = qlx.measure <Z> %164#1 : !qlx.logical_qubit -> i1
    %167 = qlx.measure <Z> %163#2 : !qlx.logical_qubit -> i1
    %168 = qlx.measure <Z> %161#2 : !qlx.logical_qubit -> i1
    %169 = qlx.measure <Z> %159#6 : !qlx.logical_qubit -> i1
    %170 = qlx.measure <Z> %159#3 : !qlx.logical_qubit -> i1
    %171 = qlx.measure <Z> %159#2 : !qlx.logical_qubit -> i1
    %172 = qlx.measure <Z> %157#1 : !qlx.logical_qubit -> i1
  }
}
